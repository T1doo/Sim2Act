# Sim2Act 限制本地候选

正常入口、已有依赖环境的安装／启动／退出／重开见 [限制候选步骤](docs/LimitedTextCandidate.md)。
历史 mock 演示见 [本地候选说明](docs/LocalCandidate.md)。
精确源码和文件校验值见 candidate-manifest.json。
不含真实凭据、数据库或历史大证据；默认不启用模型，显式参数只开放单文本逐字合同。
