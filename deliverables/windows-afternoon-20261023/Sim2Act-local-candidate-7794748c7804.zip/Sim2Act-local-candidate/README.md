# Sim2Act 合成 mock 本地候选

安装、演示命令及限制见 [本地候选说明](docs/LocalCandidate.md)。
精确源码和文件校验值见 candidate-manifest.json。
不含真实凭据、数据库或历史大证据；不启用真实模型。
