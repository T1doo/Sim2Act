@echo off
setlocal
cd /d "%~dp0"
set "TEMP=%~dp0temp"
set "TMP=%~dp0temp"
set "PYTHONPATH="
set "PYTHONNOUSERSITE=1"
if not exist "%~dp0temp" mkdir "%~dp0temp"
"%~dp0runtime\python.exe" -I -B -X utf8 "%~dp0desktop.py"
set "SIM2ACT_PREVIEW_EXIT=%ERRORLEVEL%"
echo.
echo Preview stopped. Close the test Edge window before deleting this folder.
pause
exit /b %SIM2ACT_PREVIEW_EXIT%
