@echo off
setlocal
cd /d "%~dp0"
"%~dp0runtime\python.exe" -I -B -X utf8 "%~dp0desktop.py" --browser-preview
exit /b %ERRORLEVEL%
