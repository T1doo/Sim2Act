@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0Sim2Act.exe" (echo Native desktop build required. See desktop-build/README.md & exit /b 1)
"%~dp0Sim2Act.exe"
exit /b %ERRORLEVEL%
