# Same-source compiled Windows package

Source: `042ab21c4fa9c7e5ba70c4e2877fb7060d962422`.

Four Windows CPython extensions and the independent WinForms/WebView2 EXE are built. The private Python backend is checked with synthetic SQLite/CSV only; the desktop EXE/WebView2 window is NOT executed. This is an internal engineering build, not a final product acceptance or Release. Old portable-manifest labels describe the unchanged input assembly stage; full-package-manifest.json is the final inventory.

Target prerequisites: Windows x64/UCRT, existing .NET Framework 4.6.2+, existing WebView2 Runtime. No system runtime/security setting is installed. Any additional unbundled native import is recorded below and must be resolved on the target before calling it a clean-machine acceptance. Do not bypass security refusals or substitute old application binaries.

[
  "advapi32.dll",
  "api-ms-win-core-path-l1-1-0.dll",
  "api-ms-win-core-synch-l1-2-0.dll",
  "api-ms-win-crt-conio-l1-1-0.dll",
  "api-ms-win-crt-convert-l1-1-0.dll",
  "api-ms-win-crt-environment-l1-1-0.dll",
  "api-ms-win-crt-filesystem-l1-1-0.dll",
  "api-ms-win-crt-heap-l1-1-0.dll",
  "api-ms-win-crt-locale-l1-1-0.dll",
  "api-ms-win-crt-math-l1-1-0.dll",
  "api-ms-win-crt-process-l1-1-0.dll",
  "api-ms-win-crt-runtime-l1-1-0.dll",
  "api-ms-win-crt-stdio-l1-1-0.dll",
  "api-ms-win-crt-string-l1-1-0.dll",
  "api-ms-win-crt-time-l1-1-0.dll",
  "api-ms-win-crt-utility-l1-1-0.dll",
  "bcrypt.dll",
  "bcryptprimitives.dll",
  "cabinet.dll",
  "crypt32.dll",
  "iphlpapi.dll",
  "kernel32.dll",
  "mscoree.dll",
  "msi.dll",
  "ntdll.dll",
  "ole32.dll",
  "oleaut32.dll",
  "pdh.dll",
  "powrprof.dll",
  "propsys.dll",
  "psapi.dll",
  "rpcrt4.dll",
  "shell32.dll",
  "user32.dll",
  "version.dll",
  "winmm.dll",
  "ws2_32.dll"
]
