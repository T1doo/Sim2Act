# Sim2Act compiled desktop host component

Exact host source: `7bf6fd84fd694efe8348e1b565b01ad2e0765c40`.

CROSS_COMPILED_NOT_WINDOWS_EXECUTED. This is the real WinForms/WebView2 host, not a browser launcher. It is a maintainer build component, not a complete installer or ready-to-use product. It does not include the private Windows Python runtime, matching Windows application wheel/four native extensions, or a desktop execution acceptance. Assemble only with the same exact application revision and preserve its READY/STOPPED, authorization, origin, lease, cancellation and persistence checks. No Windows runtime or system permission is installed by this build.
