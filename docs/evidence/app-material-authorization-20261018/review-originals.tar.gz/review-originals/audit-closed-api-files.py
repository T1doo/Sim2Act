"""Stdlib file-only review; never imports Sim2Act or opens any database."""
from pathlib import Path
import collections
import hashlib
import json

ROOT=Path('/workspace/app-material-authorization-20261018')
OUT=Path('/workspace/app-material-authorization-review-20261018')
def read(p):
    return json.loads(p.read_text())
def fp(v):
    return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def protected(b,a,changed):
    assert set(b)==set(a) and len(b)==55
    assert {t for t in b if b[t]!=a[t]}==set(changed)
def journal(b,a,kind,body,value):
    added=[r for r in a['delivery_graph_requests'] if r not in b['delivery_graph_requests']]
    assert len(added)==2
    assert {r['kind'] for r in added}=={kind,kind+'_seal'}
    f=value['receipt'];record=f['record']
    assert record['request_fingerprint']==fp(body)
    assert f['fingerprint']==fp({k:v for k,v in f.items() if k!='fingerprint'})
    assert added[0]['snapshot']==added[1]['snapshot']=={'request':record,'response':f}
    for r in added:
        assert r['fingerprint']==fp(r['snapshot'])
        assert r['request_fingerprint']==fp(record)
        assert r['request_key']==body['request_key']==record['request_key']
        assert r['app_id']==record['app_id'] and r['principal_id']==record['principal_id']
    return added

cmd=read(ROOT/'api-final/command.json')
assert cmd['exit_code']==0 and cmd['status']=='PASS' and cmd['before']==cmd['after']
stdout=(ROOT/'api-final/stdout').read_text()
assert '4 passed' in stdout
byname={d.name:d for d in (ROOT/'api-final/data').iterdir() if d.is_dir() and not d.is_symlink()}
assert set(byname)=={'test_exact_App_only_two_grants0','test_expiry_during_existing_Ap0','test_foreign_project_and_missi0','test_metadata_atomic_withdraw_0'}
x=read(byname['test_exact_App_only_two_grants0']/'exact-app-material-authority.json')
b,a=x['before'],x['after'];protected(b,a,['grants','delivery_graph_requests'])
v=x['response'];body=x['request'];record=v['receipt']['record']
runtime=next(r['runtime_id'] for r in b['app_drafts'] if r['id']==x['app_id'])
created=[r for r in a['grants'] if r not in b['grants']]
assert len(created)==2 and {r['tool_ref'] for r in created}=={'resource.read','data.aggregate_csv'}
assert all(r['principal_id']==runtime==record['runtime_id'] and r['project_id']==record['project_id'] and r['resource_id']==body['resource_id'] and r['revision']==1 and r['revoked'] is False and r['expires_at']==v['receipt']['created_at']+86400 for r in created)
assert not [r for r in b['grants'] if r['principal_id']==runtime and r['resource_id']==body['resource_id']]
assert all(r in a['grants'] for r in b['grants'])
assert sorted(v['receipt']['grants'],key=lambda r:r['id'])==sorted(created,key=lambda r:r['id']) and v['receipt_status']==v['app_material_status']=='ACTIVE'
assert body['expected_app_grants_fingerprint']==fp([]) and body['expected_grant_version']==fp(sorted(b['grants'],key=lambda r:r['id']))
j=journal(b,a,'csv-app-material-access.v1.authorize',body,v)
assert body['expected_source_hash'] not in json.dumps(j)
assert x['fixture_App_B_grants']==0 and x['stale']['status']==409

w=read(byname['test_metadata_atomic_withdraw_0']/'withdraw-and-late-replay.json')
b,a=w['before'],w['after'];protected(b,a,['grants','delivery_graph_requests'])
ids={r['id'] for r in w['original_authorization']['receipt']['grants']}
for old in b['grants']:
    new=next(r for r in a['grants'] if r['id']==old['id'])
    assert new==({**old,'revoked':True,'revision':old['revision']+1} if old['id'] in ids else old)
assert len(a['grants'])==len(b['grants'])
assert w['withdraw_response']['receipt_status']==w['late_response']['receipt_status']=='REVOKED'
assert w['withdraw_response']['upstream_available'] is False
journal(b,a,'csv-app-material-access.v1.revoke',w['withdraw_request'],w['withdraw_response'])
for name,filename in [('test_expiry_during_existing_Ap0','expiry-proof-boundary.json'),('test_foreign_project_and_missi0','scope-and-upstream.json')]:
    p=read(byname[name]/filename);protected(p['before'],p['after'],[])

traces=[];proofs={}
for name,d in sorted(byname.items()):
    rows=read(d/'actual-http.json');traces+=rows
    proofs[name]={'ASGI_structured_request_count':len(rows),'response_codes':dict(collections.Counter(str(r['status']) for r in rows))}
assert len(traces)==47
files={}
for p in sorted((ROOT/'api-final').rglob('*')):
    if not p.is_file() or p.is_symlink() or any(q.is_symlink() for q in p.parents if q!=ROOT):
        continue
    if p.suffix not in {'.json'} and p.name not in {'stdout','stderr'}:
        continue
    if 'pytest-cache' in str(p) or '__pycache__' in str(p):
        continue
    data=p.read_bytes();files[str(p.relative_to(ROOT))]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
result={'status':'PASS_PURE_CLOSED_FILE_AUDIT','qualification':'4 distinct ASGI TestClient cases, author pytest4PASS11.95s/outer16.756770785999834; reviewer did not run them',
        'ASGI_trace_requests_including_fixture':47,'test_cases':proofs,'full_55_table_JSON_recomputed':True,
        'checks':{'authorize_exact_two_App_B_rows_and_two_seals':True,'no_fixture_App_B_Grant':True,'full_body_and_independent_seal_fingerprints':True,'read_key_does_not_include_private_source_hash':True,'withdraw_exact_group_revoked_and_non_authority_53_tables_preserved':True,'expiry_and_scope_full55_unchanged':True},
        'source_freeze':cmd['before'],'source_before_after_equal':True,'files':files,
        'limits':['These traces are in-process ASGI/TestClient structured requests, not loopback/wire or native browser','No database content read or database hash recomputed','No product imports/tests/Worker/model/Git/network executed','Pure table comparisons are exported synthetic JSON, not independent SQL reconstruction','Current installed UI remains pending; no overall feature/runtime verdict from this API-only audit','Pytest current symlinks excluded; four unique fixture directories only']}
(OUT/'closed-api-file-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in {'files','source_freeze','checks','limits'}},ensure_ascii=False,indent=2))
