"""Independent stdlib file/zip/AST review. No product imports, DB or network."""
from pathlib import Path
import ast,collections,hashlib,json,zipfile
A=Path('/workspace/app-material-authorization-20261018');Q=A/'qualified-final';R=Path('/workspace/Sim2Act');O=Path('/workspace/app-material-authorization-review-20261018')
def load(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def encoded(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()
def fp(x):return sha(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode())
def same_tables(b,a,allowed):
 assert set(b)==set(a) and len(b)==55
 changed={k for k in b if b[k]!=a[k]};assert changed<=set(allowed),(changed,allowed)
 return sorted(changed)
def exact_pair(b,a,kind,body,response):
 rows=[r for r in a['delivery_graph_requests'] if r not in b['delivery_graph_requests']]
 assert len(rows)==2 and {r['kind'] for r in rows}=={kind,kind+'_seal'}
 f=response['receipt'];rec=f['record'];assert rec['request_fingerprint']==fp(body)
 assert f['fingerprint']==fp({k:v for k,v in f.items() if k!='fingerprint'})
 assert rows[0]['snapshot']==rows[1]['snapshot']=={'request':rec,'response':f}
 for r in rows:
  assert r['fingerprint']==fp(r['snapshot']) and r['request_fingerprint']==fp(rec)
  assert (r['request_key'],r['app_id'],r['principal_id'])==(rec['request_key'],rec['app_id'],rec['principal_id'])
 return rows

def rejection(value,row,aid,pid,principal,runtime):
 p=value['error']['submission_rejection'];body=row['request_body']
 assert set(p)=={'namespace','app_id','project_id','principal_id','runtime_id','kind','request_key','request_fingerprint','acceptance','previous_request','phase'}
 assert p==dict(namespace='csv-app-material-access.v1.rejection',app_id=aid,project_id=pid,principal_id=principal,runtime_id=runtime,kind='csv-app-material-access.v1.authorize',request_key=body['request_key'],request_fingerprint=fp(body),acceptance='NOT_ACCEPTED',previous_request='ABSENT',phase='TX_ROLLED_BACK')
 return p

final9=load(A/'final-source-hashes.json');assert len(final9)==9
assert all(sha((R/p).read_bytes())==h for p,h in final9.items())
before=load(A/'runtime-final-source-before.json');after=load(A/'runtime-final-source-after.json');assert before==after and len(before)==142
assert all(sha((R/p).read_bytes())==h for p,h in before.items())
expected={p.removeprefix('src/'):h for p,h in before.items() if p.startswith('src/sim2act/')};assert len(expected)==140
for p in ['src/sim2act/api.py','src/sim2act/apps.py','src/sim2act/csv_material_access.py','tests/test_csv_material_access.py']:ast.parse((R/p).read_text(),filename=p)
wheel=next((Q/'wheel').glob('*.whl'));assert wheel.stat().st_size==952178 and sha(wheel.read_bytes())=='0f581efd1c296ae43357cefdf99bb84afaa8cb867004f2ff4d43a9053b9f1e60'
with zipfile.ZipFile(wheel) as z:zipmap={n:sha(z.read(n)) for n in z.namelist() if n.startswith('sim2act/') and not n.endswith('/')}
assert zipmap==expected==load(Q/'wheel-files.json')
site=Q/'installed-venv/lib/python3.12/site-packages'
assert {n:sha((site/n).read_bytes()) for n in expected}==expected
assert sha((Q/'execution-source/tests/initial_material_revision.cjs').read_bytes())==before['tests/initial_material_revision.cjs']

# Final API execution: in-process ASGI/TestClient, not socket/wire requests.
api=A/'api-qualified-final';cmd=load(api/'command.json');assert cmd['status']=='PASS' and cmd['exit_code']==0 and cmd['before']==cmd['after']
assert all(before[p]==h for p,h in cmd['before'].items())
assert '4 passed' in (api/'stdout').read_text() and '8.88s' in (api/'stdout').read_text()
dirs=sorted(d for d in (api/'data').iterdir() if d.is_dir() and not d.is_symlink());assert len(dirs)==4
traces=[];api_details={}
for d in dirs:
 rows=load(d/'actual-http.json');traces+=rows;api_details[d.name]={'requests_including_fixture':len(rows),'status_counts':dict(collections.Counter(str(x['status']) for x in rows))}
 for p in d.glob('*.json'):
  if p.name=='actual-http.json':continue
  v=load(p)
  if p.name=='exact-app-material-authority.json':
   b,a=v['before'],v['after'];assert set(same_tables(b,a,['grants','delivery_graph_requests']))=={'grants','delivery_graph_requests'}
   added=[g for g in a['grants'] if g not in b['grants']];f=v['response']['receipt'];rec=f['record']
   assert len(added)==2 and {g['tool_ref'] for g in added}=={'resource.read','data.aggregate_csv'}
   assert sorted(added,key=lambda g:g['id'])==sorted(f['grants'],key=lambda g:g['id'])
   assert all(g['principal_id']==rec['runtime_id'] and g['project_id']==rec['project_id'] and g['resource_id']==rec['resource_id'] and g['revision']==1 and not g['revoked'] and g['expires_at']==f['created_at']+86400 for g in added)
   exact_pair(b,a,'csv-app-material-access.v1.authorize',v['request'],v['response'])
   samekey=[x for x in rows if x['method']=='POST' and x['path'].endswith('/authorizations') and x.get('body',{}).get('request_key')==v['request']['request_key']]
   wrong=[x for x in samekey if x['status']==409 and x['body'].get('expected_source_hash')=='0'*64];assert len(wrong)==2
   assert 'submission_rejection' in wrong[0]['response']['error'] and 'submission_rejection' not in wrong[1]['response']['error']
   proof=wrong[0]['response']['error']['submission_rejection'];assert proof['request_fingerprint']==fp(wrong[0]['body'])
  elif p.name=='withdraw-and-late-replay.json':
   b,a=v['before'],v['after'];same_tables(b,a,['grants','delivery_graph_requests']);ids={g['id'] for g in v['original_authorization']['receipt']['grants']}
   assert len(a['grants'])==len(b['grants'])
   for g in b['grants']:assert next(n for n in a['grants'] if n['id']==g['id'])==({**g,'revoked':True,'revision':g['revision']+1} if g['id'] in ids else g)
   exact_pair(b,a,'csv-app-material-access.v1.revoke',v['withdraw_request'],v['withdraw_response']);assert v['late_response']['receipt_status']=='REVOKED'
  else:assert same_tables(v['before'],v['after'],[])==[]

report=load(Q/'installed-result.json');assert report['status']=='PASS' and all(x['exit_code']==0 for x in report['commands'])
assert len(report['processes'])==3 and all(p['exit_code']==0 and p['stopped'][0]['clean'] and p['stopped'][0]['worker_stopped'] for p in report['processes'])
fixture=load(Q/'fixture.json');base=load(Q/'fixture-before-ui.json');app=next(x for x in base['app_drafts'] if x['id']==fixture['app_id']);runtime=app['runtime_id'];pid=fixture['project_id'];aid=fixture['app_id'];iid=fixture['instance_id'];principal=fixture['principal_id']
assert len(base)==55 and not base['runs'] and fixture['fixture_App_B_grants']==0 and app['candidate']['manifest']['revision']==fixture['goal']['goal_version']==1
assert not [g for g in base['grants'] if g['principal_id']==runtime and g['resource_id']==fixture['B_id']]
pages={n:load(Q/(n+'-proof.json')) for n in ['new-page','cold-page','withdraw-page']}
assert [(len(pages[n]['checks']),len(pages[n]['requests'])) for n in pages]==[(29,102),(9,56),(13,61)]
# Validate every actual response digest. JSON order retained by proof; HTML derived from immutable packaged banner.
module=ast.parse((site/'sim2act/synthetic_workspace.py').read_text())
constants={}
def static_string(n):
 if isinstance(n,ast.Constant) and isinstance(n.value,str):return n.value
 if isinstance(n,ast.Name) and n.id in constants:return constants[n.id]
 if isinstance(n,ast.BinOp) and isinstance(n.op,ast.Add):return static_string(n.left)+static_string(n.right)
 raise ValueError('Only literal strings, earlier string constants and string addition supported')
for n in module.body:
 if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
  if n.targets[0].id in {'TOKEN','BANNER'}:constants[n.targets[0].id]=static_string(n.value)
banner=constants['BANNER']
html=(site/'sim2act/web/index.html').read_text().replace('<body>','<body>'+banner,1).encode()
response_digests=0;codes=collections.Counter();methods=collections.Counter();by_page={}
for name,page in pages.items():
 assert page['status']=='PASS' and page['phase']=='complete';assert page['browser']==page['visual']=='NOT_RUN'
 for row in page['requests']:
  codes[str(row['status'])]+=1;methods[row['method']]+=1
  raw=encoded(row['response']) if row['path'].startswith('/api/') else html if row['path']=='/' else (site/'sim2act/web'/row['path'].lstrip('/')).read_bytes()
  assert sha(raw)==row['sha256'],(name,row['path']);response_digests+=1
 for asset in page['assets']:assert sha((site/'sim2act/web'/asset['src'].lstrip('/')).read_bytes())==asset['sha256']
 bad=[r for r in page['requests'] if r['status']==400];assert len(bad)==1 and bad[0]['path'].endswith('/protocol/contracts') and bad[0]['response']['error']['code']=='RESOURCE_UNAVAILABLE'
 by_page[name]={'checks':len(page['checks']),'requests':len(page['requests']),'javascript_assets':len(page['assets']),'methods':dict(collections.Counter(x['method'] for x in page['requests']))}
assert response_digests==219 and all(x['method']=='GET' for x in pages['cold-page']['requests'])
new=pages['new-page'];withdraw=pages['withdraw-page']
auth_posts=[x for x in new['requests'] if x['method']=='POST' and x['path'].endswith('/csv-material-access/authorizations')];assert [x['status'] for x in auth_posts]==[409,201]
reject=rejection(auth_posts[0]['response'],auth_posts[0],aid,pid,principal,runtime)
same_tables(load(Q/'before-rejected.json'),load(Q/'after-rejected.json'),['heartbeats'])
b,a=load(Q/'before-authorize.json'),load(Q/'after-authorize.json');assert set(same_tables(b,a,['grants','delivery_graph_requests','heartbeats']))-{'heartbeats'}=={'grants','delivery_graph_requests'}
added=[x for x in a['grants'] if x not in b['grants']];f=auth_posts[1]['response']['receipt'];assert len(added)==2 and {x['id'] for x in added}=={x['id'] for x in f['grants']}
assert all(g['principal_id']==runtime and g['resource_id']==fixture['B_id'] and g['project_id']==pid and g['revision']==1 and not g['revoked'] and g['expires_at']==f['created_at']+86400 for g in added)
assert all(x in a['grants'] for x in b['grants']);exact_pair(b,a,'csv-app-material-access.v1.authorize',auth_posts[1]['request_body'],auth_posts[1]['response'])
assert new['pre_authorization_baseline_key']!=new['post_authorization_baseline_key']
same_tables(load(Q/'before-preview.json'),load(Q/'after-preview.json'),['delivery_graph_requests','heartbeats'])
stop=load(Q/'first-stop.json');cold=load(Q/'cold-stop.json');end=load(Q/'withdraw-stop.json')
assert stop['grants']==a['grants']
for t in ['principals','resources','goal_cards','goal_card_versions','app_drafts']:assert base[t]==stop[t]
initial=load(Q/'before-edit.json')
for t in ['internal_releases','internal_app_runs','internal_instance_data','internal_run_bindings','run_contracts','runs','operations','operation_intents']:assert all(x in stop[t] for x in initial[t])
ids=[new['old_run_id'],new['check_run_id'],new['new_run_id']];runs={x['id']:x for x in stop['runs']}
assert set(ids)==set(runs) and all(runs[x]['status']=='SUCCEEDED' and runs[x]['worker_id']==report['first_worker'] and runs[x]['fence']==1 for x in ids)
claims=[x for x in stop['events'] if x['kind']=='CLAIMED'];assert len(claims)==3 and {x['run_id'] for x in claims}==set(ids) and not stop['attempts'] and not stop['reservations']
typed_info=[]
for rid,total,version,resource,hash_ in [(ids[0],'30',1,fixture['resource_id'],fixture['A_hash']),(ids[1],'350',1,fixture['B_id'],fixture['B_hash']),(ids[2],'350',2,fixture['B_id'],fixture['B_hash'])]:
 binding=next(x for x in stop['internal_run_bindings'] if x['run_id']==rid);ar=next(x for x in stop['internal_app_runs'] if x['id']==binding['app_run_id']);typed=next(x for x in stop['internal_instance_data'] if x['run_id']==ar['id']);out=typed['data']['result']
 assert ar['status']=='SUCCEEDED' and typed['version']==version and out['sum']==total and out['resource_id']==resource and out['source_hash']==hash_ and typed['instance_id']==ar['instance_id']
 assert (ar['instance_id']==iid)==(rid!=ids[1]);typed_info.append({'core_run':rid,'app_run':ar['id'],'instance':ar['instance_id'],'release':ar['release_id'],'version':version,'sum':total,'resource_id':resource})
for release in stop['internal_releases']:assert release['fingerprint']==fp(release['snapshot'])
rel=next(x for x in stop['internal_releases'] if x['id']==new['new_release_id']);src=rel['snapshot']['csv_goal_revision_source']
assert src['namespace']=='csv-material-revision.v1' and src['goal']==new['preview']['context']['goal'] and src['reference']['preview_key']==new['preview']['request_key'] and src['reference']['instance_id']==iid and src['reference']['purpose']=='USE'
assert new['preview']['context']['parent']['spec_revision']==1 and new['preview']['spec_revision']==2 and src['goal']['version']==1
assert same_tables(stop,cold,['heartbeats'])==['heartbeats']
wa,wb=load(Q/'before-withdraw.json'),load(Q/'after-withdraw.json');same_tables(wa,wb,['grants','delivery_graph_requests','heartbeats'])
revokes=[x for x in withdraw['requests'] if x['method']=='POST' and x['path'].endswith('/csv-material-access/revocations')];assert len(revokes)==1 and revokes[0]['status']==201
exact_pair(wa,wb,'csv-app-material-access.v1.revoke',revokes[0]['request_body'],revokes[0]['response'])
created_ids={x['id'] for x in added};lost=withdraw['upstream_revoked_gid']
for old in stop['grants']:
 now=next(x for x in end['grants'] if x['id']==old['id']);assert now==({**old,'revoked':True,'revision':old['revision']+1} if old['id'] in created_ids|{lost} else old)
assert len(end['grants'])==len(stop['grants']);same_tables(cold,end,['grants','delivery_graph_requests','heartbeats'])
held=[x for x in withdraw['requests'] if x.get('delivery_delayed')];assert len(held)==1 and held[0]['delivery_released'] and held[0]['response']['receipt_status']=='ACTIVE'
assert revokes[0]['response']['receipt_status']=='REVOKED' and revokes[0]['response']['app_material_status']=='INACTIVE'
assert any(x['status']==403 and x['path'].endswith('/csv-material-access') for x in withdraw['requests'])
assert any(x['status']==403 and x['path'].endswith('/'+new['new_run_id']) for x in withdraw['requests'])
assert any(x['path'].endswith('/csv-owner-review') and x.get('response',{}).get('owner_acceptance')=='PENDING' for x in new['requests'])
assert not stop['csv_owner_records'] and not stop['csv_owner_seals']
# Check same-key authorization replay is read-only/revoked in final ASGI trace, not inferred from prior window.
assert any(x['method']=='GET' and x['path'].endswith('/authorizations/user-explicit-B') and x['response'].get('receipt_status')=='REVOKED' for x in traces)
result={'verdict':'LIMITED_PASS_APP_MATERIAL_BUSINESS_AUTHORIZATION','method':'Independent pure stdlib file/zip/AST audit; no product/test/DB/Git/network execution',
 'source9':final9,'runtime_142_before_after_and_current_equal':True,'wheel_140_source_zip_installed_equal':True,'wheel':{'bytes':wheel.stat().st_size,'sha256':sha(wheel.read_bytes())},
 'final_api':{'unique_cases':4,'executions':4,'author_pytest':'4 PASS / 8.88s','outer_seconds':cmd['seconds'],'trace_type':'ASGI/TestClient structured, not wire','trace_requests_including_fixture':len(traces),'details':api_details,'full55JSON_and_seals_recomputed':True},
 'final_installed':{'pages':by_page,'loopback_response_SHA_reconstructed':response_digests,'methods_including_fixture_controls':dict(methods),'response_statuses':dict(codes),'three_owned_processes_clean_exit0':True,'fixture_App_B_Grants':0,'claims':3,'attempts':0,'reservations':0,'model_calls':0,'typed_run_bindings':typed_info,'full55_table_export_comparisons':True,'human':'PENDING; no PREPARE/DECIDE','semantics':'UNKNOWN'},
 'checks':{'exact_App_only_two_Grants_and_two_seals':True,'two_explicit_existing_Grant_controls':'unrelated C ownerREAD triggers stale baseline; A ownerREAD triggers source loss','rollback_rejection_full_scope_and_bodyFP':reject,'fresh_reselection_consent_no_autoPOST':True,'new_baseline_key_not_reused':True,'old_Goal1_and_history_preserved':True,'metadata_withdraw_after_source403':True,'held_ACTIVE_cannot_reinstall_current_view':True,'same_keys_never_renew_regrant':True,'all_219_HTTPsha_and75_JS_asset_hashes_reconstructed':True,'optional_protocol400_per_page':True},
 'limits':['Only one Goal CSV App plus one added B','AUTH64 requests/control64 material IDs includesA; full-capacity boundary NOT_RUN, no64-added-B claim; original project Grant listing/per-gid revoke retained','SQLite installed loopback/JSDOM only; shared existing locked dependencies; not native browser/visual/Win/PG/remoteCI/deployment','No real model/provider requests, credentials/system permissions or external source install; source missing and LIVE blocked','No real human decision or real semantic/scene acceptance','Content403 after combined A-owner loss and B-App withdrawal does not isolate B-only denial causality','No database content opened or database bytes hashed by reviewer; comparisons use exported synthetic55-table JSON','No author archive/commit/push or remote HEAD attestation; remote auth not retried; old full-disk missing review not recovered','Earlier api and qualified-installed runs retained as historical/superseded, not counted current final qualification'],
 'observer_corrections':['ui-observation-timing-correction.json','closed-api-first-observer-error.json','first-package-observer-correction.json','final-audit-observer-correction.json']}
(O/'final-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['verdict','final_api','final_installed']},ensure_ascii=False,indent=2))
