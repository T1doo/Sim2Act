"""Pure immutable code/package-file bridge only; no imports or DB access."""
from pathlib import Path
import hashlib,json,zipfile
AUTHOR=Path('/workspace/app-material-authorization-20261018')
ROOT=AUTHOR/'qualified-installed'
OUT=Path('/workspace/app-material-authorization-review-20261018')
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_text())
frozen=read(AUTHOR/'runtime-source-before.json')
expected={p.removeprefix('src/'):v for p,v in frozen.items() if p.startswith('src/sim2act/')}
manifest=read(ROOT/'wheel-files.json')
assert manifest==expected
wheels=list((ROOT/'wheel').glob('*.whl'));assert len(wheels)==1
wheel=wheels[0]
with zipfile.ZipFile(wheel) as z:
    files={n:sha(z.read(n)) for n in z.namelist() if n.startswith('sim2act/') and not n.endswith('/')}
assert files==expected
pkg=ROOT/'installed-venv/lib/python3.12/site-packages'
installed={n:sha((pkg/n).read_bytes()) for n in expected}
repo=Path('/workspace/Sim2Act')
current={n:sha((repo/'src'/n).read_bytes()) for n in expected}
current_differences=[n for n in expected if current[n]!=expected[n]]
assert installed==expected
fixture=read(ROOT/'fixture.json');tables=read(ROOT/'fixture-before-ui.json')
assert len(tables)==55 and fixture['fixture_App_B_grants']==0
app=next(r for r in tables['app_drafts'] if r['id']==fixture['app_id'])
assert not [r for r in tables['grants'] if r['principal_id']==app['runtime_id'] and r['resource_id']==fixture['B_id']]
assert not tables['runs'] and len(tables['internal_instances'])==len(tables['internal_releases'])==1
instance=tables['internal_instances'][0]
assert instance['revision']==1 and instance['source_app_id']==fixture['app_id'] and instance['id']==fixture['instance_id']
assert app['candidate']['generation']==fixture['goal'] and fixture['goal']['goal_version']==1 and app['candidate']['manifest']['revision']==1
assert app['candidate']['manifest']['data_bindings'][0]['resource_ref']==fixture['resource_id']
result={'status':'PASS_PURE_FIRST_PACKAGE_AND_FIXTURE_BRIDGE','not_overall_feature_verdict':True,'runtime_source_map_count':len(frozen),'package_file_count':len(expected),'wheel':{'name':wheel.name,'bytes':wheel.stat().st_size,'sha256':sha(wheel.read_bytes())},'runtime_hashmap_equals_zip_equals_installed_package':True,'separate_frozen_source_copies_exist':False,'current_source_differences':current_differences,'package_hashes':expected,'fixture':{'snapshot_tables':55,'App_B_Grants':0,'runs_before_page':0,'original_manifest_revision':1,'original_Goal_version':1,'initial_instances':1,'initial_releases':1,'app_runtime':app['runtime_id'],'App':app['id'],'project':fixture['project_id'],'iid':fixture['instance_id'],'resource_A':fixture['resource_id'],'resource_B':fixture['B_id']},'limits':['Only closed fixture JSON and frozen package/source read; no running test result read or signed','No product/HTTP/Worker/pytest/DB/SQL/Git/network or private holdout access','Installed dependency path is shared existing locked environment; no clean-machine dependency claim','This first wheel predates planned explicit rejected-submission proof; later current qualification requires own source bridge']}
(OUT/'first-package-fixture-bridge.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in {'package_hashes','limits'}},ensure_ascii=False,indent=2))
