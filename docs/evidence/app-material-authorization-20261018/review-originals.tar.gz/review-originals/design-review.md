# App追加已有CSV业务授权 — 独立设计审查

可以在用户本次明确授权内实施一个窄的App业务授权服务。尚无实现/运行PASS；不把业务Grant扩展成系统权限。现有源码没有既有CSV App追加接口：`apps.persist_csv_candidate`150–177只在创建新App/runtime时为已选A插入READ+SUM两行24h Grant；`Store.add_grants`883–897会同时授权principal/runtime，不能原样用于只追加App/B；`api.py`493–520只有列表和单gid/version撤回。自然家族per-use授权服务与此家族/能力不同，不能借用它签CSV权限。

产品规范§5.5（185–191）要求当前用户∩版本声明∩App身份∩当前资源授权；§5.6（193–199）要求原键幂等、明确撤回与版本比较；§8.4（392–398）要求精确授权变化和撤回后缓存/旧批准不能复活。此前App/B两项人工fixture前提不等于已有产品授权功能，本任务应真正移除该前提。

## 最小允许合同

1. **仅服务端派生范围。** 在owner/project锁后确认App属于同项目，runtime取自该App独立存储绑定；限制为现材料修订能处理的单注册`data.aggregate_csv@1`原Goal CSV家族。当前可读原App/来源须正常重验，不能通过伪造CSV标签/替换principal绕家族。目标是同项目已导入CSV资源ID/hash；用户和项目运行身份当前必须已有resource.read及data.aggregate_csv。B尚无App权限正是本服务的目的，所以不能在准备阶段误用`apps.authorize_source(...App runtime)`先要求缺失App/B权；应先检查用户/项目交集，授权后才核完整App交集。
2. **清楚披露真正范围。** 固定只授选定App runtime对选定B的READ+SUM，固定有界有效期（沿创建上限24h即可），不新Principal、不改用户/项目Grant、不扩工具/外部source。Grant表没有Release/instance维度，因此它是App运行身份级，可能供该App其他实例使用；各Release声明仍限制实际访问。不能把UI写成只给当前iid/Release授权。当前实例/Release指纹可用于确认防陈旧，不能冒充持久Grant的隔离维度。
3. **先选择后明确确认。** 准备/列表只读，无Grant写。用户核对project/App/runtime/B ID/hash、两工具、有效期和现权限基线后明确确认；Strict DTO不接受任意tools/runtime/principal/路径/URL。可复用现有批准/原键双锚合同，或一个绑定完整冻结请求与明确consent的确认命令；不要复用Release commit类型去改变Grant语义。
4. **同事务精确写入。** 锁序project→App→按稳定ID排序的有关Grant；比较准备时grant-set/权限修订指纹，再插入仅App/B两行和严格双锚回执，写后在同TX核当前owner/B权限、资源hash与两精确新Grant。异常整TX回滚。不要用通用add_grants顺带给用户/项目扩权。不同新键竞争同旧grant-set基线应只一份受理，第二份409；同键同体回原Grant IDs/原expiry，不续期/加行。
5. **原键永远不能修复权限。** 已受理组必须固定两Grant IDs、原revision/expiry、App/project/runtime/resource/tools和请求指纹。GET/重复POST/迟到响应只能读取历史受理及当前有效性；撤回/过期/缺失/污染后不能补回、翻revoked=false或刷新期限。半回执/孤Grant/错ID/body冲突保守UNKNOWN。若未来支持重新授权，必须独立新准备/新当前基线/用户重新确认，不能作为原键恢复；本最小片可先只做首次追加并明确拒绝隐式renew/regrant。

## 撤回与页面安全

建议对新组提供同TX精确两Grant/revision-vector撤回；既有gid撤回仍保持原语义。如UI只连续调用两次原gid接口，必须展示部分撤回/UNKNOWN，不能一次200就说两项都撤回。READ先撤会阻断SUM的递归READ门，但剩余Grant仍须如实显示。

撤回及当前状态需要metadata-only路径：按当前owner/project和独立组/精确App-runtime/Grant行scope/version判断，不需要正在撤回的App/B READ，不读Goal/CSV正文。否则先撤READ或原A权限失效会阻断剩余权限撤回，重复此前已修的“知道对象却无法停止”入口问题。可复用现list_grants/revoke的owner-project元数据权限边界；不恢复缓存私有内容。

迟到受理回执只证明历史受理，不能直接重置UI为当前有效；需当前状态GET及account/connection/project/workspace/App/实例/资源选择代次围栏。旧withdraw/status或其他页面撤回后的晚callback不得重启Grant写。任一403/版本冲突清私有材料/冻结review内容，保原intent/key和metadata状态；重复点击锁定，UNKNOWN只读恢复，不自动POST。

追加Grant会改变`lifecycle.grant_version`全项目指纹和graph authFP，原CHECK/Release批准按现门失效。不要豁免此次变化。现UI baselineAccepted和steps.baseline会留旧derive键；授权后须在无unknown/accepted业务steps的可切换阶段保留旧键到history，进入原新material cycle，用户再明确读取/derive新基线（新baselineKey）。不能只置baselineAccepted=false却重用原已受理derive键，也不能把授权当材料已替换/Release已采用。

## 最小实际验收

从无App/B Grant的普通原spec1/Goal1开始，A/B由原资源API导入（用户/项目权限原有），App初始只有A权限；本轮不再SQL补App/B。页面明确选择B/两工具/期限并确认，实际新增恰两App Grant及封存回执，无新用户/项目权限；双击不重复。同原M控制器新derive/preview→CHECK350→Release→同iid采纳→新B350/v2，原A30及Goal/旧历史保持。模型0。

至少钉住本新增权限边界：旧确认错配到另一App/runtime、跨项目/主体错配和缺用户/项目权均不能借原scope取得B正文/授权；同键重放不续期；真实撤回后原key/迟到回执不恢复Grant，当前读取/执行继续拒绝；metadata撤回仍可达。只做这些直接相关有限节点，不扩旧故障矩阵。原系统OS/私有库/凭据/外部连接/通配资源/管理员或新executor权限仍不在本授权范围，发现必须停该扩展并列条件。

只读源码和规范，无产品、pytest、Worker/model、DB/SQL、Git/auth/network、私有holdout访问或产品写入。当前仅为设计建议，目录未封存，待实际实现独审与合成原件。
