# App追加CSV业务授权：WIP独立静审

当前后端WIP未见剩余确定P1/P2；这是静态可继续实现结论，尚无产品/测试资格。新服务观察字节为 `f7d0abc8dc916c0dad6c21029798b4d710765621b8cafe87e003d1ca1aa7a7a6`。三文件哈希与对照补丁见 `implementation-source-observations.json`、`apps-wip-diff.patch`、`api-wip-diff.patch`。

发现过一个P2：原fresh authorize先核B上游，随后完整App/Goal证明及CSV处理，再写两项24h App Grant；末尾receipt把权限到期吞成`upstream_available=false`，仍可提交。该发现仅来自修前工具显示的源码，没有动态复现或修前全文件哈希；明确标注的摘录在 `p2-original-tool-visible-excerpts.txt`。当前 `authority_guard` 在新授权写前250和写后256行均抛错复查B的用户/项目READ+SUM、A的用户/项目/App READ+SUM与退休状态，失败由原TX回滚；原键、GET与withdraw仍维持metadata状态读取。这一P2已在当前字节静态闭合，动态验收待执行。

授权只给存储App runtime、同项目选定CSV、固定READ/SUM两项、24h；没有`Store.add_grants`用户/项目双授或任意tool/runtime输入。Strict命令绑定候选指纹、全项目Grant基线、App/B完整Grant向量、资源hash和明确scope consent；B上游先于App Goal正文。这里真实范围是该App所有实例，各Release声明仍另行约束使用，不能宣称仅当前实例授权。

原键及读取先owner/project和App标量scope，再校双锚、完整请求承诺和冻结Grant组；当前实现没有恢复、续期或改revoked=false分支。新`/state`只列该App运行身份的Grant控制元数据；失去材料权限后仍可按精确vector撤回，并在一个TX复用原逐gid/revision CAS。metadata回执允许失权时返回当前不可用状态，不读取材料hash/正文/Goal。原API单gid撤回helper与先前保全执行源逐句核对，owner/revision/command语义保持；旧创建Grant的共同expiry是明确有限实现差异。

UI尚待下一阶段独审；需实际核明确确认后恰两App/B行、没有用户/项目Grant增量、原键不续期，以及撤回/迟到响应不补权。追加Grant会让原graph/approval权限指纹失效，页面应走现有新基线流程，不能豁免旧版本门。

本审仅纯文件/AST/源码对照；没有import产品、测试、HTTP、Worker、模型、DB/SQL、Git、网络、私有留出访问或仓库写入。不签冻结源码、实际授权/撤回、SQLite并发或其他平台资格。本目录未封存，等待实现冻结及实际原件。
