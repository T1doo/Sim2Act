# 明确未受理请求：第三项P2修后静审

新`submission_tx`与UI`rejected()`当前未见阻止选定单App/单B正向链资格的P1/P2。四项实际观察字节与`runtime-final-source-before.json`一致，见`rejection-proof-static-review.json`。原有成功安装窗口只属于修复前字节，不能替代本次最终资格。

原问题是完整403/409未受理也进入UNKNOWN，原key不存在双锚却会锁后续准备。现后端先owner/project和窄App标量scope，记录该kind/key两锚均ABSENT，内部捕获原DomainError；只在store.tx已因该原异常退出回滚后附完整scope和原bodyFP证明。已有任一锚、scope失败或不同commit/rollback异常不会得到该证明。没有新增拒绝写入或补权。

前端只有核namespace/App/project/principal/runtime/kind/key/fullbodyFP与三literal，再在异步hash后复核here/current，才置REJECTED并清旧context/items/checkbox。实际网络未知仍锁原key；新的操作必须明确重新读范围、选择和勾选，再生成新key，不能自动POST。RAM保存的拒绝证明是原请求当时已回滚的控制证据，不是永久tombstone，也不证明当前来源有效。

当前API源增加wronghash附proof和已有accepted key变体无proof；新页driver以既有无关TXT owner READ显式CAS变化触发真实基线409，再fresh读/选/勾选，另有55表原件。这些尚待闭合原件核验，未由独审执行。本片单B路径无新增确定阻断；64个追加B加创建A可能超metadata状态64资源上限的容量角落已向作者提示，未动态验或签容量边界。

只读源码/AST/hash，无产品、测试、DB、SQL、Git、网络、模型或私有留出访问。本目录继续未seal。
