# App材料授权UI：两项P2修后静审

当前WIP未发现剩余确定P1/P2，可继续冻结与定向资格。源码哈希及具体范围见`ui-wip-fix-review.json`；修后JS保存在`ui-wip-fix-source-observed.js.txt`。早期修前工具文本观察记录保留于`ui-wip-review.*`；但并行主写入在第一次保存源码前已修复，所以两份保存的JS快照实际均为相同修后字节，不能声称保全修前全文件。见`ui-observation-timing-correction.json`，原笔记保留，不冒充动态复现或产品失败。

纯查询错误原键现在先完整校验临时候选，再替换current/history；失败不产生未知写入锁，真正pending仍禁止被lookup覆盖。新action的材料403复用完整`clearApplicationUseData(v)`，实际提交403/409也标记失效清理；清空私有结果/列/冻结修订，保原意图并重绘metadata控制入口。单纯不存在原键GET409仅提示，不清历史意图。这两项已在当前字节静态闭合，运行原件待核。

其余已有围栏覆盖当前view、account/project/App/instance generation、connection/workspace与DOM，异步hash后再次检查；Map跨同App实例保留未知写锁，回执旧响应不能写入替代view。授权后next要求新GET有效状态，创建新材料cycle和新baselineKey，旧baseline归history，再走原CHECK/Release/CAS，未豁免权限或版本门。App级metadata入口在私有App读取前就可选择；API撤回不需原A/B正文授权。固定helper仍只App READ/SUM24h；新授权前后throwing authority guard及pair None保守拒绝保持。

已静读API四节点及新driver：实际UI资格拟覆盖无App/B预授的明确授权、错误键继续操作、新基线及原材料链，以及fixture通过旧API撤A READ后403清理，再metadata撤B与旧ACTIVE迟到隔离。该既有A Grant撤回须作为fixture控制动作单列，不冒称页面有新增用户/项目授权工具。测试未由本独审执行，也未读取在途原件。

仅源码与文件检查；无产品、HTTP、pytest、Worker/model、DB/SQL、Git/network或私有留出访问。未签冻结源码、实际运行PASS、Windows/PG/native/CI/LIVE。等待闭合原件后有限终验，本目录未封存。
