# App材料授权UI：WIP有限独审

仅静态源码检查，未运行产品/测试/DB/Git/网络。观察字节在`ui-wip-source-observations.json`，本次主JS原字节在`ui-wip-source-observed.js.txt`；尚未冻结或签运行资格。

**P2：纯GET查错原键导致锁死已静态修正。** 初读工具显示389–392行在GET之前执行`if(entry.current)entry.history.push(entry.current); const p={...,body:null,state:"unknown"}; entry.current=p; ... await readReceipt(p)`。完整修前文件未保存，此处为工具可见文本转述，并非原始stderr或动态复现。不存在的键会把纯查询升级为未知写意图，跨实例锁住同App全部后续操作。现代码先用临时p完成GET与完整回执验证，最后在here/pending检查后才替换current/history，真正未知POST仍不能被lookup覆盖。实际误键检查待原件核验。

**P2：私有UI在已知材料403后残留，待修。** 当前新action catch只清本授权面板context/items/live/proof。普通实例此前已显示A结果、列及Goal修订正文，A READ失效后点击读取可追加CSV，后台完整load_draft正确403，但旧`use-output`/列/修订正文未清。建议该类403复用`clearApplicationUseData(v)`，保留原key/intent，利用现重绘留下metadata撤回入口；不要恢复缓存instance或私有正文。纯原键查错409仍应独立处理，不覆盖历史意图。

其余当前静态接线有明确App全部实例/READ+SUM/24h告知及独立checkbox；读取与打开不授权。App级pending Map跨实例保留、真正UNKNOWN仅原key GET，不自动POST。here检查view/account/project/generation、connection/workspace及DOM，并在hash await后重新检查。接受授权后不会自动改版本；next需再次读当前回执和有效性，明确启动新材料cycle，保留旧baseline到history，使用新baselineKey再走原CHECK/Release/CAS。目录metadata管理入口在完整App读取之前，A或结果失权仍可通过owner/project元数据撤回，不重装cached私有实例。

未复核在途/作者API原件，作者口述4PASS不计独立执行。UI及实际页面资格仍待冻结源和闭合原件。本目录保持未seal。
