"""Owned synthetic installed-wheel processes; raw finite acceptance, no model/network provider."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import queue
import signal
import sqlite3
import subprocess
import threading
import time
import zipfile

ROOT = Path('/workspace/blank-synthetic-workspace-20261018/attempt2')
VENV = ROOT.parent / 'installed-venv'
CWD = ROOT / 'outside-checkout'
DATA = ROOT / '持久 空白工程'
DRIVER = ROOT / 'execution-driver/blank_workspace_ui.cjs'
WHEEL = ROOT.parent / 'wheels-schema-fixed/sim2act-0.1.0-py3-none-any.whl'
PYTHON = VENV / 'bin/python'
BIN = VENV / 'bin/sim2act'
DEPS = Path('/workspace/sim2act-venv/lib/python3.12/site-packages')
ENV = {k: v for k, v in os.environ.items() if k not in {
    'INTERN_API_TOKEN', 'SIM2ACT_INTERN_TOKEN', 'SIM2ACT_TEST_DATABASE_URL',
    'PYTHONPATH', 'PYTHONHOME', 'PIP_INDEX_URL', 'PIP_EXTRA_INDEX_URL'}}
ENV.update(PIP_CONFIG_FILE='/dev/null', NODE_PATH='/workspace/node-tools/node_modules',
           SIM2ACT_DATABASE_URL='synthetic-invalid-dsn-must-not-be-used',
           SIM2ACT_LIVE_ENABLED='synthetic-invalid-live-must-not-be-used',
           SIM2ACT_GOAL_PLANNER_PROVIDER='synthetic-invalid-provider-must-not-be-used')
REPORT = {'status': 'RUNNING', 'started': datetime.datetime.now(datetime.UTC).isoformat(),
          'dependency_install': 'Fresh venv wheel with explicit existing locked dependency directory; no dependency redownload',
          'model_provider_network': 'No transport/provider configured; NeverModel raises before generation',
          'commands': [], 'checks': [], 'processes': []}

def save():
    (ROOT / 'installed-acceptance-result.json').write_text(json.dumps(REPORT, ensure_ascii=False, indent=2) + '\n')

def check(value, label):
    assert value, label
    REPORT['checks'].append(label)
    save()

def command(name, args, timeout=120):
    record = dict(name=name, command=[str(a) for a in args], cwd=str(CWD),
                  started=datetime.datetime.now(datetime.UTC).isoformat())
    REPORT['commands'].append(record)
    save()
    start = time.monotonic()
    with (ROOT / (name + '.stdout')).open('wb') as out, (ROOT / (name + '.stderr')).open('wb') as err:
        result = subprocess.run(args, cwd=CWD, env=ENV, stdout=out, stderr=err, timeout=timeout)
    record.update(exit_code=result.returncode, seconds=time.monotonic() - start,
                  finished=datetime.datetime.now(datetime.UTC).isoformat())
    save()
    assert result.returncode == 0, name + ' failed; raw stdout/stderr retained'
    print(name + ': PASS', flush=True)

def snapshot(name):
    # Read-only privileged inspection of this runner's own synthetic fixture.
    con = sqlite3.connect((DATA / 'synthetic-workspace.db').as_uri() + '?mode=ro', uri=True)
    try:
        con.row_factory = sqlite3.Row
        names = [row[0] for row in con.execute("SELECT name FROM sqlite_schema WHERE type='table' ORDER BY name")]
        result = {}
        for table in names:
            assert table.replace('_', '').isalnum()
            types = {row[1]: row[2] for row in con.execute('PRAGMA table_info("' + table + '")')}
            rows = []
            for row in con.execute('SELECT * FROM "' + table + '"'):
                value = dict(row)
                for key in value:
                    if types[key] == 'JSON' and value[key] is not None:
                        value[key] = json.loads(value[key])
                rows.append(value)
            result[table] = sorted(rows, key=lambda row: json.dumps(row, sort_keys=True))
    finally:
        con.close()
    (ROOT / (name + '.json')).write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    return result

class OwnedProcess:
    def __init__(self, name, new):
        self.name = name
        self.events = queue.Queue()
        self.lines = []
        args = [str(BIN), 'synthetic-workspace', '--data-dir', str(DATA), '--port', '0'] + (['--new'] if new else [])
        self.out = (ROOT / (name + '.stdout')).open('w')
        self.err = (ROOT / (name + '.stderr')).open('w')
        self.record = dict(name=name, command=args, cwd=str(CWD), started=datetime.datetime.now(datetime.UTC).isoformat())
        REPORT['processes'].append(self.record)
        self.process = subprocess.Popen(args, cwd=CWD, env=ENV, stdout=subprocess.PIPE, stderr=self.err, text=True, bufsize=1)
        self.record['pid'] = self.process.pid
        save()
        def read():
            for line in self.process.stdout:
                self.out.write(line)
                self.out.flush()
                self.lines.append(line)
                try:
                    self.events.put(json.loads(line))
                except json.JSONDecodeError:
                    pass
        self.thread = threading.Thread(target=read, daemon=True)
        self.thread.start()
        self.ready = None

    def start(self):
        deadline = time.monotonic() + 20
        while time.monotonic() < deadline:
            try:
                value = self.events.get(timeout=.1)
                if value.get('event') == 'SYNTHETIC_WORKSPACE_READY':
                    self.ready = value
                    self.record['ready'] = value
                    save()
                    print(self.name + ': READY ' + value['url'], flush=True)
                    return value
            except queue.Empty:
                if self.process.poll() is not None:
                    break
        raise AssertionError(self.name + ' no READY; raw process logs retained')

    def stop(self):
        if self.process.poll() is None:
            self.process.send_signal(signal.SIGINT)
            try:
                self.process.wait(timeout=15)
            except subprocess.TimeoutExpired:
                self.record['owned_process_sigterm_required'] = True
                self.process.terminate()
                self.process.wait(timeout=10)
        self.thread.join(timeout=3)
        self.out.close()
        self.err.close()
        self.record['exit_code'] = self.process.returncode
        self.record['finished'] = datetime.datetime.now(datetime.UTC).isoformat()
        stopped = [json.loads(line) for line in self.lines if 'SYNTHETIC_WORKSPACE_STOPPED' in line]
        self.record['stopped'] = stopped
        save()
        check(self.process.returncode == 0 and len(stopped) == 1 and stopped[0]['clean']
              and stopped[0]['worker_stopped'] and stopped[0]['data_preserved'], self.name + ' Ctrl+C stops owned worker cleanly and preserves data')

owned = None
try:
    save()
    CWD.mkdir()
    check((VENV / 'bin/sim2act').is_file(), 'reuse exact wheel installation from preserved first attempt; no reinstall')
    site = VENV / 'lib/python3.12/site-packages'
    assert (site / 'explicit-existing-locked-dependencies.pth').read_text() == str(DEPS) + '\n'
    probe = '''import importlib.metadata as m,json,sys,sim2act,sim2act.cli,sim2act.synthetic_workspace
print(json.dumps(dict(executable=sys.executable,package=sim2act.__file__,cli=sim2act.cli.__file__,workspace=sim2act.synthetic_workspace.__file__,sys_path=sys.path,versions={n:m.version(n) for n in ['sim2act','fastapi','uvicorn','sqlalchemy','psycopg','httpx','pydantic','psutil']}),indent=2))'''
    command('installed-path-probe', [str(PYTHON), '-c', probe])
    paths = json.loads((ROOT / 'installed-path-probe.stdout').read_text())
    check(all(Path(paths[k]).is_relative_to(site) for k in ['package', 'cli', 'workspace'])
          and '/workspace/Sim2Act/src' not in paths['sys_path'], 'package and CLI imported from new wheel outside checkout')
    with zipfile.ZipFile(WHEEL) as archive:
        manifest = []
        for name in archive.namelist():
            if name.startswith('sim2act/') and not name.endswith('/'):
                expected = hashlib.sha256(archive.read(name)).hexdigest()
                actual = hashlib.sha256((site / name).read_bytes()).hexdigest()
                assert actual == expected, name
                manifest.append(dict(path=name, sha256=actual))
    (ROOT / 'installed-wheel-files.json').write_text(json.dumps(manifest, indent=2) + '\n')
    REPORT['wheel'] = dict(path=str(WHEEL), bytes=WHEEL.stat().st_size,
                          sha256=hashlib.sha256(WHEEL.read_bytes()).hexdigest(), package_files=len(manifest))
    check(not DATA.exists(), 'actual data directory absent before console new command')
    owned = OwnedProcess('new-process', True)
    first = owned.start()
    blank = snapshot('blank-before-page')
    check(len(blank['principals']) == 1 and len(blank['quotas']) == 1
          and all(not rows for table, rows in blank.items() if table not in {'principals', 'quotas', 'heartbeats'}),
          'brand new running workspace has zero business rows')
    check({row['id'] for row in blank['heartbeats']} == {first['worker_id']}, 'blank heartbeat belongs only to exact first Worker')
    command('new-page', ['node', str(DRIVER), first['url'], str(ROOT / 'new-page-proof.json'), 'new'], timeout=240)
    page = json.loads((ROOT / 'new-page-proof.json').read_text())
    check(page['status'] == 'PASS', 'new installed page completes explicit user creation and run')
    owned.stop(); owned = None
    after = snapshot('after-first-stop')
    jobs = {row['id']: row for row in after['runs']}
    app_run = next(row for row in after['internal_app_runs'] if row['id'] == page['run_id'])
    REPORT['application_run'] = app_run
    binding = next(row for row in after['internal_run_bindings'] if row['app_run_id'] == page['run_id'])
    job = jobs[binding['run_id']]
    check(len(jobs) == 2 and job['status'] == 'SUCCEEDED' and job['worker_id'] == first['worker_id'] and job['fence'] == 1,
          'only refused task and one application job exist; original Worker claims exact successful job once')
    claimed = [row for row in after['events'] if row['run_id'] == job['id'] and row['kind'] == 'CLAIMED']
    check(len(claimed) == 1 and claimed[0]['data']['fence'] == 1, 'one real CLAIMED fence1 event for application job')
    data = next(row for row in after['internal_instance_data'] if row['run_id'] == page['run_id'])
    check(data['version'] == 1 and data['data']['result']['sum'] == '30', 'typed persistent result version1 sum30 retained after stop')
    owned = OwnedProcess('cold-process', False)
    second = owned.start()
    check(second['worker_id'] != first['worker_id'] and second['principal_id'] == first['principal_id'], 'new process has distinct Worker and same persisted identity')
    command('cold-page', ['node', str(DRIVER), second['url'], str(ROOT / 'cold-page-proof.json'), 'cold', str(ROOT / 'new-page-proof.json')], timeout=180)
    owned.stop(); owned = None
    cold = snapshot('after-cold-stop')
    changed = [table for table in after if after[table] != cold[table]]
    check(changed == ['heartbeats'], 'cold reopen changes only heartbeats; other54 tables identical')
    check({row['id'] for row in cold['heartbeats']} == {first['worker_id'], second['worker_id']}, 'both exact Worker heartbeat identities accounted')
    REPORT.update(status='PASS', finished=datetime.datetime.now(datetime.UTC).isoformat(),
                  table_count=len(cold), cold_changed_tables=changed)
    save()
    print('INSTALLED ACCEPTANCE PASS', flush=True)
except BaseException as error:
    REPORT.update(status='FAIL', error=dict(type=type(error).__name__, message=str(error)),
                  finished=datetime.datetime.now(datetime.UTC).isoformat())
    save()
    print('INSTALLED ACCEPTANCE FAIL: ' + str(error), flush=True)
    raise
finally:
    if owned is not None:
        owned.stop()
