"""Owned synthetic installed-wheel processes; raw finite acceptance, no model/network provider."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import queue
import signal
import sqlite3
import subprocess
import threading
import time
import zipfile

ROOT = Path('/workspace/blank-synthetic-workspace-20261018/cold-continuation')
VENV = ROOT.parent / 'installed-venv'
CWD = ROOT / 'outside-checkout'
DATA = ROOT.parent / 'attempt2/持久 空白工程'
DRIVER = ROOT / 'execution-driver/blank_workspace_ui.cjs'
WHEEL = ROOT.parent / 'wheels-schema-fixed/sim2act-0.1.0-py3-none-any.whl'
PYTHON = VENV / 'bin/python'
BIN = VENV / 'bin/sim2act'
DEPS = Path('/workspace/sim2act-venv/lib/python3.12/site-packages')
ENV = {k: v for k, v in os.environ.items() if k not in {
    'INTERN_API_TOKEN', 'SIM2ACT_INTERN_TOKEN', 'SIM2ACT_TEST_DATABASE_URL',
    'PYTHONPATH', 'PYTHONHOME', 'PIP_INDEX_URL', 'PIP_EXTRA_INDEX_URL'}}
ENV.update(PIP_CONFIG_FILE='/dev/null', NODE_PATH='/workspace/node-tools/node_modules',
           SIM2ACT_DATABASE_URL='synthetic-invalid-dsn-must-not-be-used',
           SIM2ACT_LIVE_ENABLED='synthetic-invalid-live-must-not-be-used',
           SIM2ACT_GOAL_PLANNER_PROVIDER='synthetic-invalid-provider-must-not-be-used')
REPORT = {'status': 'RUNNING', 'started': datetime.datetime.now(datetime.UTC).isoformat(),
          'dependency_install': 'Fresh venv wheel with explicit existing locked dependency directory; no dependency redownload',
          'model_provider_network': 'No transport/provider configured; NeverModel raises before generation',
          'commands': [], 'checks': [], 'processes': []}

def save():
    (ROOT / 'installed-acceptance-result.json').write_text(json.dumps(REPORT, ensure_ascii=False, indent=2) + '\n')

def check(value, label):
    assert value, label
    REPORT['checks'].append(label)
    save()

def command(name, args, timeout=120):
    record = dict(name=name, command=[str(a) for a in args], cwd=str(CWD),
                  started=datetime.datetime.now(datetime.UTC).isoformat())
    REPORT['commands'].append(record)
    save()
    start = time.monotonic()
    with (ROOT / (name + '.stdout')).open('wb') as out, (ROOT / (name + '.stderr')).open('wb') as err:
        result = subprocess.run(args, cwd=CWD, env=ENV, stdout=out, stderr=err, timeout=timeout)
    record.update(exit_code=result.returncode, seconds=time.monotonic() - start,
                  finished=datetime.datetime.now(datetime.UTC).isoformat())
    save()
    assert result.returncode == 0, name + ' failed; raw stdout/stderr retained'
    print(name + ': PASS', flush=True)

def snapshot(name):
    # Read-only privileged inspection of this runner's own synthetic fixture.
    con = sqlite3.connect((DATA / 'synthetic-workspace.db').as_uri() + '?mode=ro', uri=True)
    try:
        con.row_factory = sqlite3.Row
        names = [row[0] for row in con.execute("SELECT name FROM sqlite_schema WHERE type='table' ORDER BY name")]
        result = {}
        for table in names:
            assert table.replace('_', '').isalnum()
            types = {row[1]: row[2] for row in con.execute('PRAGMA table_info("' + table + '")')}
            rows = []
            for row in con.execute('SELECT * FROM "' + table + '"'):
                value = dict(row)
                for key in value:
                    if types[key] == 'JSON' and value[key] is not None:
                        value[key] = json.loads(value[key])
                rows.append(value)
            result[table] = sorted(rows, key=lambda row: json.dumps(row, sort_keys=True))
    finally:
        con.close()
    (ROOT / (name + '.json')).write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    return result

class OwnedProcess:
    def __init__(self, name, new):
        self.name = name
        self.events = queue.Queue()
        self.lines = []
        args = [str(BIN), 'synthetic-workspace', '--data-dir', str(DATA), '--port', '0'] + (['--new'] if new else [])
        self.out = (ROOT / (name + '.stdout')).open('w')
        self.err = (ROOT / (name + '.stderr')).open('w')
        self.record = dict(name=name, command=args, cwd=str(CWD), started=datetime.datetime.now(datetime.UTC).isoformat())
        REPORT['processes'].append(self.record)
        self.process = subprocess.Popen(args, cwd=CWD, env=ENV, stdout=subprocess.PIPE, stderr=self.err, text=True, bufsize=1)
        self.record['pid'] = self.process.pid
        save()
        def read():
            for line in self.process.stdout:
                self.out.write(line)
                self.out.flush()
                self.lines.append(line)
                try:
                    self.events.put(json.loads(line))
                except json.JSONDecodeError:
                    pass
        self.thread = threading.Thread(target=read, daemon=True)
        self.thread.start()
        self.ready = None

    def start(self):
        deadline = time.monotonic() + 20
        while time.monotonic() < deadline:
            try:
                value = self.events.get(timeout=.1)
                if value.get('event') == 'SYNTHETIC_WORKSPACE_READY':
                    self.ready = value
                    self.record['ready'] = value
                    save()
                    print(self.name + ': READY ' + value['url'], flush=True)
                    return value
            except queue.Empty:
                if self.process.poll() is not None:
                    break
        raise AssertionError(self.name + ' no READY; raw process logs retained')

    def stop(self):
        if self.process.poll() is None:
            self.process.send_signal(signal.SIGINT)
            try:
                self.process.wait(timeout=15)
            except subprocess.TimeoutExpired:
                self.record['owned_process_sigterm_required'] = True
                self.process.terminate()
                self.process.wait(timeout=10)
        self.thread.join(timeout=3)
        self.out.close()
        self.err.close()
        self.record['exit_code'] = self.process.returncode
        self.record['finished'] = datetime.datetime.now(datetime.UTC).isoformat()
        stopped = [json.loads(line) for line in self.lines if 'SYNTHETIC_WORKSPACE_STOPPED' in line]
        self.record['stopped'] = stopped
        save()
        check(self.process.returncode == 0 and len(stopped) == 1 and stopped[0]['clean']
              and stopped[0]['worker_stopped'] and stopped[0]['data_preserved'], self.name + ' Ctrl+C stops owned worker cleanly and preserves data')

owned = None
try:
    save()
    CWD.mkdir()
    original = ROOT.parent / 'attempt2'
    page = json.loads((original / 'new-page-proof.json').read_text())
    prior = json.loads((original / 'installed-acceptance-result.json').read_text())
    after = json.loads((original / 'after-first-stop.json').read_text())
    first = prior['processes'][0]['ready']
    check(page['status'] == 'PASS' and prior['status'] == 'FAIL'
          and prior['error']['type'] == 'StopIteration', 'preserved new-page PASS and wrong-ID outer failure retained separately')
    aid = page['result']['app_run_id']
    binding = next(row for row in after['internal_run_bindings'] if row['run_id'] == page['run_id'])
    app_run = next(row for row in after['internal_app_runs'] if row['id'] == aid)
    job = next(row for row in after['runs'] if row['id'] == page['run_id'])
    check(binding['app_run_id'] == aid and binding['snapshot']['app_run_id'] == aid
          and app_run['instance_id'] == page['instance_id'] and app_run['release_id'] == page['release_id'],
          'exact public Run -> immutable binding -> internal AppRun linkage verified')
    check(len(after['runs']) == 2 and job['status'] == 'SUCCEEDED' and job['worker_id'] == first['worker_id']
          and job['fence'] == 1 and app_run['status'] == 'SUCCEEDED' and app_run['output']['sum'] == '30',
          'only refused task plus original successful job; precise Worker fence1')
    claimed = [row for row in after['events'] if row['run_id'] == job['id'] and row['kind'] == 'CLAIMED']
    check(len(claimed) == 1 and claimed[0]['data']['fence'] == 1, 'one actual successful job CLAIMED fence1 event')
    data = next(row for row in after['internal_instance_data'] if row['run_id'] == aid)
    check(data['version'] == 1 and data['data']['result']['sum'] == str(10 + 20)
          and data['data']['result']['count'] == 2, 'typed result independently recomputed30 version1 with correct internal ID')
    release = next(row for row in after['internal_releases'] if row['id'] == page['release_id'])
    goal = next(row for row in after['goal_card_versions'] if row['card_id'] == page['goal']['id'])
    generation = release['snapshot']['draft']['candidate']['generation']
    check(generation['goal_snapshot'] == goal['snapshot'] and generation['goal_fingerprint'] == goal['fingerprint']
          and generation['goal_version'] == goal['version'] == 1, 'complete Goal v1 snapshot and fingerprint pinned in internal Release')
    check(len(after['attempts']) == 1 and after['attempts'][0]['mode'] == 'MOCK'
          and after['attempts'][0]['error'] == 'UNSUPPORTED_CAPABILITY', 'only refused mock attempt exists; deterministic application has zero model attempts')
    before = snapshot('before-cold')
    check(before == after, 'stopped same fixture all55 tables equal first-stop raw snapshot before continuation')
    owned = OwnedProcess('cold-process', False)
    second = owned.start()
    check(second['worker_id'] != first['worker_id'] and second['principal_id'] == first['principal_id'],
          'cold process owns distinct Worker and same persistent identity')
    command('cold-page', ['node', str(DRIVER), second['url'], str(ROOT / 'cold-page-proof.json'), 'cold', str(original / 'new-page-proof.json')], timeout=180)
    coldpage = json.loads((ROOT / 'cold-page-proof.json').read_text())
    check(coldpage['status'] == 'PASS' and coldpage['run_id'] == page['run_id'], 'cold full page reads same successful Run')
    owned.stop(); owned = None
    cold = snapshot('after-cold-stop')
    changed = [table for table in after if after[table] != cold[table]]
    check(changed == ['heartbeats'], 'cold reopen changes only heartbeats; other54 tables identical')
    check({row['id'] for row in cold['heartbeats']} == {first['worker_id'], second['worker_id']}, 'both exact Worker heartbeat identities accounted')
    check(next(row for row in cold['heartbeats'] if row['id'] == first['worker_id'])
          == next(row for row in after['heartbeats'] if row['id'] == first['worker_id']), 'stopped first Worker heartbeat unchanged')
    REPORT.update(status='PASS', finished=datetime.datetime.now(datetime.UTC).isoformat(), table_count=len(cold),
                  cold_changed_tables=changed, core_run_id=page['run_id'], app_run_id=aid,
                  first_worker_id=first['worker_id'], cold_worker_id=second['worker_id'],
                  corrected_fresh_full_runner='NOT_RERUN', scope='pure corrected snapshot linkage plus same-data cold process/page only')
    save()
    print('SAME-FIXTURE COLD CONTINUATION PASS', flush=True)
except BaseException as error:
    REPORT.update(status='FAIL', error=dict(type=type(error).__name__, message=str(error)),
                  finished=datetime.datetime.now(datetime.UTC).isoformat())
    save()
    print('COLD CONTINUATION FAIL: ' + str(error), flush=True)
    raise
finally:
    if owned is not None:
        owned.stop()
