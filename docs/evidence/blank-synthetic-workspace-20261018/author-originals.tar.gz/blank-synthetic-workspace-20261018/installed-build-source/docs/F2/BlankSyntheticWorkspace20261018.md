# 可冷重开的空白合成工程入口

基线 `c861d92dbb91dfd8d3b9b7ed56015340758a9565`。先对照原产品 §9 与 F2-T07 核查：有限 CSV 列/材料/Goal 修订、有限 DAG 接线、自然配方前序依赖切换、人工锁和保守扩验均有实现；Report 的 decision→explanation 只是归档展示，不是可执行版本的修改。手工正文改版、更宽规则/节点、跨文件组合及 Schema 迁移尚无已冻结的通用依赖/保留合同，不能通过换一个字段、工具或忽略未知 PROJECT 依赖来补称完成。本片不继续这些小变体。

转推进原产品 §6.2、§6.5 和 F1-T01/安装运行、F3/AT-27 的交付入口代码。现 wheel 包含页面但没有 console entry；CLI 只有 migrate/init-user/schemas/probe。现有 first-use 是退出清理的测试，natural_activation_demo 预置固定项目，local_candidate_demo 预先生成成果且 serve 只读。它们不是从安装包开始、自己创建项目并可冷重开的空工程。

## 实现前合同

- 安装包提供显式 `sim2act synthetic-workspace --new --data-dir <新目录>`；后续不加 `--new` 打开同目录。新建只做原 test-only SQLite schema、基础 quota 和公开合成身份，项目/资源/应用/Run/结果全空。不依赖 checkout、测试目录、旧包、现成数据库或作者结果。
- 复用普通 `create_app`、原 `Worker`/租约/账本与原页面；只允许127.0.0.1和有效端口，默认动态端口。Worker 使用原一秒服务节拍及拒绝模型的对象，不创建替代执行器。Settings显式mock/token空/LIVE false/生成provider disabled；不读取.env、环境凭据或DSN，不提供生产连接选项。
- 数据目录及父级不能是链接；new拒绝已有目录，失败保留已创建内容。冷开只接受精确marker、已有普通数据库文件、匹配schema和原合成身份，不自动迁移/初始化/重置已有库。不删除文件、不杀未知进程、不改ordinary PostgreSQL启动或SQLite拒绝。
- 网页明确显示合成工程范围及公开测试登录，不用于敏感材料。用户通过原页面自己建项目、保存CSV/完整Goal、选择固定能力、确认内部版本/实例并提交任务；没有预置项目/候选/成果，不激活真实自然模型。
- Ctrl+C只停止本命令持有的API/Worker并保留目录；冷开沿用同项目/身份/历史。停止不会伪装取消Run，未完成任务仍服从原租约/恢复规则。不能把本地合成入口当生产启动、独立发布、Windows或真实用户数据迁移资格。

最小实测：从当前源构建wheel并安装到独立venv（明确复用现有锁定依赖路径，不声称重新下载依赖）；在checkout外启动真实进程/loopback API，从空页经完整页面建立CSV工程、完整Goal和固定CSV应用，确认内部版本与实例，原Worker实际得到30。停止进程后检查数据保留，另启进程从安装包冷读同一Run/成果；心跳按精确Worker对象分别计量。加有限目录/marker/凭据环境隔离及普通Store拒绝SQLite检查；不重跑故障矩阵。完整命令、执行字节、HTTP、claim与原始失败分期留存。
