# Closed first/second attempt — limited file review

The first driver fails at boot with `$ is not defined` while separately `eval`-ing installed scripts. Its proof records only three GETs (root and two assets), one security-header check, no API or business request. The initial source scope and driver failure remain historical evidence; this is not a failed CSV computation.

The second driver loads actual scripts through script nodes. Its closed page proof is PASS with 13 checks and 102 requests (92GET/10POST), followed by a clean owned-process stop. Its outer runner remains FAIL/StopIteration and did not execute cold open. Do not promote that runner to PASS.

The runner error is an ID observer mismatch. The original `app_jobs.inspect_job` DTO returns core Run in `id`, and AppRun separately in `app_run_id`. The closed snapshot has one exact binding joining `run_4d9148440a58446fbb430c02905eccee` to `iapprun_3313632374a14e499933f80d7ed1fe65`, the same instance/Release and typed result30/version1. `internal_app_runs.id` and `internal_instance_data.run_id` use the AppRun ID; querying them with the core ID produces the observed StopIteration. No product code change or repeat model/Worker computation is needed to correct that observer and then cold-read this same result.

The successful CSV job has one real CLAIMED fence1 event. The complete fixture has two CLAIMED events: that job and the intentionally refused ordinary model task. The refused task also retains one FAILED Attempt with `UNSUPPORTED_CAPABILITY` and unknown/null token usage. These rows are not actual provider/model usage, and should not be described as no reservation or one total claim.

`closed-first-and-attempt2-review.json` records the independently checked JSON association and exact read-file hashes. No physical DB was opened/read/hashed. Cold qualification remains pending; the reviewer has not rerun product, page, model or tests.
