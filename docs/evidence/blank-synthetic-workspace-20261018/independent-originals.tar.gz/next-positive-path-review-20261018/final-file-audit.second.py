"""Pure stdlib file audit. Never imports product or opens physical databases."""
from pathlib import Path
import ast,collections,csv,decimal,hashlib,io,json,zipfile
R=Path('/workspace/blank-synthetic-workspace-20261018')
REPO=Path('/workspace/Sim2Act')
OUT=Path('/workspace/next-positive-path-review-20261018')
def J(p): return json.loads(p.read_text())
def H(b): return hashlib.sha256(b).hexdigest()
def FP(v): return H(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode())
def one(rows, **keys):
    found=[x for x in rows if all(x.get(k)==v for k,v in keys.items())]
    assert len(found)==1,keys
    return found[0]
seal=J(R/'sealed-manifest.json')
assert H((R/'sealed-manifest.json').read_bytes())=='64d27c735ec69e89e9b9aca730bbf949582f9675fe924b5104d726acf96d4cc5'
assert H(json.dumps(seal['files'],sort_keys=True,separators=(',',':')).encode())==seal['files_projection_sha256']
verified=[]; databases=[]
for x in seal['files']:
    p=R/x['path']; assert not p.is_symlink() and p.stat().st_size==x['bytes'],x['path']
    if any(s in p.name.lower() for s in ('.db','.sqlite')):
        databases.append(x['path']);continue
    assert H(p.read_bytes())==x['sha256'],x['path'];verified.append(x['path'])
for x in seal['symlinks']: assert str((R/x['path']).readlink())==x['target'],x['path']
assert len(seal['files'])==seal['file_count']==1382 and sum(x['bytes'] for x in seal['files'])==seal['bytes']==33866540
final=J(R/'final-source-hashes.json')
for p,h in final.items(): assert H((R/'final-source'/p).read_bytes())==h==H((REPO/p).read_bytes()),p
build=J(R/'installed-build-before.json'); assert build==J(R/'wheel-fixed-command.json')['source_after'] and len(build)==146
wheel=R/'wheels-schema-fixed/sim2act-0.1.0-py3-none-any.whl'
assert wheel.stat().st_size==940289 and H(wheel.read_bytes())=='3f0224488c4f7f710fb2136afe1a36ad5e55a3d3462631e15f9053e43f26b6d0'
with zipfile.ZipFile(wheel) as z:
    names={n for n in z.namelist() if n.startswith('sim2act/') and not n.endswith('/')}
    expected={p.removeprefix('src/') for p in build if p.startswith('src/sim2act/')}
    assert names==expected and len(names)==139
    for n in names:
        assert H(z.read(n))==build['src/'+n]==H((R/'installed-venv/lib/python3.12/site-packages'/n).read_bytes()),n
    entries=z.read('sim2act-0.1.0.dist-info/entry_points.txt').decode()
    assert 'sim2act = sim2act.cli:main' in entries
    assets={n.removeprefix('sim2act/web/'):H(z.read(n)) for n in names if n.startswith('sim2act/web/')}
for group in ('','attempt2','cold-continuation'):
    a=J(R/group/'execution-before.json');b=J(R/group/'execution-after.json')
    assert a==b
    for p,h in a.items():assert H(Path(p).read_bytes())==h,p
first=J(R/'new-page-proof.json'); first_result=J(R/'installed-acceptance-result.json')
new=J(R/'attempt2/new-page-proof.json'); outer=J(R/'attempt2/installed-acceptance-result.json')
cold=J(R/'cold-continuation/cold-page-proof.json'); cr=J(R/'cold-continuation/installed-acceptance-result.json')
assert first['status']=='FAIL' and first['error']['message']=='$ is not defined' and all(x['method']=='GET' and not x['path'].startswith('/api/') for x in first['requests'])
assert first_result['status']=='FAIL' and outer['status']=='FAIL' and outer['error']['type']=='StopIteration'
assert new['status']==cold['status']==cr['status']=='PASS' and len(new['checks'])==13 and len(cold['checks'])==9
assert len(new['requests'])==102 and collections.Counter(x['method'] for x in new['requests'])=={'GET':92,'POST':10}
assert len(cold['requests'])==46 and all(x['method']=='GET' for x in cold['requests'])
non200=[x for x in cold['requests'] if x['status']!=200]
assert len(non200)==1 and non200[0]['path'].endswith('/protocol/contracts') and non200[0]['status']==400 and non200[0]['response']['error']['code']=='RESOURCE_UNAVAILABLE'
for p in (new,cold):
    assert len(p['assets'])==27
    for a in p['assets']:assert assets[a['src'].lstrip('/')]==a['sha256']
    headers=p['root_headers'];assert headers['x-content-type-options']=='nosniff' and headers['cache-control']=='no-store' and "script-src 'self'" in headers['content-security-policy']
    assert p['browser']==p['visual']=='NOT_RUN'
s=J(R/'attempt2/after-first-stop.json'); before=J(R/'cold-continuation/before-cold.json'); after=J(R/'cold-continuation/after-cold-stop.json')
blank=J(R/'attempt2/blank-before-page.json');assert len(s)==len(before)==len(after)==55 and s==before
assert all(not rows for k,rows in blank.items() if k not in ('principals','quotas','heartbeats')) and len(blank['principals'])==len(blank['quotas'])==1
changed=[k for k in s if s[k]!=after[k]];assert changed==['heartbeats']
fw=outer['processes'][0]['ready']['worker_id'];cw=cr['processes'][0]['ready']['worker_id'];assert fw!=cw
assert outer['processes'][0]['ready']['principal_id']==cr['processes'][0]['ready']['principal_id']
assert {x['id'] for x in blank['heartbeats']}=={fw} and {x['id'] for x in after['heartbeats']}=={fw,cw}
assert one(s['heartbeats'],id=fw)==one(after['heartbeats'],id=fw)
for process in [outer['processes'][0],cr['processes'][0]]:
    assert process['exit_code']==0 and len(process['stopped'])==1 and all(process['stopped'][0][k] is True for k in ('clean','worker_stopped','data_preserved'))
    assert '--port' in process['command'] and process['cwd'].startswith(str(R))
    assert process['ready']['url'].startswith('http://127.0.0.1:')
rid=new['run_id'];aid=new['result']['app_run_id'];binding=one(s['internal_run_bindings'],run_id=rid,app_run_id=aid)
job=one(s['runs'],id=rid);app=one(s['internal_app_runs'],id=aid);data=one(s['internal_instance_data'],run_id=aid)
assert len(s['runs'])==2 and job['status']==app['status']=='SUCCEEDED' and job['worker_id']==fw and job['fence']==1
assert app['instance_id']==new['instance_id']==binding['snapshot']['instance_id'] and app['release_id']==new['release_id']==binding['snapshot']['release_id']
assert binding['fingerprint']==FP(binding['snapshot']) and data['fingerprint']==FP(data['data'])
assert data['version']==app['result_version']==1 and data['data']['result']==app['output']==new['result']['result']
res=one(s['resources'],id=new['resource_id']);assert res['hash']==H(res['content'].encode())
values=[decimal.Decimal(x['amount']) for x in csv.DictReader(io.StringIO(res['content']))]
assert sum(values)==decimal.Decimal(30) and len(values)==2 and app['output']['sum']=='30' and app['output']['count']==2
release=one(s['internal_releases'],id=new['release_id']);goal=one(s['goal_card_versions'],card_id=new['goal']['id'],version=1)
g=release['snapshot']['draft']['candidate']['generation'];assert g['goal_snapshot']==goal['snapshot'] and g['goal_fingerprint']==goal['fingerprint']==FP(goal['snapshot']) and g['goal_version']==1
assert release['fingerprint']==FP(release['snapshot'])
claims=[x for x in s['events'] if x['kind']=='CLAIMED'];assert len(claims)==2 and len([x for x in claims if x['run_id']==rid and x['data']['fence']==1])==1
assert len(s['attempts'])==1;attempt=s['attempts'][0];assert attempt['run_id']==new['refused_run_id'] and attempt['status']=='FAILED' and attempt['mode']=='MOCK' and attempt['error']=='UNSUPPORTED_CAPABILITY' and attempt['usage']=={'status':'unknown','tokens':None}
assert cold['run_id']==rid and cold['instance_id']==new['instance_id'] and cr['corrected_fresh_full_runner']=='NOT_RERUN'
for n in ('first','fixed','final'):
    t=(R/f'boundary-{n}.stdout').read_text();assert (('4 passed' if n=='first' else '8 passed') in t)
    c=J(R/f'boundary-{n}-command.json');assert c['exit_code']==0 and c['source_before']==c['source_after']
probe=J(R/'attempt2/installed-path-probe.stdout');site=R/'installed-venv/lib/python3.12/site-packages'
assert all(Path(probe[k]).is_relative_to(site) for k in ('package','cli','workspace')) and '/workspace/Sim2Act/src' not in probe['sys_path']
archive=REPO/'docs/evidence/blank-synthetic-workspace-20261018/author-originals.tar.gz'
assert archive.stat().st_size==9492853 and H(archive.read_bytes())=='749ef698b232051bdcf302a57fae5dadf2258e00498ca4ce50f6dba4a019a352'
summary={'status':'PASS_LIMITED_FILE_REVIEW','author_seal_file_sha256':H((R/'sealed-manifest.json').read_bytes()),'author_files_projection_sha256':seal['files_projection_sha256'],'manifest_items':len(seal['files']),'raw_bytes':seal['bytes'],'non_database_files_hashed':len(verified),'database_files_stat_only':databases,'symlinks_readlink_only':len(seal['symlinks']),'final_source_files':len(final),'build_inputs':len(build),'package_files':len(names),'wheel_sha256':H(wheel.read_bytes()),'boundary_unique_current':8,'boundary_history_pass_counts':[4,8,8],'new_page':{'checks':13,'requests':102,'GET':92,'POST':10,'assets':27},'cold_page':{'checks':9,'requests':46,'GET':46,'POST':0,'assets':27},'same_data_tables':55,'cold_changed_tables':changed,'unchanged_nonheartbeat_tables':54,'core_run_id':rid,'app_run_id':aid,'first_worker':fw,'cold_worker':cw,'whole_fixture_claims':2,'successful_app_claims':1,'failed_mock_attempts':1,'known_actual_model_provider_calls':0,'cold_optional_protocol_get':{'status':400,'code':'RESOURCE_UNAVAILABLE','message':'Evaluation asset unavailable'},'models_evidence_boundary':'source NeverModel/no provider plus refusal/result facts; no independent runtime network interception asserted','phase_results':['first_full_runner_FAIL_driver_scope','second_full_runner_FAIL_ID_observer','second_new_page_PASS','same_data_cold_continuation_PASS'],'corrected_fresh_full_runner':'NOT_RERUN','db_scope':'No physical DB content/hash access; independently compared author-exported full JSON','reviewer_product_execution':False,'reviewer_network_or_git':False}
(OUT/'final-verification.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
