# WIP fixes — limited independent source review

Read-only review, without executing imported product code, tests, Worker, database or network.

The three initial P2 source findings have been addressed in the current WIP:

- The schema comparison now pins and reflects ordered column names, SQLite-compiled types, nullability, primary-key columns and unique-constraint columns, and compares the complete table mapping before authentication.
- `NeverModel` raises the existing nonretryable `DomainError("UNSUPPORTED_CAPABILITY", ...)`. The original Worker failure path records task failure and can service later work; this is static control-flow confirmation, not an executed result.
- `checked_path` rejects `?` before directory creation, and the engine's parsed database path is required to equal the checked intended path before initialize/reflection/authentication connects.

Two bounded follow-up observations were sent before freeze:

1. The new same-name schema tests initially include a `created_at` column that the original `principals` table does not contain. Therefore the old names-only implementation would also reject those fixtures. Keep exactly the original three column names/order and vary only a constraint or type; no additional nodes are needed.
2. The synthetic root middleware returns `HTMLResponse` directly outside `create_app.security`. It bypasses the original root response's Content-Security-Policy, X-Content-Type-Options and Cache-Control headers. Preserve those three existing headers on the injected root page or keep the original response path. This does not require changing permissions or any production controller.

No other concrete P1/P2 found in the reviewed owned-start/stop flow. Runtime, wheel-installation and cold-reopen qualification remain pending; no frozen-source bridge or PASS is asserted yet.
