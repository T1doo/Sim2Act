# Installed-package page driver — static review

Read `scripts/first-use/blank_workspace_ui.cjs` without executing it. The driver uses real loopback HTTP and evaluates the installed HTML's actual script assets in JSDOM; its `browser` and `visual` fields explicitly remain `NOT_RUN`. It disables page interval polling and uses explicit original refresh actions. It is not a native browser or Windows qualification.

The new branch starts with zero projects and invokes original handlers to create a project, save CSV, submit an unsupported ordinary model task, save a complete Goal, select the existing fixed CSV capability, preview, confirm an internal Release, create an instance and submit one persistent application Run. It then requires the original background Worker result to be SUCCEEDED with sum30/count2/result_version1 and reads it in the original UI. The unsupported task is required to fail with the original `UNSUPPORTED_CAPABILITY` code before the positive path continues.

The cold branch loads the previous proof's precise project/application/instance/Run, finds the application in the unified directory, selects its persisted history item, and requires the same result30. All cold-driver requests must be GET; it creates no second Run.

Requests retain methods, paths, actual status/body hashes and API JSON. Root security headers and each evaluated asset hash are recorded. The bounded result polling GETs are separately labelled and are direct test reads, not user gestures. The driver does not seed projects/resources/results. Setup, wheel/venv path verification, process launch/termination, whole-database or Worker accounting belong to the external runner and have not yet been reviewed.

No static P1/P2 found in this driver. One wording correction was requested: the launcher has an owned Worker **thread within its real server process**, not independent API and Worker processes. The 15/18-second waits are test observer budgets, not product lease/deadline changes; an eventual timeout must be classified from original evidence. Runtime results remain pending.
