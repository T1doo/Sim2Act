# Installed-process runner — static review

Read `/workspace/blank-synthetic-workspace-20261018/installed_acceptance.py` and its `execution-before.json`. No execution, import of product code, database access, Git or network by this reviewer.

The runner creates a new venv, installs the specified wheel using `--no-index --no-deps`, and adds an explicitly disclosed existing dependency directory. It does not edit the old environment's editable `.pth`. Its import probe requires the package, CLI and launcher paths to be under the new venv and rejects checkout/src in sys.path. It verifies every packaged `sim2act/` file against the installed file. Dependency versions are recorded; this is reuse of installed locked dependencies, not a clean download/install of the dependency graph.

The process launch uses the new console script with cwd outside checkout, explicit new persistent data directory, fixed loopback behavior and dynamic port. It supplies deliberately invalid production DSN/LIVE/provider environment values and removes token variables. Settings source review establishes that these values are not consumed. The runner records only explicitly synthetic/public identities.

New and cold launches each own a concrete Popen object. Shutdown targets that object's PID via SIGINT and, only on its bounded timeout, TERM. The stop assertion requires exit0 plus one clean STOPPED event with worker_stopped/data_preserved. It does not stop unknown processes. This is one API process with its owned Worker thread, followed by a separate cold-open process.

The author uses physically read-only SQLite connections to export full synthetic table snapshots. Those are author evidence, not an independent reviewer database reconstruction. The new assertion allows only quota/principal and the exact first Worker's heartbeat before page actions. After the page it checks only the rejected model task and one background application job, the exact worker/fence1 and one CLAIMED event, and typed result30/version1. The cold phase requires a distinct Worker with the same identity; all tables except heartbeats must remain equal and both precise heartbeat IDs must be present.

The runner keeps original command stdout/stderr and failure metadata. A failing final shutdown may raise separately, but the previously saved failure and stop record remain present. No static P1/P2 found in this bounded runner. It does not establish Windows, PostgreSQL or LIVE qualification. Runtime evidence remains pending.
