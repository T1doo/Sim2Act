# Blank installed synthetic workspace — WIP independent review

Scope: read-only source review of `synthetic_workspace.py`, CLI routing, packaging entrypoint and the proposed bounded acceptance contract. No product, test, Worker, model, network, Git/auth or database operations were executed by this reviewer. `wip-inputs.json` records a WIP read snapshot, not a frozen qualification manifest.

The proposed positive path has independent user value: an installed package can open an empty, persistent, explicitly synthetic project workspace. Existing checkout demos either preload results or clean up their fixtures; they do not deliver this entrypoint. This remains separate from ordinary PostgreSQL startup, Windows qualification, LIVE admission, real semantic acceptance and arbitrary local-edit contracts.

## P2 findings reported before freeze

1. **Cold schema validation checks names only.** `schema_fingerprint` and reflected comparison currently cover table/column names. A same-name schema with altered column types/nullability/primary keys/unique constraints passes and can reach authentication and later Worker writes. Pin and compare a finite structural signature before accepting the cold database; do not initialize or migrate the existing database.
2. **A disabled model task can stop the whole workspace.** `NeverModel.request` raises `WorkspaceError`, while existing `Worker.process`/`once` handle `DomainError` for task rejection. The ordinary model-task form is still reachable. This exception escapes to the new service loop, which shuts down the API/Worker. Use the existing nonretryable `DomainError` rejection path so the task fails safely and the workspace remains available, without modifying production Worker gates or creating a model implementation.
3. **Directory-to-SQLite URL interpolation is ambiguous for `?`.** `settings_for` interpolates a user path directly into a SQLAlchemy URL. A legal POSIX directory containing `?` is parsed as URL query syntax, so the checked/marked directory can differ from the actual engine database path; new initialization could access a different existing file. Reject ambiguous path syntax before creating/connecting, or construct a lossless accepted URL, then require the engine database path to equal the checked intended database path before its first connection. Chinese characters and spaces should remain supported.

These are static findings; no dynamic reproduction was run. They are not yet recorded as fixed or qualified.

## Confirmed source boundaries

The CLI's explicit `synthetic-workspace` branch returns before `Settings.from_env`. It constructs Settings with default mock mode, empty token, LIVE false, generation provider disabled, and always creates `Store(..., test_only=True)`. The original Store's ordinary SQLite rejection is untouched. The supplied model cannot perform model requests. Natural runtime independently requires an explicit exact offline MockTransport and enabled provider, which this launcher does not supply.

The socket is bound to fixed loopback before a data directory is touched; a conflicting port is not scanned around. `--new` rejects an existing directory, cold mode does not call initialize, and path/database link checks are explicit. The root page displays the synthetic/non-sensitive/public-login boundary. Existing ordinary API/controller and Worker execution remain the business path.

Shutdown signals only the owned server and Worker, joins the owned thread for ten seconds, preserves the database, and reports `clean=false` if the thread is still active or the loop raised. That bounded shutdown behavior must be verified by the author; source inspection is not a clean-stop result. A new service heartbeat is normal even before a business Run, so blankness should be asserted on business tables rather than all rows after Worker startup.

## Required bounded qualification

After the findings are fixed, build and install the wheel outside checkout into a new environment with explicitly documented existing locked dependencies. Use the package's console command and ordinary page to create a fresh CSV/Goal/application/Release/instance and obtain the deterministic result 30 from the original Worker. Stop the owned process and cold reopen the same workspace in another process, verifying identity and exact historical result. Preserve original commands, executable/package paths, installed source hashes, actual HTTP/page evidence, owned Worker identities/heartbeat accounting, shutdown result and per-run input hashes. Do not claim Windows, ordinary PG startup, new executor/Grant, LIVE or real semantic acceptance.

Current conclusion: design value and core safety direction supported; three concrete P2 fixes remain before freezing the current WIP.
