# Root route closure — static review

The synthetic root page is now an ordinary `@app.get("/")` route placed first in the existing app router. It no longer adds an outer middleware that returns before `create_app.security`. The unchanged security middleware therefore applies its Origin check and normal CSP/nosniff/no-store response headers to the injected page. No security-header policy was copied or independently redefined.

The same-name schema negative fixtures now use exactly the original three `principals` column names/order and vary only primary/unique constraints or the `name` type. These test bodies exercise the structural comparison that was missing from the original WIP.

All four reported source issues and the initial schema-fixture weakness are statically addressed. No remaining concrete P1/P2 found in the present narrow launcher diff. This supports freezing the source for the bounded installed-package qualification; it does not establish runtime success.

The finite boundary module currently has seven test functions, with one two-value parameterization (eight intended nodes). The author reports eight executed PASS; raw execution evidence has not yet been independently audited by this reviewer. The initial four-PASS run must remain a separate earlier source scope.

The proposed installed-package test is consistent with the original product's explicit offline engineering examples (§6.2), while the target Windows/PostgreSQL/independent-process startup requirements (§6.5 and AT-27) remain separately unverified. An in-process API plus owned Worker thread must not be called the original independently deployed API/Worker platform qualification.

Only source and docs were read. No product/test/database/network/Git execution or repository writes. The review directory remains unsealed pending the final author evidence.
