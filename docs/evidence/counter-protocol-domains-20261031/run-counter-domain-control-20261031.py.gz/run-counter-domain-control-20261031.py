from pathlib import Path
import importlib.abc,sys,os,json,hashlib
repo=Path('/workspace/Sim2Act');scratch=Path('/workspace/scratch');mode=sys.argv[1]
root=scratch/'use-manifest-baseline-c6a42c78-20261031' if mode=='c6' else repo
sys.path[:0]=[str(root/'src'),str(root/'tests')]
if mode=='raw':
 class MissingNative(importlib.abc.MetaPathFinder):
  def find_spec(self,fullname,path=None,target=None):
   if fullname=='sim2act._cold_source_owned_impl':raise ModuleNotFoundError('Synthetic optional Source extension absent',name=fullname)
 sys.meta_path.insert(0,MissingNative())
from sim2act import natural_spec_runtime as r,_cold_source_packet as owned
assert Path(r.__file__).resolve()==root/'src/sim2act/natural_spec_runtime.py'
assert owned.available() is (mode!='raw')
print(json.dumps(dict(mode=mode,runtime_module=r.__file__,source_available=owned.available(),test_sha256=hashlib.sha256((repo/'tests/test_counter_loaded_segment.py').read_bytes()).hexdigest())),flush=True)
import pytest
raise SystemExit(pytest.main(['-c',str(root/'pyproject.toml'),str(repo/'tests/test_counter_loaded_segment.py'),'-q','-p','no:cacheprovider','--basetemp='+str(scratch/('counter-domain-'+mode+'-20261031')),'--junitxml='+str(scratch/('counter-domain-'+mode+'-20261031.xml'))]))
