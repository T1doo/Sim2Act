# 图表合同盘点与同 Run CSV 成果格式

接续 `e455a21964cd0e797ceddd9e0e9573f073c2dd40`，原13个本地提交保留，远端/auth不再探测。对照原 F2-T04/T06 与产品 §3.2 F05、§3.3、§5.3：chart 在 `View` 中只有 `component_ref/output_field`；校验仅核输出字段存在，未定义图形类型、x/y角色、序列、单位、排序、缺失值或聚合语义。所有现有chart引用是枚举、未支持说明及负例。字面引用中的 start/end_line 是出处坐标，不是业务量；CSV的 sum/count/column 也没有轴角色合同。因此本轮不画图、不更改chart支持声明。

原 F05/T06 同时要求 MD/JSON/CSV 成果。现 `data.aggregate_csv` 已定义同一材料、列、count及精确十进制sum字符串；`csvRunDownloadValue` 已定义实例/Run/Release/结果版本及该四字段的白名单。当前入口只有结果JSON，原CSV材料下载不等于本次计算成果。选择这个已有数据合同的格式缺口，不重复列修改、授权、私有试写或已交付JSON导出，不新增producer、executor、Grant、接口或账本写入。

## 实现前格式与验收合同

1. 原成功Run旁另列“下载此运行结果 CSV”，JSON按钮和字节合同保持。两格式复用同一fresh/no-store GET、Run/typed AppRun/Release/版本/四字段比对、当前权限与账号/连接/项目/工作区/实例/读取/所选Run围栏；同Run共享in-flight锁，重复/跨格式点击不重复下载。失败或未选Run不提供下载。
2. 文件为UTF-8无BOM，固定八列表头 `instance_id,run_id,release_id,result_version,resource_id,column,sum,count`，随后且仅一行该Run结果；无原材料、账号、权限、完整合同或模型内容。CSV单元格按逗号/双引号/CR/LF做标准引号编码，双引号加倍；记录分隔固定CRLF，末尾CRLF。文件名仅用原实例、Run、结果版本及csv扩展名；MIME `text/csv;charset=utf-8`。
3. sum不经Number/parseFloat/浮点运算，保持原精确字符串（含负号/指数）；count和result_version只序列化既有安全整数。不增加单位、时间轴、额外聚合或取整。CSV解析器可逐格回读原值，不声称外部表格自动类型推断保精度。
4. 文本字段若含Unicode控制/格式字符，或去前导空白后以 `= + - @` 开头，CSV保守拒绝且无Blob；不加apostrophe或改写原值。sum单独要求完整十进制/指数数值形状，合法负数不被当成公式。JSON原值下载保持可用，页面给明确格式限制。正常汉字/逗号/双引号列名可逐字输出。拒绝仍先fresh GET重新鉴权。
5. 一条合成真实HTTP/原NoModel Worker→JSDOM实际下载链核当前与历史Run、超过JS数值精度的sum、Unicode/逗号/引号、负值、CSV危险列名拒绝而JSON不改、双击/跨格式锁、实际迟到读取不下载和真实403。正文反例仅覆盖新格式边界，不重跑旧完整故障矩阵。页面前后55表全等，明确fixture撤权另列；零模型、页面零POST/Worker。

这是实现前合同，尚无本轮运行PASS。真实模型/场景、Windows、PG、原生浏览器文件保存、远端CI及正式发布未验；语义UNKNOWN、人工PENDING，旧满盘独审缺失保持。
