from pathlib import Path
import sys,json
base=Path(__file__).parent;installed=base/'installed-package';sys.path.insert(0,str(installed))
import sim2act,pytest
assert Path(sim2act.__file__).resolve().is_relative_to(installed)
print('INSTALLED_PACKAGE',sim2act.__file__,flush=True)
code=pytest.main(['-q','-o','pythonpath=',*sys.argv[1:]])
modules={n:m.__file__ for n,m in tuple(sys.modules.items()) if n.startswith('sim2act') and getattr(m,'__file__',None)}
assert all(Path(p).resolve().is_relative_to(installed) for p in modules.values())
(base/'installed-modules.json').write_text(json.dumps(dict(exit_code=code,modules=modules),indent=2)+'\n')
raise SystemExit(code)
