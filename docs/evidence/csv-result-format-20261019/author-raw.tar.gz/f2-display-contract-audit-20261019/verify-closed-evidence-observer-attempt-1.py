"""Pure-file audit of closed qualification artifacts; no product imports or DB reads."""
import csv
import hashlib
import io
import json
from pathlib import Path
import xml.etree.ElementTree as ET
from collections import Counter

root = Path(__file__).resolve().parent
repo = Path('/workspace/Sim2Act')
def read(path):
    return json.loads(path.read_text())
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def digest(value):
    return sha(json.dumps(value, sort_keys=True).encode())

freeze = read(root/'source-freeze-qualified.json')
assert len(freeze) == 148
for name, expected in freeze.items():
    for path in (repo/name, root/'qualified-inputs'/name):
        raw = path.read_bytes()
        assert {'bytes':len(raw), 'sha256':sha(raw)} == expected, path
modules = read(root/'installed-modules.json')
assert modules['exit_code'] == 0
assert all(Path(p).is_relative_to(root/'installed-package/sim2act') for p in modules['modules'].values())
suite = ET.parse(root/'qualified-installed.xml').getroot().find('testsuite')
assert suite.attrib['tests'] == '3'
assert all(suite.attrib[k] == '0' for k in ('errors','failures','skipped'))
nodes = [{'classname':n.attrib['classname'], 'name':n.attrib['name'], 'seconds':float(n.attrib['time'])} for n in suite.findall('testcase')]
assert len({(n['classname'],n['name']) for n in nodes}) == 3
summary = {'status':'PASS', 'method':'pure-file only; no product/test execution or database reads',
 'pytest':{'unique_nodes':nodes,'suite_seconds':float(suite.attrib['time'])},
 'frozen_inputs_unchanged':len(freeze),'installed_modules':len(modules['modules']), 'cases':[]}
header = ['instance_id','run_id','release_id','result_version','resource_id','column','sum','count']
for number, expected_case in enumerate(['csv-format','csv-boundaries','versions-and-rejections']):
    folder = root/'qualified-installed'/f'test_csv_run_download_actual_h{number}'
    data, info, proof = [read(folder/n) for n in ['results.json','info.json','database-proof.json']]
    assert data['status'] == 'PASS' and data['case'] == expected_case
    assert data['model_requests'] == 0 and proof['model_requests'] == 0
    assert data['browser_download'] == 'NOT_RUN' and data['pg'] == 'NOT_RUN'
    assert len(data['asset_loads']) == 27
    for asset in data['asset_loads']:
        raw = asset['text'].encode()
        assert asset['status'] == 200 and sha(raw) == asset['sha256']
        assert raw == (root/'qualified-inputs/src/sim2act/web'/asset['name']).read_bytes()
        assert raw == (root/'installed-package/sim2act/web'/asset['name']).read_bytes()
    assert all(r['method']=='GET' and r['no_body'] and r['cache']=='no-store' for r in data['requests'])
    controlled = [r for r in data['requests'] if r.get('controlled_response')]
    changed = [r for r in data['requests'] if r['actual_response_text'] != r['delivered_response_text']]
    assert all(r.get('controlled_response')=='SYNTHETIC_AFTER_ACTUAL_HTTP' for r in changed)
    assert all(r['actual_status']==200 for r in controlled)
    assert data['final_state']['pending']==0 and data['final_state']['actions']==0
    assert data['final_state']['page_errors']==[]
    assert all(b['revoked'] for b in data['blobs'])
    files = []
    for index, blob in enumerate(data['blobs']):
        filename = f'captured-result-{index}.csv' if f'captured-result-{index}.csv' in data['csv_files'] else f'captured-blob-{index}.json'
        raw = (folder/filename).read_bytes()
        assert len(raw)==blob['bytes'] and sha(raw)==blob['sha256']
        anchor = data['anchors'][index]
        if filename.endswith('.csv'):
            assert not raw.startswith(b'\xef\xbb\xbf') and raw.endswith(b'\r\n')
            rows = list(csv.reader(io.StringIO(raw.decode(),newline=''),strict=True))
            assert len(rows)==2 and rows[0]==header
            output = next(o for o in info['outputs'] if o['id']==rows[1][1])
            result = output['result']
            expected = [info['instance'],output['id'],output['release_id'],str(output['result_version']),result['resource_id'],result['column'],result['sum'],str(result['count'])]
            assert rows[1]==expected
            encoded=io.StringIO(newline='');csv.writer(encoded,lineterminator='\r\n').writerows([header,expected])
            assert raw==encoded.getvalue().encode()
            assert anchor['filename']==f"sim2act-{info['instance']}-{output['id']}-v{output['result_version']}.csv"
            files.append({'name':filename,'bytes':len(raw),'sha256':sha(raw),'run_id':output['id'],'release_id':output['release_id'],'result_version':output['result_version'],'column':result['column'],'sum':result['sum'],'original_historical_release':output['release_id']!=info['current_release']})
        else:
            value=json.loads(raw)
            output=next(o for o in info['outputs'] if o['id']==value['run_id'])
            expected={'instance_id':info['instance'],'run_id':output['id'],'release_id':output['release_id'],'result_version':output['result_version'],'result':{k:output['result'][k] for k in ('resource_id','column','sum','count')}}
            assert value==expected and raw==(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
    before, after = [read(folder/n) for n in ('database-before-page.json','database-after-page.json')]
    assert len(before)==len(after)==55
    assert digest(before)==proof['before_sha256'] and digest(after)==proof['after_sha256']
    differences=[name for name in before if before[name]!=after[name]]
    delta=None
    if expected_case=='csv-boundaries':
        assert differences==['grants']
        old=[json.loads(s) for s in set(before['grants'])-set(after['grants'])]
        new=[json.loads(s) for s in set(after['grants'])-set(before['grants'])]
        assert len(old)==len(new)==1 and old[0]['revoked'] is False and new[0]['revoked'] is True
        assert old[0]['tool_ref']=='resource.read' and new[0]['revision']==old[0]['revision']+1
        assert {k:v for k,v in old[0].items() if k not in ['revoked','revision']}=={k:v for k,v in new[0].items() if k not in ['revoked','revision']}
        delta={'before':old[0],'after':new[0]}
        denied=[r for r in data['requests'] if r['actual_status']==403]
        assert len(denied)==1 and json.loads(denied[0]['actual_response_text'])['error']['code']=='GRANT_REVOKED'
    else:
        assert not differences
    workers=read(folder/'worker-log.json')
    assert all(w['claimed'] for w in workers) and [w['run_id'] for w in workers]==info['runs']
    fixtures=read(folder/'fixture-http.json')
    summary['cases'].append({'case':expected_case,'page_checks':len(data['checks']),'page_http_requests':len(data['requests']),'asset_http_requests':len(data['asset_loads']),'fixture_testclient_requests':len(fixtures),'controlled_response_records':len(controlled),'actually_changed_delivered_responses':len(changed),'actual_page_statuses':dict(Counter(str(r['actual_status']) for r in data['requests'])),'worker_claims':len(workers),'run_statuses':dict(Counter(o['status'] for o in info['outputs'])),'blobs':len(data['blobs']),'csv_files':files,'database_tables':55,'table_differences':differences,'controlled_grant_delta':delta})
summary['bounds']={'real_model_requests':0,'remote_operations':0,'old_navigation_parameter_cases':'NOT_RUN','csv_run_ABA_and_actual_revoke':'RUN','csv_identity_project_instance_fences':'static reuse review only; original full navigation matrix NOT_RERUN','native_browser_save':'NOT_RUN','Windows':'NOT_RUN','PG':'NOT_RUN','remote_CI':'NOT_RUN','pinned_setuptools82_build':'NOT_RUN; local builder setuptools84','real_scenarios':'UNKNOWN','human_acceptance':'PENDING','old_full_disk_review':'NOT_RECOVERED'}
(root/'closed-evidence-verification.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
