from pathlib import Path
import hashlib,json,csv,io,re,collections,unicodedata,xml.etree.ElementTree as ET
from decimal import Decimal,localcontext
from urllib.parse import urlparse
R=Path('/workspace/f2-display-contract-audit-20261019')
O=Path('/workspace/f2-chart-contract-review-20261018')
def sha(b): return hashlib.sha256(b).hexdigest()
def fp(v): return sha(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode())
def j(p): return json.loads(p.read_text())
def projection(i,q):
    return dict(instance_id=i['instance'],run_id=q['id'],release_id=q['release_id'],result_version=q['result_version'],result={k:q['result'][k] for k in ['resource_id','column','sum','count']})
headers=['instance_id','run_id','release_id','result_version','resource_id','column','sum','count']
all_cases=[]; http=[]; fixture=[]; csvs=[]; jsons=[]; worker_total=0
for d in sorted(p for p in (R/'qualified-installed').iterdir() if p.is_dir() and not p.is_symlink()):
    p=j(d/'results.json'); i=j(d/'info.json'); before=j(d/'database-before-page.json'); after=j(d/'database-after-page.json')
    assert p['status']=='PASS' and p['case']==i['case'] and len(before)==len(after)==55 and before.keys()==after.keys()
    assert all(isinstance(rows,list) and all(isinstance(row,str) for row in rows) for rows in before.values())
    tables={k:[json.loads(row) for row in rows] for k,rows in before.items()}
    changed=[k for k in before if before[k]!=after[k]]
    grant_delta=[]
    if i['case']=='csv-boundaries':
        assert changed==['grants']
        old={q['id']:q for q in tables['grants']};new={q['id']:q for q in map(json.loads,after['grants'])}
        assert old.keys()==new.keys()
        ids=[k for k in old if old[k]!=new[k]];assert len(ids)==1
        k=ids[0];a,b=old[k],new[k]
        assert {f for f in a if a[f]!=b[f]}=={'revision','revoked'}
        assert type(a['revoked']) is bool and a['revoked'] is False and b['revoked'] is True and b['revision']==a['revision']+1
        assert a['tool_ref']=='resource.read' and a['project_id']==i['project'] and a['resource_id']==i['outputs'][0]['result']['resource_id']
        grant_delta=[dict(id=k,principal_id=a['principal_id'],resource_id=a['resource_id'],tool_ref=a['tool_ref'],revision=[a['revision'],b['revision']],revoked=[False,True])]
    else: assert not changed
    proof=j(d/'database-proof.json')
    assert proof['before_sha256']==sha(json.dumps(before,sort_keys=True).encode()) and proof['after_sha256']==sha(json.dumps(after,sort_keys=True).encode())
    assert not tables['attempts'] and not tables['reservations']
    runs={q['id']:q for q in tables['runs']};appruns={q['id']:q for q in tables['internal_app_runs']};releases={q['id']:q for q in tables['internal_releases']}
    inst=next(q for q in tables['internal_instances'] if q['id']==i['instance'])
    assert inst['release_id']==i['current_release'] and inst['source_app_id']==i['app'] and inst['project_id']==i['project']
    for q in releases.values():
        assert q['fingerprint']==fp(q['snapshot']) and q['project_id']==i['project'] and q['principal_id']==inst['principal_id']
        draft=q['snapshot']['draft'];assert draft['id']==i['app'] and draft['runtime_id']==inst['runtime_id'] and draft['fingerprint']==fp(draft['candidate'])
    for q in i['outputs']:
        core=runs[q['id']];app=appruns[q['app_run_id']]
        assert core['status']==q['status']==app['status'] and core['project_id']==i['project'] and core['principal_id']==inst['principal_id'] and core['runtime_id']==inst['runtime_id']
        assert q['instance_id']==app['instance_id']==i['instance'] and q['release_id']==app['release_id'] and q['release_id'] in releases
        assert q['result_version']==app['result_version'] and q['result']==app['output']
        typed=[t for t in tables['internal_instance_data'] if t['run_id']==q['app_run_id']]
        if q['status']=='SUCCEEDED':
            assert len(typed)==1 and q['known_effects']==typed
            t=typed[0];assert t['instance_id']==i['instance'] and t['release_id']==q['release_id'] and t['version']==q['result_version'] and t['data']['result']==q['result'] and t['fingerprint']==fp(t['data'])
            res=next(z for z in tables['resources'] if z['id']==q['result']['resource_id'])
            assert res['format']=='csv' and res['hash']==q['result']['source_hash']==sha(res['content'].encode())
            rows=list(csv.DictReader(io.StringIO(res['content'],newline='')))
            with localcontext() as context:
                context.prec=10000; total=sum((Decimal(z[q['result']['column']]) for z in rows),Decimal(0))
            assert Decimal(q['result']['sum'])==total and q['result']['count']==len(rows)
        else: assert q['status']=='FAILED' and q['result'] is None and not typed
    workers=j(d/'worker-log.json'); assert len(workers)==len(i['outputs']) and len({q['worker_id'] for q in workers})==len(workers)
    beats={q['id']:q['at'] for q in tables['heartbeats']}
    for w in workers:
        core=runs[w['run_id']];assert w['claimed'] is True and core['worker_id']==w['worker_id'] and core['fence']==1
        claims=[q for q in tables['events'] if q['run_id']==w['run_id'] and q['kind']=='CLAIMED'];assert len(claims)==1 and claims[0]['data']['fence']==1
        assert w['started_at']<=beats[w['worker_id']]<=w['ended_at']
    worker_total+=len(workers)
    freeze=j(R/'source-freeze-qualified.json')
    assert len(p['asset_loads'])==27 and len({a['name'] for a in p['asset_loads']})==27
    for a in p['asset_loads']:
        expected=freeze['src/sim2act/web/'+a['name']]
        assert a['status']==200 and sha(a['text'].encode())==a['sha256']==i['web_hashes'][a['name']]==expected['sha256'] and len(a['text'].encode())==expected['bytes']
    assert p['loaded_source_sha256']==i['web_hashes'] and len(i['web_hashes'])==27
    controlled=0; missing_delivered=0; status=collections.Counter()
    for n,q in enumerate(p['requests']):
        assert q['method']=='GET' and q['no_body'] is True and q['response_headers']['cache-control']=='no-store'
        if re.fullmatch(r'/api/internal/instances/[^/]+/runs/[^/]+',q['path']): assert q.get('cache')=='no-store'
        if 'cache' not in q: assert q['path'] in [f"/api/projects/{i['project']}/protocol/contracts",f"/api/projects/{i['project']}/resources"]
        assert urlparse(q['url']).netloc==urlparse(i['base']).netloc and urlparse(q['url']).hostname=='127.0.0.1'
        assert q['finished_ms']>=q['started_ms'] and abs(q['elapsed_ms']-(q['finished_ms']-q['started_ms']))<0.01
        data=json.loads(q['actual_response_text']); status[q['actual_status']]+=1
        if q.get('controlled_response'):
            assert q['controlled_response']=='SYNTHETIC_AFTER_ACTUAL_HTTP' and q['actual_status']==200 and q['actual_response_text']!=q['delivered_response_text'];controlled+=1
        elif 'delivered_response_text' in q: assert q['actual_response_text']==q['delivered_response_text']
        else: missing_delivered+=1
        if q['actual_status']==400: assert q['path'].endswith('/protocol/contracts') and data['error']['code']=='RESOURCE_UNAVAILABLE'
        if q['actual_status']==403: assert i['case']=='csv-boundaries' and data['error']['code']=='GRANT_REVOKED'
        http.append(dict(case=i['case'],index=n,path=q['path'],status=q['actual_status'],actual_sha256=sha(q['actual_response_text'].encode()),delivered_sha256=sha(q['delivered_response_text'].encode()) if 'delivered_response_text' in q else None,controlled_response=q.get('controlled_response')))
    assert controlled=={'csv-format':0,'csv-boundaries':1,'versions-and-rejections':18}[i['case']]
    assert missing_delivered==int(i['case']=='versions-and-rejections')
    for n,q in enumerate(j(d/'fixture-http.json')):
        assert urlparse(q['url']).hostname=='testserver' and q['status'] in [200,201,202]
        json.loads(q['response_text'])
        fixture.append(dict(case=i['case'],index=n,method=q['method'],url=q['url'],status=q['status'],request_sha256=sha(q['request_body'].encode()) if q['request_body'] is not None else None,response_sha256=sha(q['response_text'].encode())))
    assert all(b['revoked'] is True for b in p['blobs']) and not p['final_state']['pending'] and not p['final_state']['actions'] and not p['final_state']['page_errors']
    for name in p['csv_files']:
        path=d/name;raw=path.read_bytes();parsed=list(csv.reader(io.StringIO(raw.decode('utf-8'),newline=''),strict=True));assert parsed[0]==headers and len(parsed)==2 and not raw.startswith(b'\xef\xbb\xbf')
        q=next(q for q in i['outputs'] if q['id']==parsed[1][1]);v=projection(i,q)
        expected=[v['instance_id'],v['run_id'],v['release_id'],str(v['result_version']),v['result']['resource_id'],v['result']['column'],v['result']['sum'],str(v['result']['count'])]
        assert parsed[1]==expected and re.fullmatch(r'[+-]?[0-9]+(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?',parsed[1][6])
        buf=io.StringIO(newline='');csv.writer(buf,lineterminator='\r\n').writerows([headers,expected]);assert raw==buf.getvalue().encode()
        index=int(re.search(r'-(\d+)\.csv$',name)[1]);blob=p['blobs'][index];assert blob['sha256']==sha(raw) and blob['bytes']==len(raw)
        filename=f"sim2act-{i['instance']}-{q['id']}-v{q['result_version']}.csv";assert any(a['filename']==filename and a['url'].endswith('-'+str(index)) for a in p['anchors'])
        assert any(x['actual_status']==200 and not x.get('controlled_response') and x['path'].endswith('/runs/'+q['id']) and json.loads(x['actual_response_text'])==q for x in p['requests'])
        csvs.append(dict(case=i['case'],path=str(path.relative_to(R)),bytes=len(raw),sha256=sha(raw),run_id=q['id'],release_id=q['release_id'],result_version=q['result_version'],column=q['result']['column'],sum=q['result']['sum']))
    for path in sorted(d.glob('captured-blob-*.json')):
        raw=path.read_bytes();v=json.loads(raw);q=next(q for q in i['outputs'] if q['id']==v['run_id']);assert v==projection(i,q)
        assert raw==(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode()
        index=int(re.search(r'-(\d+)\.json$',path.name)[1]);assert p['blobs'][index]['sha256']==sha(raw) and p['blobs'][index]['bytes']==len(raw)
        jsons.append(dict(case=i['case'],path=str(path.relative_to(R)),bytes=len(raw),sha256=sha(raw),run_id=q['id'],release_id=q['release_id'],sum=q['result']['sum']))
    all_cases.append(dict(case=i['case'],raw_directory=str(d.relative_to(R)),checks=len(p['checks']),page_gets=len(p['requests']),assets=len(p['asset_loads']),actual_page_statuses=dict(status),fixture_asgi=len(j(d/'fixture-http.json')),controlled_response_negatives=controlled,synthetic_transport_loss_after_actual_get=missing_delivered,fixture_workers=len(workers),fixture_succeeded=sum(q['status']=='SUCCEEDED' for q in i['outputs']),fixture_failed_nonnumeric=sum(q['status']=='FAILED' for q in i['outputs']),model_attempts=len(tables['attempts']),reservations=len(tables['reservations']),protected_snapshot_tables=55,changed_snapshot_tables=changed,grant_delta=grant_delta,current_release=i['current_release'],historical_result_release=i['outputs'][1]['release_id'],all_retained_result_and_release_hashes_valid=True))
history=[]
for name in ['attempt-1.xml','attempt-2.xml','attempt-3.xml','qualified-installed.xml']:
    x=ET.parse(R/name).getroot();ts=list(x.iter('testcase'))
    items=[dict(node_id=t.attrib['classname']+'.'+t.attrib['name'],seconds=float(t.attrib['time']),result='FAIL' if t.find('failure') is not None else 'ERROR' if t.find('error') is not None else 'SKIP' if t.find('skipped') is not None else 'PASS',failure_message=t.find('failure').attrib.get('message') if t.find('failure') is not None else None) for t in ts]
    history.append(dict(path=name,testcases=items,counts=dict(collections.Counter(t['result'] for t in items))))
assert history[-1]['counts']=={'PASS':3} and history[0]['counts']==history[1]['counts']=={'FAIL':2} and history[2]['counts']=={'PASS':1}
modules=j(R/'installed-modules.json'); assert modules['exit_code']==0 and all(Path(p).is_relative_to(R/'installed-package') for p in modules['modules'].values())
out={'verdict':'PURE_FILE_FINAL_QUALIFICATION_AUDIT_PASS','source_runtime_pending_seal':True,'method':'Stdlib JSON/CSV/Decimal/hash/XML only. No product/test/DB/Git/network execution. Snapshot exports are author-produced; reviewer independently recomputed their JSON contents, not physical DB.','qualified_cases':all_cases,'totals':dict(unique_final_pytest_nodes=3,qualified_passes=3,page_checks=sum(q['checks'] for q in all_cases),page_gets=len(http),assets=sum(q['assets'] for q in all_cases),fixture_asgi=len(fixture),fixture_workers=worker_total,fixture_claims=worker_total,fixture_succeeded=sum(q['fixture_succeeded'] for q in all_cases),fixture_failed_nonnumeric=sum(q['fixture_failed_nonnumeric'] for q in all_cases),csv_files=len(csvs),retained_json_blob_files=len(jsons),created_blob_count=sum(len(j(R/q['raw_directory']/'results.json')['blobs']) for q in all_cases),controlled_response_negatives=sum(q['controlled_response_negatives'] for q in all_cases),synthetic_transport_loss_after_actual_get=sum(q['synthetic_transport_loss_after_actual_get'] for q in all_cases),model_attempts=0,reservations=0,page_post=0,page_workers=0),'csv_files':csvs,'json_files':jsons,'http_response_hashes':http,'fixture_asgi_hashes':fixture,'junit_history':history,'installed_product_modules':len(modules['modules']),'limits':['Chart still unsupported: no axis/series/unit semantic contract','CSV restricted to fixed successful single aggregate Run output; dangerous textual cells rejected and JSON retained','No native browser save, cold browser/server restart, Windows, PG, remote CI, formal publication, real model/semantics or human acceptance tested','Cross-Run ABA and one actual source revoke tested; no new full identity/project/reconnect fault matrix','Two earlier exploration runs failed; smoke PASS is not a final installed qualification node']}
(O/'qualified-raw-verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'verdict':out['verdict'],'totals':out['totals'],'cases':all_cases,'csv_files':csvs},ensure_ascii=False,indent=2))
