# F2 chart 合同与下一业务缺口（有限只读审查）

**结论：chart 不能按当前合同直接接线；可优先补“所选成功 CSV 聚合 Run 的 CSV 文件交付”。** 后者是已有结果的明确文件格式能力，不重做换列、换材料、授权、集合导出或恢复链。本轮未实现、未执行或验收该能力。

## chart 的具体缺口

- 原产品 §3.2 F05（`平台产品设计.md:88`）、§3.3（:103）要求简单图表；F2-T04/T06（`分阶段开发计划.md:96–98`）要求可信组件和真实成果。
- `contracts.py:76–78` 的 View 只有 component_ref 与 output_field。严格模型不能接收额外轴字段；`:672–674` 仅检查输出字段存在，没有 x/category、series/y、单位、顺序、聚合、null/精度及有限数据合同。
- `internal.js:629–649` 已按历史 record.release_id 核原 Release/候选/typed/Run，不存在需要重做的历史定义绑定。`:651–673` 已安全解释 text/table，并明确拒绝 chart；不能改用当前 draft 或最新 Release 填补旧成果的图表定义。
- `text_apps.py:95–108` 的整数 start_line/end_line 是引用坐标，不能推成业务图表。`apps.py:42–49` 的 count/sum 是单次聚合输出，也没有类别/series/单位约定。其他现有固定生产者的 text/table 声明不提供可直接引用的 chart 数据合同。
- `ManifestViewComposition20261018.md:3–13` 明确本片 text/table，chart 未支持。既有 text/table 与历史/冷读工程资格不应换名重做。

因此 chart 是真实尚未交付的代码及合同范围，不是已经定义好组件却遗漏按钮。未来先确定独立图表声明及生产者/业务语义、编译校验和有限 renderer，再独立验收；这不要求新 executor/Grant，但本次不能自动猜轴或将 provenance 画成业务量。

## 优先的已有合同切片：CSV 聚合成果下载

- 原 F05 明列 MD/JSON/CSV，F2-T06 要求真实文件成果。`tools.py:333–353` 已定义已授权 CSV 的 resource_id/column/count/精确 Decimal 字符串 sum/source_hash；`apps.py:42–49` 为闭合输出 schema。
- `use.js:221–228` 已有成功 Run、原 AppRun/Release/result_version、typed record 对齐后的固定白名单结果；`:230–259` 目前唯一按钮和 Blob 均为 JSON。对 web 下载/Blob 调用的源检索未发现聚合成果 CSV 序列化入口。
- `app.js:82–89` 可下载已有资源原字节，故不能说“平台完全不能下载 CSV”；但下载原材料不会交付本次已验证的聚合成果。普通任务成果路径 `:266–280` 限定已有 MD。`CsvRunResultDownload20261016.md:3–11` 也明确旧交付只有所选 Run JSON。
- 最小实现复用 csvRunDownloadValue/csvRunDownloadControl 的同 Run fresh GET、历史绑定、双击锁、账号/连接/项目/工作区/实例/Run 围栏及 403 清私有数据，仅新增明确 CSV 格式。可将现 JSON 白名单扁平化为固定 header + 一行；不增加源 CSV 内容、合同/Goal/权限/token，也不触 server 写入。
- 先冻结新文件合同：UTF-8、确定字段顺序/换行、标准双引号转义、sum 原样字符串且不经 Number；CSV 解析保留原十进制词法不等于保证电子表格自动导入的数值精度。任意 column 可含公式开头字符，单纯加 CSV 双引号不足，须明确可逆文本编码或有限拒绝策略，不应静默改名/改值。
- 最小验收可复用 `test_csv_run_download.py:39–40` 与 `csv_run_download.cjs` 的合法成功 Run/历史和 Blob 捕获机制，新增一次明确 CSV 下载并独立解析比较白名单/Unicode/逗号引号换行及精确十进制；仍核 fresh GET 和全表只读。无需重跑完整自然、授权或恢复矩阵。实际浏览器/Windows/PG/真实语义继续单列未测。

本次有界检查亦确认 report_presentations 的 decision→explanation 页面操作、manual lock、现自然局部修改控制器已有，不能误算新未接入口。未找到比上述 CSV 文件交付更高且已有足够合同、可在当前权限范围独立完成的替代项。正式发布和受信真实 source/provider 安装仍未完成，不能用改标志或填环境变量代替。

## 方法与限制

仅源码、文档、已有测试代码的读取及普通文件 SHA256；未运行产品/pytest/Worker/模型/SQL/DB/网络/Git，未读私有留出集或旧封存目录。HEAD/clean/分支状态由 parent 提供，未独立 Git 核验。未验证任何未来实现、归档或提交。当前读取源 hash 见 source-read-hashes.json。

检索曾出现缺失路径（checks.py、CSVRunDownload* 文档 glob）导致只读 rg 退出2；改读实际 tools.py 与 CsvRunResultDownload20261016.md。它们是文件检索错误，不是产品或测试失败，工具可见文本摘录见 query-observations.json。
