# CSV 格式实现前有限静审（未冻结资格）

当前读取的 `web/use.js` 与 `CsvResultFormat20261019.md`：未发现范围扩大、同 Run 跨格式锁、迟到响应、403 清正文或原 JSON 投影/字节算法方面的新确定 P1/P2。只读静审，不是运行 PASS。

CSV 文本门先拒 Cc/Cf，trimStart 后拒 =+-@；不加 apostrophe 篡改字段。sum 单独限长并按有界十进制/指数词法核验，不经 Number；普通负数无需作为公式拒绝。固定八表头/单结果行、逗号和引号转义、CRLF/UTF-8 无 BOM 与合同一致。文件名只用既有实例/Run/版本标识。缺图表合同仍明确保持 unsupported。

两按钮共用 closure downloading 与全局 applicationUseDownloads 原 key（无 format 维度）。双击、跨格式及重绘中的相同 scope/Run 不另 GET；连接代次和读取代次/实例对象/Run 选择使原回调失效。fresh GET 对齐既有 AppRun/Release/result_version/typed 四字段后，才同步形成 Blob；403 仍调用原 clearApplicationUseData。JSON 保留同一 value 的 stringify(indent=2)+LF、MIME、文件名，只新增独立 CSV 按钮。

一项静态格式偏差已即时告知 root：本次 WIP sum 正则使用 JS `$`，可匹配最终单个 LF 前位置，因此 `1\n` 不符合“完整数值字符串”合同却可能匹配。正常注册 aggregate 不产此值；不是已运行 HTTP 漏洞或费用/权限问题。建议绝对终止断言 `(?![\s\S])` 或显式控制字符拒绝，附一个 synthetic helper 反例即可；不应扩实际故障矩阵。见 `csv-format-wip-observation.json` 和原 helper 字节摘录。后续以实际最终源复审此点。

测试源码静审：新 csv-format/csv-boundaries 复用原真实 loopback/NoModel Worker，两个 Release/同实例历史，成功与失败 Run 分别处理；Python 用独立 csv.reader/csv.writer 比较完整八格和原字节。CJS 的 Release 污染属于合成响应负例，撤权通过夹具实际 API 执行；两者不能混报。页面55表断言及 fixture 撤权另列，不引新 API/Grant/producer。当前没有读取在途输出，未独立签任何探索或最终运行结果；源码仍可能变动。

方法：普通文件读取、文本检索和 SHA256。未运行产品、Node/pytest、DB/SQL、Git、网络、模型，未写仓库/作者/旧封存目录。此目录尚未封存，等 root 后续冻结与闭合原件。
