from pathlib import Path
import json,hashlib,os,stat,collections
R=Path('/workspace/f2-chart-contract-review-20261018');A=Path('/workspace/f2-display-contract-audit-20261019');S=Path('/workspace/Sim2Act')
def h(p):
    b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(name,data): (R/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
raw=json.loads((R/'qualified-raw-verification.json').read_text()); bridge=json.loads((R/'qualified-freeze-verification.json').read_text());am=json.loads((R/'author-manifest-verification.json').read_text())
put('raw-viewer-inline-error-transcript.json',{'classification':'PURE_FILE_VIEWER_ERROR_NOT_PRODUCT','provenance':'Original tool-visible output transcribed afterwards, not originally redirected raw stderr; output included truncated HTML. No failed command was rerun.','traceback':'File "<stdin>", line 10; TypeError: string indices must be integers, not str','cause':'The snapshot rows are JSON strings; viewer indexed them as dicts.','correction':'Decode rows with json.loads, retain full raw-array equality for all55 tables.'})
put('final-aggregation-error-transcript.json',{'classification':'PURE_FILE_AGGREGATION_ASSERTION_NOT_PRODUCT','provenance':'Original functions.exec tool-visible output transcribed afterwards; no originally redirected stderr or saved script.','traceback':'File "<stdin>", line 7; AssertionError','faulting_assertion':'manifest.non_db_bytes_hashed==26321790','cause':'Reviewer erroneously presumed uniform DB sizes when predetermining nonDB bytes. All500 actual hashes had already passed.','correction':'Use the sum of individually verified manifest entries: '+str(am['non_db_bytes_hashed'])+' nonDB bytes, with actual perDB stat sizes. No product/author files changed.'})
put('observer-corrections.json',{'reviewer_errors':[{'record':'query-observations.json','kind':'Missing read-only source/glob paths'},{'record':'qualified-freeze-observer-correction.json','original_script':'verify-qualified-inputs.py','stderr':'qualified-freeze-audit.stderr','kind':'Earlier source manifest listed139 package files while oldwheel has141; corrected exact oldwheel comparison'},{'record':'raw-viewer-inline-error-transcript.json','kind':'JSON-row string/dict shape assumption; tool transcript only'},{'original_script':'audit-qualified-raw.py','stderr':'qualified-raw-audit.stderr','kind':'Optional cache metadata absent on unrelated protocol/resource GET; fresh download requests explicitly no-store and allresponses no-store'},{'original_script':'audit-qualified-raw-v2.py','stderr':'qualified-raw-audit-v2.stderr','kind':'GET request_body is null; corrected null handling'},{'record':'final-aggregation-error-transcript.json','kind':'Wrong hardcoded nonDB bytes; corrected to verified sum'}],'corrected_pure_audits':['verify-qualified-inputs-v2.py','audit-qualified-raw-v3.py','verify-author-manifest.py'],'author_observer_failures_retained_and_hashed':['verify-closed-evidence-observer-attempt-1.txt','verify-closed-evidence-observer-attempt-2.log','verify-closed-evidence-observer-attempt-3.log'],'product_or_pytest_runs_by_reviewer':0})
executions=[t for group in raw['junit_history'] for t in group['testcases']]
counts=dict(collections.Counter(t['result'] for t in executions))
refs={n:h(R/n) for n in ['qualified-raw-verification.json','qualified-freeze-verification.json','author-manifest-verification.json','observer-corrections.json']}
v={'verdict':'LIMITED_PASS_CSV_RUN_RESULT_FORMAT','remaining_p1_p2_in_reviewed_slice':[],'chart':'Still unsupported: no axes/series/units/shape semantics; no inferred chart added. Not wholeF2 acceptance.','reviewer_execution':{'product':0,'pytest':0,'worker':0,'model':0,'network':0,'git':0,'physical_DB_content_or_hash':0,'private_holdout':0},'author_closure':{k:am[k] for k in ['manifest','seal','payload_regular_files','payload_bytes','non_db_files_hashed','non_db_bytes_hashed','database_files_stat_only','symlinks','physical_tree_exact_except_two_closing_metadata_files']},'freeze':bridge,'qualified':{'pytest_nodes':3,'pass':3,'fail':0,'error':0,'skip':0,'junit_total_seconds':122.999,'totals':raw['totals'],'cases':raw['qualified_cases'],'csv':raw['csv_files'],'retained_json_blob_files':raw['json_files'],'page_actual_statuses':{'200':126,'400_optional_protocol':3,'403_actual_revocation':1},'fixture_HTTP_is_ASGI_and_separate_from_page_loopback':True,'independent_all55_JSON_comparison':True,'independent_physical_DB_recomputation':False,'failed_anchor_blob3':'Revoked metadata only; no saved file/anchor; not fabricated','installed_product_modules':94},'history':{'saved_pytest_executions':len(executions),'counts':counts,'final_unique_nodes':3,'detail':raw['junit_history'],'smoke_not_installed_final_qualification':True,'earlier_failed_runs_not_reclassified':True},'scope_static':{'sum_issue_fixed':'Exact match[0] equality rejects LF/suffix. Final synthetic formatter negative is distinct from actual HTTP.','original_JSON_projection_and_serialization':'Unchanged in reviewed scope; five retained JSON files independently exact-byte checked','cross_format_dedup':'SameRun shared pending key; no new permission or serverwrite','document':{'path':'docs/F2/CsvResultFormat20261019.md',**h(S/'docs/F2/CsvResultFormat20261019.md')},'document_no_material_overstatement_found':True,'archive_commit_remote_not_endorsed':True},'limits':raw['limits']+['Exponent support and broad dangerous-Unicode cases are static contract coverage, not an exhaustive dynamic positive fixture set','No spreadsheet automatic type/precision guarantee','Pinned setuptools82.0.1 build NOT_RUN; existing Python3.12/setuptools84 offline build','Real semantics UNKNOWN; human acceptance PENDING; old lost review reports not restored'],'machine_audits':refs,'observer_errors':'observer-corrections.json','intermediate_pending_flags':'Earlier raw-audit pending-seal flags are chronological and superseded by this final author closure.'}
put('final-verification.json',v)
report=f'''# 同 Run CSV 成果格式有限独审

**LIMITED_PASS_CSV_RUN_RESULT_FORMAT。当前限定切片未发现剩余确定 P1/P2。** chart 仍无轴、series、单位及数据语义合同，本轮正确保持 unsupported，不签整个F2。

本次仅补成功聚合Run的显式八列CSV文件，复用原fresh GET、typed AppRun/Release/版本/结果绑定和下载锁；未新增producer、Python运行代码、Grant、API或表。sum精确字符串、危险文本拒绝CSV而JSON可用。WIP正则末尾LF边界已修为完整match[0]等值；最终synthetic helper反例明确另列。

最终安装包JUnit **3PASS/0FAIL/ERROR/SKIP，122.999秒**：csv-format43.170秒/20检查，csv-boundaries37.793秒/12检查，原JSON回归41.707秒/52检查。84检查非84pytest。130页面GET、81资产与61夹具ASGI分列；页面实际126×200、3×可选protocol400、1×真实READ撤权403。19份实际HTTP后响应污染、1次合成transport丢响应均单列。

独立解析并重编码4份CSV全字节相同，核固定八列/单结果行、UTF-8无BOM/CRLF、同Run与历史Release、超JS精度的9007199254740993.123456790、汉字逗号引号和合法负数。5份留存JSON全字节同原投影。故意anchor失败的blob3只有revoked元数据，无文件/anchor，未补造。共享两格式锁、Run ABA迟到无文件、危险列拒CSV而JSON仍可用、实际403清私有数据由真实页面证据支持。

全55表导出JSON已独立比较：格式与JSON例全等；边界例仅一个既知owner READ Grant revoked false→true/revision1→2，其他54表与其他Grant原样。Run/AppRun/typed/Release/数据历史保持；独立重算typed/Release/候选指纹、来源hash及原CSV十进制结果。最终13个夹具Worker各一次claim/fence1，10成功+3预期非数值失败，心跳身份/时段匹配；0Attempt/Reservation，页面0POST/Worker。未打开或重算物理DB。

148冻结输入/副本/当前源一致；958217B wheel SHA c3ea694281e2c68791da89bfb8f96632c16f26db4d6216218bb71539cba78195 的141包文件同源/安装，94模块来自安装包。对旧包仅use.js变化，112个Python文件不变。作者清单df70350e20e5559ac8c4b24a9d3098a651322454e332d6e40687aac32c34ed1b：508项/{am['payload_bytes']}B；500非DB/{am['non_db_bytes_hashed']}B逐SHA，8fixture DB仅stat，4链接逐目标核对。另核两封存元数据，不计current别名为新测试。

探索史：首轮2FAIL为switch回执字段夹具错误；第二轮2FAIL为driver词法TDZ且0页面检查；第三轮1PASS仅源码smoke；最终安装包3PASS。合计8次保存pytest执行/4P4F、最终3unique，失败不改签。作者3次纯文件观察器错误与独审路径/139对141/JSON行类型/cache/null body/预估字节错误均保留，修正仅纯文件审计，未新增产品运行。

限制：合成Linux/JSDOM/Node Blob捕获+实际loopback；非原生文件保存，不保证电子表格自动类型推断精度。未新跑完整账号/项目/实例/重连矩阵、冷进程恢复、指数positive或穷尽Unicode边界。Windows/PG/远端CI/真实模型语义/真人验收/正式发布未验；固定setuptools82.0.1构建未跑（作者现有84离线构建）。不背书后续归档、提交、远端；旧满盘独审未恢复。最终交付文档范围与原件相符。

证据：[机器终验](final-verification.json)、[原件计算](qualified-raw-verification.json)、[源及wheel桥](qualified-freeze-verification.json)、[作者清单](author-manifest-verification.json)、[观察器更正](observer-corrections.json)。早期pending标志为当时状态，由此最终闭合取代。封存后停止写入本独审目录。
'''
(R/'final-independent-review.md').write_text(report,encoding='utf-8')
files={};links={}
for p in sorted(R.rglob('*')):
    if p.name=='sealed-manifest.json':continue
    rel=p.relative_to(R).as_posix()
    if p.is_symlink():
        target=os.readlink(p);links[rel]={'target':target,'target_sha256':hashlib.sha256(os.fsencode(target)).hexdigest()}
    elif p.is_file():files[rel]=h(p)
m={'status':'SEALED','files':files,'symlinks':links,'file_count':len(files),'raw_bytes':sum(q['bytes'] for q in files.values()),'bounds':'Includes all current review regular files except this manifest; all reviewer writes stop after seal.'}
put('sealed-manifest.json',m)
seal=R/'sealed-manifest.json';out={'verdict':v['verdict'],'report':{'path':str(R/'final-independent-review.md'),**h(R/'final-independent-review.md')},'verification':{'path':str(R/'final-verification.json'),**h(R/'final-verification.json')},'manifest':{'path':str(seal),**h(seal)},'payload_regular_files':len(files),'payload_raw_bytes':m['raw_bytes'],'symlinks':len(links),'writes_stopped':True}
for p in R.rglob('*'):
    if p.is_file() and not p.is_symlink():p.chmod(0o444)
for p in sorted((p for p in R.rglob('*') if p.is_dir() and not p.is_symlink()),reverse=True):p.chmod(0o555)
R.chmod(0o555)
print(json.dumps(out,ensure_ascii=False,indent=2))
