from pathlib import Path
import json,hashlib,os,stat
R=Path('/workspace/f2-display-contract-audit-20261019');O=Path('/workspace/f2-chart-contract-review-20261018')
def sha(b): return hashlib.sha256(b).hexdigest()
p=R/'MANIFEST.sha256.json';raw=p.read_bytes();m=json.loads(raw)
assert sha(raw)=='df70350e20e5559ac8c4b24a9d3098a651322454e332d6e40687aac32c34ed1b'
assert len(m['files'])==508 and sum(q['bytes'] for q in m['files'].values())==31564670 and len(m['symlinks'])==4
files=[];databases=[]
for name,v in m['files'].items():
    path=R/name; s=path.lstat();assert stat.S_ISREG(s.st_mode) and s.st_size==v['bytes']
    if name.endswith(('.db','.sqlite','.sqlite3','.db-journal','.db-wal','.db-shm')):
        databases.append({'path':name,'bytes':s.st_size,'method':'stat_only_no_content_or_hash'});continue
    assert sha(path.read_bytes())==v['sha256'];files.append({'path':name,**v})
assert len(databases)==8
for name,target in m['symlinks'].items():
    path=R/name;assert path.is_symlink() and os.readlink(path)==target and Path(target).is_relative_to(R)
actual_files=set();actual_links={}
for folder,dirs,names in os.walk(R,followlinks=False):
    for name in dirs+names:
        p=Path(folder)/name;rel=p.relative_to(R).as_posix()
        if p.is_symlink(): actual_links[rel]=os.readlink(p)
        elif p.is_file(): actual_files.add(rel)
assert actual_files==set(m['files'])|{'MANIFEST.sha256.json','SEAL.json'}
assert actual_links==m['symlinks']
seal_raw=(R/'SEAL.json').read_bytes();seal=json.loads(seal_raw)
assert seal['status']=='SEALED' and seal['manifest_sha256']==sha(raw) and seal['files']==508 and seal['file_bytes']==31564670 and seal['symlinks']==4
out={'verdict':'AUTHOR_NON_DB_BYTE_MANIFEST_AND_LINKS_VERIFIED','author':str(R),'manifest':{'path':p.name,'bytes':len(raw),'sha256':sha(raw)},'seal':{'path':'SEAL.json','bytes':len(seal_raw),'sha256':sha(seal_raw)},'payload_regular_files':508,'payload_bytes':31564670,'non_db_files_hashed':len(files),'non_db_bytes_hashed':sum(q['bytes'] for q in files),'database_files_stat_only':databases,'symlinks':actual_links,'physical_tree_exact_except_two_closing_metadata_files':True,'non_db_verified_files':files,'scope':'No database content or hash recomputation; no symlink traversal; no product/pytest/network/Git execution.'}
(O/'author-manifest-verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='non_db_verified_files'},ensure_ascii=False,indent=2))
