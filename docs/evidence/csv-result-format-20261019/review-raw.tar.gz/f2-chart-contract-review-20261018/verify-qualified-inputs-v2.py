from pathlib import Path
import hashlib,json,zipfile
R=Path('/workspace/f2-display-contract-audit-20261019')
S=Path('/workspace/Sim2Act')
O=Path('/workspace/f2-chart-contract-review-20261018')
def fp(p):
    b=p.read_bytes(); return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
f=json.loads((R/'source-freeze-qualified.json').read_text())
assert len(f)==148 and all(isinstance(k,str) and set(v)=={'bytes','sha256'} for k,v in f.items())
assert all(fp(S/k)==v for k,v in f.items())
assert all(fp(R/'qualified-inputs'/k)==v for k,v in f.items())
pkg={k[4:]:v for k,v in f.items() if k.startswith('src/sim2act/')}
assert len(pkg)==141
wheel=R/'wheel/sim2act-0.1.0-py3-none-any.whl'
wf=fp(wheel)
assert wf=={'bytes':958217,'sha256':'c3ea694281e2c68791da89bfb8f96632c16f26db4d6216218bb71539cba78195'}
with zipfile.ZipFile(wheel) as z:
    names=[n for n in z.namelist() if n.startswith('sim2act/') and not n.endswith('/')]
    assert len(names)==len(set(names))==141 and set(names)==set(pkg)
    for k in names:
        b=z.read(k); assert {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}==pkg[k]
assert all(fp(R/'installed-package'/k)==v for k,v in pkg.items())
wv=json.loads((R/'wheel-verification.json').read_text())
assert {q['path']:{k:q[k] for k in ('bytes','sha256')} for q in wv['files']}==pkg
base=Path('/workspace/private-record-preview-final-20261018/source-freeze-qualified.json')
prior=json.loads(base.read_text())
prior_pkg={k[4:]:v for k,v in prior.items() if k.startswith('src/sim2act/')}
assert set(prior_pkg)<=set(pkg)
prior_wheel=base.parent/'wheel/sim2act-0.1.0-py3-none-any.whl'
assert fp(prior_wheel)=={'bytes':957688,'sha256':'993d022e17d445f76c8277f8fb65f92a00e1595b58323e8dbff9db708691facc'}
with zipfile.ZipFile(prior_wheel) as z:
    prior_names=[n for n in z.namelist() if n.startswith('sim2act/') and not n.endswith('/')]
    assert len(prior_names)==len(set(prior_names))==141 and set(prior_names)==set(pkg)
    prior_all={k:{'bytes':len(z.read(k)),'sha256':hashlib.sha256(z.read(k)).hexdigest()} for k in prior_names}
assert all(prior_all[k]==v for k,v in prior_pkg.items())
changed=[k for k in pkg if prior_all[k]!=pkg[k]]
assert changed==['sim2act/web/use.js'],changed
py=[k for k in pkg if k.endswith('.py')]
assert all(prior_all[k]==pkg[k] for k in py)
value=(R/'installed-package/sim2act/web/use.js').read_text()
assert 'if(!decimal||decimal[0]!==r.sum)' in value
assert 'JSON.stringify(value,null,2)+"\\n"' in value
out={'verdict':'PURE_FILE_FREEZE_WHEEL_BRIDGE_PASS_RUNTIME_QUALIFICATION_PENDING','execution':'stdlib hashing, JSON, zip reads only; no product import/test/DB/Git/network','frozen_inputs':148,'package_files':141,'current_and_qualified_copies_equal':True,'wheel':wf,'source_wheel_installed_equal':True,'baseline_manifest':str(base),'baseline_manifest_sha256':fp(base)['sha256'],'baseline_manifest_package_files':len(prior_pkg),'baseline_wheel':{'path':str(prior_wheel),**fp(prior_wheel)},'baseline_wheel_only_package_files':sorted(set(pkg)-set(prior_pkg)),'package_changed_vs_previous_private_preview':changed,'python_package_files':len(py),'all_python_package_files_unchanged':True,'format_sum_fix_present':True,'original_json_serialization_expression_retained':True,'active_qualification_logs_results_and_databases_read':False,'no_runtime_pass_claimed':True}
(O/'qualified-freeze-verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(out,ensure_ascii=False))
