"""Assert final qualification imports the installed wheel, not source."""
import json
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
target = root / 'installed-package'
sys.path.insert(0, str(target))
import sim2act
assert Path(sim2act.__file__).is_relative_to(target)
print('INSTALLED_PACKAGE', sim2act.__file__, flush=True)
import pytest
code = pytest.main(sys.argv[1:])
modules = {name: module.__file__ for name, module in sys.modules.items()
           if name.startswith('sim2act') and getattr(module, '__file__', None)}
assert all(Path(path).is_relative_to(target) for path in modules.values())
(root / 'guard-final-installed-modules.json').write_text(json.dumps({'exit_code': code, 'modules': modules}, indent=2) + '\n')
raise SystemExit(code)
