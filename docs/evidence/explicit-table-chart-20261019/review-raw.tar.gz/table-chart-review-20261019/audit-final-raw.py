from pathlib import Path
from html.parser import HTMLParser
import hashlib,json,math,collections,xml.etree.ElementTree as ET
A=Path('/workspace/table-chart-audit-20261019');R=Path('/workspace/table-chart-review-20261019')
def j(path):return json.loads(path.read_text())
def sha(data):return hashlib.sha256(data).hexdigest()
def fp(v):return sha(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode())
def rows(table):return [v if isinstance(v,dict) else json.loads(v) for v in table]
class SVGSnapshot(HTMLParser):
    def __init__(self):super().__init__(convert_charrefs=True);self.nodes=[];self.stack=[]
    def handle_starttag(self,tag,attrs):
        assert tag in {'svg','line','text','rect','title'} and len(attrs)==len(dict(attrs))
        assert all(not k.startswith('on') and k not in ['href','src'] for k,v in attrs)
        node={'tag':tag,'attrs':dict(attrs),'text':''};self.nodes.append(node);self.stack.append(node)
    def handle_endtag(self,tag):assert self.stack and self.stack.pop()['tag']==tag
    def handle_data(self,data):
        for node in self.stack:node['text']+=data
    def take(self,tag):return [n for n in self.nodes if n['tag']==tag]
qualified=[('display','qualified-installed/test_explicit_table_chart_actu0'),('guards','guard-final/test_explicit_table_chart_actu0')]
results=[];charts=[];response_hashes=[];worker_count=mock_count=0
freeze=j(A/'source-freeze-guard-final.json')
for case,rel in qualified:
    d=A/rel;p=j(d/'results.json');i=j(d/'info.json');b=j(d/'before-page.json');after=j(d/'after-page-or-failure.json')
    assert p['status']=='PASS' and p['case']==case and len(b)==len(after)==55 and b.keys()==after.keys()
    db={name:rows(value) for name,value in b.items()};changed=[name for name in b if b[name]!=after[name]]
    grant_delta=[]
    if case=='display':assert not changed
    else:
        assert changed==['grants'];old={v['id']:v for v in db['grants']};new={v['id']:v for v in rows(after['grants'])};assert old.keys()==new.keys()
        ids=[name for name in old if old[name]!=new[name]];assert len(ids)==1
        a,z=old[ids[0]],new[ids[0]];assert {name for name in a if a[name]!=z[name]}=={'revoked','revision'} and a['revoked'] is False and z['revoked'] is True and z['revision']==a['revision']+1 and a['tool_ref']=='resource.read'
        grant_delta=[{'id':a['id'],'principal_id':a['principal_id'],'resource_id':a['resource_id'],'revision':[a['revision'],z['revision']],'revoked':[False,True]}]
    cores={q['id']:q for q in db['runs']};appruns={q['id']:q for q in db['internal_app_runs']};releases={q['id']:q for q in db['internal_releases']}
    inst=next(q for q in db['internal_instances'] if q['id']==i['instance']);assert inst['release_id']==i['current_release'] and inst['source_app_id']==i['app'] and inst['project_id']==i['project']
    for release in releases.values():
        assert release['fingerprint']==fp(release['snapshot']) and release['principal_id']==inst['principal_id'] and release['project_id']==i['project']
        draft=release['snapshot']['draft'];assert draft['id']==i['app'] and draft['runtime_id']==inst['runtime_id'] and draft['fingerprint']==fp(draft['candidate'])
    for output in i['outputs']:
        assert output['status']==cores[output['id']]['status']=='SUCCEEDED'
        app=appruns[output['app_run_id']];assert output['instance_id']==app['instance_id']==i['instance'] and output['result_version']==app['result_version'] and output['result']==app['output']
        typed=[q for q in db['internal_instance_data'] if q['run_id']==output['app_run_id']];assert len(typed)==1 and output['known_effects']==typed
        record=typed[0];assert record['instance_id']==i['instance'] and record['release_id']==output['release_id'] and record['version']==output['result_version'] and record['data']['result']==output['result'] and record['fingerprint']==fp(record['data'])
        resource=next(q for q in db['resources'] if q['id']==output['result']['resource_id']);assert resource['hash']==output['result']['source_hash']==sha(resource['content'].encode())
        cites=[{'start_line':n,'end_line':n,'quote':text} for n,text in enumerate(resource['content'].splitlines(),1) if output['result']['term'] in text];assert cites==output['result']['citations']
    workers=j(d/'workers.json');claims=j(d/'claims.json');beats={v['id']:v['at'] for v in db['heartbeats']}
    assert len(workers)==len(claims)==4 and len({v['worker_id'] for v in workers})==4
    for worker,claim in zip(workers,claims):
        assert worker['worker_id']==claim['worker_id'] and worker['claimed'] is True and cores[claim['run_id']]['worker_id']==worker['worker_id'] and cores[claim['run_id']]['fence']==claim['fence']==1
        assert worker['started']<=beats[worker['worker_id']]<=worker['finished']
        assert len([v for v in db['events'] if v['kind']=='CLAIMED' and v['run_id']==claim['run_id']])==1
    assert len(j(d/'mock-generation-requests.json'))==2;worker_count+=4;mock_count+=2
    for asset in p['assets']:
        f=freeze['src/sim2act/web/'+asset['name']];assert asset['status']==200 and sha(asset['text'].encode())==asset['sha256']==i['web_hashes'][asset['name']]==f['sha256']
    assert len(p['assets'])==p['boots']*27 and not p['pageErrors']
    statuses=collections.Counter();controlled=0
    for n,q in enumerate(p['requests']):
        assert q['method']=='GET' and q['body'] is None and q['headers']['cache-control']=='no-store' and q['finished']>=q['started']
        body=json.loads(q['actual_response_text']);statuses[q['actual_status']]+=1
        if '/runs/' in q['path']:assert q.get('cache')=='no-store'
        if q.get('synthetic_delivery'):assert q['actual_response_text']!=q['delivered_response_text'];controlled+=1
        else:assert q['actual_response_text']==q['delivered_response_text']
        if q['actual_status']==400:assert q['path'].endswith('/protocol/contracts') and body['error']['code']=='RESOURCE_UNAVAILABLE'
        if q['actual_status']==403:assert case=='guards' and body['error']['code']=='GRANT_REVOKED'
        response_hashes.append({'case':case,'index':n,'path':q['path'],'actual_status':q['actual_status'],'actual_sha256':sha(q['actual_response_text'].encode()),'delivered_sha256':sha(q['delivered_response_text'].encode()),'synthetic_delivery':q.get('synthetic_delivery')})
    assert controlled==(2 if case=='guards' else 0)
    for chart in p['charts']:
        file=d/chart['file'];data=file.read_bytes();assert sha(data)==chart['sha256'];parser=SVGSnapshot();parser.feed(data.decode());parser.close();assert not parser.stack
        output=next(v for v in i['outputs'] if v['id']==chart['run_id']);cites=output['result']['citations'];values=[v[chart['series']] for v in cites]
        assert chart['release_id']==output['release_id'] and chart['result_version']==output['result_version'] and chart['field']=='citations' and chart['category']=='quote' and chart['values']==values and chart['unit']=='UNSPECIFIED'
        assert all(str(v) in chart['caption'] for v in [output['id'],output['release_id'],chart['result_version'],chart['series']]) and '单位：未指定' in chart['caption']
        minimum=min(0,*values);maximum=max(0,*values);span=maximum-minimum or 1;zero=200+(0-minimum)/span*420
        root=parser.take('svg');bars=parser.take('rect');axis=parser.take('line');texts=parser.take('text');titles=parser.take('title');assert len(root)==len(axis)==1 and len(bars)==len(titles)==len(values)
        assert root[0]['attrs']['viewbox']==f'0 0 660 {len(values)*38+48}' and float(axis[0]['attrs']['x1'])==float(axis[0]['attrs']['x2'])==zero
        for n,(bar,value,cite) in enumerate(zip(bars,values,cites)):
            attrs=bar['attrs'];x=200+(value-minimum)/span*420
            assert attrs['data-row']==str(n+1) and attrs['data-value']==str(value)
            assert math.isclose(float(attrs['x']),min(x,zero),abs_tol=1e-9) and math.isclose(float(attrs['width']),abs(x-zero),abs_tol=1e-9) and float(attrs['y'])==12+n*38 and float(attrs['height'])==16
            expected=f"第{n+1}行 · quote: {cite['quote']} · {chart['series']}: {value} · 单位未指定";assert attrs['aria-label']==titles[n]['text']==expected
            label=f"{n+1}. {cite['quote'][:24]}"+('…' if len(cite['quote'])>24 else '')
            assert texts[2+2*n]['text']==label and texts[3+2*n]['text']==str(value)
        charts.append({'case':case,'path':str(file.relative_to(A)),'bytes':len(data),'sha256':sha(data),'run_id':output['id'],'release_id':output['release_id'],'result_version':output['result_version'],'series':chart['series'],'values':values,'unit':'UNSPECIFIED','format':'JSDOM SVG element outerHTML snapshot parsed as HTML, not standalone XML SVG export'})
    if case=='guards':
        assert j(d/'shutdown.json')=={'server_thread_alive':False}
        journal=[json.loads(line) for line in (d/'page-journal.jsonl').read_text().splitlines()];counts=collections.Counter(v['kind'] for v in journal)
        assert counts=={'asset':27,'actual_HTTP':41,'delivered_HTTP':41,'assertion':40,'fixture_revoke_HTTP':1}
        assert [v['label'] for v in journal if v['kind']=='assertion']==p['checks']
        for q in p['requests']:
            for kind,key in [('actual_HTTP','actual_response_text'),('delivered_HTTP','delivered_response_text')]:
                item=[v['request'] for v in journal if v['kind']==kind and v['request']['started']==q['started']];assert len(item)==1 and item[0][key]==q[key]
        revoke=next(v for v in journal if v['kind']=='fixture_revoke_HTTP');assert revoke['status']==200 and revoke['body']=='{}' and json.loads(revoke['response_text'])=={'status':'REVOKED'}
        assert any('/revoke' in q['url'] and q['status']==200 for q in j(d/'fixture-http.json'))
    results.append({'case':case,'path':rel,'checks':len(p['checks']),'page_GET':len(p['requests']),'page_statuses':dict(statuses),'assets':len(p['assets']),'boots':p['boots'],'charts':len(p['charts']),'fixture_ASGI':len(j(d/'fixture-http.json')),'workers':4,'mock_requests':2,'changed_tables':changed,'grant_delta':grant_delta,'helper_probe_classification':p['synthetic_helpers']})
# Existing shared text/table regression: actual ASGI response text hashes and complete snapshots.
d=A/'qualified-installed/test_manifest_text_table_actua0';p=j(d/'page-proof.json');b=j(d/'before-page.json');after=j(d/'after-page-or-failure.json');assert p['status']=='PASS' and len(b)==55 and b==after
actual=j(d/'actual-http.json');assert len(actual)==119 and len(p['requests'])==50 and len(p['assets'])==54
for req in p['requests']:assert req['method']=='GET' and any(q['method']=='GET' and q['path']==req['path'] and q['status']==req['status'] and sha(q['response'].encode())==req['response_sha256'] for q in actual)
for asset in p['assets']:
    name='index.html' if asset['path']=='/' else asset['path'].lstrip('/')
    assert asset['sha256']==freeze['src/sim2act/web/'+name]['sha256'] and any(q['method']=='GET' and q['path']==asset['path'] and q['status']==200 and sha(q['response'].encode())==asset['sha256'] for q in actual)
workers=j(d/'workers.json');claims=j(d/'claims.json');assert len(workers)==len(claims)==4 and all(w['once_result'] is True for w in workers) and all(q['fence']==1 for q in claims)
assert len(j(d/'mock-generation-requests.json'))==2;worker_count+=4;mock_count+=2
regression={'checks':len(p['checks']),'page_GET':50,'assets':54,'boots':p['boots'],'actual_ASGI_all_phases':119,'ASGI_fixture_remainder_after_page_assets':119-50-54,'all55_JSON_equal':True,'fixture_workers':4,'mock_requests':2,'page_statuses':dict(collections.Counter(q['status'] for q in p['requests'])),'scope':p['scope'],'negative_classification':p['negative_classification']}
history=[]
for name in ['qualified-installed.xml','guard-followup.xml','guard-final.xml']:
    tree=ET.parse(A/name).getroot();nodes=[]
    for t in tree.iter('testcase'):nodes.append({'nodeid':t.attrib['classname']+'.'+t.attrib['name'],'seconds':float(t.attrib['time']),'status':'FAIL' if t.find('failure') is not None else 'ERROR' if t.find('error') is not None else 'PASS'})
    history.append({'path':name,'nodes':nodes})
all_nodes=[v for h in history for v in h['nodes']];assert len(all_nodes)==5 and collections.Counter(v['status'] for v in all_nodes)=={'PASS':3,'FAIL':2}
modules={}
for path in [A/'installed-modules.json',A/'guard-final-installed-modules.json']:
    if path.exists():
        data=j(path);assert all(Path(v).is_relative_to(A/'installed-package') for v in data['modules'].values());modules[path.name]={'exit_code':data['exit_code'],'module_count':len(data['modules'])}
out={'verdict':'PURE_FILE_FINAL_TABLE_CHART_QUALIFICATION_PASS','qualified_chart_cases':results,'shared_text_table_regression':regression,'totals':{'latest_unique_nodes':3,'saved_executions':5,'saved_pass':3,'saved_fail':2,'chart_case_checks':sum(v['checks'] for v in results),'all_qualified_check_records':sum(v['checks'] for v in results)+regression['checks'],'actual_bound_chart_snapshots':len(charts),'chart_loopback_page_GET':sum(v['page_GET'] for v in results),'chart_loopback_assets':sum(v['assets'] for v in results),'chart_fixture_ASGI':sum(v['fixture_ASGI'] for v in results),'shared_regression_ASGI_total':119,'qualified_fixture_workers':worker_count,'qualified_synthetic_Mock_requests':mock_count,'qualified_business_NoModel_jobs':9,'qualified_generation_jobs':3,'page_POST':0,'page_Worker':0,'real_model_calls':0},'charts':charts,'chart_http_response_hashes':response_hashes,'junit_history':history,'installed_module_origin':modules,'method':'Pure JSON/hash/HTMLParser/arithmetic/XML reads; no product/pytest/Node/Worker/DB/Git/network execution. Author JSON snapshots independently compared, not physical databases.','limits':['Actual values are citation line coordinates, not inferred business meaning; unit unspecified','SVG files are HTML DOM outerHTML snapshots, not strict XML export or native visual acceptance','Negative/zero/NaN/Infinity/unsafe/tiny-domain and unbound probes are synthetic helper inputs, not produced business results','Start/end_line choices exercised although actual literal citation start and end values coincide','Late series/workspace/instance and realREAD403 exercised; no complete new cross-account/project/reconnect matrix','Cold DOM only, not server/worker restart; no Windows/PG/remoteCI/LIVE/real semantics/human acceptance/formal publication','Initial guard Timeout had fourSVG but missing finallogs; failed followup37checks/fiveSVG is not finalPASS']}
(R/'raw-final-verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'verdict':out['verdict'],'totals':out['totals'],'cases':results,'regression':regression},ensure_ascii=False,indent=2))
