# table-bar.v1 设计有限独审

新增显式、版本化的表格临时展示合同在本次授权内可继续；此前“chart无合同不能猜轴”结论仍适用于未经选择的 Manifest.chart。此片通过用户明确选择已有表列补足展示参数，不修改原结果、不证明坐标具有业务量语义，不新增producer/Action/Grant/API/存储。当前仅设计审查，未实现或运行资格。

代码接入：internal.js:662–670 是完整有限table校验后安全DOM，:678–688持有原record/view/manifest，可附受信chart点击closure。renderManifestViews纯函数自身没有Run/选择范围，不应仅拿缓存result直接绘图。literalResultValue:748–762可复用成功Run/typed/原Release/resultVersion/输出比对，:764–790可复用下载式fresh GET与连接、workspace、instanceGeneration、runGeneration围栏。

点击应同时重新读取原record.release_id，核snapshot/candidate完整hash与principal/project/app/runtime，所选field/schema及原manifest一致，再核原typed data fingerprint和Run/AppRun/version/输出。internalResultManifests:629–649已有这套原Release/typed核查，但复用时不得替换为moving draft/latest Release或批量缓存永久授权。每次crypto await后仍须current。历史结果卡并不天然等于当前选中Run；明确捕获该卡Run，不可从view.rid猜目标。

合同需先明确：

- 两个空选择，未选不能画；类别取现有标量列，series仅一个schema数值列。空、缺字段、null、非数值、非有限或不存在列拒绝。继承原64行/16列/安全整数/有限number及总字符串上限；不能coerce字符串sum或补0。
- 原顺序一行一bar，重复类别不聚合，给原始行序号以区分。label按原字段名和值，用textContent，不把quote/行号改成业务指标。
- 明确负数和全零域、零基线与真实数值文字。max-min可能在两端都有限时溢出；需安全归一或明确拒绝，不能画成空/0。不要新增轴单位推断、插值、重排或统计聚合；没有已有单位声明即标未指定。
- 选择改变立即清旧图、使在途意图失效；同scope/Run共享pending防双击/重绘重复，旧finally只释放自身。每个await和paint前核同account/connection/project/workspace/instance/Run/selection代次及DOM活跃；403复用invalidateInternalContent清正文。不能由晚回调重建private内容。
- 保留原table/raw/JSON与专用family行为。Manifest.chart枚举仍不因本临时模式自动具备轴语义；交付声明只签这个显式用户选择模式，非通用所有家族图表。

最小资格可用已有literal citations表实际Run：用户选quote+start_line，明确单位未指定/引用坐标，实际fresh Run+原Release后显示；同Run换列选择需另点；空/无数值列拒绝、已定义domain数值小反例可明确synthetic；一种真实晚回调/授权403沿现harness即可，不扩大旧故障矩阵。待真正代码和闭合原件再独审，不提前签PASS。

方法：仅普通源码/原方案读取与hash；未执行产品/pytest/Worker/模型/网络/Git/DB，未读私有holdout，未写仓库或任何旧封存根。本新目录未封存。
