from pathlib import Path
import hashlib
import json
import os

review = Path('/workspace/table-chart-review-20261019')
author = Path('/workspace/table-chart-audit-20261019')
repo = Path('/workspace/Sim2Act')

def read_json(path):
    return json.loads(path.read_text())

def fingerprint(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

assert not (review / 'sealed-manifest.json').exists()
seal_audit = read_json(review / 'author-seal-verification.json')
raw_audit = read_json(review / 'raw-final-verification.json')
wheel_audit = read_json(review / 'freeze-wheel-verification.json')
assert seal_audit['verdict'] == 'NON_DB_PAYLOAD_AND_SYMLINK_SEAL_PASS'
assert raw_audit['verdict'] == 'PURE_FILE_FINAL_TABLE_CHART_QUALIFICATION_PASS'
assert raw_audit['totals']['saved_pass'] == 3
assert raw_audit['totals']['saved_fail'] == 2
assert seal_audit['manifest']['path'] == 'MANIFEST.sha256.json'
assert seal_audit['direct_non_DB_hashed_files'] == 918
assert seal_audit['physical_DB_stat_only'] == 5
assert seal_audit['compressed_DB_stat_only'] == 18
for path in review.glob('*.stderr'):
    assert path.stat().st_size == 0, path.name

sources = {}
for relative in ['src/sim2act/web/internal.js', 'src/sim2act/web/app.css',
                 'tests/test_table_chart.py', 'tests/table_chart.cjs']:
    sources[relative] = fingerprint(repo / relative)
for relative in ['src/sim2act/web/internal.js', 'src/sim2act/web/app.css']:
    assert sources[relative] == wheel_audit['source_hashes'][relative]

audit_names = [
    'design-review.md', 'implementation-review-wip.md', 'wip-findings.json',
    'fix-static-review.json', 'freeze-wheel-verification.json',
    'first-batch-review.json', 'followup-static-verification.json',
    'guard-final-static-verification.json', 'raw-final-verification.json',
    'author-seal-verification.json'
]
audits = {name: fingerprint(review / name) for name in audit_names}
docs = {
    relative: fingerprint(repo / relative)
    for relative in ['docs/F2/ExplicitTableChart20261019.md', 'docs/F2/Plan.md']
}
verification = {
    'verdict': 'LIMITED_PASS_EXPLICIT_TABLE_BAR_V1',
    'remaining_confirmed_P1_P2_in_reviewed_slice': [],
    'scope': {
        'contract': 'Explicit user-selected table-bar.v1 for a closed bounded homogeneous table; one numeric series, original row order, zero baseline, unit UNSPECIFIED.',
        'product_changes': ['src/sim2act/web/internal.js', 'src/sim2act/web/app.css'],
        'unchanged_python_package_members': 112,
        'fresh_binding': 'Original Run fresh/no-store GET and historical Release full hash/candidate/typed/content identity validation before rendering; no current-draft substitution.',
        'charts_are_presentational': True,
        'new_producer_executor_Grant_API_DB_changes': False,
        'source_read_hashes_final': sources,
    },
    'author_closure': {
        'manifest': seal_audit['manifest'],
        'seal': seal_audit['seal'],
        'payload_files': 941,
        'declared_payload_bytes': 40683574,
        'direct_non_DB_hashed_files': 918,
        'direct_non_DB_hashed_bytes': 36110365,
        'DB_stat_only': {'physical': 5, 'compressed': 18, 'content_or_digest_recomputed': False},
        'symlink_targets_verified': seal_audit['symlinks'],
        'closure_metadata_additional_to_payload': 2,
        'all_tree_entries_accounted': True,
    },
    'source_installation_bridge': {
        'declared_inputs_each_freeze': 189,
        'direct_hashes_current_and_copy': 183,
        'legacy_compressed_DB_inputs_stat_only': 6,
        'product141_constant_across_all_runs': True,
        'initial_to_followup_changes_only': ['tests/test_table_chart.py', 'tests/table_chart.cjs'],
        'followup_to_final_changes_only': ['tests/table_chart.cjs'],
        'test_changes': 'Guards-only watchdog100 to240, record observations before cleanup, test Uvicorn graceful shutdown5; all Python Assert AST unchanged. Final fixture POST adds JSON header/body{} and response journal, original status200 assertion unchanged.',
        'ordinary_wait_seconds_unchanged': 15,
        'wheel': wheel_audit['wheel'],
        'installed_origin': raw_audit['installed_module_origin'],
        'changed_package_members_vs_prior_wheel': wheel_audit['changed_package_members'],
    },
    'qualification': {
        'junit_history': raw_audit['junit_history'],
        'latest_unique_nodes_PASS': 3,
        'saved_executions': 5,
        'saved_PASS': 3,
        'saved_FAIL': 2,
        'first_batch_two_PASS_not_rerun_after_test_only_fixes': True,
        'totals': raw_audit['totals'],
        'qualified_chart_cases': raw_audit['qualified_chart_cases'],
        'shared_text_table_regression': raw_audit['shared_text_table_regression'],
        'all_five_executions_captured_synthetic_provider_requests': 10,
        'fixture_model_boundary': 'Qualified three fixtures: three Mock generation jobs with six captured requests and nine NoModel business jobs; generation Run PARTIAL, business SUCCEEDED. No zero-Attempt/reservation claim for Mock generation.',
        'HTTP_boundary': 'New chart cases use actual loopback HTTP; shared regression uses actual ASGI/TestClient HTTP. Page requests and assets counted separately; shared119 ASGI includes page50/assets54/fixture15. Optional protocol400 and real source READ403 remain explicit.',
        'table_comparison': 'Independently compared exported full55-table JSON. Display and shared regression all equal. Final guards exactly one known READ Grant revision1 to2 and revokedfalse totrue; all other rows and tables equal. No physical DB opened or rehashed.',
        'figure_verification': 'Nine qualified JSDOM SVG outerHTML snapshots: byte SHA, safe DOM tags/attributes, actual Run citation values, field metadata, zero baseline and final rectangle coordinates independently recomputed with HTMLParser/arithmetic. Not standalone XML export or native-browser visual acceptance.',
        'negative_delivery_classification': 'Wrong typed and historical Release fingerprints are controlled frontend delivery corruptions after actual server200; actual and delivered text retained separately.',
        'late_callback_scope': 'Actual delayed200 after series change, workspace ABA and instance switch refused; explicit new click after workspace return succeeds; actual READ revoke403 clears content.',
    },
    'retained_findings_and_failures': {
        'pre_execution_P2': [
            {'id': 'P2_FINAL_COORDINATE_COLLAPSE', 'status': 'FIXED_BEFORE_FIRST_PRODUCT_RUN', 'evidence': 'wip-findings.json; fix-static-review.json; actual-coordinate guard plus synthetic [1e-20,1] negative'},
            {'id': 'P2_WORKSPACE_RETURN_DEAD_CONTROL', 'status': 'FIXED_BEFORE_FIRST_PRODUCT_RUN', 'evidence': 'wip-findings.json; fix-static-review.json; final guards actual workspace ABA plus new explicit click'},
        ],
        'first_guard_FAIL': '100-second Node watchdog TimeoutExpired then cleanup thread assertion masks primary exception. Four SVG retained; final results/workers/claims/HTTP observations absent. Missing evidence not reconstructed and case not relabelled PASS.',
        'followup_guard_FAIL': '37 checks/five SVG retained. Fixture POST400 missing JSON body did not enter Grant revoke handler. Original outer400 response body NOT_RETAINED; middleware classification is source-contract inference, not invented observed errorcode.',
        'author_observer_error': {'path': 'observer-correction.json', 'detail': 'ElementTree ParseError on HTML outerHTML ARIA attribute. Original script/log retained; HTMLParser correction only, zero product changes or test executions.'},
        'reviewer_readonly_query_error': 'Initial rg named tests/table_chart.cjs before creation, exit2 missing path retained in wip-findings.json; not a product/test failure.',
        'reviewer_pure_file_audit_errors': [],
    },
    'documents': {'reviewed_hashes': docs, 'verdict': 'NO_MATERIAL_SCOPE_OR_EVIDENCE_OVERSTATEMENT_FOUND', 'later_packaging_commit_push_not_endorsed': True},
    'limits': raw_audit['limits'] + [
        'Only the finite explicit table-bar contract is qualified, not arbitrary charts, inferred units, new series producers or the whole F2.',
        'Known subset values are actual citation start/end line coordinates; both chosen series have coincident values in these actual literal rows. Signed/zero/nonfinite/unsafe/tiny-domain probes are synthetic display inputs.',
        'Existing setuptools84 offline wheel; pinned82.0.1 build NOT_RUN.',
        'Human PENDING; real semantic UNKNOWN; no LIVE/source admission or publication acceptance.',
        'Author archive, later Git commit and any future push not independently reviewed or approved.',
    ],
    'supporting_audits': audits,
    'reviewer_execution': {'method': 'Pure source/AST/JSON/hash/zip/HTMLParser/arithmetic/JUnit-XML reads only', 'product_tests_Node_Worker_DB_Git_network_model': 0, 'private_holdout_read': False, 'author_repo_older_sealed_roots_written': False},
}
(review / 'final-verification.json').write_text(json.dumps(verification, ensure_ascii=False, indent=2) + '\n')
report = '''# 显式表格条形图 v1：有限独立审查

**LIMITED_PASS_EXPLICIT_TABLE_BAR_V1。** 在本片源码、安装包及已关闭原件范围内，未发现剩余确定 P1/P2。此前两项 P2（最终坐标舍入归零、工作区返回后按钮失效）均在第一次产品执行前修复；WIP 发现及修复记录保留。

本结论覆盖已有封闭有界表格，由用户明确选择原类别列和单一数值系列，重新鉴权同 Run 与其历史 Release 后展示 `table-bar.v1`。原顺序、原值、零基线及单位“未指定”保持；不推断语义、补值、聚合或创建业务 Run。安全 DOM、最终坐标拒绝门、原 Release/typed/内容指纹、迟到回调和真实撤权403清理均已核。两生产文件相对旧包变化，112个 Python 文件不变，无新增 producer/executor/Grant/API/表。

原始 JUnit 保存 **5次执行：3PASS、2FAIL；3个唯一节点最新均PASS**。首批 display142.862秒、共享 text/table253.198秒通过；guards191.934秒因100秒驱动watchdog后收尾异常失败，缺失最终日志不补造。其续验164.821秒失败保留（37检查/5图，测试撤权POST漏JSON正文，原400正文未保存）；最后仅补该请求正文/响应日志，guards219.284秒通过。测试记录/收尾和有界watchdog修改未删业务断言，首批两个PASS未重跑，不称单批全绿。

通过节点共有118条检查记录（32+40+46），并非118个测试；9份已绑定图形快照（4+5）。新图表两场景85次loopback页面GET、81份资产；共享回归119条ASGI记录已包含50页面GET、54资产与15夹具请求。可选protocol400及实际READ403明确保留。通过夹具12个捕获Worker各单claim/fence1：3个Mock生成任务、9个NoModel业务任务，6份合成模型请求；全部5次保存执行共10份合成请求。页面POST/Worker和真实模型均0，不误称生成阶段无Attempt/Reservation。

独立对比完整55表JSON：display与共享回归全等；最终guards仅指定一个READ Grant由revision1→2、revoked false→true，其余54表及其他Grant完全一致。已重算实际citation值、图形坐标/文本、HTTP原文SHA、历史Run/Release/typed绑定、资产与安装来源。负数/全零/非法数值为明确合成展示输入；错指纹为真实200后的受控前端污染，不冒服务端拒绝。`.svg`是JSDOM的outerHTML快照，以HTMLParser核验，**不是独立XML导出或原生视觉验收**。

作者封存941项/40,683,574字节中，918个非DB原件/36,110,365字节逐SHA核验，23个DB路径（5物理、18压缩副本）仅stat，4链接核字面目标；未打开或重算DB。作者清单完整SHA为 `ce00537bc3c7a5bbaa737d29e6c1a57cd4c603b8203decbd42823c4c995c5561`。189输入中183项直接hash、6旧压缩DB仅stat；141包文件与源/安装一致，wheel960382字节，SHA `bdd222e96b37be35c33a309c86f4bd33aec4505a628775d9eb89327e1a9ef3fe`。最终文档/Plan未见实质夸大。

作者XML观察器错误及HTMLParser更正均保留，非产品失败或新测试；本独审初始缺文件rg查询也保留。本人仅纯文件复算，未执行产品、测试、Node、Worker、DB、Git、网络或模型，未读私有留出集。依据见 [机器结论](final-verification.json)、[原件复算](raw-final-verification.json)、[封存核验](author-seal-verification.json)及既存静态报告。

本结论不提升任意chart、跨账号/项目/重连完整矩阵、服务器冷启、Windows/PG/原生浏览器/CI/LIVE/语义/真人验收/正式发布资格；人工PENDING、真实语义UNKNOWN。原旧缺失审查不恢复。后续归档、Git提交与推送由作者另证，本报告不预先背书。
'''
(review / 'final-independent-review.md').write_text(report)

payload = {}
links = {}
for base, dirs, names in os.walk(review, followlinks=False):
    base_path = Path(base)
    for name in list(dirs):
        path = base_path / name
        if path.is_symlink():
            target = os.readlink(path)
            links[str(path.relative_to(review))] = {'target': target, 'sha256': hashlib.sha256(os.fsencode(target)).hexdigest()}
            dirs.remove(name)
    for name in names:
        path = base_path / name
        rel = str(path.relative_to(review))
        if rel == 'sealed-manifest.json':
            continue
        if path.is_symlink():
            target = os.readlink(path)
            links[rel] = {'target': target, 'sha256': hashlib.sha256(os.fsencode(target)).hexdigest()}
        else:
            payload[rel] = fingerprint(path)
manifest = {
    'status': 'SEALED',
    'scope': 'Independent readonly explicit table-bar.v1 review; this manifest excludes itself; no subsequent writes.',
    'files': dict(sorted(payload.items())),
    'symlinks': dict(sorted(links.items())),
    'file_count': len(payload),
    'raw_bytes': sum(entry['bytes'] for entry in payload.values()),
}
manifest_path = review / 'sealed-manifest.json'
manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
result = {
    'verdict': verification['verdict'],
    'remaining_confirmed_P1_P2': [],
    'manifest_path': str(manifest_path),
    'manifest': fingerprint(manifest_path),
    'payload_files': manifest['file_count'],
    'payload_raw_bytes': manifest['raw_bytes'],
    'symlinks': len(links),
    'report': fingerprint(review / 'final-independent-review.md'),
    'verification': fingerprint(review / 'final-verification.json'),
    'writes_stopped_after_this_seal': True,
}
for path in review.rglob('*'):
    if not path.is_symlink() and path.is_file():
        path.chmod(0o444)
for path in sorted([p for p in review.rglob('*') if p.is_dir() and not p.is_symlink()], key=lambda p: len(p.parts), reverse=True):
    path.chmod(0o555)
review.chmod(0o555)
print(json.dumps(result, ensure_ascii=False, indent=2))
