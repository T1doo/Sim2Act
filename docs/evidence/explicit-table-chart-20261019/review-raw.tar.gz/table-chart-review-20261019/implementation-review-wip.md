# WIP 实现有限独审

新显式table-bar.v1接线与安全DOM方向正确；fresh Run→原Release完整hash/typed绑定及旧family保留。目前两个需修P2已即时发root：最终SVG坐标加left后非零被舍为0，以及组件创建时永久workspace围栏导致正常tab往返后按钮静默失效。

精确用户路径、代码位置、独立binary64算例及最小修复见wip-findings.json。它们是源码静审/纯算术说明，非实际HTTP复现。wip-chart-helper-observation.js保存本次读取的当前WIP helper，非未来冻结或资格副本。待root修复后静审，不要求新增完整故障矩阵。

未执行产品、测试、模型、Worker、DB、Git或网络；未写仓库/旧封存目录。本新reviewdir未seal。
