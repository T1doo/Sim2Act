from pathlib import Path
import hashlib,json,os,stat
A=Path('/workspace/table-chart-audit-20261019');R=Path('/workspace/table-chart-review-20261019')
def fp(path):
 b=path.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
manifest_path=A/'MANIFEST.sha256.json';manifest_record=fp(manifest_path);assert manifest_record['sha256']=='ce00537bc3c7a5bbaa737d29e6c1a57cd4c603b8203decbd42823c4c995c5561'
m=json.loads(manifest_path.read_text());assert len(m['files'])==941 and sum(v['bytes'] for v in m['files'].values())==40683574 and len(m['symlinks'])==4
hashed=[];db=[]
for name,record in m['files'].items():
 item=A/name;metadata=item.lstat();assert stat.S_ISREG(metadata.st_mode) and metadata.st_size==record['bytes']
 if name.endswith(('.db','.db.gz','.sqlite','.sqlite3','.db-journal','.db-wal','.db-shm')):
  db.append({'path':name,'bytes':metadata.st_size,'method':'stat only; physical/compressed DB bytes not read or hashed'});continue
 assert fp(item)==record;hashed.append(name)
assert len(db)==23 and len(hashed)==918
for name,target in m['symlinks'].items():assert (A/name).is_symlink() and os.readlink(A/name)==target and Path(target).is_relative_to(A)
found_files=set();found_links={}
for folder,dirs,names in os.walk(A,followlinks=False):
 for name in dirs+names:
  item=Path(folder)/name;rel=item.relative_to(A).as_posix()
  if item.is_symlink():found_links[rel]=os.readlink(item)
  elif item.is_file():found_files.add(rel)
assert found_files==set(m['files'])|{'MANIFEST.sha256.json','SEAL.json'} and found_links==m['symlinks']
seal_path=A/'SEAL.json';seal=json.loads(seal_path.read_text());assert seal['status']=='SEALED' and seal['manifest_sha256']==manifest_record['sha256'] and seal['files']==941 and seal['file_bytes']==40683574 and seal['symlinks']==4
out={'verdict':'NON_DB_PAYLOAD_AND_SYMLINK_SEAL_PASS','manifest':{'path':manifest_path.name,'absolute_path':str(manifest_path),**manifest_record},'seal':{'path':seal_path.name,**fp(seal_path)},'payload_files':941,'payload_bytes':40683574,'direct_non_DB_hashed_files':len(hashed),'direct_non_DB_hashed_bytes':sum(m['files'][n]['bytes'] for n in hashed),'physical_DB_stat_only':sum(not q['path'].endswith('.gz') for q in db),'compressed_DB_stat_only':sum(q['path'].endswith('.gz') for q in db),'DB_path_items':db,'symlinks':found_links,'closing_metadata_files_additional_to_payload':2,'all_real_tree_entries_accounted':True,'no_author_repo_or_earlier_sealed_directory_writes':True,'reviewer_product_test_DB_Git_network_executions':0}
(R/'author-seal-verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='DB_path_items'},ensure_ascii=False,indent=2))
