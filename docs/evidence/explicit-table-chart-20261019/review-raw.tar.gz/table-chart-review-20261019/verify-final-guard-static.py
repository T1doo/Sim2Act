from pathlib import Path
import hashlib,json,xml.etree.ElementTree as ET
A=Path('/workspace/table-chart-audit-20261019');R=Path('/workspace/table-chart-review-20261019');S=Path('/workspace/Sim2Act')
def fp(path):
 b=path.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
old=json.loads((A/'source-freeze-guard-followup.json').read_text());new=json.loads((A/'source-freeze-guard-final.json').read_text());assert old.keys()==new.keys() and len(new)==189
assert [n for n in new if old[n]!=new[n]]==['tests/table_chart.cjs']
for name,entry in new.items():
 if name.endswith(('.db','.db.gz','.sqlite','.sqlite3')):assert (S/name).stat().st_size==(A/'guard-final-inputs'/name).stat().st_size==entry['bytes']
 else: assert fp(S/name)==fp(A/'guard-final-inputs'/name)==entry
oldjs=(A/'guard-followup-inputs/tests/table_chart.cjs').read_text();newjs=(S/'tests/table_chart.cjs').read_text()
oldpart="const response=await fetch(info.base+'/test-only-chart-revoke',{method:'POST',headers:{Authorization:'Bearer synthetic-test-A'}});assert.equal(response.status,200);"
newpart="const response=await fetch(info.base+'/test-only-chart-revoke',{method:'POST',headers:{Authorization:'Bearer synthetic-test-A','Content-Type':'application/json'},body:'{}'});\n   journal({kind:'fixture_revoke_HTTP',method:'POST',status:response.status,response_text:await response.text(),body:'{}'});assert.equal(response.status,200);"
assert oldpart in oldjs and newpart in newjs and newjs.replace(newpart,oldpart)==oldjs
closed=A/'guard-followup/test_explicit_table_chart_actu0';result=json.loads((closed/'results.json').read_text())
assert result['status']=='FAIL' and len(result['checks'])==37 and len(result['charts'])==5 and '400 !== 200' in result['error']
assert json.loads((closed/'before-page.json').read_text())==json.loads((closed/'after-page-or-failure.json').read_text())
assert json.loads((closed/'shutdown.json').read_text())=={'server_thread_alive':False}
assert not any('/revoke' in q['url'] for q in json.loads((closed/'fixture-http.json').read_text()))
xml=ET.parse(A/'guard-followup.xml').getroot();nodes=list(xml.iter('testcase'));assert len(nodes)==1 and nodes[0].find('failure') is not None
out={'verdict':'STATIC_FIXTURE_JSON_BODY_FIX_ACCEPTABLE_RUNTIME_PENDING','changed_input':['tests/table_chart.cjs'],'all_product141_unchanged':True,'direct_frozen_input_hashes':183,'old_compressed_DB_stat_only':6,'CJS_exact_change':'The single fixture POST now sends application/json {} and persists its response; original status200 assertion unchanged; all other bytes restored by removing only this replacement.','product_contract':'api.py180–184 parses every POST/PUT/PATCH body with strict_json before handler; no production/API permission changes.','closed_followup':{'junit_seconds':float(nodes[0].attrib['time']),'status':'FAIL','checks':37,'svg_files':5,'page_gets':len(result['requests']),'assets':len(result['assets']),'all55_snapshot_JSON_equal':True,'server_thread_alive':False,'fixture_grant_revoke_calls':0,'actual_fixture_POST_status':400,'actual_fixture_response_body':'NOT_RETAINED; no body/errorcode reconstructed','middleware_cause':'Source-contract inference consistent with empty original POST and no handler trace, not an observed response body.'},'final_guard_logs_results_and_DB_not_read':True,'reviewer_product_test_DB_Git_network_execution':0,'review_not_sealed':True}
(R/'guard-final-static-verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False))
