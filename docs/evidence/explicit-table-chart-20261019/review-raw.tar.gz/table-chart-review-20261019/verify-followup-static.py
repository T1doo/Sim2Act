from pathlib import Path
import json,hashlib,ast,difflib
A=Path('/workspace/table-chart-audit-20261019');R=Path('/workspace/table-chart-review-20261019');S=Path('/workspace/Sim2Act')
def fp(path):
 b=path.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
old=json.loads((A/'source-freeze-qualified.json').read_text());new=json.loads((A/'source-freeze-guard-followup.json').read_text())
assert old.keys()==new.keys() and len(new)==189
changed=sorted(k for k in old if old[k]!=new[k]);assert changed==['tests/table_chart.cjs','tests/test_table_chart.py']
stat_only=[]
for name,record in new.items():
 if name.endswith(('.db','.db.gz','.sqlite','.sqlite3')):
  assert (S/name).stat().st_size==(A/'guard-followup-inputs'/name).stat().st_size==record['bytes'];stat_only.append(name)
 else: assert fp(S/name)==fp(A/'guard-followup-inputs'/name)==record
old_py=(A/'qualified-inputs/tests/test_table_chart.py').read_text();new_py=(S/'tests/test_table_chart.py').read_text()
def assertions(text):
 return [(ast.dump(n.test,include_attributes=False),ast.dump(n.msg,include_attributes=False) if n.msg else None) for n in sorted((n for n in ast.walk(ast.parse(text)) if isinstance(n,ast.Assert)),key=lambda x:x.lineno)]
assert assertions(old_py)==assertions(new_py)
old_funcs={n.name:ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(old_py)) if isinstance(n,ast.FunctionDef) and n.name!='test_explicit_table_chart_actual_http'}
new_funcs={n.name:ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(new_py)) if isinstance(n,ast.FunctionDef) and n.name!='test_explicit_table_chart_actual_http'}
assert old_funcs==new_funcs
old_js=(A/'qualified-inputs/tests/table_chart.cjs').read_text();new_js=(S/'tests/table_chart.cjs').read_text()
normalized=new_js.replace("const journal=record=>fs.appendFileSync(path.join(root,'page-journal.jsonl'),JSON.stringify({...record,at:performance.now()})+'\\n');\n",'')
normalized=normalized.replace("checks.push(label);journal({kind:'assertion',index:checks.length,label});",'checks.push(label);')
normalized=normalized.replace("const asset={name,status:r.status,sha256:sha,text};assets.push(asset);journal({kind:'asset',asset});",'assets.push({name,status:r.status,sha256:sha,text});')
normalized=normalized.replace("journal({kind:'actual_HTTP',request});",'').replace("journal({kind:'delivered_HTTP',request});",'')
assert normalized==old_js
(R/'test-followup.diff').write_text(''.join(difflib.unified_diff(old_py.splitlines(True),new_py.splitlines(True),fromfile='first-qualified/test_table_chart.py',tofile='followup/test_table_chart.py'))+''.join(difflib.unified_diff(old_js.splitlines(True),new_js.splitlines(True),fromfile='first-qualified/table_chart.cjs',tofile='followup/table_chart.cjs')))
out={'verdict':'STATIC_TEST_ONLY_FOLLOWUP_ACCEPTABLE_RUNTIME_PENDING','changed_inputs':changed,'unchanged_product_files':sum(k.startswith('src/sim2act/') for k in new),'declared_inputs':189,'direct_input_hashes':len(new)-len(stat_only),'compressed_DB_stat_only':stat_only,'python_assert_ast_exact_equal':len(assertions(new_py)),'all_nested_fixture_helper_AST_equal':sorted(new_funcs),'CJS_removing_only_new_journal_calls_restores_original_exact_bytes':True,'guard_timeout':'240seconds guards only; display100 unchanged','inner_wait':'15000ms unchanged','cleanup':'Preserves observations before original thread-stop assertion; adds primary TimeoutExpired metadata and test server graceful5s. Cleanup failure still fails.','first_two_passed_nodes_not_rerun':True,'new_results_logs_or_DB_not_read':True,'no_product_or_test_execution_by_reviewer':True,'final_original_guard_failure_retained':True,'review_not_sealed':True}
(R/'followup-static-verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False))
