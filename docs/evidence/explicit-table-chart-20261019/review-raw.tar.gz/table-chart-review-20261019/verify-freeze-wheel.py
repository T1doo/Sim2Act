from pathlib import Path
import hashlib,json,zipfile
A=Path('/workspace/table-chart-audit-20261019');R=Path('/workspace/table-chart-review-20261019');S=Path('/workspace/Sim2Act')
def file_hash(path):
    data=path.read_bytes();return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
freeze_path=A/'source-freeze-qualified.json';freeze=json.loads(freeze_path.read_text());assert len(freeze)==189
hashed=[];db_stat=[]
for name,record in freeze.items():
    source_path=S/name;copy_path=A/'qualified-inputs'/name
    if name.endswith(('.db','.db.gz','.sqlite','.sqlite3')):
        assert source_path.stat().st_size==copy_path.stat().st_size==record['bytes']
        db_stat.append({'path':name,'bytes':record['bytes'],'method':'stat_only_no_DB_or_compressed_DB_content_or_hash'});continue
    assert file_hash(source_path)==file_hash(copy_path)==record
    hashed.append(name)
assert len(hashed)==183 and len(db_stat)==6
package={name[4:]:value for name,value in freeze.items() if name.startswith('src/sim2act/')};assert len(package)==141
wheel_path=A/'wheel/sim2act-0.1.0-py3-none-any.whl';wheel_record=file_hash(wheel_path)
assert wheel_record=={'bytes':960382,'sha256':'bdd222e96b37be35c33a309c86f4bd33aec4505a628775d9eb89327e1a9ef3fe'}
with zipfile.ZipFile(wheel_path) as wheel:
    names=[name for name in wheel.namelist() if name.startswith('sim2act/') and not name.endswith('/')]
    assert len(names)==len(set(names))==141 and set(names)==set(package)
    for name in names:
        body=wheel.read(name); assert {'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}==package[name]
        assert file_hash(A/'installed-package'/name)==package[name]
prior_path=Path('/workspace/f2-display-contract-audit-20261019/wheel/sim2act-0.1.0-py3-none-any.whl')
assert file_hash(prior_path)=={'bytes':958217,'sha256':'c3ea694281e2c68791da89bfb8f96632c16f26db4d6216218bb71539cba78195'}
with zipfile.ZipFile(prior_path) as old:
    oldnames=[name for name in old.namelist() if name.startswith('sim2act/') and not name.endswith('/')]
    assert len(oldnames)==141 and set(oldnames)==set(package)
    oldrecords={name:{'bytes':len(old.read(name)),'sha256':hashlib.sha256(old.read(name)).hexdigest()} for name in oldnames}
changed=sorted(name for name in package if oldrecords[name]!=package[name]);assert changed==['sim2act/web/app.css','sim2act/web/internal.js']
python_files=[name for name in package if name.endswith('.py')];assert len(python_files)==112 and all(oldrecords[name]==package[name] for name in python_files)
verification=json.loads((A/'wheel-verification.json').read_text())
assert {q['path']:{'bytes':q['bytes'],'sha256':q['sha256']} for q in verification['files']}==package
out={'verdict':'PURE_FILE_FREEZE_AND_WHEEL_PASS_RUNTIME_PENDING','method':'Only ordinary file/zip/JSON reads and hashing; no product import/test/DB/Git/network','freeze':{'path':str(freeze_path),**file_hash(freeze_path),'declared_inputs':189,'direct_hashes_current_and_copy':183,'old_compressed_DB_stat_only':db_stat},'wheel':{'path':str(wheel_path),**wheel_record,'package_members':141,'all_source_wheel_installed_equal':True},'previous_wheel':{'path':str(prior_path),**file_hash(prior_path)},'changed_package_members':changed,'unchanged_python_members':len(python_files),'source_hashes':{name:record for name,record in freeze.items() if name in ['src/sim2act/web/internal.js','src/sim2act/web/app.css','tests/table_chart.cjs','tests/test_table_chart.py']},'active_qualification_results_logs_DB_not_read':True,'no_runtime_PASS_claim':True,'review_not_sealed':True}
(R/'freeze-wheel-verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(out,ensure_ascii=False,indent=2))
