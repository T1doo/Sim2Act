# 首次直接换材料：作者原始证据

{
  "status": "PASS_AUTHOR_FINITE_FIRST_MATERIAL_SLICE",
  "base": "6a8444fbae08cc14ebe0c25de673b9788429815d",
  "branch": "dev/production-trial-stages-20261018",
  "scope": "Original spec1/Goal1 directly replaces existing authorized B, no prior column revision; explicit new Run and cold exact history; not App authorization provisioning",
  "api": {
    "nodes": 3,
    "pytest_seconds": 17.77,
    "outer_seconds": 22.379570630997478,
    "source_bridge": "cache-api/import-order-bridge.json; only two imports reordered; independent reconstructed-hash/AST bridge required"
  },
  "installed": {
    "new_checks": 21,
    "new_http": 84,
    "cold_checks": 9,
    "cold_http": 56,
    "wheel": {
      "bytes": 942732,
      "sha256": "f034a382ffd4860c775d7f953238a3f61336e8b2e922426c5a3a696510c476e7"
    },
    "core_run_ids": [
      "run_e02a6c32943c46eaaad2319c49416470",
      "run_2e204270d3c64b15ac4ae92a32be9f48",
      "run_ecf2df76c088464f92d56e4c3fcabeef"
    ],
    "first_worker": "worker_527790895e7e4eaa9526ac5eaf30a5f8",
    "cold_worker": "worker_aa7448ceb4c0460c8bbd3df89356ebaf",
    "instance_id": "iinstance_01ba1607d3ea7fd596f6c60f3f541665",
    "old_release_id": "irelease_76e9d9ce8dfc46bd83a115b00eb6545b",
    "new_release_id": "irelease_3abcb5bc8fcb4d2783bedf0cff9d45d5",
    "old_sum": "30",
    "old_version": 1,
    "new_sum": "350",
    "new_version": 2,
    "goal_version": 1,
    "three_ordinary_claims": 3,
    "model_attempts": 0,
    "reservations": 0
  },
  "precondition": "exact2 synthetic App/B resource.read + data.aggregate_csv Grants before measurement/derive/Release; no product authority write; measured all Grant bytes unchanged",
  "failed_windows": {
    "api_original": "FAIL_TIMEOUT180s .F; long old compatibility node NOT_COMPLETED",
    "lock_diagnostic": "FAIL assertion expected409, original correct LOCK_CONFLICT400; assertion corrected",
    "api_final": "FAIL_TIMEOUT240s ..; old compatibility node NOT_COMPLETED",
    "installed": "FAIL fixture HTTPX headers keyword TypeError before first fixture HTTP, workspace init already occurred",
    "final_installed": "FAIL terminal18s observed QUEUED; after shutdown PAUSED/newtyped absent",
    "fair_installed": "FAIL whole-page300s; incremental page RUNNING18checks; after shutdown PAUSED/newtyped absent",
    "cache_static": "FAIL RuffI001 test import order; corrected only imports",
    "readonly_profile": "FAIL first helper Settings.limits AttributeError; corrected helper PASS11.705s and55tables unchanged"
  },
  "deadline": "qualified observer whole-page900s for three original300s jobs; original product Run budget/lease unchanged; prior300 FAIL remains",
  "boundaries": {
    "Win": "NOT_RUN",
    "native_browser": "NOT_RUN",
    "PostgreSQL": "NOT_RUN",
    "real_semantic": "NOT_RUN",
    "real_human_acceptance": "NOT_RUN",
    "remote_CI": "NOT_RUN",
    "real_account_material": "SOURCE_MISSING",
    "old_full_disk_final_review": "NOT_RECOVERED",
    "current_remote_HEAD": "UNKNOWN_ACCESS_NOT_RETRIED",
    "git_remote_auth_retry": 0,
    "push": 0
  },
  "timestamp": "2026-10-18T22:18:00.210612+00:00"
}

完整失败、观察器更正及未测边界均保留；sealed-manifest覆盖本目录所有普通文件及符号链接。未使用旧满盘实例或私有语义holdout。
