# 首次直接更换已有授权 CSV

基线 `6a8444fbae08cc14ebe0c25de673b9788429815d`。上一片[首版保留Goal换列](InitialColumnRevision20261018.md)仅修改同一CSV的列，不等于换材料，也不关闭本缺口。原F2-T07/T08要求在明确依赖变更后独立检查、精确版本批准、保留实例及旧数据；本片复用原材料修订/CHECK/Release/采纳合同，不添加executor、Grant或权限入口。

实现前范围：原spec1/Goal1的业务实例可直接选择另一份已有用户/项目/App三方授权的CSV，无需先做列修订或下一Goal。原Release尚未固定列，界面须明确选择A和B共有的数值列；首版新规格固定该列，因此影响明确包含SOURCE及ACTION，仍APP独立重验并尊重ACTION人工锁。旧已采纳材料分支的冻结结构和计算不变，原Release/Goal/材料/权限/历史不覆写。新Run使用B的新内容/hash，旧A结果仅历史；语义UNKNOWN、人工PENDING。

原first source descriptor明确为ORIGINAL_CSV_RELEASE/spec1/column:null，不伪造已采用的父修订。只读历史重构使用原不可变Release和完整Goal版本；当前新工作仍检查原graph、权限、Goalhead、数据/实例CAS。原key/双锚/恢复和页面账号项目实例代次隔离继续复用，未受理和结果不明仍按原控制器处理。

授权前置必须区分：普通材料导入只授用户及项目运行身份，当前没有给既有CSV App追加材料权限的页面；本片不补或绕过它。“已有授权”必须包括App对B的resource.read与data.aggregate_csv。合成验收会在测量和derive之前明确预置这两项App/B Grant，其他创建走原API；产品换材料操作前后Grant逐字相等。不能将此前置说成空白页面已授予B或普通未授权材料可直接使用。

最小实际链：初始Release1、原Goal1、同一App/iid，A amount10/20→旧30/v1；直接材料入口选择B amount100/250，保留amount及Goal，独立CHECK350、分别确认Release2及原iid采纳，再显式新Run350/v2，冷页读取旧A30和新B350及各自Release。无Goal PUT，无任何先行列修订或采用。用原Worker/mock固定工具，不调用真实模型。

既有全部失败/observer更正/封存保持。沿用Git/auth拒绝，不重试远端、不换路；同一普通开发分支本地提交。Win/native、PG、真实语义/人工签收及远端CI未执行不认领。
