import cProfile,json,signal,pstats,io,time
from pathlib import Path
from sim2act.synthetic_workspace import open_workspace,settings_for
from sim2act.lifecycle import read_release
ROOT=Path('/workspace/first-material-direct-20261018/fair-installed')
fixture=json.loads((ROOT/'fixture.json').read_text());page=json.loads((ROOT/'new-page-proof.json').read_text())
root,store,marker=open_workspace(ROOT/'首版换材料 已授权',new=False)
profile=cProfile.Profile();started=time.monotonic();result={}
def deadline(sig,frame):raise TimeoutError('bounded readonly Release proof 50s')
signal.signal(signal.SIGALRM,deadline);signal.alarm(50)
try:
 with store.tx()as c:
  profile.enable()
  value=read_release(store,c,marker['principal_id'],page['new_release_id'],settings_for(root).limits)
  result.update(status='PASS',release=value['id'])
except BaseException as e:result.update(status='FAIL',error=repr(e))
finally:
 signal.alarm(0);profile.disable();store.engine.dispose();result['seconds']=time.monotonic()-started
 profile.dump_stats(str(ROOT/'readonly-release.pstats'));stream=io.StringIO();pstats.Stats(profile,stream=stream).strip_dirs().sort_stats('cumulative').print_stats(60)
 (ROOT/'readonly-release-profile.txt').write_text(stream.getvalue());(ROOT/'readonly-release-profile.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
