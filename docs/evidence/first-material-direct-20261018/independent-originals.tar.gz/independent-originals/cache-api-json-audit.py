import csv,hashlib,io,json
from decimal import Decimal
from pathlib import Path
A=Path('/workspace/first-material-direct-20261018/cache-api/data')
O=Path('/workspace/first-material-direct-review-20261018')
def read(p): return json.loads(p.read_text())
def fp(x): return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
p=A/'test_direct_original_material_0/direct-material-preview.json'; q=A/'test_direct_material_action_in0/direct-material-locked.json'
x=read(p);y=read(q);b=x['before'];a=x['after'];v=x['preview'];ctx=x['context']
assert len(b)==len(a)==55 and set(a)==set(b)
assert [t for t in b if b[t]!=a[t]]==['delivery_graph_requests']
old=b['delivery_graph_requests'];new=[z for z in a['delivery_graph_requests'] if z not in old]
assert all(z in a['delivery_graph_requests'] for z in old) and len(new)==2
assert {z['kind'] for z in new}=={'csv-goal-revision.v1.preview','csv-goal-revision.v1.preview_seal'}
assert new[0]['snapshot']==new[1]['snapshot']
body=new[0]['snapshot']['request']
for z in new:
 assert z['app_id']==ctx['instance_id'] and z['principal_id']==ctx['principal_id'] and z['request_key']==body['request_key']==v['request_key']
 assert z['request_fingerprint']==fp(body) and z['snapshot']['response']==v and z['fingerprint']==fp(z['snapshot'])
assert fp({k:z for k,z in v.items() if k!='preview_fingerprint'})==v['preview_fingerprint']
assert v['context']==ctx and ctx['initial_material'] is True and ctx['goal_mode']=='KEEP_ORIGINAL_GOAL'
assert ctx['original_goal_version']==ctx['goal']['version']==ctx['instance_revision']==1 and ctx['data_version']==0
parent=ctx['parent'];assert set(parent)=={'kind','release_id','release_fingerprint','effective_fingerprint','spec_revision','goal','column','reference','graph_fingerprint'}
assert parent['kind']=='ORIGINAL_CSV_RELEASE' and parent['spec_revision']==1 and parent['column'] is None and parent['reference'] is None
assert parent['goal']==ctx['goal'] and parent['release_id']==ctx['release_id'] and parent['release_fingerprint']==ctx['release_fingerprint'] and parent['effective_fingerprint']==ctx['draft_fingerprint']
assert len(b['internal_releases'])==len(b['internal_instances'])==1
assert not b['runs'] and not b['internal_app_runs'] and not b['internal_instance_data'] and not b['attempts']
release=b['internal_releases'][0];s=release['snapshot'];base=s['draft'];candidate=base['candidate']
assert release['id']==ctx['release_id'] and release['fingerprint']==fp(s)==ctx['release_fingerprint']
assert not {'csv_goal_revision_source','execution_source','natural_logic_source'} & set(s)
assert candidate['manifest']['revision']==candidate['actions'][0]['revision']==candidate['manifest']['action_bindings'][0]['revision']==1
assert base['id']==ctx['app_id'] and base['runtime_id']==ctx['runtime_id'] and base['project_id']==ctx['project_id'] and fp(candidate)==base['fingerprint']==ctx['draft_fingerprint']
g=candidate['generation'];goal=ctx['goal'];assert goal=={'card_id':g['goal_card_id'],'version':g['goal_version'],'fingerprint':g['goal_fingerprint'],'snapshot':g['goal_snapshot']}
assert fp(goal['snapshot'])==goal['fingerprint']
gv=[r for r in b['goal_card_versions'] if r['card_id']==goal['card_id'] and r['version']==1];assert len(gv)==1 and gv[0]['snapshot']==goal['snapshot'] and gv[0]['fingerprint']==goal['fingerprint']
assert v['parent_graph']==v['baseline_graph']
changed={n['key'] for n in v['parent_graph']['graph']['nodes'] if n['id'] in v['impact']['changed_nodes']}
assert changed=={'source:'+ctx['source']['resource_id'],'action:aggregate'} and v['impact']['revalidation_scope']=='APP'
assert v['input']==v['baseline_input']=={'column':'amount'} and body['baseline_column']==body['column']=='amount'
assert v['material']=={'resource_id':body['resource_id'],'hash':body['source_hash'],'format':'csv','revision':1}
assert v['material']['resource_id']!=ctx['source']['resource_id'] and v['material']['hash']!=ctx['source']['hash']
e=v['effective_candidate'];assert fp(e)==v['effective_fingerprint'] and v['spec_revision']==e['manifest']['revision']==e['actions'][0]['revision']==e['manifest']['action_bindings'][0]['revision']==2
assert e['goal']==goal['snapshot']['content'] and e['generation']==g and e['source_hash']==body['source_hash']
assert e['manifest']['data_bindings'][0]['resource_ref']==body['resource_id']
for spec in (e['manifest'],e['actions'][0]):
 assert spec['input_schema']['properties']['column']=={'type':'string','enum':['amount']}
 assert all(z['resource_ref']==body['resource_id'] for z in spec['permission_requirements'])
resources={r['id']:r for r in b['resources']}
for rid,h in [(ctx['source']['resource_id'],ctx['source']['hash']),(body['resource_id'],body['source_hash'])]:
 rr=resources[rid];assert rr['project_id']==ctx['project_id'] and rr['format']=='csv' and rr['hash']==hashlib.sha256(rr['content'].encode()).hexdigest()==h
sums={label:str(sum((Decimal(r['amount']) for r in csv.DictReader(io.StringIO(resources[rid]['content']))),Decimal(0))) for label,rid in [('A',ctx['source']['resource_id']),('B',body['resource_id'])]};assert sums=={'A':'30','B':'350'}
bs=[r for r in b['grants'] if r['principal_id']==ctx['runtime_id'] and r['resource_id']==body['resource_id']]
assert len(bs)==2 and {r['tool_ref'] for r in bs}=={'resource.read','data.aggregate_csv'} and all(r['project_id']==ctx['project_id'] and r['revoked'] is False for r in bs)
assert b['grants']==a['grants'] and x['rejection_all55_equal'] is True and len(x['rejected'])==2
for rej in x['rejected']:
 proof=rej['error']['submission_rejection'];assert proof['instance_id']==ctx['instance_id'] and proof['principal_id']==ctx['principal_id'] and proof['request_key']==body['request_key'] and proof['acceptance']=='NOT_ACCEPTED' and proof['previous_request']=='ABSENT' and proof['phase']=='TX_ROLLED_BACK'
assert len(y['before'])==55 and y['before']==y['after']
lc=y['context'];err=y['response']['error'];rejection=err['submission_rejection'];assert err['code']=='LOCK_CONFLICT'
assert rejection['instance_id']==lc['instance_id'] and rejection['principal_id']==lc['principal_id'] and rejection['acceptance']=='NOT_ACCEPTED' and rejection['previous_request']=='ABSENT' and rejection['phase']=='TX_ROLLED_BACK'
locks=y['before']['delivery_graph_locks'];assert len(locks)==1
lock=locks[0];assert lock['snapshot']['logical_key']=='action:aggregate' and lock['snapshot']['locked'] is True and lock['fingerprint']==fp(lock['snapshot'])
out={'status':'PASS_INDEPENDENT_PURE_CLOSED_JSON','inputs':{str(p):sha(p),str(q):sha(q)},'tables':55,'preview_unchanged_tables':54,'exact_new_paired_journal_rows':2,'request_fingerprint':fp(body),'preview_fingerprint':v['preview_fingerprint'],'original_release_spec1_no_prior_Run_or_adoption':True,'original_Goal1_full_snapshot_exact':True,'changed_nodes':sorted(changed),'revalidation_scope':'APP','original_parent_column':None,'fixed_new_column':'amount','independent_csv_sums':sums,'exact_two_preexisting_App_B_Grants':True,'Grant_rows_unchanged':True,'locked_preview_all55_equal':True,'locked_action_fingerprint_verified':True,'known_lock_HTTP_status':'400 from separate closed diagnostic stdout; JSON body does not itself record HTTP status','rejected_call_table_scope':'Original executed test assertion/exported boolean for wronghash/no-App-authority; no per-rejection independent table snapshots.','qualification_limit':'Closed final cache API module has three nodes; this sub-audit recomputes its preview and lock exports. Legacy full compatibility NOT_COMPLETED; installed running UI not signed.','reviewer_product_DB_Git_network_execution':False}
(O/'cache-api-json-verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False,indent=2))
