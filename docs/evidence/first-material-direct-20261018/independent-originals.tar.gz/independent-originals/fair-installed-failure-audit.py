import hashlib,json
from pathlib import Path
A=Path('/workspace/first-material-direct-20261018/fair-installed');O=Path('/workspace/first-material-direct-review-20261018')
def read(n):return json.loads((A/n).read_text())
r=read('installed-result.json');v=read('new-page-proof.json');b=read('execution-before.json');e=read('execution-after.json');before=read('before-edit.json');after=read('after-failure.json')
assert r['status']=='FAIL' and r['error']=={'type':'AssertionError','message':'new-page observer deadline exceeded'}
assert v['status']=='RUNNING' and v['phase']=='new-run' and len(v['checks'])==18 and 'new_run_id' not in v
posts=[z for z in v['requests'] if z.get('method')=='POST' and z.get('path','').endswith('/runs')]
assert len(posts)==2 and all(z['status']==202 for z in posts)
nrid=posts[-1]['response']['run_id'];assert nrid=='run_35c6ffc54213494bbeeedc479b151782'
assert len(b['source'])==143 and b['source']==e['source'] and e['matches_before'] is True
assert b['fixture_script_sha256']==e['fixture_script_sha256'] and b['runner_sha256']==e['runner_sha256']
assert len(before)==len(after)==55 and before['grants']==after['grants'] and not after['attempts']
core={z['id']:z for z in after['runs']};assert core[nrid]['status']=='PAUSED'
assert core[v['old_run_id']]['status']==core[v['check_run_id']]['status']=='SUCCEEDED'
bind={z['run_id']:z['app_run_id'] for z in after['internal_run_bindings']}
assert nrid in bind and not any(z['run_id']==bind[nrid] for z in after['internal_instance_data'])
checkdata=[z for z in after['internal_instance_data'] if z['run_id']==bind[v['check_run_id']]];assert len(checkdata)==1 and checkdata[0]['data']['result']['sum']=='350'
olddata=[z for z in after['internal_instance_data'] if z['run_id']==bind[v['old_run_id']]];assert len(olddata)==1 and olddata[0]['data']['result']['sum']=='30'
assert core[nrid]['worker_id']==core[v['old_run_id']]['worker_id']==core[v['check_run_id']]['worker_id']
claims=[z for z in after['events'] if z['kind']=='CLAIMED'];assert len(claims)==3 and {z['run_id'] for z in claims}==set(core)
assert len(r['processes'])==1 and r['processes'][0]['exit_code']==0
stops=r['processes'][0]['stopped'];assert len(stops)==1 and stops[0]['clean'] is True and stops[0]['worker_stopped'] is True
stderr=(A/'new-process.stderr').read_text();assert 'CancelledError' in stderr and 'single_sqlite_writer' in stderr and 'await asyncio.sleep(0.01)' in stderr and 'Cancel 1 running task' in stderr
out={'status':'FAIR_INSTALLED_FAIL_NOT_QUALIFIED','outer_status':r['status'],'outer_error':r['error'],'incremental_page_status':'RUNNING retained; incomplete tail, not retroactively marked FAIL or PASS','page_checks':18,'new_Run_id_from_actual_POST202':nrid,'page_new_Run_id_field_missing':True,'after_owned_shutdown':'PAUSED on same original claimed Worker, no new business typed row; no model Attempts','old_A_sum':'30','isolated_CHECK_B_sum':'350','Worker_claims':3,'Grant_rows_unchanged':True,'all_143_input_and_fixture_runner_hashes_equal':True,'owned_process_exit':0,'STOPPED_clean':True,'ASGI_cancelled_waiter_in_raw_stderr':1,'causality':'Not proven uniquely; no proof of starvation/race or completed new B result.','physical_DB_access':'None; independently inspected author-exported closed55 JSON only.','raw_sha256':{n:hashlib.sha256((A/n).read_bytes()).hexdigest() for n in ['installed-result.json','new-page-proof.json','execution-before.json','execution-after.json','before-edit.json','after-failure.json','new-process.stderr']},'reviewer_product_test_DB_Git_network_execution':False}
(O/'fair-installed-failure-verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False,indent=2))
