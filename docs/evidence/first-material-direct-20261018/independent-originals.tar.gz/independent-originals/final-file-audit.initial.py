import hashlib,json,os,stat,zipfile
from pathlib import Path
A=Path('/workspace/first-material-direct-20261018');Q=A/'qualified-installed';R=Path('/workspace/Sim2Act');O=Path('/workspace/first-material-direct-review-20261018')
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_text())
raw=(A/'sealed-manifest.json').read_bytes();m=json.loads(raw)
assert sha(raw)=='7f858795b1b9ffdc54776b7d177aca13f22a6e4c74053c53677f831cc15c43e9'
assert m['file_count']==len(m['files'])==2413 and m['bytes']==sum(z['bytes'] for z in m['files'])==81228636
hashed=[];DB=[]
for z in m['files']:
 p=A/z['path'];s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_size==z['bytes'],z['path']
 if '.db' in p.name or '.sqlite' in p.name:DB.append(z['path']);continue
 assert sha(p.read_bytes())==z['sha256'],z['path'];hashed.append(z)
assert len(m['symlinks'])==24
for z in m['symlinks']:assert (A/z['path']).is_symlink() and os.readlink(A/z['path'])==z['target'],z['path']
found=[];links=[]
for base,dirs,files in os.walk(A,followlinks=False):
 for n in dirs[:]:
  p=Path(base)/n
  if p.is_symlink():links.append(str(p.relative_to(A)));dirs.remove(n)
 for n in files:
  p=Path(base)/n
  if p.is_symlink():links.append(str(p.relative_to(A)))
  elif p.parent!=A or p.name!='sealed-manifest.json':found.append(str(p.relative_to(A)))
assert set(found)=={z['path'] for z in m['files']} and set(links)=={z['path'] for z in m['symlinks']}
f=read(A/'final-source-hashes.json');assert len(f)==9
for n,h in f.items():assert sha((A/'final-source'/n).read_bytes())==h==sha((R/n).read_bytes()),n
b=read(Q/'execution-before.json');e=read(Q/'execution-after.json');assert len(b['source'])==143 and b['source']==e['source'] and e['matches_before'] is True
for n,h in b['source'].items():assert sha((Q/'execution-source'/n).read_bytes())==h,n
assert b['runner_sha256']==e['runner_sha256']==sha((Q/'installed_run.py').read_bytes())
assert b['fixture_script_sha256']==e['fixture_script_sha256']==sha((Q/'execution-source/prepare_installed_fixture.py').read_bytes())
d=read(A/'post-execution-doc-bridge.json');assert d['execution_source']==b['source'] and d['changed']==['docs/F2/FirstMaterialRevision20261018.md']
current={n:sha((R/n).read_bytes()) for n in b['source']};assert current==d['final_source']
assert [n for n in current if current[n]!=b['source'][n]]==d['changed']
w=read(Q/'wheel-files.json');assert len(w)==139
wp=Q/'wheel/sim2act-0.1.0-py3-none-any.whl';wb=wp.read_bytes();assert len(wb)==942732 and sha(wb)=='f034a382ffd4860c775d7f953238a3f61336e8b2e922426c5a3a696510c476e7'
with zipfile.ZipFile(wp) as z:
 assert {n for n in z.namelist() if n.startswith('sim2act/') and not n.endswith('/')}==set(w)
 for n,h in w.items():assert sha(z.read(n))==h==sha((Q/'installed-venv/lib/python3.12/site-packages'/n).read_bytes())==sha((R/'src'/n).read_bytes()),n
old=read(Path('/workspace/initial-column-edit-20261018/final-fresh/wheel-files.json'));delta=[n for n in w if w[n]!=old[n]];assert set(delta)=={'sim2act/csv_material_revisions.py','sim2act/synthetic_workspace.py','sim2act/web/csv-goal-revision.js'}
assert read(A/'cache-api/command.json')['status']=='PASS' and read(A/'cache-static-final.json')['status']=='PASS'
assert all(z['exit_code']==0 for z in read(A/'cache-static-final.json')['commands'])
r=read(Q/'installed-result.json');assert r['status']=='PASS' and len(r['checks'])==30 and r['whole_page_deadline_seconds']==900 and r['real_models']==0
assert all(z['exit_code']==0 and len(z['stopped'])==1 and z['stopped'][0]['clean'] is True and z['stopped'][0]['worker_stopped'] is True for z in r['processes'])
assert len(r['processes'])==2
v={'status':'PASS_LIMITED_PURE_FILE_SOURCE_AUDIT','author_manifest_file_sha256':sha(raw),'author_regular_files':2413,'author_regular_bytes':81228636,'non_DB_hashed_files':len(hashed),'non_DB_hashed_bytes':sum(z['bytes'] for z in hashed),'DB_stat_only':DB,'symlink_readlink_only':24,'exact_tree_membership':True,'final_source_9_current_frozen_equal':f,'execution_inputs_143_before_after_and_copies_equal':True,'fixture_runner_hashes_before_after_copies_equal':True,'post_execution_difference':'FirstMaterialRevision documentation only; package/runtime/tests unchanged','wheel':{'bytes':len(wb),'sha256':sha(wb),'package139_zip_installed_current_equal':True},'package_delta_vs_prior_first_column_139':delta,'protected_136_package_files_unchanged':True,'installed_outer_checks':30,'owned_processes_clean_exit0':2,'whole_page_observer_seconds':900,'original_product_Run_seconds':300,'runtime_performance_guarantee':False,'reviewer_product_test_DB_SQL_Git_network_execution':False,'note':'Physical SQLite files stat-only; their contents and hashes were not read/recomputed. Archive/raw-copy packaging/commit not audited.'}
(O/'final-file-verification.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n');print(json.dumps(v,ensure_ascii=False,indent=2))
