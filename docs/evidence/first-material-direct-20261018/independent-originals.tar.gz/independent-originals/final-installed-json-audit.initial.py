import ast,collections,csv,hashlib,io,json,zipfile
from decimal import Decimal
from pathlib import Path
A=Path('/workspace/first-material-direct-20261018');Q=A/'qualified-installed';O=Path('/workspace/first-material-direct-review-20261018')
def read(n):return json.loads((Q/n).read_text())
def fp(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def sha(b):return hashlib.sha256(b).hexdigest()
v=read('new-page-proof.json');cold=read('cold-page-proof.json');run=read('installed-result.json');fixture=read('fixture.json')
assert v['status']==cold['status']==run['status']=='PASS' and len(v['checks'])==21 and len(cold['checks'])==9 and len(run['checks'])==30
assert len(v['requests'])==84 and len(cold['requests'])==56
assert dict(collections.Counter(z['method'] for z in v['requests']))=={'GET':75,'POST':9}
assert all(z['method']=='GET' for z in cold['requests'])
assert dict(collections.Counter(z['status'] for z in v['requests']))=={200:76,400:1,202:3,201:4}
assert dict(collections.Counter(z['status'] for z in cold['requests']))=={200:55,400:1}
with zipfile.ZipFile(Q/'wheel/sim2act-0.1.0-py3-none-any.whl') as z:
 nodes=ast.parse(z.read('sim2act/synthetic_workspace.py').decode()).body
 token=next(n.value.value for n in nodes if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='TOKEN' for t in n.targets))
 def const_str(n):
  if isinstance(n,ast.Constant) and isinstance(n.value,str):return n.value
  if isinstance(n,ast.Name) and n.id=='TOKEN':return token
  if isinstance(n,ast.BinOp) and isinstance(n.op,ast.Add):return const_str(n.left)+const_str(n.right)
  raise ValueError('Unexpected static banner expression')
 banner=const_str(next(n.value for n in nodes if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='BANNER' for t in n.targets)))
 html=z.read('sim2act/web/index.html').decode().replace('<body>','<body>'+banner,1).encode()
 response_hashes=0
 for page in [v,cold]:
  assert len(page['assets'])==25
  assert page['root_headers']['x-content-type-options']=='nosniff' and page['root_headers']['cache-control']=='no-store' and "script-src 'self'" in page['root_headers']['content-security-policy']
  bad=[r for r in page['requests'] if r['status']==400];assert len(bad)==1 and bad[0]['path']=='/protocol/contracts' and bad[0]['response']['error']['code']=='RESOURCE_UNAVAILABLE'
  for asset in page['assets']:assert asset['sha256']==sha(z.read('sim2act/web'+asset['src']))
  for r in page['requests']:
   if 'response' in r:raw=json.dumps(r['response'],ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()
   elif r['path']=='/':raw=html
   else:raw=z.read('sim2act/web'+r['path'])
   assert sha(raw)==r['sha256'],r['path'];response_hashes+=1
assert response_hashes==140
names=['fixture-before-ui.json','before-edit.json','before-preview.json','after-preview.json','after-adopt.json','after-new-run.json','first-stop.json','cold-stop.json']
snaps={n:read(n) for n in names};assert all(len(s)==55 and set(s)==set(snaps[names[0]]) for s in snaps.values())
pre=snaps['fixture-before-ui.json'];old=snaps['before-edit.json'];bp=snaps['before-preview.json'];ap=snaps['after-preview.json'];ad=snaps['after-adopt.json'];end=snaps['after-new-run.json'];stop=snaps['first-stop.json'];cs=snaps['cold-stop.json']
for n in ['principals','projects','resources','app_drafts','grants','goal_cards','goal_card_versions']:
 assert all(s[n]==pre[n] for s in snaps.values()),n
assert not pre['runs'] and not pre['internal_app_runs'] and not pre['internal_instance_data'] and len(pre['internal_releases'])==1 and len(pre['internal_instances'])==1
assert not {'csv_goal_revision_source','execution_source','natural_logic_source'} & set(pre['internal_releases'][0]['snapshot'])
iid=v['instance_id'];assert iid==fixture['instance_id']=='iinstance_01ba1607d3ea7fd596f6c60f3f541665'
assert pre['internal_instances'][0]['revision']==1 and pre['internal_instances'][0]['data_version']==0
pr=v['preview'];ctx=pr['context'];goal=ctx['goal'];body_rows=[r for r in ap['delivery_graph_requests'] if r not in bp['delivery_graph_requests']]
assert set(n for n in bp if bp[n]!=ap[n])<={'delivery_graph_requests','heartbeats'}
assert all(bp[n]==ap[n] for n in bp if n not in ['delivery_graph_requests','heartbeats']) and len(body_rows)==2
assert all(r in ap['delivery_graph_requests'] for r in bp['delivery_graph_requests'])
assert {r['kind'] for r in body_rows}=={'csv-goal-revision.v1.preview','csv-goal-revision.v1.preview_seal'}
assert body_rows[0]['snapshot']==body_rows[1]['snapshot'];body=body_rows[0]['snapshot']['request']
for r in body_rows:
 assert r['app_id']==iid and r['principal_id']==ctx['principal_id'] and r['request_key']==body['request_key']==pr['request_key']
 assert r['request_fingerprint']==fp(body) and r['snapshot']['response']==pr and r['fingerprint']==fp(r['snapshot'])
assert pr['preview_fingerprint']==fp({k:z for k,z in pr.items() if k!='preview_fingerprint'})
assert ctx['initial_material'] is True and ctx['goal_mode']=='KEEP_ORIGINAL_GOAL' and ctx['parent']['kind']=='ORIGINAL_CSV_RELEASE' and ctx['parent']['spec_revision']==1 and ctx['parent']['column'] is None
assert ctx['instance_revision']==ctx['data_version']==ctx['original_goal_version']==goal['version']==1
assert ctx['goal']==ctx['parent']['goal'] and fp(goal['snapshot'])==goal['fingerprint']
g=fixture['goal'];assert goal=={'card_id':g['goal_card_id'],'version':g['goal_version'],'fingerprint':g['goal_fingerprint'],'snapshot':g['goal_snapshot']}
assert pr['input']==pr['baseline_input']=={'column':'amount'} and pr['spec_revision']==2
assert {n['key'] for n in pr['parent_graph']['graph']['nodes'] if n['id'] in pr['impact']['changed_nodes']}=={'source:'+fixture['resource_id'],'action:aggregate'} and pr['impact']['revalidation_scope']=='APP'
assert pr['parent_graph']==pr['baseline_graph']
assert pr['effective_candidate']['generation']==g and pr['effective_candidate']['goal']==goal['snapshot']['content']
assert pr['material']=={'resource_id':fixture['B_id'],'hash':fixture['B_hash'],'format':'csv','revision':1}
assert pr['effective_fingerprint']==fp(pr['effective_candidate'])
resources={r['id']:r for r in pre['resources']};sums={}
for label,rid,h in [('A',fixture['resource_id'],fixture['A_hash']),('B',fixture['B_id'],fixture['B_hash'])]:
 row=resources[rid];assert row['hash']==h==sha(row['content'].encode())
 sums[label]=str(sum((Decimal(r['amount']) for r in csv.DictReader(io.StringIO(row['content']))),Decimal(0)))
assert sums=={'A':'30','B':'350'}
Bgrants=fixture['precondition_app_B_grants'];assert len(Bgrants)==2 and {r['tool_ref'] for r in Bgrants}=={'resource.read','data.aggregate_csv'}
assert all(r in pre['grants'] and r['principal_id']==ctx['runtime_id'] and r['project_id']==ctx['project_id'] and r['resource_id']==fixture['B_id'] and r['revoked'] is False for r in Bgrants)
assert len([r for r in pre['grants'] if r['principal_id']==ctx['runtime_id'] and r['resource_id']==fixture['B_id']])==2
for n in ['runs','internal_app_runs','internal_run_bindings','run_contracts','internal_instance_data','internal_releases','operations','operation_intents','events']:
 assert all(row in end[n] for row in old[n]),n
assert len(end['runs'])==len(end['internal_app_runs'])==len(end['internal_run_bindings'])==len(end['run_contracts'])==len(end['internal_instance_data'])==3
ids=[v['old_run_id'],v['check_run_id'],v['new_run_id']];assert ids==['run_e02a6c32943c46eaaad2319c49416470','run_2e204270d3c64b15ac4ae92a32be9f48','run_ecf2df76c088464f92d56e4c3fcabeef']
core={r['id']:r for r in end['runs']};bind={r['run_id']:r for r in end['internal_run_bindings']};apps={r['id']:r for r in end['internal_app_runs']};typed={r['run_id']:r for r in end['internal_instance_data']}
assert set(core)==set(ids) and all(r['status']=='SUCCEEDED' and r['fence']==1 and r['worker_id']==run['first_worker'] for r in core.values())
claims=[r for r in end['events'] if r['kind']=='CLAIMED'];assert len(claims)==3 and {r['run_id'] for r in claims}==set(ids)
for rid,version,sum_value,resource,h in [(ids[0],1,'30',fixture['resource_id'],fixture['A_hash']),(ids[1],1,'350',fixture['B_id'],fixture['B_hash']),(ids[2],2,'350',fixture['B_id'],fixture['B_hash'])]:
 appid=bind[rid]['app_run_id'];a=apps[appid];t=typed[appid];assert a['status']=='SUCCEEDED' and a['result_version']==version==t['version'] and t['data']=={'result':{'resource_id':resource,'column':'amount','count':2,'sum':sum_value,'source_hash':h}} and t['fingerprint']==fp(t['data'])
 assert bind[rid]['fingerprint']==fp(bind[rid]['snapshot']) and bind[rid]['snapshot']['run_id']==rid and bind[rid]['snapshot']['app_run_id']==appid
for c in end['run_contracts']:assert c['snapshot']['limits']['run_seconds']==300 and c['fingerprint']==fp(c['snapshot'])
assert bind[ids[2]]['snapshot']['csv_goal']==goal
assert not end['attempts'] and not end['reservations'] and not end['csv_owner_records'] and not end['csv_owner_seals']
rel={r['id']:r for r in end['internal_releases']};assert set(rel)=={v['old_release_id'],v['new_release_id']} and v['old_release_id']==fixture['old_release_id']
assert all(fp(r['snapshot'])==r['fingerprint'] for r in rel.values())
origin=rel[v['new_release_id']]['snapshot']['csv_goal_revision_source'];assert origin['namespace']=='csv-material-revision.v1' and origin['spec_revision']==2 and origin['parent']==ctx['parent'] and origin['goal']==goal and origin['effective_fingerprint']==pr['effective_fingerprint']
instance=lambda snap:next(r for r in snap['internal_instances'] if r['id']==iid)
assert instance(old)['revision']==1 and instance(old)['data_version']==1 and instance(ad)['revision']==2 and instance(ad)['data_version']==1 and instance(end)['revision']==2 and instance(end)['data_version']==2
history=instance(end)['history'];assert len(history)==2 and history[0]['release_id']==v['old_release_id'] and history[1]['kind']=='switch' and history[1]['previous_release_id']==v['old_release_id'] and history[1]['release_id']==v['new_release_id']
owner=[r['response'] for r in v['requests'] if r['path'].endswith('/csv-owner-review')];assert len(owner)==1 and owner[0]['run_id']==ids[2] and owner[0]['instance_id']==iid and owner[0]['sequence']==0 and owner[0]['owner_acceptance']=='PENDING' and owner[0]['formal_publication_enabled'] is False
assert all(r['method']!='PUT' for r in v['requests']) and not any(r['method']=='POST' and r['path'].endswith('/csv-goal-revisions/previews') for r in v['requests'])
assert len([r for r in v['requests'] if r['method']=='POST' and r['path'].endswith('/runs')])==2
for rid,release,resource,h in [(ids[0],v['old_release_id'],fixture['resource_id'],fixture['A_hash']),(ids[2],v['new_release_id'],fixture['B_id'],fixture['B_hash'])]:
 rs=[r for r in cold['requests'] if r['path']==f'/api/internal/instances/{iid}/runs/{rid}'];assert rs and all(r['response']['id']==rid and r['response']['release_id']==release and r['response']['result']['resource_id']==resource and r['response']['result']['source_hash']==h for r in rs)
assert all(stop[n]==cs[n] for n in stop if n!='heartbeats') and all(r in cs['heartbeats'] for r in stop['heartbeats'])
out={'status':'PASS_INDEPENDENT_CLOSED_INSTALLED_JSON','new_page_checks':21,'new_HTTP':84,'new_methods':{'GET':75,'POST':9},'cold_page_checks':9,'cold_GET':56,'independently_reconstructed_response_SHA256':140,'all_actual_25JS_and_CSS_assets_equal_wheel':True,'optional_protocol_HTTP400_per_page':1,'snapshot_tables':55,'preview_protected_tables':53,'preview_exact_new_sealed_rows':2,'original_Goal1_full_snapshot_preserved':True,'precondition':'API-prepared original Release, explicit exact2 App/B Grants before measurement; no ordinary B-Grant UI claimed','Grant_rows_equal_all_stages':True,'SOURCE_ACTION_APP':True,'independent_A_B_sums':sums,'business_iid':iid,'core_Run_ids':ids,'worker_ids':[run['first_worker'],run['cold_worker']],'claims':3,'model_attempts':0,'reservations':0,'check_typed_version':1,'business_results':['A30/v1','B350/v2'],'old_history_rows_preserved':True,'owner':'same newRun sequence0 PENDING, no DECIDE','cold_nonheartbeat_tables_equal':54,'scope':'Pure file/JSON/CSV/AST-static-string/zip computation; no product imports/tests/Worker/DB/Git/network/private holdout','raw_inputs_sha256':{n:sha((Q/n).read_bytes()) for n in ['new-page-proof.json','cold-page-proof.json',*names]}}
(O/'final-installed-json-verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False,indent=2))
