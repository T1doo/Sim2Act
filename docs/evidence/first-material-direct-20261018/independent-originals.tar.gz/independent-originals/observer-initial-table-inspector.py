import json
from pathlib import Path
p=Path('/workspace/first-material-direct-20261018/api-final/data/test_direct_original_material_0/direct-material-preview.json');x=json.loads(p.read_text());a=x['after']['delivery_graph_requests'];b=x['before']['delivery_graph_requests'];extra=[r for r in a if r not in b]
print('new rows',len(extra));print(json.dumps(extra,ensure_ascii=False)[:4500]);print('ctxkeys',list(x['context']));print('tables counts',[(n,len(x['before'][n])) for n in ['grants','internal_releases','internal_instances','runs','internal_run_data','delivery_graph_requests']]);print('beforefirstgrant',x['before']['grants'][0])
