from pathlib import Path
import hashlib,json
p=Path('/workspace/first-material-direct-20261018/final-installed');o=Path('/workspace/first-material-direct-review-20261018')
read=lambda n:json.loads((p/n).read_text())
v=read('new-page-proof.json');r=read('installed-result.json');s=read('stopped-run-status.json');b=read('execution-before.json');e=read('execution-after.json');after=read('after-failure.json');before=read('before-edit.json')
assert v['status']==r['status']=='FAIL' and len(v['checks'])==18 and v['phase']=='new-run'
assert b['source']==e['source'] and len(b['source'])==143 and e['equal_before'] is True and b['runner_sha256']==e['runner_sha256'] and b['fixture_script_sha256']==e['fixture_script_sha256']
observed=[z for z in v['requests'] if z['path'].endswith('/runs/'+v['new_run_id']) and z['method']=='GET'];assert len(observed)==2 and all(z['status']==200 and z['response']['status']=='QUEUED' for z in observed)
assert len(after)==len(before)==55 and after['grants']==before['grants']
core={z['id']:z for z in after['runs']};assert core[v['old_run_id']]['status']=='SUCCEEDED' and core[v['check_run_id']]['status']=='SUCCEEDED' and core[v['new_run_id']]['status']=='PAUSED'
assert not any(z['run_id']==v['new_run_id'] for z in after['attempts'])
appids={z['id'] for z in after['internal_app_runs'] if z['run_id']==v['new_run_id']}
assert appids and not any(z['run_id'] in appids for z in after['internal_instance_data'])
stop=[]
for line in (p/'new-process.stdout').read_text().splitlines():
 try:x=json.loads(line)
 except json.JSONDecodeError:continue
 if x.get('event')=='SYNTHETIC_WORKSPACE_STOPPED':stop.append(x)
assert len(stop)==1 and stop[0]['clean'] is True and stop[0]['worker_stopped'] is True
out={'status':'PRIOR_INSTALLED_FAIL_RETAINED','page_checks':18,'new_Run':v['new_run_id'],'actual_page_observations':'two GET200 QUEUED, error null','after_owned_shutdown':'PAUSED on same claimed Worker, no new business typed result; old A and isolated CHECK succeeded','shutdown_clean':True,'all_Grant_rows_equal':True,'all_143_before_after_inputs_equal':True,'actual_cause':'NOT_PROVEN; bounded18-second terminal observer failure plus shutdown state does not uniquely establish starvation/race','snapshot_provenance':'Author exported closed55-table JSON; independently compared JSON only, no physical DB read/hash. stopped-run-status.json is author post-stop export, not reviewer DB observation.','source_files':{n:hashlib.sha256((p/n).read_bytes()).hexdigest() for n in ['new-page-proof.json','installed-result.json','stopped-run-status.json','execution-before.json','execution-after.json','after-failure.json','before-edit.json','new-process.stdout']},'reviewer_product_test_DB_Git_network_execution':False}
(o/'prior-installed-failure-review.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False,indent=2))
