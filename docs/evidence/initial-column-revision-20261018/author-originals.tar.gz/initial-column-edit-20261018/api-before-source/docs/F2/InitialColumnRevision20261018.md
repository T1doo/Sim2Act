# 首版应用保留 Goal、修改现有列绑定

基线 `b58584d101261bccbb43dce56b77f49fc5da0567`。原[分阶段计划 F2-T07/T08](../分阶段开发计划.md#4-f2两条生成路径与最小增量闭环)、[产品 §9.3](../平台产品设计.md#93-修改执行规则)要求可修改声明依赖、独立检查、精确版本批准及保留旧历史。

核查已有：`GoalOnlyRevision20261018.md`及`csv_goal_revisions.py`已覆盖新Goal保留列，`csv_column_revisions.py`已覆盖采用后保留Goal换列；`csv_material_revisions.py`只支持采用后的已有App授权新材料，旧测试明确预授App/B权限，普通空工程没有补该权限入口。`column_patches`只产归档草案，不生成Release或切换原实例。本片不新增Grant或绕过该材料授权缺口。

真实首用缺口：最初Goal v1/spec v1的应用即使只改同一授权CSV的列，也被Preview `goal_version>=2`、服务端 `original+1`和页面按钮条件强制先造下一Goal。空白合成工程的用户无法直接把amount绑定改为quantity并采用到原实例。

## 实现前合同

只补首版保留精确原Goal的列修改：当前已保存Goal仍等于原generation的card/version/snapshot/fingerprint时，允许明确不同数值列；影响请求仅ACTION，沿图扩大APP重验，未知PROJECT仍拒绝。原Goal+1路径保持原字段/计算/GOAL影响，旧冻结记录重构不新增字段。同Goal同列仍拒绝，不解释自然目标，不自动修订Goal或降低检查。

复用原preview双锚、CHECK隔离实例与原Worker、精确Release审批、原实例CAS及typed结果版本。无新executor、工具、Grant、DDL或发布。原草案/Goal/权限/材料/旧Release与结果不重写；同一原实例采用新规格后，明确新Run重算新列，owner独立PENDING、语义UNKNOWN。

最小验收从新的空白合成工程开始，经原页面建两列CSV（amount=10/20、quantity=7/8）和通用完整Goal v1、候选/内部Release/实例，旧Run30；不PUT Goal，页面明确amount→quantity，验证ACTION-only/稳定Goal，单个隔离CHECK真实执行15，分别确认新Release及同iid采用，再显式新Run得到15/v2；冷页读取旧30和新15/相应Release，原历史逐字保持。权限表前后相等，全部普通产品路径，不用fixture授App新材料权限；禁止真实模型。有限兼容检查保留既有Goal+1和no-op拒绝，不扩旧矩阵。

之前b585的两完整runner FAIL、分期PASS及提交核验脚本TypeError原件维持封存；本片是新的独立执行窗口，不将旧失败补成完整链重跑。Git远端/auth不重试，保留9个本地未推送提交；Win/PG/native/真实语义/CI未执行。
