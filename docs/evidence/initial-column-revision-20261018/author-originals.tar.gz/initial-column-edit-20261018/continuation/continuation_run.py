"""Exact new installed wheel, original blank launcher/Worker and real UI HTTP."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import queue
import signal
import sqlite3
import subprocess
import threading
import time
import zipfile

ROOT = Path('/workspace/initial-column-edit-20261018/continuation')
REPO = Path('/workspace/Sim2Act')
PY = Path('/workspace/sim2act-venv/bin/python')
VENV = ROOT / 'installed-venv'
SITE = VENV / 'lib/python3.12/site-packages'
CWD = ROOT / 'outside-checkout'
DATA = ROOT.parent / 'attempt2/首版 只修改列'
WHEEL = ROOT / 'wheel/sim2act-0.1.0-py3-none-any.whl'
DRIVER = ROOT / 'execution-source/tests/initial_column_revision.cjs'
ENV = {k:v for k,v in os.environ.items() if k not in {
    'INTERN_API_TOKEN','SIM2ACT_INTERN_TOKEN','SIM2ACT_TEST_DATABASE_URL',
    'PYTHONPATH','PYTHONHOME','PIP_INDEX_URL','PIP_EXTRA_INDEX_URL'}}
ENV.update(PIP_CONFIG_FILE='/dev/null', NODE_PATH='/workspace/node-tools/node_modules',
           SIM2ACT_DATABASE_URL='synthetic-invalid-dsn-must-not-be-read', SIM2ACT_LIVE_ENABLED='invalid-synthetic-flag')
REPORT = dict(status='RUNNING', started=datetime.datetime.now(datetime.UTC).isoformat(), commands=[], processes=[], checks=[],
              dependencies='explicit shared existing locked directory; no clean-machine dependency download claim')

def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def save(): dump(ROOT / 'installed-result.json', REPORT)

def check(ok, label):
    assert ok, label
    REPORT['checks'].append(label)
    save()

def command(name, args, *, cwd=CWD, timeout=180):
    row=dict(name=name,command=[str(x) for x in args],cwd=str(cwd),started=datetime.datetime.now(datetime.UTC).isoformat())
    REPORT['commands'].append(row);save();start=time.monotonic()
    with (ROOT/(name+'.stdout')).open('wb')as out,(ROOT/(name+'.stderr')).open('wb')as err:
        result=subprocess.run(args,cwd=cwd,env=ENV,stdout=out,stderr=err,timeout=timeout)
    row.update(exit_code=result.returncode,seconds=time.monotonic()-start);save()
    check(result.returncode==0,name+' exit0');print(name+': PASS',flush=True)

def snapshot(name):
    con=sqlite3.connect((DATA/'synthetic-workspace.db').as_uri()+'?mode=ro',uri=True)
    try:
        con.row_factory=sqlite3.Row
        result={}
        for table, in con.execute("SELECT name FROM sqlite_schema WHERE type='table' ORDER BY name").fetchall():
            assert table.replace('_','').isalnum()
            types={row[1]:row[2] for row in con.execute('PRAGMA table_info("'+table+'")')}
            values=[]
            for row in con.execute('SELECT * FROM "'+table+'"'):
                value=dict(row)
                for key in value:
                    if types[key]=='JSON' and value[key] is not None:value[key]=json.loads(value[key])
                values.append(value)
            result[table]=sorted(values,key=lambda row:json.dumps(row,sort_keys=True))
    finally:con.close()
    dump(ROOT/(name+'.json'),result);return result

class Owned:
    def __init__(self,name,new):
        self.name=name;self.lines=[];self.events=queue.Queue();self.out=(ROOT/(name+'.stdout')).open('w');self.err=(ROOT/(name+'.stderr')).open('w')
        args=[str(VENV/'bin/sim2act'),'synthetic-workspace','--data-dir',str(DATA),'--port','0']+(['--new']if new else[])
        self.row=dict(name=name,command=args,cwd=str(CWD));REPORT['processes'].append(self.row)
        self.p=subprocess.Popen(args,cwd=CWD,env=ENV,stdout=subprocess.PIPE,stderr=self.err,text=True,bufsize=1);self.row['pid']=self.p.pid;save()
        def reader():
            for line in self.p.stdout:
                self.out.write(line);self.out.flush();self.lines.append(line)
                try:self.events.put(json.loads(line))
                except json.JSONDecodeError:pass
        self.thread=threading.Thread(target=reader,daemon=True);self.thread.start()
    def ready(self):
        deadline=time.monotonic()+25
        while time.monotonic()<deadline:
            try:
                value=self.events.get(timeout=.1)
                if value.get('event')=='SYNTHETIC_WORKSPACE_READY':self.row['ready']=value;save();return value
            except queue.Empty:
                if self.p.poll() is not None:break
        raise AssertionError(self.name+' READY not observed; raw logs retained')
    def stop(self):
        if self.p.poll() is None:
            self.p.send_signal(signal.SIGINT)
            try:self.p.wait(timeout=15)
            except subprocess.TimeoutExpired:
                self.row['owned_sigterm_required']=True;self.p.terminate();self.p.wait(timeout=10)
        self.thread.join(timeout=3);self.out.close();self.err.close()
        events=[json.loads(x)for x in self.lines if 'SYNTHETIC_WORKSPACE_STOPPED'in x]
        self.row.update(exit_code=self.p.returncode,stopped=events);save()
        check(self.p.returncode==0 and len(events)==1 and all(events[0][key]for key in ['worker_stopped','clean','data_preserved']),self.name+' Ctrl+C clean and data preserved')

def page(name,base,mode,previous=None):
    args=['node',str(DRIVER),base,str(ROOT/(name+'-proof.json')),mode]+([str(previous)]if previous else[])
    row=dict(name=name,command=args,cwd=str(CWD));REPORT['commands'].append(row);save();start=time.monotonic()
    with (ROOT/(name+'.stdout')).open('w')as out,(ROOT/(name+'.stderr')).open('w')as err:
        p=subprocess.Popen(args,cwd=CWD,env=ENV,stdout=subprocess.PIPE,stderr=err,stdin=subprocess.PIPE,text=True,bufsize=1)
        lines=queue.Queue()
        def reader():
            for line in p.stdout:lines.put(line)
        thread=threading.Thread(target=reader,daemon=True);thread.start()
        try:
            while p.poll()is None or not lines.empty():
                if time.monotonic()-start>300:raise AssertionError(name+' observer deadline exceeded')
                try:line=lines.get(timeout=.1)
                except queue.Empty:continue
                out.write(line);out.flush();message=json.loads(line)
                if 'stage'in message:
                    snapshot(message['stage']);p.stdin.write('snapshot-read-only-complete\n');p.stdin.flush();print('snapshot '+message['stage'],flush=True)
            p.wait(timeout=5)
        finally:
            if p.poll()is None:p.terminate();p.wait(timeout=10)
            thread.join(timeout=2);p.stdin.close()
    row.update(exit_code=p.returncode,seconds=time.monotonic()-start);save();check(p.returncode==0,name+' actual page PASS');return json.loads((ROOT/(name+'-proof.json')).read_text())

owned=None
try:
    save();CWD.mkdir()
    command('wheel-build',[str(PY),'-m','pip','wheel','--no-deps','--no-cache-dir','--retries','0','--timeout','15','--index-url','https://pypi.org/simple','--wheel-dir',str(ROOT/'wheel'),'.'],cwd=REPO)
    command('venv-create',[str(PY),'-m','venv',str(VENV)])
    command('wheel-install',[str(VENV/'bin/python'),'-m','pip','install','--no-index','--no-deps',str(WHEEL)])
    (SITE/'explicit-existing-locked-dependencies.pth').write_text('/workspace/sim2act-venv/lib/python3.12/site-packages\n')
    command('import-path',[str(VENV/'bin/python'),'-c',"import sim2act,sim2act.synthetic_workspace,sys,json;print(json.dumps(dict(package=sim2act.__file__,workspace=sim2act.synthetic_workspace.__file__,sys_path=sys.path)))"])
    paths=json.loads((ROOT/'import-path.stdout').read_text());check(Path(paths['workspace']).is_relative_to(SITE)and'/workspace/Sim2Act/src'not in paths['sys_path'],'new coordinated launcher installed outside checkout')
    with zipfile.ZipFile(WHEEL)as archive:
        hashes={name:hashlib.sha256(archive.read(name)).hexdigest()for name in archive.namelist()if name.startswith('sim2act/')and not name.endswith('/')}
    check(all(hashlib.sha256((SITE/name).read_bytes()).hexdigest()==digest for name,digest in hashes.items()),'all139 package files match exact new wheel')
    dump(ROOT/'wheel-files.json',hashes);REPORT['wheel']=dict(bytes=WHEEL.stat().st_size,sha256=hashlib.sha256(WHEEL.read_bytes()).hexdigest());save()
    prior=ROOT.parent/'attempt2';old=json.loads((prior/'new-page-proof.json').read_text());first=json.loads((prior/'installed-result.json').read_text())['processes'][0]['ready']
    before=snapshot('before-continuation')
    check(len(before['runs'])==2 and all(r['status']=='SUCCEEDED'for r in before['runs']),'old result and original CHECK retained as successful before continuation')
    instance=next(r for r in before['internal_instances']if r['id']==old['instance_id']);check(instance['revision']==2 and instance['data_version']==1,'existing adoption already stored; never replay old commit')
    owned=Owned('resume-process',False);second=owned.ready();result=page('resume-page',second['url'],'adopted',prior/'new-page-proof.json');owned.stop();owned=None;after=snapshot('resume-stop')
    for t in ['principals','grants','resources','goal_cards','goal_card_versions','app_drafts','internal_releases','internal_approvals']:
        check(before[t]==after[t],'continuation preserves exact '+t)
    for t in ['internal_app_runs','internal_instance_data','internal_run_bindings','run_contracts','runs','operations','operation_intents']:
        check(all(r in after[t]for r in before[t]),'all original historical rows preserved '+t)
    jobs={r['id']:r for r in after['runs']};ids=[old['old_run_id'],old['check_run_id'],result['new_run_id']]
    check(set(jobs)==set(ids)and all(jobs[r]['status']=='SUCCEEDED'and jobs[r]['fence']==1 for r in ids),'same fixture only old CHECK new jobs, all original fence1')
    check(jobs[ids[0]]['worker_id']==jobs[ids[1]]['worker_id']==first['worker_id']and jobs[ids[2]]['worker_id']==second['worker_id'],'first and continuation Worker claims separately accounted')
    claims=[r for r in after['events']if r['kind']=='CLAIMED'];check(len(claims)==3 and not after['attempts'],'three claims across phased fixture; zero model attempts')
    for rid,expected,version in [(ids[0],'30',1),(ids[2],'15',2)]:
        binding=next(r for r in after['internal_run_bindings']if r['run_id']==rid);typed=next(r for r in after['internal_instance_data']if r['run_id']==binding['app_run_id'])
        check(typed['version']==version and typed['data']['result']['sum']==expected,'correct core/AppRun binding and immutable typed result '+rid)
    check(all(r['method']=='GET' or (r['method']=='POST'and r['path'].endswith('/runs'))for r in result['requests']),'only explicit new Run POST in continuation; accepted revisions never replayed')
    owned=Owned('cold-process',False);third=owned.ready();check(len({first['worker_id'],second['worker_id'],third['worker_id']})==3 and first['principal_id']==second['principal_id']==third['principal_id'],'three exact service Worker identities same principal')
    coldpage=page('cold-page',third['url'],'cold',ROOT/'resume-page-proof.json');owned.stop();owned=None;cold=snapshot('cold-stop')
    check([t for t in after if after[t]!=cold[t]]==['heartbeats'],'all54 nonheartbeat tables unchanged on cold read')
    REPORT.update(status='PASS',finished=datetime.datetime.now(datetime.UTC).isoformat(),scope='same accepted attempt2 fixture continued with coordinated launcher; no revised fresh complete rerun',core_run_ids=ids,first_worker=first['worker_id'],continuation_worker=second['worker_id'],cold_worker=third['worker_id'],real_models=0,native_browser='NOT_RUN',Win='NOT_RUN',PG='NOT_RUN',remote_CI='NOT_RUN');save();print('SAME ADOPTED INSTANCE CONTINUATION AND COLD PASS',flush=True)
except BaseException as error:
    REPORT.update(status='FAIL',error=dict(type=type(error).__name__,message=str(error)),finished=datetime.datetime.now(datetime.UTC).isoformat());save();print('FAIL '+repr(error),flush=True);raise
finally:
    if owned is not None:owned.stop()
