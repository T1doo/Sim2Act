from pathlib import Path
import hashlib,json
r=Path('/workspace/initial-column-edit-20261018/api-run/test_original_goal_first_colum0/initial-column-preview-proof.json')
o=Path('/workspace/next-local-edit-gap-review-20261018/api-preview-json-verification.json')
p=json.loads(r.read_text());before,after=p['before'],p['after'];ctx=p['context'];v=p['preview']
def fp(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
assert len(before)==len(after)==55 and set(before)==set(after)
assert [t for t in before if before[t]!=after[t]]==['delivery_graph_requests']
prior=before['delivery_graph_requests'];now=after['delivery_graph_requests']
assert all(x in now for x in prior)
added=[x for x in now if x not in prior];assert len(added)==2 and len(now)==len(prior)+2
assert {x['kind'] for x in added}=={'csv-goal-revision.v1.preview','csv-goal-revision.v1.preview_seal'}
body=dict(request_key='first-column',expected_revision=ctx['instance_revision'],expected_release_fingerprint=ctx['release_fingerprint'],expected_graph_fingerprint=ctx['graph_fingerprint'],goal_version=1,goal_fingerprint=ctx['goal']['fingerprint'],baseline_column='amount',column='quantity')
assert all(x['app_id']==ctx['instance_id'] and x['principal_id']==ctx['principal_id'] and x['request_key']==body['request_key'] and x['request_fingerprint']==fp(body) and x['snapshot']=={'request':body,'response':v} for x in added)
base={k:x for k,x in v.items() if k!='preview_fingerprint'};assert fp(base)==v['preview_fingerprint']
assert v['context']==ctx and ctx['goal']['version']==ctx['original_goal_version']==1
act=next(x for x in v['baseline_graph']['graph']['nodes'] if x['key']=='action:aggregate')
assert v['impact']['changed_nodes']==[act['id']] and v['impact']['revalidation_scope']=='APP'
assert v['effective_candidate']['goal']==ctx['goal']['snapshot']['content']
assert v['effective_candidate']['manifest']['input_schema']['properties']['column']=={'type':'string','enum':['quantity']}
assert p['noops_preserve_all55'] is True
value={'status':'PASS_PURE_JSON','reviewer_product_or_test_execution':False,'physical_db_access':False,'source_json':str(r),'source_sha256':hashlib.sha256(r.read_bytes()).hexdigest(),'tables':55,'unchanged_nonjournal_tables':54,'old_journal_rows_preserved':len(prior),'new_journal_rows':2,'exact_kinds':sorted(x['kind'] for x in added),'request_fingerprint':fp(body),'preview_fingerprint':v['preview_fingerprint'],'changed_nodes':v['impact']['changed_nodes'],'goal_version':1,'new_fixed_column':'quantity','noop_full55_evidence':'Original executed test equality assertion + exported boolean; no separate rejected-call snapshots saved','positive_full55_evidence':'Independently compared all exported before/after table rows; exact two new journal rows'}
o.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n');print(json.dumps(value,ensure_ascii=False,indent=2))
