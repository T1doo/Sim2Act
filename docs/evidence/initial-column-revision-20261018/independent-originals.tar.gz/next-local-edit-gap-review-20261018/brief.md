# Confirmed next local-edit gap: first-version CSV material replacement

Read-only investigation against the local source and existing contract/qualification descriptions. No Git/status/auth/network, product/test/Worker/model, physical DB or private holdout access. Root remains sole repository writer.

## One genuine missing positive path

A user who creates the original GoalCard CSV app (including through the newly installed blank workspace) cannot directly keep its Goal and selected numeric column while replacing its source material on the same application/instance. The existing replacement chain only opens **after** a Goal/column revision has already been adopted. The user would have to perform an unrelated revision first.

Source evidence:

- `web/csv-goal-revision.js:14–27`: the material entry button is only emitted when `release.snapshot.csv_goal_revision_source` exists.
- `csv_material_revisions.py:61–66`: context requires `parent` plus `goal_mode=KEEP_ADOPTED_GOAL`.
- `csv_column_revisions.py:77–88,116–124`: parent scope requires an original revision reference pointing to this instance; parent requires revision SOURCE and spec revision≥2.
- `csv_goal_revisions.py:72`: the inherited Preview DTO requires Goal version≥2; a first-version material change must explicitly support unchanged Goal v1, rather than loosening ordinary Goal-revision validation.
- `csv_column_revisions.py:189–200`: effective_next requires existing spec≥2 and fixes the column schema. It cannot simply accept a spec1 candidate without defining the initial schema impact.
- Existing `tests/test_csv_material_revisions.py:prepared` first CHECKs/commits/adopts the Goal/column revision (Goal2/current instance revision2), then tests replacement. It does not cover this original Release path.

This is consistent with original product §9.3 steps1–8 (typed impact, preserved history, new checked Release) and F2-T07. It is not a rebranding of GoalOnlyRevision or another material-reuse qualification.

`csv_material_reuse.py` is a different delivered path: a source flow is reused on another existing target app, with a new DAG plan and separate release/instance. It does not replace this original instance's binding and cannot stand in for this gap.

## Existing controller to reuse and necessary scope

Reuse material preview → original isolated CHECK → version approval/commit → same-instance adoption CAS and the original Worker/readback. Add an explicit, narrowly checked original-release branch; do not globally loosen column.parent/release_scope or permit malformed parent chains.

Freeze the exact original Goal version/snapshot/fingerprint unchanged, source A/hash, selected original column, authorized target B/hash, current instance revision/data_version and exact original Release/graph/authority. The original canonical draft/Goal/graph/history remain immutable; the new effective source/definition belongs to the new Release.

An original CSV input schema admits multiple columns. Reusing effective_next would silently narrow it to one fixed column. Either retain that original input domain, or explicitly include ACTION in the source-replacement impact and disclose first-time column fixation. The latter integrates with the existing adopted-parent metadata, which expects a single fixed column. Preserve stable IDs for unrelated nodes, conservatively recheck APP dependencies, reject unknown PROJECT scope and lock conflicts, and keep output/data schemas compatible with old results.

Minimum positive proof: original Goal1/spec1/Release1 business instance with an old successful result; explicitly choose B and original column; isolated CHECK; separately confirm Release2 and adoption; normal Worker recomputes from B on the same instance; old result/Goal/Release/owner record bytes remain and the new Run starts its own PENDING acceptance. A later explicit new input should use B, not cached A output. Do not repeat earlier safety matrices.

## A second hard prerequisite within this same gap: target authority

The current ordinary UI does not authorize a second material for the original application runtime. `apps.persist_csv_candidate:163–176` grants the new appruntime only A's READ/sum permissions. `Store.resource:899–933` grants a newly saved B only to the owner and project runtime. `apps.authorize_source:122–126` and material.source_row require the additional app-runtime intersection, so materials() filters B out. The exposed Grant API lists/revokes; no existing app-B delegation UI was found.

The old material test fixture explicitly clones two exact Grants to the app runtime (`tests/test_csv_material_revisions.py`, prepared helper). That is a disclosed synthetic precondition, not an ordinary-user authorization path. Merely adding the first-version branch while using this fixture cannot prove a blank-workspace user can perform the change.

With a strict no-new-Grant boundary, the implementable slice is limited to applications that already possess B authority. Genuine fresh-user accessibility also requires an explicitly authorized, exact two-permission binding action under the original owner/project authority; it cannot silently use project runtime authority, create a new grant behind a replacement preview, or treat fixture SQL as user interaction. Parent scope must resolve this prerequisite before claiming complete fresh-user delivery.

No other candidate gap is recommended: Goal-only, adopted material, column, natural dependency and archived presentation paths already exist and should not be repeated. This report identifies one specific first-version material-edit gap with its authority prerequisite, not a second feature proposal.
