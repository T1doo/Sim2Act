# Already-adopted instance continuation — static review

Read the frozen continuation_run.py and adopted/cold branches, without reading live result/DB contents or executing product/tests/network/Git. Runner/driver hashes match execution-before; the map contains143 inputs. No new static P1/P2 found.

The script opens the original attempt2 data with a new installed coordinated launcher and explicitly asserts that only old/CHECK jobs exist, both SUCCEEDED, and the business instance is already revision2/data_version1. It does not replay the accepted preview, CHECK, Release approval/commit or adoption. The adopted page reauthorizes and reads the current instance/quantity binding using the original UI before submitting a fresh business Run once. It then requires result15/v2 and PENDING owner.

The runner compares immutable Goal/source/Grant/draft/Release/approval rows, preserves historical Run/AppRun/binding/typed/operation rows, and accounts separately for old/CHECK claims versus the new continuation claim. The cold page reads the two exact historical Run IDs and checks each original Release, with GET-only requests and54 non-heartbeat tables unchanged.

The final closed-file review should independently compare new_release_id against the original accepted adoption target, rather than relying only on the driver's !=oldRelease assertion, and count the actual single new Run POST. The original failed response logs plus exported JSON permit these checks without rerunning.

This is deliberately a same-already-adopted-data continuation. Even a PASS will not be a corrected fresh-full result or prove that the coordinator repairs every API contention/cancellation path. First fatal class remains UNKNOWN; second is proven SQLite BUSY heartbeat failure. A correct no-worker GET/diagnostic outcome does not prove causal repair.

A static-file lookup first used root/static-final.json and returned ENOENT; the actual path is continuation/static-final.json. This was a read-only filename error, not product execution, and no author file was changed. Directory remains unsealed pending closed evidence.
