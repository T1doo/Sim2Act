import hashlib,json,os,stat,zipfile
from pathlib import Path
A=Path('/workspace/initial-column-edit-20261018')
R=Path('/workspace/Sim2Act')
O=Path('/workspace/next-local-edit-gap-review-20261018')
def sha(b): return hashlib.sha256(b).hexdigest()
def read(p): return json.loads(p.read_text())
def dump(x): return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
mraw=(A/'sealed-manifest.json').read_bytes(); m=json.loads(mraw)
assert sha(mraw)=='9995d7f297b6d55a2fbe5acc7c23f612e980f9fe0df3cea9e82053b43cc7dde1'
assert m['file_count']==len(m['files'])==4088
assert sum(x['bytes'] for x in m['files'])==m['bytes']==86735823
assert sha(dump(m['files']))==m['files_projection_sha256']=='ae73cb11292aa0e7a10543c3fbc6fcaed9e08b7f24f3cc8f7fe96d75daca0f68'
non_db=[]; db=[]
for x in m['files']:
 p=A/x['path']; s=p.lstat(); assert stat.S_ISREG(s.st_mode) and s.st_size==x['bytes'],x['path']
 if '.db' in p.name or '.sqlite' in p.name: db.append(x['path']); continue
 assert sha(p.read_bytes())==x['sha256'],x['path']; non_db.append(x)
assert len(m['symlinks'])==14
for x in m['symlinks']:
 p=A/x['path']; assert p.is_symlink() and os.readlink(p)==x['target'],x['path']
actual=[]; links=[]
for base,dirs,files in os.walk(A,followlinks=False):
 for n in dirs[:]:
  p=Path(base)/n
  if p.is_symlink(): links.append(str(p.relative_to(A)));dirs.remove(n)
 for n in files:
  p=Path(base)/n
  if p.is_symlink(): links.append(str(p.relative_to(A)))
  elif p.name!='sealed-manifest.json' or p.parent!=A: actual.append(str(p.relative_to(A)))
assert set(actual)=={x['path'] for x in m['files']}
assert set(links)=={x['path'] for x in m['symlinks']}
f=read(A/'final-source-hashes.json'); assert len(f)==9
for n,h in f.items():
 assert sha((A/'final-source'/n).read_bytes())==h,n
 assert sha((R/n).read_bytes())==h,n
b=read(A/'final-fresh/execution-before.json'); e=read(A/'final-fresh/execution-after.json')
assert len(b['source'])==143 and b['source']==e['source'] and e['equal_before'] is True
assert b['runner_sha256']==e['runner_sha256']==sha((A/'final-fresh/final_fresh_run.py').read_bytes())
for n,h in b['source'].items(): assert sha((A/'final-fresh/execution-source'/n).read_bytes())==h,n
w=read(A/'final-fresh/wheel-files.json');assert len(w)==139 and w==read(A/'continuation/wheel-files.json')
wp=A/'continuation/wheel/sim2act-0.1.0-py3-none-any.whl';wb=wp.read_bytes()
assert len(wb)==940967 and sha(wb)=='7eb1c477f806a5f728201706e2951557afe74e6f10170e876f60f97088700cb4'
site=A/'continuation/installed-venv/lib/python3.12/site-packages'
with zipfile.ZipFile(wp) as z:
 zn={n for n in z.namelist() if n.startswith('sim2act/') and not n.endswith('/')};assert zn==set(w)
 for n,h in w.items():
  assert sha(z.read(n))==h,n
  assert sha((site/n).read_bytes())==h,n
  assert sha((R/'src'/n).read_bytes())==h,n
assert read(A/'author-closure.json')['status']=='PASS'
final=read(A/'final-fresh/installed-result.json');assert final['status']=='PASS' and len(final['checks'])==24 and final['real_models']==0
for n,count in [('new-page-proof.json',20),('cold-page-proof.json',9)]:
 p=read(A/'final-fresh'/n);assert p['status']=='PASS' and len(p['checks'])==count
for n in ['installed-result.json','attempt2/installed-result.json','continuation/installed-result.json']:
 assert read(A/n)['status']=='FAIL',n
static=read(A/'continuation/static-final.json');assert all(x.get('exit_code')==0 for x in static),static
v={'status':'PASS_LIMITED_PURE_FILE_AUDIT','author_manifest_file_sha256':sha(mraw),'author_files_projection_sha256':m['files_projection_sha256'],'author_regular_files':4088,'author_regular_bytes':86735823,'independently_hashed_non_DB_files':len(non_db),'independently_hashed_non_DB_bytes':sum(x['bytes'] for x in non_db),'DB_stat_only':db,'symlinks_readlink_only':14,'exact_tree_membership':True,'final_source_9_frozen_current_equal':f,'final_execution_inputs_143_equal':True,'frozen_execution_copy_143_hashed':True,'runner_before_after_frozen_equal':True,'wheel':{'bytes':len(wb),'sha256':sha(wb),'package_files':139,'zip_installed_current_sources_equal':True},'final_fresh_outer_checks':24,'new_page_checks':20,'cold_page_checks':9,'prior_installed_windows':['FAIL_UNKNOWN_FIRST_CAUSE','FAIL_SQLITE_BUSY_HEARTBEAT','FAIL_CORRECT_SOFTWARE_GRAPH_VERSION_BOUNDARY'],'reviewer_executed_product_tests_Worker_model_network_Git_SQL_DB_read':False,'scope':'stdlib file/JSON/zip/hash/stat/readlink; physical DB stat only; no imports of product or installed venv','notes':['Fresh execution on final gate software completed; prior three failures unchanged.','143 frozen execution inputs include documentation that may subsequently be updated in nine final deliverable files; equality of current package139 and final frozen9 checked separately.','Evidence README not yet present during review; future packaging/commit/push not reviewed.']}
(O/'final-file-verification.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(v,ensure_ascii=False,indent=2))
