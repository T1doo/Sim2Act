from pathlib import Path
import collections,csv,decimal,hashlib,io,json
R=Path('/workspace/initial-column-edit-20261018/final-fresh');O=Path('/workspace/next-local-edit-gap-review-20261018')
def J(n):return json.loads((R/n).read_text())
def F(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def one(rows,**q):
 x=[v for v in rows if all(v.get(k)==z for k,z in q.items())];assert len(x)==1,q;return x[0]
p=J('new-page-proof.json');c=J('cold-page-proof.json');result=J('installed-result.json')
assert result['status']==p['status']==c['status']=='PASS' and len(p['checks'])==20 and len(c['checks'])==9
assert len(p['requests'])==137 and collections.Counter(x['method'] for x in p['requests'])=={'GET':120,'POST':17}
assert len(c['requests'])==53 and all(x['method']=='GET' for x in c['requests'])
for page in (p,c):
 bad=[x for x in page['requests'] if x['status']>=400]
 assert len(bad)==1 and bad[0]['path'].endswith('/protocol/contracts') and bad[0]['status']==400 and bad[0]['response']['error']['code']=='RESOURCE_UNAVAILABLE'
 assert not any(x['method'] in ('PUT','PATCH','DELETE') for x in page['requests'])
 assert page['browser']==page['visual']=='NOT_RUN'
s=J('first-stop.json');cold=J('cold-stop.json');old=J('before-edit.json');bp=J('before-preview.json');ap=J('after-preview.json');adopt=J('after-adopt.json')
assert all(len(x)==55 for x in (s,cold,old,bp,ap,adopt))
assert [k for k in s if s[k]!=cold[k]]==['heartbeats']
assert all(bp[k]==ap[k] for k in bp if k not in ('heartbeats','delivery_graph_requests'))
oldjournal=bp['delivery_graph_requests'];newjournal=ap['delivery_graph_requests'];assert all(x in newjournal for x in oldjournal)
added=[x for x in newjournal if x not in oldjournal];assert len(added)==2 and len(newjournal)==len(oldjournal)+2
assert {x['kind'] for x in added}=={'csv-goal-revision.v1.preview','csv-goal-revision.v1.preview_seal'}
assert added[0]['snapshot']==added[1]['snapshot'] and added[0]['snapshot']['response']==p['preview']
body=added[0]['snapshot']['request'];assert all(x['request_fingerprint']==F(body) and x['app_id']==p['instance_id'] for x in added)
pv=p['preview'];assert pv['preview_fingerprint']==F({k:v for k,v in pv.items() if k!='preview_fingerprint'})
act=one(pv['baseline_graph']['graph']['nodes'],key='action:aggregate');assert pv['impact']['changed_nodes']==[act['id']] and pv['impact']['revalidation_scope']=='APP'
for t in ('principals','grants','resources','goal_cards','goal_card_versions','app_drafts'):
 assert old[t]==s[t],t
for t in ('internal_releases','internal_approvals','internal_app_runs','internal_instance_data','internal_run_bindings','run_contracts','runs','operations','operation_intents','csv_owner_records','csv_owner_seals'):
 assert all(x in s[t] for x in old[t]),t
ids=[p['old_run_id'],p['check_run_id'],p['new_run_id']];assert {x['id'] for x in s['runs']}==set(ids)
workers=[x['ready']['worker_id'] for x in result['processes']];assert len(set(workers))==2
for process in result['processes']:
 assert process['exit_code']==0 and len(process['stopped'])==1 and all(process['stopped'][0][k] for k in ('worker_stopped','clean','data_preserved'))
 assert process['ready']['url'].startswith('http://127.0.0.1:')
for rid in ids:
 job=one(s['runs'],id=rid);assert job['status']=='SUCCEEDED' and job['fence']==1 and job['worker_id']==workers[0]
 assert len([x for x in s['events'] if x['kind']=='CLAIMED' and x['run_id']==rid and x['data']['fence']==1])==1
assert len([x for x in s['events'] if x['kind']=='CLAIMED'])==3 and not s['attempts']
resource=one(s['resources'],id=p['resource_id']);assert resource['hash']==hashlib.sha256(resource['content'].encode()).hexdigest()
rows=list(csv.DictReader(io.StringIO(resource['content'])));assert len(rows)==2
for rid,col,total,ver,release in ((ids[0],'amount','30',1,p['old_release_id']),(ids[2],'quantity','15',2,p['new_release_id'])):
 binding=one(s['internal_run_bindings'],run_id=rid);assert binding['fingerprint']==F(binding['snapshot'])
 app=one(s['internal_app_runs'],id=binding['app_run_id']);data=one(s['internal_instance_data'],run_id=app['id'])
 assert app['instance_id']==p['instance_id'] and app['release_id']==data['release_id']==release
 assert app['input']['column']==col and app['status']=='SUCCEEDED' and app['result_version']==data['version']==ver
 assert app['output']==data['data']['result'] and app['output']['sum']==total and app['output']['count']==2
 assert data['fingerprint']==F(data['data']) and sum(decimal.Decimal(x[col]) for x in rows)==decimal.Decimal(total)
oldrel=one(s['internal_releases'],id=p['old_release_id']);newrel=one(s['internal_releases'],id=p['new_release_id'])
assert oldrel['fingerprint']==F(oldrel['snapshot']) and newrel['fingerprint']==F(newrel['snapshot'])
goal=one(s['goal_card_versions'],card_id=p['goal']['id'],version=1);assert len(s['goal_card_versions'])==1 and goal['fingerprint']==F(goal['snapshot'])
assert oldrel['snapshot']['draft']['candidate']['generation']['goal_snapshot']==pv['context']['goal']['snapshot']==goal['snapshot']
source=newrel['snapshot']['csv_goal_revision_source'];assert source['goal']==pv['context']['goal'] and source['input']=={'column':'quantity'} and source['effective_fingerprint']==pv['effective_fingerprint']
assert pv['effective_candidate']['goal']==oldrel['snapshot']['draft']['candidate']['goal']
inst=one(s['internal_instances'],id=p['instance_id']);oldinst=one(old['internal_instances'],id=p['instance_id']);middle=one(adopt['internal_instances'],id=p['instance_id'])
assert oldinst['revision']==1 and oldinst['release_id']==p['old_release_id'] and oldinst['data_version']==1
assert middle['revision']==inst['revision']==2 and middle['data_version']==1 and inst['data_version']==2 and inst['release_id']==p['new_release_id']
assert any(x.get('kind')=='switch' and x.get('previous_release_id')==p['old_release_id'] and x.get('release_id')==p['new_release_id'] for x in inst['history'])
assert not s['csv_owner_records'] and not s['csv_owner_seals']
post=lambda suffix:[x for x in p['requests'] if x['method']=='POST' and x['path'].endswith(suffix)]
assert len(post('/csv-goal-revisions/previews'))==1 and len(post('/csv-goal-revisions/checks'))==1 and len(post('/csv-goal-revisions/version-approvals'))==1 and len(post('/csv-goal-revisions/adoption-approvals'))==1
assert post('/csv-goal-revisions/adoption-approvals')[0]['request_body']['target_release_id']==p['new_release_id']
assert [x['status'] for x in post('/runs')]==[202,202]
for rid in (ids[0],ids[2]):
 actual=[x['response'] for x in c['requests'] if x['path'].endswith('/runs/'+rid) and x['status']==200]
 assert actual and any(x.get('id')==rid and x.get('release_id')==(p['old_release_id'] if rid==ids[0] else p['new_release_id']) for x in actual)
wheel=J('wheel-files.json')
for page in (p,c):
 assert len(page['assets'])==25
 for asset in page['assets']:assert wheel['sim2act/web/'+asset['src'].lstrip('/')]==asset['sha256']
 css=one(page['requests'],path='/app.css');assert css['status']==200 and css['sha256']==wheel['sim2act/web/app.css']
for page in (p,c):assert page['root_headers']['cache-control']=='no-store' and page['root_headers']['x-content-type-options']=='nosniff' and "script-src 'self'" in page['root_headers']['content-security-policy']
v={'status':'PASS_PURE_JSON_CLOSED_FRESH','reviewer_product_DB_network_Git_execution':False,'new_page':{'checks':20,'requests':137,'GET':120,'POST':17,'JS_assets':25,'CSS':1},'cold_page':{'checks':9,'requests':53,'GET':53,'JS_assets':25,'CSS':1},'optional_protocol400_per_page':1,'worker_ids':workers,'core_run_ids':ids,'business_instance':p['instance_id'],'old_release':p['old_release_id'],'new_release':p['new_release_id'],'unchanged_goal_version':1,'claims':3,'model_attempts':0,'preview_unchanged_tables_except_requests_heartbeat':53,'preview_journal_additions':2,'cold_unchanged_nonheartbeat_tables':54,'results':{'amount':'30/v1','quantity':'15/v2'},'owner':'PENDING, no DECIDE records','full_fresh_scope':'exact final gate software; prior failures remain separate','json_source_files':{n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in ['new-page-proof.json','cold-page-proof.json','first-stop.json','cold-stop.json','before-edit.json','before-preview.json','after-preview.json','after-adopt.json']}}
(O/'fresh-json-verification.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n');print(json.dumps(v,ensure_ascii=False,indent=2))
