# First-column installed page/runner — static review

Read `tests/initial_column_revision.cjs` and `/workspace/initial-column-edit-20261018/installed_run.py` without execution. No repository writes, network/Git, product/test/Worker/model or physical DB access.

No static product/authority blocker found. This is a new complete positive path using the newly installed ordinary synthetic console service: no project/Goal/app/result seed, no app-B permission fixture, no Goal PUT, and no driver-owned business Worker. The real service owns the original Worker thread and must claim old/CHECK/new jobs itself. The page uses original handlers and records actual loopback HTTP/asset hashes.

The driver checks the original result30/v1; originalGoal1 ACTION-only preview with one POST under double click; separate CHECK consent; separate Release consent; no automatic adoption; explicit original-instance CAS to revision2 and fixed quantity; new explicit business result15/v2 and PENDING owner; then two exact historical Runs/Release bindings in a cold GET-only page. It does not claim manual ACCEPT or real target semantics. SameGoal/sameColumn is tested as disabled here, while the finite API node already tests server rejection.

The runner uses a newly built wheel/new venv, disclosed existing locked dependency path, cwd outside checkout, exact package/installed-file hashes and owned process handles. It reads only its own synthetic DB in mode=ro to export snapshots; the independent reviewer will only compare those JSON files. CoreRun/AppRun typed associations correctly follow `internal_run_bindings`. It requires exactly three SUCCEEDED core Runs/fence1 on the first Worker, three CLAIMED events and no model Attempt, preserves original historical rows and compares all54 non-heartbeat tables across cold reopen.

There are **five** actual stdin snapshot checkpoints: before-edit, before-preview, after-preview, after-adopt, after-new-run. The driver only waits for acknowledgement that the read-only snapshot finished; it does not request Worker driving or fake a result. A prequalification message's four-stage description should not determine final counts.

Two nonblocking precision notes were sent: assert the CSS GET status200 before injecting it; preserve native/visual NOT_RUN despite computed display/hidden visibility checks. The 15/18/20-second page waits and outer300-second observer budget are test limits, not product lease changes. Any failure must remain in original evidence and be classified from the closed traces.

The inspected live source is not yet a frozen/runtime qualification. Source/driver/runner hashes and actual first/cold windows will need a final byte bridge after closure; no PASS is anticipated from this review.
