# Bounded synthetic launcher wait/diagnostics — additional scope review

The third production-file change is explicit and limited to this test-only installed entry. `settings_for` adds a fixed SQLite connection timeout30; the user-path `?` rejection and parsed database path equality remain before the first connection. No Store, Worker, ordinary Settings/PG, lease, deadline, authority or success gate changed. Waiting longer does not grant a lease extension: original expired guards still reject. A constructor proof observing two30000ms connections establishes the setting only, not original failure causality or concurrency correctness.

The generic service exception log adds only exception class, exact-int SQLite code when available, and at most32 stack frames of basename/function/line. It does not serialize exception messages, SQL, parameters, locals, resource text or credentials. Existing failclosed service termination remains. No new retry/resend/recovery rule is introduced.

The source AST differs from the b585 launcher only in settings_for/serve plus traceback import; db.py/worker.py/config.py remain byte-identical. The original failure's exception class cannot be recovered, and its root cause remains UNKNOWN. A future fresh success must not be used to infer that the prior error was definitely a lock timeout.

Separately, an independent comparison of the author's closed after-failure/after-diagnostic55-table JSON exports confirms that diagnostic Worker `worker_45c4063ed44c461192392b551ccd7ec3` only added its single heartbeat. The two original Runs remain SUCCEEDED, claims remain2 and model Attempts remain0. Thus this was a distinct mutating heartbeat probe, not a read-only operation or a replay of the approval request. Its once=false does not reproduce the original concurrent failure.

No remaining static P1/P2 found in this bounded launcher adjustment. The new wheel/full-path execution is still pending; no runtime qualification or performance claim is inferred. The reviewer did not execute product/tests/Worker, open/hash a DB, or use Git/network.
