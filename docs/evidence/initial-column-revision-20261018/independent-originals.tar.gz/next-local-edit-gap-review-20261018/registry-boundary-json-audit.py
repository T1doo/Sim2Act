from pathlib import Path
import json,hashlib
R=Path('/workspace/initial-column-edit-20261018');O=Path('/workspace/next-local-edit-gap-review-20261018')
def J(p):return json.loads(p.read_text())
def FP(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def registry(m):return {Path(n).name:h for n,h in m.items() if n.startswith('sim2act/') and n.endswith('.py') and '/' not in n.removeprefix('sim2act/') and Path(n).name!='config.py'}
s=J(R/'continuation/before-continuation.json');old=registry(J(R/'attempt2/wheel-files.json'));new=registry(J(R/'continuation/wheel-files.json'))
assert set(old)==set(new);changed=[n for n in old if old[n]!=new[n]];assert changed==['synthetic_workspace.py'],changed
refs=[]
for row in s['delivery_graph_source_versions']:
 snap=row['snapshot'];definition=snap['definition']
 if 'registry_versions' not in definition:continue
 assert row['fingerprint']==FP(snap) and definition['registry_versions']==old
 refs.append({'logical_key':row['logical_key'],'revision':row['revision'],'stored_fingerprint':FP(definition),'new_definition_fingerprint':FP({**definition,'registry_versions':new})})
assert len(refs)==3 and all(x['stored_fingerprint']!=x['new_definition_fingerprint'] for x in refs)
p=J(R/'continuation/resume-page-proof.json');runposts=[x for x in p['requests'] if x['method']=='POST' and x['path'].endswith('/runs')]
assert len(runposts)==1 and runposts[0]['status']==409
rejection=runposts[0]['response']['error']['submission_rejection'];assert rejection['acceptance']=='NOT_ACCEPTED' and rejection['previous_request']=='ABSENT' and rejection['phase']=='TX_ROLLED_BACK'
v={'status':'PASS_PURE_FILE_VERSION_BOUNDARY_EXPLANATION','product_window_status':'FAIL_NOT_QUALIFIED','reviewer_product_DB_network_execution':False,'registry_python_files':len(old),'changed_registry_paths':changed,'old_launcher_sha256':old[changed[0]],'new_launcher_sha256':new[changed[0]],'affected_stored_registry_definitions':refs,'new_Run_POST':{'status':409,'error':runposts[0]['response']['error']['message'],'submission_rejection':rejection},'observer_null_GET':[x['path'] for x in p['requests'] if x['path'].endswith('/runs/null')],'required_qualification':'new empty workspace complete positive path on exact final wheel; do not rederive/reapprove/rewrite old version evidence','first_failure_cause':'UNKNOWN','second_failure_cause':'SQLITE_BUSY heartbeat','continuation_failure_cause':'package registry mismatch, correct safety refusal; no causal gate-repair proof'}
(O/'registry-boundary-json-verification.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n');print(json.dumps(v,ensure_ascii=False,indent=2))
