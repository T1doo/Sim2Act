# Selected smaller slice: first CSV column revision with unchanged Goal

The initial material-replacement gap in `brief.md` is real but remains unimplemented: ordinary fresh users do not possess the second material's app-runtime authority, and this phase must not add Grants. The selected implementation should therefore be **same existing material, original Goal unchanged, explicitly change amount→quantity, checked new Release adopted by the same business instance**.

This is distinct from the older column-patches preview. `ColumnBindingPatchQuickstart.md` explicitly states that its draft/check do not add a Release or switch a running instance. The current revision chain does support adopted-version KEEP_ADOPTED_GOAL, but initially requires an unrelated Goal bump.

## Exact existing barriers

- `csv_goal_revisions.Preview.goal_version` has `ge=2` (line72).
- Initial `calculate` requires `body.goal_version == original_goal_version+1` (line259).
- `web/csv-goal-revision.js` disables preview when no parent and current Goal is not original+1 (line262), and tells users to save the next Goal first (baseline/status text). These need a precise unchanged-original path.
- `changedGoal` correctly distinguishes a real content change for same-column proposals. Keep the sameGoal+sameColumn rejection; a different column does not need a Goal content change.

No further >=2/+1 acceptance gate was found in the bounded `checked`, bound/job verification, version approval and adoption paths: they freeze/rebuild the exact Goal object/fingerprint. Their checks, worker/fence/authority/source and immutable receipt machinery should remain intact.

## Minimum contract

Accept the initial original Goal only when current Goal version equals the source generation's original version **and the entire Goal snapshot/fingerprint equals the frozen original Release generation**. The old explicit-next-Goal path must still accept only original+1 and retain its former impact behavior. A later unrelated head does not authorize keeping a stale original goal.

For unchanged Goal and an explicit different column, the requested change set is ACTION-only. The initial candidate admits multiple input columns; the existing effective builder fixes the selected column in the new spec. Disclose and count this first-time input constraint change as ACTION impact; do not label it preservation of the entire original action definition. Goal/source stable IDs and content stay unchanged, while affected checks/packaging propagate through the original graph.

Avoid adding a new unconditional context field that changes old sealed NEXT_GOAL preview reconstruction. Existing accepted +1 journal bodies and fingerprints must remain reconstructible; a branch-specific discriminator, if needed, must not change the old branch's canonical output.

## Minimum actual acceptance

Use one normally created original Goal1/spec1 app with existing same-CSV amount/quantity permissions and an old sum30 result. Without editing Goal or granting anything new, select amount→quantity; preview the ACTION impact; explicitly run isolated CHECK; separately approve/commit Release2 and same-instance adoption; submit a new normal Worker Run and get sum15/version2. Preserve original Goal/draft/Release/result/owner record bytes and exact IDs; new Run acceptance is PENDING, old acceptance projection may be STALE under its existing gate. Verify the exact sameGoal+sameColumn no-op rejection without any write. Do not repeat the adopted material/column or natural dependency matrices.

Static conclusion: a genuine first-use gap, independently useful and inside the existing executor/authority boundary. No product/test/DB/HTTP/Git/network execution by this reviewer. Implementation and runtime qualification remain pending.
