"""Offline feasibility only. Not a production replacement or G0 benchmark."""

import hashlib
import json
import statistics
import time
from pathlib import Path

import pytest
from conftest import env
from test_cold_accounted_sqlite import forbid_execution as forbid_execution
from test_pb_spec_production_controller import prepare_pb
from sqlalchemy import create_engine, select

from sim2act import natural_live_admission as gate
from sim2act import natural_spec_runtime as rt
from sim2act.db import meta


class Buffer:
    def __init__(self):
        self.stream = rt._ColdGraphBytesIO()
        self.busy = False

    def encode(self, value):
        if self.busy:
            return rt._cold_graph_bytes(value)
        self.busy = True
        try:
            self.stream.seek(0)
            self.stream.write(b'SIM2ACT_COLD_GRAPH_PICKLE_V2\x00')
            rt._ColdGraphPickler(self.stream, protocol=5).dump(value)
            self.stream.truncate(self.stream.tell())
            return self.stream.getvalue()
        except BaseException:
            self.stream = rt._ColdGraphBytesIO()
            raise
        finally:
            self.busy = False


@pytest.fixture
def contract(tmp_path, monkeypatch):
    monkeypatch.delenv('SIM2ACT_TEST_DATABASE_URL', raising=False)
    monkeypatch.delenv('SIM2ACT_RECORD_PG_CONFIG', raising=False)
    generator = env.__wrapped__(tmp_path)
    base = next(generator)
    data = None
    try:
        data, binding = prepare_pb(base, tmp_path)
        yield binding.contract
    finally:
        if data is not None and data[2] is not base[2]:
            data[2].close()
        with pytest.raises(StopIteration):
            next(generator)


def test_bytes_and_cost_on_actual_prepare_pb_contract(contract, tmp_path):
    raw = gate._trial_typed_storage(gate.PBTrialContract, contract)
    pool = Buffer()
    saved = rt._cold_graph_bytes(raw)
    old = pool.encode(raw)
    assert old == saved
    for value in (raw, {'different': []}, raw):
        assert pool.encode(value) == rt._cold_graph_bytes(value)
    assert old == saved  # held bytes survive later overwrite/truncate.
    del old
    rounds = []
    for n in range(6):
        costs = {}
        for name in (('fresh', 'buffer') if n % 2 == 0 else ('buffer', 'fresh')):
            encode = rt._cold_graph_bytes if name == 'fresh' else pool.encode
            start = time.thread_time()
            for _ in range(2000):
                hashlib.sha256(encode(raw)).digest()
            costs[name] = time.thread_time() - start
        rounds.append(costs)
    report = dict(actual_contract_class=type(contract).__name__,
        codec_bytes=len(saved), rounds=rounds, iterations=2000,
        fresh_median=statistics.median(x['fresh'] for x in rounds),
        buffer_median=statistics.median(x['buffer'] for x in rounds),
        mock_calls=0, scope='actual prepare_pb contract only; not complete G0 graph')
    Path('/tmp/sim2act-input-bytes-proof-20261021/buffer-contract-cost.json').write_text(json.dumps(report,indent=2))


def test_actual_closed_synthetic_sql_rows_buffer_cost():
    path = Path('/tmp/sim2act-tail-cpu-20261021/final-run/test_one_complete_identity_pre0/candidate/fixture.db')
    before = hashlib.sha256(path.read_bytes()).hexdigest()
    engine = create_engine('sqlite:///file:' + str(path) + '?mode=ro&uri=true')
    try:
        with engine.connect() as connection:
            values = {table.name: list(connection.execute(select(table)).mappings())
                for table in meta.sorted_tables}
        saved = rt._cold_graph_bytes(values)
        pool = Buffer()
        assert pool.encode(values) == saved
        rounds = []
        for n in range(6):
            costs = {}
            for name in (('fresh', 'buffer') if n % 2 == 0 else ('buffer', 'fresh')):
                encode = rt._cold_graph_bytes if name == 'fresh' else pool.encode
                started = time.thread_time()
                for _ in range(50):
                    hashlib.sha256(encode(values)).digest()
                costs[name] = time.thread_time() - started
            rounds.append(costs)
        report = dict(source=str(path), source_sha256=before,
            rows=sum(map(len, values.values())), codec_bytes=len(saved), rounds=rounds,
            iterations=50, fresh_median=statistics.median(x['fresh'] for x in rounds),
            buffer_median=statistics.median(x['buffer'] for x in rounds), mock_calls=0,
            scope='real closed synthetic SQL row snapshot; NOT the original G0 input graph')
        Path('/tmp/sim2act-input-bytes-proof-20261021/buffer-row-cost.json').write_text(json.dumps(report,indent=2))
    finally:
        engine.dispose()
    assert hashlib.sha256(path.read_bytes()).hexdigest() == before
