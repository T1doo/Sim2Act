import datetime,hashlib,json,pathlib,subprocess,xml.etree.ElementTree as ET
root=pathlib.Path('/workspace/integration-quality-20261019');repo=pathlib.Path('/workspace/Sim2Act')
run=json.loads((root/'qualified-v8/execution.json').read_text())
assert run['exit_code']==0 and run['inputs_unchanged']
cases=ET.parse(root/'qualified-v8/results.xml').getroot().findall('.//testcase')
assert len(cases)==20 and not any(c.find('failure') is not None or c.find('error') is not None or c.find('skipped') is not None for c in cases)
before=json.loads((root/'qualified-v8/inputs-before.json').read_text());after=json.loads((root/'qualified-v8/inputs-after.json').read_text());assert before==after
for f,h in before.items():assert hashlib.sha256((repo/f).read_bytes()).hexdigest()==h,f
mypy=json.loads((root/'mypy-v8/execution.json').read_text());assert mypy['exit_code']==0 and mypy['source_files']==113 and mypy['inputs_unchanged']
mb=json.loads((root/'mypy-v8/inputs-before.json').read_text());ma=json.loads((root/'mypy-v8/inputs-after.json').read_text());assert mb==ma
for f,h in mb.items():assert hashlib.sha256((repo/f).read_bytes()).hexdigest()==h
candidate=json.loads((root/'candidate-v8/manifest.json').read_text())
for f,h in candidate.items():assert before[f]==h
head=subprocess.check_output(['git','-c','core.fsmonitor=false','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head=='614ef1967903fc875855c674f9662294de7b11c7'
paths=list(before);queries=''.join(head+':'+p+'\n' for p in paths).encode()
r=subprocess.run(['git','-c','core.fsmonitor=false','cat-file','--batch'],cwd=repo,input=queries,capture_output=True);assert r.returncode==0
at=0
for f in paths:
 end=r.stdout.index(b'\n',at);header=r.stdout[at:end].split();assert header[1]==b'blob',f
 length=int(header[2]);blob=r.stdout[end+1:end+1+length];assert hashlib.sha256(blob).hexdigest()==before[f],f
 at=end+2+length
proofs=list((root/'qualified-v8/tmp').rglob('ACTUAL_V2_SEVEN_SLOTS.json'));assert len(proofs)==1
v2=json.loads(proofs[0].read_text());assert v2['actual_sends']==7 and v2['stage_send_counts']==[3,2,2] and v2['actual_model_requests']==0 and v2['synthetic_qualification_override'] is True
assert len(v2['wire'])==7 and v2['accounting']['reserved_requests']==7 and v2['accounting']['usage_status']=='KNOWN'
slots=v2['accounting']['ledger']['slots'];assert len(slots)==7 and all(s['accepted'] for s in slots)
assert all(b['reserved_at']-a['reserved_at']>=60 for a,b in zip(slots,slots[1:]))
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'code_checkpoint':head,'tests':len(cases),'test_exit_code':run['exit_code'],'input_files':len(before),'inputs_unchanged_and_current':True,'committed_blobs_equal_tested_inputs':len(paths),'mypy_source_files':113,'mypy_exit_code':0,'synthetic_v2_sends':[3,2,2],'real_model_calls':0,'v2_proof_path':str(proofs[0].relative_to(root)),'v2_proof_sha256':hashlib.sha256(proofs[0].read_bytes()).hexdigest(),'cases':[{'classname':c.get('classname'),'name':c.get('name'),'seconds':float(c.get('time'))} for c in cases]}
(root/'FINAL-AUDIT.json').write_text(json.dumps(receipt,indent=2));print(json.dumps({k:v for k,v in receipt.items() if k!='cases'}))
