import datetime
import hashlib
import json
import pathlib
import subprocess
import xml.etree.ElementTree as ET

root = pathlib.Path('/workspace/integration-quality-20261019')
repo = pathlib.Path('/workspace/Sim2Act')
labels = ['qualified-v10-v2', 'qualified-v10-rest']
cases = []
receipts = {}
inputs = None
for label in labels:
    path = root / label
    run = json.loads((path / 'execution.json').read_text())
    assert run['exit_code'] == 0 and run['inputs_unchanged'] and not run['timed_out'], label
    assert run['real_transport_forbidden'] and run['outer_timeout_seconds'] == 900
    before = json.loads((path / 'inputs-before.json').read_text())
    after = json.loads((path / 'inputs-after.json').read_text())
    assert before == after
    if inputs is None:
        inputs = before
    assert inputs == before
    selected = ET.parse(path / 'results.xml').getroot().findall('.//testcase')
    assert len(selected) == (1 if label.endswith('-v2') else 21)
    assert not any(c.find(tag) is not None for c in selected for tag in ('failure', 'error', 'skipped'))
    cases.extend(selected)
    receipts[label] = run
assert len(cases) == 22 and len(inputs) == 684
for name, sha in inputs.items():
    assert hashlib.sha256((repo / name).read_bytes()).hexdigest() == sha, name

mypy = json.loads((root / 'mypy-v9/execution.json').read_text())
assert mypy['exit_code'] == 0 and mypy['source_files'] == 113 and mypy['inputs_unchanged']
mb = json.loads((root / 'mypy-v9/inputs-before.json').read_text())
ma = json.loads((root / 'mypy-v9/inputs-after.json').read_text())
assert mb == ma
for name, sha in mb.items():
    assert inputs[name] == sha

candidate = json.loads((root / 'candidate-v10/manifest.json').read_text())
assert len(candidate) == 12
for name, sha in candidate.items():
    assert inputs[name] == sha
head = subprocess.check_output(['git', '-c', 'core.fsmonitor=false', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert head == 'aae3abd9c5c422b199f82e66570b4bd71be49621'
tracked = set(subprocess.check_output(['git', '-c', 'core.fsmonitor=false', 'ls-files', '-z'], cwd=repo).decode().split('\0'))
paths = [name for name in inputs if name in tracked]
generated = {name: sha for name, sha in inputs.items() if name not in tracked}
assert len(paths) == 678 and len(generated) == 6
assert all(name.startswith('src/sim2act.egg-info/') for name in generated)
for name, sha in generated.items():
    captured = root / 'generated-inputs' / name
    captured.parent.mkdir(parents=True, exist_ok=True)
    captured.write_bytes((repo / name).read_bytes())
    assert hashlib.sha256(captured.read_bytes()).hexdigest() == sha
queries = ''.join(head + ':' + name + '\n' for name in paths).encode()
result = subprocess.run(['git', '-c', 'core.fsmonitor=false', 'cat-file', '--batch'], cwd=repo, input=queries, capture_output=True, check=True)
at = 0
for name in paths:
    end = result.stdout.index(b'\n', at)
    header = result.stdout[at:end].split()
    assert header[1] == b'blob', name
    size = int(header[2])
    blob = result.stdout[end + 1:end + 1 + size]
    assert hashlib.sha256(blob).hexdigest() == inputs[name], name
    at = end + 2 + size

proofs = list((root / 'qualified-v10-v2/tmp').rglob('ACTUAL_V2_SEVEN_SLOTS.json'))
assert len(proofs) == 1
v2 = json.loads(proofs[0].read_text())
assert v2['actual_sends'] == 7 and v2['stage_send_counts'] == [3, 2, 2]
assert v2['actual_model_requests'] == 0 and v2['synthetic_qualification_override'] is True
assert len(v2['wire']) == 7 and v2['accounting']['reserved_requests'] == 7
assert v2['accounting']['usage_status'] == 'KNOWN'
slots = v2['accounting']['ledger']['slots']
assert len(slots) == 7 and all(slot['accepted'] for slot in slots)
assert all(b['reserved_at'] - a['reserved_at'] >= 60 for a, b in zip(slots, slots[1:]))
assert v2['contract']['caps']['lease_seconds'] == 30 and v2['contract']['caps']['run_seconds'] == 300
assert v2['contract']['stage_handoff_seconds'] == 900
heartbeat_logs = list((root / 'qualified-v10-v2/observer').glob('*.heartbeat.jsonl'))
heartbeat_rows = [json.loads(line) for file in heartbeat_logs for line in file.read_text().splitlines()]
actual_background_commits = [row for row in heartbeat_rows if row['phase'] == 'return' and row['run_id'] is not None
                             and row['thread_name'] != 'MainThread' and row['renewed_until'] is not None]
assert actual_background_commits, 'Actual background heartbeat must remain exercised'

receipt = dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(), code_checkpoint=head,
               tests=len(cases), execution_receipts=receipts, input_files=len(inputs),
               inputs_unchanged_and_current=True, committed_blobs_equal_tested_inputs=len(paths),
               generated_inputs_with_separate_byte_archive=generated,
               mypy_source_files=113, mypy_exit_code=0, synthetic_v2_sends=[3, 2, 2], real_model_calls=0,
               actual_background_heartbeat_commits=len(actual_background_commits),
               v2_proof_path=str(proofs[0].relative_to(root)),
               v2_proof_sha256=hashlib.sha256(proofs[0].read_bytes()).hexdigest(),
               cases=[dict(classname=c.get('classname'), name=c.get('name'), seconds=float(c.get('time'))) for c in cases])
(root / 'FINAL-AUDIT.json').write_text(json.dumps(receipt, indent=2))
print(json.dumps({key: value for key, value in receipt.items() if key != 'cases'}))
