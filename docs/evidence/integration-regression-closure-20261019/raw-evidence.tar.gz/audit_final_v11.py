"""Attribute completed checks to their exact frozen inputs, without a merged-SHA PASS."""
import datetime
import hashlib
import json
import pathlib
import sqlite3
import subprocess
import xml.etree.ElementTree as ET

root = pathlib.Path('/workspace/integration-quality-20261019')
repo = pathlib.Path('/workspace/Sim2Act')
old_sha = 'aae3abd9c5c422b199f82e66570b4bd71be49621'
new_sha = '08a966cf5413295d49cdb942287e83d9f72ac6c7'
git = ['git', '-c', 'core.fsmonitor=false']


def execution(label, expected, failures=0):
    path = root / label
    receipt = json.loads((path / 'execution.json').read_text())
    assert receipt['inputs_unchanged'] and not receipt['timed_out']
    assert receipt['exit_code'] == (1 if failures else 0)
    assert receipt['real_transport_forbidden'] and receipt['outer_timeout_seconds'] == 900
    before = json.loads((path / 'inputs-before.json').read_text())
    assert before == json.loads((path / 'inputs-after.json').read_text())
    cases = ET.parse(path / 'results.xml').getroot().findall('.//testcase')
    assert len(cases) == expected
    assert sum(case.find('failure') is not None for case in cases) == failures
    assert not any(case.find(tag) is not None for case in cases for tag in ('error', 'skipped'))
    return before, dict(receipt=receipt, junit_cases=len(cases),
                        passed=expected - failures, failed=failures,
                        cases=[dict(classname=c.get('classname'), name=c.get('name'),
                                    seconds=float(c.get('time')),
                                    failed=c.find('failure') is not None) for c in cases])


def committed(sha, inputs):
    tracked = set(subprocess.check_output(git + ['ls-tree', '-r', '--name-only', '-z', sha], cwd=repo).decode().split('\0'))
    paths = [name for name in inputs if name in tracked]
    generated = {name: value for name, value in inputs.items() if name not in tracked}
    assert len(generated) == 6 and all(name.startswith('src/sim2act.egg-info/') for name in generated)
    queries = ''.join(sha + ':' + name + '\n' for name in paths).encode()
    result = subprocess.run(git + ['cat-file', '--batch'], cwd=repo, input=queries, capture_output=True, check=True)
    at = 0
    for name in paths:
        end = result.stdout.index(b'\n', at)
        header = result.stdout[at:end].split()
        assert header[1] == b'blob', name
        size = int(header[2])
        assert hashlib.sha256(result.stdout[end + 1:end + 1 + size]).hexdigest() == inputs[name], name
        at = end + size + 2
    for name, sha256 in generated.items():
        captured = root / 'generated-inputs' / name
        captured.parent.mkdir(parents=True, exist_ok=True)
        captured.write_bytes((repo / name).read_bytes())
        assert hashlib.sha256(captured.read_bytes()).hexdigest() == sha256
    return dict(committed_input_blobs=len(paths), generated_inputs_archived_separately=generated)


old_v2, v2_receipt = execution('qualified-v10-v2', 1)
old_rest, rest_receipt = execution('qualified-v10-rest', 21, 1)
assert old_v2 == old_rest and len(old_v2) == 684
failed = [case for case in rest_receipt['cases'] if case['failed']]
assert len(failed) == 1 and failed[0]['name'] == 'test_actual_nodes_and_atomic_pending_checklist[False-sequential]'
new_guard, guard_receipt = execution('ordinary-proof-v11', 1)
new_source, source_receipt = execution('ordinary-source-v11', 1)
assert new_guard == new_source and len(new_source) == 685
for name, sha in new_source.items():
    assert hashlib.sha256((repo / name).read_bytes()).hexdigest() == sha, name
old_identity = committed(old_sha, old_v2)
new_identity = committed(new_sha, new_source)
assert old_identity['committed_input_blobs'] == 678 and new_identity['committed_input_blobs'] == 679
changed = subprocess.check_output(git + ['diff', '--name-only', old_sha, new_sha], cwd=repo, text=True).splitlines()
assert sorted(changed) == sorted(['src/sim2act/goal_applications.py', 'src/sim2act/pa_trial_dispatch.py', 'tests/test_ordinary_generation_reads.py'])
for version, sha, inputs, count in [('v10', old_sha, old_v2, 12), ('v11', new_sha, new_source, 14)]:
    candidate = json.loads((root / ('candidate-' + version) / 'manifest.json').read_text())
    assert len(candidate) == count
    assert all(inputs[name] == value for name, value in candidate.items())
assert subprocess.check_output(git + ['rev-parse', 'HEAD'], cwd=repo, text=True).strip() == new_sha

mypy = json.loads((root / 'mypy-v11/execution.json').read_text())
assert mypy['exit_code'] == 0 and mypy['source_files'] == 113 and mypy['inputs_unchanged']
mb = json.loads((root / 'mypy-v11/inputs-before.json').read_text())
assert mb == json.loads((root / 'mypy-v11/inputs-after.json').read_text())
assert all(new_source[name] == sha for name, sha in mb.items())
ruff = json.loads((root / 'static-v11/ruff-comparison.json').read_text())
assert ruff['candidate_diagnostics'] == 110 and ruff['baseline_diagnostics'] == 117 and not ruff['new_diagnostics']

proof_path = next((root / 'qualified-v10-v2/tmp').rglob('ACTUAL_V2_SEVEN_SLOTS.json'))
v2 = json.loads(proof_path.read_text())
assert v2['actual_sends'] == 7 and v2['stage_send_counts'] == [3, 2, 2]
assert v2['actual_model_requests'] == 0 and v2['synthetic_qualification_override'] is True
slots = v2['accounting']['ledger']['slots']
assert len(slots) == 7 and all(slot['accepted'] for slot in slots)
assert v2['accounting']['reserved_requests'] == 7 and v2['accounting']['usage_status'] == 'KNOWN'
assert all(b['reserved_at'] - a['reserved_at'] >= 60 for a, b in zip(slots, slots[1:]))
proof_guard = json.loads(next((root / 'ordinary-proof-v11/tmp').rglob('ordinary-proof-reuse.json')).read_text())
assert proof_guard['actual_mock_generation_requests'] == 3 and proof_guard['expiry_without_write_refused']
assert proof_guard['write_invalidated_and_damage_refused'] and proof_guard['present_null_not_ordinary']

database = next((root / 'ordinary-source-v11/tmp').rglob('fixture.db'))
with sqlite3.connect('file:' + str(database) + '?mode=ro', uri=True) as conn:
    conn.row_factory = sqlite3.Row
    jobs = [dict(row) for row in conn.execute('SELECT id,status,fence,worker_id,created_at,lease_until,error FROM runs')]
    assert sorted(job['status'] for job in jobs) == ['PARTIAL', 'SUCCEEDED']
    source_run = next(job for job in jobs if job['status'] == 'SUCCEEDED')
    counts = [dict(row) for row in conn.execute('SELECT status,mode,count(*) AS count FROM attempts WHERE run_id=? GROUP BY status,mode', (source_run['id'],))]
    assert counts == [dict(status='VERIFIED', mode='MOCK', count=2)]
    typed = [dict(row) for row in conn.execute('SELECT instance_id,version,run_id,release_id,data FROM internal_instance_data')]
    assert len(typed) == 1
(root / 'ordinary-source-v11-result.json').write_text(json.dumps(dict(jobs=jobs, source_attempts=counts, typed_results=typed), indent=2))

receipt = dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(), source_checkpoint=new_sha,
    prior_checkpoint=old_sha, scope='Version-attributed evidence; no single-SHA 23-PASS claim',
    v10=dict(source_sha=old_sha, v2=v2_receipt, selected_rest=rest_receipt, input_identity=old_identity,
             combined_passed=21, combined_failed=1, synthetic_v2_sends=[3, 2, 2]),
    v11=dict(source_sha=new_sha, exact_ordinary_source=source_receipt, ordinary_proof_guards=guard_receipt,
             input_identity=new_identity, source_files_mypy=113, mypy_exit_code=0,
             selected_new_tests_passed=2, real_model_calls=0),
    historical_failure_retained=True, v11_full_v2_rerun=False, v11_full_previous_suite_rerun=False,
    bound_trial_branch='Independent source review: existing non-None binding branches unchanged; runtime V2 belongs to v10 only',
    whole_ruff='FAIL110, baseline117, no additions', remote_ci='Unknown, earlier read-only API Forbidden',
    actual_paid_evidence='UNKNOWN; synthetic test does not establish real account fees')
(root / 'FINAL-AUDIT.json').write_text(json.dumps(receipt, indent=2))
print(json.dumps({key: value for key, value in receipt.items() if key not in ('v10', 'v11')}))
