import copy, subprocess, types
from sim2act import local_record_apps as now
from sim2act.contracts import Limits
from sim2act.errors import DomainError
old=types.ModuleType('sim2act._review_legacy_records');old.__package__='sim2act'
exec(compile(subprocess.check_output(['git','show','HEAD:src/sim2act/local_record_apps.py'],text=True),'<HEAD legacy local records>','exec'),old.__dict__)
body=dict(name='Record form',goal='Keep authorized local records',consent='SAVE_LOCAL_RECORD_FORM',request_key='old-form')
limits=Limits(max_requests=4,max_tools=4,max_repairs=1,max_total_tokens=64000,max_output_tokens=1024,run_seconds=300)
args=('app_'+'1'*32,'action_'+'2'*32,'goal_'+'3'*32,'principal_'+'4'*32,dict(id='proj_'+'5'*32,runtime_id='principal_'+'6'*32),body,limits)
a,b=old.definition(*args),now.definition(*args)
assert now.canonical(a)==now.canonical(b)
assert old.CreateApp.model_validate(body).model_dump()==now.CreateApp.model_validate(body).model_dump()
assert now.CreateApp.model_validate(dict(body,content_edits=None)).model_dump()==body
assert not now.allows_content_edits(b)
print('legacy definition canonical bytes and old/default request dumps: identical')
i=dict(source_app_id=args[0],id='iinstance_'+'7'*32,release_id='irelease_'+'8'*32,principal_id=args[3])
r=dict(record_id='record_'+'9'*32,record_revision=1,title='old',details='old details',state='OPEN',last_event_fingerprint='a'*64)
e=dict(namespace=now.EDIT_EVENT_VERSION,app_id=i['source_app_id'],instance_id=i['id'],release_id=i['release_id'],principal_id=i['principal_id'],kind='EDIT_CONTENT',collection_version=2,record_id=r['record_id'],record_revision=2,previous_event_fingerprint=r['last_event_fingerprint'],previous_collection_fingerprint='b'*64,title='corrected',details='corrected details',state='OPEN',reason='correct transcription')
for patch in [dict(state='DONE'),dict(record_revision=3),dict(previous_event_fingerprint='c'*64),dict(reason=' '),dict(title=' '),dict(title=r['title'],details=r['details']),dict(namespace=now.EVENT_VERSION),dict(kind='SET_STATE'),dict(record_id='record_'+'0'*32),dict(collection_version=1)]:
 try:now.apply_event({r['record_id']:copy.deepcopy(r)},dict(e,**patch),'b'*64,2,i,allow_content_edit=True)
 except DomainError:pass
 else:raise AssertionError(patch)
print('10 malformed EDIT event mutations independently rejected')
c={r['record_id']:copy.deepcopy(r)}
now.apply_event(c,e,'b'*64,2,i,allow_content_edit=True)
assert c[r['record_id']]['state']=='OPEN' and c[r['record_id']]['record_revision']==2
print('valid EDIT preserves state and stable record identity')
