"""Independent actual-API scope rejection probe; synthetic local SQLite only."""
import json
import sys
from pathlib import Path

from conftest import env as env_fixture
from test_local_record_apps import ready, current, execute, create_body, ok, snapshot


def main():
    root = Path(__file__).parent / "scope-fixture-fixed"
    root.mkdir(exist_ok=True)
    assert not (root / "fixture.db").exists(), "One execution only; no fixture reuse"
    fixture = env_fixture.__wrapped__(root)
    data = next(fixture)
    client = data[2]
    wire = []

    def record(response):
        response.read()
        wire.append(dict(method=response.request.method, url=str(response.request.url),
            request=response.request.content.decode(), status=response.status_code,
            response=response.text))

    client.event_hooks["response"].append(record)
    try:
        source = ready(data, key="independent-source", content_edits=True)
        execute(data, source, create_body(current(data, source), "independent-base-a",
            "Independent A", "Original authoritative A content"))
        original = current(data, source)
        a = original["records"][0]
        other = ok(client.post(f"/api/internal/record-releases/{source['release']['id']}/instances",
            json=dict(expected_release_fingerprint=source["release"]["fingerprint"],
                      request_key="independent-other-instance")), 201)
        target = dict(source, instance=other["instance"],
            path=f"/api/internal/record-instances/{other['instance']['id']}")
        project = ok(client.post("/api/projects", json=dict(name="Independent second project")), 201)["id"]
        cross = ready(data, pid=project, key="independent-project-target", content_edits=True)
        outcomes = []
        for name, destination in (("other_instance", target), ("other_project", cross)):
            state = current(data, destination)
            body = dict(command="EDIT_CONTENT", expected_revision=state["revision"],
                expected_data_version=state["data_version"],
                expected_release_fingerprint=state["release_fingerprint"],
                request_key="independent-" + name, record_id=a["record_id"],
                expected_record_revision=a["record_revision"], title="Cross-scope replacement",
                details="Must never reach another collection", reason="Synthetic negative probe")
            before = snapshot(data[0])
            response = client.post(destination["path"] + "/previews", json=body)
            assert response.status_code == 409, response.text
            assert snapshot(data[0]) == before
            outcomes.append(dict(case=name, status=response.status_code, all_tables_unchanged=True))
        body.update(expected_revision=original["revision"], expected_data_version=original["data_version"],
            expected_release_fingerprint=original["release_fingerprint"], request_key="independent-other-owner")
        before = snapshot(data[0])
        response = client.post(source["path"] + "/previews", json=body,
            headers={"Authorization": "Bearer synthetic-test-B"})
        assert response.status_code == 403, response.text
        assert snapshot(data[0]) == before
        assert current(data, source) == original
        outcomes.append(dict(case="other_owner", status=response.status_code, all_tables_unchanged=True))
        (Path(__file__).parent / "scope-http.json").write_text(json.dumps(wire, ensure_ascii=False, indent=2))
        (Path(__file__).parent / "scope-result.json").write_text(json.dumps(dict(
            cases=outcomes, real_model_requests=0, accepted_edit_runs=0,
            original_record_and_history_unchanged=True), indent=2))
        print(json.dumps(outcomes))
        print("PASS: 3 actual API scope rejections; full database unchanged after each; source record/history unchanged; 0 models")
    finally:
        client.event_hooks["response"].remove(record)
        try:
            next(fixture)
        except StopIteration:
            pass


if __name__ == "__main__":
    main()
