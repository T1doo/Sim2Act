import subprocess,json
from pathlib import Path
r=Path('/workspace/logic-correction-effective-evidence-20261014/author');python='/workspace/Sim2Act/.venv/bin/python';runner=str(r/'run_suite.py')
suites=[('v7-load-pb',[str(r/'test_modified_correction_matrix.py')+'::test_modified_recipe_actual_cold_correction_and_independent_review[pb]','-p','stage_timing_v4']),('v7-load-pa-page',[str(r/'test_modified_correction_ui.py')+'::test_visible_modified_rejection_one_correction_and_fresh_owner[pa-normal]'])]
# Deliberate two-case synthetic regression, each separate fresh copied database.
# No source mutations, new probes, budget/lease changes or retry controller.
processes=[]
for label,args in suites:
 log=(r/(label+'-controller.stdout')).open('w');processes.append((label,subprocess.Popen([python,runner,label,*args],cwd='/workspace/Sim2Act-pa-provider',stdout=log,stderr=subprocess.STDOUT),log))
results=[]
for label,process,log in processes:
 code=process.wait();log.close();v=json.loads((r/(label+'-result.json')).read_text());results.append(dict(label=label,**v));print(json.dumps(dict(label=label,**v)),flush=True)
(r/'CONTROLLED_PAIR.json').write_text(json.dumps(dict(description='two explicitly selected synthetic business cases; original limits; separate databases; concurrency is controlled context, not exclusive causal proof',results=results),indent=2)+'\n')
