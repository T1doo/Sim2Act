import subprocess,json,time
from pathlib import Path
r=Path('/workspace/logic-correction-effective-evidence-20261014/author')
runner=str(r/'run_suite.py');python='/workspace/Sim2Act/.venv/bin/python'
suites=[
 ('fresh-v7-pa',['tests/test_logic_version_corrections.py::test_fresh_modified_parent_rejection_freezes_current_recipe[pa]']),
 ('v7-correction-pb',[str(r/'test_modified_correction_matrix.py')+'::test_modified_recipe_actual_cold_correction_and_independent_review[pb]','-p','stage_timing_v4']),
 ('v7-correction-pb-r2',[str(r/'test_modified_correction_matrix.py')+'::test_modified_recipe_actual_cold_correction_and_independent_review[pb]','-p','stage_timing_v4']),
 ('v7-correction-pa',[str(r/'test_modified_correction_matrix.py')+'::test_modified_recipe_actual_cold_correction_and_independent_review[pa]']),
 ('v7-late',[str(r/'test_modified_correction_matrix.py')+'::test_actual_late_reply_cannot_save_modified_correction']),
 ('v7-ui-pa',[str(r/'test_modified_correction_ui.py')+'::test_visible_modified_rejection_one_correction_and_fresh_owner[pa-normal]']),
 ('v7-ui-pb',[str(r/'test_modified_correction_ui.py')+'::test_visible_modified_rejection_one_correction_and_fresh_owner[pb-run-lost]']),
]
results=[]
for label,args in suites:
 (r/'SERIAL_STATE.json').write_text(json.dumps(dict(active=label,completed=results)))
 completed=subprocess.run([python,runner,label,*args],cwd='/workspace/Sim2Act-pa-provider')
 result=json.loads((r/(label+'-result.json')).read_text());results.append(dict(label=label,**result));print('COMPLETED '+label,flush=True)
 # Failed history is retained. Missing fresh fixtures or source mutation stops dependencies.
 if result['source_changes'] or (label=='fresh-v7-pa' and completed.returncode):break
(r/'SERIAL_STATE.json').write_text(json.dumps(dict(active=None,completed=results),indent=2)+'\n')
