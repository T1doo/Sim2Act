import json,hashlib,subprocess,xml.etree.ElementTree as E
from pathlib import Path
r=Path('/workspace/logic-correction-effective-evidence-20261014');a=r/'author';repo=Path('/workspace/Sim2Act-pa-provider')
labels=['v7-qualification','fresh-v7-pb','fresh-v7-pa','v7-correction-pb','v7-correction-pb-r2','v7-correction-pa','v7-late','v7-ui-pa','v7-ui-pb','v7-load-pb','v7-load-pa-page']
results={k:json.loads((a/(k+'-result.json')).read_text()) for k in labels}
source=json.loads((a/'v7-qualification-source-before.json').read_text());assert source['head']=='efeebb147665c2fc492bdd77629ab9a7988db96f'
identities={}
for label,v in results.items():
 assert not v['source_changes']
 for end in ['before','after']:assert json.loads((a/(label+'-source-'+end+'.json')).read_text())==source
 for case in E.parse(a/(label+'.xml')).getroot().findall('.//testcase'):
  key=case.attrib.get('classname','')+'::'+case.attrib['name'];status='FAIL' if case.find('failure') is not None else 'ERROR' if case.find('error') is not None else 'SKIP' if case.find('skipped') is not None else 'PASS';identities.setdefault(key,[]).append(dict(label=label,status=status))
assert all(hashlib.sha256((repo/f).read_bytes()).hexdigest()==h for f,h in source['files'].items())
ui={}
for label in ['v7-ui-pa','v7-ui-pb','v7-load-pa-page']:
 paths=[p for p in (a/(label+'-tmp')).glob('*/result.json') if not p.parent.is_symlink()]
 if paths:
  v=json.loads(paths[0].read_text());ui[label]=dict(status=v['status'],checks=len(v['checks']),scenario=v['scenario'])
stages={}
for label in ['v7-correction-pb','v7-correction-pb-r2','v7-load-pb']:
 p=a/(label+'-tmp-stage-timing.json')
 if p.exists():
  v=json.loads(p.read_text());records=[dict(record_index=i,**x) for i,x in enumerate(v['records']) if x['stage'].endswith(('.claim','.effective','.frozen_contract','.reservation_check','.heartbeat','.renew','.advance_model'))];stages[label]=dict(status=v['status'],record_count=len(v['records']),limit=v['limit'],selected=records,filter='only calls >=0.1s; nested durations overlap; no wall-clock or per-phase fence attribution')
raw={k:sum(v.get(k,0) for v in results.values()) for k in ['passed','failed','errors','skipped','selected']}
summary=dict(qualified_source=source['head'],core='30c7ada5035c37e5e93af00fb4b3bead9f589a4d',status='FINITE_REGRESSIONS_COMPLETED; historical deadline reliability root cause not fully established',raw_counts=raw,unique_identities=len(identities),attempts=identities,suites=results,ui=ui,ordinary_stage_projection=stages,source_count=len(source['files']),source_changes=[],historical_v6='P/F/P retained; old failure detailed phases/transaction wait/heartbeat NOT RECORDED',not_run=['PostgreSQL','Windows','native browser','real/paid models','real human semantic acceptance','complete P-A/P-B product acceptance','remote CI','deployment'],private_diagnostic='BLOCKED; no retry/reconstruction/replacement')
(r/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n');(a/'source-final.json').write_text(json.dumps(source,indent=2)+'\n');print(json.dumps(dict(raw=raw,unique=len(identities),ui=ui)))
