"""Current qualified fresh PA/PB seeds; normal correction and actual late faults."""
import copy, hashlib, json, os, shutil
from contextlib import contextmanager
from pathlib import Path
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import delete, select, update
from test_natural_spec_apps import transport
from test_natural_spec_owner_acceptance import decision, preview, state
from test_natural_spec_corrections import prepare_correction
from test_pb_natural_specs import drive_to_success
from test_spec_app_operations import snapshot
from sim2act.api import create_app
from sim2act.config import Settings
from sim2act.db import Store, delivery_graph_requests, events, fingerprint, grants, internal_app_runs, internal_instance_data, internal_instances, internal_run_bindings, local_effects, operations, runs
from sim2act import natural_spec_corrections as correction, natural_logic_patches as logic
from sim2act.worker import Worker

ROOT=Path('/workspace/logic-correction-effective-evidence-20261014/author')
@contextmanager
def opened(tmp_path,family):
    root=ROOT/(os.environ.get('SIM2ACT_CORRECTION_SEED_LABEL','fresh-v7-'+family)+'-tmp')
    choices=[]
    for p in root.glob('*/modified-parent-proof.json'):
        if p.parent.is_symlink():continue
        value=json.loads(p.read_text())
        if value['family']==family:choices.append((p,value))
    assert len(choices)==1,choices
    path,proof=choices[0];seed=path.parent/'fixture.db';seedfp=hashlib.sha256(seed.read_bytes()).hexdigest();dst=tmp_path/'copy.db';shutil.copyfile(seed,dst)
    settings=Settings('sqlite:///'+str(dst),tmp_path,mode='mock',goal_planner_provider='intern-s2');store=Store(settings.database_url,test_only=True);client=TestClient(create_app(store,settings));client.headers['Authorization']='Bearer synthetic-test-A'
    data=(store,settings,client,proof['principal_id'],proof['project_id'])
    try:yield data,proof
    finally:
        client.close();store.engine.dispose();assert hashlib.sha256(seed.read_bytes()).hexdigest()==seedfp

def prepared(data,proof,key='matrix-new-intent'):
    body={**proof['prepare'],'request_key':key};review,commit=prepare_correction(data,proof['base_path'],body);return review,commit

def queued(data,proof,commit):
    r=data[2].post(proof['base_path']+'/correction-runs',json=commit);assert r.status_code==202,r.text;return r.json()

def check_ids(store,proof):
    origin=proof['review']['logic_source']['origin']
    with store.tx() as c:
        row=c.execute(select(delivery_graph_requests.c.snapshot).where(delivery_graph_requests.c.app_id==origin['instance_id'],delivery_graph_requests.c.kind==logic.CHECK,delivery_graph_requests.c.request_key==origin['preview_key'])).scalar_one()['response']
        artifact=c.execute(select(events.c.data['artifact_resource'].as_string()).where(events.c.run_id==row['run_id'],events.c.kind=='SPEC_COMMITTED')).scalar_one()
        runtime=c.execute(select(runs.c.runtime_id).where(runs.c.id==row['run_id'])).scalar_one()
    return row,artifact,runtime

@pytest.mark.parametrize('family',['pa','pb'])
def test_modified_recipe_actual_cold_correction_and_independent_review(tmp_path,family):
    with opened(tmp_path,family) as (data,proof):
        review,commit=prepared(data,proof);old=snapshot(data[0]);accepted=queued(data,proof,commit);child=accepted['run_id'];stable=snapshot(data[0])
        duplicate=queued(data,proof,commit);assert duplicate['run_id']==child and duplicate['cached']
        assert snapshot(data[0])==stable
        r=data[2].post(proof['base_path']+'/correction-runs',json={**commit,'expected_review_fingerprint':'0'*64});assert r.status_code==409,r.text;assert snapshot(data[0])==stable
        r=data[2].post(proof['base_path']+'/correction-reviews',json={**proof['prepare'],'request_key':commit['request_key'],'declaration_fingerprint':'0'*64});assert r.status_code==409,r.text;assert snapshot(data[0])==stable
        inspected=data[2].get('/api/internal/instances/'+proof['instance_id']+'/runs/'+child)
        assert inspected.status_code==200,inspected.text
        route='/api/internal/instances/'+proof['instance_id']+'/runs/'+child
        for command in ('pause','resume'):
            control=data[2].get(route+'/control-status');assert control.status_code==200,control.text
            changed=data[2].post(route+'/commands',json=dict(command=command,version=control.json()['version']))
            assert changed.status_code==200,changed.text
        cold=Store(data[1].database_url,test_only=True);client=TestClient(create_app(cold,data[1]));client.headers['Authorization']='Bearer synthetic-test-A';current=(cold,data[1],client,*data[3:]);sent=[]
        try:
            drive_to_success(current,child,transport(sent,proof['content']));assert len(sent)==2
            first=json.loads(sent[0]['messages'][1]['content']);second=json.loads(sent[1]['messages'][1]['content'])
            assert first['human_correction']['reference']['parent_run_id']==proof['parent_run_id']
            assert first['human_correction']['original_goal']==review['context']['goal']
            assert first['human_correction']['original_criteria']==review['context']['items']
            assert ('prior_items' in second['current_inputs'])==('prior_items' in review['effective_candidate']['spec_recipe']['steps'][2]['inputs'])
            r=client.get(proof['base_path']+'/correction-requests/'+commit['request_key']);assert r.status_code==200,r.text;receipt=r.json();assert receipt['run_id']==child and receipt['result_version']==2
            artifact=client.get('/api/internal/app-run-jobs/'+child+'/spec-artifact');assert artifact.status_code==200,artifact.text;result=json.loads(artifact.json()['resource']['content']);assert result['source_content']==proof['content'] and result['owner_acceptance']=='PENDING'
            newpath=proof['owner_path'].replace(proof['parent_run_id'],child);fresh=state(current,newpath);assert fresh['latest'] is None and fresh['owner_acceptance']=='PENDING' and fresh['current']['source_goal']==review['context']['source_goal']
            p,_=preview(current,newpath,'independent-correction-review');r=client.post(newpath+'-requests',json=decision(p,True));assert r.status_code==201,r.text
            latest=state(current,newpath);assert latest['owner_acceptance']=='REJECTED'
            # Even a fresh rejected child cannot recurse into another correction.
            r=client.post(newpath.replace('/spec-owner-review','')+'/correction-reviews',json=dict(request_key='forbidden-grandchild',expected_owner_sequence=latest['sequence'],declaration_id=latest['latest']['id'],declaration_fingerprint=latest['latest']['fingerprint'],expected_context_fingerprint=fingerprint(latest['current'])));assert r.status_code==409 and 'Corrections-of-corrections' in r.text,r.text
            after=snapshot(cold)
            for table in ('internal_instance_data','natural_owner_records','natural_owner_seals'):assert all(row in after[table] for row in old[table]),table
            for table in ('app_drafts','internal_releases','goal_cards','goal_card_versions'):assert old[table]==after[table],table
            (tmp_path/'correction-proof.json').write_text(json.dumps(dict(review=review,receipt=receipt,wire=sent,result=result,new_independent_review=latest,recursive_rejection=r.json(),simulated_human_only=True,real_paid_models=0),indent=2)+'\n')
        finally:client.close();cold.engine.dispose()

@pytest.mark.parametrize('fault',['target-revoke','check-revoke','source-version','cancel','withdraw','competing-version'])
def test_actual_late_reply_cannot_save_modified_correction(tmp_path,fault):
    with opened(tmp_path,'pa') as (data,proof):
        review,commit=prepared(data,proof);accepted=queued(data,proof,commit);child=accepted['run_id'];sent=[];fired=[]
        check,artifact,runtime=check_ids(data[0],proof)
        def mutate(raw,payload):
            if fired:return
            if fault=='cancel':
                route='/api/internal/instances/'+proof['instance_id']+'/runs/'+child
                v=data[2].get(route+'/control-status');assert v.status_code==200,v.text
                r=data[2].post(route+'/commands',json=dict(command='cancel',version=v.json()['version']));assert r.status_code==200,r.text
            elif fault=='withdraw':
                r=data[2].post(proof['owner_path']+'-requests',json=dict(command='REVOKE',request_key='withdraw-during-model',expected_sequence=proof['prepare']['expected_owner_sequence'],target_id=proof['declaration']['id'],target_fingerprint=proof['declaration']['fingerprint'],reason='SIMULATED withdraw while actual model response pending'));assert r.status_code==201,r.text
            else:
                with data[0].tx() as c:
                    if fault=='target-revoke':c.execute(update(grants).where(grants.c.resource_id==review['context']['material']['resource_id'],grants.c.tool_ref=='resource.read').values(revoked=True))
                    elif fault=='check-revoke':c.execute(update(grants).where(grants.c.resource_id==artifact,grants.c.principal_id==runtime,grants.c.tool_ref=='resource.read').values(revoked=True))
                    elif fault=='source-version':c.execute(update(internal_instances).where(internal_instances.c.id==review['logic_source']['origin']['instance_id']).values(revision=internal_instances.c.revision+1))
                    else:c.execute(update(internal_instances).where(internal_instances.c.id==proof['instance_id']).values(data_version=internal_instances.c.data_version+1))
            fired.append(fault)
        cold=Store(data[1].database_url,test_only=True)
        try:Worker(cold,data[1],goal_planner_transport=transport(sent,proof['content'],mutate)).once()
        finally:cold.engine.dispose()
        assert fired==[fault] and len(sent)==1
        with data[0].tx() as c:
            status=c.execute(select(runs.c.status).where(runs.c.id==child)).scalar_one()
            assert status!='SUCCEEDED'
            assert c.execute(select(internal_instance_data.c.run_id).where(internal_instance_data.c.run_id==accepted['app_run_id'])).first() is None
            assert c.execute(select(local_effects.c.operation_id).join(operations,operations.c.id==local_effects.c.operation_id).where(operations.c.run_id==child)).first() is None
        if fault=='cancel' and status=='RECONCILING':
            route='/api/internal/instances/'+proof['instance_id']+'/runs/'+child
            control=data[2].get(route+'/control-status');assert control.status_code==200,control.text
            closed=data[2].post(route+'/commands',json=dict(command='cancel',version=control.json()['version']))
            assert closed.status_code==200,closed.text
            with data[0].tx() as c:status=c.execute(select(runs.c.status).where(runs.c.id==child)).scalar_one()
        if fault=='cancel':assert status=='CANCELLED'
        (tmp_path/'late-proof.json').write_text(json.dumps(dict(fault=fault,status=status,wire=sent,fired=fired,child=accepted,no_child_typed=True,no_child_save=True,synthetic_fault=True),indent=2)+'\n')

@pytest.mark.parametrize('fault',['queued-cancel','queued-check-revoke','accepted-main-seal-delete'])
def test_cold_start_and_one_child_index_loss(tmp_path,fault):
    with opened(tmp_path,'pb') as (data,proof):
        review,commit=prepared(data,proof);accepted=queued(data,proof,commit);child=accepted['run_id'];sent=[]
        if fault=='accepted-main-seal-delete':
            with data[0].tx() as c:c.execute(delete(delivery_graph_requests).where(delivery_graph_requests.c.app_id==child,delivery_graph_requests.c.kind.in_([correction.ACCEPTED,correction.ACCEPTED+'_seal'])))
            stable=snapshot(data[0]);body={**proof['prepare'],'request_key':'forbidden-second-child'};r=data[2].post(proof['base_path']+'/correction-reviews',json=body);assert r.status_code==409 and 'already has' in r.text,r.text;assert snapshot(data[0])==stable
        elif fault=='queued-cancel':
            route='/api/internal/instances/'+proof['instance_id']+'/runs/'+child;v=data[2].get(route+'/control-status');assert v.status_code==200,v.text;r=data[2].post(route+'/commands',json=dict(command='cancel',version=v.json()['version']));assert r.status_code==200,r.text
        else:
            _,artifact,runtime=check_ids(data[0],proof)
            with data[0].tx() as c:c.execute(update(grants).where(grants.c.resource_id==artifact,grants.c.principal_id==runtime,grants.c.tool_ref=='resource.read').values(revoked=True))
        cold=Store(data[1].database_url,test_only=True)
        try:Worker(cold,data[1],goal_planner_transport=transport(sent,proof['content'])).once()
        finally:cold.engine.dispose()
        assert not sent
        with data[0].tx() as c:
            status=c.execute(select(runs.c.status).where(runs.c.id==child)).scalar_one();assert status in ({'CANCELLED'} if fault=='queued-cancel' else {'FAILED','WAITING_RESOURCE'} if fault=='queued-check-revoke' else {'FAILED'})
            assert c.execute(select(internal_instance_data.c.run_id).where(internal_instance_data.c.run_id==accepted['app_run_id'])).first() is None
        (tmp_path/'startup-proof.json').write_text(json.dumps(dict(fault=fault,status=status,sent=sent,accepted=accepted),indent=2)+'\n')
