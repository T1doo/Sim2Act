"""Ordinary synthetic heartbeat metadata and thread lifecycle logs; no SQL/body reads."""
import functools,json,logging,threading,time
from pathlib import Path
records=[];intervals={};lock=threading.Lock();owners={};owner_states={}
def emit(stage,**fields):
 with lock:records.append(dict(stage=stage,at=time.time(),thread=threading.get_ident(),**fields))
def pytest_sessionstart(session):
 from sim2act.db import Store
 from sim2act import text_workflows
 class BusinessHandler(logging.Handler):
  def emit(self,record):
   if record.msg in {'heartbeat_contention_deferred','heartbeat_background_halted','heartbeat_failure_observed'}:
    emit(record.msg,**{k:getattr(record,k) for k in ['run_id','fence','attempts','heartbeat_lease_until','heartbeat_deadline','error_type'] if hasattr(record,k)})
 logger=logging.getLogger('sim2act.text_workflows');logger.setLevel(logging.INFO);logger.addHandler(BusinessHandler())
 oldclaim=Store.claim
 @functools.wraps(oldclaim)
 def claim(self,*args,**kwargs):
  run=oldclaim(self,*args,**kwargs)
  if run:
   intervals[run['id']]=dict(lower=run['lease_until'],upper=run['lease_until'],created_at=run['created_at'],fence=run['fence'])
   emit('claim',run_id=run['id'],fence=run['fence'],lease_until=run['lease_until'],created_at=run['created_at'])
  return run
 Store.claim=claim
 oldprocess=text_workflows.process_job
 @functools.wraps(oldprocess)
 def process(worker,run,*args,**kwargs):
  owners[run['id']]=threading.get_ident();owner_states[run['id']]=kwargs.get('_heartbeat_state');emit('process_enter',run_id=run['id'],fence=run['fence'])
  try:return oldprocess(worker,run,*args,**kwargs)
  finally:emit('process_exit',run_id=run['id'],fence=run['fence'])
 text_workflows.process_job=process
 oldbeat=Store.heartbeat
 @functools.wraps(oldbeat)
 def heartbeat(self,worker_id,run_id=None,fence=None,lease_seconds=30,**options):
  started=time.time();known=intervals.get(run_id,{});phase=('background' if owners[run_id]!=threading.get_ident() else 'synchronous') if run_id in owners else 'unclassified'
  emit('heartbeat_begin',passed_deadline=options.get('_deadline'),passed_wait=options.get('_wait_seconds'),run_id=run_id,fence=fence,phase=phase,known_lease_lower=known.get('lower'),known_lease_upper=known.get('upper'),remaining_lease_lower=known.get('lower',started)-started)
  try:value=oldbeat(self,worker_id,run_id,fence,lease_seconds,**options)
  except Exception as exc:
   orig=getattr(exc,'orig',None);emit('heartbeat_error',run_id=run_id,fence=fence,phase=phase,seconds=time.time()-started,error_type=type(exc).__name__,domain_code=getattr(exc,'code',None),sqlite_errorcode=getattr(orig,'sqlite_errorcode',None),sqlite_errorname=getattr(orig,'sqlite_errorname',None));raise
  else:
   ended=time.time()
   if run_id:
    intervals[run_id]={**known,'lower':value if isinstance(value,(int,float)) else started+lease_seconds,'upper':value if isinstance(value,(int,float)) else ended+lease_seconds}
   emit('heartbeat_success',run_id=run_id,fence=fence,phase=phase,seconds=ended-started,exact_committed_lease_until=value,lease_lower_bound=started+lease_seconds if run_id else None,lease_upper_bound=ended+lease_seconds if run_id else None)
   return value
 Store.heartbeat=heartbeat
 from sim2act import natural_spec_runtime
 oldadvance=natural_spec_runtime.advance_model
 @functools.wraps(oldadvance)
 def advance(worker,run,*args,**kwargs):
  value=oldadvance(worker,run,*args,**kwargs)
  if not value:emit('terminal_transaction_return',run_id=run['id'],fence=run['fence'],accepted_at=run['created_at'])
  return value
 natural_spec_runtime.advance_model=advance
 original_thread=threading.Thread
 class LoggedThread(original_thread):
  def __init__(self,*args,**kwargs):
   target=kwargs.get('target',args[1] if len(args)>1 else None)
   self.business_beat=bool(target and getattr(target,'__module__',None)=='sim2act.text_workflows' and getattr(target,'__qualname__',None)=='process_job.<locals>.beat')
   super().__init__(*args,**kwargs)
  def run(self):
   if not self.business_beat:return super().run()
   emit('background_thread_enter')
   try:return super().run()
   finally:emit('background_thread_exit')
 threading.Thread=LoggedThread

def pytest_sessionfinish(session,exitstatus):
 path=Path(str(session.config.option.basetemp)).parent/(Path(str(session.config.option.basetemp)).name+'-heartbeat-log.json')
 path.write_text(json.dumps(dict(status=int(exitstatus),intervals_are_success_call_time_bounds_not_exact_committed_lease=True,records=records),indent=2)+'\n')
