import hashlib,json,re,subprocess
from pathlib import Path
p=Path('src/sim2act/text_continuations.py');s=p.read_text()
core=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
baseline='9bed3b2fb32ffbae3b5d2503396bc2aca153fb65'
s=re.sub(r'proof\["review_baseline"\] == "[a-f0-9]{40}"','proof["review_baseline"] == "'+baseline+'"',s);s=re.sub(r'proof\["review_candidate"\] == "[a-f0-9]{40}"','proof["review_candidate"] == "'+core+'"',s);p.write_text(s)
q=Path('src/sim2act/text_software_qualification.json');value=json.loads(q.read_text())
value['review_baseline']=baseline;value['review_candidate']=core
files={}
for f in sorted(p.parent.glob('*.py')):
 if f.name=='config.py':continue
 b=f.read_bytes()
 if f==p:b=re.sub(rb'QUALIFICATION_HASH = "[a-f0-9]{64}"',b'QUALIFICATION_HASH = "'+b'0'*64+b'"',b)
 files[f.name]=hashlib.sha256(b).hexdigest()
value['files']=files;q.write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
p.write_text(re.sub(r'QUALIFICATION_HASH = "[a-f0-9]{64}"','QUALIFICATION_HASH = "'+hashlib.sha256(q.read_bytes()).hexdigest()+'"',s))
print(core,len(files),hashlib.sha256(q.read_bytes()).hexdigest())
