import subprocess,json
from pathlib import Path
r=Path('/workspace/logic-correction-heartbeat-evidence-20261014/author');runner=str(r/'run_suite.py');python='/workspace/Sim2Act/.venv/bin/python'
suites=[
 ('v11-legacy',['tests/test_text_workflows.py']),
 ('fresh-v11-pb',['tests/test_logic_version_corrections.py::test_fresh_modified_parent_rejection_freezes_current_recipe[pb]','-p','heartbeat_business_log']),
 ('fresh-v11-pa',['tests/test_logic_version_corrections.py::test_fresh_modified_parent_rejection_freezes_current_recipe[pa]','-p','heartbeat_business_log']),
 ('v11-correction-pb',[str(r/'test_modified_correction_matrix.py')+'::test_modified_recipe_actual_cold_correction_and_independent_review[pb]','-p','heartbeat_business_log']),
 ('v11-correction-pb-r2',[str(r/'test_modified_correction_matrix.py')+'::test_modified_recipe_actual_cold_correction_and_independent_review[pb]','-p','heartbeat_business_log']),
 ('v11-correction-pa',[str(r/'test_modified_correction_matrix.py')+'::test_modified_recipe_actual_cold_correction_and_independent_review[pa]','-p','heartbeat_business_log']),
 ('v11-late',[str(r/'test_modified_correction_matrix.py')+'::test_actual_late_reply_cannot_save_modified_correction']),
 ('v11-ui-pa',[str(r/'test_modified_correction_ui.py')+'::test_visible_modified_rejection_one_correction_and_fresh_owner[pa-normal]']),
 ('v11-ui-pb',[str(r/'test_modified_correction_ui.py')+'::test_visible_modified_rejection_one_correction_and_fresh_owner[pb-run-lost]']),
]
results=[]
for label,args in suites:
 (r/'SERIAL_STATE.json').write_text(json.dumps(dict(active=label,completed=results)))
 code=subprocess.run([python,runner,label,*args],cwd='/workspace/Sim2Act-pa-provider').returncode
 value=json.loads((r/(label+'-result.json')).read_text());results.append(dict(label=label,**value));print('COMPLETED '+label,flush=True)
 if value['source_changes'] or (label.startswith('fresh') and code):break
(r/'SERIAL_STATE.json').write_text(json.dumps(dict(active=None,completed=results),indent=2)+'\n')
