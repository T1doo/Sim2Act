import json,hashlib,xml.etree.ElementTree as E
from pathlib import Path
r=Path('/workspace/logic-correction-heartbeat-evidence-20261014');a=r/'author';repo=Path('/workspace/Sim2Act-pa-provider')
labels=['v11-boundary-qualification','v11-legacy','fresh-v11-pb','fresh-v11-pa','v11-correction-pb','v11-correction-pb-r2','v11-correction-pa','v11-late','v11-ui-pa','v11-ui-pb']
results={k:json.loads((a/(k+'-result.json')).read_text()) for k in labels};source=json.loads((a/'v11-boundary-qualification-source-before.json').read_text());assert source['head']=='7e6b793c922a1751cdd8906ff1dd7eed675113bd'
identities={}
for label,v in results.items():
 assert not v['source_changes']
 for end in ['before','after']:assert json.loads((a/(label+'-source-'+end+'.json')).read_text())==source
 for case in E.parse(a/(label+'.xml')).getroot().findall('.//testcase'):
  key=case.attrib.get('classname','')+'::'+case.attrib['name'];status='FAIL' if case.find('failure') is not None else 'ERROR' if case.find('error') is not None else 'SKIP' if case.find('skipped') is not None else 'PASS';identities.setdefault(key,[]).append(dict(label=label,status=status))
assert all(hashlib.sha256((repo/f).read_bytes()).hexdigest()==h for f,h in source['files'].items())
terminals=[]
for label in ['v11-correction-pb','v11-correction-pb-r2','v11-correction-pa']:
 paths=[p for p in (a/(label+'-tmp')).glob('*/terminal-public-receipt.json') if not p.parent.is_symlink()]
 if not paths:continue
 v=json.loads(paths[0].read_text());log=json.loads((a/(label+'-tmp-heartbeat-log.json')).read_text())['records'];rid=v['run_id'];own=[x for x in log if x.get('run_id')==rid];returns=[x for x in own if x['stage']=='terminal_transaction_return'];assert len(returns)==1 and returns[0]['fence']==v['fence'];at=returns[0]['at'];v.update(label=label,commit_return_observed_at=at,accepted_to_commit_return_seconds=at-v['accepted_at'],remaining_original_deadline_seconds=v['deadline']-at,timing_method='posttransaction advance_model(False) return observer; not SPEC_COMMITTED event timestamp',claim_count=sum(x['stage']=='claim' for x in own),background_successes=sum(x['stage']=='heartbeat_success' and x.get('phase')=='background' for x in own),contention_deferred=sum(x['stage']=='heartbeat_contention_deferred' for x in own),background_halted=sum(x['stage']=='heartbeat_background_halted' for x in own),background_halted_before_terminal=sum(x['stage']=='heartbeat_background_halted' and x['at']<at for x in own),failure_observed=sum(x['stage']=='heartbeat_failure_observed' for x in own),errors=[x for x in own if x['stage']=='heartbeat_error']);terminals.append(v)
ui={}
for label in ['v11-ui-pa','v11-ui-pb']:
 paths=[p for p in (a/(label+'-tmp')).glob('*/result.json') if not p.parent.is_symlink()]
 if paths:
  v=json.loads(paths[0].read_text());ui[label]=dict(status=v['status'],checks=len(v['checks']),scenario=v['scenario'])
raw={k:sum(v.get(k,0) for v in results.values()) for k in ['passed','failed','errors','skipped','selected']}
v=dict(source=source['head'],core='0cafd80c752abe61df0fc6e1079eac42e721a780',source_count=len(source['files']),source_changes=[],suites=results,raw_counts=raw,unique_identities=len(identities),attempts=identities,terminals=terminals,ui=ui,historical='previous33189265executions62unique/page66 not accumulated; v8two freshPB FAIL, v9one freshPB FAIL, and v10two correctionPB FAIL preserved separately; no source/fixture re-signing',not_run=['PostgreSQL','Windows','native browser','real/paid models','real human semantic acceptance','fullP-A/P-B product acceptance','remote CI','deployment'],private_diagnostic='BLOCKED no retry/reconstruction/replacement')
(r/'SUMMARY.json').write_text(json.dumps(v,indent=2)+'\n');(a/'source-final.json').write_text(json.dumps(source,indent=2)+'\n');(a/'terminal-public-summary.json').write_text(json.dumps(terminals,indent=2)+'\n');print(json.dumps(dict(raw=raw,unique=len(identities),ui=ui,terminals=[{k:x[k] for k in ['label','fence','accepted_to_commit_return_seconds','remaining_original_deadline_seconds','claim_count','background_successes','contention_deferred','background_halted']} for x in terminals])))
