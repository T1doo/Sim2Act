"""Bounded normal synthetic business call stage timings; no values or bodies."""
import functools,json,threading,time
from pathlib import Path
_records=[]
_local=threading.local()
_LIMIT=10000

def pytest_sessionstart(session):
    import sim2act.db as db
    from sim2act import worker,app_jobs,pa_spec_apps,natural_spec_runtime,lifecycle,natural_spec_corrections,pb_natural_uses,pb_natural_specs,natural_logic_patches,text_continuations
    groups=[(db.Store,['claim','guard','heartbeat','frozen_contract','_frozen_contract_after_scope']),
      (worker.Worker,['once','process','reserve']),
      (app_jobs,['process_job','load_binding','lock_live','fail_job']),
      (pa_spec_apps,['is_job','job_scope_gate','scope_gate','bound','commit_guard','advance','verify_origin','audit_fingerprint','receipts']),
      (natural_spec_runtime,['advance_model','effective','renew','reservation_check']),
      (lifecycle,['read_release']),
      (natural_spec_corrections,['gate','logic_gate','bound']),
      (pb_natural_uses,['scope_gate','bound']),
      (pb_natural_specs,['verify_origin']),
      (natural_logic_patches,['read_release_source']),
      (text_continuations,['job_gate'])]
    for obj,names in groups:
        for name in names:
            if not hasattr(obj,name):continue
            original=getattr(obj,name);stage=obj.__name__+'.'+name
            def wrap(original,stage):
                @functools.wraps(original)
                def measured(*args,**kwargs):
                    depth=getattr(_local,'depth',0);_local.depth=depth+1;start=time.perf_counter();status='returned'
                    try:return original(*args,**kwargs)
                    except Exception as e:
                        status=type(e).__name__+':'+str(getattr(e,'code',''));raise
                    finally:
                        elapsed=time.perf_counter()-start;_local.depth=depth
                        if elapsed>=0.01 and len(_records)<_LIMIT:_records.append(dict(stage=stage,seconds=elapsed,status=status,depth=depth))
                return measured
            setattr(obj,name,wrap(original,stage))

def pytest_sessionfinish(session,exitstatus):
    path=Path(str(session.config.option.basetemp)).parent/(Path(str(session.config.option.basetemp)).name+'-stage-timing.json')
    path.write_text(json.dumps(dict(status=int(exitstatus),limit=_LIMIT,records=_records),indent=2)+'\n')
