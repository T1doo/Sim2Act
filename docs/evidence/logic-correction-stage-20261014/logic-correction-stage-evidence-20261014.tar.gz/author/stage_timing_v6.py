"""Bounded normal synthetic business call stage timings; no values or bodies."""
import functools,json,threading,time
from pathlib import Path
_records=[]
_local=threading.local()
_LIMIT=10000

def pytest_sessionstart(session):
    import sim2act.db as db
    from sim2act import worker,app_jobs,pa_spec_apps,natural_spec_runtime,lifecycle,natural_spec_corrections,pb_natural_uses,pb_natural_specs,natural_logic_patches,text_continuations,app_owner_goals,natural_specs
    groups=[(db.Store,['claim','guard','heartbeat','frozen_contract','_frozen_contract_after_scope']),
      (worker.Worker,['once','process','reserve']),
      (app_jobs,['process_job','load_binding','lock_live','fail_job']),
      (pa_spec_apps,['is_job','job_scope_gate','scope_gate','bound','commit_guard','advance','verify_origin','audit_fingerprint','receipts','_advance_local']),
      (natural_spec_runtime,['advance_model','effective','renew','reservation_check']),
      (lifecycle,['read_release','validate_frozen_candidate','validate_source_bytes']),
      (natural_spec_corrections,['gate','logic_gate','logic_anchor','bound']),
      (pb_natural_uses,['scope_gate','bound']),
      (pb_natural_specs,['verify_origin']),
      (natural_logic_patches,['read_release_source']),
      (text_continuations,['job_gate','draft_gate']), (app_owner_goals,['verify_frozen_run']), (natural_specs,['compile_candidate'])]
    for obj,names in groups:
        for name in names:
            if not hasattr(obj,name):continue
            original=getattr(obj,name);stage=obj.__name__+'.'+name
            def wrap(original,stage):
                @functools.wraps(original)
                def measured(*args,**kwargs):
                    depth=getattr(_local,'depth',0);_local.depth=depth+1;start=time.perf_counter();status='returned'
                    try:return original(*args,**kwargs)
                    except Exception as e:
                        status=type(e).__name__+':'+str(getattr(e,'code',''));raise
                    finally:
                        elapsed=time.perf_counter()-start;_local.depth=depth
                        if elapsed>=0.1 and len(_records)<_LIMIT:_records.append(dict(stage=stage,seconds=elapsed,status=status,depth=depth))
                return measured
            setattr(obj,name,wrap(original,stage))

    original_segment=natural_spec_corrections.scope_segment
    @functools.wraps(original_segment)
    def segment_stage(store,c,user,rid):
        token=c.info.get("correction_scope_segment")
        proof=token.get("logic",{}) if isinstance(token,dict) else {}
        if not token: status="absent"
        elif token.get("spec_scope_checked") is not True: status="unmarked"
        elif token.get("run_id")!=rid or token.get("principal_id")!=user: status="different_scope"
        elif proof.get("_call_connection") is not c: status="different_connection"
        elif proof.get("_call_transaction") is not c.get_transaction(): status="different_transaction"
        elif proof.get("_call_write_epoch")!=c.info.get("source_proof_write_epoch",0): status="write_invalidated"
        else: status="matching"
        if not token:
            captured=getattr(_local,"last_segment",None)
            previous=captured.get("logic",{}) if captured else {}
            if captured and captured.get("run_id")==rid and captured.get("principal_id")==user:
                if previous.get("_call_connection") is c and previous.get("_call_transaction") is c.get_transaction() and previous.get("_call_write_epoch")==c.info.get("source_proof_write_epoch",0):
                    status="ambient_absent_captured_same_read_segment"
        started=time.perf_counter()
        value=original_segment(store,c,user,rid)
        if len(_records)<_LIMIT:_records.append(dict(stage="readonly_scope_segment",seconds=time.perf_counter()-started,status=status+":"+("available" if value is not None else "unavailable"),depth=getattr(_local,"depth",0)))
        if value is not None:_local.last_segment=value
        return value
    natural_spec_corrections.scope_segment=segment_stage

def pytest_sessionfinish(session,exitstatus):
    path=Path(str(session.config.option.basetemp)).parent/(Path(str(session.config.option.basetemp)).name+'-stage-timing.json')
    path.write_text(json.dumps(dict(status=int(exitstatus),limit=_LIMIT,records=_records),indent=2)+'\n')
