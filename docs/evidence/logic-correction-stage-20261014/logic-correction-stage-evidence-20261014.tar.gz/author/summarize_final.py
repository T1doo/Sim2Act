import hashlib,json,subprocess,xml.etree.ElementTree as ET
from pathlib import Path
root=Path('/workspace/logic-correction-stage-evidence-20261014');a=root/'author';repo=Path('/workspace/Sim2Act-pa-provider')
labels=['v6-lease-qualification','v6-lifecycle-switch','fresh-v6-pa','fresh-v6-pb','v6-correction-pa','v6-correction-pb','v6-ui-pa','v6-ui-pb','v6-late-matrix','v6-startup-base','v6-handoff-family','v6-correction-pb-exact']
results={label:json.loads((a/(label+'-result.json')).read_text()) for label in labels}
reference=json.loads((a/'v6-lease-qualification-source-before.json').read_text());assert reference['head']=='0d522be8895bf895b7548df7eeabf45679495a4d'
unique={};duplicates=[]
for label,result in results.items():
 assert not result['source_changes'],(label,result)
 for end in ['before','after']:
  source=json.loads((a/(label+'-source-'+end+'.json')).read_text());assert source==reference,(label,end)
 for case in ET.parse(a/(label+'.xml')).getroot().findall('.//testcase'):
  key=case.attrib.get('classname','')+'::'+case.attrib['name'];status='FAIL' if case.find('failure') is not None else 'ERROR' if case.find('error') is not None else 'SKIP' if case.find('skipped') is not None else 'PASS'
  if key in unique:
   unique[key]['attempts'].append(dict(status=status,label=label));duplicates.append(dict(case=key,label=label,first=unique[key]['label'],status=status))
  else:unique[key]=dict(status=status,label=label,attempts=[dict(status=status,label=label)])
for name,digest in reference['files'].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest,name
assert len(reference['files'])==465
assert not subprocess.check_output(['git','diff',reference['head'],'HEAD','--','src','tests','pyproject.toml'],cwd=repo,text=True)
counts={status:sum(any(attempt['status']==status for attempt in x['attempts']) for x in unique.values()) for status in ['PASS','FAIL','ERROR','SKIP']}
assert counts==dict(PASS=109,FAIL=1,ERROR=0,SKIP=1)
mixed={k:v['attempts'] for k,v in unique.items() if len(set(t['status'] for t in v['attempts']))>1}
ui={}
for label in ['v6-ui-pa','v6-ui-pb']:
 p=next(p for p in (a/(label+'-tmp')).glob('*/result.json') if not p.parent.is_symlink());v=json.loads(p.read_text());ui[label]=dict(status=v['status'],check_count=len(v['checks']),scenario=v['scenario'],native_browser='NOT RUN',real_human_semantic_acceptance='NOT RUN')
late=[]
for p in (a/'v6-late-matrix-tmp').glob('*/late-proof.json'):
 if p.parent.is_symlink():continue
 v=json.loads(p.read_text());late.append(dict(fault=v['fault'],status=v['status'],mock_requests=len(v['wire']),no_child_typed=v['no_child_typed'],no_child_save=v['no_child_save']))
summary=dict(status='NORMAL_BOUNDED_FLOW_DEMONSTRATED_WITH_RETAINED_SUPPLEMENTAL_BUDGET_FAILURE',qualified_source=reference['head'],core='22fa6903d8ceade8f5af359adf5687f041c6e574',source_count=465,source_changes=[],unique_identity_count=len(unique),unique_counts_are_nonexclusive=True,unique_counts=counts,mixed_attempts=mixed,raw_counts={k:sum(v.get(k,0) for v in results.values()) for k in ['passed','failed','errors','skipped','selected']},duplicate_cases=duplicates,suites=results,ui=ui,late=late,pb_success=json.loads((a/'v6-pb-public-success.json').read_text()),pb_exact_success=json.loads((a/'v6-pb-exact-public-success.json').read_text()),current_failure=json.loads((a/'v6-extra-pb-failure-public.json').read_text()),ruff='PASS',mypy='5 existing baseline errors; new set annotation issue fixed',independent='actual v6 source static review; 0 dynamic tests/Workers',not_run=['PostgreSQL','Windows','native browser','real/paid models','real human semantic acceptance','complete P-A/P-B product acceptance','remote CI','deployment'],private_udf_probe='BLOCKED: original explicit refusal, no retry/reconstruction/replacement',historical_failures=['7f5dfe20 old blocked delivery and previous archive unchanged','v4 initial timing-plugin import error','v4 PB correction before first request','v5 correction later lease/deadline failure','v5-r2 complete timing total-budget failure; no Worker loss'],history_not_in_final_totals=True)
(root/'SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');(a/'source-final.json').write_text(json.dumps(reference,indent=2)+'\n')
print(json.dumps(dict(counts=counts,duplicate_count=len(duplicates),raw=summary['raw_counts'],ui=ui),ensure_ascii=False))
