"""Normal owned synthetic header fault must not silently strand the Run."""
import copy,json
from sqlalchemy import select,update
from test_modified_correction_matrix import opened,prepared,queued
from test_natural_spec_apps import transport
from sim2act.db import runs,internal_instance_data
from sim2act.worker import Worker
from sim2act import pa_spec_apps

def test_claimed_natural_family_change_closes_without_execution(tmp_path):
    with opened(tmp_path,'pb') as (data,proof):
        _,commit=prepared(data,proof,'family-change-rejection');accepted=queued(data,proof,commit);rid=accepted['run_id'];sent=[]
        worker=Worker(data[0],data[1],goal_planner_transport=transport(sent,proof['content']))
        claimed=data[0].claim(worker.id,data[1].lease_seconds)
        assert claimed['id']==rid and claimed['context']['spec_family']=='pa-natural-spec-app.v1'
        with data[0].tx() as c:
            context=copy.deepcopy(claimed['context']);context['spec_family']='synthetic-invalid-family'
            c.execute(update(runs).where(runs.c.id==rid).values(context=context))
        pa_spec_apps.process_job(worker,claimed)
        with data[0].tx() as c:
            row=c.execute(select(runs.c.status,runs.c.error,runs.c.context,runs.c.lease_until).where(runs.c.id==rid)).mappings().one()
            typed=c.execute(select(internal_instance_data.c.version).where(internal_instance_data.c.run_id==accepted['app_run_id'])).scalars().all()
        assert row['status']=='FAILED' and row['error']['code']=='VERSION_CONFLICT',row
        assert 'family changed' in row['error']['message'].lower()
        assert row['lease_until']==0 and row['context']['requests']==0 and row['context']['tools']==0 and sent==[] and typed==[]
        (tmp_path/'family-change-public-proof.json').write_text(json.dumps(dict(status=row['status'],error_code=row['error']['code'],requests=0,tools=0,typed_versions=typed,wire_requests=len(sent)),indent=2)+'\n')
