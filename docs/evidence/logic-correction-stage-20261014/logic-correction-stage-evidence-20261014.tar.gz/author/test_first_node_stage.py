"""One ordinary owned synthetic READ, then explicit normal cancellation."""
import json
from sqlalchemy import select
from test_modified_correction_matrix import opened,prepared,queued
from test_natural_spec_apps import transport
from sim2act.db import runs
from sim2act.worker import Worker
from sim2act import pa_spec_apps

def test_first_read_stage_then_normal_cancel(tmp_path):
    with opened(tmp_path,'pb') as (data,proof):
        _,commit=prepared(data,proof,'bounded-first-read');accepted=queued(data,proof,commit);rid=accepted['run_id'];sent=[]
        worker=Worker(data[0],data[1],goal_planner_transport=transport(sent,proof['content']));claimed=data[0].claim(worker.id,data[1].lease_seconds)
        assert claimed['id']==rid
        assert pa_spec_apps.advance(worker,claimed) is True and sent==[]
        route='/api/internal/instances/'+proof['instance_id']+'/runs/'+rid
        status=data[2].get(route+'/control-status');assert status.status_code==200
        result=data[2].post(route+'/commands',json=dict(command='cancel',version=status.json()['version']));assert result.status_code==200
        with data[0].tx() as c:
            row=c.execute(select(runs.c.status,runs.c.context['requests'],runs.c.context['tools']).where(runs.c.id==rid)).one()
        assert row[0] in ('CANCEL_REQUESTED','CANCELLED') and row[1]==0 and row[2]==1
        (tmp_path/'bounded-read-public-proof.json').write_text(json.dumps(dict(status=row[0],requests=row[1],tools=row[2],model_wires=len(sent)),indent=2)+'\n')
