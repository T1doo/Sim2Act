"""Actual visible modified-version correction, original-key recovery and cold Worker."""
import hashlib,json,os,subprocess
from pathlib import Path
import pytest
from sqlalchemy import select
from test_modified_correction_matrix import ROOT,opened
from test_natural_spec_apps import transport
from test_pb_natural_specs import drive_to_success
from test_spec_app_operations import snapshot
from sim2act.api import create_app
from sim2act.db import Store,app_drafts
from fastapi.testclient import TestClient

@pytest.mark.parametrize('family,scenario',[('pa','normal'),('pb','run-lost')])
def test_visible_modified_rejection_one_correction_and_fresh_owner(tmp_path,family,scenario):
    with opened(tmp_path,family) as (data,proof):
        with data[0].tx() as c:app=c.execute(select(app_drafts.c.name).where(app_drafts.c.id==proof['review']['context']['app_id'])).scalar_one()
        before=snapshot(data[0]);info=dict(project=proof['project_id'],name=app,instance=proof['instance_id'],run=proof['parent_run_id'],goal_text=proof['review']['context']['goal']['goal'],scenario=scenario,output=str(tmp_path/'result.json'))
        path=tmp_path/'info.json';path.write_text(json.dumps(info));sent=[];worked=[];cold=coldclient=None;errpath=tmp_path/'node.stderr'
        with errpath.open('w') as err:
            process=subprocess.Popen(['node',str(ROOT/'modified-correction-ui.cjs'),str(path)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True,env={**os.environ,'NODE_PATH':'/workspace/node-tools/node_modules'})
            try:
                for line in process.stdout:
                    request=json.loads(line)
                    if request.get('done'):break
                    if request.get('command')=='worker':
                        cold=Store(data[1].database_url,test_only=True);coldclient=TestClient(create_app(cold,data[1]));coldclient.headers['Authorization']='Bearer synthetic-test-A';current=(cold,data[1],coldclient,*data[3:]);drive_to_success(current,request['rid'],transport(sent,proof['content']));worked.append(request['rid']);answer=dict(id=request['id'],status=200,text='{}')
                    else:
                        r=(coldclient or data[2]).request(request['method'],request['path'],json=request.get('body'),headers=request.get('headers'));answer=dict(id=request['id'],status=r.status_code,text=r.text,content_type=r.headers.get('content-type'))
                    process.stdin.write(json.dumps(answer)+'\n');process.stdin.flush()
                process.stdin.close();assert process.wait(timeout=20)==0,errpath.read_text();result=json.loads((tmp_path/'result.json').read_text());assert result['status']=='PASS' and len(sent)==2 and len(worked)==1
                web=Path('/workspace/Sim2Act-pa-provider/src/sim2act/web');assert len(result['static_resource_loads'])==20*result['boots']
                for row in result['static_resource_loads']:
                    name='index.html' if row['path']=='/' else row['path'][1:];assert row['sha256']==hashlib.sha256((web/name).read_bytes()).hexdigest()
                after=snapshot(cold or data[0])
                for table in ('internal_instance_data','natural_owner_records','natural_owner_seals'):assert all(row in after[table] for row in before[table]),table
                for table in ('app_drafts','internal_releases','goal_cards','goal_card_versions'):assert after[table]==before[table],table
                (tmp_path/'wire.json').write_text(json.dumps(sent,indent=2)+'\n')
            finally:
                if process.poll() is None:process.kill();process.wait(timeout=5)
                if coldclient:coldclient.close()
                if cold:cold.engine.dispose()
