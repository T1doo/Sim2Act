"""Actual qualified business proof survives only nested read-only gates."""
import json
from types import SimpleNamespace
import pytest
from sqlalchemy import select,update
from test_modified_correction_matrix import opened,prepared,queued
from sim2act import db,natural_spec_corrections as correction,pa_spec_apps
from sim2act.errors import DomainError
from sim2act.contracts import Limits
from sim2act.worker import Worker

def test_real_segment_rechecks_time_write_and_transaction(tmp_path,monkeypatch):
    with opened(tmp_path,'pb') as (data,proof):
        _,commit=prepared(data,proof,'handoff-life-boundary');accepted=queued(data,proof,commit);rid=accepted['run_id']
        worker=Worker(data[0],data[1]);claimed=data[0].claim(worker.id,data[1].lease_seconds);assert claimed['id']==rid
        with data[0].tx() as c:
            job=data[0].guard(c,rid,claimed['fence']);segment=correction.scope_segment(data[0],c,data[3],rid);assert segment is not None
            epoch=c.info.get('source_proof_write_epoch',0)
            # The real historical source gate clears the ambient slot but writes nothing.
            assert pa_spec_apps.job_scope_gate(data[0],c,data[3],proof['parent_run_id'])
            assert c.info.get('source_proof_write_epoch',0)==epoch
            assert correction.scope_segment(data[0],c,data[3],rid) is None
            assert correction.scope_segment(data[0],c,data[3],rid,_segment=segment) is segment
            with monkeypatch.context() as changed_clock:
                changed_clock.setattr(db,'time',SimpleNamespace(time=lambda:1e12))
                with pytest.raises(DomainError,match='GRANT_REVOKED'):
                    correction.scope_segment(data[0],c,data[3],rid,_segment=segment)
            assert c.info.get('source_proof_write_epoch',0)==epoch
            # Even a same-value owned write invalidates the old proof.
            c.execute(update(db.runs).where(db.runs.c.id==rid).values(goal=job['goal']))
            assert correction.scope_segment(data[0],c,data[3],rid,_segment=segment) is None
            pa_spec_apps.bound(data[0],c,data[3],job,Limits(**{k:getattr(data[1],k) for k in Limits.model_fields}))
        with data[0].tx() as c:
            assert correction.scope_segment(data[0],c,data[3],rid,_segment=segment) is None
        route='/api/internal/instances/'+proof['instance_id']+'/runs/'+rid
        status=data[2].get(route+'/control-status');assert status.status_code==200
        closed=data[2].post(route+'/commands',json=dict(command='cancel',version=status.json()['version']));assert closed.status_code==200
        (tmp_path/'scope-handoff-public-proof.json').write_text(json.dumps(dict(readonly_handoff=True,natural_time_rechecked=True,write_invalidates=True,new_transaction_invalidates=True,model_requests=0),indent=2)+'\n')
