"""Finite metadata cycle gate, without claiming synthetic graphs are valid apps."""
import copy

import pytest
from sqlalchemy import insert, update
from test_internal_lifecycle import create, limits, release

from sim2act import lifecycle
from sim2act.db import fingerprint, internal_approvals, internal_instances, internal_releases, new_id
from sim2act.errors import DomainError


def metadata_release(store, user, base, source):
    """New artificial envelope solely for iterative pointer-graph boundary tests."""
    snapshot = copy.deepcopy(base['snapshot'])
    snapshot['natural_logic_source'] = dict(namespace='natural-local-logic.v1', instance_id=source,
        preview_key='metadata-only', preview_fingerprint='a'*64, check_fingerprint='b'*64, execution_digest='c'*64)
    with store.tx() as c:
        a = lifecycle.new_approval(c, user, base['project_id'], 'release', dict(snapshot=snapshot))
        row = dict(id=new_id('irelease'), project_id=base['project_id'], principal_id=user,
            approval_id=a['id'], snapshot=snapshot, fingerprint=fingerprint(snapshot))
        c.execute(insert(internal_releases).values(**row))
        c.execute(update(internal_approvals).where(internal_approvals.c.id==a['id']).values(consumed=True))
    return row


def test_multilevel_metadata_existing_and_proposed_cycles_are_finite(env):
    store, user = env[0], env[3]
    base, _, _ = release(env); source=create(env,base); middle=create(env,base)
    first=metadata_release(store,user,base,source['id'])
    second=metadata_release(store,user,base,middle['id'])
    with store.tx() as c:
        c.execute(update(internal_instances).where(internal_instances.c.id==middle['id']).values(release_id=first['id']))
        trace=lifecycle.logic_release_trace(store,c,user,second)
        assert not trace['cyclic'] and len(trace['edges'])==2
        trace=lifecycle.logic_release_trace(store,c,user,second,proposed_instance=source['id'])
        assert trace['cyclic'] and len(trace['edges'])==2
    with pytest.raises(DomainError,match='cycle'):
        lifecycle.prepare_switch(store,user,source['id'],second['id'],source['revision'],limits(env))
    with store.tx() as c:
        # Represent a pre-existing damaged pointer graph, not a supported nested app.
        c.execute(update(internal_instances).where(internal_instances.c.id==source['id']).values(release_id=second['id']))
        with pytest.raises(DomainError,match='cycle'):
            lifecycle.read_release(store,c,user,second['id'],limits(env))
        with pytest.raises(DomainError,match='cycle'):
            lifecycle.prepare_switch(store,user,source['id'],base['id'],source['revision'],limits(env))


def test_unrelated_normal_switch_freezes_dependency_digest_and_duplicate_is_no_write(env):
    store,user=env[0],env[3];base,aid,fp=release(env);i=create(env,base);target,_,_=release(env,aid,fp)
    a=lifecycle.prepare_switch(store,user,i['id'],target['id'],i['revision'],limits(env))
    assert len(a['payload']['logic_dependency_fingerprint'])==64
    got=lifecycle.commit_switch(store,user,a['id'],a['fingerprint'],limits(env))
    assert got['revision']==i['revision']+1
    before=lifecycle.inspect_instance(store,user,i['id'],limits(env))
    with pytest.raises(DomainError):lifecycle.commit_switch(store,user,a['id'],a['fingerprint'],limits(env))
    assert lifecycle.inspect_instance(store,user,i['id'],limits(env))==before


def test_foreign_instance_cannot_read_dependency_metadata(env):
    base,_,_=release(env);i=create(env,base)
    with env[0].tx() as c, pytest.raises(DomainError):
        lifecycle.switch_preflight(env[0],c,env[4],i['id'],base['id'])
