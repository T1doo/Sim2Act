# 修改后的自然规范版本继续处理未见材料（2026-10-13）

从9bed3b2fb32ffbae3b5d2503396bc2aca153fb65有限接收切片接续，分支dev/logic-version-per-use-20261013。root唯一产品集成写入者；既有独审仅外部只读证据和测试。目标是F2-T07有限两模型依赖开关的新内部Release可继续处理未见材料，不提升完整AT13–15。

共享per-use保留原PA/PB来源以判family和审查原来源权限，但从当前核验的natural_logic_source有效candidate取得recipe与revision2。新材料/Goal由现有strict独立路线预览和明确同意批准，不复制执行器；逻辑候选不伪造原goal_application/spec_task混合来源。saved_logic_source封入独立USE双seal/回执；正常Worker的绑定优先per-use，新targetGoal优先default逻辑原Goal，入队/每个模型提交/最终SAVE保持当前权限、Goal、版本、fence与原预算检查。

旧app/draft/Release、原Goal、typed历史与人工声明保留；新的结果使用新实例/Run和自己的Goal。人工复审从PENDING及空判断开始，测试合成声明不改机器UNKNOWN/NOT_RUN/PENDING，不开放发布。PA先验证，PB独立验证。

独审实际红例保留：检查artifact READ撤销后audit仍返回原摘要；旧Release GET在同Release实例切换后晚返回，覆盖新预览并重复panel。修复后audit每次活读验证逻辑来源、完整执行digest及独立JOB/CHECKED，不能把已封origin常量当活检查。页面新增GET/hash以原实例、selection、workspace、connection和单调render代次核对，并核完整snapshot hash。

PB实际633.52秒轮检查成功而新材料Run在原3claims上限内未成功，失败DB/claim原样保留；未加预算。修复仅复用当前完整draft/user/Limits及同Connection+RootTransaction的已授权验证结果，所有scope/draft/family/compile/sourcebytes/Goal/graph/locks/digest照验，post-model提交每次新call完整+活检查；不跨事务缓存。原shape/anchor/CHANGED/config排除不扩大。

旧候选种子在新软件下图基线闭拒：保留409/旧probe SKIP，不重签/改seal/软件或graph上下文，不据此签绿。当前fresh成功种子才能作有效对照。其余夹具NameError、c.id、封存脚本断言、源map测试行桥全部完整留证，按真实来源与执行计数。

终态冻结、PASS/FAIL/SKIP、完整可见路径、控制器和compound probes单列见最终SUMMARY/报告。真实模型/付费请求0；PG/Windows/native浏览器、真实人工语义、旧软件/旧库升级、source退休、链式修改、任意PROJECT UNKNOWN、完整PA/PB、CI、部署/发布均不提升。已拒browser/CI路径未重试。当前正常环境、默认网络与开发分支授权持续；main/coredev/旧分支和ownerWIP不改。
