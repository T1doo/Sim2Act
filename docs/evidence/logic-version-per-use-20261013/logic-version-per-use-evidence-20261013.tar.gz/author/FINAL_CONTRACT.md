# 修改后的内部版本继续处理未见材料

有限合同：共享 per-use 保留原 P-A/P-B 来源及身份权限，从当前已核验 natural_logic_source 的 effective candidate 获取实际 recipe。目标材料、Goal、预算、版本和精确确认逐项冻结，入队及每个实际 Worker 提交重验。旧 recipe 指纹拒绝。新结果独立人工复审，测试使用合成声明，机器语义状态仍 UNKNOWN、owner PENDING、发布禁用。

代码：pb_natural_uses.py 的 review/bound/audit；pa_spec_apps.py 的绑定及提交守卫；app_jobs.py 的 per-use 路由；lifecycle/apps/natural_logic_patches 的仅同事务完整来源验证复用；web/internal.js 的有效 recipe 预览、快照哈希、实例/选择/workspace/connection/render 等待栅栏。原始草案、旧 Release、Goal、typed 历史和人工锁均保留。

有限依赖开关只改变 qualifiers 是否依赖 prior_items/prior_feedback，固定两模型、六步骤，不扩大 PROJECT UNKNOWN 或任意语义依赖，不复制执行器。新逻辑候选不能混入原 goal_application/spec_task 生成标记。

性能修复只跳过当前只读 call、同 Connection/RootTransaction/user/Limits/Release 指纹完全匹配的重复来源验证。初次 bound 已验证当前完整 Release，入口 audit 可用其结果；实际 post-model commit_guard 不传私有 memo，再完整验证及实时摘要。无跨事务缓存，不扩大 lease、deadline、requests/tokens。

保留全部失败：独审 artifact READ 撤销红例及同 Release ABA UI 红例、P-B 夹具 import NameError、原三 claims/原300秒 deadline 未通过的两轮实际 P-B、旧 seed 图基线409/SKIP、外部测试/封存脚本错误。没有重签旧 seed 或重写 graph/软件/来源 seal。

NOT RUN：真实模型/付费 API、PG、Windows、native browser、真实人工语义验收、旧源码/旧数据库升级、完整 P-A/P-B、source 退休与链式任意修改、远端 CI、部署/发布。既有拒绝 browser/CI 路径未重试。
