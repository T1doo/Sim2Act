import cProfile,pstats,io,time,shutil,json
from pathlib import Path
from sqlalchemy import select
from sim2act.db import Store,runs
from sim2act.contracts import Limits
from sim2act.config import Settings
from sim2act import pa_spec_apps as spec
src=Path('/workspace/logic-version-per-use-evidence-20261013/author/pb-perf-final-tmp/test_pb_modified_release_third0/fixture.db');dst=src.parent/'profile-copy.db';shutil.copyfile(src,dst)
s=Store('sqlite:///'+str(dst),test_only=True);settings=Settings('sqlite:///'+str(dst),dst.parent,mode='mock',goal_planner_provider='intern-s2');limits=Limits(**{k:getattr(settings,k) for k in Limits.model_fields})
p=cProfile.Profile();start=time.monotonic()
with s.tx() as c:
 job=c.execute(select(runs).where(runs.c.id=='run_20e95407889c449aa57ae436c5fb81bf')).mappings().one()
 p.enable();b=spec.bound(s,c,job['principal_id'],job,limits);p.disable()
out=io.StringIO();pstats.Stats(p,stream=out).sort_stats('cumtime').print_stats(35)
Path('/workspace/logic-version-per-use-evidence-20261013/author/profile-pb-bound.txt').write_text(out.getvalue());print(time.monotonic()-start);print(out.getvalue())
s.engine.dispose()
