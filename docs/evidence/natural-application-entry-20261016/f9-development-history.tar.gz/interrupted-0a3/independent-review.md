# F2-T05 自然规范应用入口独立复核

复核时间：2026-10-16 UTC。只读独审；未修改仓库，未访问旧实例，未复制源码树，未调用真实模型。

## 冻结与范围

- 基线：`8fc70cc43a6ac81cd522249e8a3d367cd66c9238`。
- 最终复核提交：`0a3e8d01fb67cf95505b21632e166f6c598072ab`；本次复核 HEAD 精确一致，`git status --short` 为空。
- 首次产品/导航复核冻结为 `bd23f9f72cd6d92c06867716ec2b8dfc7129426c`。最终提交只调整新 HTTP 测试 driver 的 PA/PB 断言；`git diff --exit-code bd23f9f..0a3e8d0 -- src` 成功，六产品文件字节全部不变。
- 比对全部 10 个变动文件：6 个产品文件、3 个测试文件和 `docs/F2/NaturalApplicationEntry20261016.md`。`git diff --check` 通过。
- 规范来源已读原 `docs/平台产品设计.md`、`docs/分阶段开发计划.md` F2-T05，以及 `docs/F2/ApplicationUsePlan.md`；已核实际 `pb_natural_uses.saved_family/review/mount`、`internal_api`、`lifecycle.instance/data_rows` 等原合同。

## 产品静审结论

本次有限接入范围未发现剩余必须修产品问题。

1. 目录分类仅增加 namespace、spec_task.kind、spec_binding.kind 标量和已有生成标记的导航提示；不返回完整候选、Goal 或授权证明。提示与完整打开再次比对；错误/损坏候选不因此取得执行权限。
2. 自然入口走既有 `showApp -> openInternal -> showInternalInstance -> renderPBUse`，仍用原 `pa-use` / `pb-use` 逐次预览、确认、提交与原 key GET 恢复。未改 executor、Principal、Grant 策略、后台派发、预算或数据库结构。
3. `openSavedNaturalUse` 捕获连接、项目、工作区和应用代际；finally 按精确 `selectionCurrent` 函数归属释放。内部历史/实例读取追加连接、工作区及选择代际，不能被迟到响应接管。
4. `showInternalRun` 在成功后读取相同 Run 的人工合同；历史成果卡可回到该 Run。切换到尚未成功/不可读 Run 会清旧人工选择、证据与 ACCEPTED 状态，避免旧声明代表本次任务。
5. 原普通规范 durable localStorage/Web Lock 请求记录、原 per-use pending 结构、精确指纹/版本检查、未知回执禁止重复提交的合同保持原实现；新增入口不创建 Run、Release 或实例。
6. 目录明确家族、定义版本、Release、实例修订、结果版本、逐次 TXT/MD + Goal、内部未发布、真实模型关闭及人工 PENDING 边界。

前轮审查提出的 workspace ABA、finally 归属和旧 ACCEPTED 文字残留问题均已修复并在冻结导航探针复验。

## 独立实际运行

运行命令：

```text
/workspace/sim2act-venv/bin/python -m pytest -q tests/test_natural_application_entry.py::test_natural_entry_navigation_synthesized_api --basetemp=/tmp/f2-entry-independent-final --junitxml=/tmp/f2-entry-independent-final.xml
```

实际结果：1 passed，0 failed，0 skipped；7.57 秒；一条 Starlette TestClient 弃用警告。精确 XML：`/tmp/f2-entry-independent-final.xml`；原始导航 JSON：`/tmp/f2-entry-independent-final/test_natural_entry_navigation_0/navigation.json`。

该测试在 `bd23f9f` 加载生产 index/app/internal/use/owner 脚本，用合成 GET API、局部 renderer stub 和 JSDOM；31 条导航检查，以及后续实例工作区 ABA 和旧人工 ACCEPTED 清除检查通过。覆盖等待应用 GET/内部历史/实例 GET 三阶段的 workspace/project/identity ABA，双选择及同 view 的实例切换；零 POST。最终 `0a3e8d0` 对应产品文件及导航测试字节完全相同，故保留此前精确资源 hash 的证明，本次未重复运行。

另直接执行了同一冻结 Node 导航脚本，结果 PASS/31，原始回执 `/tmp/f2-entry-independent-navigation.json`。首次尝试默认 `python` 无 pytest，未运行测试；随后使用本环境已有 `/workspace/sim2act-venv` 成功，未新增安装。

本独审未自行运行新 HTTP/Worker 三节点；只静审其实现。根线程的最终执行结果应单独作为实际 HTTP/Worker 证据。

## 测试合同修正复核

此前指出 `bd23f9f` 新 HTTP driver 把 PA 专有 `instance_data_version` / `real_model_allowance` 字段用于 PB。`0a3e8d0` 的 8 增 2 删仅修这两个断言：PA 仍核原字段，PB 核已有有效候选的有限 max_requests 和原允许动作集合；两族共同核零 new_model_requests、零 artifact_writes、formal_publication_enabled=false。与原 per-use API 家族差异一致，没有为测试扩展 API；此问题已闭合。小差异的 `git diff --check` 通过。

本报告结论：最终提交的产品静审、测试合同复核和相同产品字节的独立导航证据通过；无剩余必须修问题。根线程最终七节点仍在执行，本报告不能单独当作三个新 HTTP/Worker 节点已通过的证明，也不计任何被中断运行的结果为通过。

非阻塞的证据精度说明：PB driver 的 permissions.every 证明现有列表没有其它动作，并非单独证明两个权限项均存在；原始响应回执和服务端现有重建门仍保留，不能据该一句断言声称权限集合的完整精确等价测试。

## 未执行与原有缺口

Windows、原生浏览器、PG、真实模型、真实材料场景/人工语义、远端 CI 和部署均非本独审执行证据。未重复底层 Worker 重启/取消矩阵。旧环境最终独审未落盘及历史作者 1P XML 独立核验不足仍未补回。

## 冻结文件 SHA256

```text
b659bfd6d1eb46a9de5c07c879cd6726788339b3726d832afdc0b1ed0865abfe  src/sim2act/api.py
dc8a663af5b29e768d58ff4b8aad535f49f687b3132826fc502dafaa39c3c164  src/sim2act/web/app.js
f072c927b78fac20e66fe8d11421b7c1e684404c2fe7e7d1111a1d9dd70b6831  src/sim2act/web/index.html
2fc015917cf2908fa59503f4453c48029542e00e80a8daae0dd886546bd00564  src/sim2act/web/internal.js
7d2c748910520f1d1aa811ec208387c994aad8fe1577cf420da0b228b76d58d0  src/sim2act/web/owner-review.js
cb849bc3ff79151cb37a5eb51ca8d8c8ad4d70d8e3d2ce87280959c08dd022dc  src/sim2act/web/use.js
f85088fa1fe94353d4a42dbdde9c4372850c238a0717e23fbcbcb95598722328  tests/natural_application_entry.cjs
15fbaaefde20c2377b7fee1c05170ba98885d7dd4b04b76788daef054a7448f5  tests/natural_application_navigation.cjs
e5dadff6dfd0da05a47337ff8ddb3eb9c2d655be6463e9a1f730e469698aca76  tests/test_natural_application_entry.py
52c81514e5330aaa8e900491bebe85159b22fd9a568631357ef554c1015c8b59  docs/F2/NaturalApplicationEntry20261016.md
```
