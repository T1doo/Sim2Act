"""Copied actual fa14 success history; each correction uses a new actual Worker."""
import hashlib,json,shutil
from dataclasses import replace
from pathlib import Path
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select
from sim2act.api import create_app
from sim2act.config import Settings
from sim2act.db import Store,internal_instances,internal_run_bindings,runs
import test_natural_spec_corrections as tests

ROOT=Path('/workspace/natural-spec-correction-evidence-20261013/author')
OLD=Path('/workspace/natural-spec-owner-evidence-20261013/author')
SEEDS={}
for family in ('pa','pb'):
    info=json.loads((OLD/(family+'-seed-proof.json')).read_text())
    seed=ROOT/(family+'-historical-success.db');shutil.copyfile(info['seed'],seed)
    assert hashlib.sha256(seed.read_bytes()).hexdigest()==info['sha256']
    (ROOT/(family+'-seed-provenance.json')).write_text(json.dumps(info,indent=2))
    store=Store('sqlite:///'+str(seed),test_only=True)
    settings=Settings('sqlite:///'+str(seed),ROOT/(family+'-reader'),mode='mock',goal_planner_provider='intern-s2')
    client=TestClient(create_app(store,settings));client.headers['Authorization']='Bearer synthetic-test-A'
    rid=info['run_id']
    with store.tx() as c:
        snap=c.execute(select(internal_run_bindings.c.snapshot).where(internal_run_bindings.c.run_id==rid)).scalar_one()
        inst=dict(c.execute(select(internal_instances).where(internal_instances.c.id==snap['instance_id'])).mappings().one())
        actor=c.execute(select(runs.c.principal_id).where(runs.c.id==rid)).scalar_one()
    goal=client.get('/api/goal-cards/'+snap['spec_goal']['card_id']).json()
    artifact=client.get('/api/internal/app-run-jobs/'+rid+'/spec-artifact');assert artifact.status_code==200,artifact.text
    checklist=json.loads(artifact.json()['resource']['content'])
    resource=goal['content']['resource_refs'][0]
    data=(store,settings,client,actor,inst['project_id'],resource,goal)
    path=f"/api/internal/instances/{inst['id']}/runs/{rid}/spec-owner-review"
    SEEDS[family]=((data,inst,rid,resource,goal,checklist['source_content'],path),seed)

@pytest.fixture(autouse=True)
def copied_success(monkeypatch,tmp_path):
    stores=[];clients=[]
    def flow(env,family='pa'):
        result,seed=SEEDS[family];old=result[0]
        dst=tmp_path/(family+'-isolated.db');shutil.copyfile(seed,dst)
        assert hashlib.sha256(seed.read_bytes()).digest()==hashlib.sha256(dst.read_bytes()).digest()
        store=Store('sqlite:///'+str(dst),test_only=True);stores.append(store)
        settings=replace(old[1],database_url='sqlite:///'+str(dst),data_dir=tmp_path)
        client=TestClient(create_app(store,settings));clients.append(client);client.headers['Authorization']='Bearer synthetic-test-A'
        return (store,settings,client,*old[3:]),*result[1:]
    monkeypatch.setattr(tests,'flow',flow)
    yield
    for c in clients:c.close()
    for s in stores:s.engine.dispose()

test_explicit_rejection_to_actual_new_result_and_fresh_owner=tests.test_explicit_rejection_to_actual_new_result_and_fresh_owner
test_preconfirm_invalid_source_no_partial_run=tests.test_preconfirm_invalid_source_no_partial_run
test_withdraw_after_queue_prevents_worker_result=tests.test_withdraw_after_queue_prevents_worker_result
test_duplicate_consent_keys_and_cancel_control=tests.test_duplicate_consent_keys_and_cancel_control
import test_natural_spec_corrections_ui as ui
test_original_worker_proof_pollution_stops_correction=tests.test_original_worker_proof_pollution_stops_correction
test_late_model_reply_after_declaration_withdrawal_cannot_commit=tests.test_late_model_reply_after_declaration_withdrawal_cannot_commit
test_cancelled_correction_keeps_original_result=tests.test_cancelled_correction_keeps_original_result
test_visible_rejection_correction_and_independent_owner=ui.test_visible_rejection_correction_and_independent_owner
