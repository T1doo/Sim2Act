import json
from sqlalchemy import select,update
from sqlalchemy.exc import DatabaseError
from sql_private_barrier import PrivateReadBarrier
from sim2act.db import runs
import seeded_cases as seeds
from test_natural_spec_corrections import rejected,prepare_correction
copied_success=seeds.copied_success


def test_foreign_source_pointer_has_no_private_resource_evaluation(env,tmp_path):
    data,inst,parent,_,_,_,_,base,body=rejected(env)
    _,commit=prepare_correction(data,base,body)
    r=data[2].post(base+'/correction-runs',json=commit);assert r.status_code==202,r.text
    child=r.json()['run_id']
    auth=data[2].headers['Authorization'];data[2].headers['Authorization']='Bearer synthetic-test-B'
    project=data[2].post('/api/projects',json=dict(name='Foreign observer-only project')).json()['id']
    resource=data[2].post(f'/api/projects/{project}/resources',json=dict(name='private.txt',format='txt',content='FOREIGN_PRIVATE_SENTINEL')).json()['id']
    data[2].headers['Authorization']=auth
    with data[0].tx() as c:
        c.execute(update(runs).where(runs.c.id==parent).values(resource_refs=[resource]))
    thrown=None;response=None
    with PrivateReadBarrier(data[0],set(),{resource}) as barrier:
        try:
            response=data[2].get(base+'/correction-requests/'+body['request_key'])
        except DatabaseError as error:thrown=type(error).__name__
    proof=dict(blocked=barrier.blocked,evaluated=barrier.evaluated,statements=barrier.statements,
        exception=thrown,http_status=response.status_code if response is not None else None,parent=parent,child=child)
    (tmp_path/'private-source-probe.json').write_text(json.dumps(proof,indent=2))
    assert not barrier.blocked,proof
    assert response is not None and response.status_code==409,response.text if response is not None else thrown
