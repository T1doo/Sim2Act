# WIP independent static review

Review on accepted base 5f943df9c17a39241feab647781456ae7871ca79 with four modified production files, one new production file and a new test file (see context.json). Product writer is root; reviewer made no product edits. Exact reviewed production bytes are saved here; source-map.json identifies 454 files. Dynamic tests NOT RUN; static concerns are not claimed as observed response leaks.

## R1: selected parent proof is not continuously revalidated (blocking contract gap)

natural_spec_corrections.gate compares only internal_run_bindings.fingerprint column to Reference.parent_binding_fingerprint, and old typed fingerprint/version columns. It does not read/verify old binding.snapshot selfhash, old Run.fingerprint/status/cancel_intent, or the old successful operation/Attempt/receipt evidence. bound later verifies only old typed.data selfhash and AppRun.output fingerprint. pa_spec_apps.audit_fingerprint's correction branch hashes ref + current app_draft origin audit; it excludes the selected rejected parent Run's actual proof/audit (especially PB per-use accepted overlay evidence).

The preview verifies full parent proof, but after preview a parent binding snapshot/Attempt/receipt can change while its fingerprint metadata remains unchanged; the current child guard does not necessarily catch that change. Old cancel_intent corruption is also not checked by natural_authority, whose terminal gate checks status only. This is a source-freeze/revalidation gap, not an established normal unauthorized disclosure. It must be covered by actual fault-injection before acceptance.

Minimum repair: after existing metadata/material/artifact gates, independently verify the historical parent successful job with spec.verify_job using original accepted binding; parent correction is expressly forbidden so no correction recursion is needed. Freeze the parent actual audit + exact proof/ledger digest at preview/confirm. Each child reservation/SAVE guard checks that digest and parent terminal/cancel metadata, in addition to the existing source typed/output/seal/body checks. Final readback verifies full proof. Preserve target-before-body order. Do not call unchanged natural_context for this historical verification, because it rejects the child active Run and later result version.

Required counterexample: accepted preview, alter old parent binding.snapshot without updating metadataFP, or old verified Attempt/receipt while preserving output/typed; confirmed/running child must reject atomically/no new SAVE. Test actual PB C lineage as well as PA. Verify old proof changed during model inflight rejects late SAVE.

## R2: preview needs an explicit fresh execution envelope

preview returns new_model_requests=0 and artifact_writes=0 while confirmation proposes an actual new extraction Run. These appear to be preview-only counts but are not named as such. It contains effective candidate runtime limits via candidate, not an explicit normalized proposed current/frozen min budget envelope. Confirmation compares old natural_context, which does not capture newly proposed caller limits. API mount limits are normally stable, so this is not evidence of a currently reproducible widened budget, but explicit user cost approval must describe the new Run rather than a zero-count preview.

Expose preview-executed counts distinctly and proposed model-node count/SAVE count/request-token-tool/run time minima. Hash the proposed envelope into review; enqueue uses/revalidates that envelope. No new grant issuance; no old model budget inheritance.

## Checked and consistent接线

- enqueue prohibits mixing correction with pb_use/offline/owner goal; normalized request and load_binding reconstruction both include human_correction and correction_request. Source_goal and expected_resource correctly select the sealed actual rejected material/Goal, retaining PB C.
- approve requires current natural_context, exact declaration/latest sequence/reasons payload and 15-minute preview, no accepted sibling and no correction parent. Project lock plus accepted insertion makes the one-child check atomic. Parent old ledger remains unchanged and child owner state is PENDING.
- gate authenticates independent accepted ledger/seal plus event, then parent natural_scope/natural_authority before full parent typed/output/declaration/review content. It rechecks original REJECTED metadata, current Goal, source typed fingerprint/version, revision/Release, and base data_version for nonterminal child. The terminal exemption permits own successful history/readback. Each normal commit_guard calls job_scope_gate; original REVOKE therefore invalidates active child.
- Parent authority's four artifact ids and material READ remain before private bodies; child source gate does not recursively visit a correction parent. Read/list/inspect gating still routes through job_scope_gate for accepted spec rows. Existing missing-marker/seal independent hints are preserved.
- model messages conditionally append feedback only for correction; ordinary message construction is unchanged. reservation_check and prove_node reconstruct the same messages/wire digest, so feedback affects actual model proof.
- Correction routes wrap initial load and enqueue failures in existing rollback-only DomainError proof. No accepted same-key proof is minted. Scalar accepted-reference search checks iid/key and bodyFP is exact. Original-key recovery first parent authority then child gate/full verification; changed accepted key cannot enqueue another child. Validation422 machine proof/UI still needs implementation and separate validation if correction pending uses that outcome.

These observations do not replace tests. Blocking issue R1 and preview-contract issue R2 were sent to parent immediately; root may choose fixes and request a fresh frozen review.
