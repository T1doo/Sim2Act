# Frozen correction independent review

Frozen HEAD 1b078d81ed1c346ce4527fa4481ec46294c6f51c; core c45fc6de70b25c9bed015841c5ca165302cfe4d1. Read-only reviewer made no product/test changes. Exact 456 source/test/pyproject files are archived at source-final, with before/after maps. This SHA's independent tests: 23 PASS, 0 FAIL, 0 ERROR, 0 SKIP; 17.213 wall seconds. Scope qualification22 plus existing literal-owner explicit ACCEPT1 (ordinary NoModel), not the author's natural Worker matrix. Raw stdout/stderr, XML, temp DB and exact command retained.

## Addressed prior concerns

R1 parent-proof stability now covers full parent Run, binding, frozen contract, Attempts, reservations, operations/intents/effects/events, material/artifact resource rows and Goal rows. Preview first verifies actual successful parent, stores parent_proof_digest, and gate compares that digest at every worker guard while revalidating original declaration payload hash. No correction parent is permitted. This removes the previously identified missing parent snapshot/Attempt/receipt/cancel byte checks, subject to the new authorization-order concern below.

R2 proposed_limits are minimum of current caller limits, parent frozen Run limits and exact original effective candidate manifest; review seals proposed_model_nodes, at most one artifact SAVE and real model allowance zero. Submit supplies these minimum limits and approve requires equality. UI displays these values beside original Goal/criteria, exact rejected declaration and result version. Original code prompts remain identical without correction. Child metadata/receipt proof uses the same selected actual source/Goal; no PB re-grant or default-B substitution.

own staged SAVE exception now permits base_data_version+1 only when this child's exact AppRun is SUCCEEDED and an exact child typed row has that same version; unrelated sibling result change remains denied. Parent REVOKE/latest ledger changes still deny inflight child. Original declaration/typed rows are not overwritten.

## Remaining P1 static concern: proof_digest data-driven extra-resource reads

proof_digest(c,rid) obtains resources selection ids from parent Run.resource_refs and all local_effects.resource_id for that parent's operations; it then selects full resources rows. Earlier natural_authority authorized original independently accepted material and the four equal saved-artifact pointers, not every potentially altered id in those two lists. Corruption of Run.resource_refs to include a denied foreign resource, or an extra non-SAVE effect to point at another resource, can therefore cause an extra private resource row to be read before changed digest rejects. The binding snapshot also chooses Goal row ids for full-row read without an independently scoped Goal id/project preflight.

This is a static ordering hypothesis, not an observed normal response leak. It was immediately reported to root with request for actual row-observer red evidence. A minimal safe repair is authorize/reconcile scalar refs against exact independent parent source id and four-way agreed artifact id before selecting any resource body; authorize all allowed effect resource ids or reject them metadata-only. For Goal rows, require exact sealed ref.goal_id/project/version metadata first. Keep full parent snapshot/evidence equality check after scoped authority. Merely relying on digest mismatch after the read does not establish pre-read protection.

The reviewer cannot call this frozen change fully accepted while that concrete P1 hypothesis remains unresolved. This does not invalidate the 23 actual tests: those test qualification and old owner, not corrupted correction-resource pointers.

## UI static findings

Correction pending maps use identity/token/project/iid/connection/original Run scope. Prepare captures fence/serial/context and rechecks after async hashes; expected declaration id/fingerprint and contextFP are checked. Run POST captures original scope/key/rid/body, and only initial matching scoped rollback proof can clear that same original pending object. Network/500 and GET failures preserve original-key recovery; navigating late responses cannot overwrite new view content. GET recovery verifies identity/original Run/reviewFP, distinct child Run, pending stage/key and same body previewFP. New result view explicitly shows old reason -> current same criterion without claiming repaired or inheriting ACCEPT. Preview creation known rejection remains conservative GET-only pending; no machine negative proof/422 clearance claimed for it.

Qualification76 file count/pin are independently recorded in FINAL_SUMMARY; tests check exact file set, original CHANGED list, unchanged anchor, nonliteral pin rejection and config exclusion. No broad whitelist exception added.
