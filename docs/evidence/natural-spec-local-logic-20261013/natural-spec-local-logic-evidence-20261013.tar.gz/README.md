# 局部自然逻辑证据

终态来源为 SOURCE_FINAL.json 中的 8cffbaa0c8cd28a9ee1b8a635ae18913aa07db10；源 src/tests/pyproject 461 文件。精确77Python资格保持8188版本的 pin 18173c130264bf9cf137ba0eff74f3f316ce2e367cd092dc5c3347fd05c16072。

- author：实际命令、每轮stdout/stderr/XML、源前后映射、SQLite、普通Worker claim记录、当前HTTP资产、可见操作及模型输入；history保留早期失败和外部控制器各修正前版本。
- independent-r2：8188实际fresh检查与版本确认、1复合PASS/10fault、保护cell屏障及完整statement trace；只读同字节Python桥见independent-backend-bridge。
- independent-ui-r3：8cff实际fresh API/Worker夹具及4current controller探针，不能当完整用户路径。
- 其余 independent-*：原设计、静态候选、实际红例、夹具失败和旧轮，不能增加终态PASS分母。
- source-final：全部461源码/测试的准确冻结字节；SUMMARY.json区分当前终态、同字节桥和失败历史；MANIFEST.json逐成员size/SHA256，归档回读验证在交付回执。

所有身份/材料/模型均合成测试；真实付费调用0。原生浏览器/PG/Windows/真实语义与完整P-A/P-B不提升。终态程序与外部测试脚本亦作为证据保存，不覆盖以前的失败。
