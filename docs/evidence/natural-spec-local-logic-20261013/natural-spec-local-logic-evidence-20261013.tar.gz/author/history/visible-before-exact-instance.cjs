"use strict";
// Normal visible flow only: actual TestClient HTTP and cold Worker via IPC.
const fs=require("node:fs"),assert=require("node:assert/strict"),crypto=require("node:crypto"),readline=require("node:readline"),{JSDOM}=require("jsdom");
const info=JSON.parse(fs.readFileSync(process.argv[2])),checks=[],actions=[],requests=[],assets=[],pending=new Map();
let dropLogic=info.scenario==="lost",dropVersion=info.scenario==="lost",serial=0,dom,w,$,boots=0,activeFetches=0,intervals=new Set(),dropGoal=false,dropDecision=false,dropCorrection=info.scenario==="lost",generated=null;
readline.createInterface({input:process.stdin}).on("line",line=>{const value=JSON.parse(line),resolve=pending.get(value.id);pending.delete(value.id);resolve(value);});
const rpc=body=>new Promise(resolve=>{const id=++serial;pending.set(id,resolve);process.stdout.write(JSON.stringify({id,...body})+"\n");});
const check=(ok,label)=>{assert(ok,label);checks.push(label);};
async function wait(test){const until=Date.now()+12000;while(Date.now()<until){if(test())return;await new Promise(resolve=>setTimeout(resolve,5));}throw Error("page wait elapsed");}
function visible(el){if(!el?.isConnected)return false;for(let node=el;node;node=node.parentElement){const s=w.getComputedStyle(node);if(node.hidden||node.hasAttribute("inert")||s.display==="none"||s.visibility==="hidden")return false;if(node.tagName==="DETAILS"&&!node.open&&!node.querySelector("summary")?.contains(el))return false;}return true;}
async function gesture(el,perform,bindings){assert(visible(el),`visible ${el?.id||el?.textContent}`);assert(!el.matches(":disabled"),`enabled ${el.id}`);el.focus();const work=[],restore=[];for(const [node,property] of bindings){const original=node?.[property];if(typeof original!=="function")continue;const wrapper=function(event){const value=original.call(this,event);work.push(Promise.resolve(value));return value;};node[property]=wrapper;restore.push(()=>{if(node[property]===wrapper)node[property]=original;});}actions.push({id:el.id||el.textContent,visible:true,enabled:true});try{perform();await Promise.all(work);}finally{restore.forEach(fn=>fn());}}
const click=value=>{const el=typeof value==="string"?$(value):value;return gesture(el,()=>el.click(),[[el,"onclick"],[el.form,"onsubmit"]]);};
const edit=(id,value)=>{const el=$(id);return gesture(el,()=>{el.value=value;el.dispatchEvent(new w.Event("input",{bubbles:true}));el.dispatchEvent(new w.Event("change",{bubbles:true}));},[[el,"oninput"],[el,"onchange"]]);};
const confirm=id=>{const el=$(id);return gesture(el,()=>{el.checked=true;el.dispatchEvent(new w.Event("change",{bubbles:true}));},[[el,"onchange"]]);};
const nav=id=>click(w.document.querySelector(`#workspace-nav [data-tab=${id}]`));
const appButton=name=>[...$("app-list").querySelectorAll("button")].find(b=>b.closest(".row").textContent.includes(name));
async function closePage(){if(!dom)return;for(const id of intervals)w.clearInterval(id);intervals.clear();await wait(()=>activeFetches===0&&pending.size===0);await new Promise(resolve=>setTimeout(resolve,0));await wait(()=>activeFetches===0&&pending.size===0);dom.window.close();dom=null;}
async function boot(){await closePage();const boot=++boots;const load=async path=>{const r=await rpc({method:"GET",path});assert.equal(r.status,200);assets.push({boot,path,status:r.status,sha256:crypto.createHash("sha256").update(r.text).digest("hex")});return r.text;};dom=new JSDOM(await load("/"),{url:"http://testserver/",runScripts:"dangerously",pretendToBeVisual:true});w=dom.window;const originalInterval=w.setInterval.bind(w);w.setInterval=(...args)=>{const id=originalInterval(...args);intervals.add(id);return id;};const css=w.document.createElement("style");css.textContent=await load("/app.css");w.document.head.append(css);$=id=>w.document.getElementById(id);Object.defineProperty(w,"crypto",{value:crypto.webcrypto});w.TextEncoder=TextEncoder;w.structuredClone=structuredClone;w.fetch=async(path,options={})=>{const request={method:options.method||"GET",path,headers:options.headers||{},body:options.body?JSON.parse(options.body):undefined};requests.push(request);activeFetches++;try{const r=await rpc(request);if(request.method==="POST"&&path.endsWith("/logic-patches/checks")&&dropLogic){dropLogic=false;throw Error("synthetic lost check response");}if(request.method==="POST"&&/\/approvals\/[^/]+\/commit$/.test(path)&&dropVersion){dropVersion=false;throw Error("synthetic lost internal version response");}if(request.method==="POST"&&path.endsWith("/pa-use-runs")&&dropCorrection){dropCorrection=false;throw Error("synthetic lost PA per-use reply");}if(request.method==="POST"&&path.endsWith("/owner-goals")&&dropGoal){dropGoal=false;throw Error("synthetic lost own goal reply");}if(request.method==="POST"&&path.endsWith("/spec-owner-review-requests")&&request.body.command==="DECIDE"&&dropDecision){dropDecision=false;throw Error("synthetic lost decision reply");}return new Response(r.text,{status:r.status,headers:{"Content-Type":r.content_type||"application/json"}});}finally{activeFetches--;}};for(const script of [...w.document.querySelectorAll("script[src]")]){const node=w.document.createElement("script");node.textContent=await load(script.getAttribute("src"));w.document.body.append(node);}await edit("token","synthetic-test-A");await click("connect");await wait(()=>$('login').hidden&&$('project-select').value===info.project);}

(async()=>{let status="FAIL",error=null;try{
 await boot();await nav("apps");await click(appButton(info.name));await click($("internal-instances").querySelector("button"));
 check(visible($("natural-logic-panel")),"existing two-model application local logic panel visible");
 await click("natural-logic-preview");let review=JSON.parse($("natural-logic-proof").textContent);const key=$("natural-logic-key").value;
 check(review.namespace==="natural-local-logic.v1"&&review.request_key===key,"exact local logic request");
 check(review.context.app_id===info.app&&review.context.instance_id===info.instance&&review.context.release_id===info.release,"original app/version/instance frozen");
 check(review.context.goal.snapshot.content.unresolved.length===16,"all original human unresolved criteria visible");
 check(review.effective_candidate.spec_recipe.steps[2].inputs.prior_feedback.ref===review.effective_candidate.spec_recipe.steps[1].step_id,"actual recipe prior feedback dependency added");
 check(review.preserved_action_definitions.length===5,"five original action definitions preserved");
 check(review.impact.revalidation_scope==="APP"&&review.semantic_status==="UNKNOWN","semantic unknown expands actual application checks");
 check($("natural-logic-check").disabled&&$("natural-logic-commit").disabled,"both confirmation stages initially disabled");
 await confirm("natural-logic-check-ack");await click("natural-logic-check");
 if(info.scenario==="lost"){
  check($("internal-run-submit").disabled&&$("natural-logic-check").disabled,"unknown check blocks duplicate normal and patch submits");
  await boot();await nav("apps");await click(appButton(info.name));await click($("internal-instances").querySelector("button"));
  await edit("natural-logic-key",key);await edit("natural-logic-stage","checks");const before=requests.filter(r=>r.method==="POST").length;await click("natural-logic-recover");
  check(requests.filter(r=>r.method==="POST").length===before,"cold check recovery only GET and original key");
 }
 let started=JSON.parse($("natural-logic-proof").textContent);
 check(started.run_id&&started.check_instance_id!==info.instance,"isolated actual check instance");
 check(requests.filter(r=>r.method==="POST"&&r.path.endsWith("/logic-patches/checks")).length===1,"one explicit check submission");
 assert.equal((await rpc({command:"worker",rid:started.run_id})).status,200);
 await edit("natural-logic-stage","checks");await click("natural-logic-recover");const proof=JSON.parse($("natural-logic-proof").textContent);
 check(proof.status==="PASS"&&proof.citation_status==="PASS"&&proof.semantic_status==="UNKNOWN","normal Worker actual mechanical success with unknown semantics");
 check($("natural-logic-commit").disabled,"actual check does not publish a version");
 await confirm("natural-logic-version-ack");await click("natural-logic-version");const approval=JSON.parse($("natural-logic-proof").textContent);
 check(approval.snapshot.natural_logic_source.check_fingerprint===proof.check_fingerprint,"new snapshot freezes actual check proof");
 check(approval.approved_logic_preview.effective_candidate.spec_recipe.steps[2].inputs.prior_feedback,"approved effective recipe visible with full immutable snapshot");
 check(approval.actual_check.check_fingerprint===proof.check_fingerprint,"actual check shown alongside version proposal");
 check(approval.snapshot.draft.candidate.goal.unresolved.length===16,"full original Goal still visible at version confirmation");
 check(!$("natural-logic-version-ack").checked&&$("natural-logic-commit").disabled,"fresh version confirmation required after exact snapshot read");
 await confirm("natural-logic-version-ack");await click("natural-logic-commit");
 if(info.scenario==="lost"){
  check($("internal-run-submit").disabled,"unknown version response blocks duplicate actions");
  const posts=requests.filter(r=>r.method==="POST").length;await click("natural-logic-recover");
  check(requests.filter(r=>r.method==="POST").length===posts,"version recovery reads original approval/history only");
 }
 const version=JSON.parse($("natural-logic-proof").textContent);
 check(version.id!==info.release&&version.snapshot.natural_logic_source.preview_key===key,"one distinct internal version committed");
 check(requests.filter(r=>r.method==="POST"&&/\/approvals\/[^/]+\/commit$/.test(r.path)).length===1,"one separately confirmed version commit");
 check($("natural-logic-status").textContent.includes(version.id),"saved internal version clearly visible");
 const old=await rpc({method:"GET",path:`/api/internal/instances/${info.instance}`,headers:{Authorization:"Bearer synthetic-test-A"}});
 check(JSON.parse(old.text).data_version===0&&JSON.parse(old.text).release_id===info.release,"original instance data and selected version preserved");
 await click("internal-refresh");
 const versionButton=[...$("internal-releases").querySelectorAll("button")].find(b=>b.closest(".row").textContent.includes(version.id));
 await click(versionButton);
 check(!visible($("pb-use-panel"))&&!visible($("natural-logic-panel")),"finite new version explicitly exposes original-source execution only");
 await click("internal-run-submit");let queued=JSON.parse($("internal-run-detail").textContent);
 check(queued.id&&queued.status==="QUEUED","fresh explicit execution of the confirmed logic version");
 assert.equal((await rpc({command:"worker",rid:queued.id})).status,200);
 await click("internal-refresh");const runButton=[...$("internal-runs").querySelectorAll("button")].find(b=>b.closest(".row").textContent.includes(queued.id));await click(runButton);
 await wait(()=>{try{return JSON.parse($("internal-run-detail").textContent).status==="SUCCEEDED";}catch{return false;}});const actual=JSON.parse($("internal-run-detail").textContent);
 check(actual.status==="SUCCEEDED"&&actual.result.semantic_status==="UNKNOWN","new logic version actual result read back without semantic acceptance");
 check(actual.result.checklist.human_unresolved.length===16,"new version execution retains all original human unresolved items");
 status="PASS";
 }catch(e){error=e.stack||String(e);}finally{try{await closePage();}catch(e){error=error||String(e);status="FAIL";}fs.writeFileSync(info.output,JSON.stringify({status,error,checks,actions,requests,static_resource_loads:assets,boots,dom_status:dom?{error:$("error").textContent,internal:$("internal-status").textContent,run:$("internal-run-status").textContent,detail:$("internal-run-detail").textContent}:null},null,2));process.stdout.write(JSON.stringify({done:true})+"\n");if(status!=="PASS")process.exitCode=1;}})();
