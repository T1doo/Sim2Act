"""Official cases over independently copied successful normal Worker baselines.

No row, clock, budget or claim limit is modified to prepare the baseline.
Each case receives its own byte-identical SQLite copy with an empty owner ledger.
"""
import hashlib
import json
import shutil
from dataclasses import replace
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

import test_natural_spec_owner_acceptance as backend
import test_natural_spec_owner_ui as ui
from sim2act.api import create_app
from sim2act.db import Store, internal_instances, internal_run_bindings, runs
from sim2act.config import Settings
from sqlalchemy import select

ROOT=Path('/workspace/natural-spec-owner-evidence-20261013/author')
SEEDS={}
# Reuse preserved real successful history; only copied DBs are opened for cases.
# The initial fa14 seed build source and Worker claim proofs remain archived.
for family in ('pa','pb'):
    proof=ROOT/(family+'-seed-proof.json')
    if not proof.exists():continue
    info=json.loads(proof.read_text());seed=Path(info['seed'])
    assert hashlib.sha256(seed.read_bytes()).hexdigest()==info['sha256']
    store=Store('sqlite:///'+str(seed),test_only=True)
    settings=Settings('sqlite:///'+str(seed),ROOT/(family+'-seed-reader'),mode='mock',goal_planner_provider='intern-s2')
    client=TestClient(create_app(store,settings));client.headers['Authorization']='Bearer synthetic-test-A'
    rid=info['run_id']
    with store.tx() as c:
        snap=c.execute(select(internal_run_bindings.c.snapshot).where(internal_run_bindings.c.run_id==rid)).scalar_one()
        inst=dict(c.execute(select(internal_instances).where(internal_instances.c.id==snap['instance_id'])).mappings().one())
        actor=c.execute(select(runs.c.principal_id).where(runs.c.id==rid)).scalar_one()
    goal=client.get('/api/goal-cards/'+snap['spec_goal']['card_id']).json()
    artifact=client.get('/api/internal/app-run-jobs/'+rid+'/spec-artifact')
    assert artifact.status_code==200,artifact.text
    checklist=json.loads(artifact.json()['resource']['content'])
    resource=goal['content']['resource_refs'][0]
    data=(store,settings,client,actor,inst['project_id'],resource,goal)
    path=f"/api/internal/instances/{inst['id']}/runs/{rid}/spec-owner-review"
    SEEDS[family]=((data,inst,rid,resource,goal,checklist['source_content'],path),seed)
ORIGINAL_FLOW=backend.flow

@pytest.fixture(autouse=True)
def immutable_successful_seed(monkeypatch,tmp_path):
    stores=[];clients=[]
    def flow(env,family='pa'):
        if family not in SEEDS:
            result=ORIGINAL_FLOW(env,family)
            data=result[0]
            seed=ROOT/(family+'-successful-empty-owner-seed.db')
            # All Worker transactions have completed; checkpoint before byte copy.
            from sqlalchemy import text
            with data[0].engine.connect() as c:
                c.execute(text('PRAGMA wal_checkpoint(TRUNCATE)'))
            source=Path(data[1].database_url.removeprefix('sqlite:///'))
            shutil.copyfile(source,seed)
            SEEDS[family]=(result,seed)
            (ROOT/(family+'-seed-proof.json')).write_text(json.dumps(dict(
                source_database=str(source),seed=str(seed),sha256=hashlib.sha256(seed.read_bytes()).hexdigest(),
                source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),run_id=result[2],
                contract='ACTUAL_NORMAL_WORKER_SUCCESS_NO_ROW_CLOCK_BUDGET_CLAIM_EDITS'),indent=2))
        result,seed=SEEDS[family];old=result[0]
        destination=tmp_path/(family+'-isolated-success.db');shutil.copyfile(seed,destination)
        assert hashlib.sha256(destination.read_bytes()).digest()==hashlib.sha256(seed.read_bytes()).digest()
        store=Store('sqlite:///'+str(destination),test_only=True);stores.append(store)
        settings=replace(old[1],database_url='sqlite:///'+str(destination),data_dir=tmp_path)
        client=TestClient(create_app(store,settings));clients.append(client)
        client.headers['Authorization']='Bearer synthetic-test-A'
        data=(store,settings,client,*old[3:])
        (tmp_path/'seed-source.json').write_text(json.dumps(dict(seed=str(seed),source_sha256=hashlib.sha256(seed.read_bytes()).hexdigest(),
            copy_sha256=hashlib.sha256(destination.read_bytes()).hexdigest(),run_id=result[2]),indent=2))
        return data,*result[1:]
    monkeypatch.setattr(backend,'flow',flow);monkeypatch.setattr(ui,'flow',flow)
    yield
    for client in clients:client.close()
    for store in stores:store.engine.dispose()

# Exact maintained official cases; no assertion replacement or test timeout widening.
test_exact_goal_result_explicit_human_declaration=backend.test_exact_goal_result_explicit_human_declaration
test_revoked_target_before_private_body_and_stop=backend.test_revoked_target_before_private_body_and_stop
test_invalid_choices_corrupt_seal_expiry_and_foreign_scope=backend.test_invalid_choices_corrupt_seal_expiry_and_foreign_scope
test_new_result_never_inherits_old_declaration=backend.test_new_result_never_inherits_old_declaration
test_artifact_pointer_pollution_rejected_before_private_reads=backend.test_artifact_pointer_pollution_rejected_before_private_reads
test_precommit_revoke_rolls_back_record_and_seal=backend.test_precommit_revoke_rolls_back_record_and_seal
test_goal_version_change_invalidates_exact_review=backend.test_goal_version_change_invalidates_exact_review
test_visible_natural_owner=ui.test_visible_natural_owner

test_precommit_typed_change_rolls_back_declaration=backend.test_precommit_typed_change_rolls_back_declaration
test_scope_identifier_barrier_rejects_whole_and_other_json_bodies=backend.test_scope_identifier_barrier_rejects_whole_and_other_json_bodies
