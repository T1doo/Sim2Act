# Natural-spec exact-result human declaration design review

Read-only base HEAD e21f389fe463474bb659a1c86c48c31640a2f901, clean at read. Full relevant original/current F2 section, V5 product generation/identity/acceptance contracts, OwnerVersionAcceptance, OwnerReadOrder and TextLogicOwner read, with complete existing owner_acceptance module and natural runtime proof integration. No product/test/owner WIP edits, dynamic Worker or model calls.

## Original contract and finite scope

F2-T05 is least application Principal/Grant and unified gateway, not permission granted by Manifest. F2-T01 preserves known/assumptions/unresolved/constraints/checks. Original product §11 expressly distinguishes citation existence from correctness of inference and requires fixed human criteria for semantic results. Existing text owner contract is append-only explicit per-item ACCEPT/REJECT, 900s PREPARE, exact sequence/key/record seal, historical receipts separate from current state, and metadata-only CANCEL/REVOKE after READ withdrawal.

Natural-spec output currently stores machine citation PASS, semantic UNKNOWN, semantic acceptance NOT_RUN and owner PENDING. Human declaration must be a separate overlay for one exact Goal/result; never rewrite immutable typed result, Run/model history or source generation status to manufacture automatic semantic correctness. Simulated test choices remain SIMULATED, not real owner evaluation. No generation, repair, publication, credential or grant authority added.

Minimum first scope: one distinct successful natural-spec Run and its exact typed result version, P-A original/binding and P-B extraction/default/per-use supported through existing verifiers. Multiple Runs with different Goals should not be merged into one artificial Goal. Existing literal/DAG/CSV owner contracts remain closed and unchanged.

## Recommended reuse

Reuse owner ledger/metadata chain, dual seal, sequence/key CAS, 256-record budget and stop reserve, PREPARE→DECIDE/CANCEL and DECIDE→REVOKE, 15-minute prepare expiry, atomic append and original-key GET only. Add a natural-only context adapter and explicit contract/version discriminator; do not merely widen old base executor condition and then call text_run_checks.verify. Existing owner UI read/edit/navigation generations can be reused with explicit family and result scope validation.

PREPARE carries exact selected run_id/AppRun/result_version, current expected instance revision/data_version, saved Release/app fingerprint and expected Goal/version/fingerprint/result hash. Server rederives current context and freezes it. DECIDE identifies latest exact PREPARE/sealed contract and complete ordered stable criteria choices plus nonempty human reason per item. Any REJECT can be presented as requires correction while preserving REJECTED record semantics; no automatic model repair, editing Goal/checks or result replacement follows.

Criteria must expose full actual GoalCard including title, goal, known, assumptions, unresolved, constraints, acceptance_checks and bound resource. Stable IDs are scoped to the immutable Goal version and/or selected output item_id/result hash. Display complete result and citation/model relation/open-question status. Explicit result-scope criterion avoids treating accepting a Goal text as accepting an unseen output. No preselected ACCEPT, dropped unresolved item, automatic rationale, reordering/duplicate criterion or silently lowered checks.

## Exact context tuple

Freeze actor/project/app/runtime; saved app/recipe fingerprint; selected effective candidate/plan fingerprint; source family/origin and authorized source audit; immutable Release ID/fingerprint; actual instance ID/revision/history fingerprint/data_version; Run ID/version/fingerprint and accepted request/binding/contract fingerprints; AppRun ID; actual result version/row fingerprint/schema/output fingerprint/saved artifact ID/hash; actual per-Run GoalCard ID/version/fingerprint/full snapshot; input material ID/hash/format and current grants/limits; successful operation/intent/receipt/Attempt verification and citation check version; exact owner criteria, expiry and preceding owner sequence.

For P-B per-use, pa_spec_apps.verify_job/bound returns the effective target Goal/material from frozen pb_use. Use that Goal C, never original extraction B or source task A. Natural input is {}: old requirement s.input != Release sample input cannot prove unseen material and must not be copied. Successful actual Worker/proofs and selected target identity are the evidence. Result v2 is not v1 even when content happens to match.

Require SUCCEEDED on Run/AppRun, no error/cancel/unknown, one exact typed row and successful actual SAVE/citation proofs. Block active nonterminal instance tasks conservatively while preparing/deciding so pending new output cannot race declaration; preserve failed/cancelled history as metadata.

## Read-before-authorize and history

Start with own actor/project/instance and scalar Run/AppRun association, accepted scope headers, source family classification, success/result-version metadata. Apply current user∩app target input READ plus existing original lineage permissions before any private Run/Goal/typed/receipt body. Also authorize exact saved artifact READ before inspecting human result body: use independent SPEC_COMMITTED and actual SAVE local_effect resource IDs; reject missing/mismatched pointers before full proof. Existing spec artifact route verifies full body before artifact read, so do not copy its ordering as a human payload gate. pb.source_gate offers pointer consistency ideas but its original-P-A-only classifier cannot authorize arbitrary P-B extraction chains.

New owner records need an independently sealed identifier-only scope header tied to record fingerprint (Run/AppRun/result version/target material/artifact/Goal refs plus actor/project/runtime). Without it, owner payload contains the only target identifier and reading it to discover permission would violate P1. Missing scope/marker cannot downgrade to legacy literal owner; detect family independently and fail closed.

Old public_state currently calls base then loads every historical owner payload before verifying selected run context. For natural multi-target history this is unsafe: authorization of saved B or current C does not allow historical D Goal/result. If keeping old full-history payload invariant, preflight current READ for every historical record whose payload will be evaluated before reading any, and conservatively hide content/reject new decisions if one fails. Metadata chains and CANCEL/REVOKE stay usable. If C must remain independent of denied D, explicitly define per-Run ledgers/authorized payload partition rather than silently weakening the old full-history validation contract.

Owner GET on revoked/expired READ returns owned-instance metadata/history and STALE/PENDING with content_access=false; no Goal/result/reason payload, no cached current ACCEPTED. Same-key POST returns historical metadata only and never activates an old choice. Stops validate own scope/latest sequence/ID/fingerprint and metadata seal only, without reacquiring source/target/output READ.

## Invalidation and required counterexamples

- Foreign actor/project/instance, mismatched Run→AppRun or typed row pointing at another instance: deny before full private cells, zero append/side effect.
- Material READ and saved artifact READ separately revoked/expired (user and app identities); revoked original P-B lineage; GET hides content, PREPARE/DECIDE rejected before Goal/result/payload evaluation, CANCEL/REVOKE still metadata-only.
- Goal version/FP change, ABA goal text restore, changed material hash/format or recipe/effective plan/Release/instance revision and switch-back: prepared contract rejects and previous current declaration STALE; historical record remains immutable.
- New successful typed v2 after v1 PREPARE or DECIDE: no reuse of v1 acceptance for v2. data_version advancement invalidates old current declaration and requires new explicit review. New FAILED/CANCELLED run does not create fake result acceptance; define and test whether its presence alone affects history-bound freshness.
- Run/Attempt/operation/receipt/typed output corruption, missing dual scope/seal, orphan result or changed result status: fail full verifier, no human bypass of technical correctness.
- DECIDE item missing/duplicate/reordered, whitespace reason, old sequence/key collision, PREPARE expiry, late reply, edit-undo or navigation ABA, lost response and poisoned original-key recovery: no stale/automatic submission, no newer UI draft overwrite. Old accepted historical receipt distinct from current STALE/REVOKED.
- Accept and require-correction both through actual visible DOM/TestClient, independently reopened SQLite and actual Worker result; human choices simulated, request count/model settings unchanged. Baseline P1 result read/controls and AT-12 rejection/unknown gates regressions retained.

## Outcome

DESIGN_CONDITIONAL: natural-only exact successful result context plus existing immutable owner ledger is feasible. Existing literal owner base/context/public_state cannot be widened without target/artifact/history scope gates and actual per-Run Goal binding. Await frozen implementation for independent review; no implementation or acceptance PASS claim here.
