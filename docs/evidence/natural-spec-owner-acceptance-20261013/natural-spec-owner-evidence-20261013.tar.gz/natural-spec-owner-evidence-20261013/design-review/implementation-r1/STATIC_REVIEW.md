# Natural owner WIP implementation read-only review

Base HEAD e21f389fe463474bb659a1c86c48c31640a2f901; exact three current WIP files snapshotted. No product edits or dynamic tests performed by reviewer. Root is only writer; old owner WIP unchanged.

The separate per-Run ledger is appropriate: no cross-C/D owner payload scan; same Run target/Goal scopes establish authority before historical natural payload evaluation. Sequence/key/metadata/payload hashes, independent seals, 256 cap and stop reserve preserve append-only semantics. Latest typed result, exact instance/Release revision, actual Goal head and successful Worker proof are required, with separate human declaration instead of modifying machine output. Scope-only CANCEL/REVOKE remains possible after READ withdrawal.

Earlier concrete blockers reported and seen repaired in current source: nonexistent goal_cards.owner_id now uses current owned project and handles missing head; artifact preauth expanded from two pointers to committed event + verified SAVE local effect + AppRun resource ID + typed resource ID metadata equality before actual artifact READ/full proof; async PREPARE hash has view/rid/snapshot/edit fence; empty/invalid DECIDE choices and reasons preflighted; fresh rolled-back absent owner key now has scoped negative proof rather than blanket HTTP4xx cleanup.

## Remaining B1: mutable selected Run defeats late rejection cleanup

ownerAction retains mutable view; owner-run change mutates view.rid in place. A POST sent for Run A returning definite rejected proof after selection B compares proof.run_id to now-B and ownerKey(view) now-B, thus leaves original A pending forever. Returning to A cannot recover a nonexistent key and cannot PREPARE/DECIDE/STOP. Capture immutable request scope key/Run/endpoint/actor/project/iid before POST; validate negative proof and clear only exact original pending object regardless of selected new Run. Reopened identical scope needs derived button refresh only, never overwrite another Run's criteria/reasons/focus. Server acceptance/loss/unknown still original-key recovery.

## Remaining B2: natural negative proof lacks HTTP failure-class check

New natural catch checks proof tuple but lacks AT12's explicit 400<=httpStatus<500 boundary. Add matching initial-POST status classification; malformed/500/connection loss with absent or poisoned proof must retain pending. Do not infer rejection from a GET error. Existing code separates GET via readGeneration; keep that boundary.

## Independent fault list for final frozen probes

- P-A and P-B per-use Goal C exact binding and latest result; ACCEPT vs REJECT with complete ordered reasoned criteria, outputs/Goal/source immutable and UNKNOWN.
- User/app input READ and output artifact READ revoked/expired independently; original PB lineage revoke; no private Run/AppRun/typed/owner payload body before authority. Scope metadata scalar IDs are distinct from complete protected cells.
- Dual metadata saved/committed fake artifact plus real artifact revoke: other AppRun/typed identifier anchors cause early reject, not late proof mismatch; single or missing anchor likewise.
- New typed version after PREPARE and after DECIDE; old current declaration STALE; old receipt metadata remains, new Run not inherits acceptance; Goal version/ABA and instance revision/switchback reject.
- Missing/corrupt natural owner seal, payload, chain, request key, wrong project/actor/instance/Run association; zero append on reject; STOP solely metadata.
- Stale DECIDE deliberate409 fresh key yields exact rollback proof and UI correction/cancel remains usable; existing accepted same key no negative proof; old key different body rejects.
- Hash wait A→B→A, POST definite rejection delayed while selected B then back A, same-scope reopen, lost actual accepted response, wrong Run proof, 500 proof poison, late GET read generation and edit-undo: no wrong content/action, no permanent fresh rejected intent lock.

Status WIP_REVIEW_WITH_STATIC_UI_GAPS B1/B2 pending root repair and real red/green. No current dynamic PASS claim or unsupported PG/native/real model claims.
