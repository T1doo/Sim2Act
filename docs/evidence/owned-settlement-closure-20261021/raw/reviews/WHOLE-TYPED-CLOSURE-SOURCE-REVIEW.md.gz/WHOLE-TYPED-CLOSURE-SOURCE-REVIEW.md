# Same-transaction whole typed-content closure: source review

Decision: **NOT READY FOR WHOLE-SETTLEMENT MIGRATION OR COHORT REMOVAL**. Existing owned values provide reusable representation primitives, but the current native issuer, arena, consumers and capacity proof do not close the complete RECEIVED Cold prepare-through-scope interval. This is a specific implementation/proof gap, not a claim that ownership-based optimization is impossible. No partial `_recheck` component, new prototype or runtime change is proposed as completion of this task.

Read source HEAD: `229ab325b3f249bd920c9b1d793ca3bb8e17d278`. Scope is original BEGIN IMMEDIATE, connection, transaction, scope and renewal placement. No T0/T1/CAS redesign, new 600-second window, Pydantic-frozen shortcut, cached mutable PASS or skipped original parent checks is approved. Reviewer performed only source reads and hashes; no code/tests/DB/Worker/product/Mock/G0/profile/signal and no repository writes. Only these `/tmp` reports were written.

## Why the current cohort is still necessary

`natural_live_admission._trial_typed_guard` invokes its original parent and then `_trial_typed_values(models)`. Each triple retains an exact expected model class, the actual mutable model and a mutable raw dict. `_trial_typed_values` freshly walks complete fixed storage, copies raw data, compares exact native container/numeric types, performs the fixed original serializer and compares again. `_graph_trial_produced` checks the existing cohort before serialization, after serialization and after adding the new model/raw triple. These are live model/raw continuity checks, not data ownership.

An output model or its returned raw dict need not itself be a CGR input. Therefore a full CGR parent pass does not logically imply that every lexical typed triple is unchanged. An Approval model/raw-alias drift example with the CGR still passing is a meaningful counterexample to deleting the cohort. Such a test proves the necessity of the currently separate boundary; it cannot prove complete replacement by owned consumers or a performance improvement.

`_Projection.copy(..., typed=True)` has complete fixed-model storage gates, bounded copying, completed-node memo/cycle/depth handling and typed/native memo separation. `_Packet`/`_Node` and eager `_Arena` can represent immutable native content. But current typed projection normalizes a model to data and does not by itself issue a complete schema-typed capability or migrate the consumer. Current `_Family` is exclusively accounted Source/Generate; `_Record` accepts only `_FIELDS` accounted schemas, and `_Arena.bind` constructs their run/attempt/chain/body views. Arbitrary PBTrialContract, Approval, StageApproveInput, EvidenceRequirements, FrozenRunContract, Limits and RunCheck are not already issued typed records. Generic representation is not a completed semantic adapter.

## Required prepare-through-scope consumer coverage

This is a concrete boundary inventory, not a claim to have produced the final exhaustive producer/query/call-count proof matrix.

| Current area | Typed data and consumers that must remain live-checked or move together |
| --- | --- |
| `_prepare` lexical cohort | `_requirements` original PBTrialContract/EvidenceRequirements; `_approved` Approval; saved Cold StageApproveInput; journal SourceVerificationResult; subsequent exact-field predicates, `_dump`, admission-prefix and journal roots. |
| `_base._typed_parameters` transitive cohort | Ledger/AccountQuotaCursor; generation FrozenRunContract; ExtractInput; GoalCardRunSource; use CommitInput; AppManifest and release-origin manifests; both stage tuples' frozen/extraction holds; saved original/expected; current SourceVerificationResult and RunCheck. Current native pure-member helpers remove nested pins, **not** this final typed pass. |
| First commit and nested gate helpers | `_graph_run_context`, `_graph_stage_current`, policy `_graph_check_run`, first Approval/StageAuthority/RunCheck; compiled AppManifest; source StageApproveInput/authority; final FrozenRunContract. Each nested helper has its own growing lexical cohort and model/raw aliases. |
| Source/accounting/archive helpers | Journal Ledger/Cursor, budget.Scope, Slot/Capture/BodyArchive and contract/approval/stage outputs; frozen/extraction models; resolver receipt and legacy fingerprint consumers. Source/Generate family migration closes only its existing declared portion. |
| Fresh second continuation | `_recheck` has eight direct produced outputs: original, expected, approval, Cold accepted, Source phase, source verification, frozen contract and declared Limits, followed by RunCheck construction. Original SQL/authority/associated-row/full Run/at/finite checks still execute; their outputs cannot be replaced by prior results. |
| Persistent trial state | `_context`, `_source_value`, `self.original/expected/context/live_source`, source/context raw records and semantic authorities are consumed again by `check` and `_typed_parameters`. An owned local return alone would leave these old live consumers behind. |
| Fixed semantic/output bridges | Policy `_run_check_from_facts` calls expected/approval/phase `.model_dump()` for original fingerprints; runtime `_model_source_key`, `_dump`, `_fingerprint`, `_fields`, receipt formatting and trial-output authority/deadline records still consume native/model values. New private packets cannot be fed into these APIs unchanged or silently thawed into a second mutable source. |
| Original scope and post | Original final record/deadline/last hash/stop-clock boundary and later original post/live/tail/settlement contracts remain separate. A new private content digest must not replace original persisted business or pre/post/origin/software formats. |

Any replacement needs an explicit producer-to-owned-record-to-every-consumer mapping, including nested `_trial_typed_hold` collectors and reused stage tuples, storage/dump omissions, exact class/domain types, alias handling and old fingerprint bytes. Fixed serialization/export for an existing protocol must be distinguished from general thawing or returning mutable dicts for subsequent business consumption. Retaining a live model as a second consumer source requires retaining its original checks.

## Precise issuance and capacity obstruction

The present candidate route selects at `_prepare`'s `accounted_candidate.choose(...)`, after the original Source -> recipe -> backend-version -> Generate sequence, but **before** assembly of extraction/stage/complete and before first-commit context, compiled manifest, source authority/source observation, final frozen contract, second-continuation fresh outputs and second context/output.

Current `_capture_bounded` produces two fixed Source/Generate packets. `qualify` reserves those packets' arena/classification, original Ledger and full mutable frontier sizing, the fixed Source/archive/resolver continuation, exact future-root dictionary scaffolding, and receipt closure costs. It does not reserve/issue all later typed model packets, schema views, canonical exports, repeated consumer snapshots or growing lexical cohorts. The arena is sealed after issuance; class tables are only for the original packets. A future-root allowlist admits a new **raw** CGR pin under the existing protocol; it is not proof that an additional typed owned allocation or view is prepaid.

Thus neither extending `_FIELDS`, inserting late snapshots, growing the sealed arena, nor relying on a large fixture allowance is an issuance-capacity proof. After OWNED issuance, a new capacity failure cannot silently fall back to LEGACY or replay original producers. Before issuance, unsupported capacity must preserve original producer/authorization/drift errors rather than swallow them. Existing `_select_completed` carefully confines fallback to that pre-issuance `_Capacity` block; the complete migration must retain an equally precise single route point.

What is missing is a finite **whole-interval** producer/call-count and field-lineage matrix: which payloads are already available before route selection; which later values are fixed-size derived scalars; which later outputs depend on fresh SQL/producer content; and the conservative simultaneous retained/temporary/encoder/classifier/view/export/work bounds for all of them. If a later value has no proven bound from already qualified inputs or original constraints, this is a route qualification blocker, not grounds for a new product cap. Any earlier/later selection point also needs a no-producer-replay/no-early-effect/no-unchecked-consumer proof. No such matrix is established by current code.

## Dynamic frontier that must remain

Original CGR still verifies exact connection/transaction/driver/total_changes/thread/source-read token+epoch/scope nonce, worker/settings/transport/binding and full remaining input content. Current `_Frontier` replaces only accounted Source/Generate and their narrowly mapped complete/generation aliases with content tokens; all other independent aliases are freshly encoded. A complete typed migration needs an exact new alias-path closure before substituting any additional root. Object identity alone cannot excuse an independent mutable alias from fresh reading. Producer calls, SQL-return guards, authorization/fence/cancel/stop and all original deadline positions stay in place.

An immutable packet may justify no repeated traversal of its own owned content after exact ownership/schema/lifetime gates. It does not establish authority, validate a current DB/worker fact, justify skipping a still-live model/raw alias, or make a cached prior validation result current. Until the entire prepare-through-scope mapping and pre-issuance capacity proof close, **retain all original typed guards/cohorts and runtime paths**. Narrow synthetic mutation regressions are useful evidence for this blocked conclusion; they do not qualify full tail execution or performance.

## Source SHA-256

- natural_live_admission.py: `84195d0061f965b8f1cc2e1bc385941c2739e09dce02293596b3025f14b4433a`
- natural_spec_runtime.py: `d0140af82c18f1b5181e6ffa929189d7dbd9ac49431a980710792c31d62628c7`
- cold_accounted.py: `87b0c464866ac038140d615182d1dc552c83dd53cbf629a9bad2b4973bad017e`
- _cold_accounted_native.py: `b6ab0b09f6abb9d8ddcd72b54127af0517a1d0f67728d96582c90e0f4d2c7147`
- _cold_accounted_budget.py: `8064435c5a0e4c286a9b7db7781d42986ada3f0e7cc104c1b1b4662c970c2dda`
- _cold_accounted_values.py: `4c518ea5a389f6f68c000d2fac47c79ffc4906a090bb03dc199e9c60b88f94fc`
- production_trial_policy.py: `65b0b8203f2c17b964c9db828d3f688fa9cc014d6ad38b6e9bca0c8d6237270f`
