# Whole typed closure: final mutation witnesses and documentation ACK

Decision: **ACK for the two narrow counterexamples and the documented NOT PROVEN/NOT RUN conclusion; no runtime migration qualification**. No blocking change is requested in the final test or README. This supplements WHOLE-TYPED-CLOSURE-SOURCE-REVIEW and does not convert its incomplete full-interval inventory into a proven complete consumer/capacity map.

Baseline/current read HEAD: `229ab325b3f249bd920c9b1d793ca3bb8e17d278`.
Final test SHA-256: `a4b3af0d09f5e0573c70fa307976bf2722575189fc0b15312178301aa3a8f310`.
README SHA-256: `d8d39e29a303530b7d77edfc0255bd004c05bd31bd60f4d937558890534247ce`.

Reviewer read the final test, its directly used fixture/native-segment definitions, source boundary, author manifests/log/XML/Ruff and README. Reviewer did not run tests, SQL/SQLite, DB, Worker, product, Mock, model, G0, profile or signals; did not write repository files. Source/scripts diff is empty. Only this `/tmp` report was written.

## Exact witness

The reused `sql_facts` creates an isolated new SQLite Store rather than a PG/environment-backed database. Its execution tripwire blocks Worker construction/once, model construction and transport handlers. `native_segment` uses original source-read scope, `_ColdGraphRead`, original journal/accounted Source and Generate producers, and actual candidate qualification/issuance. It is a lower-level harness with synthetic upstream facts, a synthetic graph input/complete shape, no full native prepare/commit, and deliberately large fixture logical allowances. These are not production bounds or full settlement acceptance.

Inside the already OWNED two-family segment, both test parameters invoke original `_approved` through its real SQL path, then original `_graph_trial_produced`. The test asserts the lexical cohort contains the exact original Approval model and exact returned raw dict, an equal initial business fingerprint, and a successful original full model pin. One parameter uses ordinary `model.approved_at -= 1`; the other mutates the returned raw dictionary. No Pydantic frozen override is used.

After each mutation, original full `graph.check` still succeeds, while model/raw business fingerprints differ. Original `_graph_trial_models_pin` then throws the exact typed-storage-changed message. Inner capture plus `witness is not None` and exact final message prevent an earlier fixture/producer rejection from masquerading as the witness. Graph, mode and scope are asserted inactive before and after scope exit. The outer expected DomainError reflects rejection of that invalid scope; the test does not reset invalidation to manufacture a pass.

The strongest supported conclusion is existential and precise: **a fresh CGR parent pass plus existing two-family OWNED issuance is insufficient to replace the live lexical Approval model/raw cohort check in this harness**. Removing that check without ownership/consumer migration would miss one of these originally rejected drifts. This does not establish that all cohorts are necessary forever, that every mutation of every type is covered, that all consumer paths have migrated, or that ownership optimization cannot be implemented.

## Author test evidence, not reviewer execution

Final witness log reports **2 passed**, one existing Starlette deprecation warning, **3.06 s**. JUnit states tests=2, failures=0, errors=0, skipped=0, time=3.057. The before/after manifests and independently hashed current test agree on the final ordinary-assignment SHA. Ruff says all checks passed.

Original initial **2 failed / 3.12 s** log is preserved: the failures were test assertions referring to nonexistent `mode.closed`, after the targeted rejection had occurred. The intermediate fixed-active **2 passed / 3.05 s** version is preserved separately; it predates final ordinary assignment. These runs are not six distinct independent tests and none is a complete settlement or tail execution.

## README scope

The README accurately distinguishes what current qualification covers (two packets, Ledger, mutable frontier, fixed continuation and exact future raw roots) from the missing full later typed-packet/schema/export/temporary-space field-lineage/call-count/simultaneous-residency proof. `choose` remains before multiple later producer outputs; an allowed future raw root is not a new typed allocation/issuance allowance. The sealed arena and pre-issuance-only fallback do not supply the missing whole-interval route proof.

The documented producer/consumer table is explicitly an inventory rather than a completed exhaustive proof. It preserves all original transaction/scope/renew/heartbeat, authorization, SQL-return, settings/frontier, Run/fence/cancel/stop and deadline checks and keeps private manifests out of old protocols. It does not resume T0/T1 or introduce new all-Run-column gates.

The NOT RUN matrix correctly excludes complete prepare -> first commit -> receipt -> second commit -> normal scope, full-candidate negative/rollback suites, G0/Mock/model windows and performance claims. No prototype or partial recheck is claimed as completion. The previous real tail result is referenced with its post-exception limitation intact. The precise current blockage is incomplete ownership/consumer and issuance-capacity qualification, not proof of impossibility.
