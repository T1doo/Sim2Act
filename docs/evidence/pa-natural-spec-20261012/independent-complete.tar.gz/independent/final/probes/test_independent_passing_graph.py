import json,hashlib
import httpx
from sqlalchemy import select
from conftest import env
from test_goal_text_applications import wire
from test_natural_spec_apps import setup,SOURCE,facts,recipe
from sim2act import natural_specs as natural
from sim2act.db import app_drafts,goal_application_candidates,attempts
from sim2act.worker import Worker

def test_checker_pass_cannot_be_replaced_by_another_valid_natural_recipe(env,tmp_path):
 data=setup(env);store,settings,client,_,pid,resource,card=data
 sent=[];proof={}
 def candidate(payload,style):
  goal=json.loads(payload['messages'][1]['content'])['saved_goal']['snapshot']['content']
  steps=recipe(style)
  return dict(recipe=steps,sample_nodes=[dict(step_id=s['step_id'],items=[i for i in facts(SOURCE) if i['kind'] in natural.MODEL_KINDS[s['operator']]]) for s in steps['steps'] if s['operator'] in natural.MODEL_KINDS],source_hash=hashlib.sha256(SOURCE.encode()).hexdigest(),goal=goal)
 def handler(request):
  payload=json.loads(request.content);sent.append(payload)
  if len(sent)==1:tool,args=natural.READ,dict(resource_id=resource)
  elif len(sent)==2:
   feedback=json.loads(next(m['content'] for m in payload['messages'] if m['role']=='tool'))
   assert feedback['data']['content']==SOURCE
   proposal=candidate(payload,'single');proof['passed_proposal']=proposal
   tool,args='spec.check_candidate',dict(candidate=proposal)
  else:
   feedback=json.loads([m['content'] for m in payload['messages'] if m['role']=='tool'][-1])
   assert feedback['data']['status']=='PASS';proof['actual_check_feedback']=feedback
   changed=candidate(payload,'sequential');proof['changed_final']=changed
   assert changed!=proof['passed_proposal']
   return httpx.Response(200,json=wire(dict(role='assistant',content=json.dumps(changed)),'stop'))
  message=dict(role='assistant',content='',tool_calls=[dict(id='independent-'+str(len(sent)),type='function',function=dict(name=tool,arguments=json.dumps(args)))])
  return httpx.Response(200,json=wire(message,'tool_calls'))
 made=client.post(f"/api/projects/{pid}/goal-cards/{card['id']}/application-runs",json=dict(expected_version=card['version'],expected_fingerprint=card['fingerprint'],request_key='independent-pass-no-swap',family='natural_spec'))
 assert made.status_code==202,made.text
 rid=made.json()['run_id'];assert Worker(store,settings,goal_planner_transport=httpx.MockTransport(handler)).once()
 reply=client.get('/api/runs/'+rid);proof['response_status']=reply.status_code;proof['run']=reply.json();proof['sent_requests']=len(sent)
 try:
  assert reply.status_code==200,reply.text
  assert reply.json()['status']=='FAILED' and reply.json()['result'] is None and reply.json()['error']['code']=='VERSION_CONFLICT',reply.text
  assert len(sent)==3
  with store.tx() as c:
   assert c.execute(select(app_drafts.c.id)).first() is None
   assert c.execute(select(goal_application_candidates.c.app_id)).first() is None
   rows=c.execute(select(attempts).where(attempts.c.run_id==rid)).mappings().all()
   assert len(rows)==3 and any(a['error'] for a in rows)
   proof['app_created']=False;proof['attempts']=len(rows)
  assert not Worker(store,settings).once()
 finally:
  (tmp_path/'passing-graph-negative.json').write_text(json.dumps(proof,indent=2)+'\n')
