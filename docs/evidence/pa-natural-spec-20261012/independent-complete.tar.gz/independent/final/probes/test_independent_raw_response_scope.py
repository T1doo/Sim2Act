"""Independent nonempty response-cell calibration and raw-first revocation proof.

Only synthetic transport and task-owned SQLite; production source stays readonly.
"""
import json,re,sqlite3
from pathlib import Path
import pytest
from sqlalchemy import select,update
from sqlalchemy.exc import DatabaseError
from conftest import env
from sql_private_barrier import PrivateReadBarrier
from test_natural_spec_apps import setup,ready,enqueue,inspect,transport
from sim2act.db import attempts,grants,operations,internal_instance_data
from sim2act.worker import Worker

class ResponseBarrier(PrivateReadBarrier):
    def __init__(self,store,ids,resource,job):
        super().__init__(store,ids,{resource});self.job=job;self.presence_checks=[];self.received_presence=False
        self.rules['attempts']=(attempts,'run_id',set(ids),{'parameters','usage','response'})
    def _trace(self,conn,cursor,statement,parameters,context,many):
        flat=' '.join(statement.split())
        self.received_presence=(flat.startswith('UPDATE attempts SET ') and 'attempts.response IS NULL' in flat and 'attempts.run_id = ?' in flat and 'attempts.id = ?' in flat and self.job in parameters)
        return super()._trace(conn,cursor,statement,parameters,context,many)
    def _authorize(self,action,table,column,database,source):
        if action==sqlite3.SQLITE_READ and table=='attempts' and column=='response' and database=='main' and source is None and self.received_presence:
            self.presence_checks.append({'table':table,'column':column,'kind':'owned UPDATE only SQL NULL-presence CAS, no full response projection'})
            return sqlite3.SQLITE_OK
        return super()._authorize(action,table,column,database,source)

def test_revoked_raw_receiver_response_cell_is_protected_and_history_survives(env,tmp_path):
    data=setup(env);origin,_,release,inst,_=ready(data);job=enqueue(data,release,inst);sent=[];held={};result={'classification':'controlled in-flight revocation; synthetic transport only'}
    def mutate(raw,payload):
        b=ResponseBarrier(data[0],{origin,job},data[5],job);b.__enter__();held['barrier']=b
        with pytest.raises(DatabaseError):
            with data[0].tx() as c:
                c.execute(select(attempts.c.response).where(attempts.c.run_id==origin).limit(1)).scalar()
        assert b.blocked and any(x.get('column')=='response' for x in b.blocked)
        result['calibration_before']={'blocked':list(b.blocked),'evaluated':list(b.evaluated)};b.blocked.clear();b.evaluated.clear();b.statements.clear()
        with data[0].tx() as c:c.execute(update(grants).where(grants.c.resource_id==data[5]).values(revoked=True))
    try:
        assert Worker(data[0],data[1],goal_planner_transport=transport(sent,mutate=mutate)).once()
        b=held['barrier'];assert len(sent)==1;assert b.blocked==[] and b.evaluated==[]
        reply=inspect(data,inst,job);assert reply.status_code==403;assert b.blocked==[] and b.evaluated==[]
        result['product']={'status':reply.status_code,'blocked':list(b.blocked),'evaluated':list(b.evaluated),'allowed_presence_checks':list(b.presence_checks),'statements':list(b.statements)}
        with pytest.raises(DatabaseError):
            with data[0].tx() as c:c.execute(select(attempts.c.response).where(attempts.c.run_id==job)).scalar_one()
        assert any(x.get('column')=='response' for x in b.blocked)
        result['calibration_after']={'blocked':list(b.blocked),'evaluated':list(b.evaluated)}
    finally:
        if held:held['barrier'].__exit__(None,None,None)
        (tmp_path/'raw-response-barrier.json').write_text(json.dumps(result,indent=2,default=str)+'\n')
    with data[0].tx() as c:
        a=c.execute(select(attempts).where(attempts.c.run_id==job)).mappings().one()
        assert a['status']=='REJECTED_KNOWN' and a['response']['received_raw'] and a['reserved_tokens']>0
        assert c.execute(select(internal_instance_data.c.version).where(internal_instance_data.c.instance_id==inst['id'])).first() is None
        assert c.execute(select(operations.c.id).where(operations.c.run_id==job,operations.c.tool_ref=='artifact.save_text')).first() is None
        result['durable_owned_history']={'attempt_id':a['id'],'status':a['status'],'reserved_tokens':a['reserved_tokens'],'raw_complete':True,'typed_count':0,'artifact_save_operations':0}
    (tmp_path/'raw-response-barrier.json').write_text(json.dumps(result,indent=2,default=str)+'\n')
