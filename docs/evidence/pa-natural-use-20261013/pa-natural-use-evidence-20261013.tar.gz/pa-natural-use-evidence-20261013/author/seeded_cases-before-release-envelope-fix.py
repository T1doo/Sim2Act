"""Byte-identical actual successful PA/PB histories; new runs use actual Worker."""
import hashlib,json,shutil
from dataclasses import replace
from pathlib import Path
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select
from sim2act.api import create_app
from sim2act.db import Store,internal_instances,internal_run_bindings,runs
import test_pa_natural_uses as tests
ROOT=Path('/workspace/pa-natural-use-evidence-20261013/author')
OLD=Path('/workspace/natural-spec-correction-evidence-20261013/author')
info=json.loads((OLD/'pa-seed-provenance.json').read_text());seed=ROOT/'pa-historical-success.db';shutil.copyfile(info['seed'],seed)
assert hashlib.sha256(seed.read_bytes()).hexdigest()==info['sha256']
(ROOT/'pa-seed-provenance.json').write_text(json.dumps(info,indent=2))
@pytest.fixture(autouse=True)
def copied_pa(monkeypatch,tmp_path):
    def base(env):
        _,settings,*_=env
        dst=tmp_path/'pa-isolated.db';shutil.copyfile(seed,dst)
        assert hashlib.sha256(seed.read_bytes()).digest()==hashlib.sha256(dst.read_bytes()).digest()
        store=Store('sqlite:///'+str(dst),test_only=True)
        settings=replace(settings,database_url='sqlite:///'+str(dst),data_dir=tmp_path,goal_planner_provider='intern-s2')
        client=TestClient(create_app(store,settings));client.headers['Authorization']='Bearer synthetic-test-A'
        rid=info['run_id']
        with store.tx() as c:
            snap=c.execute(select(internal_run_bindings.c.snapshot).where(internal_run_bindings.c.run_id==rid)).scalar_one()
            inst=dict(c.execute(select(internal_instances).where(internal_instances.c.id==snap['instance_id'])).mappings().one())
            actor=c.execute(select(runs.c.principal_id).where(runs.c.id==rid)).scalar_one()
        goal=client.get('/api/goal-cards/'+snap['spec_goal']['card_id']).json()
        resource=goal['content']['resource_refs'][0]
        app=client.get('/api/apps/'+inst['source_app_id']);assert app.status_code==200,app.text
        release=client.get('/api/internal/releases/'+inst['release_id']);assert release.status_code==200,release.text
        data=(store,settings,client,actor,inst['project_id'],resource,goal)
        stores.append(store);clients.append(client)
        return data,app.json(),release.json()['release'],inst,rid
    stores=[];clients=[];monkeypatch.setattr(tests,'base_pa',base)
    yield
    for c in clients:c.close()
    for s in stores:s.engine.dispose()
test_same_saved_pa_third_material_cold_worker_and_fresh_owner=tests.test_same_saved_pa_third_material_cold_worker_and_fresh_owner
test_illegal_inputs_and_cross_family_no_partial_write=tests.test_illegal_inputs_and_cross_family_no_partial_write
test_late_pa_target_result_cannot_commit=tests.test_late_pa_target_result_cannot_commit
test_target_read_gates_and_no_default_downgrade=tests.test_target_read_gates_and_no_default_downgrade
test_actual_pa_cancel_after_target_revocation=tests.test_actual_pa_cancel_after_target_revocation
test_natural_pa_grant_expiry_invalidates_preview=tests.test_natural_pa_grant_expiry_invalidates_preview
