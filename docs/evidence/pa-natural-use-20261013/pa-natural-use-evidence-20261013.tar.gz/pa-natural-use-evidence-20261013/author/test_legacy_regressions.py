"""Recheck byte-identical old PB binding and old PA correction through current gates."""
import hashlib,json,shutil
from dataclasses import replace
from pathlib import Path
from fastapi.testclient import TestClient
from seeded_cases import copied_pa
import test_pa_natural_uses as tests
import test_natural_spec_corrections as correction
from test_natural_spec_apps import SOURCE
from sim2act.api import create_app
from sim2act.db import Store

def test_historical_pb_per_use_without_pa_version_key_still_verifies(env,tmp_path):
    info=json.loads(Path('/workspace/natural-spec-correction-evidence-20261013/author/pb-seed-provenance.json').read_text())
    dst=tmp_path/'pb-old.db';shutil.copyfile(info['seed'],dst);assert hashlib.sha256(dst.read_bytes()).hexdigest()==info['sha256']
    store=Store('sqlite:///'+str(dst),test_only=True);settings=replace(env[1],database_url='sqlite:///'+str(dst),data_dir=tmp_path,goal_planner_provider='intern-s2')
    client=TestClient(create_app(store,settings));client.headers['Authorization']='Bearer synthetic-test-A'
    try:
        r=client.get('/api/internal/app-run-jobs/'+info['run_id']+'/spec-artifact');assert r.status_code==200,r.text
        assert json.loads(r.json()['resource']['content'])['source_content'].startswith('The field beacon')
        (tmp_path/'old-pb-proof.json').write_text(json.dumps(dict(provenance=info,response=r.json(),current_fresh_worker=False),indent=2))
    finally:client.close();store.engine.dispose()

def test_existing_pa_human_correction_still_creates_new_result(env,tmp_path,monkeypatch):
    data,app,release,inst,original=tests.base_pa(env)
    path='/api/internal/instances/'+inst['id']+'/runs/'+original+'/spec-owner-review'
    monkeypatch.setattr(correction,'flow',lambda env,family='pa':(data,inst,original,data[5],data[6],SOURCE,path))
    correction.test_explicit_rejection_to_actual_new_result_and_fresh_owner(env,tmp_path,'pa')
