"""Actual bounded input errors and a real competing normal Worker."""
import hashlib,json
from concurrent.futures import ThreadPoolExecutor
import pytest
from sqlalchemy import select
from seeded_cases import copied_pa
import test_pa_natural_uses as tests
from test_natural_spec_apps import SOURCE,enqueue,transport
from test_pb_natural_specs import drive_to_success
from test_pb_natural_uses import THIRD
from test_spec_app_operations import snapshot
from sim2act.db import attempts,internal_instance_data,operations,runs
from sim2act.worker import Worker

@pytest.mark.parametrize('fault',['empty','long','csv','multiple-refs'])
def test_invalid_bounded_pa_material_never_creates_run(env,tmp_path,fault):
    data,app,release,inst,_=tests.base_pa(env)
    content=' ' if fault=='empty' else 'x'*2049 if fault=='long' else 'a,b\n1,2' if fault=='csv' else THIRD
    r=data[2].post('/api/projects/'+data[4]+'/resources',json=dict(name='invalid target',format='csv' if fault=='csv' else 'txt',content=content));assert r.status_code==201,r.text
    resource=r.json()['id'];value={**data[6]['content'],'title':'Explicit invalid new material','resource_refs':[resource,data[5]] if fault=='multiple-refs' else [resource]}
    r=data[2].post('/api/projects/'+data[4]+'/goal-cards',json=value);assert r.status_code==201,r.text
    goal=data[2].get('/api/goal-cards/'+r.json()['id']).json()
    body=dict(expected_revision=inst['revision'],expected_release_fingerprint=release['fingerprint'],expected_app_fingerprint=app['fingerprint'],expected_recipe_fingerprint=tests.fingerprint(app['candidate']['spec_recipe']),resource_id=resource,card_id=goal['id'],expected_goal_version=goal['version'],expected_goal_fingerprint=goal['fingerprint'],expected_source_hash=hashlib.sha256(content.encode()).hexdigest(),request_key='invalid-'+fault)
    before=snapshot(data[0]);route='/api/internal/instances/'+inst['id'];out=[]
    for path,b in [(route+'/pa-use-reviews',body),(route+'/pa-use-runs',dict(review=body,expected_review_fingerprint='0'*64,consent=tests.use.PA_CONSENT))]:
        r=data[2].post(path,json=b);assert r.status_code in (400,403,409,422),r.text;assert snapshot(data[0])==before;out.append(dict(path=path,status=r.status_code,response=r.json()))
    (tmp_path/'invalid-material.json').write_text(json.dumps(out,indent=2))

def test_actual_sibling_worker_result_blocks_late_pa_target_save(env,tmp_path):
    data,app,release,inst,original,resource,goal,body,route=tests.prepared_pa(env)
    _,commit=tests.prepare(data,route,body);r=data[2].post(route+'/pa-use-runs',json=commit);assert r.status_code==202,r.text
    accepted=r.json();rid=accepted['run_id'];sent=[];sibling={};before=snapshot(data[0])
    def mutate(raw,payload):
        def competing_worker():
            other=enqueue(data,release,inst,key='real-sibling-competes')
            wire=[];drive_to_success(data,other,transport(wire,SOURCE));assert len(wire)==1
            sibling.update(run_id=other,wire=wire)
        # The transport callback is inside the first model's asyncio loop; the
        # genuinely separate Worker gets its own thread/event loop, no nesting.
        with ThreadPoolExecutor(max_workers=1) as pool:
            pool.submit(competing_worker).result(timeout=60)
    assert Worker(data[0],data[1],goal_planner_transport=transport(sent,THIRD,mutate)).once()
    with data[0].tx() as c:
        rows=[dict(x) for x in c.execute(select(internal_instance_data).where(internal_instance_data.c.instance_id==inst['id'])).mappings()]
        primary=dict(c.execute(select(runs).where(runs.c.id==rid)).mappings().one());other=dict(c.execute(select(runs).where(runs.c.id==sibling['run_id'])).mappings().one())
        attempt=dict(c.execute(select(attempts).where(attempts.c.run_id==rid)).mappings().one())
        assert primary['status']!='SUCCEEDED' and other['status']=='SUCCEEDED'
        assert attempt['status']=='REJECTED_KNOWN' and attempt['response']['received_raw']
        assert sorted(x['version'] for x in rows)==[1,2]
        assert not any(x['run_id']==accepted['app_run_id'] for x in rows)
        assert not c.execute(select(operations.c.id).where(operations.c.run_id==rid,operations.c.tool_ref=='artifact.save_text')).first()
    after=snapshot(data[0]);assert before['app_drafts']==after['app_drafts'] and before['internal_releases']==after['internal_releases']
    assert all(x in rows for x in before['internal_instance_data']) and len(sent)==1
    (tmp_path/'sibling-proof.json').write_text(json.dumps(dict(primary=primary,sibling=other,attempt=attempt,primary_wire=sent,sibling_wire=sibling['wire'],versions=[1,2],new_target_typed_saves=0,real_model_requests=0),indent=2))
