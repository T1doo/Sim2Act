"""Actual saved PA authority downgrade probe, no new model or queued Run."""
import json
import pytest
from sqlalchemy import delete,select,update
from test_pb_natural_use_read_gates import TypedPrivateBarrier
import test_pa_natural_uses as tests
from seeded_cases import copied_pa
from sim2act import lifecycle,pb_natural_uses as use,pa_spec_apps as spec
from sim2act.db import delivery_graph_requests,grants,internal_run_bindings
from sim2act.errors import DomainError

def test_all_pa_markers_missing_requires_context_before_typed_body(env,tmp_path):
    data,app,release,inst,rid=tests.base_pa(env)
    with data[0].tx() as c:
        aid=c.execute(select(internal_run_bindings.c.app_run_id).where(internal_run_bindings.c.run_id==rid)).scalar_one()
        c.execute(delete(delivery_graph_requests).where(
            delivery_graph_requests.c.app_id.in_([rid,inst['id']]),
            delivery_graph_requests.c.kind.in_([spec.RUN_META,spec.RUN_META+'_seal',use.PA.use,use.PA.use+'_seal',use.PA.meta,use.PA.meta+'_seal'])))
        c.execute(update(grants).where(grants.c.resource_id==data[5],grants.c.tool_ref=='resource.read').values(revoked=True))
    proof={}
    try:
        with TypedPrivateBarrier(data[0],rid,aid,data[5]) as barrier:
            try:
                with data[0].tx() as c:
                    lifecycle.data_rows(c,inst['id'])
            except DomainError as exc:
                assert exc.code in {'PERMISSION_DENIED','VERSION_CONFLICT'}
            else:
                pytest.fail('PA protected history read without current authority context')
            assert not barrier.blocked and not barrier.full_binding_reads
    finally:
        proof.update(blocked=barrier.blocked,evaluated=barrier.evaluated,full_binding_reads=barrier.full_binding_reads)
        (tmp_path/'private-downgrade-proof.json').write_text(json.dumps(proof,indent=2))
