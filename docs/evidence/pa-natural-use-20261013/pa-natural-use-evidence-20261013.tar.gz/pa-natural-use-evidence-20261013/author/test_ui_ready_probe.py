from seeded_cases import copied_pa
import pytest
import test_pa_natural_uses_ui as ui
@pytest.fixture(autouse=True)
def node_probe(monkeypatch):
    original=ui.subprocess.Popen
    def launch(args,*a,**k):
        if args[:2]==['node','tests/pa_natural_uses_ui.cjs']:
            args=[args[0],'/workspace/pa-natural-use-evidence-20261013/author/pa_ui_ready_probe.cjs',*args[2:]]
        return original(args,*a,**k)
    monkeypatch.setattr(ui.subprocess,'Popen',launch)
test_visible_same_pa_third_material_and_fresh_owner=ui.test_visible_same_pa_third_material_and_fresh_owner
