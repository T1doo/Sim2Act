# Final P-A per-use independent review

HEAD a6db829bfeb11c059bd1e2ebfa3ca802647db74e, core 8950b16c185b4b8569963ea5059e01fbf62b2146. Independent actual suite on this freeze: 23 PASS, 0 FAIL, 0 ERROR, 0 SKIP; 20.134 wall seconds. Scope qualification22 and old literal-owner ACCEPT1. Full459 sources/test/pyproject before/after byte-stable, exact source-final/raw/XML/temp DB and command archived. Previous fe3f23 and e8bf static evidence retained and not used as this freeze's test result.

Qualification76 pin89c54de9dbccfb8f4ffd32fecd3529e14a9e12174aa9c267c7392a6073b472a3 exact. Original baselinecb128 anchor byte-identical and original CHANGED/source exact set tests pass; config excluded. No broadened qualification whitelist.

## Final delta and schema closure

e8bf→a6 changes only pb_natural_uses route implementation annotation/registration, qualification JSON/literal pin and software metadata, plus the JSDOM fixture primitive assignment. Static function annotation is CommitInput|PACommitInput, but the immutable family body annotation is assigned before FastAPI registration. Independent OpenAPI-only readback confirms /pb-use-runs body ref exactly CommitInput and PB exact consent; /pa-use-runs exactly PACommitInput and PA exact consent. Both additionalProperties=false; no union schema allows wrong-family consent. No store, HTTP request, Worker or model was invoked by this schema inspection.

First schema inspection attempted Limits() with no required six fields and returned validationerror before mount; this reviewer inspection setup failure is retained in schema-readback scope note. Retry passes unused closure limits=None and independently validates actual generated route schemas. It is not a product failure or pytest execution. Final fast suite is independently terminal23PASS.

Fixture adds native Node structuredClone to JSDOM window so product's existing structuredClone runs normally; it changes no product fallback/approval/transport and fabricates no worker result.

## Prior blocking repairs remain closed

Only PA enqueue writes pa_base_data_version and only PA bound reads it. PB old snapshots do not need new fields and their review namespace/body/consent/expected report and source-audit branch remain unchanged. This is static compatibility assessment; freshPB runtime suite belongs to author, not reviewer.

Saved App/Release natural namespace is an independent protected_instance hint. All perRun USE/META/RUN_META and overlay deletion cannot disable protected history for unchanged natural PA. Raw noctx data_rows refuses, metadata control requires accepted association before bodies, and both family scope gates reconcile their dedicated metadata with generic spec.RUN_META and exact saved-family provenance. Original source authority is verified separately from target perRun scope. PA keeps goal generation/spec_binding markers and exposes saved_origin; no PB task lineage is forged.

ActivePA dataVersion gate permits unchanged base or only this exact accepted AppRun's staged SUCCEEDED resultVersion/typed base+1; another Run's committed typed version cannot satisfy it. Historical terminal results are permitted to retain old target/typed versions under current own scope. Each current Goal, actual material hash, grant expiry/revocation, exact Release/revision, lease/cancel/budget and full proof gate remains; latest result's owner ledger is independent with PENDING semantics. Model/citation verification does not imply semantic acceptance.

UI still uses distinct PA/PB route/namespace/consent and immutable family scope, common pending idempotency and generation fences. PA recipeFP derives actual saved recipe, target preview matches request/context/hash/app/Release; old original-key GET recovery and scoped proven rollback rejection behaviors remain. Independent UI actual actions were not repeated here.

No new static blocker found. Remaining independent NOT RUN: fresh PA/PB naturalWorker matrix, native browser, PostgreSQL, Windows and paid models. Parent actual author16/affected3/freshPB evidence must be reported separately with its exact sources and results; this report does not claim it completed.
