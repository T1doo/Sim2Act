"""Package completed bounded diagnostic receipts, excluding only declared caches/aliases."""
import hashlib,json,tarfile
from pathlib import Path
B=Path('/workspace/pa-production-wiring-evidence-20261015');D=Path('/workspace/Sim2Act-pa-provider/docs/evidence/pa-production-wiring-20261015')
def h(p):
 z=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):z.update(block)
 return z.hexdigest()
files={}
for p in sorted(B.rglob('*')):
 rel=p.relative_to(B)
 if {'__pycache__','.pytest_cache','mypy-cache'}.intersection(rel.parts) or p.is_symlink() or not p.is_file():continue
 assert not any(x.is_symlink() for x in p.parents if x!=B.parent)
 if rel.as_posix()=='PACKAGE_RESULT.json':continue
 files[rel.as_posix()]={'bytes':p.stat().st_size,'sha256':h(p)}
assert 'delivery/REPORT.md' in files
for run in ('initial-faults','revised-pa','budget-production-regression','existing-worker-regression','allowed-rollback-remainder','strengthened-injections'):
 for n in ('COMMAND.json','START.json','PROCESS_EXIT.json','RESULT.json','results.xml','source-before.json','source-after.json','executed-source-manifest.json'):
  assert 'observation/'+run+'/'+n in files
D.mkdir(exist_ok=True,parents=True);target=D/'pa-wiring-evidence.tar.gz'
with tarfile.open(target,'w:gz') as archive:
 for name in files:archive.add(B/name,arcname=name,recursive=False)
seen=set()
with tarfile.open(target,'r:gz') as archive:
 for m in archive:
  n=m.name;assert m.isfile() and n not in seen and n in files and not n.startswith('/') and chr(92) not in n and all(x not in ('','.','..') for x in n.split('/'))
  seen.add(n);z=hashlib.sha256()
  with archive.extractfile(m) as f:
   for block in iter(lambda:f.read(1024*1024),b''):z.update(block)
  assert m.size==files[n]['bytes'] and z.hexdigest()==files[n]['sha256']==h(B/n)
assert seen==set(files)
(D/'MANIFEST.json').write_text(json.dumps(files,indent=2)+'\n')
x=dict(file=target.name,bytes=target.stat().st_size,sha256=h(target),members=len(files),product_source_sha='95d0d501c14d8536968655b3cf168564c54cb4b8',product_fix='P_A_OFFLINE_WIRING_LIVE_CLOSED',all_members_readback=True)
(D/'ARCHIVE.json').write_text(json.dumps(x,indent=2)+'\n');(B/'PACKAGE_RESULT.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x))
