"""After frozen runs terminate, strengthen execution proof without product edits."""
from pathlib import Path
import ast,json,hashlib,subprocess
repo=Path('/workspace/Sim2Act-pa-provider');p=repo/'tests/test_pa_trial_dispatch.py'
b=Path('/workspace/pa-production-wiring-evidence-20261015')
for name in ('revised-pa','budget-production-regression','existing-worker-regression','allowed-rollback-remainder'):
 assert (b/'observation'/name/'RESULT.json').is_file(), name
 assert json.loads((b/'observation'/name/'RESULT.json').read_text())['source_unchanged']
before=p.read_text();s=before
s=s.replace('    attempts,\n','    Store,\n    attempts,\n',1)
s=s.replace('    original = trial._sent\n','    original = trial._sent\n    injected = []\n',1)
s=s.replace('        return original(worker, run, aid, request_wire)\n','        injected.append(fault)\n        return original(worker, run, aid, request_wire)\n',1)
needle='    assert sent == []\n    with data[0].tx() as c:\n'
assert s.count(needle)==1
s=s.replace(needle,'    assert injected == [fault]\n'+needle,1)
needle='        assert history["dispatch_authorized"] is False\n    assert len(sent) == before\n'
assert s.count(needle)==1
s=s.replace(needle,'''        assert history["dispatch_authorized"] is False
        if fault == "response_lost":
            cold = Store(str(data[0].engine.url), test_only=True)
            try:
                assert production.recover(cold, data[3], binding.contract, binding.approval_key) == history
                cold_sent = []
                fresh = binding.registry.accounts[0].model_copy(update=dict(checked_at=time.time()))
                cold_binding = replace(binding, registry=replace(binding.registry, accounts=(fresh,)))
                assert not Worker(cold, data[1], pa_trial=cold_binding,
                    goal_planner_transport=httpx.MockTransport(lambda r: cold_sent.append(r))).once()
                assert cold_sent == []
                assert production.recover(cold, data[3], binding.contract, binding.approval_key) == history
            finally:
                cold.engine.dispose()
    assert len(sent) == before
''',1)
def funcs(text):
 return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(text).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
a,z=funcs(before),funcs(s);changed=[k for k in a if a[k]!=z[k]]
assert set(changed)=={'test_changed_authority_or_request_before_marker_never_sends','test_actual_adapter_failure_keeps_nonrefundable_slot_and_never_retries'}
p.write_text(s)
(b/'integration/TEST_ASSERTION_STRENGTHENING.json').write_text(json.dumps(dict(changed_functions=changed,seven_slot_function_ast_unchanged=a['test_actual_seven_slots_use_existing_worker_and_adapter']==z['test_actual_seven_slots_use_existing_worker_and_adapter'],before_sha256=hashlib.sha256(before.encode()).hexdigest(),after_sha256=hashlib.sha256(s.encode()).hexdigest(),product_edits=False),indent=2)+'\n')
print(json.dumps(dict(changed=changed,product_edits=False)))
