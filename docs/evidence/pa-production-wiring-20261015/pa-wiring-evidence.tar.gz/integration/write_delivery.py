"""Write delivery from terminal facts; do not turn interruption into a pass."""
from pathlib import Path
import json,subprocess
B=Path('/workspace/pa-production-wiring-evidence-20261015');R=Path('/workspace/Sim2Act-pa-provider')
names=('initial-faults','revised-pa','budget-production-regression','existing-worker-regression','allowed-rollback-remainder','strengthened-injections')
results={n:json.loads((B/'observation'/n/'RESULT.json').read_text()) for n in names}
for n,v in results.items():
 assert v['source_files']==501 and v['source_unchanged'] and v['head_unchanged'] and v['tree_clean'],n
for n in ('revised-pa','budget-production-regression','allowed-rollback-remainder','strengthened-injections'):
 assert results[n]['returncode']==0 and not results[n]['timed_out'] and not any(results[n]['counts'][s] for s in ('failure','error','skipped')),n
assert results['initial-faults']['counts']['failure']==1 and results['initial-faults']['counts']['pass']==19
assert results['existing-worker-regression']['returncode']==2
seven_files=list((B/'observation/revised-pa/tmp').rglob('actual-seven-slots.json'));assert len(seven_files)==1
seven=json.loads(seven_files[0].read_text());assert len(seven['gaps'])==6 and min(seven['gaps'])>=60
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
assert not subprocess.check_output(['git','diff','--name-only','95d0d501c14d8536968655b3cf168564c54cb4b8',head,'--','src'],cwd=R,text=True).strip()
checks=dict(source_sha='95d0d501c14d8536968655b3cf168564c54cb4b8',final_assertion_sha=head,
 source_unchanged_since_seven_slot_run=True,source_files=501,seven_slot_evidence=seven,
 batches={n:{k:v for k,v in d.items() if k!='cases'} for n,d in results.items()},
 corrected_legacy_interruption=json.loads((B/'observation/existing-worker-regression/INTERRUPTION_CORRECTION.json').read_text()),
 overall_release='NOT_ACCEPTED',original_complete='388PASS_1FAIL_RC1_RETAINED',live='CLOSED',real_model_requests=0)
legacy = checks['batches']['existing-worker-regression']
legacy['raw_runner_counts'] = legacy.pop('counts')
legacy['completed_counts'] = dict(pass_count=13, failure=0, error=0, skipped=0)
legacy['interrupted'] = 1
legacy['not_run'] = 8
checks['completed_unique_targeted_cases'] = 29 + 79 + 13 + 5
checks['additional_strengthened_reexecutions'] = 9
checks['restricted_callback_cases_not_run'] = 4
(B/'delivery/DELIVERY.json').write_text(json.dumps(checks,indent=2)+'\n')
rows=[]
for n in names:
 v=results[n]
 if n=='existing-worker-regression': outcome='13 PASS / 1 INTERRUPTED / 8 NOT RUN (corrected; RC2)'
 else: outcome=f"{v['counts']['pass']} PASS / {v['counts']['failure']} FAIL / {v['counts']['error']} ERROR / {v['counts']['skipped']} SKIP; RC{v['returncode']}"
 rows.append(f"| {n} | {outcome} | {v['elapsed']:.3f}s |")
report='''# P-A trial wiring through the existing Worker — 2026-10-15

The former actual seven-slot fixture patched the transport class to add trial accounting; the default production admission used a canned sender only. This slice adds a server-owned `PATrialBinding` to the existing Worker and captured InternModel adapter. It executes only explicit isolated SQLite/MockTransport fixtures. Production account/free-entitlement/enforced-nonchargeability resolution remains absent and LIVE remains closed.

## Implementation and contracts

`pa_trial_dispatch.py` binds the original approved Generate3/Source2/Cold2 contract, exact canonical account quota, approval, owner/project, stage authority, software qualification and budgets. Original Worker reservation appends the slot and actual request archive atomically with Attempt/reservation/context/event. Original adapter guard is followed by fresh admission and one durable send marker before IO. Captured original decoded response/prefix is recorded before original business validation; verified settlement joins complete request/response/event/wire/marker evidence inside the existing checker/candidate/NS verification transactions. Current auth/cancel/version/lease/fence checks remain active, with no new executor and no lease or deadline extension.

The public budget methods retain their original interfaces. Independent AST comparison proves the extracted transaction bodies are unchanged after the helper docstring/transaction precondition. No HTTP fee/account/callback override, credentials, real model request, deployment or protected branch change.

A DB marker cannot atomically fence external HTTP. A late received body may become an owned fact while business acceptance is refused. Explicit response archive failure means NOT_PERSISTED, nonrefundable UNKNOWN and no automatic archive retry. The existing first generation resource.read receipt was committed earlier and is not claimed to roll back. Completed history cannot gain new archives; original-key recovery reads without resending/refunding/re-enabling.

## Actual validation

| Batch | Terminal result | Wall time |
|---|---|---|
'''+ '\n'.join(rows)+f'''

The seven-slot run made **7 actual OFFLINE MockTransport sends**, retained **14 request/response archives**, recorded synthetic KNOWN **{seven['accounting']['total_tokens']} tokens** / reserved envelope **{seven['accounting']['reserved_envelope']}**, and preserved the transport class. Six real gaps in seconds: {', '.join(f'{x:.6f}' for x in seven['gaps'])}. Freshness refresh is explicitly synthetic fixture data, never real account or fee evidence. All seven slots accepted only after original deterministic checks; citation validity is not human semantic acceptance.

The first 19PASS/1FAIL was a test-injected process-loss RuntimeError escaping before UNKNOWN assertions, not an erased history. The revised test catches only that exact injected exception and proves the durable unresolved slot/marker and no success. The final assertion batch additionally proves all eight pre-send injections executed and verifies original-key recovery from a new Store/Worker after lost response, with no additional adapter send. The seven-slot test function AST and all product source remain unchanged by that assertion strengthening.

Source qualification: candidate `e02e84632331d6f4aafb6fe92d6a13210b2fe5b3`, pin `449cf2b6018b3d8e62b32aab511e323cc89f458c0bb4caa73b7bd2ee71117bb6`, 86 exact qualified modules. Seven-slot/initial regression source SHA `95d0d501c14d8536968655b3cf168564c54cb4b8`; strengthened assertion SHA `{head}`. Every batch captured and read back 501 src/tests/pyproject files with unchanged before/after/copied bytes, HEAD and clean tree. The strengthened batch is a separate frozen test revision; no claim that all cases ran in one final-SHA full suite.

Full-source Ruff PASS. Mypy: 5 existing errors in status_report.py/tools.py, 87 source files; zero new errors. Not a green type-check or remote CI claim.

## Independent review and retained interruption

Reports preserve the initial implementation findings, the pre-send P2 fix, budget AST proof and final evidence review. The legacy runner mistakenly selected `test_natural_spec_callback_reads.py`, which imports the known restricted private SQL/UDF barrier module. Root stopped its own pytest with SIGINT before the four callback test bodies; collection import did occur. No alternate barrier/UDF tool or diagnostic was attempted. Stdout confirms 13 completed PASS; XML adds one unnamed interrupted artifact which the original naive RESULT counted as PASS14. Original XML/RESULT are preserved; INTERRUPTION_CORRECTION.json and the independent review establish **13PASS/1INTERRUPTED/8NOTRUN, RC2**. Five independent permitted rollback cases then ran separately; the four restricted callback cases remain NOT RUN. No barrier/UDF evidence is claimed.

## Remaining gates

Original complete389 **388PASS/1FAIL/RC1 remains NOT_ACCEPTED**, including the un-erased peer_version failure; no new peer diagnostic or blind complete389. P-B production wiring is not part of this slice. Real provider/account/free entitlement/enforced zero charge, LIVE, PostgreSQL, Windows, native browser, human semantics, deployment, remote CI and full live P-A/P-B acceptance are **NOT RUN**. Overall release remains closed.

Evidence: ../evidence/pa-production-wiring-20261015/pa-wiring-evidence.tar.gz, MANIFEST.json and ARCHIVE.json. These contain immutable failures, exact commands/process exits/XML/source closures, raw fixture outcomes, reviews and corrections. Final ordinary branch push is verified separately by exact remote SHA, 13 protected refs, clean 0/0 state and unchanged unrelated WIP.
'''
(B/'delivery/REPORT.md').write_text(report)
doc=R/'docs/F2/PATrialWorkerWiring20261015.md';doc.write_text(report)
print(json.dumps(dict(source_sha=checks['source_sha'],assertion_sha=head,batches={n:v['counts'] for n,v in results.items()})))
