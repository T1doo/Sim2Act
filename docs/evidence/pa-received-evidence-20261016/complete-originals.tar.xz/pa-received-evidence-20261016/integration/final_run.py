import pathlib,hashlib,json,subprocess,os,time,xml.etree.ElementTree as ET
R=pathlib.Path('/workspace/Sim2Act-pa-provider');B=pathlib.Path('/tmp/pa-received-evidence-20261016');O=pathlib.Path('/workspace/pa-received-final-20261016');P='/workspace/Sim2Act/.venv/bin/python'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=R,text=True).strip()
def manifest():return {str(p.relative_to(R)):h(p) for folder in ('src','tests') for p in sorted((R/folder).rglob('*')) if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts}|{'pyproject.toml':h(R/'pyproject.toml')}
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
sha=git('rev-parse','HEAD');assert not git('status','--porcelain');before=manifest();write(O/'source-before.json',before)
common=[P,'-m','pytest','-q','-p','no:cacheprovider','-p','pb_allowed_imports','-p','pack_cases']
groups={'ordinary-model':['tests/test_natural_spec_apps.py','tests/test_natural_received_evidence.py','tests/test_natural_reception_handoff.py','--deselect=tests/test_natural_spec_apps.py::test_queued_revocation_updates_pair_without_private_body_reads','--deselect=tests/test_natural_spec_apps.py::test_revoked_receiver_only_preserves_owned_raw_no_protected_full_read'],'shared-archive':['tests/test_pa_spec_apps.py','tests/test_natural_source_archives.py::test_received_failure_facts_survive_without_business_success','tests/test_natural_trial_runs.py::test_actual_strict_qualification_refusal_is_atomic']}
env={k:os.environ[k] for k in ('PATH','LANG','LC_ALL','TZ') if k in os.environ};env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=f'{B}/integration:{R}/src:{R}/tests')
started=time.time();jobs=[]
for name,selected in groups.items():
 d=O/name;d.mkdir(exist_ok=False);tmp=B/(name+'-tmp');args=[*common,*selected,'--basetemp='+str(tmp),'--junitxml='+str(d/'results.xml')];local=dict(env,PACK_CASES=str(d/'packed'),PB_IMPORT_RECEIPT=str(d/'IMPORT_POLICY.json'));so=(d/'stdout.log').open('w');se=(d/'stderr.log').open('w');proc=subprocess.Popen(args,cwd=R,env=local,stdout=so,stderr=se);jobs.append((name,d,proc,so,se));write(d/'COMMAND.json',{'argv':args,'tested_sha':sha,'pid':proc.pid,'timeout_seconds':1800,'database_url_inherited':False})
exits={}
for name,d,proc,so,se in jobs:
 timeout=False
 try:code=proc.wait(timeout=max(1,1800-(time.time()-started)))
 except subprocess.TimeoutExpired:timeout=True;proc.kill();code=proc.wait()
 so.close();se.close();exits[name]={'returncode':code,'timed_out':timeout}
write(O/'PROCESS_EXIT.json',exits);after=manifest();write(O/'source-after.json',after);cases=[]
for name,d,*_ in jobs:
 for c in ET.parse(d/'results.xml').getroot().iter('testcase'):
  cases.append({'batch':name,'id':c.get('classname','')+'::'+c.get('name',''),'status':next((v.tag for v in c if v.tag in ('failure','error','skipped')),'pass')})
result={'tested_sha':sha,'counts':{s:sum(c['status']==s for c in cases) for s in ('pass','failure','error','skipped')},'cases':cases,'processes':exits,'elapsed':time.time()-started,'source_files':len(before),'source_unchanged':before==after,'head_unchanged':sha==git('rev-parse','HEAD'),'tree_clean':not git('status','--porcelain'),'xml_sha256':{name:h(d/'results.xml') for name,d,*_ in jobs},'excluded_restricted_nodes':2,'full_source_archive_trial_test_not_run':True};write(O/'RESULT.json',result);print(json.dumps(result))
