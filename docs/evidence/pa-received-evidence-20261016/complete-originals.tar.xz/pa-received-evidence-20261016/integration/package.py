import pathlib,json,hashlib,tarfile,shutil,os,subprocess
R=pathlib.Path('/workspace/Sim2Act-pa-provider');B=pathlib.Path('/tmp/pa-received-evidence-20261016');F=pathlib.Path('/workspace/pa-received-final-20261016');C=pathlib.Path('/workspace/pa-received-full-chain-20261016');V=pathlib.Path('/tmp/pa-received-evidence-review-20261016')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((F/'RESULT.json').read_text());q=json.loads((C/'RESULT.json').read_text());assert r['counts']=={'pass':99,'failure':0,'error':0,'skipped':0};assert q['counts']=={'pass':1,'failure':0,'error':0,'skipped':0};assert (V/'FINAL_REVIEW.md').is_file();assert (B/'REPORT_FINAL.md').is_file()
source=json.loads((F/'source-after.json').read_text());assert all(h(R/p)==v for p,v in source.items());assert len(source)==514
shutil.copytree(V,B/'review',dirs_exist_ok=True)
roots=[(B,''),(F,'final/'),(C,'ordinary-source-cold/')];files={}
for root,prefix in roots:
 for p in sorted(root.rglob('*')):
  rel=prefix+str(p.relative_to(root))
  if p.is_symlink():files[rel]={'symlink':os.readlink(p)}
  elif p.is_file():files[rel]={'sha256':h(p),'bytes':p.stat().st_size}
(B/'COMPLETE_MANIFEST.json').write_text(json.dumps(files,indent=2)+'\n')
(B/'SEAL.json').write_text(json.dumps({'tested_sha':r['tested_sha'],'manifest_sha256':h(B/'COMPLETE_MANIFEST.json'),'counts':{'pass':100,'failure':0,'error':0,'skipped':0},'restricted_deselected':2,'qualified':False,'new_trial_full_chain':'NOT_RUN','final_review_sha256':h(B/'review/FINAL_REVIEW.md')},indent=2)+'\n')
D=R/'docs/evidence/pa-received-evidence-20261016';D.mkdir(parents=True,exist_ok=True);a=D/'complete-originals.tar.xz'
with tarfile.open(a,'w:xz',preset=6) as t:
 for root,prefix in roots:t.add(root,arcname=B.name+('/'+prefix.rstrip('/') if prefix else ''))
expected={}
for root,prefix in roots:
 for p in root.rglob('*'):
  if p.is_file() and not p.is_symlink():expected[B.name+'/'+prefix+str(p.relative_to(root))]=h(p)
count=0
with tarfile.open(a,'r:xz') as t:
 for m in t:
  if m.isfile():assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==expected[m.name],m.name;count+=1
assert count==len(expected)
for n in ('FAILURE_HISTORY.json','QUALIFICATION_AND_PRESERVATION.json','COMPLETE_MANIFEST.json','SEAL.json','FINAL_RESULT.json'):
 shutil.copyfile(B/n,D/n)
shutil.copyfile(B/'review/FINAL_REVIEW.md',D/'FINAL_REVIEW.md')
shutil.copyfile(F/'ordinary-model/results.xml',D/'ordinary-model-results.xml');shutil.copyfile(F/'shared-archive/results.xml',D/'shared-archive-results.xml');shutil.copyfile(C/'results.xml',D/'ordinary-source-cold-results.xml');shutil.copyfile(F/'PROCESS_EXIT.json',D/'PROCESS_EXIT.json');shutil.copyfile(C/'PROCESS_EXIT.json',D/'ordinary-source-cold-PROCESS_EXIT.json')
for p in (C/'packed').glob('*.tar.xz'):
 with tarfile.open(p) as t:
  for m in t:
   if m.isfile() and m.name.endswith('ACTUAL_SOURCE_COLD.json'):(D/'ACTUAL_SOURCE_COLD.json').write_bytes(t.extractfile(m).read())
receipt={'archive':a.name,'sha256':h(a),'bytes':a.stat().st_size,'regular_members_verified':count,'complete_manifest_sha256':h(B/'COMPLETE_MANIFEST.json'),'tested_source_files':514};(D/'BUNDLE_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
report=(B/'REPORT_FINAL.md').read_text()+'\n## 可复算原件\n\n[最终结果](../evidence/pa-received-evidence-20261016/FINAL_RESULT.json)、[普通运行原XML](../evidence/pa-received-evidence-20261016/ordinary-model-results.xml)、[共享提交/归档原XML](../evidence/pa-received-evidence-20261016/shared-archive-results.xml)、[单条普通Source→Cold原XML](../evidence/pa-received-evidence-20261016/ordinary-source-cold-results.xml)、[实际成果回执](../evidence/pa-received-evidence-20261016/ACTUAL_SOURCE_COLD.json)、[独审](../evidence/pa-received-evidence-20261016/FINAL_REVIEW.md)。\n\n[完整原始证据](../evidence/pa-received-evidence-20261016/complete-originals.tar.xz)含所有红测/失败/开发WIP原件、完整SQLite/case包、命令/退出/stdout/stderr、source闭包及静审历史；逐一核验'+str(count)+'个原文件，归档SHA256 `'+receipt['sha256']+'`，详见[归档回执](../evidence/pa-received-evidence-20261016/BUNDLE_RECEIPT.json)。\n'
(R/'docs/F2/PAReceivedEvidence20261016.md').write_text(report)
assert all(h(R/p)==v for p,v in source.items());print(json.dumps(receipt,indent=2))
