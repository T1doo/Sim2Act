"""Evidence-only byte recovery, never imported/executed; each matches saved hash."""
import pathlib,json,hashlib,subprocess
R=pathlib.Path('/workspace/Sim2Act-pa-provider');B=pathlib.Path('/tmp/pa-received-evidence-20261016');m=json.loads((B/'FIRST_CANDIDATE_SOURCE.json').read_text());baseline=json.loads((B/'BASELINE_SOURCE.json').read_text());D=B/'development-source';D.mkdir(exist_ok=True)
paths=[p for p,v in m.items() if baseline.get(p)!=v];receipt=[]
for name in paths:
 data=(R/name).read_text()
 if name=='src/sim2act/natural_spec_runtime.py':
  data=data.replace('''        receipt_owner(c, job, aid, wire)
        require(c.execute(select(attempts.c.id).where(
            attempts.c.id == aid, attempts.c.run_id == job["id"],
            attempts.c.status == "RECEIVED", attempts.c.response == response,
            attempts.c.usage == received_usage)).first() is not None,
            "Received response changed before reception commit")
''','')
  data=data.replace('''            # The receive transaction has already committed. A later owner,
            # wire or response change cannot authorize writes to that history.
            receipt_owner(c, job, aid, wire)
''','')
  data=data.replace('''                    attempts.c.response == response,
                    attempts.c.usage == received_usage,
''','')
  data=data.replace('''            changed = c.execute(
                update(attempts)
                .where(
                    attempts.c.id == aid,
                    attempts.c.run_id == job["id"],
                    attempts.c.status == "RECEIVED",
''','''            c.execute(
                update(attempts)
                .where(
                    attempts.c.id == aid,
                    attempts.c.run_id == job["id"],
                    attempts.c.status == "RECEIVED",
''')
  data=data.replace('''            require(changed.rowcount == 1, "Received rejection has a competing owner")
''','')
 elif name=='tests/test_natural_received_evidence.py':
  data=data.replace('''    attempts,
    delivery_graph_requests,
    events,
    internal_instance_data,
    internal_run_bindings,
    operations,
    reservations,
    runs,
''','''    attempts, delivery_graph_requests, events, internal_instance_data,
    internal_run_bindings, operations, reservations, runs,
''')
  data=data.replace('''    assert duplicate.status_code == 202 and duplicate.json()['run_id'] == rid, duplicate.text
    assert duplicate.json()['cached'] is True
    assert response.status_code in (200, 409), response.text
    if response.status_code == 200:
        assert response.json()['status'] != 'SUCCEEDED'
''','''    assert duplicate.status_code in (200, 202, 400, 403, 409), duplicate.text
''')
 raw=data.encode();actual=hashlib.sha256(raw).hexdigest();assert actual==m[name],(name,actual,m[name]);p=D/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);receipt.append({'file':name,'sha256':actual,'matches_saved_after_run_wip_manifest':True})
(B/'DEVELOPMENT_SOURCE_RECOVERY.json').write_text(json.dumps({'method':'Reverse only exact known later patches in evidence copy; never imported/executed; unchanged files anchored to baseline16bf Git','changed_files':receipt,'unchanged_baseline_files':sum(baseline.get(p)==v for p,v in m.items()),'not_a_before_after_frozen_acceptance':True},indent=2)+'\n');print(json.dumps(receipt,indent=2))
