"""One ordinary API/actual Worker/saved source/cold new-input chain, no Trial."""
import json

from conftest import env  # noqa: F401
from fastapi.testclient import TestClient
from sqlalchemy import select
from test_natural_spec_apps import (
    COLD, SOURCE, enqueue, inspect, instance, material, ready, setup, transport,
)

from sim2act import natural_specs as natural
from sim2act.api import create_app
from sim2act.db import Store, attempts, internal_instance_data, runs
from sim2act.worker import Worker


def test_actual_ordinary_saved_source_then_cold_new_input(env, tmp_path):  # noqa: F811
    data = setup(env)
    store, settings, client = data[:3]
    origin, app_id, release, inst, generation = ready(data, 'sequential')
    source_id = enqueue(data, release, inst, key='source-actually-saved')
    source_sends = []
    assert Worker(store, settings, goal_planner_transport=transport(source_sends, SOURCE)).once()
    source_result = inspect(data, inst, source_id)
    assert source_result.status_code == 200 and source_result.json()['status'] == 'SUCCEEDED'
    source_checklist = source_result.json()['result']['checklist']
    source_artifact = client.get(f'/api/internal/app-run-jobs/{source_id}/spec-artifact')
    assert source_artifact.status_code == 200
    assert json.loads(source_artifact.json()['resource']['content']) == source_checklist
    assert source_checklist['source_content'] == SOURCE
    with store.tx() as c:
        source_rows = [dict(r) for r in c.execute(select(internal_instance_data).where(
            internal_instance_data.c.instance_id == inst['id'])).mappings()]
        assert len(source_rows) == 1
        source_attempts = [dict(r) for r in c.execute(select(attempts).where(
            attempts.c.run_id == source_id)).mappings()]
        assert len(source_attempts) == 2 and all(r['status'] == 'VERIFIED' for r in source_attempts)
    rid, card = material(client, data[4], COLD)
    base = f'/api/projects/{data[4]}/natural-spec-model-runs/{origin}'
    options = client.get(base + '/binding-options', params={'card_id':card['id']})
    assert options.status_code == 200
    p = options.json()
    body = dict(card_id=card['id'], expected_goal_version=card['version'],
        expected_goal_fingerprint=card['fingerprint'], expected_source_hash=p['source_hash'],
        expected_model_candidate_fingerprint=p['model_candidate_fingerprint'],
        expected_recipe_fingerprint=p['recipe_fingerprint'], name='Cold independent source',
        consent=natural.CONSENT,
        request_key='actual-source-cold')
    made = client.post(base + '/bindings', json=body)
    assert made.status_code == 201, made.text
    target = made.json()['id']
    cold_release, cold_inst = instance(data, target)
    cold = Store(settings.database_url, test_only=True)
    try:
        with TestClient(create_app(cold, settings)) as fresh:
            fresh.headers['Authorization'] = 'Bearer synthetic-test-A'
            recovered = fresh.get(base + '/bindings/by-key/actual-source-cold')
            assert recovered.status_code == 200 and recovered.json()['id'] == target
            cold_data = (cold, settings, fresh, *data[3:])
            cold_id = enqueue(cold_data, cold_release, cold_inst, key='cold-actually-saved')
            cold_sends = []
            assert Worker(cold, settings, goal_planner_transport=transport(cold_sends, COLD)).once()
            result = inspect(cold_data, cold_inst, cold_id)
            assert result.status_code == 200 and result.json()['status'] == 'SUCCEEDED', result.text
            checklist = result.json()['result']['checklist']
            assert checklist['source_content'] == COLD and checklist['source']['resource_id'] == rid
            artifact = fresh.get(f'/api/internal/app-run-jobs/{cold_id}/spec-artifact')
            assert artifact.status_code == 200 and json.loads(artifact.json()['resource']['content']) == checklist
            assert SOURCE not in json.dumps(cold_sends)
            assert len(generation) == 3 and len(source_sends) == len(cold_sends) == 2
            with cold.tx() as c:
                assert [dict(r) for r in c.execute(select(internal_instance_data).where(
                    internal_instance_data.c.instance_id == inst['id'])).mappings()] == source_rows
                assert [dict(r) for r in c.execute(select(attempts).where(
                    attempts.c.run_id == source_id)).mappings()] == source_attempts
                assert c.execute(select(runs.c.status).where(runs.c.id == source_id)).scalar_one() == 'SUCCEEDED'
            (tmp_path / 'ACTUAL_SOURCE_COLD.json').write_text(json.dumps(dict(
                generation_run=origin, source_run=source_id, cold_run=cold_id,
                source_result=source_result.json(), source_artifact=source_artifact.json(),
                cold_result=result.json(), cold_artifact=artifact.json(),
                generation_dispatches=len(generation), source_dispatches=len(source_sends),
                cold_dispatches=len(cold_sends), original_source_history_unchanged=True,
                qualification_replaced=False, trial_binding_used=False,
                semantic_goal_acceptance=checklist['semantic_goal_acceptance']), indent=2))
    finally:
        cold.engine.dispose()
