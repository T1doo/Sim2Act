# Frozen received-evidence repair: static re-review

Frozen SHA: `ff6d703f9dc21f59ec905098e82be80caef0db13`; Git status clean. Scope is the five changed files: two product modules and three tests. Outcome: previously identified receipt/archive/rejection transaction issues are addressed in the frozen source; no remaining static blocker identified for this bounded repair. Actual final acceptance awaits the ongoing frozen tests and source closure.

The RESPONSE path removes only the reservation join prerequisite. REQUEST still requires its original reservation. Original Run principal/project/runtime, exact Attempt id/run/mode and request wire hash/length remain checked; original request archive pair/header identity, immutability and no terminal backfill remain mandatory. This does not turn an archived response into proof of a valid slot or successful Source.

The reception transaction now checks original identity before its compare-and-set, atomically writes RECEIVED/raw/model/usage/elapsed and NS_RECEIVED, then checks original identity and scalar status/response/usage consistency after the event. A failed event or final scalar proof rolls back that reception transaction; it must not be described as persisted in that failure case. No live permission/lease or reservation prerequisite was added to the factual write, so stopped/late receipt behavior remains possible without authorizing work.

record_response runs afterward in its own transaction inside the original try/reject block. Its failure rolls back only the archive and does not erase the committed raw. The complete original verification/counters/permissions/operation/lease/fence/settlement checks still gate success.

The rejection transaction now repeats receipt_owner before any trial rejection side effect, uses RECEIVED plus original response and usage as its compare-and-set, and requires one changed row before operation rejection and NS_REJECTED. The trial.reject call is inside this same transaction, so a later failed CAS rolls its tentative ledger effects back too. Owner/wire drift rejects before touching the changed history; competing response prevents the rejection update and event. The earlier RECEIVED facts or intentionally damaged competitor row remain untouched rather than being fabricated into REJECTED_KNOWN.

The three new handoff tests wrap the actual Store.tx context manager, call the original transaction unchanged, and inject scoped fixture damage only after a real RECEIVED transaction commits, before the next archive/verification transaction. They use the actual ordinary Worker/MockTransport and verify the competing Attempt and NS_REJECTED rows remain equal to the captured damaged rows, no typed data, and one actual source send. They do not replace ownership/qualification/runtime product functions to obtain success. The original external handoff XML is 3FAIL (owner/wire/competing_response), with concrete REJECTED_KNOWN vs RECEIVED drift in the failure trace; it remains evidence of the first candidate defect, not final acceptance.

The five received-evidence cases still establish missing/moved reservation, missing request seal, cancellation and network-prefix boundaries only when their actual final results arrive. Existing response_write_failure changes expectations intentionally to retained known raw/usage/NS_RECEIVED plus rolled-back archive/no business success. Request-write failure, invalid/empty/oversize/prefix and normal complete source behavior must continue to be tested; no test count is inferred from source inspection.

Frozen SHA256:

- natural_source_archives.py: `335b72ac93563aa0fc528b09a3b69144ca759df1cc735eef012a74d3d1ca47f0`
- natural_spec_runtime.py: `ced4711e76d0ca7cc89c5d78132a5562871ce2abf33f0735fe216675cbae7cfe`
- test_natural_received_evidence.py: `83fe7d849dd63493faf4a67f8786d5d2c1c04f1254799f6c365498f6f26ca4cb`
- test_natural_reception_handoff.py: `49bbc8dfc4f16e874bc01f91618e3d55ca9b978cf309c38a65e05908810420ce`
- test_natural_source_archives.py: `b9df03c23bd1a3c3f71bd367afe4a1d10d6685528d458f773f134991fbaee1a9`

No qualification, anchor, pin, budget, sender or full trial execution permission was changed. This is ordinary offline received-fact retention, not the unresolved associated page/qualified Worker path. Known restricted diagnostic bodies must remain NOT RUN and excluded without retry. No tests/SQL/API/browser/private diagnostics were executed by this reviewer; only read-only source/Git/XML reads and this separate review-file write occurred.
