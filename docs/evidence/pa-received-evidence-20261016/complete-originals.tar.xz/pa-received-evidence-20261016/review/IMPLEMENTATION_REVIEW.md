# Received evidence candidate: independent static review

Status: core transaction repair matches the proposed contract; additional ownership rejection protection/evidence requested before accepting an unrestricted no-foreign-history claim. Candidate is mutable and its first batch is running. This is not frozen/runtime acceptance.

## Confirmed in current diff

- receipt_owner retains scalar Run principal/project/runtime, Attempt id/run/mode and actual original wire hash/length checks. Runtime calls it before the independent RECEIVED update. No live lease or current resource-body permission is required for the factual append.
- REQUEST passes reserved=True and retains the exact original reservation join. RESPONSE no longer depends on a still-present reservation. Original REQUEST pair/header fingerprints, immutable duplicate handling and initial status/backfill restrictions remain in _write.
- Raw/response_model/usage/elapsed and NS_RECEIVED remain atomic in their own receipt transaction. The original STARTED/response-null compare-and-set and changed-row requirement remain. record_response moves into the existing try/reject region in a distinct transaction; an archive DomainError can no longer roll back the already committed received fact.
- Complete verification/counters/current permissions/cancel/lease/fence and ordinary rejection code have not been relaxed. No slot recreation/refund/retry branch was added.
- The old response_write_failure assertions were intentionally changed from STARTED/rawNone to REJECTED_KNOWN/raw retained/known usage/NS_RECEIVED and no RESPONSE archive. That is the required behavior change, not evidence of a new successful business result. Request-archive failure expectations are unchanged.

The new five actual ordinary-Worker tests target missing reservation, moved reservation, missing request seal, cancellation with missing reservation, and a network prefix with missing reservation. They assert single original send, retained original parameters/reserved tokens, no successful result/typed data/save operation, no slot recreation or foreign-slot repair, body facts where possible, and no original-key/fresh-Worker resend. Prefix remains STARTED/unknown. Their finite production-function path uses ordinary MockTransport rather than new trial binding/qualification replacements. They do not qualify software or validate a full trial Source/Cold controller.

## Remaining ownership boundary to protect

The receipt_owner guard closes the pre-receipt ownership hole identified in PROTOCOL_REVIEW, but the existing except/rejection transaction still updates Attempt WHERE id/run/status=RECEIVED and creates NS_REJECTED without checking original Run owner. With the new receipt/archive split, current identity can drift after receipt commit and before the archive transaction. The archive correctly rejects a moved Run owner; the later rejection transaction can nevertheless mark that now-foreign owner's Attempt REJECTED_KNOWN and append rejection metadata under the same Run id. A moved Attempt.run_id is already excluded by the UPDATE condition; Run owner drift is not.

Recheck original owned scalar Run/Attempt/wire identity in the rejection transaction, without requiring reservation/current private-body permission/live lease. If identity is moved or a competing response/status won, preserve the prior received facts and leave that moved/competing history untouched. Do not create a fabricated NS_REJECTED anchor when the corresponding owned transition did not win. Keep the original error visible; secondary rejection failure must not pretend its state transition completed.

Required focused regressions: Run principal/project/runtime or Attempt.run_id/wire changed before reception must refuse attachment without changing another row; drift after RECEIVED commit before archive/reject must preserve received raw yet not modify foreign/competing rejection state. A test can inject at these existing boundaries using the ordinary owned-fixture transaction code; no private SQL diagnostic module or qualification bypass is needed. Also retain the original reservation write failure zero-send regression and reception-event write failure atomic rollback behavior.

This issue is inferred directly from the unchanged rejection predicates; I did not execute a reproducer. The first five new cases do not cover these moved-owner/moved-Attempt guards, so their success alone would not establish the complete cross-owner contract.

No tests/SQL/API/browser or model requests were executed by this reviewer. No source/test or sealed evidence files were changed; only this new independent review note was written.
