# Received-response evidence: minimum repair contract

Read-only protocol review against the current 16bf source. No product/test edits, tests, SQL, application/API/browser calls, private diagnostics or model requests were performed. This is advice before the new candidate is frozen, not implementation acceptance.

## Confirmed defect and supported direction

natural_source_archives._write currently inner-joins reservations for both REQUEST and RESPONSE. natural_spec_runtime.advance_model updates Attempt to RECEIVED/raw/usage, calls record_response, and writes NS_RECEIVED in a single transaction. Deleting the original reservation after the actual MockTransport response therefore makes response archival reject and rolls the reception transaction back to STARTED/raw=None. The existing missing_slot test's expected REJECTED_KNOWN can fail for precisely this reason. This is a genuine fact-retention defect; complete-business verification should still reject a missing reservation.

Keep REQUEST archival unchanged: exact existing reservation, original wire, owned Run/Attempt and initial status, bounded body, paired immutable receipt/event, and no historical backfill. Reservation/request archival failure must remain zero sends with the whole reservation transaction rolled back.

For RESPONSE, remove only the requirement that the current reservation row still exists. Prove the current scalar Run principal/project/runtime, Attempt id/run/mode and original natural_spec_wire hash/length, and exact original REQUEST pair header fingerprints against the actual captured request_body. Keep immutable duplicate comparison, STARTED/RECEIVED-only new archive creation, existing bounds/omission/complete flags and terminal-backfill rejection. This writes owned immutable evidence; it is not a send capability, budget reservation or successful-source proof. Later source archive resolution must retain its complete original ledger/Attempt/request/response/lineage checks.

## Essential ownership check before the newly independent receipt commit

The existing archive call supplies the reception transaction's Run owner/wire check indirectly. Moving it out without replacement would lose that protection: a Run can retain its id while principal/project/runtime changes after send, and the old bare UPDATE Attempt WHERE id/run/status/response NULL would persist raw under the moved owner before the archive rejects.

The new receipt transaction must first preserve the essential owned identity and original Attempt/wire metadata comparisons to the sender_guard-captured held_attempt. Do not require live lease/current material permissions for factual receipt retention, since late or revoked receives are exactly what must survive. Do require original scalar Run ownership and the exact still-owned Attempt; never attach bytes to a moved Run/Attempt or overwrite a competing response. Keep STARTED/response-null compare-and-set and require one changed row. Write raw/response_model/normalized usage/elapsed and its original NS_RECEIVED fingerprint atomically in that same transaction. No private Goal/source/body read is needed for this owned append.

If original identity or competing receipt makes that commit unsafe, leave the competing/moved rows untouched and report conflict; no contract can promise successful persistence when the receipt write itself fails. Do not create a false NS_RECEIVED anchor when its update did not win.

## Archive and verification transaction split

After the receipt transaction has committed, enter the existing try/reject range and run record_response in its own transaction. A DomainError rolls back only that archive pair/event, leaves committed RECEIVED/raw/usage/NS_RECEIVED intact, and follows the existing rejection/failed-business path. No verification, settlement or output should run after archive failure. Rejection writes should still be limited to this original Attempt/Operation and must not overwrite competing final state; create NS_REJECTED only for the corresponding owned transition, never a fabricated anchor for another row.

Preserve the final complete bound/counters/reservation/operation/request/current permissions/lease/fence/version/cancel/trial/account/budget guards unchanged. A missing slot remains missing and blocks VERIFIED/typed data/instance result/Source acceptance. Do not reconstruct it, refund charge, automatically requeue or resend. If a secondary rejection/ledger write also fails, the previously committed reception is still retained, but do not claim a rejection transition completed when it did not.

For raw=None, invalid JSON, empty/oversize or network prefix paths, keep STARTED/unknown usage/nonrefundable unknown semantics. Owned captured bytes may be archived with their actual completeness/omission metadata; do not upgrade a prefix to complete or synthesize parsed raw, usage or canonical SHA. Archival failure must not produce success. Do not use a live-authorization check to erase late received facts.

## Required focused evidence

- Actual missing_slot response: exactly one original send; original raw/usage/NS_RECEIVED survives; available owned RESPONSE fact survives if otherwise valid; missing reservation remains missing; complete counters/business proof rejects; no typed output and unrelated Run/Attempt/AppRun unchanged.
- RESPONSE archive pair/event write failure after its write: reception survives, archive pair/event rolls back, no VERIFIED/output/refund/resend. Existing response_write_failure STARTED/raw=None assertions are deliberately superseded by this repair and should have a preserved red/change history. REQUEST write failure keeps its original zero-send behavior.
- NS_RECEIVED write failure still rolls back that receipt atomically; do not label it persisted.
- Original Run owner, Attempt.run_id, mode/wire parameters and request archive/pair tampering; foreign Attempt/Run, competing response, duplicate identical/different archive, late lease/fence, cancellation, revocation and changed instance/source. Owned facts may survive stopped execution, but no acceptance or other-owner mutation may survive.
- Invalid/empty/oversize/prefix response regressions retain original extent/omission/unknown behavior and raw privacy (no body/token leakage in public events).
- Reopen/read original keys never sends again, replenishes a slot or turns missing archival evidence into a valid Source. Preserve known restricted-import diagnostic exclusions; no alternative private SQL route is needed for these ordinary owned-fixture tests.

One unrelated future limitation noticed while reading: natural_spec_runtime.counters currently enforces an exact context-key set that excludes the new association MARKER. That may matter for eventual real associated Source execution once qualification is legitimately available. It is outside this received-facts repair and should not be silently changed or represented as covered by synthetic association tests here.

Only this independent new review directory was written. Root remains the only implementation writer.
