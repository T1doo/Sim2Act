# 独立审查红轮：30fe / Goal16

结论 ACTUAL CORE FAIL。HEAD30fe4f99ae320e6dd532561967c6cc676fa5a5ca；pa_spec_apps SHA7a745b61d2088e4c479becfdeb3485f817bbdf1e182bc073d582f60ec871c51e。429 source/tests/pyproject在退出时0diff，own进程0。

root请求额外有限Goal unresolved16边界，reviewer优先实际运行1probe：session93643 exit1/chunk4e7463，1FAIL/4.65s。合法原卡16unresolved→actual3 synthetic responses PARTIAL→confirm200→Release/Instance创建成功；首次POST instance/runs在app_jobs.py:189抛未处理Pydantic FrozenRunContract validation exception：goal.unresolved17，max16。多一项是来源tag，不能丢原16项来兜底。

完整SQLite witness：GoalCards2、confirmed app1、Release1、Instance1、AppRuns0、typed0；candidate完整16unresolved，模型Run PARTIAL。是不可运行已保存小应用，不是测试fixture错误或合法403/409响应。原capacity.log/XML/fixture.db/probe/425+4代码映射均保留。因异常在HTTP调用处抛出，未生成原test的goal-capacity-result.json；补充capacity-persisted-witness.json和capacity-exit-and-source.json如实保留，不捏造HTTP返回。

本轮原62+extra15均未启动，无其PASS计数。后续d915修复将完整人类unresolved保留、版本封印放独立spec_goal，需新源码fresh验收；原1FAIL不会覆盖或改为历史PASS。

仅/tmp写，未改产品/测试/预算/人工gold。真实模型/网络/费用/PG/Windows/native/永久禁取消窗口未运行。
