"""Bounded Goal16 usability challenge requested by root; only new SQLite fixture."""
import json
from pathlib import Path
import pytest
from conftest import env
import test_pa_spec_apps as support
from sim2act.db import app_drafts, select
from sim2act.worker import Worker


def test_native_goal_sixteen_unresolved_is_not_saved_as_unrunnable_spec_app(env):
    data = support.setup(env)
    content = dict(data[6]["content"])
    content["unresolved"] = ["Finite question " + str(i) for i in range(16)]
    made = data[2].post(f"/api/projects/{data[4]}/goal-cards", json=content)
    assert made.status_code == 201, made.text
    card = data[2].get(f"/api/goal-cards/{made.json()['id']}").json()
    data = (*data[:6], card)
    facts = {"input_unresolved":16, "card_status":made.status_code}
    out = Path(__file__).resolve().parents[1] / "goal-capacity-result.json"
    try:
        rid, result, sent = support.generate(data)
    except AssertionError as exc:
        with data[0].tx() as c:
            count = len(c.execute(select(app_drafts.c.id)).all())
        facts.update(early_failure=str(exc), app_count=count)
        out.write_text(json.dumps(facts,indent=2)+'\n')
        assert count == 0
        return
    facts.update(generation_status=result["status"], synthetic_responses=len(sent), source_run=rid)
    if result["status"] != "PARTIAL":
        with data[0].tx() as c:
            assert c.execute(select(app_drafts.c.id)).first() is None
        facts["safely_rejected_before_app"] = True
        out.write_text(json.dumps(facts,indent=2)+'\n')
        return
    confirmed = support.confirm(data, rid, result)
    facts["confirmation_http"] = confirmed.status_code
    if confirmed.status_code != 200:
        facts["confirmation_body"] = confirmed.json()
        out.write_text(json.dumps(facts,indent=2)+'\n')
        assert confirmed.status_code in {400,403,409,422}
        with data[0].tx() as c:
            assert c.execute(select(app_drafts.c.id)).first() is None
        return
    aid=confirmed.json()["id"]
    release, instance = support.instance(data, aid)
    facts.update(app_id=aid, release_id=release["id"], instance_id=instance["id"])
    response = data[2].post(f"/api/internal/instances/{instance['id']}/runs",json={
        "expected_revision":instance["revision"],"expected_release_fingerprint":release["fingerprint"],
        "input":{},"request_key":"capacity-cold-run"})
    facts.update(run_http=response.status_code,run_body=response.json())
    out.write_text(json.dumps(facts,indent=2)+'\n')
    assert response.status_code == 202, "Accepted model app must remain executable without dropping native unresolved"
    assert Worker(data[0],data[1]).once()
    actual=support.inspect(data,instance,response.json()['run_id'])
    facts.update(worker_http=actual.status_code,worker_body=actual.json())
    out.write_text(json.dumps(facts,indent=2)+'\n')
    assert actual.status_code==200 and actual.json()["status"]=="SUCCEEDED"
