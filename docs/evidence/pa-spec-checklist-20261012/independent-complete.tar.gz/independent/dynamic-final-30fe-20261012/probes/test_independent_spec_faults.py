"""Finite controlled corruption/late-callback probes; not realistic attack claims.

Fresh current-source SQLite/actual Worker fixtures. No network/model/PG/native.
Only this temporary directory is written. Manual quote gold remains outside the
synthetic façade in the author helper; no old cancelled probe is imported.
"""
import copy
import json
import time
from pathlib import Path

import pytest
from sqlalchemy import insert, select, text, update
from sqlalchemy.exc import DatabaseError

from conftest import env
import test_pa_spec_apps as support
from identifier_private_barrier import IdentifierPrivateBarrier, pa_rules
from sim2act import apps, pa_spec_apps as spec
from sim2act.contracts import Limits
from sim2act.db import (
    app_drafts, attempts, events, fingerprint, goal_cards, grants,
    internal_app_runs, internal_instances, meta, new_id, operation_intents,
    operations, projects, runs, task_extractions,
)
from sim2act.errors import DomainError

OUT = Path(__file__).resolve().parents[1] / "extra-details"


def all_rows(store):
    with store.engine.connect() as c:
        return {table.name: sorted((dict(r) for r in c.execute(select(table)).mappings()),
            key=lambda r: json.dumps(r, sort_keys=True, default=str)) for table in meta.sorted_tables}


def digest(value):
    return __import__("hashlib").sha256(json.dumps(value, sort_keys=True,
        separators=(",", ":"), default=str).encode()).hexdigest()


def record(name, **facts):
    OUT.mkdir(exist_ok=True)
    (OUT / (name + ".json")).write_text(json.dumps(facts, ensure_ascii=False,
        sort_keys=True, indent=2, default=str) + "\n")


def prefix(env):
    data = support.setup(env)
    source_run, aid, release, instance = support.prepared(data)
    rid = support.enqueue(data, release, instance)
    worker, claimed, limits = support.claim(data, rid)
    for _ in range(3):
        assert spec.advance(worker, claimed) is True
    return data, source_run, aid, release, instance, rid, worker, claimed, limits


@pytest.mark.parametrize("fault", ["run_runtime", "instance_cas", "lease_elapsed",
    "deadline_elapsed", "revoke_save", "goal_head", "cancel_late",
    "audit_attempt_extra", "audit_event_extra"])
def test_final_callback_keeps_all_audit_bytes_and_rolls_back_global_db(env, monkeypatch, fault):
    data, origin, aid, release, inst, rid, worker, claimed, limits = prefix(env)
    store = data[0]
    before = all_rows(store)
    original_event = store.event
    fired = []
    original_now = time.time

    def event(c, run_id, kind, body):
        result = original_event(c, run_id, kind, body)
        if kind != "SPEC_COMMITTED":
            return result
        fired.append(kind)
        if fault == "run_runtime":
            c.execute(update(runs).where(runs.c.id == rid).values(runtime_id=data[3]))
        elif fault == "instance_cas":
            c.execute(update(internal_instances).where(internal_instances.c.id == inst["id"])
                .values(revision=inst["revision"] + 1))
        elif fault in {"lease_elapsed", "deadline_elapsed"}:
            now = claimed["lease_until"] + 0.01 if fault == "lease_elapsed" else claimed["created_at"] + 301
            monkeypatch.setattr(time, "time", lambda: now)
        elif fault == "revoke_save":
            c.execute(update(grants).where(grants.c.principal_id == claimed["runtime_id"],
                grants.c.resource_id == data[4], grants.c.tool_ref == spec.SAVE)
                .values(revoked=True, revision=2))
        elif fault == "goal_head":
            c.execute(update(goal_cards).where(goal_cards.c.id == data[6]["id"])
                .values(version=data[6]["version"] + 1))
        elif fault == "cancel_late":
            c.execute(update(runs).where(runs.c.id == rid).values(cancel_intent=True))
        elif fault == "audit_attempt_extra":
            old = c.execute(select(attempts).where(attempts.c.run_id == origin)
                .order_by(attempts.c.created_at, attempts.c.id)).mappings().first()
            changed = copy.deepcopy(old["parameters"])
            changed["independent_late_audit_field"] = "controlled protected-byte change"
            c.execute(update(attempts).where(attempts.c.id == old["id"]).values(parameters=changed))
        else:
            old = c.execute(select(events).where(events.c.run_id == origin, events.c.kind == "STATE")
                .order_by(events.c.created_at, events.c.id)).mappings().first()
            assert old is not None
            changed = copy.deepcopy(old["data"])
            changed["independent_late_audit_field"] = "controlled protected-byte change"
            c.execute(update(events).where(events.c.id == old["id"]).values(data=changed))
        return result

    monkeypatch.setattr(store, "event", event)
    error = None
    returned = None
    try:
        returned = spec.advance(worker, claimed)
    except DomainError as exc:
        error = exc.code
    finally:
        monkeypatch.setattr(time, "time", original_now)
    after = all_rows(store)
    record("terminal-" + fault, fixture="controlled same-transaction callback corruption",
        origin_run=origin, run=rid, fired=fired, returned=returned, error=error,
        before_sha256=digest(before), after_sha256=digest(after), database_unchanged=before == after,
        changed_tables=[name for name in before if before[name] != after[name]],
        changed_after={name: after[name] for name in before if before[name] != after[name]})
    assert fired == ["SPEC_COMMITTED"]
    assert error is not None, "Late protected scope/audit/CAS/stop change must reject the complete save"
    assert after == before, "Artifact/grants/effect/typed/history and controlled fault must all roll back"


@pytest.mark.parametrize("fault", ["stale_queued", "error_mismatch"])
def test_prefix_relabel_does_not_pass_actual_progress_check(env, fault):
    data, origin, aid, release, inst, rid, worker, claimed, limits = prefix(env)
    with data[0].tx() as c:
        app_run = c.execute(select(internal_app_runs.c.id).where(internal_app_runs.c.instance_id == inst["id"])).scalar_one()
        c.execute(update(internal_app_runs).where(internal_app_runs.c.id == app_run)
            .values(**({"status": "QUEUED"} if fault == "stale_queued" else {"error": {"code": "CONTROLLED_MISMATCH"}})))
    before = all_rows(data[0])
    with data[0].tx() as c, pytest.raises(DomainError) as exc:
        job = c.execute(select(runs).where(runs.c.id == rid)).mappings().one()
        spec.verify_job(data[0], c, data[3], job, limits)
    after = all_rows(data[0])
    record("prefix-" + fault, error=exc.value.code, database_unchanged=before == after,
        before_sha256=digest(before), after_sha256=digest(after))
    assert after == before


def test_unknown_final_operation_is_never_redispatched(env):
    data, origin, aid, release, inst, rid, worker, claimed, limits = prefix(env)
    with data[0].tx() as c:
        job = c.execute(select(runs).where(runs.c.id == rid)).mappings().one()
        binding = spec.bound(data[0], c, data[3], job, limits)
        outputs, proved = spec.receipts(data[0], c, job, binding)
        step, action = binding["plan"]["definition"]["manifest"]["workflow"][-1], binding["plan"]["definition"]["actions"][-1]
        intent = spec.intent_for(step, action, binding["plan"], outputs, proved)
        oid = new_id("op")
        c.execute(insert(operations).values(id=oid, run_id=rid, call_id=step["step_id"],
            fingerprint=fingerprint(intent), tool_ref=spec.SAVE, status="OUTCOME_UNKNOWN"))
        c.execute(insert(operation_intents).values(operation_id=oid, request=intent))
    before = all_rows(data[0]); errors = []
    for _ in range(2):
        with pytest.raises(DomainError) as exc:
            spec.advance(worker, claimed)
        errors.append(exc.value.code)
    after = all_rows(data[0])
    record("unknown-save", errors=errors, database_unchanged=before == after,
        before_sha256=digest(before), after_sha256=digest(after))
    assert errors == ["OUTCOME_UNKNOWN", "OUTCOME_UNKNOWN"] and after == before


def private_rules(run_ids, resource_ids, card_ids, app_ids):
    rules = pa_rules(run_ids, resource_ids, card_ids)
    rules["app_drafts"] = dict(key="id", rows=set(app_ids), private={"candidate"}, paths={"candidate": {
        ("namespace",), ("spec_binding", "kind"), ("pa_binding", "kind"),
        ("task_proof", "proof", "kind"), ("manifest", "data_bindings", 0, "resource_ref")}})
    rules["task_extractions"] = dict(key="app_id", rows=set(app_ids), private={"snapshot"},
        paths={"snapshot": {("kind",)}})
    return rules


def calibrated(store, rules, aid):
    barrier = IdentifierPrivateBarrier(store, rules)
    barrier.__enter__()
    with store.engine.connect() as c:
        resource = c.execute(select(app_drafts.c.candidate["manifest"]["data_bindings"][0]["resource_ref"].as_string())
            .where(app_drafts.c.id == aid)).scalar_one()
        assert resource.startswith("res_")
    assert barrier.identifier_evaluated and not barrier.blocked and not barrier.private_evaluated
    with pytest.raises(DatabaseError), store.engine.connect() as c:
        c.execute(text("SELECT d.candidate FROM app_drafts AS d WHERE d.id IN (:aid)"), {"aid": aid}).all()
    assert any(f.get("table") == "app_drafts" for f in barrier.private_evaluated)
    calibration = {"blocked": list(barrier.blocked), "private_cells": list(barrier.private_evaluated),
        "identifier_projections": list(barrier.identifier_evaluated)}
    barrier.blocked.clear();barrier.private_evaluated.clear();barrier.identifier_evaluated.clear();barrier.statements.clear()
    return barrier, calibration


@pytest.mark.parametrize("remove_binding_hint", [False, True])
def test_joint_marker_strip_denies_before_private_candidate_body(env, remove_binding_hint):
    data = support.setup(env)
    origin, aid, _, _ = support.prepared(data)
    target_resource, card = support.material(data[2], data[4], support.COLD)
    options = spec.options(data[0], data[3], data[4], origin, card["id"], Limits(**{k: getattr(data[1], k) for k in Limits.model_fields}))
    body = spec.BindInput(card_id=card["id"], expected_goal_version=card["version"], expected_goal_fingerprint=card["fingerprint"],
        expected_source_hash=options["source_hash"], expected_model_candidate_fingerprint=options["model_candidate_fingerprint"],
        expected_recipe_fingerprint=options["recipe_fingerprint"], name="Independent unseen binding", consent=spec.CONSENT, request_key="independent-target")
    limits = Limits(**{k: getattr(data[1], k) for k in Limits.model_fields})
    bound_app = spec.bind(data[0], data[3], data[4], origin, body, limits)["id"]
    with data[0].tx() as c:
        row = c.execute(select(app_drafts).where(app_drafts.c.id == bound_app)).mappings().one()
        candidate = copy.deepcopy(row["candidate"]);candidate.pop("namespace")
        if remove_binding_hint:candidate["spec_binding"].pop("kind")
        c.execute(update(app_drafts).where(app_drafts.c.id == bound_app).values(candidate=candidate, fingerprint=fingerprint(candidate)))
        task = c.execute(select(task_extractions).where(task_extractions.c.app_id == bound_app)).mappings().one()
        snapshot = copy.deepcopy(task["snapshot"]);snapshot.pop("kind")
        c.execute(update(task_extractions).where(task_extractions.c.app_id == bound_app).values(snapshot=snapshot))
    before = all_rows(data[0])
    barrier, calibration = calibrated(data[0], private_rules([origin], [data[5], target_resource], [data[6]["id"], card["id"]], [bound_app]), bound_app)
    try:
        with pytest.raises(DomainError) as exc:
            apps.inspect_draft(data[0], data[3], bound_app, limits)
        record("private-strip-" + str(remove_binding_hint), error=exc.value.code, calibration=calibration,
            blocked=barrier.blocked, private_cells=barrier.private_evaluated,
            identifier_projections=barrier.identifier_evaluated, statements=barrier.statements)
        assert not barrier.blocked and not barrier.private_evaluated
    finally:
        barrier.__exit__(None, None, None)
    assert all_rows(data[0]) == before


def test_revoked_original_audit_runtime_denies_before_full_run_or_candidate(env):
    data = support.setup(env)
    origin, aid, _, _ = support.prepared(data)
    with data[0].tx() as c:
        runtime = c.execute(select(projects.c.runtime_id).where(projects.c.id == data[4])).scalar_one()
        c.execute(update(grants).where(grants.c.principal_id == runtime,
            grants.c.resource_id == data[5], grants.c.tool_ref == "resource.read").values(revoked=True, revision=2))
    before = all_rows(data[0]);limits = Limits(**{k: getattr(data[1], k) for k in Limits.model_fields})
    barrier, calibration = calibrated(data[0], private_rules([origin], [data[5]], [data[6]["id"]], [aid]), aid)
    try:
        with pytest.raises(DomainError) as exc:
            apps.inspect_draft(data[0], data[3], aid, limits)
        record("private-audit-revoked", error=exc.value.code, calibration=calibration,
            blocked=barrier.blocked, private_cells=barrier.private_evaluated,
            identifier_projections=barrier.identifier_evaluated, statements=barrier.statements)
        assert not barrier.blocked and not barrier.private_evaluated
    finally:
        barrier.__exit__(None, None, None)
    assert all_rows(data[0]) == before
