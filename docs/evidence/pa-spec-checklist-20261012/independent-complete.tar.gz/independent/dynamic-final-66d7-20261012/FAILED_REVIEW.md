# 独立审查红轮：66d7 / audit bytes

结论 ACTUAL CORE FAIL。HEAD66d7e752493a9632b0fe5bbf70177922d6a70ebd；pa_spec_apps SHA71ec60a83e8ba30db47888fea28ea8d91ff18121ed8baf792dff2235da700310。429 source/tests/pyproject在停止时0diff，own进程0。

extra15实际完整终态13PASS2FAIL/108.70s，session74209 exit1 chunkb578af。两FAIL在SPEC_COMMITTED同事务受控callback向原origin Attempt.parameters或STATE event.data加额外audit字段；advance无异常返回False，真实新artifact/grants/effect/typed与终态都提交，原audit改变也提交。失败不是夹具错误，不声称外部攻击者可绕事务锁。

根因最后verify_job重算新的audit fingerprint，却不与入口b.audit_fingerprint比较。完整语义验证忽略未用audit字段，不能替代全审计byte CAS。后续作者修复与新的2PASS不抹此原FAIL。

selected计划60，但SIGINT实际exit2/chunk6a2ad3，中断前58PASS/398.77s：backend34+qualification22+旧legacy1+UI valid1。binding-lost/late未完成，不签PASS。XML1个无名中断占位不算PASS。已完成合并73唯一=71PASS2FAIL；整体不能称最终完整验收。extra与作者选集没有相同nodeid，语义覆盖可能重叠；selected58与作者选集重叠，不能相加。

UI valid实际22checks、40asset loads/20unique files/2boots，全部载入hash匹配429快照；IPC TestClient+offlineJSDOM，非native，synthetic-only。其他UI未完成。

原日志/XML/SQLite/rawdetails/probe/code快照全部保留。原静态S1-S7不算动态FAIL。真实模型/费用/业务/语义/PG/Windows/native/wheel及旧精确安装窗口均未验证。
