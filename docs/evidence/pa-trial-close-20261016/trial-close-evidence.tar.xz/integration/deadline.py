"""Offline source-backed lower bound; no model, clock mutation, quota or SQL."""
import ast, hashlib, json
from pathlib import Path
R=Path('/workspace/Sim2Act-pa-provider')
def read(n):return (R/'src/sim2act'/n).read_text()
prep=read('natural_trial_preparation.py'); gate=read('natural_live_admission.py'); budget=read('natural_trial_budget.py')
assert 'expires_at=time.time() + 300' in prep
assert '_require(last is None or now - last >= 60, "RATE_LIMITED")' in budget
assert '_require(time.time() < scope.expires_at, "PERMISSION_DENIED")' in budget
cls=next(n for n in ast.parse(gate).body if isinstance(n,ast.ClassDef) and n.name=='TrialCaps')
caps={n.target.id:ast.literal_eval(n.value) for n in cls.body if isinstance(n,ast.AnnAssign) and isinstance(n.value,ast.Constant)}
assert caps['max_requests']==7 and caps['requests_per_minute']==1 and caps['paid_cap']==0
slots=[i*60 for i in range(caps['max_requests'])]
result=dict(kind='OFFLINE_STATIC_LOWER_BOUND_NOT_EXECUTION', source_sha256={n:hashlib.sha256(read(n).encode()).hexdigest() for n in ['natural_trial_preparation.py','natural_live_admission.py','natural_trial_budget.py']}, caps=caps, preparation_ttl_seconds=300, optimistic_first_reservation_delay=0, earliest_reservations_seconds=slots, seventh_earliest_seconds=slots[-1], admission_deadline_strict=True, possible_within_original_deadline=False, original_expiry_extended=False, actual_model_requests=0, scope_of_conclusion='Seven actual reservations cannot fit this preparation contract; does not claim seven slots executed or fee eligibility.', proposed_next_slice='Version review validity separately from execution deadline; freeze both in a new exact consent contract, never extend existing approved expiry.')
Path('/tmp/pa-trial-close-evidence-20261016/DEADLINE.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
