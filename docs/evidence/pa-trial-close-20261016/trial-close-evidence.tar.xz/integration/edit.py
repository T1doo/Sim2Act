from pathlib import Path
r=Path('/workspace/Sim2Act-pa-provider')
p=r/'src/sim2act/natural_live_admission.py';s=p.read_text();s=s.replace('SCOPE, APPROVE, REVOKE, PHASE =', 'CLOSED = VERSION + ".preparation-closed"\nSCOPE, APPROVE, REVOKE, PHASE =');s=s.replace('    eid = entity(contract)\n    require(_keys(c, user, eid, SCOPE)', '    eid = entity(contract)\n    require(not _keys(c, user, eid, CLOSED), "Natural trial preparation irreversibly closed")\n    require(_keys(c, user, eid, SCOPE)');s=s.replace('def approve(store, user, contract: TrialContract, body: ApproveInput):\n    with store.tx() as c:\n        _current', 'def approve(store, user, contract: TrialContract, body: ApproveInput):\n    with store.tx() as c:\n        if user != contract.principal_id:\n            raise DomainError("PERMISSION_DENIED")\n        store.lock_project(c, user, contract.project_id)\n        require(not _keys(c, user, entity(contract), CLOSED),\n                "Natural trial preparation irreversibly closed")\n        _current');p.write_text(s)
p=r/'src/sim2act/natural_trial_preparation.py';s=p.read_text().replace('import time','import math\nimport time',1);s=s.replace('def entity(user, pid, key):','class EndInput(Strict):\n    confirm_end: Literal[True]\n\n\nclass Closure(Strict):\n    principal_id: str\n    project_id: str\n    trial_key: str = Field(pattern=gate.KEY)\n    review_token: str = Field(pattern=gate.HASH)\n    preparation_fingerprint: str = Field(pattern=gate.HASH)\n    closed_at: float\n    request: EndInput\n\n\ndef entity(user, pid, key):');s=s.replace('def _load(store, c, user, pid, key):','def _load(store, c, user, pid, key, *, current=True):');s=s.replace('    gate._current(store, c, user, contract, active=False)\n    return request, contract','    if current:\n        gate._current(store, c, user, contract, active=False)\n    else:\n        # Ending grants no execution authority; only current project/READ/SAVE\n        # authority and the original immutable pair are needed after Goal drift.\n        gate._authorize(store, c, user, contract)\n    return request, contract');s=s.replace('def _receipt(store, c, user, contract):\n    approved', 'def _receipt(store, c, user, contract):\n    closed = _closed(c, user, contract.project_id, contract.trial_key)\n    if closed:\n        return closed\n    approved');insert='''def _closed(c, user, pid, key):
    eid = entity(user, pid, key)
    keys = gate._keys(c, user, eid, gate.CLOSED)
    if not keys:
        return None
    gate.require(keys == {"close"} and gate._keys(c, user, eid, PREPARE) == {"prepare"})
    record = gate._saved(c, user, eid, gate.CLOSED, "close", Closure)
    gate.require(record.principal_id == user and record.project_id == pid
        and record.trial_key == key and math.isfinite(record.closed_at) and record.closed_at > 0)
    # Metadata-only recovery checks original pair fingerprints without TXT/Goal JSON.
    prepared_fps = c.execute(select(delivery_graph_requests.c.request_fingerprint).where(
        delivery_graph_requests.c.principal_id == user,
        delivery_graph_requests.c.app_id == eid,
        delivery_graph_requests.c.kind.in_([PREPARE, PREPARE + "_seal"]),
        delivery_graph_requests.c.request_key == "prepare")).scalars().all()
    gate.require(len(prepared_fps) == 2
        and all(fp == record.preparation_fingerprint for fp in prepared_fps))
    for kind in (gate.SCOPE, gate.APPROVE, gate.PHASE, gate.REVOKE):
        gate.require(not gate._keys(c, user, eid, kind), "Closed preparation has conflicting records")
    return dict(status="PREPARATION_CLOSED_NO_APPROVAL", approved=False,
        review_token=record.review_token, closed_at=record.closed_at, live_allowed=False,
        new_runs=0, new_slots=0, actual_model_requests=0)


@controlled
def end_preparation(store, user, pid, key, body: EndInput):
    with store.tx() as c:
        store.lock_project(c, user, pid)
        # Complete pair + fresh authority, without requiring obsolete Goal head equality.
        request, contract = _load(store, c, user, pid, key, current=False)
        closed = _closed(c, user, pid, key)
        if closed:
            gate.require(closed["review_token"] == fingerprint(contract.model_dump()))
            return closed
        eid = entity(user, pid, key)
        for kind in (gate.SCOPE, gate.APPROVE, gate.PHASE, gate.REVOKE):
            gate.require(not gate._keys(c, user, eid, kind), "Approved preparation must be withdrawn")
        record = Closure(principal_id=user, project_id=pid, trial_key=key,
            review_token=fingerprint(contract.model_dump()),
            preparation_fingerprint=fingerprint(request.model_dump()),
            closed_at=time.time(), request=body)
        gate._save(c, user, eid, gate.CLOSED, "close", record)
        return _closed(c, user, pid, key)


''';s=s.replace('@controlled\ndef prepare(',insert+'@controlled\ndef prepare(');s=s.replace('        approved = gate._keys(c, user, eid, gate.APPROVE)','        closed = _closed(c, user, pid, key)\n        if closed:\n            return closed\n        approved = gate._keys(c, user, eid, gate.APPROVE)');p.write_text(s)
p=r/'src/sim2act/natural_trial_api.py';s=p.read_text();s=s.replace('    @app.post(base + "/consent")','    @app.post(base + "/end-preparation")\n    def end_preparation(pid: str, key: str, body: preparation.EndInput, user=dependency):\n        return preparation.end_preparation(store, user, pid, key, body)\n\n    @app.post(base + "/consent")');p.write_text(s)
p=r/'tests/test_natural_trial_preparation.py';s=p.read_text().replace('gate.REVOKE, gate.REVOKE + "_seal"]','gate.REVOKE, gate.REVOKE + "_seal", gate.CLOSED, gate.CLOSED + "_seal"]');p.write_text(s)
