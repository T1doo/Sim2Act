"""Seal raw completed-case bytes, unpacking xz members into one deduplicating archive."""
import hashlib,io,json,tarfile
from pathlib import Path
B=Path('/tmp/pa-trial-close-evidence-20261016')
O=Path('/workspace/Sim2Act-pa-provider/docs/evidence/pa-trial-close-20261016');O.mkdir(parents=True,exist_ok=True)
archive=O/'trial-close-evidence.tar.xz'; manifest={}; links={}; packed={}
with tarfile.open(archive,'w:xz',preset=6) as out:
    for p in sorted(B.rglob('*')):
        rel=str(p.relative_to(B))
        if p.is_symlink():
            out.add(p,arcname=rel,recursive=False);links[rel]=str(p.readlink())
        elif p.is_file() and p.name.endswith('.tar.xz'):
            packed[rel]=hashlib.sha256(p.read_bytes()).hexdigest()
            with tarfile.open(p,'r:xz') as inner:
                for m in inner:
                    if m.isfile():
                        data=inner.extractfile(m).read();name=rel+'.entries/'+m.name
                        info=tarfile.TarInfo(name);info.size=len(data);out.addfile(info,io.BytesIO(data));manifest[name]=hashlib.sha256(data).hexdigest()
                    elif m.issym():
                        m.name=rel+'.entries/'+m.name;out.addfile(m);links[m.name]=m.linkname
        elif p.is_file():
            out.add(p,arcname=rel,recursive=False);manifest[rel]=hashlib.sha256(p.read_bytes()).hexdigest()
with tarfile.open(archive,'r:xz') as t:
    got=set()
    for m in t:
        got.add(m.name)
        if m.isfile():assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==manifest[m.name]
        elif m.issym():assert m.linkname==links[m.name]
    assert got==set(manifest)|set(links)
record=dict(files=manifest,symlinks=links,original_completed_fixture_xz_sha256=packed,packing='Original raw member bytes preserved; nested per-case compression replaced by one archive. Original pack manifests retained.',archive_bytes=archive.stat().st_size,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),all_retained_bytes_readback=True)
(O/'MANIFEST.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k not in ('files','symlinks','original_completed_fixture_xz_sha256')}))
