import hashlib,json,subprocess,tarfile
from pathlib import Path
R=Path('/workspace/Sim2Act-pa-provider');B=Path('/tmp/pa-trial-close-evidence-20261016')
def git(*a):return subprocess.check_output(['git',*a],cwd=R,text=True).strip()
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def refs(s):return {line.split()[1]:line.split()[0] for line in s.splitlines()}
base='819e5cf6e851e0c648dc3f5e540345e81899bd25';code='437316f57e37106739abd1e7cdf8511c8674403b'
before=refs((B/'remote-before.txt').read_text());after_text=git('ls-remote','--heads','origin');after=refs(after_text)
branch='refs/heads/dev/pa-trial-close-20261016';head=git('rev-parse','HEAD')
assert after[branch]==head
assert all(after.get(k)==v for k,v in before.items())
assert set(after)==set(before)|{branch}
assert after['refs/heads/main']=='6f688e4dd80b5c81d41aecde90e360d3629f9c21'
assert after['refs/heads/dev/f1-foundation']=='bbe07a2a10583001d12a0d00fc2aff92254d80fe'
assert not git('status','--porcelain')
assert git('rev-list','--left-right','--count','HEAD...origin/dev/pa-trial-close-20261016')=='0\t0'
assert not git('diff',code,'HEAD','--','src','tests','pyproject.toml')
subprocess.check_call(['git','merge-base','--is-ancestor',base,head],cwd=R)
frozen=json.loads((B/'final/source-before.json').read_text())
assert all(h(R/n)==v for n,v in frozen.items())
manifest=json.loads((R/'docs/evidence/pa-trial-close-20261016/MANIFEST.json').read_text())
archive=R/'docs/evidence/pa-trial-close-20261016/trial-close-evidence.tar.xz'
assert h(archive)==manifest['archive_sha256']
with tarfile.open(archive,'r:xz') as t:
    for n,digest in manifest['files'].items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==digest
    for n,target in manifest['symlinks'].items():assert t.getmember(n).linkname==target
old=Path('/workspace/Sim2Act')
wip={str(p.relative_to(old)):h(p) for p in [old/'src/sim2act/owner_acceptance.py',old/'docs/F2/TextFourStepOwnerAcceptance20261012.md']}
assert wip['src/sim2act/owner_acceptance.py']=='4b0f680cd5817db49c180ec0cae0613f67bbcc5aac4d3f02965c50bd3d638db7'
assert wip['docs/F2/TextFourStepOwnerAcceptance20261012.md']=='c3ad19200029ab85377fbc352cb7cdc4c9699fdbdbcb10b304c6f26c5dc4ca1e'
result=dict(status='PASS',head=head,tested_code_sha=code,base=base,remote_exact=True,clean=True,uncommitted=0,unpushed=0,old_remote_heads_preserved=len(before),new_remote_heads=len(after),source_matches_frozen=True,evidence_all_bytes_verified=True,old_wip_hashes=wip,remote_before=before,remote_after=after,archive_sha256=manifest['archive_sha256'])
Path('/workspace/pa-trial-close-final-verification-20261016.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('remote_before','remote_after','old_wip_hashes')}))
