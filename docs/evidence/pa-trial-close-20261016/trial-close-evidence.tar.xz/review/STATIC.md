# Initial closure static review

BLOCKED pending UI resolution. No tests, SQL, API calls or runtime observations were performed by the reviewer. Source was read only; this is the initial candidate review and is not final acceptance.

## Concrete finding

Normal successful preparation and a successful full preparation GET return PREPARED_LIVE_BLOCKED with approved=false. prepareTrial and trialRead still assign state=known for this receipt. renderTrialConsent enables trial-new for known, and its onclick admits known/rejected/closed without requiring a closure or verified revocation. This lets new-prepared/new-history abandon an unapproved old key without a persistent CLOSED marker; an old complete contract or already-loaded approval may subsequently succeed. The same known branch also admits approved but unrevoked entries. Restricting only metadata PREPARED_NOT_APPROVED to unapproved does not implement the declared terminal-evidence requirement.

Required resolution: separate full readable unapproved scope (which may still be explicitly approved or ended) from metadata-only unapproved scope (end only); explicit new requires durable CLOSED or verified REVOKED evidence, with a separately justified definitive-rejection case. Normal readable unapproved state must not be forced into the current metadata state that disables consent. Adapt all old new-prepared/history scenarios to explicitly end or revoke first, and retain a test that original complete-contract approval is refused after ending.

## Server checks inspected

gate.approve now obtains the existing project lock and rejects any CLOSED keys before _current, including partial seal histories through _keys. _approved also rejects CLOSED. end_preparation obtains the same lock/transaction, loads a complete preparation only after both fresh READ and SAVE checks, skips Goal-current equality only for this non-authorizing close call, and checks all paired SCOPE/APPROVE/PHASE/REVOKE namespaces empty. Paired closure writes are validated again before commit; failure rolls back. Approval-first refuses close; closure-first refuses an already-loaded old approval through the common gate. The original _current contract is unchanged.

Closed recovery checks closure pair/identity/original key, finite timestamp, preparation request fingerprints and absence of contradictory approval/stage/revocation pairs. This recovery loads closure metadata, not original TXT/Goal JSON; current project ownership remains required. Missing pair halves fail closed. No additional server authorization bypass identified in this static pass. EndInput currently confirms the URL-key termination without a review_token; this is a deliberate API-scope choice to document, not an observed authority-grant bypass because ending only reduces authority and preparation keys are immutable.

New static tests cover old complete DTO denial, a loaded-then-paused consent losing to close, approval-first, missing preparation/closure seals, paired-write rollback, explicit strict confirmation, fresh READ before private pair and metadata recovery after READ revocation. Actual results remain pending. Manual-B UI scenarios update address before consent/withdrawal response loss and reload, then assert only GET B. They do not establish the unresolved normal-unapproved terminal gate above.

Preparation expiry remains300 seconds and RPM1 requires at least360 seconds from first to seventh reservation. This is a separate known execution-feasibility limitation; no approval extension or execution qualification is accepted here.

Inspected core diff SHA256: 2f5b006e6c4ce1df7bfc69d5abe4e675b12fe11429bd1ec70f600782857ec9f8. Initial blocking finding already sent to root before this record was written. Preserve this record and append a separate resolution review after a source fix.
