# UI terminal-evidence resolution review

The concrete blocking finding in STATIC.md is resolved in the currently inspected source. This is static resolution, not execution acceptance. The initial review is preserved byte-for-byte.

Both renderTrialConsent and the explicit trial-new handler now admit only CLOSED, definitive rejected state, or known receipt with approved=true and revoked=true. A normal PREPARED_LIVE_BLOCKED approved=false receipt remains known/readable and may be explicitly consented, but cannot start another preparation. It may end only after the separate end checkbox; both renderer and end handler accept this readable-unapproved state and the metadata-only unapproved state. Metadata-only unapproved still cannot be consented or replaced; sending/UNKNOWN cannot end or new. Closure is accepted only after the server paired CLOSED proof and subsequent original-key GET. A stale known-unapproved view racing approval can submit end, but the common project-locked server protocol rejects close if approval won; it does not unlock new based on the old observed approved=false.

The updated restartPreparation driver explicitly ends an unapproved entry or withdraws an approved entry before trial-new. Held second preparation and late abandoned consent assertions now require the fresh unapproved entry's new button remain disabled; prior scope/key/ack protection assertions remain. Existing Goal-close/lost-close and manual-B lost consent/withdrawal reload cases remain present. No assertion here declares these cases passed; the root's bounded actual test is still authoritative.

Previously inspected server constraints remain unchanged in scope: closure and common approve serialize under project lock; half paired histories refuse; original-current approval checks remain; closing an obsolete Goal requires fresh READ/SAVE and a complete immutable pair; metadata recovery exposes no TXT/Goal body. EndInput binds explicit confirm_end to the URL original key, not a newly added scope token; this termination-only interface does not create authority.

No new blocking issue found in this follow-up static pass. Runtime tests, packaging and remote verification remain pending. No tests, SQL, API or runtime diagnostics ran. Only this new resolution record was written; source and old sealed evidence were untouched.

Current natural-goal.js SHA256: 5e175f548194da35ba2e410bab60b1a120b7d9a2f60127dcc1b4f717ef833f2c.
Current UI driver SHA256: c9f95c36012433fcfb390052699d2be8bce8c523899d372465d3f2d63d4fd159.
