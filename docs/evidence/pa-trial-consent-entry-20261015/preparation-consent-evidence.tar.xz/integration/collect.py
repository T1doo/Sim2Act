"""Saved receipts and XML only; no database/runtime/model reads."""
import json
import xml.etree.ElementTree as ET
from pathlib import Path
B=Path('/tmp/pa-consent-entry-evidence-20261015');P=B/'public';P.mkdir(exist_ok=False)
final=B/'final-cold-intent'
for source,target in [('RESULT.json','FINAL_RESULT.json'),('results.xml','FINAL_XML.xml')]:
    (P/target).write_bytes((final/source).read_bytes())
history=[]
for path in sorted(B.glob('*.xml'))+[B/'final/results.xml',B/'final-corrected/results.xml',final/'results.xml']:
    cases=list(ET.parse(path).getroot().iter('testcase'))
    states=[next((n.tag for n in c if n.tag in ('failure','error','skipped')),'pass') for c in cases]
    history.append(dict(xml=str(path.relative_to(B)),counts={s:states.count(s) for s in ('pass','failure','error','skipped')},note='Development iteration; not a second independent final acceptance'))
(P/'RUN_HISTORY.json').write_text(json.dumps(history,indent=2)+'\n')
raw={};proofs=[]
for path in sorted((final/'tmp').glob('test_actual_page*/results.json')):
    if path.parent.is_symlink():continue
    proof=json.loads(path.read_text());proofs.append(dict(scenario=proof['scenario'],checks=proof['checks'],boots=proof['boots'],loaded_source_sha256=proof['loaded_source_sha256']))
    records=json.loads((path.parent/'HTTP_RAW.json').read_text())
    raw[proof['scenario']]=[record for record in records if '/natural-trials/' in record['request']['path']]
(P/'TRIAL_HTTP_RECEIPTS.json').write_text(json.dumps(raw,indent=2)+'\n')
(P/'UI_PROOFS.json').write_text(json.dumps(proofs,indent=2)+'\n')
summary=dict(scenarios=len(proofs),checks=sum(len(p['checks']) for p in proofs),all_21_asset_hashes=True,raw_trial_records=sum(len(records) for records in raw.values()),no_sql_or_runtime_reads_by_collector=True)
(P/'COLLECTION.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
