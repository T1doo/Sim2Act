"""Frozen offline combination with exact Git/bytes and actual exit/XML receipts."""
import hashlib
import json
import os
import shutil
import subprocess
import time
import xml.etree.ElementTree as ET
from pathlib import Path

R = Path('/workspace/Sim2Act-pa-provider')
B = Path('/tmp/pa-consent-entry-evidence-20261015')
OUT = B / 'final-corrected'
SHA = '22c3f8a65ca42cf9c2dd8c51ec15a6c6dcc95e5d'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=R, text=True).strip()

def h(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def manifest():
    return {str(p.relative_to(R)): h(p) for folder in ('src', 'tests')
            for p in sorted((R / folder).rglob('*'))
            if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts} | {'pyproject.toml': h(R / 'pyproject.toml')}

def write(p, v):
    p.write_text(json.dumps(v, indent=2) + '\n')

assert git('rev-parse', 'HEAD') == SHA and not git('status', '--porcelain')
OUT.mkdir(exist_ok=False)
before = manifest()
write(OUT / 'source-before.json', before)
changed = git('diff', '--name-only', '619cc4bf5caf28841c3d8b9a6f0b9d22021f85d9', SHA).splitlines()
for name in changed:
    target = OUT / 'frozen-source' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(R / name, target)
nodes = ['tests/test_natural_trial_preparation.py', 'tests/test_natural_trial_consent_ui.py',
    'tests/test_natural_trial_api.py',
    *['tests/test_natural_live_admission.py::' + name for name in [
        'test_exact_approval_idempotent_cold_recovery_does_not_extend_expiry',
        'test_revocation_irreversible_and_readable_with_no_new_permission',
        'test_permission_loss_denies_before_private_approval_read',
        'test_pair_loss_does_not_reprepare_or_reapprove']]]
argv = ['/workspace/Sim2Act/.venv/bin/python', '-m', 'pytest', '-q', '-p', 'no:cacheprovider',
    '-p', 'pb_allowed_imports', *nodes, f'--basetemp={OUT}/tmp', f'--junitxml={OUT}/results.xml']
env = {k: os.environ[k] for k in ('PATH', 'LANG', 'LC_ALL', 'TZ') if k in os.environ}
env.update(PYTHONDONTWRITEBYTECODE='1', PYTHONPATH=f'{B}/integration:{R}/src:{R}/tests',
    NODE_PATH='/workspace/node-tools/node_modules', PB_IMPORT_RECEIPT=str(OUT / 'IMPORT_POLICY.json'))
write(OUT / 'COMMAND.json', dict(argv=argv, tested_sha=SHA, timeout=600,
    no_inherited_database_url=True, allowed_inprocess_http=True, native_browser=False,
    harness_sha256=h(Path(__file__)), import_guard_sha256=h(B / 'integration/pb_allowed_imports.py')))
started = time.time()
with (OUT / 'stdout.log').open('w') as so, (OUT / 'stderr.log').open('w') as se:
    process = subprocess.Popen(argv, cwd=R, env=env, stdout=so, stderr=se)
    write(OUT / 'START.json', dict(pid=process.pid, started=started))
    timed_out = False
    try:
        code = process.wait(timeout=600)
    except subprocess.TimeoutExpired:
        timed_out = True
        process.kill()
        code = process.wait()
finished = time.time()
write(OUT / 'PROCESS_EXIT.json', dict(returncode=code, timed_out=timed_out, finished=finished))
after = manifest()
write(OUT / 'source-after.json', after)
cases = []
for c in ET.parse(OUT / 'results.xml').getroot().iter('testcase'):
    cases.append(dict(id=c.get('classname') + '::' + c.get('name'),
        status=next((n.tag for n in c if n.tag in ('failure', 'error', 'skipped')), 'pass'), time=c.get('time')))
result = dict(tested_sha=SHA, returncode=code, timed_out=timed_out, elapsed=finished-started,
    counts={s: sum(c['status'] == s for c in cases) for s in ('pass', 'failure', 'error', 'skipped')},
    cases=cases, source_files=len(before), source_unchanged=before == after,
    head_unchanged=git('rev-parse', 'HEAD') == SHA, tree_clean=not git('status', '--porcelain'),
    xml_sha256=h(OUT / 'results.xml'))
write(OUT / 'RESULT.json', result)
print(json.dumps(result), flush=True)
