"""Seal retained raw fixtures, receipts, failures and reviews without altering B."""
import hashlib
import json
import tarfile
from pathlib import Path

B = Path('/tmp/pa-consent-entry-evidence-20261015')
OUT = Path('/workspace/Sim2Act-pa-provider/docs/evidence/pa-trial-consent-entry-20261015')
OUT.mkdir(parents=True, exist_ok=False)
def h(p): return hashlib.sha256(p.read_bytes()).hexdigest()
files = sorted(p for p in B.rglob('*') if p.is_file() and not p.is_symlink())
links = {str(p.relative_to(B)): str(p.readlink()) for p in B.rglob('*') if p.is_symlink()}
manifest = {str(p.relative_to(B)): dict(bytes=p.stat().st_size,sha256=h(p)) for p in files}
(OUT/'MANIFEST.json').write_text(json.dumps(dict(files=manifest,symlinks=links),indent=2)+'\n')
archive = OUT/'preparation-consent-evidence.tar.xz'
with tarfile.open(archive,'w:xz',preset=9) as tar:
    for p in files: tar.add(p,arcname=str(p.relative_to(B)),recursive=False)
    for name in links: tar.add(B/name,arcname=name,recursive=False)
with tarfile.open(archive,'r:xz') as tar:
    assert len(tar.getmembers()) == len(manifest)+len(links)
    for m in tar.getmembers():
        if m.issym(): assert links[m.name] == m.linkname
        else:
            assert m.isfile() and m.name in manifest
            data=tar.extractfile(m).read();v=manifest[m.name]
            assert len(data)==v['bytes'] and hashlib.sha256(data).hexdigest()==v['sha256']==h(B/m.name)
assert set(manifest)=={str(p.relative_to(B)) for p in B.rglob('*') if p.is_file() and not p.is_symlink()}
receipt=dict(file=archive.name,bytes=archive.stat().st_size,sha256=h(archive),files=len(manifest),symlinks=len(links),all_readback=True,
    scope='PREPARATION_CONSENT_ONLY',actual_pa_pb='NOT_ACCEPTED',tested_sha='9a5f1e43772454b7ec933106b132afc539e1eb04')
(OUT/'ARCHIVE.json').write_text(json.dumps(receipt,indent=2)+'\n')
(OUT/'public').mkdir()
for p in sorted((B/'public').iterdir()):
    if p.is_file(): (OUT/'public'/p.name).write_bytes(p.read_bytes())
print(json.dumps(receipt),flush=True)
