# P-A 准备与同意入口静态独审

基线619cc4bf5caf28841c3d8b9a6f0b9d22021f85d9；根代理是唯一代码写入者。审查现有未提交实现与新文件，并读取设计docs/sources/V5/平台产品设计.md的P-A路径111–115行。本审查不运行测试、SQL、API或浏览器，不改源码/旧证据。当前结论：两项已修复，另有一项导航悬挂响应恢复缺口待收口；不赋予最终验收。

## 已发现并确认修复

1. 重复准备先读私有body。初版prepare用graph.lookup作存在性检测，而lookup SELECT整行含完整冻结材料/Goal；在_load的资源授权前发生。最新实现改为只投影request_key检测PREPARE/其seal是否存在，再进入_load先授权资源ID后pair读取，解除该次序问题。根已补重复POST撤权与单边seal缺失三例，检查没有snapshot整列读取；这里仅静态审查其断言，不声称实际PASS。初次改c.id不适用于复合主键，根改用真实request_key，失败历史由根保留。

2. HTTP400 OUTCOME_UNKNOWN被误作确定拒绝。初版prepareTrial按4xx统一rejected，可能允许另建key。最新显式排除应用码OUTCOME_UNKNOWN，保留unknown并锁定new/consent。新增unknown400用真实server准备后删除主记录只留seal，页面同seeded-key POST得到实际API400并要求仅GET恢复。该fixture注入是真实已有记录缺损，不是假造成功回执；本审查不执行它。

根同时修复已观察导航后原key丢失；clear恢复当前身份/项目key，冷页只取URL原key。准备后Goal选择框禁用，显式new后才改；refresh清旧scope与两ack，避免receipt置空仍展示旧TXT。

## 当前待修复：POST悬挂时导航回来无法读取原key

clearTrialConsent仅把known变unknown，sending保持不变。若POST已提交而响应悬挂，离开/返回页后entry仍sending；recover按钮disabled且recoverTrial直接return。原key虽显示，也不能GET恢复，只能等旧响应或整页reload。当前late-navigation测试先release旧响应再返回，未覆盖这一具体时序。

建议视图失效时把发送中的操作转unknown，保持原key、禁止new/重发，并用每操作generation/token防止旧POST迟到覆盖已成功的当前GET恢复结果。覆盖顺序应是持有旧响应→离开→返回→原key GET→最后release旧响应；恢复后的receipt/ack/控制不能被迟到结果改写。这属于本次未知/导航迟到入口合同，不需要改执行器、lease或发送逻辑。此项解决前尚有阻断。

## 其余有限合同与安全次序

服务器从两张不同完整Goal和当前授权单TXT构造原TrialContract/caps，材料字节/行界、Goal/resource fingerprint、身份/项目/runtime、软件/授权fingerprint、阶段key和初始300秒到期均冻结；客户端只提交Goal ID/version和明确同意，未提交内部contract/LIVE/caps。UI完整展示两份材料、八个Goal字段、身份/模型/端点/未验证额度、七槽及全部原预算、期限和LIVE关闭。

prepare同事务项目锁、授权投影先于私有JSON、后续_current重验；remember两份写入与后验失败共事务回滚。新HTTP回归注入两份写入后异常并断言无prepare记录。approve虽_load后调用原gate.approve的另一个事务，但后者重新_current，先lock_project和READ/SAVE再验证当前Goal/材料/权限/软件/期限；没有把前事务proof复用为提交权。常规Goal/资源修改也使用项目锁。这里只证明代码路径；PG/真实竞态未由审查者执行。

status和withdraw仅读取同owner/project原key的批准元数据及scope指纹，不重新打开TXT/Goal；撤READ后完整preparation拒绝，metadata-only状态仍允许明确不可逆撤回。原revoke提取helper保持原SCOPE/APPROVE配对及精确fp/revoke幂等条件；包装函数保留user==contract.principal检查。未增加Run、attempt、ledger槽或发送器入口，LIVE仍无注册权。

失去prepare/consent/withdraw回执时只读原key恢复，不自动重发；确认框在恢复/导航/选择变化后清空；UI延期不改变冻结expires_at，服务器仍最终拒绝到期批准。实际页面通过完整HTML/CSS/脚本与真实HTTP IPC加载，测试来源hash与HTML脚本集合比对；JSDOM不等于原生浏览器验收。测试business快照范围是Run/Attempt/非同意账目，不是声称外部注入的Goal/资源/权限也没有变化。

测试证据与此前失败由根独立保存：本审查不把根提供的PASS/FAIL数量重新当成已独立执行结果；后续需对冻结SHA/HTTP/UI及旧接口实际结果单独独审。旧产品NOT_ACCEPTED/历史故障不因本入口准备同意成功而解除。

## 本次读取快照哈希

- `src/sim2act/natural_trial_preparation.py`: `bd764781d5958efa3bea74e55d0265ed3f4a12d18f1b405bdfbdb39b39ef00ed`
- `src/sim2act/natural_live_admission.py`: `47aeb012c977a59920142ab17a33fae3589699e22ab39008a4b79c38e3d991c9`
- `src/sim2act/natural_trial_api.py`: `d11afd8da73f1d7659c9eab51f26f39d02012cef6ac54ed0cff1769e08c57e73`
- `src/sim2act/web/natural-goal.js`: `759009fb08718c244e3ebeb7ddf97608280bf15027d34ed69a6e59f4c5457f9f`
- `src/sim2act/web/app.js`: `02a59901a1384e27de254d2b6585ba545b068416e0c77180a1d53b03ffab8a52`
- `src/sim2act/web/index.html`: `640319f9ac2342984c86c84b202745ee0d1d9a498102fcae73937b24c2e2862c`
- `tests/test_natural_trial_preparation.py`: `3c46a1c2628466a1e9773cd73227da1b920f5d06cc8079fc3d9b41aea82125da`
- `tests/test_natural_trial_consent_ui.py`: `a5928516def550c60f05aba8977515b719851d113b0fe56cf98dfb3bf63e1f17`
- `tests/natural_trial_consent_ui.cjs`: `6cdd64c0cf8d05b42f881ac9834d58d21201640eccfdc9dde1d4f879d5ee048c`
