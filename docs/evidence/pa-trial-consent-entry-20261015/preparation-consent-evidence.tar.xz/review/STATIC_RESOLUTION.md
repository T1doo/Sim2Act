# Sending 导航恢复静态收口复审

结论：原STATIC.md的最后导航阻断已在当前实现收口，旧发现保留不改。当前未见剩余阻断性静态问题；冻结SHA完整组合/旧接口实际验收仍待后续独审。本轮没有执行测试、Worker、SQL或API，也没有修改源码/旧证据。

clearTrialConsent现在对所有已有entry递增operation、清receipt，并把known和sending都转unknown；当前身份/项目原key保留。导航返回时原key恢复按钮可用，new/重发仍锁定，不再依赖旧POST返回。refresh先调用clear使早期读取/突变失效。

prepare/read/mutate各自捕获该entry的操作代数，await后及catch写状态前检查operation；trialRead还核ctx身份/项目/连接/页面代数，并在失效后停止metadata fallback，不在新身份下补旧请求。旧POST即使迟到，operation已落后于新GET，因此不能清除已恢复receipt或覆盖state/message。旧finally的trialCurrent(ctx)检查也因导航代数失效而跳过，不能改新页确认框。原确认/撤回均仍需明确手势，未知只能GET原key，不会因此增加第二POST。

专项driver现在实际执行持有已提交consent响应→离开→返回→GET原key恢复且验证持久批准→最后释放旧POST→检查scope/status保持不变，随后才继续原撤回流程。与先释放再返回的旧次序不同，覆盖了本次明确时序。只读核到该专项XML有一个通过case；log含10deselected，此选择本身不代表其他页面场景通过。读取到结果status PASS及两条关键时序断言，所加载每份真实页面资产hash与当前文件一致。原STATIC.md指出的提前私有读取与400未知分类修复仍保留，不被本专项替代。

专项XML SHA256：`a783f337999528fcb8b92661f8886d55c8e1e861ccb661118bf44a194efce2b2`。
当前natural-goal.js SHA256：`759009fb08718c244e3ebeb7ddf97608280bf15027d34ed69a6e59f4c5457f9f`。
当前页面driver SHA256：`6cdd64c0cf8d05b42f881ac9834d58d21201640eccfdc9dde1d4f879d5ee048c`。

只读专项证据检查：
- one_XML_pass: True
- proof_actual_late_scenario_PASS: True
- critical_order_assertions_present: True
- loaded_assets_exact_current: True

实际HTTP试验回执（只读现有JSON，不调用API）：
- ('POST', '/api/projects/proj_8052030ceb2b428eb682825c015750b2/natural-trials/598eb7ac-b445-45bf-8426-ab39dc5fff43/preparation', 200)
- ('POST', '/api/projects/proj_8052030ceb2b428eb682825c015750b2/natural-trials/598eb7ac-b445-45bf-8426-ab39dc5fff43/consent', 200)
- ('GET', '/api/projects/proj_8052030ceb2b428eb682825c015750b2/natural-trials/598eb7ac-b445-45bf-8426-ab39dc5fff43/preparation', 200)
- ('POST', '/api/projects/proj_8052030ceb2b428eb682825c015750b2/natural-trials/598eb7ac-b445-45bf-8426-ab39dc5fff43/withdrawal', 200)
- ('GET', '/api/projects/proj_8052030ceb2b428eb682825c015750b2/natural-trials/598eb7ac-b445-45bf-8426-ab39dc5fff43/preparation', 200)

本专项仅验证这一具体导航/迟到恢复修复，不能当成完整P-A/P-B、真实模型、PG/Windows或历史Cold稳定性验收。旧NOT_ACCEPTED/既有失败不被入口成功解除。
