import hashlib,json,tarfile
from pathlib import Path
B=Path('/tmp/pa-trial-deadlines-evidence-20261016')
found=[]
for p in (B/'final/main/packed').glob('*.tar.xz'):
    with tarfile.open(p,'r:xz') as t:
        for m in t:
            if m.name.endswith('/ACTUAL_V2_SEVEN_SLOTS.json'):
                found.append(json.load(t.extractfile(m)))
assert len(found)==1
r=found[0];c=r['contract'];slots=r['accounting']['ledger']['slots'];wires=r['wire']
assert len(slots)==len(wires)==7 and all(s['accepted'] for s in slots)
assert all(b['reserved_at']-a['reserved_at']>=60 for a,b in zip(slots,slots[1:]))
assert all(s['reserved_at']<c['execution_expires_at'] for s in slots)
assert all(w['at']<w['run_created_at']+300 for w in wires)
assert any(w['stage']=='source' and w['at']>=r['source']['authority']['stage_approval_expires_at'] for w in wires)
counts={stage:sum(s['reservation']['stage']==stage for s in slots) for stage in ('generate','source','cold')}
assert counts==dict(generate=3,source=2,cold=2)
assert c['review_expires_at']==c['prepared_at']+300 and c['execution_expires_at']==c['prepared_at']+3600==c['expires_at']
assert c['caps']['requests_per_minute']==1 and c['caps']['paid_cap']==0 and c['caps']['run_seconds']<=300
result=dict(status='PASS',kind=r['kind'],contract_fingerprint=r['source']['authority']['contract_fingerprint'],
    prepared_at=c['prepared_at'],review_expires_at=c['review_expires_at'],execution_expires_at=c['execution_expires_at'],
    reserved_offsets=[round(s['reserved_at']-c['prepared_at'],6) for s in slots],stage_counts=counts,
    source_approval_deadline=r['source']['authority']['stage_approval_expires_at'],cold_approval_deadline=r['cold']['authority']['stage_approval_expires_at'],
    original_runtime_renewals=sum(h['original_runtime_renew'] for event in r['clock_events'] for h in event['renewals']),
    source_executes_after_handoff_deadline_but_before_original_run_deadline=True,reviewed_execution_deadline_never_extended=True,
    actual_provider_requests=0,synthetic_mock_transport_requests=7,production_sender_qualification='NOT RUN',real_wall_clock_performance='NOT QUALIFIED')
(B/'DEADLINES_SUMMARY.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
