import json,tarfile,hashlib
from pathlib import Path
B=Path('/tmp/pa-trial-deadlines-evidence-20261016')
rows=[]
for p in sorted((B/'final/main/packed').glob('*.tar.xz')):
    with tarfile.open(p,'r:xz') as t:
        matches=[m for m in t if m.isfile() and m.name.endswith('/results.json')]
        for m in matches:
            v=json.load(t.extractfile(m)); rows.append(dict(scenario=v['scenario'],status=v['status'],checks=len(v['checks']),boots=v['boots'],assets=len(v['static_resource_loads']),natural_trial_http=sum('/natural-trials/' in x['path'] for x in v['requests']),source_hashes=v['loaded_source_sha256']))
assert len(rows)==20 and all(r['status']=='PASS' for r in rows)
result=dict(scenarios=rows,total_checks=sum(r['checks'] for r in rows),boots=sum(r['boots'] for r in rows),asset_loads=sum(r['assets'] for r in rows),natural_trial_http=sum(r['natural_trial_http'] for r in rows),native_browser='NOT RUN',actual_model_requests=0)
(B/'UI_SUMMARY.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='scenarios'}))
