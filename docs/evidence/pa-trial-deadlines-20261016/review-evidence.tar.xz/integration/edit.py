from pathlib import Path
R=Path('/workspace/Sim2Act-pa-provider')
p=R/'src/sim2act/natural_live_admission.py';s=p.read_text();at=s.index('\n\nclass PBTrialContract');s=s[:at]+'''

class TrialContractV2(TrialContract):
    """New exact consent only. V1 is never inferred, migrated or extended."""

    namespace: Literal["natural-live-trial.v2"] = "natural-live-trial.v2"
    prepared_at: float = Field(gt=0, allow_inf_nan=False)
    review_expires_at: float = Field(gt=0, allow_inf_nan=False)
    execution_expires_at: float = Field(gt=0, allow_inf_nan=False)
    # Previous Run acceptance -> next explicit stage approval, including prior
    # Run (<=300s), queueing and human handoff. Not a completion-time guarantee.
    stage_handoff_seconds: Literal[900] = 900

    @model_validator(mode="after")
    def deadlines(self):
        require(self.review_expires_at == self.prepared_at + 300
            and self.execution_expires_at == self.prepared_at + 3600
            and self.expires_at == self.execution_expires_at,
            "Exact V2 review and execution deadlines changed")
        return self
''' +s[at:];at=s.index('\n\nclass ApproveInput');s=s[:at]+'''

def contract_model(value):
    if value.get("namespace") == "natural-live-trial.v2":
        return TrialContractV2
    require(value.get("namespace", VERSION) == VERSION, "Unknown trial contract version")
    return PBTrialContract if value.get("path") == "P-B" else TrialContract


def parse_contract(value):
    return contract_model(value).model_validate(value)


def _review_window(contract):
    if isinstance(contract, TrialContractV2):
        require(contract.prepared_at <= time.time() < contract.review_expires_at,
                "Original review deadline expired or not yet active")
''' +s[at:];at=s.index('\n\nclass StageApproveInput');s=s[:at]+'''

class StageAuthorityV2(StageAuthority):
    predecessor_run_id: str = Field(pattern=r"^run_[a-f0-9]{32}$")
    predecessor_created_at: float = Field(gt=0, allow_inf_nan=False)
    stage_approval_expires_at: float = Field(gt=0, allow_inf_nan=False)


def _stage_deadlines(c, user, contract, stage, generation_run_id):
    if not isinstance(contract, TrialContractV2):
        return {}
    if stage == "source":
        predecessor_id, runtime = generation_run_id, contract.runtime_id
        # Generation is an accepted candidate, still semantically PARTIAL.
        statuses = {"SUCCEEDED", "PARTIAL"}
    else:
        require(stage == "cold")
        require(_keys(c, user, entity(contract), PHASE) <= {"source", "cold"})
        source = _saved(c, user, entity(contract), PHASE, "source", StageApproveInput)
        require(isinstance(source.authority, StageAuthorityV2)
            and source.authority.stage == "source"
            and source.authority.contract_fingerprint == fingerprint(contract.model_dump())
            and source.authority.generation_run_id == generation_run_id
            and source.expected_authority_fingerprint == fingerprint(source.authority.model_dump()))
        predecessor_id, runtime = source.authority.run_id, source.authority.runtime_id
        statuses = {"SUCCEEDED"}
    # Only scalar timing/identity metadata; no private result/context body.
    previous = c.execute(select(runs.c.id, runs.c.created_at, runs.c.principal_id,
        runs.c.project_id, runs.c.runtime_id, runs.c.status, runs.c.cancel_intent).where(
        runs.c.id == predecessor_id)).mappings().first()
    require(previous is not None and previous["principal_id"] == user
        and previous["project_id"] == contract.project_id and previous["runtime_id"] == runtime
        and previous["status"] in statuses and previous["cancel_intent"] is False
        and type(previous["created_at"]) in (int, float) and math.isfinite(previous["created_at"])
        and contract.prepared_at <= previous["created_at"] <= time.time(),
        "Exact previous stage timing or identity changed")
    return dict(predecessor_run_id=predecessor_id,
        predecessor_created_at=previous["created_at"],
        stage_approval_expires_at=min(previous["created_at"] + contract.stage_handoff_seconds,
                                      contract.execution_expires_at))


def _stage_review_window(authority):
    if isinstance(authority, StageAuthorityV2):
        require(authority.predecessor_created_at <= time.time() < authority.stage_approval_expires_at,
                "Original stage handoff deadline expired")
''' +s[at:];s=s.replace('    authority: StageAuthority\n','    authority: StageAuthorityV2 | StageAuthority\n');s=s.replace('    authority = StageAuthority(contract_fingerprint=', '    timing = _stage_deadlines(c, user, contract, stage, gen_id)\n    authority_model = StageAuthorityV2 if isinstance(contract, TrialContractV2) else StageAuthority\n    authority = authority_model(**timing, contract_fingerprint=');s=s.replace('        authority, _ = _stage_current(store, c, user, contract, stage, run_id)\n        return dict', '        authority, _ = _stage_current(store, c, user, contract, stage, run_id)\n        _stage_review_window(authority)\n        return dict');s=s.replace('        stage = body.authority.stage\n        current, job', '        require(isinstance(body.authority, StageAuthorityV2) == isinstance(contract, TrialContractV2))\n        stage = body.authority.stage\n        current, job');s=s.replace('        require(current == body.authority', '        _stage_review_window(current)\n        require(current == body.authority',1);s=s.replace('        require(fresh == current)\n        return dict(status="EXACT_STAGE', '        require(fresh == current)\n        _stage_review_window(fresh)\n        return dict(status="EXACT_STAGE');s=s.replace('        require(time.time() < contract.expires_at, "Trial approval expired")','        require(time.time() < contract.expires_at, "Trial approval expired")\n        if isinstance(contract, TrialContractV2):\n            require(time.time() >= contract.prepared_at, "Trial not yet active")');s=s.replace('    if active:\n        require(not _keys(c, user, eid, REVOKE)', '    if isinstance(contract, TrialContractV2):\n        require(contract.prepared_at <= approval.approved_at < contract.review_expires_at,\n                "Original approval outside reviewed window")\n    if active:\n        require(not _keys(c, user, eid, REVOKE)');s=s.replace('        _current(store, c, user, contract)\n        fp, eid', '        _current(store, c, user, contract)\n        _review_window(contract)\n        fp, eid');s=s.replace('        return _receipt(accepted)\n\n\ndef _receipt', '        _review_window(contract)\n        return _receipt(accepted)\n\n\ndef _receipt');p.write_text(s)
p=R/'src/sim2act/natural_trial_preparation.py';s=p.read_text().replace('gate.TrialContract.model_validate(value)','gate.parse_contract(value)');s=s.replace('    if approved:\n        approval =', '    if isinstance(contract, gate.TrialContractV2):\n        receipt["review_expired"] = time.time() >= contract.review_expires_at\n    if approved:\n        approval =',1);s=s.replace('        contract = gate.TrialContract(trial_key=key,', '        prepared_at = time.time()\n        contract = gate.TrialContractV2(prepared_at=prepared_at,\n            review_expires_at=prepared_at + 300, execution_expires_at=prepared_at + 3600,\n            trial_key=key,');s=s.replace('expires_at=time.time() + 300)', 'expires_at=prepared_at + 3600)');p.write_text(s)
p=R/'src/sim2act/natural_trial_api.py';s=p.read_text().replace('Contract = gate.PBTrialContract | gate.TrialContract','Contract = gate.TrialContractV2 | gate.PBTrialContract | gate.TrialContract').replace('model = gate.PBTrialContract if value.get("path") == "P-B" else gate.TrialContract', 'model = gate.contract_model(value)');p.write_text(s)
p=R/'src/sim2act/pa_trial_dispatch.py';s=p.read_text().replace('contract: gate.TrialContract | gate.PBTrialContract','contract: gate.TrialContractV2 | gate.TrialContract | gate.PBTrialContract').replace('in (gate.TrialContract, gate.PBTrialContract)', 'in (gate.TrialContractV2, gate.TrialContract, gate.PBTrialContract)');p.write_text(s)
p=R/'src/sim2act/web/natural-goal.js';s=p.read_text().replace('c.contract.expires_at', 'c.contract.expires_at');s=s.replace('function trialValid(r, key) {','const trialReviewDeadline = c => c?.namespace === "natural-live-trial.v2" ? c.review_expires_at : c?.expires_at;\nfunction trialValid(r, key) {');s=s.replace('  return r;\n}\nfunction renderTrialConsent()', '  if (c.namespace === "natural-live-trial.v2" && (!Number.isFinite(c.prepared_at) || c.review_expires_at !== c.prepared_at + 300 || c.execution_expires_at !== c.prepared_at + 3600 || c.expires_at !== c.execution_expires_at || c.stage_handoff_seconds !== 900)) throw Error("未知期限合同");\n  return r;\n}\nfunction renderTrialConsent()');s=s.replace('Date.now() >= r.contract.expires_at * 1000', 'Date.now() >= trialReviewDeadline(r.contract) * 1000');s=s.replace('  const cap = c.caps;','  const cap = c.caps;\n  const deadlines = c.namespace === "natural-live-trial.v2" ? `V2 审阅截止 ${new Date(c.review_expires_at * 1000).toISOString()}；执行截止 ${new Date(c.execution_expires_at * 1000).toISOString()}。均从准备时冻结，恢复、批准、重放不续期。总时窗60分钟含5分钟审阅；每个后继阶段须在前序 Run 受理后15分钟内明确批准（含前序最多300秒、排队及人工交接）。每 Run 的300秒含额度等待、模型延迟和工具工作；人工迟到或剩余时间不足即拒绝。不是七槽完成保证。` : "V1 原单一期限保持，不迁移或续期。";');s=s.replace('P-A 精确准备与同意范围\\n项目', 'P-A 精确准备与同意范围\\n${deadlines}\\n项目');p.write_text(s)
p=R/'tests/test_natural_trial_preparation.py';s=p.read_text().replace('assert read.json()["expired"] is True', 'assert read.json()["review_expired"] is True\n        assert read.json()["expired"] is False');p.write_text(s)
p=R/'tests/test_natural_trial_close.py';s=p.read_text().replace('gate.TrialContract.model_validate(r[\'contract\'])','gate.parse_contract(r[\'contract\'])');p.write_text(s)
