"""Keep full raw evidence externally; commit a lossless selected review bundle.

No prior evidence or frozen B bytes are removed. Outer archive flattens per-case
xz members; their original compressed hashes and all raw member hashes remain.
"""
import hashlib,io,json,tarfile
from pathlib import Path
B=Path('/tmp/pa-trial-deadlines-evidence-20261016')
D=Path('/tmp/pa-trial-deadlines-20261016-delivery');D.mkdir(exist_ok=True)
R=Path('/workspace/Sim2Act-pa-provider/docs/evidence/pa-trial-deadlines-20261016')
def h(data):return hashlib.sha256(data).hexdigest()
files={};original={};selected={};selection_sources={}
def keep(name,data):
    files[name]=h(data)
    # Full raw fixtures and HTTP remain in the complete archive. The review
    # bundle contains original logs/receipts/proofs, not an altered acceptance.
    plain=name.split('/')[-1]
    if name.startswith('review/') or name.startswith('integration/') or plain in {'RESULT.json','PROCESS_EXIT.json','COMMAND.json','IMPORT_POLICY.json','stdout.log','stderr.log','source-before.json','UI_SUMMARY.json','DEADLINES_SUMMARY.json'} or name.endswith('.xml') or ('/case/' in name and plain.endswith('.json') and plain!='HTTP_RAW.json') or (name.endswith('.log') and '/' not in name):
        selected[name]=data
        selection_sources[name]=h(data)
with tarfile.open(D/'complete-evidence.tar.xz','w:xz',preset=6) as out:
    for p in sorted(B.rglob('*')):
        if not p.is_file() or p.is_symlink():continue
        name=str(p.relative_to(B))
        if p.name.endswith('.tar.xz'):
            original[name]=h(p.read_bytes())
            with tarfile.open(p,'r:xz') as inner:
                for m in inner:
                    if not m.isfile():continue
                    data=inner.extractfile(m).read();n=name+'.entries/'+m.name
                    info=tarfile.TarInfo(n);info.size=len(data);out.addfile(info,io.BytesIO(data));keep(n,data)
        else:
            data=p.read_bytes();out.add(p,arcname=name,recursive=False);keep(name,data)
full=D/'complete-evidence.tar.xz'
with tarfile.open(full,'r:xz') as t:
    assert {m.name for m in t}==set(files)
    for name,digest in files.items():assert h(t.extractfile(name).read())==digest
record=dict(files=files,original_completed_fixture_xz_sha256=original,archive_bytes=full.stat().st_size,archive_sha256=h(full.read_bytes()),all_raw_bytes_verified=True)
manifest=json.dumps(record,indent=2).encode()+b'\n';(D/'MANIFEST.json').write_bytes(manifest)
R.mkdir(parents=True,exist_ok=True)
public=R/'review-evidence.tar.xz'
with tarfile.open(public,'w:xz',preset=9) as t:
    for name,data in sorted(selected.items()):
        info=tarfile.TarInfo(name);info.size=len(data);t.addfile(info,io.BytesIO(data))
with tarfile.open(public,'r:xz') as t:
    assert {m.name for m in t}==set(selected)
    for name,data in selected.items():assert t.extractfile(name).read()==data
summary=dict(full_archive_path=str(full),full_archive_bytes=full.stat().st_size,full_archive_sha256=record['archive_sha256'],full_manifest_path=str(D/'MANIFEST.json'),full_manifest_sha256=h(manifest),full_raw_files=len(files),original_fixture_archives=len(original),review_archive_bytes=public.stat().st_size,review_archive_sha256=h(public.read_bytes()),review_files=len(selected),all_bytes_readback=True,selection='Original selected JSON receipts/proofs, logs, XML, review and harness files. Complete raw SQLite and full HTTP are retained in the separate complete archive; no raw B bytes deleted.',limited_workspace_bytes_reason='Workspace had 308 KiB free after code commit; full raw archive stays in /tmp and is linked by exact hash.')
(R/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
