"""Reopen the same pre-change V1 DB bytes; no migration, credentials or transport."""
import hashlib,json,tarfile
from pathlib import Path
from sqlalchemy import select
from sim2act import natural_live_admission as gate
from sim2act import natural_trial_budget as budget
from sim2act.db import Store,delivery_graph_requests
B=Path('/tmp/pa-trial-deadlines-evidence-20261016'); out=B/'v1-after';out.mkdir(exist_ok=True)
archive=next((B/'v1-before-packed').glob('*.tar.xz'))
with tarfile.open(archive,'r:xz') as t:
    raw=t.extractfile('case/fixture.db').read(); evidence=json.load(t.extractfile('case/V1_ORIGINAL.json'))
p=out/'fixture.db';p.write_bytes(raw);before_hash=hashlib.sha256(raw).hexdigest()
c=gate.TrialContract.model_validate_json(evidence['contract']);user=c.principal_id
store=Store('sqlite:///'+str(p),test_only=True)
with store.tx() as conn:
    rows=[dict(r) for r in conn.execute(select(delivery_graph_requests).order_by(delivery_graph_requests.c.app_id,delivery_graph_requests.c.kind,delivery_graph_requests.c.request_key)).mappings()]
assert rows==evidence['records']
recovered=gate.recover(store,user,c,'exact-approval')
accounting=budget.read(store,user,budget.scope_for(c,'exact-approval'))
assert recovered['approval']['expires_at']==c.expires_at and accounting['reserved_requests']==1
assert accounting['scope']['expires_at']==c.expires_at
with store.tx() as conn:
    after=[dict(r) for r in conn.execute(select(delivery_graph_requests).order_by(delivery_graph_requests.c.app_id,delivery_graph_requests.c.kind,delivery_graph_requests.c.request_key)).mappings()]
store.engine.dispose()
assert rows==after and p.read_bytes()==raw
result=dict(status='PASS',v1_contract_unchanged=c.model_dump_json()==evidence['contract'],same_pre_change_database_sha256=before_hash,after_database_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),original_pairs_and_unknown_nonrefundable_slot_unchanged=True,rows=len(rows),original_expires_at=c.expires_at,review_deadline_added=False,new_model_requests=0)
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
