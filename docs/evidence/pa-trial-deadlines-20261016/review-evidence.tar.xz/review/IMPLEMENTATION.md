# V2 deadline implementation static review

No blocking defect identified in this source pass. This does not accept the running test batch or claim qualification/execution acceptance. PROTOCOL.md remains preserved. The reviewer ran no tests, SQL, API, browser, real model or product-runtime code.

Original V1 TrialContract, PBTrialContract, Approval and StageAuthority class ASTs are identical to base a8d30e253c11ed84180328c623efeb2af580e352. New V2 subclass strictly requires finite times with review=prepared+300, execution=prepared+3600, expires_at=execution and handoff900. The inherited original contract expiry validator still runs; no old DTO or saved record is inferred/upgraded. New preparation emits V2 only for new keys; existing-key loads select the recorded namespace. Scope/approval/budget namespace and ledger layout remain original; V2's complete contract fingerprint distinguishes its authority.

Explicit API union and original-contract parser, preparation parser, StageApproveInput V2 authority union and PATrialBinding exact accepted classes retain V2 fields. Strict extras prevent accepting a partial V2 authority as V1. PB remains exact V1. Common _saved uses type(contract) for original scope matching. No V1-annotated persisted nested contract truncation found in inspected paths.

Common approve obtains project lock, retains CLOSED denial/current authority/software/Goal checks, checks review window before writes and after writes even for duplicate approval. _approved checks the original approval timestamp within original V2 review interval regardless of active flag; current execution time is required only when active. Historical GET does not renew. Existing budget/permit/fee/run/lease checks use the validated expires_at execution alias, and per-Run300/paid0/RPM1/lease30 values are not increased.

_stage_deadlines runs after complete bound/model_source and generation-accounting checks. It only derives predecessor metadata; handoff clock enforcement appears only in stage_review and approve_stage pre/post-write, including duplicates. Thus admission can rebuild a timely saved authority after handoff cutoff without prematurely cancelling its own Run budget. Source timing uses this trial's accepted generation ID/runtime, permits PARTIAL accepted-candidate state supported by existing model_source proof, and does not claim semantic task success. Cold timing uses this trial's paired PHASE.source authority with exact contract/generation fingerprints and requires that specific Source Run SUCCEEDED. Scalar identity/runtime/status/cancellation/finite created_at checks precede the derived min(created+900,execution) authority fields. V1/V2 authority mix is refused before phase write.

Defense-in-depth suggestion (not an observed bypass): when reading source phase for cold, explicitly compare source.approval_key to the original stored approval request key and its predecessor_run_id to generation ID. Normal approve_stage writes already establish these relationships; explicit read-side checks would avoid relying on that historical invariant for a corrupted paired record. Root was informed.

New static test coverage includes strict review boundary/duplicate rejection with unchanged historical GET; V1 byte/ledger preservation; alias/finite/literal rejection; before/after-write deadline rollback; explicit API/dispatch parse roundtrip. The seven-slot test uses existing mock Worker and a test adapter that calls real admission/reservation/settlement, fixed clock and real heartbeat bounded to original30 lease and Run+300. This is synthetic transport/accounting evidence, not actual production PATrialBinding sender wiring or real provider validation. Its pending result must be read as actual before acceptance. A source phase approved at generation acceptance+880 can execute after+900 under its own Run deadline; cold uses succeeded approved source; exact handoff/execution cutoffs reject and GET remains read-only. No lease/guard replacement appears in this test.

The earlier V1 seven-slot impossibility is not retroactively changed. V2 gives a larger feasible window only for a new exact consent;3600 seconds does not guarantee completion, fee entitlement or real execution. Account/qualification/LIVE gates are not repinned or opened by this slice.

Inspected source SHA256 values:

- src/sim2act/natural_live_admission.py: `b160ce2c56c6f2ce1e584f5427a8a8768697b3576ea62f4f71cf51619f09a038`
- src/sim2act/natural_trial_preparation.py: `0ff61fbe12af5e990c0ca75378dc455adc24c2da0559bc16b4d5aac2807cbc16`
- src/sim2act/natural_trial_api.py: `55d051e653238701ca7ecaa2834c8fd08a1c6e18f0c99f5095362213e901a248`
- src/sim2act/pa_trial_dispatch.py: `d4168fc69adb04b1671c27b83e80dac009b5d54eb8001b791bf254594b618eb6`
- src/sim2act/web/natural-goal.js: `1161607fbb9ced0040cf97fa5446457a4cec891ff82b23b6b3c7e1272380b5c6`
