"""Saved files only: preserve actual red, green and full delivered-page receipts."""
import json,tarfile,xml.etree.ElementTree as ET
from pathlib import Path
B=Path('/tmp/pa-trial-new-intent-evidence-20261016');P=B/'public';P.mkdir(exist_ok=False)
for src,dst in [('final/RESULT.json','FINAL_RESULT.json'),('final/results.xml','FINAL_XML.xml'),('red.xml','RED_XML.xml')]:
    (P/dst).write_bytes((B/src).read_bytes())
history=[]
for path in sorted(B.glob('*.xml'))+[B/'final/results.xml']:
    states=[next((n.tag for n in c if n.tag in ('failure','error','skipped')),'pass') for c in ET.parse(path).getroot().iter('testcase')]
    history.append(dict(xml=str(path.relative_to(B)),counts={s:states.count(s) for s in ('pass','failure','error','skipped')}))
(P/'RUN_HISTORY.json').write_text(json.dumps(history,indent=2)+'\n')
red=[]
with tarfile.open(B/'red-fixtures.tar.xz','r:xz') as tar:
    for member in tar.getmembers():
        if member.isfile() and Path(member.name).name=='results.json':
            proof=json.loads(tar.extractfile(member).read());assert proof['status']=='FAIL'
            red.append(dict(member=member.name,proof=proof))
assert len(red)==2
(P/'RED_COMPONENT_PROOFS.json').write_text(json.dumps(red,indent=2)+'\n')
raw={};proofs=[]
for path in sorted((B/'final/tmp').glob('test_actual_page*/results.json')):
    if path.parent.is_symlink():continue
    proof=json.loads(path.read_text());proofs.append(dict(scenario=proof['scenario'],checks=proof['checks'],boots=proof['boots'],loaded_source_sha256=proof['loaded_source_sha256']))
    records=json.loads((path.parent/'HTTP_RAW.json').read_text())
    raw[proof['scenario']]=[record for record in records if '/natural-trials/' in record['request']['path']]
(P/'TRIAL_HTTP_RECEIPTS.json').write_text(json.dumps(raw,indent=2)+'\n')
(P/'UI_PROOFS.json').write_text(json.dumps(proofs,indent=2)+'\n')
summary=dict(scenarios=len(proofs),checks=sum(len(p['checks']) for p in proofs),boots=sum(p['boots'] for p in proofs),raw_trial_records=sum(len(v) for v in raw.values()),red_scenarios=2)
(P/'COLLECTION.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
