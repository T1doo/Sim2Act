"""Lossless packing of exited owned fixture trees; raw log/XML stay unpacked."""
import hashlib,json,shutil,tarfile
from pathlib import Path
B=Path('/tmp/pa-trial-new-intent-evidence-20261016')
for name in ('red','green-basic','green-navigation'):
    root=B/name
    assert (B/(name+'.xml')).is_file() and (B/(name+'.log')).is_file()
    files={str(p.relative_to(root)):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in root.rglob('*') if p.is_file() and not p.is_symlink()}
    links={str(p.relative_to(root)):str(p.readlink()) for p in root.rglob('*') if p.is_symlink()}
    archive=B/(name+'-fixtures.tar.xz');assert not archive.exists()
    with tarfile.open(archive,'w:xz') as tar:tar.add(root,arcname=name)
    with tarfile.open(archive,'r:xz') as tar:
        members={str(Path(m.name).relative_to(name)):m for m in tar.getmembers() if m.isfile()}
        assert set(members)==set(files)
        for n,m in members.items():
            d=tar.extractfile(m).read();assert len(d)==files[n]['bytes'] and hashlib.sha256(d).hexdigest()==files[n]['sha256']
        assert {str(Path(m.name).relative_to(name)):m.linkname for m in tar.getmembers() if m.issym()}==links
    (B/(name+'-PACKED.json')).write_text(json.dumps(dict(files=files,symlinks=links,archive=archive.name,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),all_readback=True,observed_exit=1 if name=='red' else 0),indent=2)+'\n')
    shutil.rmtree(root)
    print(name, len(files), 'raw bytes verified and retained in archive')
