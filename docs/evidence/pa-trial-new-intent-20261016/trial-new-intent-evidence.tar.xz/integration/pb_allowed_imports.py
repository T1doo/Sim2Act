"""Fail before any known restricted diagnostic module can be imported."""
import importlib.abc
import json
import os
import sys
from pathlib import Path

DENIED = {'sql_private_barrier', 'test_natural_spec_callback_reads', 'test_pb_natural_use_read_gates'}
ATTEMPTS = []

class StopRestrictedImport(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.rsplit('.', 1)[-1] in DENIED:
            ATTEMPTS.append(fullname)
            raise RuntimeError('Known restricted diagnostic import is not allowed')
        return None

sys.meta_path.insert(0, StopRestrictedImport())

def pytest_sessionfinish(session, exitstatus):
    path = Path(os.environ['PB_IMPORT_RECEIPT'])
    loaded = sorted(n for n in sys.modules if n.rsplit('.', 1)[-1] in DENIED)
    path.write_text(json.dumps(dict(denied_module_import_attempts=ATTEMPTS,
        denied_modules_loaded=loaded, exitstatus=int(exitstatus)), indent=2) + '\n')
    if ATTEMPTS or loaded:
        session.exitstatus = 2
