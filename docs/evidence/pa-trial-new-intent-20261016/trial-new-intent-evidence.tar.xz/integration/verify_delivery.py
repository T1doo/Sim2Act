"""Read-only exact pushed ref, frozen bytes, old history and sealed-evidence audit."""
import hashlib,json,subprocess,tarfile
from pathlib import Path
R=Path('/workspace/Sim2Act-pa-provider');B=Path('/tmp/pa-trial-new-intent-evidence-20261016')
BRANCH='dev/pa-trial-new-intent-20261016';BASE='2b6120c944cc177e023f090ad1cecfe8368493ba';TESTED='9f7be1d07aabc0c8bfbdfea56c60d72b468ec846'
def git(*a,cwd=R):return subprocess.check_output(['git',*a],cwd=cwd,text=True).strip()
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
head=git('rev-parse','HEAD');baseline=json.loads((B/'BASELINE.json').read_text());protected=baseline['protected_remote']
assert len(protected)==21 and git('branch','--show-current')==BRANCH
refs=['refs/heads/'+BRANCH,*protected]
remote=dict(line.split('\t')[::-1] for line in git('ls-remote','origin',*refs).splitlines())
assert remote['refs/heads/'+BRANCH]==head and all(remote[k]==v for k,v in protected.items())
assert not git('status','--porcelain')
assert git('rev-list','--left-right','--count','HEAD...refs/remotes/origin/'+BRANCH)=='0\t0'
assert not git('diff','--name-only',TESTED,'HEAD','--','src','tests','pyproject.toml')
assert git('diff','--name-only',BASE,'HEAD','--','src','pyproject.toml')=='src/sim2act/web/natural-goal.js'
assert git('diff','--name-only',BASE,'HEAD','--','tests').splitlines()==['tests/natural_trial_consent_ui.cjs','tests/test_natural_trial_consent_ui.py']
assert not git('diff','--name-only',BASE,'HEAD','--','src/sim2act/*.py','src/sim2act/text_software_anchors.json','docs/evidence/pa-trial-consent-entry-20261015','docs/F2/PATrialConsentEntry20261015.md')
for ancestor in [BASE,TESTED,'3e890e329332d434e8f3aa245cb15f905bb41455','6f688e4dd80b5c81d41aecde90e360d3629f9c21']:
    subprocess.run(['git','merge-base','--is-ancestor',ancestor,head],cwd=R,check=True)
old=Path('/workspace/Sim2Act');assert git('rev-parse','HEAD',cwd=old)=='a4fd476127a477006dbdb29a9a1f6c2f09e6a001'
assert all(h(old/n)==v for n,v in baseline['other_wip'].items())
OUT=R/'docs/evidence/pa-trial-new-intent-20261016';meta=json.loads((OUT/'ARCHIVE.json').read_text());m=json.loads((OUT/'MANIFEST.json').read_text())
assert set(m['files'])=={str(p.relative_to(B)) for p in B.rglob('*') if p.is_file() and not p.is_symlink()}
assert m['symlinks']=={str(p.relative_to(B)):str(p.readlink()) for p in B.rglob('*') if p.is_symlink()}
assert h(OUT/meta['file'])==meta['sha256']
with tarfile.open(OUT/meta['file'],'r:xz') as tar:
    assert len(tar.getmembers())==len(m['files'])+len(m['symlinks'])
    for member in tar.getmembers():
        if member.issym():assert m['symlinks'][member.name]==member.linkname
        else:
            assert member.isfile();data=tar.extractfile(member).read();v=m['files'][member.name]
            assert len(data)==v['bytes'] and hashlib.sha256(data).hexdigest()==v['sha256']==h(B/member.name)
for p in (B/'public').iterdir():
    if p.is_file():assert h(p)==h(OUT/'public'/p.name)
result=json.loads((B/'final/RESULT.json').read_text())
assert result['counts']=={'pass':43,'failure':0,'error':0,'skipped':0}
assert result['source_unchanged'] and result['head_unchanged'] and result['tree_clean'] and result['returncode']==0
value=dict(final_sha=head,tested_sha=TESTED,branch=BRANCH,clean=True,ahead_behind='0/0',protected_count=21,protected_unchanged=True,remote=remote,
    final_vs_tested_source_test_diff=[],server_python_diff=[],qualified_target_changed=False,old_evidence_unchanged=True,unrelated_wip_unchanged=True,archive=meta,result=result,
    actual_pa_pb='NOT_ACCEPTED',scope='EXPLICIT_NEW_PREPARATION_FIX_ONLY',real_model_paid_calls=0,remote_ci='NOT_RUN')
Path('/workspace/pa-trial-new-intent-final-verification-20261016.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps({k:v for k,v in value.items() if k not in ('remote','result')}),flush=True)
