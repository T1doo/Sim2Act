# Static independent review — explicit new trial intent

No blocking defect found in the currently inspected three-file diff. This is static review only; no tests, SQL, API or runtime diagnostics ran and no execution result is asserted.

`updateTrialAddress` deletes the two trial fragment parameters only when current URL project/key exactly match the abandoned pair, retaining other fragment parameters, path/query and `history.state` through `replaceState`. Preparation and explicit key recovery write the current pair without adding a history entry. This preserves cold-link recovery rather than globally deleting original keys.

The explicit-new handler admits only `known`/`rejected`, increments the old entry operation before address replacement and Map deletion, then clears preview/cards/acknowledgements and advances generation. Sending/UNKNOWN remains blocked. Refresh cannot reconstruct the abandoned original pair from the replaced current address, while second preparation creates a fresh UUID. Existing late reply checks compare the captured old entry operation before assigning state; generation/context checks further prevent visible acknowledgement of another view.

History handling performs no HTTP or POST. It invalidates prior operations/generation and erases private receipt/scope/ack before constructing a no-body UNKNOWN placeholder for a valid key. A different history key cannot replace an existing sending/UNKNOWN key; the current original pair is restored in the URL and requires GET recovery. Missing/foreign-project/invalid trial intent also conservatively preserves an existing entry. Same-key or repeated popstate/hashchange events can recreate only UNKNOWN state, never cached approval; replaceState itself does not dispatch these history events. Different known keys may be left and restored through explicit GET, without mutating their durable approvals.

Five new scenarios exercise prepared/revoked new→refresh→fresh second POST, back/forward read-only key recovery with no automatic HTTP, pending-history conflict and late abandoned consent release after a fresh preparation. Existing cold/lost-cold/unknown400 cases remain in parametrization. Driver assertions preserve unrelated query/hash/history state and explicitly check second preparation paths differ, no old consent retry and no execution POST. Runtime evidence for these new scenarios remains the root agent’s running bounded test, not this review.

Scope remains front-end state/address synchronization and its actual-page driver; server and qualification code are unchanged in the inspected diff. No unrelated sealed evidence was read or modified. Any later source change needs a new frozen-source check before final acceptance.

Inspected diff SHA256: 17aeedc307958ab1f5b4cfc7324e3e6c3c83d848838788ab0daa8a9108e8dd7c.
