"""Lossless post-fixture packing, no hooks during business execution."""
import hashlib,json,os,shutil,tarfile,io
from pathlib import Path
import pytest
@pytest.hookimpl(hookwrapper=True, tryfirst=True)
def pytest_runtest_teardown(item, nextitem):
    yield
    p = item.funcargs.get('tmp_path')
    if p is None or not p.exists(): return
    out=Path(os.environ['PACK_CASES']);out.mkdir(exist_ok=True,parents=True)
    name=hashlib.sha256(item.nodeid.encode()).hexdigest()[:16]
    files={str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob('*') if f.is_file() and not f.is_symlink()}
    dest=out/(name+'.tar.xz')
    with tarfile.open(dest,'w:xz') as t:t.add(p,arcname='case')
    with tarfile.open(dest,'r:xz') as t:
        for n,h in files.items():assert hashlib.sha256(t.extractfile('case/'+n).read()).hexdigest()==h
    (out/(name+'.json')).write_text(json.dumps(dict(nodeid=item.nodeid,files=files,archive_sha256=hashlib.sha256(dest.read_bytes()).hexdigest()),indent=2))
    shutil.rmtree(p)
    compact(out)


def compact(out):
    cases=sorted(p for p in out.glob('*.tar.xz') if len(p.name)==23)
    if len(cases)<4:return
    cases=cases[:4];raw={};containers={}
    for p in cases:
        containers[p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
        with tarfile.open(p,'r:xz') as t:
            for n in t.getmembers():
                if n.isfile():raw[p.name+'/'+n.name]=t.extractfile(n).read()
    name='raw-group-'+str(len(list(out.glob('raw-group-*.tar.xz')))).zfill(4)
    dest=out/(name+'.tar.xz')
    with tarfile.open(dest,'w:xz',preset=9) as t:
        for n,v in raw.items():
            info=tarfile.TarInfo(n);info.size=len(v);t.addfile(info,io.BytesIO(v))
    with tarfile.open(dest,'r:xz') as t:
        for n,v in raw.items():assert t.extractfile(n).read()==v
    (out/(name+'.json')).write_text(json.dumps(dict(containers=containers,
        raw_members={n:hashlib.sha256(v).hexdigest() for n,v in raw.items()},
        archive_sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),
        representation='Original raw file bytes verified; derived per-case archive replaced by shared raw compression'),indent=2))
    for p in cases:p.unlink()
