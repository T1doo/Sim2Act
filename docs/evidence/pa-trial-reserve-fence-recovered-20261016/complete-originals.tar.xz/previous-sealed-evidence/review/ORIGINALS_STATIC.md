# Original audit material byte review

PASS for current candidate/source and proposed minimum original evidence bytes; frozen regression still pending. No test/SQL/API/browser/verify script executed.

Frozen HEAD70e2c7069ed9d3caca94493b39627563be9a5591 changes only natural_trial_budget.py and its new reserve-fence test from0c674971. No new product behavior beyond the reviewed two-bound reserve fence.

Read audit-originals.tar.xz (21640bytes SHA80382aced6e8b197d69e517e2d0ccbe7946081ad078cfe9dfbb0bf03f576ff93) and minimum-originals.tar.xz (12580bytes SHA5c41c0a2f27b6fe6827f34d6037695c31d7a7a0df0121709643e8ed8b1e167ae). Both unique member sets exactly match their internal MANIFEST plus manifest file, every original member size/SHA matches, and every minimum original member is a byte-exact subset of the larger audit archive.

V1 fixture.db and V1_ORIGINAL.json compare byte-for-byte to the prior sealed pre-change per-case archive, not newly generated fixture data. Current reopened fixture.db.xz decompresses to the same original DB SHA3b45551185fc0579f927f0b244aefdc353ff0b623727ab31f776b02d8cb781b6; included CURRENT_READ_RESULT.json equals new B's existing result. Eight original rows and UNKNOWN slot state are represented in original JSON and current read result; reviewer used file comparison only, never SQL.

Red and green QUOTA_RACE.json and associated fixture.db each match the same original per-case archive by exact hash and raw bytes. Write HTTP_RAW.json,WRITE_ROLLBACK.json and fixture.db match one original write case together. Thus the minimum includes genuine old SQLite and genuine preparation/consent/GET HTTP text, not only a reconstructed summary. The budget reservation/refusal itself is a direct actual component API in the test, not an HTTP reserve endpoint; README says so.

No complete original package in Git or final111PASS claim is accepted here yet. Await frozen final XML/result/source manifests; preserve all compressed red failures. Only this new review record was written, no source or old sealed evidence changed.
