# Trial/stage/Run 同事务关联的有限后端切片

基线 `a8dc3e0eccb6c40fa22e1459482cd7dd202e979a`，独立分支 `dev/pa-trial-stage-association-20261016`。冻结产品/测试 `dcfbcb985c14d98f1cd7b3a375f9d4f9373f3afc`。根代理为唯一产品写入者，独审只读。原 main/core、原 owner WIP、旧锚与此前封存证据未改；本轮未删除缓存或任何旧目录。

这是可独立开发的 server-controller 后端协议，没有新增 HTTP 入口或页面操作；没有把普通 Worker 冒充已获软件资格的绑定 Worker。

`natural_trial_runs.py` 用 prepared P-A V2 的原 Generate/Source/Cold key、完整合同和批准建立关联。Generate 使用机械拆出的 `Store.submit_tx`；Source/Cold 使用现有 `app_jobs.enqueue(logic_tx=c)`。Run、两组配对关联、context marker、事件同事务提交，提交后重核批准/资格/来源；任何失败整笔回滚。普通旧 Run 不得被原键收养；重复受理只返回同一个 Run，变更输入冲突。仅元数据的 original-key recovery 不再执行、延长或返回私有材料/Goal；fresh Goal 漂移、过期和撤销后的历史读取不恢复执行权，撤销资源读取权限仍拒绝。

`Store.claim` 以 scalar marker 或任一持久关联侧识别任务，普通 Worker 跳过关联任务，V2 绑定 Worker 仅领取同一合同/批准且具备原明确阶段批准的任务。未批准阶段保持 QUEUED、fence=0、零 attempt。V1 只保留原精确 Generate key/已批准阶段身份的兼容选择，不领取其它普通任务。关联绑定原 created_at 和冻结合同摘要；claim 在完整证明后、实际写前、CLAIMED 写后严格使用同一原 Run/合同最小截止，迟到写回滚，不能用续租或篡改 created_at 延长。handoff900 只约束明确批准，已批准阶段仍受各自原 Run≤300/原 execution/lease，不能把 review 窗口当 dispatch TTL。

`Worker.process/reserve` 防直接调用绕过关联检查；reserve 与 Generate 最终写组在原事务内重验；`pa_spec_apps` 原完整 guard、最终实际写和 readback 仍在原事务内重验关联。所有原账户、fee、ledger、权限、软件资格、实例/来源、取消、租约和预算门保留，未复制执行器。

初审 CHANGES_REQUIRED 的四项问题及截止 TOCTOU 均保留独审原文，修复后冻结静审未发现新增提交阻断。开发批次 20P、27P、31P 分别保留，不累计为独立节点，也不冒称最终冻结验收。Ruff 最初35项格式/fixture问题、后1项 fixture lint，最终变更文件检查 PASS；原日志不覆盖。

正向31项协议测试只替换 literal qualification；Source/Cold 正向还明确替换 enqueue/lineage 为有限合成依赖，最终写故障测试明确替换账户/旧 commit 边界。它们证明事务/原键/排队/回滚约束，不能证明实际绑定 Worker 或真实应用完整闭环。真实 `_qualified()` 拒绝路径不替换，实测 VERSION_CONFLICT: Current software differs from the exact reviewed literal target，且全库不变。其它原有真实 Mock Worker 回归是其各自普通/合成路径证明，不会给新 coordinator 自动授予资格。

## 当前软件资格的具体缺口和最小步骤

现有资格只列86个实现文件；当前完整88文件集合相对其规范化 files 新增 `natural_trial_preparation.py`、`natural_trial_runs.py`，另改变 db、natural_live_admission、natural_trial_api、natural_trial_budget、pa_spec_apps、pa_trial_dispatch、worker。`text_continuations.py` 原 pin 的唯一64字符置零后没有额外差异。原 anchor SHA `24f26f3621b8fc49a24fa3566484b568148d9317f2d279d79f264416b994193a`、qualification SHA `f8ec19c731ab5ac1f675d909bb6186febb381c9deebd9a705ba05cf440c7f5a5`、CHANGED 和全部资格执行代码原字节未改。旧 proof 的 review_baseline/review_candidate 是其历史合同字段，不能当作当前冻结 SHA 的独审证据。

1. 固定待审实现全集、完整 SHA 和逐文件原字节摘要，并把当前两新增/七改变文件与86文件资格、原两检索锚逐项对照，审查真实权限/执行/历史边界；config 排除及唯一 pin 64字符规范化保持原规则，不能加文件名豁免或放宽 UNKNOWN/语义依赖。
2. 在已有允许的隔离测试条件下，完成当前冻结目标的资格/篡改矩阵、两个既有锚的原实例/历史/权限/深层校验及受影响通路复验，保留所有失败和独审结论。本任务的新协议合成测试不能替代这些证明。已知拒绝的私有 SQL 诊断和浏览器路径在这里仍不执行；若所需校验只能依赖这些受限动作，则明确该证据缺口，由原授权流程处理，不能改工具/路径绕过。
3. 只有上述具体范围得到独审证明后，才可按既有完整 files manifest + 单 literal pin 的流程提出独立资格更新，附当前冻结 SHA/原证据/精确范围；保留严格 schema 和历史字段的真实含义。若需改变资格合同元数据或协议本身，单独审查，而不是自行写入“已合格”。本轮没有执行任何 repin、锚重建、豁免或资格授权。
4. 资格更新会改变实际 implementation fingerprint；需新 prepare/精确批准以及适用的逐实例软件许可，旧 trial/Release/人工决定不自动继承。先重新执行真实 `_qualified`、批准/撤销/版本漂移及服务器绑定 Worker 的离线有限链路，最后接页面。软件资格通过仍不等于存在生产零收费账户 resolver/sender，也不授予真实模型或付费调用权。

Windows、PG、原生浏览器、真实模型/费用、实际绑定 Worker 的新 controller 完整执行、页面 Generate→candidate→Source→Cold、完整 P-A/P-B业务验收、旧用户升级、部署、远端 CI：NOT RUN/NOT ACCEPTED。无凭据配置、权限扩大、真实模型请求、付费 API 或强推。
