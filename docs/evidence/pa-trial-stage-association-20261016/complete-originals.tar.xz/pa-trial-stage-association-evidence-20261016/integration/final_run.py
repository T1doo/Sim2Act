"""Single immutable-SHA offline final run with lossless post-case packing."""
import hashlib,json,os,subprocess,time,xml.etree.ElementTree as ET
from pathlib import Path
R=Path('/workspace/Sim2Act-pa-provider');B=Path('/tmp/pa-trial-stage-association-evidence-20261016');O=B/'final'
def git(*a):return subprocess.check_output(['git',*a],cwd=R,text=True).strip()
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def manifest():return {str(p.relative_to(R)):h(p) for folder in ('src','tests') for p in sorted((R/folder).rglob('*')) if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts}|{'pyproject.toml':h(R/'pyproject.toml')}
def write(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n')
sha=git('rev-parse','HEAD');assert not git('status','--porcelain');O.mkdir(exist_ok=False)
before=manifest();write('source-before.json',before)
nodes=['tests/test_natural_trial_runs.py','tests/test_goal_card_runs.py','tests/test_runtime_coordination.py','tests/test_f1_closure.py','tests/test_natural_spec_apps.py','tests/test_pa_spec_apps.py','tests/test_natural_trial_reserve_fence.py','tests/test_natural_trial_deadlines.py','tests/test_natural_trial_preparation.py','tests/test_natural_trial_close.py','tests/test_natural_trial_consent_ui.py','tests/test_natural_trial_api.py','tests/test_natural_trial_budget.py',*['tests/test_natural_live_admission.py::'+n for n in ['test_exact_approval_idempotent_cold_recovery_does_not_extend_expiry','test_revocation_irreversible_and_readable_with_no_new_permission','test_permission_loss_denies_before_private_approval_read','test_pair_loss_does_not_reprepare_or_reapprove','test_default_real_deny_and_test_permit_is_not_live','test_expired_history_does_not_restore_admission']]]

long_node='tests/test_natural_trial_budget.py::test_seven_actual_reservations_stage_binding_nontransfer_no_refund'
common=['/workspace/Sim2Act/.venv/bin/python','-m','pytest','-q','-p','no:cacheprovider','-p','pb_allowed_imports','-p','pack_cases']
env={k:os.environ[k] for k in ('PATH','LANG','LC_ALL','TZ') if k in os.environ};env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=f'{B}/integration:{R}/src:{R}/tests',NODE_PATH='/workspace/node-tools/node_modules')
started=time.time();jobs=[]
for name,selected in [('main',[*nodes,'--deselect='+long_node]),('real-cadence',[long_node])]:
    folder=O/name;folder.mkdir();args=[*common,*selected,'--basetemp='+str(folder/'tmp'),'--junitxml='+str(folder/'results.xml')]
    local=dict(env,PACK_CASES=str(folder/'packed'),PB_IMPORT_RECEIPT=str(folder/'IMPORT_POLICY.json'))
    so=(folder/'stdout.log').open('w');se=(folder/'stderr.log').open('w')
    process=subprocess.Popen(args,cwd=R,env=local,stdout=so,stderr=se)
    jobs.append((name,folder,process,so,se));write(name+'-COMMAND.json',dict(argv=args,tested_sha=sha,timeout=1200,inherited_database_url=False,pid=process.pid))
exits={}
for name,folder,process,so,se in jobs:
    timeout=False
    try:code=process.wait(timeout=max(1,1200-(time.time()-started)))
    except subprocess.TimeoutExpired:timeout=True;process.kill();code=process.wait()
    so.close();se.close();exits[name]=dict(returncode=code,timed_out=timeout)
end=time.time();write('PROCESS_EXIT.json',exits);after=manifest();write('source-after.json',after)
cases=[]
for name,folder,process,so,se in jobs:
    if (folder/'results.xml').exists():
        for c in ET.parse(folder/'results.xml').getroot().iter('testcase'):
            cases.append(dict(batch=name,id=c.get('classname')+'::'+c.get('name'),status=next((n.tag for n in c if n.tag in ('failure','error','skipped')),'pass')))
result=dict(tested_sha=sha,processes=exits,elapsed=end-started,counts={s:sum(c['status']==s for c in cases) for s in ('pass','failure','error','skipped')},cases=cases,source_files=len(before),source_unchanged=before==after,head_unchanged=sha==git('rev-parse','HEAD'),tree_clean=not git('status','--porcelain'),xml_sha256={name:h(folder/'results.xml') for name,folder,*_ in jobs if (folder/'results.xml').exists()},real_cadence_isolated_for_clock_domains=True)
write('RESULT.json',result);print(json.dumps(result))
