"""Lossless post-fixture packing, no hooks during business execution."""
import hashlib,json,os,shutil,tarfile
from pathlib import Path
import pytest
@pytest.hookimpl(hookwrapper=True, tryfirst=True)
def pytest_runtest_teardown(item, nextitem):
    yield
    p = item.funcargs.get('tmp_path')
    if p is None or not p.exists(): return
    out=Path(os.environ['PACK_CASES']);out.mkdir(exist_ok=True,parents=True)
    name=hashlib.sha256(item.nodeid.encode()).hexdigest()[:16]
    files={str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob('*') if f.is_file() and not f.is_symlink()}
    dest=out/(name+'.tar.xz')
    with tarfile.open(dest,'w:xz') as t:t.add(p,arcname='case')
    with tarfile.open(dest,'r:xz') as t:
        for n,h in files.items():assert hashlib.sha256(t.extractfile('case/'+n).read()).hexdigest()==h
    (out/(name+'.json')).write_text(json.dumps(dict(nodeid=item.nodeid,files=files,archive_sha256=hashlib.sha256(dest.read_bytes()).hexdigest()),indent=2))
    shutil.rmtree(p)
