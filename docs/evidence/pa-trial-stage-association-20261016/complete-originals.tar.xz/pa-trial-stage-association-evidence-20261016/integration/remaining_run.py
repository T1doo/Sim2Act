"""Finish exact original remaining nodes after documented graceful batch split."""
import hashlib,json,os,subprocess,time,xml.etree.ElementTree as ET
from pathlib import Path
R=Path('/workspace/Sim2Act-pa-provider');B=Path('/tmp/pa-trial-stage-association-evidence-20261016');O=B/'remaining'
def git(*a):return subprocess.check_output(['git',*a],cwd=R,text=True).strip()
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def manifest():return {str(p.relative_to(R)):h(p) for folder in ('src','tests') for p in sorted((R/folder).rglob('*')) if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts}|{'pyproject.toml':h(R/'pyproject.toml')}
def write(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n')
sha=git('rev-parse','HEAD');assert sha=='dcfbcb985c14d98f1cd7b3a375f9d4f9373f3afc' and not git('status','--porcelain');O.mkdir()
plan=json.loads((B/'GRACEFUL_SPLIT.json').read_text());before=manifest();assert before==json.loads((B/'final/source-before.json').read_text())==json.loads((B/'final/source-after.json').read_text());write('source-before.json',before)
args=['/workspace/Sim2Act/.venv/bin/python','-m','pytest','-q','-p','no:cacheprovider','-p','pb_allowed_imports','-p','pack_cases',*plan['remaining_nodes'],'--basetemp='+str(O/'tmp'),'--junitxml='+str(O/'results.xml')]
env={k:os.environ[k] for k in ('PATH','LANG','LC_ALL','TZ') if k in os.environ};env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=f'{B}/integration:{R}/src:{R}/tests',NODE_PATH='/workspace/node-tools/node_modules',PACK_CASES=str(O/'packed'),PB_IMPORT_RECEIPT=str(O/'IMPORT_POLICY.json'))
start=time.time();write('COMMAND.json',dict(argv=args,tested_sha=sha,timeout=1200,inherited_database_url=False,scope='Exact remaining original IDs; no restricted diagnostic retries; last two completed prefix cases intentionally reverified'))
with (O/'stdout.log').open('w') as so,(O/'stderr.log').open('w') as se:
 p=subprocess.Popen(args,cwd=R,env=env,stdout=so,stderr=se)
 timed_out=False
 try:code=p.wait(timeout=1200)
 except subprocess.TimeoutExpired:timed_out=True;p.kill();code=p.wait()
end=time.time();after=manifest();write('source-after.json',after)
cases=[]
if (O/'results.xml').exists():
 for c in ET.parse(O/'results.xml').getroot().iter('testcase'):
  cases.append(dict(id=(c.get('classname') or '<incomplete>')+'::'+(c.get('name') or '<incomplete>'),status=next((n.tag for n in c if n.tag in ('failure','error','skipped')),'pass' if c.get('classname') else 'unknown')))
result=dict(tested_sha=sha,returncode=code,timed_out=timed_out,elapsed=end-start,counts={s:sum(c['status']==s for c in cases) for s in ('pass','failure','error','skipped','unknown')},cases=cases,source_files=len(before),source_unchanged=before==after,head_unchanged=sha==git('rev-parse','HEAD'),tree_clean=not git('status','--porcelain'))
write('RESULT.json',result);print(json.dumps(result))
