# Frozen backend association: independent static review

Reviewed exact commit: `dcfbcb985c14d98f1cd7b3a375f9d4f9373f3afc`. Read-only Git status was clean. Outcome: no remaining source-level blocker identified for committing and validating this limited offline backend coordinator slice. Full frozen related-suite acceptance remains pending its actual final results. This is not page, real bound Worker, software qualification or production acceptance.

The earlier STATIC.md and STATIC_RESOLUTION.md findings remain preserved. The frozen implementation resolves the last identified deadline gap: Association freezes original created_at; `_check_run` compares it exactly; `check_claim` captures the original min(frozen Run limit, trial cap, execution deadline), rechecks it after the final scope proof and returns it; Store.claim uses that same deadline after final source scope, immediately before ownership write, and after CLAIMED. The final failure raises within the original transaction so ownership/event writes roll back. No later timestamp or lease restarts the original Run clock.

Other resolved findings remain intact: approved handoff timing is not reused as dispatch TTL; V2 binding selection excludes unrelated ordinary Runs; original-key acceptance is atomic with both paired associations and marker/event; post-write and final commit association checks share the owning transaction; qualification/fee/account/send/budget/lease/fence and original current phase checks remain required. Terminal checks do not impose RUNNING on the already verified SUCCEEDED representation. No new nested transaction was found in check_worker_tx. Ordinary unassociated paths do not invoke trial qualification/account checks.

## Evidence inspected, without executing it

`/tmp/pa-trial-stage-association-evidence-20261016/third.xml` reports tests=31, failures=0, errors=0, skipped=0, 47.098 seconds; the log ends 31 passed. Its XML SHA256 is `5954d92bbe56030e9a50047f2abf32d3825d8c57b0709504768efe38e6e72134`. The four last_proof/last_scope/claim_write/created_tamper node names are present as passing cases. The import receipt reports empty denied attempts/loaded modules and exitstatus 0. ruff-final.log says All checks passed. First/second logs, XML and earlier Ruff failure logs remain present. These are development-batch observations; I have not inferred a frozen full-suite source/command manifest from them.

The new tests explicitly label their boundary: positive acceptance replaces production._qualified; Source/Cold tests replace enqueue and lineage authority with finite synthetic dependencies; final-write tests replace binding/account/dispatch proof to isolate the original transaction rollback. The strict refusal and qualification-drift tests separately restore the real software check and require unchanged database on rejection. Thus these tests support coordinator, original-key, queue isolation, authorization and rollback behavior. They do not prove successful actual associated Source/Cold execution, fee/account entitlement, a qualified Worker or a complete browser flow.

Frozen file SHA256:

- natural_trial_runs.py: `42c396a9b1600ca0f4ebba1cee225ace1386116c408f89eb3815588f6ff2e250`
- db.py: `22785fb275c919692a270df3f3ac76becf2c475fed23922bab4210c5306eae86`
- worker.py: `a86c52904c29847ea7e1fd446e5e3bfbbe65f31e9d26fb709d6e86b4b9a23d3e`
- pa_spec_apps.py: `36c8dae47d32250a3ab1d3aa322a3963eb5c8379f5d443f5260e6c58b906e0ba`
- test_natural_trial_runs.py: `54a0da665892da820d75123f09e8c804ad2fb6da3f23bdc0ee27a8cb6b0a4ad8`

## Remaining scope and prerequisites

The original production admission, text_continuations, qualification manifest and anchors have no diff from base a8dc3e0eccb6c40fa22e1459482cd7dd202e979a. The exact-current-software qualification rejection remains real. To attempt the strict full page seven-slot chain later requires a separately authorized, complete exact final-software qualification review with its evidence; updating a hash or using synthetic replacements is not that process. The final implementation tree must be covered, and production account/sender readiness remains a separate prerequisite. No LIVE permission is inferred.

Before finite backend acceptance, inspect the actual frozen related regression RESULT/XML/source manifests, including ordinary submit/claim/application paths and the original 111-case coverage without skipped-away nodes. PostgreSQL concurrency and Run→project lock ordering, Windows, browser and actual full page/bound Worker remain NOT RUN unless later actual evidence says otherwise. Historical P-A/P-B/Cold acceptance is unchanged.

This reviewer ran only read-only file/Git commands, no tests, SQL, API/browser, Python, qualification, network, model or paid requests. Only independent review notes outside the evidence/source tree were written. No source, tests, old sealed evidence or refs were changed.
