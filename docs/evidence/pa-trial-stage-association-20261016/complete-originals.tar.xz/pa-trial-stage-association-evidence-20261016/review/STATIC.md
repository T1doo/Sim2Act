# Stage association: independent static review

Status: CHANGES_REQUIRED for the mutable candidate read during this review. This is an independent backend slice only; no HTTP/page chain or qualified binding Worker execution has been accepted. No tests, SQL, API, browser, qualification invocation or model request were run by this reviewer.

Reviewed: natural_trial_runs.py, db.py submit_tx/claim changes, worker.py process/reserve/once changes, and the existing admission/dispatch/commit functions. Root remains the only source/test writer. Review findings were sent to root immediately; this file describes the reviewed candidate rather than a frozen final acceptance.

## Findings

1. **Handoff approval deadline incorrectly enforced during execution.** `check_claim` calls `_stage_review_window(authority)` for saved Source/Cold PHASE. `check_worker` invokes this same check on process and every reserve. The V2 contract deliberately uses the handoff deadline only for review/approval; a stage approved before its deadline may execute its bounded Run afterward. Remove that window from execution readiness while retaining the complete exact PHASE/current authority proof and existing execution/Run/lease guards. Test approval just before the deadline followed by claim and later reserve after it; neither should be denied solely by handoff expiry.

2. **Bound Worker can acquire unrelated ordinary Runs.** `Store.claim(trial_binding=...)` currently retains `~associated_sql()` as an OR branch. An older normal queued Run can therefore be claimed by the bound Worker, then its original trial preflight may reject/fail it rather than leaving it for its ordinary Worker. The bound selection needs an explicit compatible scope. Prefer matching associated Runs; if legacy unassociated trial fixtures must remain supported, prove their exact original binding instead of selecting all ordinary Runs. Test a mixed queue with an older ordinary Run and ensure ownership/status/fence of that Run remain unchanged.

3. **Run lifetime is not checked before acquisition.** `check_claim` checks current trial execution expiry but does not check the original Run `created_at + min(original frozen run limit, trial run cap)` deadline. Generate has no phase branch to incidentally reject an old Run. A queued associated Run older than its original 300 seconds can be acquired and fail only at a later reserve. To satisfy failure-keeps-QUEUED, check finite original creation/deadline at the final claim-write boundary, never reset its start time. Test just-before, exact-boundary, and elapsed Run deadlines without extending the trial expiry or lease.

4. **Final association revalidation is not wired into terminal transactions.** New association validation is at process/reserve. Existing terminal trial checks are conditional on `self.pa_trial` and do not independently prove the new paired association/marker. Add a transaction-sharing association check at the existing final commit boundaries, without opening a nested transaction, caching proofs, or reapplying the handoff approval deadline. Preserve the existing account/current phase/lease/fence/settlement checks. Test mutation of the association after the final reserve and an attempted unbound terminal commit. A separately executed `check_worker` transaction is insufficient for commit atomicity.

## Positive static observations

- `submit_tx` is a mechanical extraction of the original submit transaction body; ordinary wrapper retry remains after rollback. It checks active owning-store transaction and does not independently commit.
- The coordinator takes the original trial/project authorization before private histories. Generate uses the exact frozen Goal/key/caps; stage acceptance uses the existing enqueue transaction and complete original stage lineage proof. Run creation, context marker, two paired association locations and acceptance event are written in the same caller transaction, with a post-write scope check.
- Existing ordinary Run/key adoption is explicitly rejected; duplicate accepted operations compare immutable input and run/frozen fingerprints rather than creating a new key.
- An ordinary Worker excludes association markers or either member of the Run-side pair. Missing one pair half does not open the queue; the bound claim path performs the complete paired proof before mutating ownership, and a DomainError returns without claiming the selected Run.
- `_scope` calls the real `production._qualified()` by default; no qualification or anchor source was changed in the reviewed diff. The previously recorded exact current-software rejection remains a real execution blocker. Unit/protocol proofs that isolate this prerequisite must remain labelled as such and cannot claim a qualified controller/page chain.
- Recovery is original association metadata, after fresh resource/SAVE authorization, and does not call dispatch, extend deadlines or use latest-object selection. Resource revocation can still reject recovery; that is not authority to return private frozen bodies or retry a POST.

## Additional required evidence before acceptance

Besides the four regressions above: transaction rollback after partial association writes; duplicate/changed-input and preexisting ordinary-key collisions; partial pair/marker tampering; missing exact PHASE leaving Source/Cold QUEUED; revoke/Goal/material/software drift at pre/post-write boundaries; wrong user/project/binding/key; cancellation and stale fence/version; matching association cannot let a normal Worker reserve or commit; real current `_qualified` rejection unchanged. PostgreSQL lock ordering (claim currently selects Run FOR UPDATE before trial project locking) deserves a bounded code review and must remain NOT RUN unless tested; do not infer concurrency coverage from SQLite tests.

No source/test files or sealed evidence were modified. Only this independent review directory was written. This review is not a test result or a frozen acceptance.
