# Mutable stage-association candidate: second static review

Status: prior findings materially addressed, with one remaining claim deadline TOCTOU. This is not frozen or runtime acceptance. The first STATIC.md remains unchanged.

Reviewed current natural_trial_runs.py, db.py, worker.py, pa_spec_apps.py diff and tests/test_natural_trial_runs.py. No test/SQL/API/browser/Python/qualification execution was performed.

## Resolved in the current source

- `check_claim` no longer applies `_stage_review_window` to an already saved phase. Exact saved PHASE/current authority, approval key and fingerprint remain mandatory. The new synthetic Source/Cold tests approve before the handoff and claim after it; their enqueue/lineage replacement is explicit, so they establish coordinator timing, not real app execution.
- V2 bound claim selection now selects matching associated Runs rather than all unrelated ordinary work. The mixed-queue test places an ordinary Run first and checks it remains QUEUED/fence zero until an ordinary claimant takes it. Legacy non-V2 selection is limited to the original exact Generate identity or stored phase identity.
- `check_worker_tx` shares the owning connection/transaction. Worker reserve and finish pre/post writes and the existing spec commit/final readback boundaries call it. It does not open a new transaction. The outer process/initial reserve convenience `check_worker` owns a transaction only outside these helpers.
- Terminal association checks do not require RUNNING or call Store.guard. `_stage_current` reads `bound`, whose ordinary and PA-use paths accept the existing correctly committed SUCCEEDED representation. Source timing refers to the original Generate; Cold timing refers to the original successful Source. Instance revision remains part of authority while data_version may advance with output. Thus I found no intrinsic SUCCEEDED-only incompatibility introduced by these calls. Existing verify_job/readback and original ownership/lease/account/commit checks remain in place; this is a static conclusion, not an actual associated Source/Cold runtime result.
- The added final STATE-write fault test exercises rollback after the original STATE event for removed binding, changed pair and elapsed original deadline. It explicitly replaces account/binding/dispatch proof and does not claim a validated bound Worker or graph execution.
- Ordinary non-associated paths only perform the new scalar association check before returning; they do not invoke trial account/qualification. Existing original trial checks were not removed.

## Remaining claim boundary issue

The original Run lifetime check was added, but it occurs before potentially lengthy `_stage_current` and final `_scope`/`_qualified`; `Store.claim` subsequently calls `source_scope_gate` and only then writes RUNNING/fence/lease. Time can cross `created_at + min(frozen Run seconds, trial cap)` after the check and before ownership acquisition. The new 299.999/300 tests set time before the entire check and do not inject this later crossing.

Preserve the original computed minimum deadline and perform a final strict pure-clock check after all these proofs, immediately before the claim update (and a final check after write if claiming rollback at write latency is part of the contract). A failure must roll back claim/event writes and leave QUEUED/fence/attempts unchanged. Do not recompute a longer deadline or reset created_at. Add a fault that advances time at the final scope/qualification or source_scope_gate return to the exact original deadline; ensure no claim mutation survives. Existing reserve/terminal time guards remain necessary independently.

## Scope limits

The real current `_qualified` rejection remains required and unchanged. Positive coordinator tests use a qualification replacement and finite stage enqueue/lineage stand-ins, as labelled. No HTTP entry, page stage chain, current-software qualification, production account/sender, or actual bound seven-slot acceptance is implied. PostgreSQL locking/concurrency remains unverified; new trial project locks after a selected Run FOR UPDATE need lock-order consideration before PG acceptance.

Only this independent resolution note was written; source/tests and sealed evidence were untouched.
