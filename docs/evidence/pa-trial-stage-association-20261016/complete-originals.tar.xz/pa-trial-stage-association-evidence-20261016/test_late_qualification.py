"""External RED while the product/test tree remains frozen for the main batch."""
import time
import pytest
from conftest import env
from test_natural_trial_preparation import prepared_data
from test_natural_trial_runs import controller, synthetic, snapshot, synthetic_stage
from sim2act import natural_trial_runs as service
from sim2act import production_trial_admission as production
from sim2act.errors import DomainError

@pytest.mark.parametrize('stage,late_call',[('generate',2),('source',3)])
def test_final_qualification_crossing_expiry_cannot_commit(synthetic,monkeypatch,stage,late_call):
    data,binding,_,_=synthetic
    calls=[]
    body=None
    if stage=='source':body,_=synthetic_stage(synthetic,monkeypatch)
    before=snapshot(data[0])
    def qualified():
        calls.append(1)
        if len(calls)==late_call:
            monkeypatch.setattr(time,'time',lambda:binding.contract.expires_at)
    monkeypatch.setattr(production,'_qualified',qualified)
    with pytest.raises(DomainError):
        if stage=='generate':service.submit_generate(data[0],data[3],binding)
        else:service.submit_stage(data[0],data[3],binding,stage,body)
    assert snapshot(data[0])==before
