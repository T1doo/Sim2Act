# Preserved authoring checks before test execution
- First continuation extraction Ruff reported F821 `run_id`; corrected to independently scoped `job["id"]` before candidate1b15 tests.
- Second origin-continuation import insertion Ruff I001; fixed before candidate9f54 tests.
- New eight-case local import order Ruff I001; fixed before candidate0d55 tests. The read_release Limits positional index was corrected from5 to4 during authoring before any execution of these cases.
- HTTP negative fixture assertion was corrected during authoring to actual `{"error": exc.public()}` response structure before any new candidate tests. Existing d94 source_revoke KeyError failure remains preserved.
- All these are authoring/lint checks, not additional executed failed pytest batches. Actual failed pytest batches retain their separate source snapshots, XML, process and import receipts.
