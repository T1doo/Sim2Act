"""Derive only public-window timing; no new execution, DB or private reads."""
import json
from collections import Counter, defaultdict
from pathlib import Path

out=Path('/workspace/pb-cold-commit-proof-evidence-20261015/observation/baseline-public-chain')
p=out/'PUBLIC_SEGMENTS.json'
assert p.exists(), 'Observer terminal artifact missing; no replacement observation is authorized'
x=json.loads(p.read_text());records=x['records']
txs=defaultdict(dict);begins=defaultdict(dict);calls=defaultdict(dict)
duplicates=[]
for r in records:
 k=r['kind']
 if k.startswith('TX_'):
  target=txs[r['tx']]
 elif k.startswith('BEGIN_'):
  target=begins[r['span']]
 elif k.startswith('CALL_'):
  target=calls[r['span']]
 else:
  continue
 if k in target:duplicates.append(dict(kind=k,tx=r.get('tx'),span=r.get('span')))
 target[k]=r

def seconds(start,end):return (end['monotonic_ns']-start['monotonic_ns'])/1e9
transaction_windows=[]
for ident,v in txs.items():
 request=v.get('TX_REQUEST');acquired=v.get('TX_ACQUIRED');body=v.get('TX_BODY_END');end=v.get('TX_EXIT')
 transaction_windows.append(dict(tx=ident,thread=request['thread'] if request else None,
  store=request.get('store') if request else None,acquired=bool(acquired),
  acquisition_window_s=seconds(request,acquired or end) if request and (acquired or end) else None,
  body_window_s=seconds(acquired,body) if acquired and body else None,
  original_exit_window_s=seconds(body,end) if body and end else None,
  error=v.get('TX_ERROR',{}).get('error'),
  begin_monotonic_ns=acquired['monotonic_ns'] if acquired else None,
  body_end_monotonic_ns=body['monotonic_ns'] if body else None,
  complete=bool(request and end and (not acquired or body))))
begin_windows=[]
for ident,v in begins.items():
 start=v.get('BEGIN_ENTER');end=v.get('BEGIN_EXIT') or v.get('BEGIN_ERROR')
 if not start:continue
 item=dict(span=ident,tx=start['tx'],thread=start['thread'],
  driver_begin_window_s=seconds(start,end) if end else None,
  result='ERROR' if 'BEGIN_ERROR' in v else 'EXIT' if end else 'INFLIGHT',
  error_type=end.get('error_type') if end else None,
  sqlite_errorname=end.get('sqlite_errorname') if end else None,
  start_monotonic_ns=start['monotonic_ns'],end_monotonic_ns=end['monotonic_ns'] if end else None)
 if 'BEGIN_ERROR' in v:
  failed=txs.get(start['tx'],{}).get('TX_REQUEST',{})
  item['other_thread_same_store_acquired_body_overlaps']=[t['tx'] for t in transaction_windows
   if t['store']==failed.get('store') and t['thread']!=start['thread']
   and t['begin_monotonic_ns'] is not None and t['body_end_monotonic_ns'] is not None
   and end and max(t['begin_monotonic_ns'],start['monotonic_ns']) < min(t['body_end_monotonic_ns'],end['monotonic_ns'])]
 begin_windows.append(item)
call_windows=[]
for ident,v in calls.items():
 start=v.get('CALL_ENTER');end=v.get('CALL_EXIT') or v.get('CALL_ERROR')
 if not start:continue
 call_windows.append(dict(span=ident,function=start['function'],tx=start['tx'],thread=start['thread'],
  run_id=start.get('run_id'),source_run_id=start.get('source_run_id'),stage=start.get('stage'),
  duration_s=seconds(start,end) if end else None,error=end.get('error') if end else None,
  start_monotonic_ns=start['monotonic_ns'],end_monotonic_ns=end['monotonic_ns'] if end else None,
  complete=bool(end)))
summary=dict(policy=x['policy'],interpretation=x['interpretation'],dropped=x['dropped'],
 pending_begin_spans=x['pending_begin_spans'],duplicates=duplicates,
 observer_stack_mismatches=sum(r['kind']=='OBSERVER_STACK_MISMATCH' for r in records),
 transaction_count=len(transaction_windows),incomplete_transactions=[t['tx'] for t in transaction_windows if not t['complete']],
 begin_count=len(begin_windows),incomplete_begin=[v['span'] for v in begin_windows if v['result']=='INFLIGHT'],
 public_call_count=len(call_windows),incomplete_calls=[v['span'] for v in call_windows if not v['complete']],
 call_counts=dict(Counter(v['function'] for v in call_windows)),
 actual_admit_stages=sorted({v['stage'] for v in call_windows if v['stage'] is not None}),
 begin_errors=[v for v in begin_windows if v['result']=='ERROR'],
 longest_begin_windows=sorted(begin_windows,key=lambda v:v['driver_begin_window_s'] or -1,reverse=True)[:10],
 longest_acquired_body_windows=sorted((v for v in transaction_windows if v['body_window_s'] is not None),key=lambda v:v['body_window_s'],reverse=True)[:15],
 longest_public_calls=sorted((v for v in call_windows if v['duration_s'] is not None),key=lambda v:v['duration_s'],reverse=True)[:25],
 public_errors=[v for v in call_windows if v['error'] is not None],
 limitations=['Instrumented single sample only; nested durations overlap and must not be summed',
 'BEGIN is original driver operation including any wait, not proof of pure lock-wait time',
 'Acquired body window is elapsed validation/business work, not CPU time or exact lock release',
 'Overlap of same-store other-thread body is an observation, not proof of sole lock-holder causation'])
(out/'PUBLIC_ANALYSIS.json').write_text(json.dumps(summary,indent=2)+'\n')
(out/'PUBLIC_PAIRED_WINDOWS.json').write_text(json.dumps(dict(transactions=transaction_windows,begins=begin_windows,calls=call_windows),indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ['dropped','transaction_count','begin_count','public_call_count','actual_admit_stages','incomplete_transactions','incomplete_begin','incomplete_calls','begin_errors']},indent=2))
