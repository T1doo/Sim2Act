"""Archive every regular owned evidence file and verify every archived byte."""
import hashlib,json,tarfile
from pathlib import Path
b=Path('/workspace/pb-cold-commit-proof-evidence-20261015')
out=Path('/workspace/Sim2Act-pa-provider/docs/evidence/pb-cold-commit-proof-20261015')
out.mkdir(parents=True,exist_ok=False)
files=sorted(p for p in b.rglob('*') if p.is_file() and not p.is_symlink())
manifest={str(p.relative_to(b)):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files}
(out/'MANIFEST.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
archive=out/'cold-commit-proof-evidence.tar.xz'
with tarfile.open(archive,'w:xz',preset=9) as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(b)),recursive=False)
with tarfile.open(archive,'r:xz') as tar:
 members=tar.getmembers();assert len(members)==len(manifest)
 for member in members:
  assert member.isfile() and member.name in manifest
  data=tar.extractfile(member).read();record=manifest[member.name]
  assert len(data)==record['bytes'] and hashlib.sha256(data).hexdigest()==record['sha256']
assert all(hashlib.sha256((b/n).read_bytes()).hexdigest()==v['sha256'] for n,v in manifest.items())
assert set(manifest)=={str(p.relative_to(b)) for p in b.rglob('*') if p.is_file() and not p.is_symlink()}
receipt=dict(file=archive.name,bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),members=len(manifest),tested_source_test_sha='d798e825e48d50ed7733739f1bee2c80d7885b31',production_source_equal_a027=True,baseline_sha='bb04afc3d42c0565ffe9adf1d076ef7af182ab95',status='NOT_ACCEPTED_UNEXPLAINED_PRE_SEND_FAILURE',all_members_readback=True,regular_files_only=True)
(out/'ARCHIVE.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
