"""Bounded exact-node run, immutable source capture and actual terminal receipt."""
import argparse,hashlib,json,os,shutil,subprocess,time
from pathlib import Path
import xml.etree.ElementTree as ET
R=Path('/workspace/Sim2Act-pa-provider');B=Path('/workspace/pb-cold-commit-proof-evidence-20261015')
P='/workspace/Sim2Act/.venv/bin/python'
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def manifest():return {str(p.relative_to(R)):h(p) for folder in ('src','tests') for p in sorted((R/folder).rglob('*')) if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts}|{'pyproject.toml':h(R/'pyproject.toml')}
a=argparse.ArgumentParser();a.add_argument('--name',required=True);a.add_argument('--sha',required=True);a.add_argument('--timeout',type=int,default=1800);a.add_argument('--observer-plugin',default='peer_boundary_observer');a.add_argument('--node',action='append',required=True);args=a.parse_args()
assert all(x.isalnum() or x in '-_' for x in args.name)
assert git('rev-parse','HEAD')==args.sha and not git('status','--porcelain')
assert args.node == ['tests/test_pb_trial_dispatch.py::test_pb_full_actual_worker_extraction_and_cold'], args.node
observer=B/'integration/public_segments.py';observer_before=h(observer)
with (B/'integration/ONE_COLD_ATTEMPT.json').open('x') as token:
 json.dump(dict(sha=args.sha,node=args.node,observer_sha256=observer_before,created=time.time()),token,indent=2)
out=B/'observation'/args.name;out.mkdir(exist_ok=False)
before=manifest();write(out/'source-before.json',before)
for n in before:
 d=out/'executed-source'/n;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/n,d)
env={k:os.environ[k] for k in ('PATH','LANG','LC_ALL','TZ') if k in os.environ}
env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=f'{B}/integration:{R}/src:{R}/tests',NODE_PATH='/workspace/node-tools/node_modules')
argv=[P,'-m','pytest','-q','-p','no:cacheprovider']
argv+=['-p','pb_allowed_imports','-p','public_segments'];env['PB_IMPORT_RECEIPT']=str(out/'IMPORT_POLICY.json')
argv+=args.node+[f'--basetemp={out}/tmp',f'--junitxml={out}/results.xml']
write(out/'COMMAND.json',dict(sha=args.sha,argv=argv,nodes=args.node,import_guard_sha256=h(B/'integration/pb_allowed_imports.py'),timeout_seconds=args.timeout,observer_sha256=observer_before,harness_sha256=h(Path(__file__)),isolated_sqlite=True,no_budget_override=True,no_inherited_database_url=True))
start=time.time()
with (out/'stdout.log').open('w') as so,(out/'stderr.log').open('w') as se:
 child=subprocess.Popen(argv,cwd=R,env=env,stdout=so,stderr=se)
 write(out/'START.json',dict(pid=child.pid,started=start))
 timed_out=False
 try:code=child.wait(timeout=args.timeout)
 except subprocess.TimeoutExpired:
  timed_out=True;child.kill();code=child.wait()
end=time.time();write(out/'PROCESS_EXIT.json',dict(returncode=code,timed_out=timed_out,finished=end))
after=manifest();write(out/'source-after.json',after)
executed={n:h(out/'executed-source'/n) for n in before};write(out/'executed-source-manifest.json',executed)
cases=[]
if (out/'results.xml').exists():
 for c in ET.parse(out/'results.xml').getroot().iter('testcase'):
  cases.append(dict(id=c.get('classname','')+'::'+c.get('name',''),status='interrupted' if not c.get('name') else next((v.tag for v in c if v.tag in ('failure','error','skipped')),'pass'),time=c.get('time')))
x=dict(sha=args.sha,returncode=code,timed_out=timed_out,elapsed=end-start,cases=cases,counts={s:sum(c['status']==s for c in cases) for s in ('pass','failure','error','skipped','interrupted')},source_files=len(before),source_unchanged=before==after==executed,head_unchanged=git('rev-parse','HEAD')==args.sha,tree_clean=not git('status','--porcelain'),xml_sha256=h(out/'results.xml') if (out/'results.xml').exists() else None)
x['observer_unchanged']=observer_before==h(observer)
write(out/'RESULT.json',x);print(json.dumps(x),flush=True)
