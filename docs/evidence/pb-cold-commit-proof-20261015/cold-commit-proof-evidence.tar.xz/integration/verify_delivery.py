"""Read-only remote/byte/WIP receipt for the narrowly continued test branch."""
import hashlib,json,subprocess
from pathlib import Path
R=Path('/workspace/Sim2Act-pa-provider')
B=Path('/workspace/pb-cold-commit-proof-evidence-20261015')
BASE='bb04afc3d42c0565ffe9adf1d076ef7af182ab95'
TESTED='d798e825e48d50ed7733739f1bee2c80d7885b31'
PROTECTED={'dev/pa-production-wiring-20261015': '60534d3d554aa611d4d7c86da635c51a24ac7c92', 'dev/project-peer-lease-20261015': 'c839ce4917eaa089b557486ca8b0dbb5a8d755a5', 'dev/pb-source-archive-20261015': '2747eec91fdcfdefb6f575a8d96dbb0dab26114e', 'dev/production-admission-contract-20261015': 'fd0ac2198986f201e05924104e7f7a7bb0908769', 'dev/project-complete-checks-admission-20261015': '255b6ac407ebad31aedbe1b8d9547ee3892cdc0f', 'main': '6f688e4dd80b5c81d41aecde90e360d3629f9c21', 'dev/f1-foundation': 'bbe07a2a10583001d12a0d00fc2aff92254d80fe', 'dev/csv-two-sum-instances-20261011': '3e890e329332d434e8f3aa245cb15f905bb41455', 'dev/logic-version-per-use-20261013': '5dc3d54a1e2dfe32fb665480bb65dea3e10b9192', 'dev/logic-version-correction-20261013': 'fbffaca5a5ca289b2c13d26d50c131d238389a21', 'dev/project-natural-revalidation-20261014': '0bc90d9f8d4ab1093be079be3dae3d5f45ffb05d', 'dev/project-account-close-20261014': '2858226b9a68c943476d112af511e54581a0bf93', 'dev/project-check-cancel-20261014': '80329152ff4b9f39c72f59fafed4828f0d68b6bb', 'dev/project-reliability-gates-20261015': '52654f7610602b7afc8a2c44eee7abc23e5c2d5d', 'dev/pb-production-wiring-20261015': '0c16fa98a94fd1b0a33a080efeb6a0098de4f98a'}
PROTECTED['dev/pb-source-read-cases-20261015']=BASE
def git(*args,cwd=R):return subprocess.check_output(['git',*args],cwd=cwd,text=True).strip()
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
branch=git('branch','--show-current');head=git('rev-parse','HEAD')
assert branch=='dev/pb-cold-commit-proof-20261015'
refs=['refs/heads/'+n for n in [branch,*PROTECTED]]
remote=dict(line.split('\t')[::-1] for line in git('ls-remote','origin',*refs).splitlines())
assert remote['refs/heads/'+branch]==head
assert all(remote['refs/heads/'+n]==v for n,v in PROTECTED.items())
assert not git('status','--porcelain')
assert git('rev-list','--left-right','--count','HEAD...@{upstream}')=='0\t0'
assert not git('diff','--name-only','a027e9a10ae5d19dff6b373be7e982847a6d3846','HEAD','--','src','pyproject.toml')
assert not git('diff','--name-only',TESTED,'HEAD','--','src','tests','pyproject.toml')
changed=git('diff','--name-only',BASE,'HEAD','--','src','tests','pyproject.toml').splitlines()
assert len(changed)==9
assert not git('diff','--name-only',BASE,'HEAD','--','docs/evidence/pb-production-wiring-20261015','docs/F2/PBTrialWorkerWiring20261015.md')
for a in [BASE,'3e890e329332d434e8f3aa245cb15f905bb41455','6f688e4dd80b5c81d41aecde90e360d3629f9c21']:
 subprocess.run(['git','merge-base','--is-ancestor',a,head],cwd=R,check=True)
old=Path('/workspace/Sim2Act')
assert git('rev-parse','HEAD',cwd=old)=='a4fd476127a477006dbdb29a9a1f6c2f09e6a001'
for n,v in {'src/sim2act/owner_acceptance.py':'4b0f680cd5817db49c180ec0cae0613f67bbcc5aac4d3f02965c50bd3d638db7','docs/F2/TextFourStepOwnerAcceptance20261012.md':'c3ad19200029ab85377fbc352cb7cdc4c9699fdbdbcb10b304c6f26c5dc4ca1e'}.items():assert h(old/n)==v
batch={n:json.loads((B/'observation'/n/'RESULT.json').read_text()) for n in sorted(p.name for p in (B/'observation').iterdir() if (p/'RESULT.json').exists())}
assert not git('diff','--name-only',BASE,'HEAD','--','docs/evidence/pb-source-read-cases-20261015','docs/F2/PBSourceReadCases20261015.md')
archive=json.loads((R/'docs/evidence/pb-cold-commit-proof-20261015/ARCHIVE.json').read_text())
import tarfile
artifact=R/'docs/evidence/pb-cold-commit-proof-20261015'
manifest=json.loads((artifact/'MANIFEST.json').read_text())
assert set(manifest)=={str(p.relative_to(B)) for p in B.rglob('*') if p.is_file() and not p.is_symlink()}
assert h(artifact/archive['file'])==archive['sha256']
with tarfile.open(artifact/archive['file'],'r:xz') as t:
 assert len(t.getmembers())==len(manifest)
 for m in t.getmembers():
  assert m.isfile() and m.name in manifest
  data=t.extractfile(m).read();record=manifest[m.name]
  assert len(data)==record['bytes'] and hashlib.sha256(data).hexdigest()==record['sha256']==h(B/m.name)
x=dict(status='NOT_ACCEPTED',final_sha=head,branch=branch,baseline_sha=BASE,tested_sha=TESTED,remote=remote,protected_refs_unchanged=True,protected_ref_count=len(PROTECTED),working_tree_clean=True,ahead_behind='0/0',product_source_diff=[],final_vs_tested_source_and_test_diff=[],baseline_source_test_diff=changed,old_evidence_unchanged=True,other_wip_unchanged=True,other_wip_status=git('status','--porcelain',cwd=old),batches=batch,archive=archive,real_model_and_paid_api_calls=0,live_enabled=False,remote_ci='NOT_RUN',original_full_result='388PASS_1FAIL_RC1_NOT_ACCEPTED')
p=Path('/workspace/pb-cold-commit-proof-final-verification-20261015.json');p.write_text(json.dumps(x,indent=2)+'\n')
print(json.dumps(x,indent=2))
