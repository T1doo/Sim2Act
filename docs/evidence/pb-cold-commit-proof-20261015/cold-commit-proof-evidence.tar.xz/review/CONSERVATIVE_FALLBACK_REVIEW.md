# Conservative cache callback fallback review

Frozen SHA `a027e9a10ae5d19dff6b373be7e982847a6d3846`; candidate `9ecdb8038334b31ba4c5fe5919cf0e24f8688ee7`; previous frozen `4464486a6d4674c6cc5ce78c8b99d3d5892d5df1`.

No blocking static finding. The actual implementation difference only gives _source a private keyword selecting origin continuation and opts out in the existing cache-hit callback-invalidated fallback. A valid cached proof still requires current complete authorities, original token/transaction/driver/thread/epoch and unchanged Limits. If that callback invalidates token or Limits, it executes full original source proof with _source_origin=False: all source scope, bound, original verify_origin, receipts, counters, typed and output checks remain. It avoids invoking the additional origin-continuation authority callback a second time in this fallback. This does not permit a stale cached return, remove a guard, broaden source memo scope, extend a lease, or preserve reusable origin evidence. First complete proofs still enable the separately reviewed local origin continuation.

All review checks in JSON pass: frozen and candidate byte identity, full 86-module manifest hash equality, exact pin f8ec19c731ab5ac1f675d909bb6186febb381c9deebd9a705ba05cf440c7f5a5, unchanged anchors/CHANGED/file-set/normalization, and all tests unchanged from previous frozen. The original fourteen assertions were not relaxed.

The prior 13 PASS / 1 FAIL limits_mutation result and eight internal cases NOT RUN are preserved history, supplied by root and not independently run here. The new 22-case batch remains separate. Static review does not claim it passed or that Cold is repaired. No tests, SQL, API, new observation or source edits were performed by this reviewer.
