# Independent Source regression receipt audit

Actual a027e9a10ae5d19dff6b373be7e982847a6d3846 source batch verified: 22 PASS, 0 FAIL/ERROR/SKIP/INTERRUPTED, RC0, harness elapsed 97.492422819s. Original cache cases 14, new internal origin cases 8. JUnit SHA256 ebdc290ca8906c60fae8bc4f73c5a29897391bd7f1aca4aa90dae926b2a1d537 matches exact XML, parsed cases and RESULT.

All three batches preserve independent full-SHA evidence and pass byte-integrity checks: source before/after/copied manifest 503 hashes agree; each packed executed-source member matches SHA256 and the exact Git blob at that batch SHA; both source/fixture tar archives match size/hash and every regular file plus symlink target. No SQLite was opened. The old failures were not rewritten.

Earlier d94c773e1ddd1fff4568b5e9f1d91a63d6fb5d2c batch remains 15 PASS, 2 FAIL, 1 INTERRUPTED, RC2: normal Cold failed RUNNING vs SUCCEEDED; source_revoke fault reached injection and sent-once assertion, then failed KeyError reading the scope-denied HTTP error as a normal status. The requested single SIGINT receipt and KeyboardInterrupt stdout are present. XML records 17 completed cases (15P2F); interrupted is separately recorded in RESULT. Remaining Cold fault cases must not be counted passed or completed.

Earlier 4464486a6d4674c6cc5ce78c8b99d3d5892d5df1 source batch remains 13 PASS, 1 FAIL, RC1 at original limits_mutation; -x prevented the eight internal cases from running in that batch. Passing a027 results do not alter this failed history.

The subsequent normal-Cold/trial/fault batch has not been accepted or attributed success in this review. Source 22 PASS establishes only these completed Source/cache/origin cases, not Cold recovery or product acceptance. No new tests, SQL, API or observation were executed by the reviewer.
