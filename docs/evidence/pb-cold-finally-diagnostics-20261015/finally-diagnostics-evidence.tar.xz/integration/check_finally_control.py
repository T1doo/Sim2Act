"""Execute the exact test-only control block with a one-call stub; no Worker or business success simulation."""
import ast
import hashlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace

from sim2act.errors import DomainError

R = Path('/workspace/Sim2Act-pa-provider')
B = Path('/workspace/pb-cold-finally-diagnostics-evidence-20261015')
p = R / 'tests/test_pb_trial_dispatch.py'
tree = ast.parse(p.read_text())
fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef)
    and n.name == 'test_pb_cold_actual_failure_never_accepts_or_retries')
start = next(i for i, n in enumerate(fn.body) if isinstance(n, ast.Assign)
    and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'once_result')
stop = next(i for i in range(start, len(fn.body)) if isinstance(fn.body[i], ast.Try))
body = fn.body[start:stop + 1]
# Preserve the actual nested nonlocal binding by compiling it inside a function.
block = ast.FunctionDef(name='run_block', args=ast.arguments(posonlyargs=[], args=[],
    kwonlyargs=[], kw_defaults=[], defaults=[]), body=body, decorator_list=[])
module = ast.fix_missing_locations(ast.Module(body=[block], type_ignores=[]))
code = compile(module, str(p) + ':exact-diagnostic-control-block', 'exec')
results = []
for case in ('true', 'false', 'domain', 'lost', 'unexpected_runtime', 'false_write_error', 'true_write_error'):
    out = B / 'control' / case
    out.mkdir(parents=True, exist_ok=False)
    calls = []

    def once():
        calls.append(1)
        if case == 'domain':
            raise DomainError('VERSION_CONFLICT', 'Synthetic public exception control')
        if case in ('lost', 'unexpected_runtime'):
            raise RuntimeError('Explicit lost P-B response')
        return case not in ('false', 'false_write_error')

    class BrokenPath:
        def __truediv__(self, name):
            return self

        def write_text(self, value):
            raise OSError('Synthetic diagnostic write failure')

    env = dict(worker=SimpleNamespace(once=once), monkeypatch=SimpleNamespace(setattr=setattr),
        DomainError=DomainError, sys=sys, json=json, fault='lost_response' if case == 'lost' else 'source_revoke',
        injected=[], sent=[], public_errors=[],
        tmp_path=BrokenPath() if case.endswith('write_error') else out)
    exec(code, env)
    error = None
    try:
        env['run_block']()
    except BaseException as caught:
        error = caught
    assert calls == [1]
    expected = 'AssertionError' if case in ('false', 'unexpected_runtime', 'false_write_error') else 'OSError' if case == 'true_write_error' else None
    assert (type(error).__name__ if error else None) == expected
    receipt = json.loads((out / 'actual-dispatch-boundary.json').read_text()) if not case.endswith('write_error') else None
    if receipt is not None:
        expected_return = None if case in ('domain', 'lost', 'unexpected_runtime') else case == 'true'
        assert receipt['worker_once_return'] is expected_return
        assert (receipt['escaped_domain_error'] or {}).get('code') == ('VERSION_CONFLICT' if case == 'domain' else None)
    if case == 'false_write_error':
        assert error.__notes__ == ['Dispatch receipt write failed: OSError']
    results.append(dict(case=case, calls=1, expected_exception=expected,
        actual_exception=type(error).__name__ if error else None,
        notes=getattr(error, '__notes__', []), receipt=receipt, passed=True))
x = dict(scope='Synthetic exact test control-block verification only; not Worker/model/acceptance coverage',
    source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(), pass_count=len(results), results=results)
(B / 'CONTROL_RESULT.json').write_text(json.dumps(x, indent=2) + '\n')
print(json.dumps(x))
