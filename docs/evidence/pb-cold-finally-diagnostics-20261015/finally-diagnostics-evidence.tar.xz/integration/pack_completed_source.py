"""Lossless executed-source packing only after the bounded test process has exited."""
import argparse
import hashlib
import json
import shutil
import tarfile
from pathlib import Path

base = Path('/workspace/pb-cold-finally-diagnostics-evidence-20261015/observation')
parser = argparse.ArgumentParser()
parser.add_argument('name')
args = parser.parse_args()
assert all(c.isalnum() or c in '-_' for c in args.name)
out = base / args.name
assert (out / 'RESULT.json').exists() and (out / 'PROCESS_EXIT.json').exists()
root = out / 'executed-source'
assert root.is_dir()
files = {str(p.relative_to(root)): dict(size=p.stat().st_size,
    sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in root.rglob('*')
    if p.is_file() and not p.is_symlink()}
links = {str(p.relative_to(root)): str(p.readlink()) for p in root.rglob('*') if p.is_symlink()}
archive = out / 'executed-source.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as tar:
    tar.add(root, arcname='executed-source')
with tarfile.open(archive, 'r:gz') as tar:
    members = {str(Path(m.name).relative_to('executed-source')): m for m in tar.getmembers() if m.isfile()}
    assert set(members) == set(files)
    for name, member in members.items():
        data = tar.extractfile(member).read()
        assert len(data) == files[name]['size']
        assert hashlib.sha256(data).hexdigest() == files[name]['sha256']
    assert {str(Path(m.name).relative_to('executed-source')): m.linkname for m in tar.getmembers() if m.issym()} == links
receipt = dict(policy='Losslessly packed exited source tree; every regular file byte and symbolic link verified before removing only the unpacked copy',
    archive='executed-source.tar.gz', size=archive.stat().st_size,
    sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), files=files, symlinks=links)
(out / 'PACKED_EXECUTED_SOURCE.json').write_text(json.dumps(receipt, indent=2) + '\n')
shutil.rmtree(root)
print(json.dumps({k: v for k, v in receipt.items() if k not in ('files', 'symlinks')}))
