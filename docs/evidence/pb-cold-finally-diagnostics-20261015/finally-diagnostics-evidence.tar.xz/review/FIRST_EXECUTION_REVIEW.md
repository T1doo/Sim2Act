# First ordered reproduction evidence review

Verified actual 013c25a0be938b6bfb0161a3f42afa235af1f89e result: 0 PASS / 0 FAIL / 1 setup ERROR, RC1, elapsed 201.291355s. Exact XML e8153e61ea5f6f84ab448e3f4eb2f0d068740a7c4a7a5477be7e058aa6def9fe contains the Source prerequisite assertion RUNNING != SUCCEEDED. All 21 selected bodies are NOT RUN; original Cold fault was not reached. This does not establish the old Cold root cause.

All 503 before/after/copied source hashes, exact Git blobs, packed source/fixture member bytes/links and archive hashes verify. No SQLite was opened.

Both public exports (prior a027 failure and current first setup error) exactly equal saved original XML and parsed error text with only host, generated IDs, memory pointers, evidence roots and synthetic token substituted. Receipt hashes agree and every error/traceback line is retained; original bytes remain present. No assertion/message/result/count/duration deletion was performed by the exporter.

CONTROL_RESULT records seven successful synthetic control-block checks with expected exception types and one synthetic call each. Its exact source hash matches 013c and the diagnostic fault function AST matches the final 4f7ed820 source. This covers only synthetic diagnostic control flow, not actual Worker/Source/Cold acceptance, and not the new prefix wrapper.

No tests, SQL, API or new observation were executed by this reviewer. The second ordered run remains independent and unaccepted by this review. Only review files were written; production source and existing evidence were untouched. Product remains NOT_ACCEPTED.
