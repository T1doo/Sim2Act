# Initial static review of finally diagnostics

All original fault assertions retain exact AST and source order; other module AST and product src/pyproject are unchanged. The wrapper calls the original bound Worker.once once and returns exactly its result. Direct DomainError remains caught as before; only its public dictionary is now recorded. Normal RuntimeError handling/assertion remains identical. No extra business SQL, send, guard, timer or lease change is present.

Concrete exception propagation caveat: finally write_text/json serialization can raise and mask an original AssertionError or escaping RuntimeError. Thus unconditional original-error transparency is not yet established for failed diagnostic IO. Suggested narrow correction is to prevent receipt IO/serialization errors from replacing the original exception, preserving their diagnostic failure separately if available. No source was edited by reviewer. Existing parent source is the sole writer.

This review used static AST/Git/hash inspection only; no test, SQL, API or new observation was executed. Candidate hash and exact original assertion count are in the JSON record.
