"""Derive scalar attribution only from the completed passive reader probe."""
import collections
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PROBE = ROOT / "baseline-first-only"
COST = PROBE / "callsite-cost"


def read(path):
    return json.loads(path.read_text())


sites = {row["site_id"]: row for row in read(COST / "caller-sites.json")}
calls = [json.loads(line) for line in (COST / "calls.jsonl").read_text().splitlines()]
by_id = {row["call_id"]: row for row in calls}
metrics = {}
checks = collections.defaultdict(list)
for row in calls:
    metric = metrics.setdefault(row["label"], dict(count=0, returned=0, exceptions=0,
        wall_inclusive_ns=0, cpu_inclusive_ns=0,
        cpu_instrumented_child_exclusive_ns=0, returned_bytes_total=0,
        returned_bytes_min=None, returned_bytes_max=None, hash_input_bytes_total=0))
    metric["count"] += 1
    metric["returned"] += int(row["returned"])
    metric["exceptions"] += int(not row["returned"])
    for field in ("wall_inclusive_ns", "cpu_inclusive_ns",
                  "cpu_instrumented_child_exclusive_ns"):
        metric[field] += row[field]
    size = row.get("returned_bytes_len")
    if size is not None:
        metric["returned_bytes_total"] += size
        for field, select in (("returned_bytes_min", min), ("returned_bytes_max", max)):
            metric[field] = size if metric[field] is None else select(metric[field], size)
    metric["hash_input_bytes_total"] += row.get("hash_input_bytes_len") or 0
    if row["label"] == "CGR.check":
        stack = tuple((sites[i]["filename"], sites[i]["qualname"], sites[i]["lineno"])
            for i in row["stack_site_ids"] if "caller_cost_tap.py" not in sites[i]["filename"])
        checks[stack[:5]].append(row)

attribution = []
for stack, rows in checks.items():
    attribution.append(dict(stack=[dict(filename=f, qualname=q, lineno=line)
        for f, q, line in stack], count=len(rows),
        cpu_inclusive_ns=sum(row["cpu_inclusive_ns"] for row in rows),
        cpu_instrumented_child_exclusive_ns=sum(
            row["cpu_instrumented_child_exclusive_ns"] for row in rows)))
attribution.sort(key=lambda row: -row["cpu_inclusive_ns"])

# Link lengths of ORIGINAL returned bytes to their original check/add ancestor.
# No product value is loaded, serialized, compared or hashed by this analysis.
sizes = []
for row in calls:
    if row["label"] != "CGR.input_bytes":
        continue
    parent = by_id.get(row["parent_call_id"])
    owner = by_id.get(parent["parent_call_id"]) if parent else None
    sizes.append(dict(input_bytes_call_id=row["call_id"],
        key_call_id=parent["call_id"] if parent else None,
        enclosing_call_id=owner["call_id"] if owner else None,
        enclosing_label=owner["label"] if owner else None,
        returned_bytes_len=row.get("returned_bytes_len")))

parent, child = read(PROBE / "parent-result.json"), read(PROBE / "child-result.json")
result = dict(classification="BOUNDED_BASELINE_ATTRIBUTION_NO_PRODUCT_CHANGE_NO_ACCEPTANCE",
    source_head="f9dfcf319b1a5bd66246aaa07a4dd0a082d1bd98",
    producer_invocations=child["producer_invocations"], outcome=child["outcome"],
    parent={key: parent[key] for key in ("exit_code", "timed_out", "wall_seconds",
        "owned_child_running", "source_unchanged", "source_db_unchanged", "copied_db_unchanged",
        "source_db_sha256_before", "source_db_sha256_after", "copied_db_sha256_before",
        "copied_db_sha256_after")},
    sql_counts=child["sql_counts"], blocked=child["blocked"],
    observer_errors=child["observer_errors"], secondary_errors=child["secondary_errors"],
    dropped_records=child["dropped_records"], metrics=metrics,
    check_stack_attribution=attribution, graph_bytes_by_call=sizes,
    notes=["Exclusive subtracts instrumented child body intervals only; observer overhead remains.",
        "Inclusive metrics nest and byte volumes overlap. They are not unique data volume.",
        "A fresh read pin over existing synthetic rows is not a new G3/Source2/Cold run.",
        "No product edits, candidate first-proof measurement, full retry, W5, G1 or finalguard occurred.",
        "The old full-run 37.52s and this reader probe are different fixtures/instrumentation; no performance delta is inferred.",
        "Every CGR.check invokes one input_key; 130 add repins plus one constructor account for the other 131.",
        "No safe substantial high-frequency scan merge has been proved. Preserve FAIL_NOT_ACCEPTED."])
(ROOT / "ANALYSIS.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(dict(labels={key: row["count"] for key, row in metrics.items()},
    analysis_sha256=hashlib.sha256((ROOT / "ANALYSIS.json").read_bytes()).hexdigest())))
