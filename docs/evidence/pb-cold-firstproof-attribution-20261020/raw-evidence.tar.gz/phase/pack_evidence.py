"""Package this phase only; verify every archived byte against the manifest."""
import hashlib
import io
import json
from pathlib import Path
import tarfile


ROOT = Path(__file__).resolve().parent
DEST = Path('/workspace/Sim2Act/docs/evidence/pb-cold-firstproof-attribution-20261020')
DESIGN = Path('/tmp/pb-cold-callsite-firstprobe-20261020')
REVIEWS = Path('/workspace/pb-cold-graph-integration-review-20261019')
V16 = REVIEWS / 'v16-f9df-firstproof-causal-slices'
V17 = REVIEWS / 'v17-firstproof-attribution-terminal'
HELPER = Path('/tmp/pb-cold-repeat-diagnostic-v4-20261020/repeat_cold_first_binding_v4.py')
EXPECTED_HELPER = '1714d223e667948a1d84a54abfdb8e35f2670c6384fc162581105da775cf6d8a'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


assert V17.is_dir(), 'Final independent fact report must exist before packing'
assert digest(HELPER.read_bytes()) == EXPECTED_HELPER
archive = DEST / 'raw-evidence.tar.gz'
manifest_path = DEST / 'ARCHIVE-MANIFEST.json'
assert not archive.exists() and not manifest_path.exists(), 'Never overwrite a sealed pack'
payload = []
for base, prefix in ((ROOT, 'phase'), (DESIGN, 'probe-design'),
                     (V16, 'review/v16'), (V17, 'review/v17')):
    for path in sorted(base.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            if path.name == 'PACKING-VERIFICATION.json':
                continue
            payload.append((path, prefix + '/' + path.relative_to(base).as_posix()))
payload.append((HELPER, 'source-helper/' + HELPER.name))
items = []
with tarfile.open(archive, 'w:gz', compresslevel=9) as output:
    for path, name in payload:
        raw = path.read_bytes()
        info = tarfile.TarInfo(name)
        info.size = len(raw)
        info.mode = 0o644
        output.addfile(info, io.BytesIO(raw))
        items.append(dict(path=name, original_path=str(path), bytes=len(raw), sha256=digest(raw)))
manifest = dict(classification='BOUNDED_BASELINE_FIRSTPROOF_RAW_EVIDENCE_NO_ACCEPTANCE',
    source_head='f9dfcf319b1a5bd66246aaa07a4dd0a082d1bd98',
    archive=archive.name, archive_bytes=archive.stat().st_size,
    archive_sha256=digest(archive.read_bytes()), file_count=len(items),
    raw_bytes=sum(item['bytes'] for item in items), files=items)
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
by_name = {item['path']: item for item in items}
verified = []
with tarfile.open(archive, 'r:gz') as packed:
    assert set(packed.getnames()) == set(by_name)
    for member in packed.getmembers():
        raw = packed.extractfile(member).read()
        item = by_name[member.name]
        assert len(raw) == item['bytes'] and digest(raw) == item['sha256']
        assert digest(Path(item['original_path']).read_bytes()) == item['sha256']
        verified.append(member.name)
record = dict(archive_sha256=manifest['archive_sha256'],
    manifest_sha256=digest(manifest_path.read_bytes()), files_readback_verified=len(verified),
    originals_unchanged=True, exact_archive_inventory=True, file_count=len(items),
    archive_bytes=manifest['archive_bytes'], raw_bytes=manifest['raw_bytes'])
(ROOT / 'PACKING-VERIFICATION.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
