# Single dormant first-binding callsite probe

The two executable probe files are frozen. This agent ran only the explicitly authorized stdlib fake selftests: **3 PASS, 0 failures/errors**, in 0.018 seconds. Product/pytest/SQLAlchemy/httpx/DB imports and network/DB/subprocess actions were guarded; both blocked-actions and remaining-forbidden-module lists are empty. This agent did not import/execute the product, inspect a database, launch the reader probe, run a Worker/model/Cold, edit the repository, or run a full-PB test.

## Archived evidence: known and missing

`archive-known-unknown.json` records the exact archive paths, metrics, and source bridge. The archived runtime and GA bytes both match Git `f9dfcf319b1a5bd66246aaa07a4dd0a082d1bd98`.

The existing full observer has phase/function aggregates, not caller sites, call IDs, per-call returned lengths, or raw call stacks. It did not instrument CGR.add or GA reader record/check/raw-seed check. G0 measured CGR.check 2,048 times (25.269 CPU seconds inclusive / 0.345 exclusive), input_key 2,183 (26.742 / 0.357), input_bytes 2,183 (24.974 / 7.207), codec.bytes 2,195 (17.871 / 17.871), and validator 137 (4.496 / 4.480). These nested inclusive values must not be added.

`581,208,365` bytes is the accumulated length of 2,183 original input_bytes returns. It is neither one graph's size nor unique data. The codec's `585,174,551` bytes and SHA input bytes overlap this stream. The archive does not preserve size min/max, growth per version, or enough detail to attribute each full check to GA record's first check, guard.add's check/re-pin, GA record's final check, or a raw-seed checkpoint. First binding returned once; G0 then failed before W5/G1/finalguard. No successful full graph/lease conclusion follows.

## Frozen inputs

- `caller_cost_tap.py`: SHA256 `70cb63bf874268352d105e575a2a0ba70ac097236f08899059e35053147766f2`
- `first_probe.py`: SHA256 `7dfd84b1611dab3d9cb3e6ce3690ebcab6d51a3353257fb0a37ce238a65ee57f`
- `selftest_stdlib.py`: SHA256 `382c3e2cc2418c714d0173c0750909d1c44c0cc358161b725caab09b0141b68f`
- Existing read-pin helper: `/tmp/pb-cold-repeat-diagnostic-v4-20261020/repeat_cold_first_binding_v4.py`, fixed SHA256 `1714d223e667948a1d84a54abfdb8e35f2670c6384fc162581105da775cf6d8a`. Only its existing derive_pin setup is reused; no old parent/child loop, facets, public oracle, ModelRead replay, or repeat machinery is invoked.

## Root-only execution

Root reserves the one authorized baseline invocation. Use an output that does not exist and a closed, stable, current-environment queued-Cold plain-prefix DB. Existing WAL/journal sidecars cause refusal. Only that DB is copied; no source tree/bundle or other environment is copied. The helper refuses a processed Cold or any different identified fixture.

```sh
/workspace/sim2act-venv/bin/python /tmp/pb-cold-callsite-firstprobe-20261020/first_probe.py \
  --db /workspace/pb-cold-graph-integration-20261019/first-binding-fresh-v4-tmp/test_plain_pb_first_binding_pr0/plain-prefix.db \
  --out /workspace/pb-cold-graph-integration-20261019/first-attributed-baseline-90 \
  --runtime-sha256 3e14d121497d381d972cb08a1a3b19b03e65acfad6276e3e679aa66801366221 \
  --ga-sha256 94a7b351ff3d9d0f0ef78f61288268e78c67d2ba92717f418e7fc61ce4e712ec \
  --timeout 90
```

The timeout is constrained to 15..120 seconds, with no retry or repeat option. The parent starts one session/process and signals only that known group on timeout. The child makes one explicit `_cold_first_binding` call. Its wrapper counts attempted invocations and rejects a second before entering the original. No Worker construction/claim/process, model/Mock/HTTP, approval/journal/admission, public full-ancestor verifier, facet, settlement, or Cold processing is allowed. The graph's original scope exit checks still run and are labeled separately.

The setup uses the existing helper's actual-row reads and synthetic unapproved continuity pin, outside active cost capture. That setup is not new G3/Source2 evidence or trial authority. Instrumentation adds no product query, serialization, hash, validation, comparison, or selected successful replacement. SQL interception only counts existing statements and rejects writes. Platform/role limits are the existing values; no lease, run budget, allowance, RPM or approval is changed.

## Interpreting records

`callsite-cost/calls.jsonl` contains one completion row per tapped original call, with unique `call_id`, `parent_call_id`, thread, phase, original-callee inclusive and direct-tapped-child-exclusive CPU/wall nanoseconds, actual caller site and bounded code/line stack IDs, original-returned byte length where applicable, and original SHA constructor buffer length where applicable. `caller-sites.json` resolves site IDs to filename/qualname/first line/current line. Capturing callers reads only `f_code` and `f_lineno`; there is no f_locals/f_globals/f_back or product repr/value traversal.

The tapped labels cover producer, CGR check/add/input_key/input_bytes, original codec/validator, runtime checkpoints, GA reader record/check, GA raw-seed check, trial typed storage, and original nested SHA constructors. Use parent IDs to attach each original input_bytes length to its input_key/check/add/GA ancestor. Initial graph construction precedes the producer and is outside its call-ID subtree. `ORIGINAL_SCOPE_EXIT_ONLY` distinguishes the original closing checks from producer-body calls.

The observer adds frame capture, locks, scalar records and evidence IO. Its caller/recording overhead can remain inside ancestors' exclusive intervals; its periodic thread can add CPU/IO contention and wall delay. This is causal attribution under observation, not uninstrumented timing, a full-PB performance pass, or authorization evidence. Nested bytes overlap. Dropped rows or observer errors invalidate complete attribution.

## Raw output

Keep the entire chosen output directory:

- `command.json`, `checkpoint-before-child.json`, `checkpoint-before-producer.json`
- `stdout.txt`, `stderr.txt`, `stacks-15s.txt`
- `callsite-cost/calls.jsonl`, `caller-sites.json`, `summary-current.json` (periodically refreshed every 15 seconds, then final)
- `child-result.json`, `parent-result.json`
- `prefix-copy.db` and any sidecars; original source DB is never opened by the child
- unchanged helper setup facts in `existing-prefix-and-synthetic-read-pin.json`

Parent receipts preserve full selected source hashes and original/copy DB file hashes before/after. Hard timeout can leave partial completion rows or no child result; open-call IDs and stacks then remain evidence of incompleteness. Do not classify that as a complete cost pass. No JUnit is expected because this is not a pytest run.

The stdlib selftest raw evidence is `selftest-command.log`, `selftest.log`, `selftest.json`, and `selftest-evidence/*/{calls.jsonl,caller-sites.json,summary-current.json}`. `manifest.json` seals hashes and the actual fake-test command. There is no authorization here for a second producer or another full chain.
