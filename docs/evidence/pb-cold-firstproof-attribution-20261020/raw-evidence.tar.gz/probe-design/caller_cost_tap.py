"""Passive callsite cost tap. Imports stdlib only; never starts a product call.

Only original callee calls/returned bytes and caller f_code/f_lineno are observed.
No product input dump, repr, comparison, serialization, fingerprint, query or
validation is added. Original returned objects and exceptions retain identity.
"""
from functools import wraps
import json
from pathlib import Path
import sys
import threading
import time


class CallerCostTap:
    def __init__(self, folder, stack_depth=10, max_records=100000):
        self.folder = Path(folder)
        self.depth = stack_depth
        self.max_records = max_records
        self.lock = threading.RLock()
        self.local = threading.local()
        self.saved = []
        self.active = False
        self.phase = 'INACTIVE'
        self.next_id = 0
        self.records = []
        self.sites = []
        self.site_index = {}
        self.errors = []
        self.dropped_records = 0
        self.producer_attempts = 0
        self.threads = {}

    def _error(self, where, error):
        try:
            with self.lock:
                self.errors.append(dict(where=where, error_type=type(error).__name__))
        except BaseException:
            pass

    def _state(self):
        if not hasattr(self.local, 'stack'):
            self.local.stack = []
            with self.lock:
                self.threads[threading.get_ident()] = self.local.stack
        return self.local.stack

    def _site_ids(self):
        # _site_ids -> observer wrapper -> actual caller. No f_locals, f_globals,
        # f_back, inspect.stack, traceback formatting, or product value access.
        result = []
        for depth in range(2, self.depth + 2):
            try:
                frame = sys._getframe(depth)
            except ValueError:
                break
            try:
                code, line = frame.f_code, frame.f_lineno
                site = (code.co_filename, code.co_qualname, code.co_firstlineno, line)
                with self.lock:
                    number = self.site_index.get(site)
                    if number is None:
                        number = len(self.sites)
                        self.site_index[site] = number
                        self.sites.append(dict(site_id=number, filename=site[0],
                            qualname=site[1], firstlineno=site[2], lineno=site[3]))
                result.append(number)
            finally:
                del frame
        return result

    def install(self, target, name, label, *, returned_bytes=False,
                hash_input=False, nested_only=False, single_producer=False):
        original = getattr(target, name)

        @wraps(original)
        def measured(*args, **kwargs):
            stack = self._state()
            if not self.active or (nested_only and not stack):
                return original(*args, **kwargs)
            # This is a harness limit, not a product admission or fallback.
            # A second attempted producer is blocked before invoking it.
            if single_producer:
                with self.lock:
                    self.producer_attempts += 1
                    if self.producer_attempts != 1:
                        raise AssertionError('Probe permits one _cold_first_binding invocation only')
            try:
                sites = self._site_ids()
            except BaseException as error:
                self._error('caller-sites:' + label, error)
                sites = []
            with self.lock:
                self.next_id += 1
                call_id = self.next_id
            parent = stack[-1] if stack else None
            frame = dict(call_id=call_id, label=label, child_wall_ns=0, child_cpu_ns=0)
            stack.append(frame)
            begin_wall, begin_cpu = time.monotonic_ns(), time.thread_time_ns()
            result, returned, error_type = None, False, None
            try:
                result = original(*args, **kwargs)  # Original executes exactly once.
                returned = True
                return result
            except BaseException as error:
                error_type = type(error).__name__
                raise
            finally:
                elapsed_wall = time.monotonic_ns() - begin_wall
                elapsed_cpu = time.thread_time_ns() - begin_cpu
                try:
                    stack.pop()
                    if parent is not None:
                        parent['child_wall_ns'] += elapsed_wall
                        parent['child_cpu_ns'] += elapsed_cpu
                    row = dict(call_id=call_id, parent_call_id=parent['call_id'] if parent else None,
                        thread_id=threading.get_ident(), phase=self.phase, label=label,
                        caller_site_id=sites[0] if sites else None, stack_site_ids=sites,
                        returned=returned, error_type=error_type,
                        wall_inclusive_ns=elapsed_wall, cpu_inclusive_ns=elapsed_cpu,
                        wall_instrumented_child_exclusive_ns=elapsed_wall-frame['child_wall_ns'],
                        cpu_instrumented_child_exclusive_ns=elapsed_cpu-frame['child_cpu_ns'])
                    if returned_bytes and returned:
                        row['returned_bytes_len'] = len(result) if type(result) is bytes else None
                    if hash_input:
                        data = args[0] if args else kwargs.get('string', kwargs.get('data', b''))
                        row['hash_input_bytes_len'] = (
                            len(data) if type(data) in (bytes, bytearray)
                            else data.nbytes if type(data) is memoryview else None)
                    with self.lock:
                        if len(self.records) < self.max_records:
                            self.records.append(row)
                        else:
                            self.dropped_records += 1
                except BaseException as error:
                    self._error('callee-finally:' + label, error)

        self.saved.append((target, name, original, measured))
        setattr(target, name, measured)

    def summary(self):
        with self.lock:
            records = list(self.records)
            opened = {str(tid): [dict(call_id=f['call_id'], label=f['label']) for f in stack]
                      for tid, stack in self.threads.items()}
            errors, dropped = list(self.errors), self.dropped_records
        table = {}
        for row in records:
            # A caller-site number resolves only to observer-owned source fields.
            key = row['phase'] + '::' + row['label'] + '::caller=' + str(row['caller_site_id'])
            item = table.setdefault(key, dict(count=0, returned=0, exceptions=0,
                wall_inclusive_ns=0, cpu_inclusive_ns=0,
                wall_instrumented_child_exclusive_ns=0,
                cpu_instrumented_child_exclusive_ns=0, returned_bytes_total=0,
                returned_bytes_min=None, returned_bytes_max=None, hash_input_bytes_total=0))
            item['count'] += 1
            item['returned'] += int(row['returned'])
            item['exceptions'] += int(not row['returned'])
            for field in ('wall_inclusive_ns', 'cpu_inclusive_ns',
                          'wall_instrumented_child_exclusive_ns', 'cpu_instrumented_child_exclusive_ns'):
                item[field] += row[field]
            size = row.get('returned_bytes_len')
            if size is not None:
                item['returned_bytes_total'] += size
                item['returned_bytes_min'] = size if item['returned_bytes_min'] is None else min(item['returned_bytes_min'], size)
                item['returned_bytes_max'] = size if item['returned_bytes_max'] is None else max(item['returned_bytes_max'], size)
            item['hash_input_bytes_total'] += row.get('hash_input_bytes_len') or 0
        return dict(classification='PASSIVE_CALLSITE_TAP_NOT_FULL_PB_OR_AUTHORITY',
            phase=self.phase, completed_calls=len(records), open_calls=opened,
            producer_attempts=self.producer_attempts, max_records=self.max_records,
            dropped_records=dropped, observer_errors=errors, by_label_and_caller=table,
            timing_definition='Inclusive original-callee body wall/thread CPU; exclusive subtracts immediate tapped child-body intervals only. Caller capture/recording overhead remains in ancestors, and IO/thread contention can increase wall. Not uninstrumented performance.',
            byte_definition='Only length of original returned bytes / original SHA constructor buffer. Nested byte volumes overlap; each row is a call, not a unique graph. No extra product dump/hash/SQL.')

    def persist(self, final=False):
        # Serializes observer-owned scalar rows, never product inputs/results.
        self.folder.mkdir(parents=True, exist_ok=True)
        (self.folder / 'summary-current.json').write_text(json.dumps(self.summary(), indent=2) + '\n')
        with self.lock:
            records, sites = list(self.records), list(self.sites)
        if final:
            with (self.folder / 'calls.jsonl').open('w') as stream:
                for row in records:
                    stream.write(json.dumps(row, separators=(',', ':')) + '\n')
            (self.folder / 'caller-sites.json').write_text(json.dumps(sites, indent=2) + '\n')

    def restore(self):
        self.active = False
        for target, name, original, replacement in reversed(self.saved):
            if getattr(target, name) is replacement:
                setattr(target, name, original)


def install_narrow_taps(tap, runtime, ga, admission, hashlib_module):
    for target, name, label, byte_return in [
        (runtime, '_cold_first_binding', 'producer.first_binding', False),
        (runtime._ColdGraphRead, 'check', 'CGR.check', False),
        (runtime._ColdGraphRead, 'add', 'CGR.add', False),
        (runtime._ColdGraphRead, 'input_key', 'CGR.input_key', False),
        (runtime._ColdGraphRead, 'input_bytes', 'CGR.input_bytes', True),
        (runtime, '_cold_read_checkpoint', 'runtime.checkpoint', False),
        (runtime, '_cold_graph_bytes', 'codec.bytes', True),
        (runtime, '_cold_graph_validate_inputs', 'codec.validate', False),
        (runtime, '_cold_graph_inputs', 'codec.inputs', False),
        (ga._GenerationFactsReader, 'check', 'GA.reader.check', False),
        (ga._GenerationFactsReader, 'record', 'GA.reader.record', False),
        (ga._ColdGenerationRawSeed, 'check', 'GA.raw_seed.check', False),
        (admission, '_trial_typed_storage', 'trial.typed_storage', False),
    ]:
        tap.install(target, name, label, returned_bytes=byte_return,
                    single_producer=label == 'producer.first_binding')
    # Only tap actual SHA constructor calls while one of the above bodies is
    # active; file/source evidence hashes occur outside this active window.
    tap.install(hashlib_module, 'sha256', 'hash.sha256_constructor',
                hash_input=True, nested_only=True)
