#!/usr/bin/env python3
"""ONE bounded dormant first-binding reader over one existing queued-Cold DB.

Design artifact only until root explicitly executes it. No pytest/fixture/Worker
process/model/Cold/approval/settlement is started. Existing current-environment
G3/Source2 rows are reused and MUST NOT be reclassified as new stage evidence.
"""
import argparse
import faulthandler
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import threading
import time


HERE = Path(__file__).resolve().parent
HELPER = Path('/tmp/pb-cold-repeat-diagnostic-v4-20261020/repeat_cold_first_binding_v4.py')
HELPER_SHA256 = '1714d223e667948a1d84a54abfdb8e35f2670c6384fc162581105da775cf6d8a'
SCOPE = 'ONE dormant first-binding pure reader; existing synthetic G3/Source2 reused; no new stages, Cold, model, authority or settlement'


def sha(path):
    # Harness evidence files only, never called inside an active product tap.
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n')


def source_facts(repo):
    paths = list((repo / 'src/sim2act').rglob('*.py'))
    paths += [p for p in (repo / 'schemas').rglob('*') if p.is_file()]
    paths.append(repo / 'pyproject.toml')
    return {str(p.relative_to(repo)): sha(p) for p in sorted(set(paths))}


def load_helper():
    if sha(HELPER) != HELPER_SHA256:
        raise RuntimeError('Existing read-pin helper changed; no producer call allowed')
    spec = importlib.util.spec_from_file_location('existing_read_pin_helper', HELPER)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)  # Stdlib-only helper import; derive_pin called explicitly later.
    return module


def child(args):
    out, repo = Path(args.out).resolve(), Path(args.repo).resolve()
    db = out / 'prefix-copy.db'
    expected = json.loads((out / 'checkpoint-before-child.json').read_text())
    if source_facts(repo) != expected['source_facts_before']:
        raise RuntimeError('Source changed before child imports')
    if sha(HERE / 'caller_cost_tap.py') != expected['tap_sha256']:
        raise RuntimeError('Tap changed before child imports')
    sys.path.insert(0, str(repo / 'src'))
    # All product imports are lazy and occur only in this root-invoked child.
    import httpx
    from sqlalchemy import event
    from sim2act import app_jobs, apps, goal_applications as ga, lifecycle, text_apps
    from sim2act import natural_live_admission as admission
    from sim2act import natural_spec_runtime as runtime, natural_trial_budget as old_budget
    from sim2act import pa_spec_apps as spec, pa_trial_dispatch as dispatch
    from sim2act import pb_natural_specs as pb, pb_natural_uses as use
    from sim2act import production_trial_journal as journal, spec_production
    from sim2act.config import Settings
    from sim2act.contracts import Limits
    from sim2act.db import Store
    from sim2act.model import InternModel
    from sim2act.worker import Worker
    from caller_cost_tap import CallerCostTap, install_narrow_taps

    if Path(runtime.__file__).resolve() != repo / 'src/sim2act/natural_spec_runtime.py':
        raise RuntimeError('Wrong runtime import')
    helper = load_helper()
    tap = CallerCostTap(out / 'callsite-cost')
    patched, blocked, secondary = [], [], []
    sql_counts = {}
    done = threading.Event()
    stackfile = (out / 'stacks-15s.txt').open('w', buffering=1)
    faulthandler.enable(file=stackfile, all_threads=True)
    faulthandler.dump_traceback_later(15, repeat=True, file=stackfile)
    store = Store('sqlite:///' + str(db), test_only=True)
    settings = Settings('sqlite:///' + str(db), out, mode='mock')
    full = Limits(**{name: getattr(settings, name) for name in Limits.model_fields})
    result = dict(scope=SCOPE, outcome='INCOMPLETE', producer_invocations=0)

    def replace(target, name, value):
        original = getattr(target, name)
        patched.append((target, name, original, value))
        setattr(target, name, value)

    def block(target, names):
        for name in names:
            label = target.__name__ + '.' + name
            def denied(*args, _label=label, **kwargs):
                blocked.append(_label)
                raise AssertionError('Forbidden reader-probe path: ' + _label)
            replace(target, name, denied)

    def before_sql(conn, cursor, statement, parameters, context, executemany):
        op = statement.lstrip().split(None, 1)[0].upper()
        if op != 'SELECT' and statement.strip().upper() != 'BEGIN IMMEDIATE':
            blocked.append('NONREAD_SQL:' + op)
            raise AssertionError('Read-only probe rejects non-read SQL')
        key = tap.phase + '::' + op
        sql_counts[key] = sql_counts.get(key, 0) + 1
        # Count existing SQL only; do not execute a query or serialize parameters.

    def periodic():
        while not done.wait(15):
            try:
                tap.persist(final=True)  # Own scalar records only; partial evidence survives watchdog.
            except BaseException as error:
                secondary.append(dict(where='periodic-evidence', error_type=type(error).__name__))

    thread = threading.Thread(target=periodic, name='own-scalar-cost-observer', daemon=True)
    event.listen(store.engine, 'before_cursor_execute', before_sql)
    primary = None
    try:
        tap.phase = 'SETUP_EXISTING_READ_PIN'
        # The unchanged helper performs its existing row reads/contract checks.
        # This is setup outside active cost capture, not new G3/Source2 evidence.
        worker, current, facts = helper.derive_pin(store, settings, out)
        # No initialized Worker, claim, attempt, model, approval or journal path.
        block(Worker, ('once', 'process', 'reserve', 'finish', 'checkpoint', '_heartbeat_lease'))
        block(Store, ('claim',))
        block(InternModel, ('request', 'request_serialized', 'request_serialized_captured', '_request_serialized'))
        for target, names in [
            (admission, ('approve', 'approve_stage', '_approved', 'admit')),
            (spec_production, ('source', 'receive_source')),
            (journal, ('read', 'reserve', 'record_attempt', 'settle', '_apply_in_transaction')),
            (dispatch, ('_admission', '_account', 'preflight', 'reserved', 'request_captured',
                        'settle_verified', 'check_commit', 'check_journal_claim')),
        ]:
            block(target, names)
        for target, name in [(httpx.Client, 'send'), (httpx.AsyncClient, 'send'),
                            (httpx.HTTPTransport, 'handle_request'), (httpx.AsyncHTTPTransport, 'handle_async_request'),
                            (httpx.MockTransport, 'handle_request'), (httpx.MockTransport, 'handle_async_request')]:
            block(target, (name,))
        # Remember canonical originals before blocking, then close the known
        # prebound alias edges without introducing another product call.
        aliases = [('sim2act.lifecycle', 'validate_frozen_candidate', apps, 'validate_frozen_candidate'),
                   ('sim2act.app_jobs', 'validate_frozen_candidate', apps, 'validate_frozen_candidate'),
                   ('sim2act.app_jobs', 'read_release', lifecycle, 'read_release'),
                   ('sim2act.registered_run_extraction', 'read_release', lifecycle, 'read_release')]
        canonical_originals = {(id(owner), name): getattr(owner, name)
                               for _, _, owner, name in aliases}
        for target, names in [
            (ga, ('source', 'initial_messages', 'history', '_history', 'verified_candidate', '_verified_candidate', 'parse_candidate')),
            (spec, ('bound', '_bound', 'verify_job', 'receipts', 'verify_origin', 'model_source', 'audit_fingerprint', 'from_response')),
            (pb, ('source', '_source', 'source_audit', '_source_audit', 'review', 'verify', 'audit_fingerprint')),
            (use, ('bound', 'review', 'audit')),
            (apps, ('validate_frozen_candidate',)), (lifecycle, ('read_release', '_read_release')),
            (app_jobs, ('load_binding',)), (text_apps, ('verify_origin',)),
        ]:
            block(target, names)
        for module_name, alias, canonical, name in aliases:
            owner = sys.modules.get(module_name)
            if owner is not None and getattr(owner, alias) is canonical_originals[(id(canonical), name)]:
                replace(owner, alias, getattr(canonical, name))
        install_narrow_taps(tap, runtime, ga, admission, hashlib)
        write(out / 'checkpoint-before-producer.json', dict(scope=SCOPE,
            cold_run_id=current['id'], source_run_id=facts['source_run']['id'],
            generation_run_id=facts['generation_run']['id'], generation_attempts=3,
            source_attempts=2, cold_attempts=0, full_ancestor_tripwires=True,
            producer_call_limit=1, diagnostic_timeout=args.timeout, model_calls=0,
            no_extra_product_queries_or_serializations_from_observer=True))
        thread.start()
        tap.active = True
        tap.phase = 'G0_PLATFORM_FIRST_ONLY'
        with store.tx() as c, pb._source_reads(store, c):
            driver, trial = c.connection.driver_connection, admission._limits(worker.pa_trial.contract)
            changes = driver.total_changes
            roles = dict(source=full, generate=None, platform=full, trial=trial, per_use=full)
            with runtime._cold_graph_read(worker, c, dict(current=current), roles, 'pre') as guard:
                graph = runtime._cold_first_binding(worker, c, guard, current, full)  # Exactly one explicit invocation.
                result.update(producer_returned=True, active_guard_at_return=guard.active,
                              same_guard=graph.guard is guard)
                tap.phase = 'ORIGINAL_SCOPE_EXIT_ONLY'
            if driver.total_changes != changes or changes != 0:
                raise AssertionError('Original first reader changed copied DB')
        tap.active = False
        if tap.producer_attempts != 1 or tap.errors or tap.dropped_records or blocked:
            raise AssertionError('Incomplete/invalid single-producer observation')
        result.update(outcome='COMPLETE_READ_ONLY_SINGLE_PRODUCER_OBSERVATION',
                      producer_invocations=tap.producer_attempts)
    except BaseException as error:
        primary = error
        result.update(outcome='FAILED_OR_INCOMPLETE_READ_ONLY_OBSERVATION', error_type=type(error).__name__)
        raise
    finally:
        tap.active = False
        done.set()
        if thread.ident is not None:
            thread.join(timeout=2)
        for action, where in [(lambda: tap.restore(), 'tap-restore'),
                              (lambda: event.remove(store.engine, 'before_cursor_execute', before_sql), 'sql-observer-remove'),
                              (lambda: store.engine.dispose(), 'engine-dispose')]:
            try:
                action()
            except BaseException as error:
                secondary.append(dict(where=where, error_type=type(error).__name__))
        for target, name, original, replacement in reversed(patched):
            if getattr(target, name) is replacement:
                setattr(target, name, original)
        try:
            tap.persist(final=True)
            result.update(producer_invocations=tap.producer_attempts, sql_counts=sql_counts,
                          blocked=blocked, observer_errors=tap.errors, secondary_errors=secondary,
                          completed_calls=len(tap.records), dropped_records=tap.dropped_records)
            write(out / 'child-result.json', result)
        except BaseException as error:
            if primary is None:
                raise
            sys.stderr.write('SECONDARY_FINAL_EVIDENCE_ERROR:' + type(error).__name__ + '\n')
        finally:
            faulthandler.cancel_dump_traceback_later()
            stackfile.close()


def main():
    parser = argparse.ArgumentParser(description=SCOPE)
    parser.add_argument('--repo', default='/workspace/Sim2Act')
    parser.add_argument('--db', required=True, help='Existing current-environment queued-Cold plain-prefix.db only')
    parser.add_argument('--out', required=True, help='Must not exist; never removed or reused')
    parser.add_argument('--runtime-sha256', required=True)
    parser.add_argument('--ga-sha256', required=True)
    parser.add_argument('--timeout', type=int, default=90)
    parser.add_argument('--child', action='store_true', help=argparse.SUPPRESS)
    args = parser.parse_args()
    if not 15 <= args.timeout <= 120:
        raise ValueError('Exactly one subprocess, bounded 15..120 seconds; no retry')
    if args.child:
        child(args)
        return 0
    out, repo, source = Path(args.out).resolve(), Path(args.repo).resolve(), Path(args.db).resolve()
    out.mkdir(exist_ok=False)
    for suffix in ('-wal', '-journal'):
        if Path(str(source) + suffix).exists():
            raise RuntimeError('Use a closed stable DB; existing sidecar rejected without touching it')
    before_sources = source_facts(repo)
    if before_sources['src/sim2act/natural_spec_runtime.py'] != args.runtime_sha256:
        raise RuntimeError('Runtime source does not match root-provided freeze')
    if before_sources['src/sim2act/goal_applications.py'] != args.ga_sha256:
        raise RuntimeError('GA source does not match root-provided freeze')
    if sha(HELPER) != HELPER_SHA256:
        raise RuntimeError('Read-pin helper differs from reviewed existing script')
    initial_db = sha(source)
    copy = out / 'prefix-copy.db'
    shutil.copyfile(source, copy)  # One DB only; no source tree/bundle/evidence copy.
    if sha(copy) != initial_db:
        raise RuntimeError('Source DB changed while copying')
    record = dict(scope=SCOPE, source_db=str(source), source_db_sha256_before=initial_db,
        copied_db_sha256_before=sha(copy), source_facts_before=before_sources,
        script_sha256=sha(Path(__file__)), tap_sha256=sha(HERE / 'caller_cost_tap.py'),
        helper_sha256=HELPER_SHA256, timeout_seconds=args.timeout,
        periodic_stacks_and_scalar_snapshots_seconds=15, producer_call_limit=1)
    write(out / 'checkpoint-before-child.json', record)
    command = [sys.executable, str(Path(__file__).resolve()), *sys.argv[1:], '--child']
    record['command'] = command
    write(out / 'command.json', record)
    env = os.environ.copy()
    for key in ('SIM2ACT_TEST_DATABASE_URL', 'PYTEST_PLUGINS', 'PYTEST_ADDOPTS'):
        env.pop(key, None)
    env['PYTHONPATH'] = str(HERE) + ':' + str(repo / 'src')
    env['PYTHONUNBUFFERED'] = '1'
    code, process, timed_out, started = None, None, False, time.monotonic()
    try:
        with (out / 'stdout.txt').open('w') as stdout, (out / 'stderr.txt').open('w') as stderr:
            process = subprocess.Popen(command, cwd=out, env=env, stdout=stdout, stderr=stderr,
                                       start_new_session=True)
            record['owned_child_pid'] = process.pid
            write(out / 'command.json', record)
            try:
                code = process.wait(timeout=args.timeout)
            except subprocess.TimeoutExpired:
                timed_out = True
                for sig in (signal.SIGTERM, signal.SIGKILL):
                    try:
                        os.killpg(process.pid, sig)
                    except ProcessLookupError:
                        pass
                    try:
                        code = process.wait(timeout=5)
                        break
                    except subprocess.TimeoutExpired:
                        if sig == signal.SIGKILL:
                            raise
    finally:
        record.update(exit_code=code, timed_out=timed_out, wall_seconds=time.monotonic()-started,
                      owned_child_running=process is not None and process.poll() is None)
        after_sources = source_facts(repo)
        record.update(source_facts_after=after_sources, source_unchanged=after_sources == before_sources,
                      source_db_sha256_after=sha(source), copied_db_sha256_after=sha(copy))
        record['source_db_unchanged'] = record['source_db_sha256_after'] == initial_db
        record['copied_db_unchanged'] = record['copied_db_sha256_after'] == initial_db
        record['child_result_exists'] = (out / 'child-result.json').is_file()
        write(out / 'parent-result.json', record)
    return 1 if timed_out or not record['source_unchanged'] or not record['source_db_unchanged'] or not record['copied_db_unchanged'] else (code or 0)


if __name__ == '__main__':
    sys.exit(main())
