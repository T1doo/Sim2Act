"""Independent fake-only observer checks. Does not import/run the probe driver.

Execute only when authorized: python3 -I -S /abs/path/selftest_stdlib.py
Product/third-party/DB imports and network/DB/subprocess audit events are denied.
"""
import builtins
from collections import Counter
import importlib.util
import json
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest


ROOT = Path(__file__).resolve().parent
DENIED = {'sim2act', 'pytest', 'sqlalchemy', 'httpx', 'sqlite3', '_sqlite3', 'psycopg', 'psycopg2'}
blocked = []
original_import = builtins.__import__


def guarded_import(name, *args, **kwargs):
    if name.split('.')[0] in DENIED:
        blocked.append('import:' + name)
        raise AssertionError('Forbidden import: ' + name)
    return original_import(name, *args, **kwargs)


def audit(event, args):
    if event == 'import' and str(args[0]).split('.')[0] in DENIED:
        blocked.append('audit-import:' + str(args[0]))
        raise AssertionError('Forbidden import')
    if event in {'sqlite3.connect', 'socket.connect', 'socket.bind', 'socket.getaddrinfo',
                 'subprocess.Popen', 'os.system'}:
        blocked.append(event)
        raise AssertionError('Forbidden DB/network/subprocess action')


builtins.__import__ = guarded_import
sys.addaudithook(audit)
spec = importlib.util.spec_from_file_location('fake_only_caller_tap', ROOT / 'caller_cost_tap.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class FakeCallerTap(unittest.TestCase):
    def setUp(self):
        self.tap = module.CallerCostTap(ROOT / 'selftest-evidence' / self._testMethodName)
        self.tap.active = True
        self.tap.phase = 'FAKE'

    def tearDown(self):
        self.tap.persist(final=True)
        self.tap.restore()

    def test_nested_ga_record_check_add_original_once_callsites_bytes_and_cpu(self):
        counts = Counter()
        payload = b'complete fake graph bytes; never a product graph'
        marker = object()
        codec = SimpleNamespace()

        def encode():
            counts['codec'] += 1
            return payload

        codec.encode = encode

        class Graph:
            def input_bytes(self):
                counts['bytes'] += 1
                return codec.encode()

            def input_key(self):
                counts['key'] += 1
                self.asserted_bytes = self.input_bytes()
                return marker

            def check(self):
                counts['check'] += 1
                return self.input_key()

            def add(self):
                counts['add'] += 1
                self.check()
                return self.input_key()

        graph = Graph()

        class GA:
            def check(self):
                counts['GA.check'] += 1
                return graph.check()

            def record(self):
                counts['GA.record'] += 1
                self.check()
                graph.add()
                return self.check()

        saved = (Graph.check, Graph.add, Graph.input_key, Graph.input_bytes, GA.check, GA.record, codec.encode)
        for target, name, label, is_bytes in [
            (Graph, 'check', 'CGR.check', False), (Graph, 'add', 'CGR.add', False),
            (Graph, 'input_key', 'CGR.input_key', False), (Graph, 'input_bytes', 'CGR.input_bytes', True),
            (GA, 'check', 'GA.check', False), (GA, 'record', 'GA.record', False),
            (codec, 'encode', 'codec.bytes', True),
        ]:
            self.tap.install(target, name, label, returned_bytes=is_bytes)
        self.assertIs(GA().record(), marker)
        self.assertIs(graph.asserted_bytes, payload)
        self.assertEqual(counts, {'GA.record': 1, 'GA.check': 2, 'add': 1,
                                  'check': 3, 'key': 4, 'bytes': 4, 'codec': 4})
        by_id = {row['call_id']: row for row in self.tap.records}
        self.assertEqual(len(by_id), 19)
        self.assertTrue(all(row['caller_site_id'] is not None and row['stack_site_ids'] for row in by_id.values()))
        checks = [row for row in by_id.values() if row['label'] == 'CGR.check']
        self.assertEqual(Counter(by_id[row['parent_call_id']]['label'] for row in checks),
                         {'GA.check': 2, 'CGR.add': 1})
        ga_checks = [row for row in by_id.values() if row['label'] == 'GA.check']
        self.assertEqual(len({row['caller_site_id'] for row in ga_checks}), 2)
        for row in by_id.values():
            self.assertGreaterEqual(row['cpu_inclusive_ns'], row['cpu_instrumented_child_exclusive_ns'])
            self.assertGreaterEqual(row['wall_inclusive_ns'], row['wall_instrumented_child_exclusive_ns'])
            self.assertGreaterEqual(row['cpu_instrumented_child_exclusive_ns'], 0)
            self.assertGreaterEqual(row['wall_instrumented_child_exclusive_ns'], 0)
            if row['label'] in {'CGR.input_bytes', 'codec.bytes'}:
                self.assertEqual(row['returned_bytes_len'], len(payload))
        self.assertEqual(self.tap.errors, [])
        self.tap.restore()
        self.assertEqual((Graph.check, Graph.add, Graph.input_key, Graph.input_bytes, GA.check, GA.record, codec.encode), saved)

    def test_single_producer_second_attempt_blocked_before_original(self):
        count = []
        marker = object()

        def producer():
            count.append('actual-original')
            return marker

        target = SimpleNamespace(first=producer)
        self.tap.install(target, 'first', 'producer.first_binding', single_producer=True)
        self.assertIs(target.first(), marker)
        with self.assertRaises(AssertionError):
            target.first()
        self.assertEqual(count, ['actual-original'])
        self.assertEqual(self.tap.producer_attempts, 2)
        self.assertEqual(len(self.tap.records), 1)
        self.assertEqual(self.tap.records[0]['label'], 'producer.first_binding')

    def test_exception_identity_and_observer_caller_failure_do_not_replace_original(self):
        original = ValueError('fake original error')
        counts = []

        def fail():
            counts.append('one')
            raise original

        def observer_failure():
            raise OSError('fake observer frame failure')

        target = SimpleNamespace(call=fail)
        self.tap.install(target, 'call', 'fake.failure')
        self.tap._site_ids = observer_failure
        with self.assertRaises(ValueError) as caught:
            target.call()
        self.assertIs(caught.exception, original)
        self.assertEqual(counts, ['one'])
        self.assertEqual(self.tap._state(), [])
        self.assertEqual(self.tap.records[0]['error_type'], 'ValueError')
        self.assertFalse(self.tap.records[0]['returned'])
        self.assertEqual(self.tap.errors, [{'where': 'caller-sites:fake.failure', 'error_type': 'OSError'}])


if __name__ == '__main__':
    with (ROOT / 'selftest.log').open('w') as stream:
        result = unittest.TextTestRunner(stream=stream, verbosity=2).run(
            unittest.defaultTestLoader.loadTestsFromTestCase(FakeCallerTap))
    forbidden = [name for name in sys.modules if name.split('.')[0] in DENIED]
    record = dict(classification='STDLIB_FAKE_ONLY_NOT_PRODUCT_FIRST_BINDING_OR_FULL_PB',
                  tests_run=result.testsRun, failures=len(result.failures), errors=len(result.errors),
                  success=result.wasSuccessful() and not blocked and not forbidden,
                  blocked_actions=blocked, forbidden_modules_remaining=forbidden)
    (ROOT / 'selftest.json').write_text(json.dumps(record, indent=2) + '\n')
    print((ROOT / 'selftest.log').read_text(), end='')
    print(json.dumps(record))
    raise SystemExit(0 if record['success'] else 1)
