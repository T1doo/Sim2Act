# f9df 首证因果切片静审：未给代码 ACK

本轮仅只读静态源码与已关闭作者 probe 记录；没有导入或运行产品、DB、测试、模型、网络、benchmark，也没有修改仓库或旧封存。所读六份源码均逐字匹配 immutable f9dfcf319b1a5bd66246aaa07a4dd0a082d1bd98 Git blob。当前结果是 **CAUSAL_SLICE_PRECHECK / NO_UNCONDITIONAL_COALESCING_ACK**，不是最终代码、性能、Stage或完整PB接受。

## 因果范围

先前唯一完整运行 G0.check2048、key2183、first_binding37.279s是有probe的失败结果；W5/G1未到。本次作者baseline是另一个结束的synthetic G3/Source2前缀副本上的单个dormant first-binding读取：parent记录exit0/23.080816s/非timeout，源与副本哈希不变，child producer一次返回，2814 SELECT、blocked/errors为空。它不是新full、不是Cold settlement或租约验证，也不是无探针性能控制；不能拿23.08与原37秒直接宣称优化/退化。

从原calls.jsonl独立汇总：CGR.check2030、input_key2161、add130、GA.reader.check272、record16。每个CGR.check恰1个input_key，另130个add完整重pin及1个构造初pin，2030+130+1=2161；未见input_key内部“一次check算两遍key”的现成冗余。Runtime _ColdRunFacts.check被记录366次，其中_present81、_get85、_put56。GA raw_key/present各21，record前后各16。具体调用边与原site字典保留在PROBE-CALLER-FACTS.json及baseline-probe目录。

所有真实SQL返回后的pin、source/authority回调后的pin、fact.add入参/重pin边界、scope封口、末时钟和原ModelRead完整验证，均不在本建议的删除范围。

## 明确撤回：GA raw_key→raw_present 不能按表面相邻删

先前即时建议只看两个reader.check返回之间的tuple构造，遗漏了reader.check内部最后的serializer归属。此建议现正式撤回，不能作为实现ACK。

GA _GenerationFactsReader.check在814做CGR fullpin，但在其后source_pin存在时又调用 FrozenRunContract.model_dump（无warnings=False，也没有先针对这个当前typed对象做完整_trial_typed_storage门）。exact root不足以证明nested Any、错误typed值的Pydantic serializer/warning路径无未知回调。typed对象本身不在CGR可编码raw树内，CGR pin的是此前dump得到的raw。因此下一次reader.check入口CG可能恰好是上一次serializer之后首个完整漂移检查。删掉它会把实际可变别名或epoch变化带到后续消费。contracts.py虽没有FrozenRunContract专属field_serializer声明，不能据此证明所有运行时nested/警告分派为纯。

相同理由阻止Runtime _ColdRunFacts.check→_present/_get按私有membership理由合并：check的manifest.model_dump在入口CG之后，可能instance shadow或nested/warning dispatch。没有额外pure-storage/schema完整桥之前，366次这个大组不是已证明可删组。若先补serializer后的postCG再共享入口，可能只是一增一减，不能先许诺降低hash数量。

## 不能删的具体边

1. GA record的reader.check→copy.deepcopy(value)→guard.add入口CG之间有deepcopy协议hook。复制是外部敏感计算；现有post-hook/add entry检查必须保留。guard.add返回之后还有raw_reads registry append，本身也是可观察的本地元数据写，不属于严格“无写纯区间”。
2. CGR.add的完整入口check、incoming整树类型/循环/forbid-root验证、真实inputs插入、完整当前字节重pin是事实扩展边。不能用早先identity/version或ALLOW布尔替代。
3. _ColdTrialGraph._base的两个CG pin之间当前通过完整typed cohort并调用fixed model_dump（含固定schema的既有exclude_if）。它不满足本轮要求的无serializerhook区间；不把已知固定schema直接当“可删全部后pin”。
4. _model_inputs、fingerprint、prefix.fields、model_dump、deepcopy、c.execute/mappings/first、own_project/authorize/source及外部callee返回都不是仅凭私有名称即可跨越的边。提前或删除pin必须保原第一错误位置与异常identity，不可事后补catch。

## reader→raw_seed 两个入口的范围及条件拆法

本次G0 raw_seed分支静态不可达：_cold_model_before调用_cold_first_binding而不传audit_seed；后者只有audit_seed非None才给ga._cold_generation_source传raw_seed。_cold_audit_seed创建generation_seed用于post/G1。故这里的双入口不是本次已量化272个GA检查的重入原因，不建议本轮优化它。

将来若单独批准，固定共享core可以保持reader原首CG→seed pointer/type→受控native Run principal提取和exact user的纯scope谓词→seed完整body→原model_dump/fingerprint后末CG。Standalone seed.check仍保原scope→entryCG→同body→末CG；组合caller只共享词法内的那一个entryCG，无checked bool/permit或结果缓存。若run的subscript或self.user!=user仍可能调未知方法，或以instance shadow check分派，则不能证明entry间纯，不能直接省第二入口。这里只是条件结构，不是代码ACK，本轮不实施G1修订。

## 目前最小实际G0候选：apps两个prefix入口

apps._cold_candidate_prefix:597的完整CG→role枚举require→_frozen_candidate_prefix:644入口CG，两pin间没有SQL、serializer、事实插入或authority回调。本次caller记录各2次，实际producer传cold/source字面量。它不是2030次的大头，最多消除两次fullpin，节时未知。

可在root授权范围内考虑固定共享body：普通/其他调用仍保_frozen_candidate_prefix入口CG→原body；Cold wrapper保原入口CG→exactstr+枚举role纯门→同body。body从原aid读取/draft_gate开始；draft_gate、own_project、validate_source_family、compile返回后的全部CG/strict-origin检查及guard.add前检查原样。无需_pinned开关、identity允许票据或新缓存。必须固定exactstr role，否则当前role in set可调未知__hash__，该省略便不成立。该exact gate属于更严格私有输入域，需短反例明确首错/异常责任，不能宣称对任意恶意私有Python对象完全等价。

这是唯一目前可明确构造“无hook纯区间”的小建议；尚无候选实现，没有代码接受。作者若认为两次收益不值得，可保留原代码，先调查完整CGR编码成本；不可为数量好看删除真实SQL后pin、把G1优化当G0因果、或引入通用permit/cache。

## 对未来窄验证的最低要求

若形成具体patch，应有：原完整返回值/SQL及查询顺序不变；真实/失败写epoch与完整输入/role漂移在下一敏感IO/消费前拒绝；serializer/deepcopy异常保原对象且sticky；fact.add出错无半证发布；W5原组、G1全新epoch、scope封口和末clock不变。该清单是候选相关短验证边界，不授权长链、外围矩阵或任何新模型调用。唯一baseline probe由作者执行；本独审不再启动probe。原full FAIL_NOT_ACCEPTED及v15seal不改。
