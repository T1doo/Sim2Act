# 最终有限事实独审：首证归因保全 ACK

结论为 **BOUNDED_FIRSTPROOF_ATTRIBUTION_FACTS_ACK / NO_PRODUCT_OR_PERFORMANCE_ACCEPTANCE**。本轮唯一有界 dormant 首证探针确实正常返回，未证明实质改善，没有实施源码候选，不值得为了现有证据再次运行完整链。原唯一完整P-B仍为 **FAIL_NOT_ACCEPTED**，W5/G1/finalguard仍 **NOT_REACHED**；v14代码ACK不升级为运行或性能接受，v15/v16旧seal不修改。

本报告只核对已关闭记录、源码/脚本和文件哈希，不执行产品、probe、测试、DB查询、Worker、模型、网络或benchmark。保存和新写内容仅在独立v17目录。父侧未来raw archive、commit/push/远端状态未送审，不属于此ACK。

## 源码和运行范围

本地基线f9dfcf319b1a5bd66246aaa07a4dd0a082d1bd98。probe记录的121文件（113个Python源+7schema+pyproject）前后、当前实际、Git基线SHA逐项相同；src/tests/scripts/schemas/config相对f9df的Git diff为空。该footprint不是原full715文件，也不是v14最后131selected文件，不混用数量。本轮没有产品源码或测试变更，也没有新产品pytest/mypy/Ruff；不把以前短门当本轮重新通过。

baseline-first-only parent记录exit0、非timeout、child不再运行，外层23.080816336秒，原watchdog90秒。脚本独占新out，只开一个子进程、不重试；child记录一个producer invocation正常返回、同一guard有效。实际producer body19.784824397秒wall/19.423375246秒threadCPU。三种时间不同，不相互替代。

原probe使用当前实例先前成功生成的合成G3/Source2+QUEUED Cold前缀的关闭副本，未生成新G3/Source2/Cold证据。helper原样检查旧前缀行，创建object.__new__(Worker)未初始化壳而不调用Worker.__init__/once/process/claim，并构造假software/authorization FP、未批准key、内存expiry=now+3600的PB连续性pin。这个新内存对象不是真审批、Grant、Stage、Run权限或production ALLOW，没有延长数据库原合同或lease，也不是实际合同TTL/Run期限的运行测试。当前README已明确这一区别。

原own_project/authorize等读取按产品路径实际执行，0新审批/许可并不等于权限检查为0。Worker执行、claim、审批、journal/Stage/发送、模型和HTTP/MockTransport入口均设有限tripwire；child blocked为空。helper只执行setup SELECT；主producer也只有读取，没有进入full admission/settlement。不得把构造出的facts/binding或guard有效当作真实Stage Authority。

作者probe通过普通Store.tx执行BEGIN IMMEDIATE，SQL监听拒绝任何其它非SELECT语句，主事务driver.total_changes要求为0；它不是SQLite URI mode=ro或query_only模式的声称。setup15SELECT+1BEGIN，首证2814SELECT+1BEGIN，DML0；源库和副本记录及本独审文件字节哈希均为9a9bdfcf0264a251670a2c59dcbd401e1e035656542413e032357a442802e4db。v17仅读取DB文件字节核哈希，未打开SQLite或查询DB。

## 数值核验

独立重新汇总原calls.jsonl，非执行作者analyze_probe.py：16340个唯一call_id、全部parent引用存在、全部returned、error_type为空；child dropped/observer_errors/secondary_errors均0。完整metrics、stack attribution及2161条bytes父链记录与ANALYSIS.json逐值完全相同；不是仅抽查四舍五入文本。

| 原实际记录 | 结果 |
| --- | --- |
| CGR.check / input_key / add | 2030 / 2161 / 130 |
| GA reader.check / record | 272 / 16；本次raw_seed分支未到 |
| 每个check→key / 每个key→input_bytes | 均恰好1；2030+130重pin+1初pin=2161 |
| input_bytes | 553170433累计返回字节；单次6435至579257 |
| codec.bytes | 2173次，threadCPU10.308180564s |
| typed_storage | 2185次，threadCPU2.186464883s |
| input_bytes | inclusiveCPU12.666612800s，已安装子body排他0.276784522s |
| validator | 133次，inclusiveCPU1.908760654s |
| SHA构造 | 3173次，inclusiveCPU0.995218294s |

这些标签跨整个active probe，包括初pin及原scope退出，不表示每个调用都在producer body里。字节量是每次实际返回/构造输入的累计视图，存在嵌套重叠，不能相加当作独立数据。instrumented-child-exclusive只减去实际已装子探针body，调用栈采样/计数/mutex/IO及调度开销仍在。当前显式typed-storage tap给出完整分项，不能把旧full未安装该tap时input_bytes排他7.207秒全部当该函数自身成本；也不能拿旧full37.52秒与本次23.08秒作优化或退化对照。无无探针对照、无候选firstproof对比、无性能接受。

探针3项纯stdlib fake自测有实际原日志：3PASS、0failure/error、0.018秒；其覆盖调用归属、原返回值/异常identity和第二producer进入前阻断，仅是观察器有限自测，不是产品/Stage/fullPB门。本独审未重跑这些自测。真实probe正常路径没有异常，不能用其成功替代所有异常路径的透明性证明。

## 安全结论与停止边界

GA/Runtime reader的入口CG之后仍可能执行serializer/warning路径，后续入口pin可以承担post敏感回调漂移检查。此前GA raw_key/present表面相邻省pin建议已在v16正式撤回；没有据此改代码。record的deepcopy hook、add的验证/插入/完整重pin、全部真实SQL/权限/source返回、封口和末clock均保留。raw_seed嵌套入口不是本次G0热点。

唯一可条件构造pure共享core的apps两次内层prefix入口，原两调用合计CPU5329746ns（约0.005330s）；且仍须精确输入域及异常顺序证明。父侧已决定不为微小收益实施。本轮不继续codec fusion、新结构设计或新产品测试；没有证明高频扫描可安全且实质减少，也没有为取绿再跑full。

最新README及ANALYSIS的数值、壳对象/未批准内存pin限定、0新增authority、不同时间区间、旧full失败、性能未知、未执行项均与原件一致。未发现妨碍诚实保全本轮结果的剩余实质错报。rawarchive将包含v17是待pack安排，不能视为此时已核成员/已推送；未来实际打包和普通dev推送由作者分别验证。

Windows、PG、CI、真实模型/语义/场景、人工验收均未执行。旧满盘环境最后独审报告未落盘仍是已知缺口，本轮没有恢复、补回或重新签署。保全后由父侧另在指定实例接续；本ACK不授权任何新probe、Run续跑或完整链。
