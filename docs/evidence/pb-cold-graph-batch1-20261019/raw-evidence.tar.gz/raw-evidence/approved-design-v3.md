# P-B Cold 模型结算：单入口、两个完整事实图（只读设计 v3）

状态：**AUTHOR_DRAFT / 待独审；不是实施授权或性能通过**。基线为已交付 `8f8a289a392321d240e73b279a61fb064ae78241`（执行源 `2b67733e` 的 src/tests 未变）。上次完整链仍为 FAIL_NOT_ACCEPTED；本轮不修改产品、合同、权限或测试，不运行产品、DB、模型、benchmark 或完整链，不推送。只对已有结束事件做算术及源码静读。

## 1. 具体问题与设计目标

新 continuation 已确实消除了 READY 后的 check_commit/journal_chain 重入，但旧 Cold TX 在 READY 前耗 29.651944 秒，剩 0.332998 秒 lease。不是再加一个尾部 stamp 能解决的问题。新入口必须接管**响应接收/归档和原 renew 之后、原结算事务开始处**，不能先执行旧 bound/两次 commit_guard 再建立图。reserve、发送、配额等待、接收事实和失败记账不在本轮重设计范围。

目标是在每个读 epoch 建一个完整、局部、不可递归回到公开 verifier 的依赖图。相同祖先历史、正文、账本和结果只加载/解析/完整核对一次；不同 ID、runtime 角色及完整 Limits 的验证面仍分别成立。写前图 G0 和五写后图 G1 **各自重新读取并验证全部事实**，仍在原一个外层事务中。不是全系统 cache，也不是公开 Binding/权限快照的共享。

性能目标是显著余量：建议后续实施验收以整个结算 TX ≤20 秒、在提交前实际 lease 余量至少8秒为候选工程门，包含所有 drift/live/hash 成本；它不是修改产品期限，也不是当前已有证据或保证。父级应先决定该门及实施边界；当前不以低于30秒一次或0.4秒余量接受设计成效。

## 2. 标识、角色与事实键

单入口临时上下文固定：exact Worker/Settings/stop/transport、Store/engine、Connection、SQLAlchemy transaction、SQLite driver、线程、真实 write epoch/total_changes、同调用 nonce、原 binding/contract/approval/account/quota 和当前 raw/wire/meta。只允许既有精确 Production/PB/Cold/test-only SQLite、无 qualified association 的普通 pb_use 线；logic/correction/project/offline replay 等变体在**进入前**按 owned scalar marker 分流原路径。进入后任何缺事实、错误、重入、写或漂移都拒绝，不 fallback。

| 角色 | 不可混用的身份与值 |
| --- | --- |
| 当前 Cold | cold_run_id、cold_runtime、当前 aid/operation_id/step/ordinal、AppRun、实例及接受 revision、Cold Release、有效 per-use candidate |
| Source | source_run_id、source_runtime、Source AppRun/实例/Release、原生成应用、成功 typed/output/result、2个自然 aid |
| Generate | generation_run_id、trial/runtime、确认的原 app/candidate、3个 RECEIVED aid、原 frozen Goal/材料及 GA read/check/确认事件 |
| 提取 | extraction_app_id/runtime、task_extractions、META/EXTRACT成对记录、独立 extraction_request_key/recipe、Source proof fingerprint及目标材料/完整Goal |
| 原 trial | principal/project、contract fingerprint、approval key、account/quota、Generate/Source/Cold stage key和源阶段/冷阶段批准 |

Trial runtime 用于原项目/trial/Generate；Source、Cold 的 app runtime 来自各自真实 Run/StageAuthority。权限键始终完整五元组 `(principal, runtime, project, resource, tool)`；不拿 Cold runtime 替代 Source/trial runtime。per-use 有效 draft 可与提取基稿同 app ID，但 candidate 不同，必须以角色+完整candidate/fingerprint区分；不能仅按 app ID 合并。只保留原代码已要求的不同材料/Goal/hash/阶段Run约束，不自创“所有ID都必须不同”。

两层事实键：

1. RawFacts：`epoch + owning principal/project + entity kind + 原始ID + row kind/key`，保留全部字段、原顺序和原始多重集；先查 cardinality 再建索引，不能用 dict/set 去掉重复。
2. ValidatedFacet：`epoch + node/role + 全部相关ID/fingerprint + 完整Limits向量/None语义 + 阶段(pre/post)`。共享 RawFacts 或同一 GenerateHistory 不能推出不同 Limits 下的 candidate/预算校验已经通过。

完整 Limits 向量为 max_requests/max_tools/max_repairs/max_total_tokens/max_output_tokens/run_seconds；平台默认 `(4,4,1,64000,1024,300)` 与 trial `_limits(contract)` 的 `(3,4,1,64000,caps.output,caps.run)` 分开。当前节点、action、声明manifest、当前 frozen、Source/Generate frozen 及提取继承源 Limits 均保留独立角色；不得取一个最宽/最小向量替代逐角色谓词。`limits=None` 的原 frozen fallback 语义也不能与恰好同值的显式平台 Limits 混同。

## 3. 依赖节点与拓扑

箭头表示“完整事实依赖”，不表示可以提前读取私有正文。每个节点仍受前置 owned scalar/当前权限 gate 约束。`P` 只表示已解析/配对，`V` 才表示完整验证，避免“阶段批准依赖账本、账本又依赖阶段批准”的假循环。

```mermaid
flowchart TD
  R[H: owned scalar身份/分流/权限次序] --> A[A: 原批准/当前材料Goal与权限]
  A --> P[P: 已配对批准及阶段DTO]
  P --> J[J: 账本/配额cursor一次完整解析]
  H --> O[O: 三角色Run/frozen及原始记录包]
  A --> O
  O --> G[G: Generate三次wire/反馈/usage/候选确认]
  J --> B[B: 每aid controller body/capture/slot]
  O --> B
  G --> SB[SB: Source原应用Release/Binding]
  SB --> SR[SR: Source六步receipt/成功结果/typed/artifact]
  B --> SR
  SR --> NS[NS: Source双NS正文与controller连接]
  B --> NS
  G --> SV[SV: Source完整阶段Authority与原批准比较]
  SR --> SV
  J --> SV
  NS --> X[X: 提取META/EXTRACT/Recipe/Source proof]
  SV --> X
  X --> CB[CB: Cold Release及逐次材料Goal Binding]
  G --> CV[CV: Cold完整阶段Authority]
  SV --> CV
  CB --> CV
  J --> CV
  CB --> M[M: 当前及前驱Cold aid/intent/usage/Operation]
  B --> M
  M --> CR[CR: Cold receipts/counters/锚点/审计]
  CV --> T[T: 完整图完成及原nontrial/当前live门]
  CR --> T
  X --> T
```

`P` 校验 pair/seal、本身hash、approval key/实体/阶段及类型，但不是完整 StageAuthority。`B` 可用 P 中的阶段指纹校验 slot.identity；只有 SV/CV 用真实图重建 Authority 并相等后，整个阶段才 V。任何消费者不得把 P 或 partial B 当权限/阶段许可。

固定 source resolver 是每个必要安全边界的**新鲜调用边**，不是可复用祖先节点：沿用 spec_production.source 的原批准、固定 producer、check_source/account、精确软件资格及双时间检查。图内不缓存 ALLOW。完成的 G1 首证按原语义立即 pin source identity和实际截止，之后每个消费者实际调用来源、要求身份连续及期限只收紧；不跨 G0/G1 继承旧来源许可或旧较晚期限。当前 observed_at 不进入相等指纹，仍每次执行原新鲜性门。

## 4. 原检查 → 新节点/位置（覆盖表）

以下是需提取/显式传参的私有 leaf，名字仅设计名，不是现有已实现 API。公开入口默认路径保留；图的子节点不能调用这些公开完整 verifier 来“补齐缺事实”。

| 原检查/调用链 | 新节点与位置；共享后仍执行的谓词 |
| --- | --- |
| advance_model 结算TX首次 lock_live/Run版本-created_at-deadline | H/T：仍实际 lock_project/Store.guard、worker/stop、版本/fence/created_at、完整原Run谓词；图从此处开始，而不是首个bound之后 |
| app_jobs.load_binding → read_release → validate_frozen_candidate → verify_origin | O/CB/SB：抽出 `_binding_from_facts`，显式接收已核Release和per-use结果；namespace、queue/ACCEPTED、fingerprint、完整input、runtime/project、frozen Limits、所有无变体marker及owner goal谓词保留 |
| lifecycle._read_release / apps.validate_frozen_candidate | lifecycle原样透传私有输入；apps新增exact graph fact严格分支（尚未实现）。每角色完整Limits独立；原draft gate、Release pointer/family/dependency_lock/schema/source bytes保留，每次可能回调的内部callee返回后先验current，选择origin之前再次验；漂移直接拒绝，不能先进入legacy fallback |
| pa_spec_apps.bound（本TX9次） | SB/CB及角色facet：RawFacts一次，LoadBinding/Release/Origin/goal/frozen/clock/counters/input/plan/audit逐项；平台与trial两个bound语义都要成立，不能以一个公开bound结果替另一个 |
| pb_natural_uses.bound/review/audit/base_audit | CB/X：pb_use成对body/frozen、accepted revision/runtime/输入、approved_grant_state、完整目标Goal、expected app/release/recipe/source指纹、effective candidate及完整audit；重建所有fingerprint，不把request hash当证明 |
| pb.verify/review/audit_fingerprint → pb.source/source_audit → verify_job | X/SB/SR：显式接收Source proof、Source audit RawFacts、目标Goal/材料；提取key、marker数量、request/seal/元数据、source id、Recipe、候选/名字/runtime、源限额继承和不同材料/Goal/hash要求保留 |
| pb.source_gate/_source_audit | H/SR/NS：原source原生家族/禁止提取链、owned scope、成功/cancel、单一committed/saved/output/typed artifact pointer、artifact权限；完整audit行集合包含run/contract/binding/AppRun/typed/release/attempt/op/intent/effect/event/reservation/原origin/Goal版本，不删字段 |
| goal_applications.source/history/verified_candidate、text_apps.verify_origin、pa.model_source/verify_origin | G：完整源材料/frozenGoal、3次请求重建、GA_WIRE_RESERVED/GA_RECEIVED、实际read/check feedback/repair、raw/canonical/usage/provider identity、最终candidate和GA_CANDIDATE_VALIDATED/GA_APP_CONFIRMED；Generation history只一次，candidate在各完整Limits角色单独校验 |
| natural_live_admission._run_context/_stage_current/_stage_current_bound | P/SV/CV/T：不再从阶段验证重进bound；显式传相应Binding、G、Source/提取事实。重建完整StageAuthority逐字段与成对批准相等；保留stage keys、app-run key/internal key、recipe、目标Goal、来源Gen、当前Instance/Release、authorization fingerprint |
| _pb_origin/_generation_accounted/journal_stage_accounted | G/SV/X/B：3 Generate、2 Source的实际Attempt集合和slot集合、backend marker精确一致、Source SUCCEEDED、Source opVERIFIED、usage和原正文连接逐项；不能由“已看到某阶段”短路 |
| _pb_source → archive._resolve_trial_source → _source_prefix → _source_stage_current | SV/NS/X：Source的完整阶段、原成功结果、原提取、Source proof fingerprints和当前权限全部通过；用私有 `_..._from_facts` 输出同样public receipt，不递归重复Source/Generate |
| production_trial_journal._context/_quota/_ledger 与 policy._ledger | J：原project lock/cursor/ledger顺序、pair/seal/旧backend不存在、revision/quota_revision/account/scope、全部slot可达性/唯一aid、stage-run互异、1RPM/全局及分阶段预算/halting；一次完整解析，不能仅投影出想用的5条 |
| _journal_owner/_journal_slot/_journal_chain（post scope15次） | B：按实际 `(stage, run, aid, runtime, binding, full wire)` 建节点，一次校验controller metadata/body pair、PA_TRIAL_BODY单锚、slot/capture/原始与canonical响应、mode/model/max_tokens/reserved、owner/worker/version/fence/phase/approval；每个aid仍独立，不用父scope aid冒充实参 |
| policy._bound 对相同ledger重复规范化 | J/B：拆私有 `_bound_from_checked_facts`，保留全部原wire/identity/account/quota/scope/project/runtime检查，消费同epoch已完整解析的J，不再次parse/遍历ledger；原公共调用仍先完整typed解析 |
| archive._source_bodies + _pb_journal_archive_chain | NS/B：Source恰2条NS请求/响应key集合及无多余；NS正文/sha/phase/extent/provenance、raw bytes/canonical分别比较；controller capture原body和NS完全一致，usage三项与slot/Attempt一一相等 |
| spec.receipts / runtime.counters/prove_node/prove_pending | SR/CR/M：保留完整op/intent/request/receipt/plan/fence/CLAIMED、唯一ordinal/step/op/aid、无跳步、无多余event/effect；源码中按节点顺序重建intent及receipt，不能只验最终输出hash |
| 当前raw/parse/schema/usage与NS_RESERVED/RECEIVED/SETTLED | M：G0当前RECEIVED/operation DISPATCHED，无当前SETTLED/STEP；G1当前VERIFIED/operation VERIFIED、完整receipt、NS_SETTLED恰1及本次STEP恰1；前驱Cold模型保持原VERIFIED证明，当前raw必须配原wire/meta/usage/reservation |
| _commit_guard 中原nontrial主体 | T：逐项保留accepted binding/release/current Goal/source/audit/Instance、生产开关、工具预算、所有Limits/Run时钟、qualified检查；改为消费图fact的private predicates，不能再经audit回到整条祖先链。最后fresh current/live检查仍执行 |
| _ModelSettlementRead.check/settle/tail | 继续保留全部原identity/epoch及完整inputs/binding指纹和single-use状态。只更换其完整首证的事实来源；不添加尾continuation，不以新图为由删/稀释原check。最终live及tail权限并集仍在来源/其他回调之后重核 |
| advance_model except / receipt_owner / reject / RECEIVE保留 | 原异常仍在同一外层rollback后走原独立拒绝事务。owner/CAS/拒绝事务竞争可保留RECEIVED/DISPATCHED；不能把原错误总转VERSION或保证必有REJECTED_KNOWN |

## 5. 一次解析与权限顺序的明确含义

每个 epoch 先按原顺序做 own_project、family/owner scalar投影、原permission gate，再读该角色私有 Run/Goal/body/candidate/cursor。图不允许一次无权限的巨型 JOIN 先取完正文再筛选。Body/capture/raw的完整解析和祖先历史校验一节点一次；必要的当前scalar/Grant/批准/时间重复读取不算祖先“全解析”，并且不能被一次完成位替代。

子验证使用明确参数，例如 `_source_receipt_from_facts(source_rows, binding_facet, generation_facet, journal_facts, per_aid_bodies, role_limits)`，而不是传一个可任意resolve/cache的全局context。节点结果只有完整通过后才可供下游使用，数据深拷贝/只读所有权不向外暴露mutable别名。图的同epoch事实仍须被输入指纹和精确标识覆盖，不能靠Frozen名字假装没有漂移。

若当前权限回调、source resolver、事件回调或任一读取改变epoch/连接/Settings/输入，当前图立刻失效，保留原错误及rollback，不重新建图掩盖失败。只有明确的原五写阶段转换允许结束G0、启动全新G1。不能为图准备再调用一个公开bound/verifier导致暗中树遍历；未来静态调用边检查需验证该点。

## 6. 两个epoch与原五写的单入口时序

```text
原接收/响应归档事务已完成，原位置renew完成（均不改）
原结算外层 Store.tx + journal_reads
  单入口H固定身份/资格，构建G0（当前RECEIVED；父级成功事实全重新读）
  G0完成完整图、parse/usage/intent/receipt、当前live和写前nontrial各原谓词
  关闭G0；只留下原写组必需的写入值和原调用期望标识，禁止继续消费旧facts
  原五写原顺序：Attempt VERIFIED；NS_SETTLED；Operation VERIFIED/receipt；AppRun RUNNING；STEP
  第一写即使所有旧token/facts失效；无中间commit/续租/读段保留
  最后一写/回调之后启动新epoch G1
  重新加载G0全部事实集合与所有权限，不只读取“被写过的五项”
  G1以当前实际VERIFIED/新锚点完整重建图、parse及receipt，再核原跨写一致性期望
  原_ModelSettlementRead消费者/完整nontrial尾部谓词及fresh权限/source/Run/期限
  单次外层commit；任何错误→全部五写rollback→原独立拒绝路径
```

跨写允许保留的只是原call/Run/aid/wire/raw/meta和写入意图及原版本/audit一致性比较值；它们**不是G1的事实生产者或授权**。G1不接收G0 Binding/祖先DTO、Grant列表、source ALLOW、parsed ledger/history/receipts或完成位，所有从实际DB/固定来源重新得出。不同epoch即使所有ID/hash值相同也不命中同节点。不能假设epoch恰好加5而忽略事件回调的额外写；任何额外写都使旧facts失效，G1只从最后实际epoch开始，原完整谓词决定是否拒绝。

当前第二Cold模型也必须支持：旧第一个Cold aid须按其原VERIFIED/SETTLED/STEP验证；当前第二aid按pre/post差异验证，不能把“本次只一aid”硬编码成Cold永远一aid。Generate恰3、Source恰2、Cold原最多2、trial最多7及ledger stage/budget全部保留；本轮6条执行不是新产品基数。

## 7. 实测成本覆盖与未知项

`cost-coverage-existing-run.json` 从旧 ended probe 单纯读取/配对事件计算；没有新执行。时间为主线程 monotonic/thread_time；被观察函数包含子函数，跨行不可相加。原observer没有每次journal的actual aid、Limits角色或check计时，因此没有假造逐祖先成本。

| 覆盖面 | 已有真实观测 | 本设计处理/缺口 |
| --- | --- | --- |
| TX总计 | wall30.308420 / CPU30.273717秒，28230 SELECT+5写 | 必须减少整图重复；不是只减少尾部 |
| 第一写之前 | 17.660291秒 | G0目标；包括原bound/guard/receipt/parse等，不全部归因祖先 |
| 第一写至post-scope | 0.009560秒 | 原五写与handoff；不是主要目标，不改写组 |
| post-scope至READY | 11.982092秒 | G1目标；保留新epoch完整证明 |
| TX开始至READY | 29.651944秒 | READY余0.332998秒；不能当有效裕量 |
| bound | 总9；按真实run参数Cold5=11.025004秒、Source4=3.225970秒（inclusive） | G0/G1各一次raw祖先+独立Limits facet；两类内/外嵌套，不能相加当独占成本 |
| commit_guard | 3次inclusive22.149238秒 | 图内原guard谓词复用完整事实，不重入公开verifier；含bound/pb_source等重叠 |
| _pb_source | 3次inclusive6.675717秒 | 拆SV/NS/X私有leaf，不重复Source/Generate全证明；fresh source边不缓存 |
| post-scope check_commit | 1次7.361469秒 | 完整图阶段谓词保留，不用“已有callback”跳过 |
| post-scope _journal_chain | 15次合计1.754480秒，包含祖先，actual调用aid未记录 | J解析一次、B按actual aid一次；不得把15全标当前aid或伪称14条具体祖先各几次 |
| _ModelSettlementRead.live | 2次合计2.019339秒 | 包含当前权限/SQL/source及多次check，不可全标hash成本；第二次实际失败 |
| `_ModelSettlementRead.check` / `binding_key` / 完整 `_model_inputs` | **UNKNOWN：次数、wall、CPU、字节数均无单独采样** | 原漂移检查全部保留；不能用总时长减祖先inclusive估计，更不能据猜测删除 |
| READY之后 | 0个check_commit/0个journal_chain；仅1个_journal_source，0.656476秒至TX body_end | 只证continuation有效，不能解决首证29.65秒 |

下一轮若批准实施，**先单独计量**，不能先删指纹再跑长链：在原check入口/退出记录次数、wall/thread CPU；在binding_key和最外层_model_inputs分别记录相同维度及规范化字节数，递归_model_value不逐层重复相加；用嵌套区间求exclusive成本。记录图node/实际run+aid/stage/runtime角色/完整Limits digest/epoch/pre-post，祖先历史/ledger解析、body解码/hash、receipt重放、candidate各Limits校验分别计量。只加passthrough观察，保留原返回/异常/clock/权限/写，不提供生产日志正文或凭据。

未来计量同时列wall、thread CPU、SQL、调用次数、distinct事实键数、重复生产者、各节点inclusive/exclusive区间与完整TX实际lease/Run余量。check与祖先成本并列，不能用一个“查询下降”百分比掩盖未计时hash。原生产fixed source默认拒绝和真实软件资格保持关闭。任何新的执行/夹具/完整链都须父级另行决定，本轮没有执行。

## 8. 候选最小文件边界

这不是三文件尾部补丁。为消除具体重入边而不复制一套executor，候选边界为以下**12个已有产品文件**，不新增通用cache模块。每项只抽私有“已授权事实→原谓词”leaf，公开默认路径仍做原完整读取/验证，图入口只在Cold结算调用。

| 文件 | 必要边界 |
| --- | --- |
| natural_spec_runtime.py | 单入口/两个epoch、原五写集成；counters/prove_node的事实leaf；保留现有check/消费者和拒绝路径 |
| pa_spec_apps.py | 原bound/receipt/audit/nontrial谓词的显式facts leaf；禁止子图回公开bound |
| apps.py | 新增exact私有graph origin事实的严格分支，在回调后/消费前验当前性；失效拒绝，不进入公开verify_origin；原普通dict/default路径的fallback语义不改 |
| app_jobs.py | load_binding的已核Release/per-use结果适配，保留queue/owner/input/frozen/marker检查，避免内置重开read_release |
| pb_natural_uses.py | per-use review/bound/audit接收提取/Source audit与Release facts |
| pb_natural_specs.py | Source proof/提取review/verify/audit接收已核Source与Generate；保留完整audit字节集合 |
| natural_live_admission.py | phase/scalar DTO与完整Authority区分；从Binding/Gen/Source facts重建阶段，不重进bound |
| natural_source_archives.py | Source prefix/body/resolved receipt的facts leaf，NS与controller仍分别配对 |
| pa_trial_dispatch.py | journal/slot/body/阶段accounting的事实leaf及固定source/live边；不改sender/reserve/reject |
| goal_applications.py | 同epochGenerate rawhistory一次、按角色Limits校验candidate；原请求/反馈/usage/锚点全保留 |
| text_apps.py | 从已核Generate candidate重建原确认与GA_APP_CONFIRMED叶检查，不重入verified_candidate |
| production_trial_policy.py | 单次已核ledger的private wire/identity绑定叶检查，原公共_bound仍先typed完整验证 |

`lifecycle.py`维持现有 `_read_release` 对 `_reuse_origin` 的原样透传，**不改文件**；`apps.py`则明确在边界内，不能只复用现有dict输入。当前代码在draft_gate/own_project/compile_preview之后若dict不匹配，会先公开verify_origin再被外层pin拒绝，因此v1的11文件方案是P2。v2须新增exact私有graph事实分支：进入前、每个可能回调的内部callee返回后和消费origin前，实际核nonce/epoch/token/connection/TX/driver/thread/controller/Settings及完整输入/角色Limits；错误或漂移直接拒绝，绝不落legacy分支。strict事实缺失不得进入该图调用；原非graph/default/dict调用仍保留原fallback，不能顺手改变其他路径。`production_trial_journal.py`保留现有_context/_quota/_ledger低层一次读取；sender/capture读取使用原私有leaf，每aid一次。DB/Store、schema、源resolver、软件锚点、配置/期限、公共DTO/HTTP、web/导航、Grant、账户/额度和其他家族执行不变。

若实际拆分发现上述existing leaf会重新递归或缺失原谓词，则此“12文件”边界尚不能直接实施，必须先修改设计再独审；不能临时绕检查或静默扩文件。必要定向测试范围仅为该图的原谓词对照、两epoch/角色/来源/漂移/错误归属和分项成本，不扩相邻恢复矩阵；此处仅设计，未建测试。

## 9. 不变量与未来接受条件

1. 只有单入口完整图能发布图完成态，节点无公开setter/任意resolve/fallback；无c.info/全局/跨Run图存储，事实显式传子节点。
2. 原permission-before-body次序、project/cursor锁顺序、所有所有者/runtime角色、Grant交集和每次敏感callback后的当前检查都保留；图不是grant缓存。
3. 按多重集保留所有原基数、事件/记录key集合、唯一/缺失/多余判定和严格排序；不改变LEFT/缺失行语义或用hash碰等代替内容证明。
4. 所有Generate、Source、提取、Cold每次材料+完整Goal、Recipe/candidate/Release/Instance/typed/result/审计血缘独立闭合。Source成功不能由Cold结果或本地示例代替。
5. 每个aid的slot/capture/NS/controller原字节、canonical、mode/model、usage三项、reserved wire/token、intent/receipt/Operation及相应锚点必须完整配对。
6. 各角色完整Limits、原frozen generation/history计数、阶段槽数与全局quota均保留；不能用一份平台4证明trial3。
7. G0/G1全图严格分开；五写原子、顺序相同，写后读取全部事实而非delta，任何失败五写全部rollback。
8. 现有_ModelSettlementRead.check完整指纹、callback drift、single-use和异常清理保持；成本UNKNOWN时不得删减。新facts不得作为未被pin的可变外部别名进入消费者。
9. 当前source/软件资格、完整Run/worker/version/fence/cancel/stop、lease/Run/contract/source/manifest/node等截止每次在真实当前时刻检查，不延长/暂停/重置。
10. 原异常码/unknown-vs-corrupt/owner及拒绝CAS归属保留；需要按原安全顺序安排节点，不把所有错误包为一个VERSION_CONFLICT或保证有REJECTED_KNOWN。多处同时损坏若因拓扑改变首错顺序，须显式记录/独审，不默认为兼容。
11. 无actor、发送、费用或真实模型许可变化，非目标路径走原实现；无主分支/部署/权限/协议变更。
12. 未来先证明“每epoch每事实键一次、每角色facet独立、完整谓词覆盖”及check/祖先分项成本，再由父级决定是否实施/执行下一门；当前只读设计不得冒称完整链或性能接受。

设计独审应明确：哪些边可以用已经完整通过的本地事实替换递归调用、哪些是必须继续fresh的权限/来源/时钟边，以及12文件平直leaf边界是否可兑现。历史FAIL、缺失的check计时及旧满盘独审缺口全部保留，当前设计不补造这些证据。


## 10. v1独审P2闭合与检验顺序约束

v1保留于v1/DESIGN.md，失败设计不改签。新增第12个文件apps.py是关闭实际内部fallback边，不是新的tail continuation。建议严格私有输入形状为exact `_ColdGraphOriginFacts`（仅设计名），包含当前图nonce/epoch/role/full-Limits和完整已核origin；只有局部图生产者能构造，不能由HTTP或caller dict字段启用。它只携带已核事实及current一致性检查，不提供resolve、读库、发送或权限动作。apps在识别strict类型后不再执行legacy匹配失败fallback；即使回调改了draft/limits/token，先拒绝，不调用公开verify_origin。lifecycle原透传无需新增分支。原dict/current ordinary fallback不是此次修复对象。

DAG是依赖关系而非“先把所有J/祖先都eager读完”的授权顺序。实施必须从原首个bound/commit_guard/receipts的**第一次需要该事实的位置**，按原安全顺序展开：先scope/权限，再对应metadata/body，再原pure谓词；已完整完成的同角色节点在后续原检查位置只复核当前性及必要live门。父节点仍显式传其已得到的子事实，不引入全局按需resolver。不得提前读取cursor/响应正文、为了收集多个错误而越过失败的权限/节点，或把相同数据的两个不同Limits facet提前并为一个。

第一写前原逻辑顺序仍是：lock_live → version/created_at/meta.deadline → 平台角色bound → 第一次原nontrial+trial完整guard → enabled → pending receipts → 当前RECEIVED行及meta/response → parse → usage相等 → output schema → receipt_for → 第二次原写前完整guard → 五写。第二次门复用同epoch完整事实，但当前权限/source/Run/期限照常；它不得只凭第一次结果允许写入。G1也保留原postguard → version/created/deadline → 平台bound → receipts → current owner/journal/Operation → frozen/各Limits → live →消费者的逻辑检查位置，只有各位置内部的重复完整祖先由显式已核事实替代。

这给出了原第一失败/unknown/corrupt/权限/预算错误的位置约束。不能通过拓扑排序把后来才检查的损坏先报出来，再声称“同为拒绝所以兼容”；如果未来实现无法保留某个原错误顺序或归属，应作为未闭合设计差异交独审/父级决定，不能静默上线。当前没有用伪代码证明已经实现这些顺序。

scope gates的当前owner/Grant/metadata复核仍独立执行，不用祖先一次完成位代替。严格事实在每个可能回调的内部callee返回后检查，再被消费；并不声称可以在不改Store的情况下为任意恶意Python回调的内部指令提供跨协议保证。原Store/SQLAlchemy受信事务协议、failed/no-op写epoch失效及driver.total_changes补充pin边界保持。


## 11. v3 原源码顺序定标（修正v2的第二项P2）

v2将pending receipts写在第一guard前，是作者设计错误；原件及独审P2保留，未执行该错误设计。规范顺序以8f源文件如下行号为准。下面的graph/facet是该位置内部的替换，不能把“全图”解释为在第一guard之前eager读取并校验所有后续receipt/Attempt。

| 原语义位置 | 8f源码位置 | 图入口仍必须执行的位置约束 |
| --- | --- | --- |
| 原响应归档、原failure抛出、原renew | natural_spec_runtime 1240–1245 | 不属于新图重排，保留原事务和失败归属 |
| TX / journal_reads / lock_live | 1246–1247 | 此处开始单入口G0，不预先跑一遍旧bound；实际锁/身份与原Store.guard保留 |
| current version、created_at、meta deadline | 1248–1253 | 必须在第一次完整bound之前判定 |
| 平台bound | 1254 | 此角色内部首次需要的祖先按原scope/body次序生成；不预执行后面的当前pending receipts |
| 第一完整commit_guard | 1255 | 原nontrial谓词和trial/current/source完整门在pending receipts之前；只共享先前完整通过的祖先事实 |
| enabled | 1256 | 仍在第一guard之后、pending receipts之前 |
| pending receipts / 当前row / RECEIVE配对 | 1257–1269 | 原Operation pending id、当前RECEIVED及原meta/response比较在此位置 |
| parse、usage、schema、receipt_for | 1270–1281 | 原模型/节点Limits/usage/意图/输出错误按此顺序 |
| 第二完整guard | 1282 | 复用同epoch祖先事实仍做当前安全边界；在第一业务写之前 |
| 原五写及中间final Attempt read | 1283–1332 | 原顺序含第一UPDATE后SELECT final、再NS_SETTLED。保留在同一TX；不合并、重排、提前提交 |
| 新journal_reads、postguard | 1336及_model_settlement_read 957–960 | G0已关闭；G1全新事实。从原postguard首次需要的角色开始，不先执行后来平台bound的不同角色校验 |
| version/created/deadline、admission/source pin | 961–969 | 完成原guard后立即核对/固定，不能推迟到后续callback之后 |
| enabled、平台bound、audit一致性 | 970–978 | 各current-check和bound输出立即pin保留；平台角色在原位置 |
| receipts、identity、journal、actual Attempt | 979–995 | 每个回调后原check保持；当前NS_SETTLED/usage/raw/wire/meta必须以G1实际值重核 |
| actual Operation、frozen/各角色Limits、live、READY | 996–1006 | 原次序；只有这里发布G1完整完成态，不以先前部分节点作顶层证明 |
| settle消费者、完整nontrial尾部及最后live | 1344–1347 / 原消费者方法 | 不新增tail continuation、不删原check、不跨epoch传旧证明；当前权限/来源/Run/期限仍fresh |

图的整个生命周期从TX入口开始，内部节点可以在这些原语义位置完成，但Root只在该epoch全部必需节点/谓词完成后发布完成态。子验证只收到其前置完整节点，不收到可任意补证的resolve接口。每个角色facet在原首次需要它的位置执行；同一原始实体的另一角色/完整Limits验证不因raw事实共享被提前或跳过。
