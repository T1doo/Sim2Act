# Batch1 shared fact leaves: independent review

**BATCH1_FACT_LEAVES_ACK. No open P1/P2.** The frozen four-file candidate is acceptable within the separately authorized batch1 extraction scope. This is not graph integration, full-history flattening, a performance result, or complete P-B acceptance. No new graph/full-chain run is authorized by this review.

The reviewed baseline is `8f8a289a392321d240e73b279a61fb064ae78241`. The candidate patch SHA256 is `e8c6c02d13e6fb89b5d4a09bcf797edb0d30f311689f1ed8094de248b929ee5d`. All four source/test snapshots match CANDIDATE.json and the actual working tree after the gates. At review time the author has not committed these changes: this conclusion pins the frozen bytes/patch and does not claim a future Git commit or push was verified.

The independent reviewer read source, baseline Git blobs, ASTs and closed JSON/XML/text evidence only. No product import/execution, tests, model, DB open/query, network, repository/raw-evidence write or old-seal write was performed. Only this new review directory was written. The earlier missing report caused by a full disk was not recreated or signed here.

## Source and invariant findings

All **28 recorded AST comparisons passed**. Unchanged module nodes and public signatures are preserved; changes are confined to the three approved product files and one new test file. Direct product call sites for the new leaves remain in their original public/private wrappers. No alternative route, new graph, executor, permission, durable state, quota/lease/time change or proof cache was introduced.

- `production_trial_policy._bound` keeps the transaction check, `_requirements`, `_ledger`, and left-to-right `_typed` calls before the extracted tail. `_bound_from_checked_facts` retains the actual project lock and the exact principal/scope/runtime/wire/quota/cursor predicates. It is structural binding, not fresh permission: reserve duplicate handling and settle's late actual-usage/halting behavior retain their original subsequent `_fresh` positions.
- `goal_applications._verified_candidate` keeps source, complete history/cardinality/diagnostic checks, role-specific full Limits parsing, then seal and the full `GA_CANDIDATE_VALIDATED` list. The seal deliberately rereads `rows[-1]` after parse, preserving the original callback replacement behavior. Frozen history Limits and caller candidate Limits (including the original None fallback) are not merged or projected.
- Counter checking retains typed rows before Operations SELECT, followed by the exact complete counter/Operations/budget tail. The post-read exact-int reserved_tokens recheck remains; `generation_diagnostic is not None` still counts a False diagnostic and rejects a final False diagnostic. All four counters, spec/non-spec allowed tools and cardinality budgets remain.
- `text_apps.verify_origin` keeps the PA and task-proof branches. Ordinary Goal verification still reads marker, gates owner, reads Run, verifies the candidate, parses confirmation, constructs the complete accepted record, reads the whole confirmation-anchor list and applies the exact final predicates. Confirmation parsing and fingerprint construction have not been advanced ahead of their original checks/IO.

These are private checked-fact leaves, not opaque proof or authorization objects. Future graph consumers must still provide complete currently checked facts, preserve all original permission/Run/time checks and IO/error order, separate full Limits roles and perform a new complete first proof after writes. In particular `_check_counters_from_facts` retains its explicit prerequisite `_check_counter_rows`; the policy leaf still performs real project locking.

## Actual bounded gates

| Group | Actual result | Pytest / outer time |
| --- | --- | --- |
| focused-v1, new leaf regressions | 4 PASS, 0 SKIP | 48.403 / 54.163307 s |
| compatibility-core-v2, policy7 + ordinary1 | 8 PASS, 0 SKIP | 60.439 / 83.393650 s |
| compatibility-origin-v2 | 5 PASS, 0 SKIP | 90.714 / 97.874226 s |
| lint-v1, four changed files | PASS | 0.129020 s outer |
| mypy-v1, `src` | PASS, 113 source files | 55.662666 s outer |

The three completed pytest groups contain **17 unique passing nodes**, with no failures/errors/skips. Each group reports one existing Starlette deprecation warning. All five completed gate receipts pin the same four candidate file hashes before/after; the reviewer independently matched those bytes. This is not a claim that the receipts hash-pinned all 113 individual source files.

The focused actual SQLite case uses the existing explicit MockTransport fixture to complete ordinary text repair generation with three Mock requests, confirmation and public origin. It checks nine complete Limits roles (None, platform, frozen and all six field changes), exact full candidate/public errors, four counters and missing/duplicate candidate/confirmation anchor lists. Explicit unit stubs additionally check normalization/lock/check order and parse-before-final-seal behavior. Public-wrapper versus direct-leaf comparisons share the candidate predicates; baseline AST equality supplies the separate original-predicate comparison. ReadSequence unit stubs demonstrate call order rather than standalone DBAPI SQL parity.

The core gate retains the original synthetic policy source-expiry/revocation/missing-entitlement, Run/version/fence/lease/phase, cancellation, unknown/missing usage/no resend, restored-state/callback rejection cases. Its ordinary-read test includes actual three-Mock generation and write/expiry invalidation. The origin gate rejects resigned candidate, marker, executor, Attempt and frozen-route changes through the existing public route. Synthetic uninstalled policy DTO transitions are not production permits or DB-global quota acceptance.

## Retained unsuccessful attempt and limits

The original 14-case compatibility-v1 hit its 180-second runner timeout (outer **180.109200 s**), has no complete JUnit and only eight progress dots. It remains **TIMEOUT**, not an aggregate pass or eight qualified passes. The ninth selected positive Cold test includes successful and malformed Cold inputs and exceeds this bounded fact-leaf scope. It was not completed or qualified in this batch. The original receipt/stdout and the author's explicit scope correction are preserved. The successful replacement 8+5 gates do not rewrite that result. The initial new-test import/callback lint failure is also retained as a failed draft iteration; only the frozen lint-v1 is counted as passing.

No full P-B, new graph path, performance benchmark, real model/semantic scenario, Windows, PostgreSQL or remote CI was executed/accepted by this batch review. The actual mock/SQLite results do not establish a latency upper bound. The previously delivered complete P-B chain remains **FAIL_NOT_ACCEPTED**. Batch1 provides only the shared-predicate foundation and preserves that unresolved integration boundary.
