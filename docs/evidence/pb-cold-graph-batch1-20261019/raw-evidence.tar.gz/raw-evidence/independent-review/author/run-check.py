import datetime, hashlib, json, os, pathlib, subprocess, sys, time
root = pathlib.Path(__file__).parent
repo = pathlib.Path('/workspace/Sim2Act')
label, *command = sys.argv[1:]
folder = root / label
folder.mkdir(exist_ok=False)
paths = ['src/sim2act/production_trial_policy.py', 'src/sim2act/goal_applications.py', 'src/sim2act/text_apps.py', 'tests/test_cold_settlement_fact_leaves.py']
hashes = {path: hashlib.sha256((repo/path).read_bytes()).hexdigest() for path in paths}
env = os.environ.copy()
env.pop('SIM2ACT_TEST_DATABASE_URL', None)
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
tick = time.monotonic()
try:
    result = subprocess.run(command, cwd=repo, env=env, capture_output=True, text=True, timeout=180)
    stdout, stderr, code, timed_out = result.stdout, result.stderr, result.returncode, False
except subprocess.TimeoutExpired as exc:
    stdout, stderr, code, timed_out = exc.stdout or b'', exc.stderr or b'', None, True
    if isinstance(stdout, bytes): stdout = stdout.decode(errors='replace')
    if isinstance(stderr, bytes): stderr = stderr.decode(errors='replace')
(folder/'stdout.txt').write_text(stdout)
(folder/'stderr.txt').write_text(stderr)
final_hashes = {path: hashlib.sha256((repo/path).read_bytes()).hexdigest() for path in paths}
receipt = dict(command=command, started_at=started, ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), wall_seconds=time.monotonic()-tick, exit_code=code, timed_out=timed_out, timeout_seconds=180, source_sha256_before=hashes, source_sha256_after=final_hashes, sources_stable=hashes==final_hashes, test_database='SIM2ACT_TEST_DATABASE_URL removed from child; pytest fixture uses isolated SQLite', real_model_authorized=False, full_pb_authorized=False)
(folder/'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(dict(label=label, exit_code=code, timed_out=timed_out, wall_seconds=receipt['wall_seconds'], sources_stable=receipt['sources_stable'])))
print(stdout[-10000:])
print(stderr[-5000:])
sys.exit(1 if timed_out else code)
