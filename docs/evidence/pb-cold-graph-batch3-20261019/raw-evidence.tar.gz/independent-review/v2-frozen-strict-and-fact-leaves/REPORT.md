# Batch3 独立有限审查

结论：**BATCH3_STRICT_AND_FACT_LEAVES_ACK**。最终 candidate-v3 未发现剩余 P1/P2；已发现的严格通道形状/engine 固定 P2 已闭合。此 ACK 只覆盖本批五个生产文件、一个短测试文件及 caller 责任表。它不表示 Cold 图已经接入、性能达标或完整 P-B 通过。

基线为 `51db08400b5f01c45e66210e8d01d8ddb605856b`。独审采用冻结 candidate-v3，而非未来提交。核对时仓库 HEAD 仍为该基线，五个生产改动与测试尚在工作树，另有交付文档；未核验未来提交、推送或未来包。七个冻结文件逐 SHA 匹配当前文件，三个正式门的六个选中文件逐 SHA 匹配冻结源。具体记录见 [INPUT-AND-GATE-BRIDGE.json](INPUT-AND-GATE-BRIDGE.json)。

审查者只读取本地源码、冻结快照、JSON/XML/日志并进行 stdlib AST/哈希核对及只读 Git；没有导入或执行产品、测试、数据库、模型、网络。没有写仓库或旧封存目录。作者已经执行的门与审查者读取证据分开记录。

## 语义与范围

[AST-COMPARISON.json](AST-COMPARISON.json) 的 24 项检查全部成立：将 12 个新私有事实叶按原参数内联后，四模块相关原入口的完整函数体与基线 AST 相同；阶段字段前缀还原到原构造器后，末位 authorization 读库位置相同。apps 默认及普通 dict 分支剔除新增 strict 专属控制后，与原完整校验体一致，公开签名未变。其他既有节点除声明的导入外未变。AST 对照覆盖提取与原入口，不代替对新增 strict 实现的人工审查。

app_jobs 的 queue/AppRun/request/Release 叶保留 permission-before-body、完整输入和实际逐次材料；pb_use 的 identity/checked review/audit 叶保留 PA/PB 分支、完整 frozen/approved_grant_state 和各自完整 Limits；阶段三叶保留材料/完整 Goal/生成身份及末位实际授权读取。阶段部分字段没有 authorization_fingerprint，不能当作 StageAuthority。spec 的 clock/plan 叶保留原 clocks、完整 Limits 及 generation_mode 的原短路顺序。没有删减历史、多重集、唯一性、receipt、ledger 或 NS/controller 原始完整字节核对；叶不能替代取得这些事实的原入口职责。

新增 `_ColdGraphOriginFacts` 是 dormant 的局部私有通道。对全部 src 的静态调用扫描没有 `_cold_graph_origin_facts` 生产调用点；只有测试调用。当前没有 Cold 图生产者、shadow、通用 resolver/cache、executor 或新 Grant。原模型结算、两个 epoch、五写、sender/reserve/reject/TTL 均不在本批改动范围；相关上下文与基线相同的源码另附 context 快照。

strict exact 类型分支在入口、draft_gate/own_project/source-family/compile 返回后、家族判定后、消费前和返回前核当前性；任一异常/漂移永久失效，不进入公开 verify_origin fallback，原异常对象保留。工厂局部 nonce、active/busy 状态及退出清理限制了重入和离开作用域后的使用。固定范围包括 Worker/Store/原 engine/Settings/controller、Connection/transaction/driver/thread、SourceReads token/epoch/total_changes、完整 inputs/origin 与角色 Limits。默认与 dict 的旧匹配/fallback 语义保留。

该对象只固定调用者传入的完整事实与连续性，**不证明调用者没有漏事实，也不重新授权或缓存 ALLOW**。未来生产者必须先按原顺序完成完整角色历史、基数、NS/controller 逐字节证明，敏感边界仍实际检查所有权限、批准、source、owner/version/fence/取消/lease/期限。角色 None 与完整六维 Limits 不能互相替换；G0/G1 不跨写复用。lifecycle 仍原样透传，该类不宣称覆盖 lifecycle 所有前后回调。责任已明确写入 [CALLER-RESPONSIBILITIES.md](candidate-v3/docs/evidence/pb-cold-graph-batch3-20261019/CALLER-RESPONSIBILITIES.md)。

## P2 闭合

candidate-v2 的 strict 当前性仅比较规范化值：同向量 Limits 换成 dict 可被规范化为等值，且 engine 原来仅核当前 Store/Connection 的关系，没有独立固定最初 engine。此为 dormant 私有合同的 P2，并非已部署授权绕过。

candidate-v3 每次 `_check` 重新验证 exact inputs/role/角色 Limits/origin 形状；原 engine 单独保存，Store 与 Connection 都必须仍为该对象，factory 要求 exact Store。三个实际短用例分别替换 Limits→dict、origin tuple→list、同时替换两边 engine，均拒绝、verify_origin 调用数为零，随后仍保持失效。其他四生产文件与 v2 逐哈希相同。见 [P2-CLOSURE.json](P2-CLOSURE.json)。没有剩余 P1/P2，也没有新增必需测试。

## 最终实际门

| 门 | 实际结果 | 原始证据 |
| --- | --- | --- |
| focused-v5 | 24 PASS，0 FAIL/ERROR/SKIP；新 20 + 原兼容 4；pytest 40.54s，runner 44.800285s | [JUnit](gates/focused-v5/junit.xml)、[receipt](gates/focused-v5/receipt.json)、[stdout](gates/focused-v5/stdout.txt) |
| lint-v2 | Ruff 六个改动生产/测试文件 PASS；runner 0.079265s | [receipt](gates/lint-v2/receipt.json)、[stdout](gates/lint-v2/stdout.txt) |
| mypy-v2 | `mypy src`，113 source files PASS；runner 21.966018s | [receipt](gates/mypy-v2/receipt.json)、[stdout](gates/mypy-v2/stdout.txt) |

三份 receipt 都 exit 0、未超时、sources_stable=true，选中六文件的 before/after 等于 candidate-v3。receipt 没有逐一固定全部 113 源或整个环境，不能扩大哈希保证。JUnit 的 24 唯一节点与 summary 一致；一个既有 Starlette 弃用 warning 保留。

新用例使用隔离 SQLite/实际 SourceReads 与写失效钩子，阻止 HTTP/Async/Mock 模型 transport。严格通道夹具用 object.__new__(Worker) 及显式 gate/compile/origin stubs，不是 claim、软件资格、真实 source、完整历史授权或 stage 接受证明。用例覆盖原 default/dict 顺序、strict 无 fallback、四回调漂移、NoOp/失败/直接 driver 写失效、完整输入顺序/字节/nonce/异常清理、queue/per-use/角色 Limits、阶段 partial DTO、缺事实及重入。兼容四项是原固定 CSV NoModel、绑定输入变化拒绝、默认关闭零 Attempt、权限先于私有批准读取；它们不等于新的 P-B 阶段接受。

## 历史尝试与限制

leaves-v1 是 1 PASS/15 fixture ERROR，且 sources_stable=false，**NOT_ACCEPTED/NOT_FROZEN**；缺完整 Limits 的测试夹具错误与执行中源变化原件均保留。leaves-v2 是 1 PASS/15 fixture ERROR（不完整 focus recipe），leaves-v3 是 1 PASS/16 fixture ERROR（非 runtime_<32hex> 合成 ID）。没有将任何失败补签。v4 smoke、17 项以及较早兼容/质量成功只作为历史，不重复计入最终 24。原 receipt、stdout/stderr、JUnit 和失败注释均在 gates/ 与 author/attempts/。

本批没有运行 Source/P-B 长前缀、完整 P-B、真实语义/场景、Windows、PostgreSQL、远端 CI、部署或性能 benchmark。指纹独占成本仍 UNKNOWN。没有保证任意恶意 Python/原生事务逃逸可被捕获；total_changes 仅为受信 Store/SQLAlchemy 产品路径中的额外实际行写 pin。旧满盘未落盘的独审证据没有被恢复或补签。完整 P-B 的历史分类继续为 **FAIL_NOT_ACCEPTED**。

本报告支持对本批基础叶与 dormant 严格通道作有限验收，并继续普通开发分支的证据提交；未来启图或扩展生产文件仍需另行授权和审查。
