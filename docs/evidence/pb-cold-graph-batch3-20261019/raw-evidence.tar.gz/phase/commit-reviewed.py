"""Commit the reviewed candidate and evidence, without pushing or rewriting history."""
import datetime,hashlib,json,pathlib,subprocess
repo=pathlib.Path('/workspace/Sim2Act');root=pathlib.Path(__file__).parent
baseline='51db08400b5f01c45e66210e8d01d8ddb605856b'
branch='dev/production-trial-stages-20261018'
def git(*args):
 return subprocess.run(['git','-c','core.fsmonitor=false',*args],cwd=repo,capture_output=True,check=True)
assert git('rev-parse','HEAD').stdout.decode().strip()==baseline
assert git('branch','--show-current').stdout.decode().strip()==branch
paths=list(json.loads((root/'candidate-v3/SOURCE-MANIFEST.json').read_text())['paths'])
for p,h in json.loads((root/'candidate-v3/SOURCE-MANIFEST.json').read_text())['paths'].items():
 assert hashlib.sha256((repo/p).read_bytes()).hexdigest()==h
extra=['docs/evidence/pb-cold-graph-batch3-20261019/'+n for n in ('README.md','RAW-SEAL.json','raw-evidence.tar.gz')]
expected=sorted(paths+extra)
assert len(expected)==10
assert not git('diff','--cached','--name-only').stdout
assert b'INDEPENDENT_REVIEW_PENDING' not in (repo/extra[0]).read_bytes()
git('add','--',*expected)
actual=git('diff','--cached','--name-only').stdout.decode().splitlines();assert sorted(actual)==expected
git('diff','--cached','--check')
staged={p:hashlib.sha256(git('show',':'+p).stdout).hexdigest() for p in expected}
assert all(staged[p]==hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in expected)
(root/'staging-receipt.json').write_text(json.dumps(dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline=baseline,branch=branch,files=staged,diff_check=0),indent=2)+'\n')
result=git('commit','-F',str(root/'commit-message.txt'))
head=git('rev-parse','HEAD').stdout.decode().strip()
assert git('rev-parse','HEAD^').stdout.decode().strip()==baseline
(root/'commit-result.json').write_text(json.dumps(dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=head,parent=baseline,stdout=result.stdout.decode(),stderr=result.stderr.decode(),committed_sha256={p:hashlib.sha256(git('show','HEAD:'+p).stdout).hexdigest() for p in expected}),indent=2)+'\n')
print(result.stdout.decode());print(head)
