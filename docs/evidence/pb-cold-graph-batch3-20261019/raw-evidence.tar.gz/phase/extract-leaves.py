from pathlib import Path
root=Path('/workspace/Sim2Act/src/sim2act')
def extract(text,start,end,name,params,call,returns='',indent='    '):
    assert text.count(start)==1, (name,'start')
    begin=text.index(start); finish=text.index(end,begin)
    block=text[begin:finish]
    leaf='def '+name+'('+params+'):\n    """Pure original predicates; caller retains all preceding scope/IO gates."""\n'+''.join(line[ len(indent)-4:] if line.strip() else line for line in block.splitlines(True))+returns+'\n\n'
    return text[:begin]+indent+call+'\n'+text[finish:],leaf
p=root/'app_jobs.py';s=p.read_text();leaves=[]
s,leaf=extract(s,'    if not b or job["principal_id"] != user:\n','    a = (\n','_binding_queue_from_facts','job, user, b','s = _binding_queue_from_facts(job, user, b)','    return s\n');leaves.append(leaf)
s,leaf=extract(s,'    if not a or fingerprint(s) != b["fingerprint"] or job["fingerprint"] != b["fingerprint"]:\n','    request = {\n','_binding_app_run_from_facts','job, b, s, a','_binding_app_run_from_facts(job, b, s, a)');leaves.append(leaf)
start='    if (\n        s["namespace"] != KIND\n';end='    store.own_project(c, user, s["project_id"])\n'
s,leaf=extract(s,start,end,'_binding_request_from_facts','job, user, s, a, request','_binding_request_from_facts(job, user, s, a, request)');leaves.append(leaf)
start='        if (\n            r["fingerprint"] != s["expected_release_fp"]\n';end='    return (s, a, r) if return_release else (s, a)\n'
s,leaf=extract(s,start,end,'_binding_release_from_facts','job, s, r, expected_resource','_binding_release_from_facts(job, s, r, expected_resource)',indent='        ');leaves.append(leaf)
s=s.replace('def load_binding(',''.join(leaves)+'def load_binding(',1);p.write_text(s)
p=root/'pb_natural_uses.py';s=p.read_text();leaves=[]
s,leaf=extract(s,'    require(saved_family(base["candidate"]) == family\n','    material, goal = spec.target(','_review_identity_from_facts','instance, release, body, base, saved, family','_review_identity_from_facts(instance, release, body, base, saved, family)');leaves.append(leaf)
s,leaf=extract(s,'    require(body.expected_review_fingerprint == checked["review_fingerprint"]\n','    if (_read_out is not None and family == PB','_bound_review_from_facts','job, snapshot, release, limits, family, body, frozen, checked','draft, manifest, report = _bound_review_from_facts(job, snapshot, release, limits, family, body, frozen, checked)','    return draft, manifest, report\n');leaves.append(leaf)
old='    return fingerprint(dict(base=base_digest, meta=meta.model_dump(),\n        scope_seal=seal_meta, request=body.model_dump(), frozen=frozen))\n'
assert s.count(old)==1
s=s.replace(old,'    return _audit_from_facts(base_digest, meta, seal_meta, body, frozen)\n')
leaves.append('def _audit_from_facts(base_digest, meta, seal_meta, body, frozen):\n    """Digest complete paired facts, after the original current scope/base audit."""\n'+old+'\n\n')
s=s.replace('def review(',''.join(leaves)+'def review(',1);p.write_text(s)
p=root/'natural_live_admission.py';s=p.read_text();leaves=[]
s,leaf=extract(s,'    require(bound["source"]["resource_id"] == target.resource_id\n','    # Match the original generation','_stage_target_from_facts','bound, target','_stage_target_from_facts(bound, target)');leaves.append(leaf)
s,leaf=extract(s,'    first = contract.bindings[0]\n    require(type(gen["created_at"])','    original = draft["candidate"]\n','_stage_generate_from_facts','contract, approval, gen, frozen','_stage_generate_from_facts(contract, approval, gen, frozen)');leaves.append(leaf)
start='    authority = authority_model(**timing, contract_fingerprint=fingerprint(contract.model_dump()),\n';end='    return authority, job\n'
b=s[s.index(start):s.index(end,s.index(start))]
# Prefix fields are computed before authorization IO just as in the original argument list.
prefix=b[:b.index('        authorization_fingerprint=')]
prefix=prefix.replace('    authority = authority_model(**timing,','    return dict(**timing,',1).rstrip()+')\n'
leaf='def _stage_authority_fields_from_facts(contract, stage, timing, job, bound, inst, draft, release, gen_id, raw, target):\n    """Partial fields only; never a complete StageAuthority or a permission."""\n'+prefix+'\n\n';leaves.append(leaf)
replacement='    fields = _stage_authority_fields_from_facts(contract, stage, timing, job, bound, inst, draft, release, gen_id, raw, target)\n    authority = authority_model(**fields, authorization_fingerprint=authorization_fingerprint(c, user, contract.project_id,\n            job["runtime_id"], [b.resource_id for b in contract.bindings]))\n'
s=s.replace(b,replacement,1);s=s.replace('def _stage_current_bound(',''.join(leaves)+'def _stage_current_bound(',1);p.write_text(s)
p=root/'pa_spec_apps.py';s=p.read_text();leaves=[]
start='        require(isinstance(clock, dict) and set(clock) == {"created_at", "deadline"}\n';end='        counters(c, job, manifest)\n'
s,leaf=extract(s,start,end,'_bound_clock_from_facts','clock, job, contract, manifest','_bound_clock_from_facts(clock, job, contract, manifest)',indent='        ');leaves.append(leaf)
start='    plan = dict(definition=draft["candidate"], input=snapshot["input"],\n';end='    value = dict(snapshot=snapshot,'
s,leaf=extract(s,start,end,'_bound_plan_from_facts','draft, snapshot, source','plan = _bound_plan_from_facts(draft, snapshot, source)','    return plan\n');leaves.append(leaf)
s=s.replace('def _bound(',''.join(leaves)+'def _bound(',1);p.write_text(s)
