"""Build bounded inspectable raw evidence after independent review, no DB files."""
import gzip
import hashlib
import io
import json
import pathlib
import shutil
import sys
import tarfile

root = pathlib.Path(__file__).parent
review = pathlib.Path(sys.argv[1])
report = pathlib.Path(sys.argv[2])
review_manifest = pathlib.Path(sys.argv[3])
assert report.is_file() and review_manifest.is_file()
repo_docs = pathlib.Path('/workspace/Sim2Act/docs/evidence/pb-cold-graph-batch3-20261019')
raw = root / 'raw-evidence'
assert not raw.exists()
excluded = {'raw-evidence', 'DELIVERY-MANIFEST.json', 'DELIVERY-SEAL.json'}
files = [p for p in root.rglob('*') if p.is_file() and not p.is_symlink()
    and not any(x in excluded or x.endswith('-tmp') or x in {'tmp', '__pycache__'} for x in p.relative_to(root).parts)]
raw.mkdir()
for source in files:
    target = raw / 'phase' / source.relative_to(root)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
for source in review.rglob('*'):
    if source.is_file() and not source.is_symlink():
        target = raw / 'independent-review' / source.relative_to(review)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
entries = []
for p in sorted(raw.rglob('*')):
    if p.is_file():
        payload = p.read_bytes()
        entries.append(dict(path=str(p.relative_to(raw)), bytes=len(payload), sha256=hashlib.sha256(payload).hexdigest()))
manifest = raw / 'MANIFEST.json'
manifest.write_text(json.dumps(dict(excluded='All test tmp DB directories, caches, pytest symlinks; post-package delivery metadata', files=entries), indent=2) + '\n')
archive = repo_docs / 'raw-evidence.tar.gz'
assert not archive.exists()
with archive.open('wb') as destination, gzip.GzipFile(filename='', fileobj=destination, mode='wb', mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w') as tar:
    for p in sorted(raw.rglob('*')):
        if not p.is_file():
            continue
        payload = p.read_bytes()
        info = tarfile.TarInfo(str(p.relative_to(raw)))
        info.size, info.mode, info.mtime = len(payload), 0o444, 0
        tar.addfile(info, io.BytesIO(payload))
expected = {e['path']: e for e in entries}
with tarfile.open(archive) as tar:
    members = tar.getmembers()
    assert len(members) == len(entries) + 1
    for m in members:
        assert m.isfile() and not pathlib.PurePosixPath(m.name).is_absolute() and '..' not in pathlib.PurePosixPath(m.name).parts
        payload = tar.extractfile(m).read()
        assert m.size == len(payload)
        if m.name == 'MANIFEST.json':
            assert payload == manifest.read_bytes()
        else:
            assert expected[m.name]['bytes'] == len(payload)
            assert expected[m.name]['sha256'] == hashlib.sha256(payload).hexdigest()
result = dict(archive='raw-evidence.tar.gz', bytes=archive.stat().st_size, sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), regular_members=len(members), manifest_members=len(entries), manifest_sha256=hashlib.sha256(manifest.read_bytes()).hexdigest(), all_members_verified=True, independent_report=str(report), independent_report_sha256=hashlib.sha256(report.read_bytes()).hexdigest(), independent_manifest=str(review_manifest), independent_manifest_sha256=hashlib.sha256(review_manifest.read_bytes()).hexdigest(), excluded='Temporary SQLite DBs, caches and pytest aliases; no test DB or prior bundle included', historical_full_pb='FAIL_NOT_ACCEPTED', hash_cost='UNKNOWN')
(repo_docs/'RAW-SEAL.json').write_text(json.dumps(result, indent=2)+'\n')
(root/'raw-package-result.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
