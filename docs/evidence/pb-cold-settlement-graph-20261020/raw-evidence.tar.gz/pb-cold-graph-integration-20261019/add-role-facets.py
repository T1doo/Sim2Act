from pathlib import Path
p=Path('/workspace/Sim2Act/src/sim2act/lifecycle.py')
s=p.read_text(); pos=s.index('\n\ndef create_instance(',s.index('def _cold_release_from_origin'))
extra='''

@dataclass(frozen=True)
class _ColdReleaseFacts:
    prefix: _ColdReleasePrefix
    candidate_prefix: Any
    release: Any
    origin: tuple
    key: str


def _cold_release_complete(store, c, user, prefix, candidate_prefix, origin):
    from . import apps
    from .natural_spec_runtime import _ColdGraphRead
    from .pa_spec_apps import require
    try:
        require(type(prefix) is _ColdReleasePrefix and type(candidate_prefix) is apps._ColdCandidatePrefix)
        guard = prefix.guard
        _checkpoint_release_read(store, c, guard)
        with apps._cold_graph_origin_facts(guard.worker, c, guard.inputs, prefix.role, guard.role_limits,
                user, candidate_prefix.draft, prefix.limits, origin) as facts:
            release = _cold_release_from_origin(store, c, user, prefix, candidate_prefix, facts)
        _checkpoint_release_read(store, c, guard)
        key = prefix.key + ":complete"
        guard.add(key, dict(release=dict(release), origin=dict(manifest=origin[0].model_dump(),
            report=origin[1], material=origin[2], goal=origin[3]), limits=prefix.limits, role=prefix.role))
        return _ColdReleaseFacts(prefix, candidate_prefix, release, origin, key)
    except BaseException:
        if type(prefix) is _ColdReleasePrefix and type(prefix.guard) is _ColdGraphRead:
            prefix.guard.invalidate()
        if type(candidate_prefix) is apps._ColdCandidatePrefix and type(candidate_prefix.guard) is _ColdGraphRead:
            candidate_prefix.guard.invalidate()
        raise


def _cold_release_facet_prefix(store, c, user, complete, limits):
    from . import apps
    from .natural_spec_runtime import _ColdGraphRead, _model_inputs
    from .pa_spec_apps import require
    try:
        require(type(complete) is _ColdReleaseFacts and type(limits) is Limits)
        old = complete.prefix
        guard = old.guard
        _checkpoint_release_read(store, c, guard)
        require(old.user == user and complete.release is old.release
            and "natural_logic_source" not in complete.release["snapshot"]
            and "execution_source" not in complete.release["snapshot"]
            and _model_inputs(dict(complete.release)) == _model_inputs(guard.inputs[complete.key]["release"]),
            "Cold Release facet requires its complete same-epoch original Release")
        key = "release-prefix:" + old.role + ":" + user + ":" + complete.release["id"] + ":" + fingerprint(limits.model_dump())
        guard.add(key, dict(user=user, role=old.role, release_id=complete.release["id"], limits=limits))
        guard.add(key + ":row", dict(complete.release))
        prefix = _ColdReleasePrefix(guard, key, user, complete.release, limits, old.role)
        candidate = apps._cold_candidate_prefix(store, c, user, complete.release["snapshot"]["draft"], limits, guard, old.role)
        return prefix, candidate
    except BaseException:
        if type(complete) is _ColdReleaseFacts and type(complete.prefix.guard) is _ColdGraphRead:
            complete.prefix.guard.invalidate()
        raise
'''
s=s[:pos]+extra+s[pos:];p.write_text(s)
p=Path('/workspace/Sim2Act/src/sim2act/app_jobs.py')
s=p.read_text();pos=s.index('\n\ndef inspect_job(',s.index('class _ColdBindingPrefix'))
extra='''

def _cold_binding_facet(store, c, user, prefix, limits):
    """Same complete raw queue identity, with a distinct caller Limits facet."""
    from .natural_spec_runtime import _ColdGraphRead, _model_inputs
    from .pa_spec_apps import require
    try:
        require(type(prefix) is _ColdBindingPrefix and type(limits) is Limits)
        guard = prefix.guard
        _binding_checkpoint(store, c, guard)
        require(prefix.user == user and _model_inputs(dict(job=dict(prefix.job), snapshot=prefix.snapshot,
            app_run=dict(prefix.app_run), contract=prefix.contract.model_dump(), limits=prefix.limits))
            == _model_inputs(guard.inputs[prefix.key]))
        key = "binding-prefix:" + prefix.role + ":" + prefix.job["id"] + ":" + fingerprint(limits.model_dump())
        guard.add(key, dict(job=dict(prefix.job), snapshot=prefix.snapshot, app_run=dict(prefix.app_run),
            contract=prefix.contract.model_dump(), limits=limits))
        return _ColdBindingPrefix(guard, key, user, prefix.job, limits, prefix.role,
            prefix.snapshot, prefix.app_run, prefix.contract)
    except BaseException:
        if type(prefix) is _ColdBindingPrefix and type(prefix.guard) is _ColdGraphRead:
            prefix.guard.invalidate()
        raise
'''
s=s[:pos]+extra+s[pos:];p.write_text(s)
