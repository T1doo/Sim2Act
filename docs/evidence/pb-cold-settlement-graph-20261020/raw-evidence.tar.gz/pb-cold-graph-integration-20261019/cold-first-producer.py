@dataclass(frozen=True)
class _ColdBindingGraph:
    guard: _ColdGraphRead
    binding: dict
    binding_prefix: object
    release: object
    counter_reader: _ColdRunFacts
    source_binding: dict
    source_binding_prefix: object
    source_release: object
    source_counter_reader: _ColdRunFacts
    source_facts: object
    source_audit: object
    native_audit: dict
    source_outputs: dict
    source_proved: list
    generation_reader: object
    generation_contract: object
    generation_material: dict
    generation_history: tuple
    generation_raw: dict
    generation_marker: object
    original_origin_prefix: object
    extraction_prefix: object
    extraction_review: object
    extraction_origin: tuple
    extraction_audit_prefix: object
    extraction_audit: str
    use_prefix: object
    use_review: object
    use_value: tuple
    use_audit_prefix: object


def _cold_first_binding(worker, c, guard, current, limits):
    """Fixed original plain-PB dependency expansion at its first bound edge."""
    from . import app_jobs, apps, goal_applications as ga, lifecycle
    from . import pa_spec_apps as spec
    from . import pb_natural_specs as pb
    from . import pb_natural_uses as use
    from .db import goal_application_candidates, runs

    store, user = worker.store, current['principal_id']
    try:
        _cold_read_checkpoint(store, c, guard)
        cold_queue = app_jobs._cold_binding_prefix(store, c, user, current, limits, guard, 'cold')
        cold_release = lifecycle._cold_release_prefix(store, c, user, cold_queue.snapshot['release_id'], limits, guard, 'cold')
        cold_draft = cold_release.release['snapshot']['draft']
        cold_candidate = apps._cold_candidate_prefix(store, c, user, cold_draft, limits, guard, 'cold')
        extraction = pb._cold_verify_prefix(store, c, user, cold_draft, limits, guard, 'cold')
        source_prefix = pb._cold_source_prefix(store, c, user, cold_draft['project_id'],
            extraction.body.review.source_run_id, limits, guard, 'cold')
        source_job = source_prefix.job
        source_queue = app_jobs._cold_binding_prefix(store, c, user, source_job, limits, guard, 'source')
        source_release = lifecycle._cold_release_prefix(store, c, user, source_queue.snapshot['release_id'], limits, guard, 'source')
        source_draft = source_release.release['snapshot']['draft']
        source_candidate = apps._cold_candidate_prefix(store, c, user, source_draft, limits, guard, 'source')
        original = spec._cold_original_origin_prefix(store, c, user, source_draft, limits, guard)
        marker = c.execute(select(goal_application_candidates).where(
            goal_application_candidates.c.app_id == source_draft['id'])).mappings().first()
        _cold_read_checkpoint(store, c, guard)
        guard.add('original-ga-marker:' + source_draft['id'], dict(marker) if marker is not None else None)
        if not marker or marker['principal_id'] != user:
            raise DomainError('VERSION_CONFLICT', 'Independent goal generation marker required')
        generation = c.execute(select(runs).where(runs.c.id == marker['run_id'])).mappings().one()
        _cold_read_checkpoint(store, c, guard)
        gen_contract, gen_material, gen_reader = ga._cold_generation_source(store, c, generation, guard)
        history = ga._cold_history_from_source(store, c, generation, gen_contract, gen_material, gen_reader)
        gen_raw = ga._cold_candidate_from_history(store, c, generation, gen_contract, gen_material, history, limits, gen_reader)
        source_origin = spec._cold_original_origin_from_generation(store, c, user, original, gen_reader, gen_raw, marker)
        source_complete = lifecycle._cold_release_complete(store, c, user, source_release, source_candidate, source_origin)
        app_jobs._cold_binding_release_prefix(store, c, user, source_queue, source_complete.release)
        source_reader = _cold_run_facts(store, c, source_job, guard)
        source_bound_prefix = spec._cold_bound_prefix(store, c, user, source_job, limits, source_queue,
            source_complete.release, source_origin, None, source_reader, validate_input=False)
        native_rows = spec._native_audit_facts(store, c, user, source_draft,
            _graph_read=guard, _generation_reader=gen_reader)
        guard.add('original-native-audit:' + source_draft['id'], native_rows)
        source_binding = spec._cold_bound_from_audit(store, c, user, source_bound_prefix, fingerprint(native_rows))
        source_outputs, source_proved = spec._cold_receipts(store, c, source_job, source_binding,
            source_reader, allow_pending=True)
        spec._cold_verify_job_from_receipts(store, c, user, source_job, limits, source_binding,
            source_outputs, source_proved, source_reader)
        source_typed = pb._cold_source_typed(store, c, user, source_prefix, source_binding, source_outputs, source_proved)
        source_audit_prefix = pb._cold_source_audit_prefix(store, c, user, cold_draft['project_id'], source_job['id'], guard)
        source_audit = pb._cold_source_audit_from_original(store, c, user, source_audit_prefix,
            native_rows, source_reader=source_reader)
        source_facts = pb._cold_source_from_audit(store, c, user, source_typed, source_audit)
        extraction_review = pb._cold_review_from_source(store, c, user, extraction, source_facts)
        extraction_origin = pb._cold_verify_from_review(store, c, user, extraction, extraction_review)
        cold_complete = lifecycle._cold_release_complete(store, c, user, cold_release, cold_candidate, extraction_origin)
        app_jobs._cold_binding_release_prefix(store, c, user, cold_queue, cold_complete.release)
        use_prefix = use._cold_bound_prefix(store, c, user, current, cold_queue.snapshot, cold_complete.release, limits, guard)
        review_prefix = use._cold_review_prefix(store, c, user, use_prefix.accepted_instance, cold_complete.release,
            use_prefix.body.review, limits, guard, runtime=current['runtime_id'],
            approved_grants=use_prefix.frozen['reviewed']['approved_grant_state'])
        extraction_audit_prefix = pb._cold_audit_prefix(store, c, user, review_prefix.base, guard)
        extraction_audit = pb._cold_audit_from_source(store, c, user, extraction_audit_prefix, source_audit)
        use_review = use._cold_review_from_audit(store, c, user, review_prefix, extraction_audit)
        use_value = use._cold_bound_from_review(store, c, user, use_prefix, use_review)
        cold_reader = _cold_run_facts(store, c, current, guard)
        cold_bound_prefix = spec._cold_bound_prefix(store, c, user, current, limits, cold_queue,
            cold_complete.release, extraction_origin, use_value, cold_reader)
        audit_prefix = use._cold_audit_prefix(store, c, user, cold_bound_prefix.value['draft'], guard)
        audit = use._cold_audit_from_base(store, c, user, audit_prefix, extraction_audit)
        binding = spec._cold_bound_from_audit(store, c, user, cold_bound_prefix, audit)
        _cold_read_checkpoint(store, c, guard)
        return _ColdBindingGraph(guard, binding, cold_queue, cold_complete, cold_reader,
            source_binding, source_queue, source_complete, source_reader, source_facts,
            source_audit, native_rows, source_outputs, source_proved, gen_reader, gen_contract,
            gen_material, history, gen_raw, marker, original, extraction, extraction_review,
            extraction_origin, extraction_audit_prefix, extraction_audit, use_prefix, use_review,
            use_value, audit_prefix)
    except BaseException:
        if type(guard) is _ColdGraphRead:
            guard.invalidate()
        raise
