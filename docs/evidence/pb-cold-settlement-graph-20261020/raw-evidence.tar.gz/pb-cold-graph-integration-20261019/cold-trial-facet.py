def _cold_trial_binding(worker, c, completed, limits):
    """Distinct complete trial-Limits facets over this epoch's full raw facts."""
    from . import app_jobs, goal_applications as ga, lifecycle
    from . import pa_spec_apps as spec
    from . import pb_natural_specs as pb
    from . import pb_natural_uses as use

    guard, store = completed.guard, worker.store
    user = completed.binding['snapshot']['principal_id']
    current = completed.counter_reader.job
    try:
        require(type(completed) is _ColdBindingGraph and type(limits) is Limits
            and limits is guard.role_limits['trial'])
        _cold_read_checkpoint(store, c, guard)
        # Limits-independent complete raw predicates already hold in this epoch.
        # Each caller-Limits compile stays at the original parent-before-child edge.
        cold_queue = app_jobs._cold_binding_facet(store, c, user, completed.binding_prefix, limits)
        cold_release, cold_candidate = lifecycle._cold_release_facet_prefix(store, c, user, completed.release, limits)
        source_queue = app_jobs._cold_binding_facet(store, c, user, completed.source_binding_prefix, limits)
        source_release, source_candidate = lifecycle._cold_release_facet_prefix(store, c, user, completed.source_release, limits)
        source_draft = source_release.release['snapshot']['draft']
        original = spec._cold_original_origin_prefix(store, c, user, source_draft, limits, guard)
        reader = completed.generation_reader
        gen_raw = ga._cold_candidate_from_history(store, c, reader.run, completed.generation_contract,
            completed.generation_material, completed.generation_history, limits, reader)
        source_origin = spec._cold_original_origin_from_generation(store, c, user, original,
            reader, gen_raw, completed.generation_marker)
        source_complete = lifecycle._cold_release_complete(store, c, user, source_release, source_candidate, source_origin)
        app_jobs._cold_binding_release_prefix(store, c, user, source_queue, source_complete.release)
        source_reader = completed.source_counter_reader
        source_job = source_reader.job
        source_prefix = spec._cold_bound_prefix(store, c, user, source_job, limits, source_queue,
            source_complete.release, source_origin, None, source_reader, validate_input=False)
        source_binding = spec._cold_bound_from_audit(store, c, user, source_prefix, fingerprint(completed.native_audit))
        source_outputs, source_proved = spec._cold_receipts(store, c, source_job, source_binding, source_reader, allow_pending=True)
        spec._cold_verify_job_from_receipts(store, c, user, source_job, limits, source_binding,
            source_outputs, source_proved, source_reader)
        source_facts = pb._cold_source_facet_from_source(store, c, user, completed.source_facts, limits,
            source_binding, source_outputs, source_proved, role='cold')
        extraction, extraction_review, extraction_origin = pb._cold_verify_facet_from_review(store, c, user,
            completed.extraction_prefix, completed.extraction_review, limits, source_facts, role='cold')
        cold_complete = lifecycle._cold_release_complete(store, c, user, cold_release, cold_candidate, extraction_origin)
        app_jobs._cold_binding_release_prefix(store, c, user, cold_queue, cold_complete.release)
        use_review = use._cold_review_facet_from_review(store, c, user, completed.use_prefix,
            completed.use_review, limits, role='trial')
        use_prefix, use_value = use._cold_bound_facet(store, c, user, completed.use_prefix,
            completed.use_review, use_review, role='trial')
        bound_prefix = spec._cold_bound_prefix(store, c, user, current, limits, cold_queue,
            cold_complete.release, extraction_origin, use_value, completed.counter_reader)
        # This full audit is Limits-independent, complete and pinned in this epoch.
        binding = spec._cold_bound_from_audit(store, c, user, bound_prefix, completed.binding['audit_fingerprint'])
        current_original = completed.native_audit['original']
        require(all(current_original.get(key) == value for key, value in source_draft.items()),
            'Current confirmed original app differs from its fully verified Release')
        raw, metadata = spec._cold_original_model_source(store, c, user, reader.run,
            current_original, completed.generation_marker, gen_raw, reader)
        guard.add('trial-generated-model-facet', dict(original=current_original, candidate=raw,
            metadata=metadata, limits=limits, frozen=completed.generation_contract.model_dump()))
        return _ColdBindingGraph(guard, binding, cold_queue, cold_complete, completed.counter_reader,
            source_binding, source_queue, source_complete, source_reader, source_facts,
            completed.source_audit, completed.native_audit, source_outputs, source_proved,
            reader, completed.generation_contract, completed.generation_material,
            completed.generation_history, raw, completed.generation_marker, original,
            extraction, extraction_review, extraction_origin, completed.extraction_audit_prefix,
            completed.extraction_audit, use_prefix, use_review, use_value, completed.use_audit_prefix), metadata
    except BaseException:
        if type(completed) is _ColdBindingGraph and type(completed.guard) is _ColdGraphRead:
            completed.guard.invalidate()
        raise
