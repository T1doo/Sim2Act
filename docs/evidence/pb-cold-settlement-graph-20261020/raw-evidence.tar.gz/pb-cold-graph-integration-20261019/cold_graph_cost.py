"""Passthrough prefix-only timing; no extra serialization, model, DB read, or gate."""
import functools
import hashlib
import json
import os
from pathlib import Path
import threading
import time

from sqlalchemy import event

_local = threading.local()


def pytest_runtest_call(item):
    from sim2act import natural_spec_runtime as runtime
    original_first = runtime._cold_first_binding
    original_hash = hashlib.sha256
    saved = []
    result = {'scope': 'ordinary queued-Cold first binding only; no full trial or settlement',
              'metrics': {}, 'sql': {}, 'hash_bytes_inside_model_inputs': 0}

    def wrap(target, name, label):
        original = getattr(target, name)
        @functools.wraps(original)
        def measured(*args, **kwargs):
            if not getattr(_local, 'active', False):
                return original(*args, **kwargs)
            start, cpu = time.monotonic(), time.thread_time()
            frame = {'label': label, 'child_wall': 0.0, 'child_cpu': 0.0}
            _local.stack.append(frame)
            if label == 'full_model_inputs':
                _local.model_depth += 1
            try:
                return original(*args, **kwargs)
            finally:
                wall, thread_cpu = time.monotonic()-start, time.thread_time()-cpu
                if label == 'full_model_inputs':
                    _local.model_depth -= 1
                _local.stack.pop()
                metric = result['metrics'].setdefault(label, {'count':0, 'wall_inclusive':0.0, 'cpu_inclusive':0.0, 'wall_direct_child_exclusive':0.0, 'cpu_direct_child_exclusive':0.0})
                metric['count'] += 1
                metric['wall_inclusive'] += wall
                metric['cpu_inclusive'] += thread_cpu
                metric['wall_direct_child_exclusive'] += wall-frame['child_wall']
                metric['cpu_direct_child_exclusive'] += thread_cpu-frame['child_cpu']
                if _local.stack:
                    _local.stack[-1]['child_wall'] += wall
                    _local.stack[-1]['child_cpu'] += thread_cpu
        saved.append((target, name, original))
        setattr(target, name, measured)

    def sha256(data=b'', *args, **kwargs):
        if getattr(_local, 'active', False) and _local.model_depth:
            result['hash_bytes_inside_model_inputs'] += len(data)
        return original_hash(data, *args, **kwargs)

    def sql(conn, cursor, statement, parameters, context, executemany):
        if getattr(_local, 'active', False):
            kind = statement.lstrip().split(None, 1)[0].upper() if statement.strip() else 'EMPTY'
            result['sql'][kind] = result['sql'].get(kind, 0) + 1

    @functools.wraps(original_first)
    def first(worker, c, *args, **kwargs):
        _local.active, _local.model_depth, _local.stack = True, 0, []
        event.listen(worker.store.engine, 'before_cursor_execute', sql)
        start, cpu = time.monotonic(), time.thread_time()
        try:
            return original_first(worker, c, *args, **kwargs)
        except BaseException as exc:
            result['exception_type'] = type(exc).__name__
            raise
        finally:
            result['first_binding_wall_seconds'] = time.monotonic()-start
            result['first_binding_thread_cpu_seconds'] = time.thread_time()-cpu
            event.remove(worker.store.engine, 'before_cursor_execute', sql)
            _local.active = False
            for target, name, original in reversed(saved):
                setattr(target, name, original)
            hashlib.sha256 = original_hash
            runtime._cold_first_binding = original_first
            folder = Path(os.environ['COLD_GRAPH_METRICS_DIR'])
            folder.mkdir(parents=True, exist_ok=True)
            (folder/'prefix-cost.json').write_text(json.dumps(result, indent=2)+'\n')

    for target, name, label in [
        (runtime._ColdGraphRead,'check','cold_graph_check'),
        (runtime._ColdGraphRead,'input_key','cold_graph_input_key'),
        (runtime,'_model_inputs','full_model_inputs'),
        (runtime._ModelSettlementRead,'check','model_settlement_check'),
        (runtime._ModelSettlementRead,'binding_key','model_binding_key'),
    ]:
        wrap(target,name,label)
    hashlib.sha256 = sha256
    runtime._cold_first_binding = first
