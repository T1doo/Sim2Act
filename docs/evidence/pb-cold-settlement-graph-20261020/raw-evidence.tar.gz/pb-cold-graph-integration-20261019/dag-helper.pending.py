def _cold_graph_inputs(values):
    """Full per-call value graph. Shared containers retain explicit full edges.

    There is no previous-check cache: every actual container and complete field
    is visited on each call. Memo entries retain their objects until this call
    ends, so temporary model dumps cannot reuse another object's identity.
    """
    from sqlalchemy.engine import RowMapping

    memo, active, nodes = {}, set(), []

    def visit(value):
        kind = type(value)
        if kind in (str, int, float, bool, type(None)):
            return [kind.__name__, value]
        require(kind in (dict, RowMapping, list, tuple, Limits, bytes),
            "Unsupported Cold graph input container")
        identity = id(value)
        require(identity not in active, "Cyclic Cold graph input")
        if identity in memo:
            original, ordinal = memo[identity]
            require(original is value)
            return ['ref', ordinal]
        ordinal = len(nodes)
        memo[identity] = value, ordinal
        nodes.append(None)
        active.add(identity)
        if kind is Limits:
            body = ['limits', visit(Limits.model_dump(value))]
        elif kind in (dict, RowMapping):
            keys = list(value.keys())
            require(all(type(key) is str for key in keys), "Cold graph keys changed")
            body = ['mapping', [[key, visit(value[key])] for key in sorted(keys)]]
        elif kind is bytes:
            # Keep the full bytes here; the original _model_inputs performs its
            # complete byte hash/length conversion, inside its measured scope.
            body = ['bytes', value]
        else:
            body = [kind.__name__, [visit(item) for item in value]]
        nodes[ordinal] = body
        active.remove(identity)
        return ['ref', ordinal]

    root = visit(values)
    return _model_inputs(dict(root=root, nodes=nodes))
