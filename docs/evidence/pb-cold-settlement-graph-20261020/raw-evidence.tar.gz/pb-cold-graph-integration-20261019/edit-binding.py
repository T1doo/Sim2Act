from pathlib import Path
p=Path('/workspace/Sim2Act/src/sim2act/app_jobs.py')
s=p.read_text()
s=s.replace('from contextlib import contextmanager\n','from contextlib import contextmanager\nfrom dataclasses import dataclass\n')
start=s.index('def load_binding(')
end=s.index('\n\ndef inspect_job(',start)
old=s[start:end]
body=old[old.index('    from .local_record_apps'):]
cut=body.index('    if authorize:\n        contract =')
prefix=body[:cut]
tail=body[cut:]
contract_end=tail.index('        if (scope is not None and archival_software is None')
contract=tail[len('    if authorize:\n'):contract_end]
release_start=tail.index('        from .app_owner_goals import verify_frozen_run')
release_end=tail.index('        if csv_revision.MARKER in s:',release_start)
release=tail[release_start:release_end]
# The same original prefix remains the only source of these checks.
helper='def _load_binding_prefix(store, c, user, job, limits, *, authorize=True, return_release=False, _graph_read=None):\n'
for line in prefix.splitlines(True):
    helper+=line
    # Pin every external read/gate before later private data is consumed.
    if line.strip() in ['reject_record_legacy(c, rid=job["id"])','scope = correction.scope_segment(store,c,user,job["id"]) if authorize else None','job_gate(store, c, user, job["id"],_spec_scope_checked=reused_scope)','scope = correction.scope_segment(store,c,user,job["id"],_segment=scope)','job_gate(store,c,user,job["id"])','scope = correction.scope_segment(store,c,user,job["id"])','project.job_gate(store,c,user,job,s,limits)','store.own_project(c, user, s["project_id"])']:
        helper+=' '*(len(line)-len(line.lstrip()))+'_binding_checkpoint(store, c, _graph_read)\n'
# SQL multi-line result checkpoints at the original consumption boundaries.
helper=helper.replace('    s = _binding_queue_from_facts(job, user, b)\n','    _binding_checkpoint(store, c, _graph_read)\n    s = _binding_queue_from_facts(job, user, b)\n')
helper=helper.replace('    _binding_app_run_from_facts(job, b, s, a)\n','    _binding_checkpoint(store, c, _graph_read)\n    _binding_app_run_from_facts(job, b, s, a)\n')
helper=helper.replace('    if bool(logic_marker)', '    _binding_checkpoint(store, c, _graph_read)\n    if bool(logic_marker)')
helper+='    return s, a, scope\n\n\n'
helper+='def _binding_contract_limits(store, c, user, job, limits, s, scope, _logic_out, *, _graph_read=None):\n'
helper+=''.join(line[4:] if line.startswith('    ') else line for line in contract.splitlines(True))
helper=helper.replace('    if contract.limits.model_dump()', '    _binding_checkpoint(store, c, _graph_read)\n    if contract.limits.model_dump()')
helper+='    _binding_checkpoint(store, c, _graph_read)\n    return contract, logic_source, scope_limits\n\n\n'
helper+='def _binding_release_base(store, c, user, job, limits, s, r, contract, archival_software=None, *, _graph_read=None):\n'
helper+='    from . import csv_goal_revisions as csv_revision\n'
helper+=''.join(line[4:] if line.startswith('    ') else line for line in release.splitlines(True))
helper=helper.replace('    verify_frozen_run(store, c, user, r["snapshot"]["draft"], limits, s, archival_software=archival_software)\n','    verify_frozen_run(store, c, user, r["snapshot"]["draft"], limits, s, archival_software=archival_software)\n    _binding_checkpoint(store, c, _graph_read)\n')
helper=helper.replace('    csv_revision.verify_job(store,c,user,job,s,r,limits,contract)\n','    csv_revision.verify_job(store,c,user,job,s,r,limits,contract)\n    _binding_checkpoint(store, c, _graph_read)\n')
helper+='    return expected_resource\n\n\n'
new=old[:old.index('    from .local_record_apps')]
new+='    from . import csv_goal_revisions as csv_revision\n    s, a, scope = _load_binding_prefix(store, c, user, job, limits, authorize=authorize, return_release=return_release)\n'
new+=tail
# Substitute both original shared blocks with their sole bodies.
new=new.replace(contract,'        contract, logic_source, scope_limits = _binding_contract_limits(store, c, user, job, limits, s, scope, _logic_out)\n')
new=new.replace(release,'        expected_resource = _binding_release_base(store, c, user, job, limits, s, r, contract, archival_software)\n')
helper='def _binding_checkpoint(store, c, guard):\n    if guard is not None:\n        from .natural_spec_runtime import _cold_read_checkpoint\n        _cold_read_checkpoint(store, c, guard)\n\n\n'+helper
strict='''

@dataclass(frozen=True)
class _ColdBindingPrefix:
    guard: Any
    key: str
    user: str
    job: Any
    limits: Limits
    role: str
    snapshot: dict
    app_run: Any
    contract: Any


def _cold_binding_prefix(store, c, user, job, limits, guard, role):
    from .natural_spec_runtime import _ColdGraphRead
    from .pa_spec_apps import require
    try:
        require(type(guard) is _ColdGraphRead and role in {"source", "cold"} and type(limits) is Limits)
        _binding_checkpoint(store, c, guard)
        s, a, scope = _load_binding_prefix(store, c, user, job, limits, return_release=True, _graph_read=guard)
        contract, _, scope_limits = _binding_contract_limits(store, c, user, job, limits, s, scope, None, _graph_read=guard)
        require(scope is None and scope_limits is limits
            and not {"human_correction", "logic_check", "project_check", "offline_replay", "csv_review", "owner_goal_binding_fingerprint"}.intersection(s),
            "Cold graph binding changed family")
        key = "binding-prefix:" + role + ":" + job["id"] + ":" + fingerprint(limits.model_dump())
        guard.add(key, dict(job=dict(job), snapshot=s, app_run=dict(a), contract=contract.model_dump(), limits=limits))
        return _ColdBindingPrefix(guard, key, user, job, limits, role, s, a, contract)
    except BaseException:
        if type(guard) is _ColdGraphRead:
            guard.invalidate()
        raise


def _cold_binding_release_prefix(store, c, user, prefix, release):
    from .natural_spec_runtime import _ColdGraphRead, _model_inputs
    from .pa_spec_apps import require
    try:
        require(type(prefix) is _ColdBindingPrefix)
        g = prefix.guard
        _binding_checkpoint(store, c, g)
        require(prefix.user == user and release["id"] == prefix.snapshot["release_id"]
            and "natural_logic_source" not in release["snapshot"]
            and _model_inputs(dict(job=dict(prefix.job), snapshot=prefix.snapshot,
                app_run=dict(prefix.app_run), contract=prefix.contract.model_dump(), limits=prefix.limits))
                == _model_inputs(g.inputs[prefix.key]))
        resource = _binding_release_base(store, c, user, prefix.job, prefix.limits,
            prefix.snapshot, release, prefix.contract, _graph_read=g)
        require(not {"human_correction", "logic_check", "project_check", "offline_replay"}.intersection(prefix.snapshot))
        g.add(prefix.key + ":release", dict(release=dict(release), resource=resource))
        return resource
    except BaseException:
        if type(prefix) is _ColdBindingPrefix and type(prefix.guard) is _ColdGraphRead:
            prefix.guard.invalidate()
        raise


def _cold_binding_from_use(store, c, user, prefix, release, use_value):
    from .natural_spec_runtime import _ColdGraphRead
    from .pa_spec_apps import require
    try:
        require(type(prefix) is _ColdBindingPrefix)
        g = prefix.guard
        _binding_checkpoint(store, c, g)
        stored = g.inputs[prefix.key + ":release"]
        require(prefix.user == user and stored["release"] == dict(release))
        resource = stored["resource"]
        if "pb_use" in prefix.snapshot:
            require(prefix.role == "cold" and "pa_use" not in prefix.snapshot
                and type(use_value) is tuple and len(use_value) == 5)
            resource = use_value[3]["resource_id"]
        else:
            require(prefix.role == "source" and "pa_use" not in prefix.snapshot and use_value is None)
        _binding_release_from_facts(prefix.job, prefix.snapshot, release, resource)
        _binding_checkpoint(store, c, g)
        return prefix.snapshot, prefix.app_run, release
    except BaseException:
        if type(prefix) is _ColdBindingPrefix and type(prefix.guard) is _ColdGraphRead:
            prefix.guard.invalidate()
        raise
'''
s=s[:start]+helper+new+strict+s[end:]
p.write_text(s)
