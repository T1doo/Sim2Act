from pathlib import Path
p=Path('/workspace/Sim2Act/src/sim2act/pa_spec_apps.py')
s=p.read_text()
start=s.index('    # load_binding/correction.bound proved current scope; this call chain only reads.\n',s.index('def _bound('))
end=s.index('\n\ndef audit_fingerprint',start)
block=s[start:end]
cut=block.index('    value = dict(')
shared=block[block.index('    contract = '):cut]
# Share the complete frozen/goal/runtime/counter/input predicates at their old position.
helper='''def _bound_checkpoint(store, c, guard):
    if guard is not None:
        from .natural_spec_runtime import _cold_read_checkpoint
        _cold_read_checkpoint(store, c, guard)


def _bound_contract_from_facts(store, c, user, job, limits, snapshot, draft, manifest, source, goal, *, validate_input=True, _graph_read=None, _natural_facts=None):
'''+shared
helper=helper.replace('    from .spec_production import generation_mode\n', '    _bound_checkpoint(store, c, _graph_read)\n    from .spec_production import generation_mode\n')
# Preserve generation_mode short-circuit order inside the original conjunction.
helper=helper.replace('        counters(c, job, manifest)\n','        if _graph_read is None:\n            counters(c, job, manifest)\n        else:\n            from .natural_spec_runtime import _cold_counters\n            _cold_counters(store, c, job, manifest, _natural_facts)\n        _bound_checkpoint(store, c, _graph_read)\n')
helper+='    _bound_checkpoint(store, c, _graph_read)\n    return contract, plan\n\n\n'
# Use the original result construction unchanged, with complete explicit audit input.
value=block[cut:block.index('    if "human_correction" in snapshot:',cut)]
audit_start=value.index('        audit_fingerprint=audit_fingerprint(')
value=value[:audit_start]+'        audit_fingerprint=audit)\n'
helper+='def _bound_value_from_facts(snapshot, app_run, release, draft, source, goal, plan, report, contract, audit):\n'+value+'    return value\n\n\n'
replace='''    # load_binding/correction.bound proved current scope; this call chain only reads.
    contract, plan = _bound_contract_from_facts(store, c, user, job, limits, snapshot,
        draft, manifest, source, goal, validate_input=validate_input)
    value = _bound_value_from_facts(snapshot, app_run, release, draft, source, goal, plan, report, contract,
        audit_fingerprint(store, c, user, draft, _logic_out=logic_out, _release=release,
            **({"_use_proof": use_proof} if use_proof is not None else {})))
'''+block[block.index('    if "human_correction" in snapshot:',cut):]
s=s[:start]+replace+'\n\n'+helper+s[end:]
# Strict assembly pauses at the original audit dependency; no ancestor verifier replay.
pos=s.index('\n\ndef audit_fingerprint')
strict='''

@dataclass(frozen=True)
class _ColdBoundPrefix:
    guard: Any
    key: str
    user: str
    job: Any
    limits: Limits
    value: dict


def _cold_bound_prefix(store, c, user, job, limits, binding_prefix, release, origin, use_value, natural_facts, *, validate_input=True):
    from . import app_jobs
    from .natural_spec_runtime import _ColdGraphRead
    try:
        require(type(binding_prefix) is app_jobs._ColdBindingPrefix)
        guard = binding_prefix.guard
        _bound_checkpoint(store, c, guard)
        snapshot, app_run, release = app_jobs._cold_binding_from_use(store, c, user, binding_prefix, release, use_value)
        accepted = c.execute(select(events.c.data).where(events.c.run_id == job["id"], events.c.kind == "ACCEPTED")).scalars().all()
        _bound_checkpoint(store, c, guard)
        require(fingerprint(accepted) == fingerprint([dict(namespace=app_jobs.KIND, app_run_id=snapshot["app_run_id"],
            instance_id=snapshot["instance_id"], release_id=snapshot["release_id"], input_fingerprint=snapshot["request_fingerprint"])]))
        draft = release["snapshot"]["draft"]
        require(is_candidate(draft["candidate"]))
        if "pb_use" in snapshot:
            require(binding_prefix.role == "cold" and type(use_value) is tuple and len(use_value) == 5)
            draft, manifest, report, source, goal = use_value
        else:
            require(binding_prefix.role == "source" and type(origin) is tuple and len(origin) == 4)
            manifest, report, source, goal = origin
        contract, plan = _bound_contract_from_facts(store, c, user, job, limits, snapshot,
            draft, manifest, source, goal, validate_input=validate_input, _graph_read=guard, _natural_facts=natural_facts)
        key = binding_prefix.key + ":bound"
        value = _bound_value_from_facts(snapshot, app_run, release, draft, source, goal, plan, report, contract, None)
        guard.add(key, dict(job=dict(job), limits=limits, value=value, accepted=accepted))
        return _ColdBoundPrefix(guard, key, user, job, limits, value)
    except BaseException:
        if type(binding_prefix) is app_jobs._ColdBindingPrefix and type(binding_prefix.guard) is _ColdGraphRead:
            binding_prefix.guard.invalidate()
        raise


def _cold_bound_from_audit(store, c, user, prefix, audit):
    from .natural_spec_runtime import _ColdGraphRead, _model_inputs
    try:
        require(type(prefix) is _ColdBoundPrefix)
        _bound_checkpoint(store, c, prefix.guard)
        require(prefix.user == user and type(audit) is str and len(audit) == 64
            and _model_inputs(prefix.value) == _model_inputs(prefix.guard.inputs[prefix.key]["value"]))
        value = {**prefix.value, "audit_fingerprint": audit}
        prefix.guard.add(prefix.key + ":complete", value)
        return value
    except BaseException:
        if type(prefix) is _ColdBoundPrefix and type(prefix.guard) is _ColdGraphRead:
            prefix.guard.invalidate()
        raise
'''
s=s[:pos]+strict+s[pos:]
if 'from dataclasses import dataclass\n' not in s:
    s=s.replace('import copy\n','import copy\nfrom dataclasses import dataclass\n',1)
p.write_text(s)
