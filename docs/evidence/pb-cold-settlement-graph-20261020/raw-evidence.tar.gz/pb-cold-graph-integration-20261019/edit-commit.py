from pathlib import Path
p=Path('/workspace/Sim2Act/src/sim2act/pa_spec_apps.py')
s=p.read_text()
a=s.index('def _commit_guard(worker,')
b=s.index('\n\n@controlled\ndef advance(',a)
old=s[a:b]
body=old[old.index('    from .app_jobs import lock_live'):]
audit='''    require(audit_fingerprint(worker.store, c, job["principal_id"], b["draft"],
        _correction_scope_checked=True) == b["audit_fingerprint"])
'''
c=body.index(audit)
prefix=body[:c]
suffix=body[c+len(audit):]
trialstart=suffix.index('    if getattr(worker, "pa_trial", None) is not None:')
nontrial=suffix[:trialstart]
trial=suffix[trialstart:]
# Default still traverses all original audit and trial predicates at exactly their edges.
wrapper=old[:old.index('    from .app_jobs import lock_live')]+'''    job, limits = _commit_guard_prefix(worker, c, run, b, delta)
'''+audit+'''    _commit_guard_after_audit(worker, c, run, job, b, limits, delta)
'''+trial
prehelper='def _commit_guard_prefix(worker, c, run, b, delta=0, *, _graph_read=None):\n'+prefix
prehelper=prehelper.replace('    job = lock_live(worker.store, c, run)\n','    job = lock_live(worker.store, c, run)\n    _bound_checkpoint(worker.store, c, _graph_read)\n',1)
prehelper=prehelper.replace('    require(fingerprint(stored["snapshot"])','    _bound_checkpoint(worker.store, c, _graph_read)\n    require(fingerprint(stored["snapshot"])',1)
prehelper=prehelper.replace('    require(fingerprint(release["snapshot"])','    _bound_checkpoint(worker.store, c, _graph_read)\n    require(fingerprint(release["snapshot"])',1)
prehelper=prehelper.replace('    require(current_goal["version"]','    _bound_checkpoint(worker.store, c, _graph_read)\n    require(current_goal["version"]',1)
prehelper=prehelper.replace('    require(fingerprint(actual)','    _bound_checkpoint(worker.store, c, _graph_read)\n    require(fingerprint(actual)',1)
prehelper+='    return job, limits\n\n\n'
posthelper='def _commit_guard_after_audit(worker, c, run, job, b, limits, delta=0, *, _graph_read=None):\n    from .db import internal_releases\n    s = b["snapshot"]\n'+nontrial
# internal_releases import in original prefix is now unused there only goal_cards.
posthelper=posthelper.replace('    from .db import internal_releases\n','')
posthelper=posthelper.replace('    require(instance["revision"]','    _bound_checkpoint(worker.store, c, _graph_read)\n    require(instance["revision"]',1)
posthelper=posthelper.replace('    frozen = worker.store._frozen_contract_after_scope(c, job).limits','    frozen_contract = worker.store._frozen_contract_after_scope(c, job)\n    _bound_checkpoint(worker.store, c, _graph_read)\n    frozen = frozen_contract.limits',1)
posthelper+='    _bound_checkpoint(worker.store, c, _graph_read)\n    return job\n\n\n'
strict='''@dataclass(frozen=True)
class _ColdCommitPrefix:
    guard: Any
    key: str
    run: Any
    job: Any
    binding: dict
    limits: Limits
    delta: int


def _cold_commit_prefix(worker, c, run, binding, guard, boundary, delta=0):
    from .natural_spec_runtime import _ColdGraphRead
    try:
        require(type(guard) is _ColdGraphRead and boundary in {"first", "second", "post", "tail"})
        _bound_checkpoint(worker.store, c, guard)
        key = "commit:" + boundary
        guard.add(key, dict(run=run, binding=binding, delta=delta))
        job, limits = _commit_guard_prefix(worker, c, run, binding, delta, _graph_read=guard)
        guard.add(key + ":current", dict(job=dict(job), limits=limits))
        return _ColdCommitPrefix(guard, key, run, job, binding, limits, delta)
    except BaseException:
        if type(guard) is _ColdGraphRead:
            guard.invalidate()
        raise


def _cold_commit_from_audit(worker, c, prefix, audit):
    from .natural_spec_runtime import _ColdGraphRead, _model_inputs
    try:
        require(type(prefix) is _ColdCommitPrefix)
        g = prefix.guard
        _bound_checkpoint(worker.store, c, g)
        require(_model_inputs(dict(run=prefix.run, binding=prefix.binding, delta=prefix.delta))
                == _model_inputs(g.inputs[prefix.key])
            and audit == prefix.binding["audit_fingerprint"])
        job = _commit_guard_after_audit(worker, c, prefix.run, prefix.job, prefix.binding,
            prefix.limits, prefix.delta, _graph_read=g)
        _bound_checkpoint(worker.store, c, g)
        return job
    except BaseException:
        if type(prefix) is _ColdCommitPrefix and type(prefix.guard) is _ColdGraphRead:
            prefix.guard.invalidate()
        raise
'''
s=s[:a]+wrapper+'\n\n'+prehelper+posthelper+strict+s[b:]
p.write_text(s)
