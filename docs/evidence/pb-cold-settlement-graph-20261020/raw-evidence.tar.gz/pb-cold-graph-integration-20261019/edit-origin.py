from pathlib import Path
p=Path('/workspace/Sim2Act/src/sim2act/pa_spec_apps.py')
s=p.read_text()
s=s.replace('def target(store, c, user, pid, cid, version=None, goal_fp=None, runtime=None, *, family=VERSION):','def target(store, c, user, pid, cid, version=None, goal_fp=None, runtime=None, *, family=VERSION, _graph_read=None):')
s=s.replace('    project = store.own_project(c, user, pid)\n    store.authorize(c, user, runtime or project["runtime_id"], pid, pid, SAVE)\n    source, goal = read_target(store, c, user, pid, cid, version, goal_fp, runtime)\n    source_check(source, family)\n    return source, goal','    project = store.own_project(c, user, pid)\n    _bound_checkpoint(store, c, _graph_read)\n    store.authorize(c, user, runtime or project["runtime_id"], pid, pid, SAVE)\n    _bound_checkpoint(store, c, _graph_read)\n    source, goal = read_target(store, c, user, pid, cid, version, goal_fp, runtime)\n    _bound_checkpoint(store, c, _graph_read)\n    source_check(source, family)\n    _bound_checkpoint(store, c, _graph_read)\n    return source, goal',1)
a=s.index('def verify_origin(')
b=s.index('\n\n@controlled\ndef options',a)
part=s[a:b]
pre='''    manifest, _, report = compile_candidate(draft["candidate"], limits)
    marker = c.execute(select(task_extractions).where(task_extractions.c.app_id == draft["id"])).mappings().first()
'''
part=part.replace(pre,'    manifest, report, marker = _original_origin_prefix(store, c, user, draft, limits)\n',1)
cs=part.index('        goal = contract.source_goal_card\n')
ce=part.index('    require(source["hash"]',cs)
ct=part[cs:ce]
part=part[:cs]+'        source, goal = _original_confirmation_target(store, c, user, draft, contract)\n'+part[ce:]
part=part.replace('        from .contracts import GoalCardRunSource\n','')
helper='''def _original_origin_prefix(store, c, user, draft, limits, *, _graph_read=None):
    manifest, _, report = compile_candidate(draft["candidate"], limits)
    _bound_checkpoint(store, c, _graph_read)
    marker = c.execute(select(task_extractions).where(task_extractions.c.app_id == draft["id"])).mappings().first()
    _bound_checkpoint(store, c, _graph_read)
    return manifest, report, marker


def _original_confirmation_target(store, c, user, draft, contract, *, _graph_read=None):
    from .contracts import GoalCardRunSource
'''+''.join(x[4:] if x.startswith('    ') else x for x in ct.splitlines(True))+'    return source, goal\n\n\n'
helper=helper.replace('    require(confirmation.get','    _bound_checkpoint(store, c, _graph_read)\n    require(confirmation.get',1)
helper=helper.replace('family=draft["candidate"]["namespace"])','family=draft["candidate"]["namespace"],\n        **({"_graph_read": _graph_read} if _graph_read is not None else {}))')
helper=helper.replace('    require(fingerprint(current.model_dump())','    _bound_checkpoint(store, c, _graph_read)\n    require(fingerprint(current.model_dump())',1)
s=s[:a]+part+'\n\n'+helper+s[b:]
# Exact original-GA-only prefix; the root feeds complete history and confirmation.
pos=s.index('\n\n@controlled\ndef options')
strict='''

@dataclass(frozen=True)
class _ColdOriginalOriginPrefix:
    guard: Any
    user: str
    draft: Any
    limits: Limits
    manifest: Any
    report: dict


def _cold_original_origin_prefix(store, c, user, draft, limits, guard):
    from .natural_spec_runtime import _ColdGraphRead
    try:
        require(type(guard) is _ColdGraphRead)
        _bound_checkpoint(store, c, guard)
        scope_gate(store, c, user, draft["id"], _graph_read=guard)
        _bound_checkpoint(store, c, guard)
        require("spec_task" not in draft["candidate"])
        manifest, report, marker = _original_origin_prefix(store, c, user, draft, limits, _graph_read=guard)
        require(marker is None and "spec_binding" not in draft["candidate"], "Cold graph requires original GA Source")
        key = "original-origin-prefix:" + draft["id"] + ":" + fingerprint(limits.model_dump())
        guard.add(key, dict(draft=draft, limits=limits, manifest=manifest.model_dump(), report=report, marker=marker))
        return _ColdOriginalOriginPrefix(guard, user, draft, limits, manifest, report)
    except BaseException:
        if type(guard) is _ColdGraphRead:
            guard.invalidate()
        raise


def _cold_original_origin_from_generation(store, c, user, prefix, reader, raw, marker):
    from .goal_applications import _GenerationFactsReader, _cold_generation_reader
    from .natural_spec_runtime import _ColdGraphRead
    try:
        require(type(prefix) is _ColdOriginalOriginPrefix and type(reader) is _GenerationFactsReader)
        guard = prefix.guard
        _bound_checkpoint(store, c, guard)
        require(reader.guard is guard and prefix.user == user)
        reader = _cold_generation_reader(store, c, reader.run, reader)
        _cold_original_model_source(store, c, user, reader.run, prefix.draft, marker, raw, reader)
        # Original subsequent source identity reads stay at the confirmation edge.
        rid = c.execute(select(goal_application_candidates.c.run_id)
            .where(goal_application_candidates.c.app_id == prefix.draft["id"])).scalar_one()
        _bound_checkpoint(store, c, guard)
        run = c.execute(select(runs).where(runs.c.id == rid)).mappings().one()
        _bound_checkpoint(store, c, guard)
        require(dict(run) == dict(reader.run))
        contract, _ = reader.source()
        _bound_checkpoint(store, c, guard)
        source, goal = _original_confirmation_target(store, c, user, prefix.draft, contract, _graph_read=guard)
        require(source["hash"] == prefix.draft["candidate"]["source_hash"]
            and prefix.manifest.data_bindings[0].resource_ref == source["resource_id"])
        result = (prefix.manifest, prefix.report, source, goal.model_dump())
        guard.add("original-origin:" + prefix.draft["id"] + ":" + fingerprint(prefix.limits.model_dump()),
            dict(manifest=prefix.manifest.model_dump(), report=prefix.report, source=source, goal=goal.model_dump()))
        return result
    except BaseException:
        if type(prefix) is _ColdOriginalOriginPrefix and type(prefix.guard) is _ColdGraphRead:
            prefix.guard.invalidate()
        if type(reader) is _GenerationFactsReader and type(reader.guard) is _ColdGraphRead:
            reader.guard.invalidate()
        raise
'''
s=s[:pos]+strict+s[pos:]
p.write_text(s)
