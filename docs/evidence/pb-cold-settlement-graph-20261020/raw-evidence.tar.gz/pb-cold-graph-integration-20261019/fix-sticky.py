from pathlib import Path
p=Path('/workspace/Sim2Act/src/sim2act/apps.py')
s=p.read_text()
a=s.index('def _cold_candidate_prefix(')
b=s.index('\n\ndef _cold_candidate_from_origin',a)
chunk=s[a:b].replace('from .natural_spec_runtime import _cold_read_checkpoint','from .natural_spec_runtime import _ColdGraphRead, _cold_read_checkpoint')
start=chunk.index('    require(guard is not None')
body=chunk[start:].replace('require(guard is not None,','require(type(guard) is _ColdGraphRead,',1)
chunk=chunk[:start]+'    try:\n'+''.join('    '+line if line.strip() else line for line in body.splitlines(True))+'\n    except BaseException:\n        if type(guard) is _ColdGraphRead:\n            guard.invalidate()\n        raise\n'
s=s[:a]+chunk+s[b:]
a=s.index('def _cold_candidate_from_origin(')
b=s.index('\n\ndef _frozen_candidate_prefix',a)
chunk=s[a:b].replace('from .natural_spec_runtime import _cold_read_checkpoint, _model_inputs','from .natural_spec_runtime import _ColdGraphRead, _cold_read_checkpoint, _model_inputs')
chunk=chunk.replace('    require(type(prefix) is _ColdCandidatePrefix and type(facts) is _ColdGraphOriginFacts,\n            "Exact Cold prefix and complete origin facts required")\n    try:\n','    try:\n        require(type(prefix) is _ColdCandidatePrefix and type(facts) is _ColdGraphOriginFacts,\n                "Exact Cold prefix and complete origin facts required")\n')
chunk=chunk.replace('        facts.invalidate()\n        prefix.guard.invalidate()\n','        if type(facts) is _ColdGraphOriginFacts:\n            facts.invalidate()\n        if type(prefix) is _ColdCandidatePrefix and type(prefix.guard) is _ColdGraphRead:\n            prefix.guard.invalidate()\n')
chunk=chunk.replace('        facts.busy = False','        if type(facts) is _ColdGraphOriginFacts:\n            facts.busy = False')
s=s[:a]+chunk+s[b:]
p.write_text(s)
p=Path('/workspace/Sim2Act/src/sim2act/lifecycle.py')
s=p.read_text()
a=s.index('def _cold_release_prefix(')
b=s.index('\n\ndef _cold_release_from_origin',a)
chunk=s[a:b].replace('from .natural_spec_runtime import _cold_read_checkpoint','from .natural_spec_runtime import _ColdGraphRead, _cold_read_checkpoint')
chunk=chunk.replace('require(guard is not None,','require(type(guard) is _ColdGraphRead,')
chunk=chunk.replace('        guard.invalidate()','        if type(guard) is _ColdGraphRead:\n            guard.invalidate()')
s=s[:a]+chunk+s[b:]
a=s.index('def _cold_release_from_origin(')
b=s.index('\n\ndef ',a+5)
chunk=s[a:b].replace('from .natural_spec_runtime import _cold_read_checkpoint, _model_inputs','from .natural_spec_runtime import _ColdGraphRead, _cold_read_checkpoint, _model_inputs')
start=chunk.index('    require(type(prefix)')
trypos=chunk.index('    try:\n',start)
req=chunk[start:trypos]
chunk=chunk[:start]+'    try:\n'+''.join('    '+line for line in req.splitlines(True))+chunk[trypos+len('    try:\n'):]
chunk=chunk.replace('        prefix.guard.invalidate()\n        facts.invalidate()','        if type(prefix) is _ColdReleasePrefix and type(prefix.guard) is _ColdGraphRead:\n            prefix.guard.invalidate()\n        if type(candidate_prefix) is apps._ColdCandidatePrefix and type(candidate_prefix.guard) is _ColdGraphRead:\n            candidate_prefix.guard.invalidate()\n        if type(facts) is apps._ColdGraphOriginFacts:\n            facts.invalidate()')
s=s[:a]+chunk+s[b:]
p.write_text(s)
