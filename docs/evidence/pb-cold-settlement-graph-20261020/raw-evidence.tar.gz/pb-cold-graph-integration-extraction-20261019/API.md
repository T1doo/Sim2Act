# P-B Source / extraction facts integration patch

`implementation.patch` changes only `src/sim2act/pb_natural_specs.py`.
`proposed.py` is the complete proposed module; `original.py` is the captured base.
Root is the only repository writer. This agent did not edit the repository.

## Explicit ordered integration

All calls share the exact `natural_spec_runtime._ColdGraphRead` `guard`, the
same current Store/Connection/transaction, and complete role Limits. The role is
`source`, `generate`, or `cold`; different caller Limits require separate Source
and extraction role facets. The guard is continuity only, never authority.

### Source

1. `p = _cold_source_prefix(store, c, user, pid, rid, limits, guard, role)`
   performs original source gate, successful-status scalar, and owned full Run
   read. It stops immediately before the original `spec.verify_job` dependency.
2. Root explicitly constructs complete same-epoch `verify_job` facts for `p.job`
   and `p.limits`, including the succeeded Run/AppRun/typed/output/result proof.
3. `t = _cold_source_typed(store, c, user, p, binding, outputs, proved)`
   consumes all three original `verify_job` results, then performs the original
   natural/non-extraction check and the original Source-specific typed SELECT.
   It retains the exact complete binding, outputs, proved receipts, full typed
   row, and original proof prefix. It stops before Source audit.
4. Construct complete Source audit using the following sequence at this edge.
5. `s = _cold_source_from_audit(store, c, user, t, audit)`
   retains both full typed facts and full Source/native audit rows, appends only
   the original audit/citation/UNKNOWN/PENDING fields, and exposes
   `s.binding`, `s.proof`, `s.typed`, and `s.audit`. No ancestor replay occurs.

### Source audit

1. `a = _cold_source_audit_prefix(store, c, user, pid, rid, guard)` performs the
   original fresh source gate, accepted RunScope pair, owned native app read,
   original non-extraction requirement, and initial scope serialization. It
   stops exactly before the native `spec.audit_fingerprint` dependency.
2. Root explicitly supplies the **complete raw rows** of that original native
   audit after proving its original scopes/history. The exact keys are:
   `run`, `contract`, `original`, `attempts`, `operations`, `intents`, `events`,
   `confirmation`, `goal_head`, `goal_version`. The three single-row values are
   full dictionaries; the rest remain full ordered raw row lists. This API does
   not turn raw rows into an ancestor verification or authority.
3. `audit = _cold_source_audit_from_original(store, c, user, a, native_rows)`
   pins the complete native input, uses its exact fingerprint at the original
   `original_audit` field, and executes every original Source audit collector
   SELECT in the original order. It retains complete `original_audit_rows`,
   complete `rows`, and `digest`; there is no digest-only accepted input.

The complete Source/native audit is independent of caller Limits, so it may be
constructed once per exact epoch and explicitly supplied to the role facets.
It must be reconstructed after every write/new epoch. Recreating the same named
producer in one guard is rejected by guard.add; choose the original first edge
and explicitly pass its completed facts thereafter.

### Extraction verify / review

1. `p = _cold_verify_prefix(store, c, user, draft, limits, guard, role)` performs
   original spec scope, marker read, ExtractInput pair, Metadata pair, and the
   complete marker/request/source identity requirement. It stops before Source.
2. Root explicitly constructs the complete Source `s` with the same `limits`
   **object**, role, user/project/source Run and guard.
3. `r = _cold_review_from_source(store, c, user, p, s)` invokes the existing
   `_review_source_from_facts` before any target IO. It then executes the
   original current target material/Goal gates, and shared complete
   `_review_from_facts`. Full inherited source declared Limits remain distinct
   from compilation caller Limits. The resulting checked/material/Goal and
   complete Source packet remain explicit full facts.
4. `manifest, report, material, goal_dump = _cold_verify_from_review(store, c,
   user, p, r)` retains the original full review/frozen/marker/app/candidate
   predicates; the name SELECT remains inside the original AND short circuit,
   before the original material-id comparison. The original final compilation
   runs under this caller Limits. The exact full output is registered.

### Extraction audit

1. `p = _cold_audit_prefix(store, c, user, draft, guard)` performs original spec
   scope, Metadata/seal pair, marker, ExtractInput pair, and owned actual draft.
   It stops before the original first `source_audit` digest field.
2. At that edge root explicitly provides the complete current Source audit
   `audit` matching `p.meta.source_run_id`.
3. `digest = _cold_audit_from_source(store, c, user, p, audit, _audit_out=out)`
   uses the shared original complete digest construction and original optional
   full actual draft/digest output, with no ancestor calls.

## Required root-owned integration changes

When `_graph_read` is non-None, the shared P-B gates forward it to
`pa_spec_apps.scope_gate` and `pa_spec_apps.job_scope_gate`; the strict review
forwards it to `pa_spec_apps.target`. These root/G-agent-owned functions must
accept the optional keyword, check sensitive callee/SQL returns before
consumption, and forward it into `pb_natural_specs.scope_gate` when dispatching
P-B. Their original no-keyword public path is unchanged by this patch. Root
confirmed job_scope_gate support is implemented, scope_gate propagation is
assigned to G agent, and target support is being implemented separately. The
captured base does not yet have these private keywords.

The caller must prove the complete role-specific `verify_job` result and the
complete native audit **before supplying it**. These private facts adapters do
not by themselves prove the caller's input. Fresh actual current permissions,
source resolution, Run/fence/stop/lease/deadlines/stage authority remain root
responsibilities at their original edges.

## Shared default behavior and static checks

Public `source`, `source_audit`, their existing transaction-local cache wrappers,
all cache scope/epoch logic, `_source_proof_fields`, `_review_source_from_facts`,
`frozen_for`, extraction writes, receipt construction, and every Source audit
query shape/order have unchanged AST in the captured leaves/collectors.
`verify`, `_source`, `_source_audit`, review candidate/tail, and extraction audit
now call shared prefix/tail implementations. With no guard, no new guard scope
is created and no private keyword is supplied to original upstream functions.

`static-check.json` records successful stdlib AST parse, exact unchanged-leaf
and complete Source-audit SQL-shape/order comparisons, and content hashes.
`git apply --check` passed against the captured repository base. No product
imports, DB calls, tests, model calls, network operations, Ruff or mypy were run
by this agent. Full graph P2 closure and acceptance are not claimed.
