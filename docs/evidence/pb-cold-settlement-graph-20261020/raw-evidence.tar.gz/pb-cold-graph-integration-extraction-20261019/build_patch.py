from pathlib import Path
import difflib
import ast
import hashlib

root=Path('/workspace/pb-cold-graph-integration-extraction-20261019')
source=Path('/workspace/Sim2Act/src/sim2act/pb_natural_specs.py')
original=source.read_text()
text=original.replace('from typing import Literal', 'from typing import Any, Literal')

def replace(start,end,new):
    global text
    i=text.index(start)
    j=text.index(end,i)
    text=text[:i]+new.rstrip()+'\n\n\n'+text[j:]

replace('def source_gate(', '\ndef source_audit(', '''def _checkpoint_graph(store, c, guard):
    if guard is not None:
        from .natural_spec_runtime import _cold_read_checkpoint
        _cold_read_checkpoint(store, c, guard)


def _checkpoint_graph_owner(guard):
    if guard is not None:
        from .natural_spec_runtime import _ColdGraphRead
        require(type(guard) is _ColdGraphRead, "Exact Cold graph read scope required")
        guard.check(guard.store, guard.connection)


def _invalidate_graph(guard):
    from .natural_spec_runtime import _ColdGraphRead
    if type(guard) is _ColdGraphRead:
        guard.invalidate()


def _cold_fields(store, c, guard, key, value):
    """Only continuity of full explicit facts; never an authority or resolver."""
    from .natural_spec_runtime import _model_inputs
    _checkpoint_graph(store, c, guard)
    require(_model_inputs(value) == _model_inputs(guard.inputs[key]),
            "Cold extraction facts changed in this read segment")


def source_gate(store, c, user, pid, rid, *, _graph_read=None):
    """Scalar classification bounds lineage depth before any protected Run body."""
    from . import pa_spec_apps as spec
    from .text_workflows import RunScopeInput

    _checkpoint_graph(store, c, _graph_read)
    store.own_project(c, user, pid)
    _checkpoint_graph(store, c, _graph_read)
    parameters = {"pb_gate_run": rid}
    result = c.execute(_GATE_HEADER, parameters)
    _checkpoint_graph(store, c, _graph_read)
    header = result.mappings().first()
    if header is None or header["principal_id"] != user or header["project_id"] != pid:
        raise DomainError("PERMISSION_DENIED")
    result = c.execute(_GATE_APPS, {"pb_gate_runtime": header["runtime_id"],
        "pb_gate_project": pid})
    _checkpoint_graph(store, c, _graph_read)
    apps = result.mappings().all()
    require(len(apps) == 1 and apps[0]["family"] == natural.VERSION
            and apps[0]["origin"] == "goal" and apps[0]["task"] is None,
            "Only an original natural-spec successful task may be extracted; no extraction chains")
    aid = apps[0]["id"]
    app_parameters = {"pb_gate_app": aid}
    result = c.execute(_GATE_KIND, app_parameters)
    _checkpoint_graph(store, c, _graph_read)
    kind = result.scalar()
    require(kind in {None, spec.KIND})
    result = c.execute(_GATE_LEDGER, app_parameters)
    _checkpoint_graph(store, c, _graph_read)
    require(result.first() is None, "P-B lineage cannot be disguised as P-A")
    scoped = spec.job_scope_gate(store, c, user, rid)
    _checkpoint_graph(store, c, _graph_read)
    require(scoped)
    result = c.execute(_GATE_STATUS, parameters)
    _checkpoint_graph(store, c, _graph_read)
    require(result.scalar_one() == "SUCCEEDED",
            "Only a completed successful task is a P-B source")
    # Independent committed metadata must agree before any source Run/receipt body.
    paired = pair(c, user, rid, spec.RUN_META, "accepted", RunScopeInput)
    _checkpoint_graph(store, c, _graph_read)
    scope, seal = paired
    require(fingerprint(scope.model_dump()) == fingerprint(seal))
    result = c.execute(_GATE_SAVED, parameters)
    _checkpoint_graph(store, c, _graph_read)
    saved = result.scalars().all()
    result = c.execute(_GATE_COMMITTED, parameters)
    _checkpoint_graph(store, c, _graph_read)
    committed = result.scalars().all()
    pointer_parameters = {"pb_gate_app_run": scope.app_run_id, "pb_gate_instance": scope.instance_id}
    result = c.execute(_GATE_OUTPUT, pointer_parameters)
    _checkpoint_graph(store, c, _graph_read)
    output = result.scalars().all()
    result = c.execute(_GATE_TYPED, pointer_parameters)
    _checkpoint_graph(store, c, _graph_read)
    typed = result.scalars().all()
    require(len(saved) == 1 and saved == committed == output == typed and saved[0],
            "Independent committed source artifact pointers differ")
    store.authorize(c, user, header["runtime_id"], pid, saved[0], natural.READ)
    _checkpoint_graph(store, c, _graph_read)''')

replace('def _source_audit(', '\ndef scope_gate(', '''def _source_audit_prefix(store, c, user, pid, rid, *, _graph_read=None):
    from . import pa_spec_apps as spec
    from .text_workflows import RunScopeInput

    source_gate(store, c, user, pid, rid, **({"_graph_read": _graph_read} if _graph_read is not None else {}))
    _checkpoint_graph(store, c, _graph_read)
    paired = pair(c, user, rid, spec.RUN_META, "accepted", RunScopeInput)
    _checkpoint_graph(store, c, _graph_read)
    scope, seal = paired
    result = c.execute(select(app_drafts).where(app_drafts.c.id == scope.app_id,
        app_drafts.c.project_id == pid, app_drafts.c.runtime_id == scope.runtime_id))
    _checkpoint_graph(store, c, _graph_read)
    original = result.mappings().one()
    require("spec_task" not in original["candidate"])
    return scope, seal, original


def _source_audit_rows(store, c, user, pid, rid, scope, seal, original, original_audit,
                       *, _graph_read=None):
    from . import pa_spec_apps as spec
    from .db import delivery_graph_requests, goal_card_versions, goal_cards

    _checkpoint_graph(store, c, _graph_read)
    rows = dict(scope=scope.model_dump(), seal=seal, original_audit=original_audit)
    queries = {
        "run": select(runs).where(runs.c.id == rid, runs.c.principal_id == user, runs.c.project_id == pid),
        "contract": select(run_contracts).where(run_contracts.c.run_id == rid),
        "binding": select(internal_run_bindings).where(internal_run_bindings.c.run_id == rid),
        "app_run": select(internal_app_runs).join(internal_instances,
            internal_instances.c.id == internal_app_runs.c.instance_id).where(
            internal_app_runs.c.id == scope.app_run_id, internal_app_runs.c.instance_id == scope.instance_id,
            internal_instances.c.principal_id == user, internal_instances.c.project_id == pid),
        "typed": select(internal_instance_data).where(
            internal_instance_data.c.instance_id == scope.instance_id,
            internal_instance_data.c.run_id == scope.app_run_id),
        "release": select(internal_releases).where(internal_releases.c.id == scope.release_id,
            internal_releases.c.principal_id == user, internal_releases.c.project_id == pid),
        "attempts": select(attempts).where(attempts.c.run_id == rid).order_by(attempts.c.id),
        "operations": select(operations).where(operations.c.run_id == rid).order_by(operations.c.id),
        "intents": select(operation_intents).join(operations,
            operations.c.id == operation_intents.c.operation_id).where(operations.c.run_id == rid)
            .order_by(operation_intents.c.operation_id),
        "effects": select(local_effects).join(operations,
            operations.c.id == local_effects.c.operation_id).where(operations.c.run_id == rid)
            .order_by(local_effects.c.operation_id),
        "events": select(events).where(events.c.run_id == rid).order_by(events.c.id),
        "reservations": select(reservations).where(reservations.c.run_id == rid).order_by(reservations.c.id),
    }
    queries["origin_marker"] = select(task_extractions).where(task_extractions.c.app_id == scope.app_id,
        task_extractions.c.principal_id == user)
    queries["origin_seals"] = select(delivery_graph_requests).where(
        delivery_graph_requests.c.app_id == scope.app_id,
        delivery_graph_requests.c.principal_id == user,
        delivery_graph_requests.c.kind.in_([spec.META, spec.META + "_seal", spec.BIND, spec.BIND + "_seal"])
        ).order_by(delivery_graph_requests.c.kind, delivery_graph_requests.c.request_key)
    result = c.execute(select(run_contracts.c.snapshot).where(run_contracts.c.run_id == rid))
    _checkpoint_graph(store, c, _graph_read)
    contract = result.scalar_one()
    goal_id = contract["goal"]["goal_id"]
    queries["current_goal"] = select(goal_cards).where(goal_cards.c.id == goal_id,
        goal_cards.c.project_id == pid)
    queries["current_goal_versions"] = select(goal_card_versions).join(goal_cards,
        goal_cards.c.id == goal_card_versions.c.card_id).where(goal_cards.c.id == goal_id,
        goal_cards.c.project_id == pid).order_by(goal_card_versions.c.version)
    rows["original"] = dict(original)
    for name, query in queries.items():
        result = c.execute(query)
        _checkpoint_graph(store, c, _graph_read)
        rows[name] = [dict(row) for row in result.mappings()]
    return rows


def _source_audit(store, c, user, pid, rid):
    """Original complete current source scope and audit bytes, never a permit."""
    from . import pa_spec_apps as spec

    scope, seal, original = _source_audit_prefix(store, c, user, pid, rid)
    original_audit = spec.audit_fingerprint(store, c, user, original)
    return fingerprint(_source_audit_rows(store, c, user, pid, rid,
        scope, seal, original, original_audit))


@dataclass(frozen=True)
class _ColdSourceAuditPrefix:
    guard: Any
    key: str
    user: str
    pid: str
    rid: str
    scope: Any
    seal: dict
    original: Any

    def fields(self):
        return dict(user=self.user, pid=self.pid, rid=self.rid, scope=self.scope.model_dump(),
                    seal=self.seal, original=dict(self.original))


@dataclass(frozen=True)
class _ColdSourceAuditFacts:
    prefix: _ColdSourceAuditPrefix
    key: str
    original_audit_rows: dict
    rows: dict
    digest: str

    def fields(self):
        return dict(prefix=self.prefix.fields(), original_audit_rows=self.original_audit_rows,
                    rows=self.rows, digest=self.digest)


def _cold_source_audit_prefix(store, c, user, pid, rid, guard):
    """Stop exactly before the original native spec audit dependency."""
    try:
        require(guard is not None)
        _checkpoint_graph(store, c, guard)
        scope, seal, original = _source_audit_prefix(store, c, user, pid, rid, _graph_read=guard)
        prefix = _ColdSourceAuditPrefix(guard, "pb-source-audit:" + user + ":" + pid + ":" + rid,
                                        user, pid, rid, scope, seal, original)
        guard.add(prefix.key, prefix.fields())
        return prefix
    except BaseException:
        _invalidate_graph(guard)
        raise


def _cold_source_audit_from_original(store, c, user, prefix, original_audit_rows):
    """Collect every original row after a complete, explicitly supplied native audit.

    The caller must have proved the native audit's original scopes and history;
    these full raw rows never substitute for that proof or fresh authorities.
    """
    guard = prefix.guard if type(prefix) is _ColdSourceAuditPrefix else None
    try:
        require(type(prefix) is _ColdSourceAuditPrefix and user == prefix.user)
        _cold_fields(store, c, guard, prefix.key, prefix.fields())
        require(type(original_audit_rows) is dict and set(original_audit_rows) == {
            "run", "contract", "original", "attempts", "operations", "intents", "events",
            "confirmation", "goal_head", "goal_version"}, "Complete original native audit rows required")
        rows = _source_audit_rows(store, c, user, prefix.pid, prefix.rid,
            prefix.scope, prefix.seal, prefix.original, fingerprint(original_audit_rows), _graph_read=guard)
        _checkpoint_graph(store, c, guard)
        facts = _ColdSourceAuditFacts(prefix, prefix.key + ":complete", original_audit_rows,
                                      rows, fingerprint(rows))
        guard.add(facts.key, facts.fields())
        return facts
    except BaseException:
        _invalidate_graph(guard)
        raise''')

replace('def _source(store,', '\ndef _source_proof_fields(', '''def _source_prefix(store, c, user, pid, rid, *, _graph_read=None):
    source_gate(store, c, user, pid, rid, **({"_graph_read": _graph_read} if _graph_read is not None else {}))
    _checkpoint_graph(store, c, _graph_read)
    result = c.execute(select(runs.c.status).where(runs.c.id == rid))
    _checkpoint_graph(store, c, _graph_read)
    status = result.scalar_one()
    require(status == "SUCCEEDED", "Only a completed successful task is a P-B source")
    result = c.execute(select(runs).where(runs.c.id == rid, runs.c.principal_id == user,
                                        runs.c.project_id == pid))
    _checkpoint_graph(store, c, _graph_read)
    return result.mappings().one()


def _source_typed(store, c, user, pid, rid, job, binding, proved, *, _graph_read=None):
    _checkpoint_graph(store, c, _graph_read)
    draft, snap, app_run = binding["draft"], binding["snapshot"], binding["app_run"]
    require(natural.is_candidate(draft["candidate"]) and "spec_task" not in draft["candidate"])
    result = c.execute(select(internal_instance_data).where(
        internal_instance_data.c.instance_id == snap["instance_id"],
        internal_instance_data.c.run_id == app_run["id"]))
    _checkpoint_graph(store, c, _graph_read)
    typed = result.mappings().one()
    proof = _source_proof_fields(user, pid, rid, binding, draft, snap, app_run, job, typed, proved)
    _checkpoint_graph(store, c, _graph_read)
    return typed, proof


def _source_from_audit(proof, digest):
    proof.update(runtime_audit_fingerprint=digest,
        citation_status="PASS", semantic_status="UNKNOWN", owner_acceptance="PENDING")
    return proof


def _source(store, c, user, pid, rid, limits, *, _source_origin=True):
    from . import pa_spec_apps as spec

    job = _source_prefix(store, c, user, pid, rid)
    binding, _, proved = spec.verify_job(store, c, user, job, limits, _source_origin=_source_origin)
    _, proof = _source_typed(store, c, user, pid, rid, job, binding, proved)
    return binding, _source_from_audit(proof, source_audit(store, c, user, pid, rid))


@dataclass(frozen=True)
class _ColdSourcePrefix:
    guard: Any
    key: str
    user: str
    pid: str
    rid: str
    limits: Limits
    role: str
    job: Any

    def fields(self):
        return dict(user=self.user, pid=self.pid, rid=self.rid, role=self.role,
                    limits=self.limits.model_dump(), job=dict(self.job))


@dataclass(frozen=True)
class _ColdSourceTyped:
    prefix: _ColdSourcePrefix
    key: str
    binding: dict
    outputs: dict
    proved: list
    typed: Any
    proof: dict

    def fields(self):
        return dict(prefix=self.prefix.fields(), binding=self.binding, outputs=self.outputs,
                    proved=self.proved, typed=dict(self.typed), proof=self.proof)


@dataclass(frozen=True)
class _ColdSourceFacts:
    typed: _ColdSourceTyped
    audit: _ColdSourceAuditFacts
    key: str
    proof: dict

    @property
    def binding(self):
        return self.typed.binding

    def fields(self):
        return dict(typed=self.typed.fields(), audit=self.audit.fields(), proof=self.proof)


def _cold_source_prefix(store, c, user, pid, rid, limits, guard, role):
    """Stop before verify_job; caller supplies its complete role-specific result."""
    try:
        require(guard is not None)
        _checkpoint_graph(store, c, guard)
        require(type(limits) is Limits and role in {"source", "generate", "cold"})
        job = _source_prefix(store, c, user, pid, rid, _graph_read=guard)
        key = ":".join(("pb-source", role, user, pid, rid, fingerprint(limits.model_dump())))
        prefix = _ColdSourcePrefix(guard, key, user, pid, rid, limits, role, job)
        guard.add(prefix.key, prefix.fields())
        return prefix
    except BaseException:
        _invalidate_graph(guard)
        raise


def _cold_source_typed(store, c, user, prefix, binding, outputs, proved):
    """Consume complete verify_job facts, then read the original typed row."""
    guard = prefix.guard if type(prefix) is _ColdSourcePrefix else None
    try:
        require(type(prefix) is _ColdSourcePrefix and user == prefix.user)
        _cold_fields(store, c, guard, prefix.key, prefix.fields())
        require(type(binding) is dict and type(outputs) is dict and type(proved) is list)
        typed, proof = _source_typed(store, c, user, prefix.pid, prefix.rid,
            prefix.job, binding, proved, _graph_read=guard)
        facts = _ColdSourceTyped(prefix, prefix.key + ":typed", binding, outputs, proved, typed, proof)
        guard.add(facts.key, facts.fields())
        return facts
    except BaseException:
        _invalidate_graph(guard)
        raise


def _cold_source_from_audit(store, c, user, typed, audit):
    """Append only the original full Source audit at its original dependency edge."""
    guard = typed.prefix.guard if type(typed) is _ColdSourceTyped else None
    try:
        require(type(typed) is _ColdSourceTyped and type(audit) is _ColdSourceAuditFacts)
        prefix = typed.prefix
        _cold_fields(store, c, guard, typed.key, typed.fields())
        _cold_fields(store, c, guard, audit.key, audit.fields())
        require(user == prefix.user == audit.prefix.user and guard is audit.prefix.guard
                and prefix.pid == audit.prefix.pid and prefix.rid == audit.prefix.rid)
        proof = _source_from_audit(dict(typed.proof), audit.digest)
        facts = _ColdSourceFacts(typed, audit, prefix.key + ":complete", proof)
        guard.add(facts.key, facts.fields())
        return facts
    except BaseException:
        _invalidate_graph(guard)
        raise''')

# Retain one candidate/review implementation, adding only optional exact scope checkpoints.
text=text.replace('def candidate(body, proof, material, goal, aid, pid, limits):',
                  'def candidate(body, proof, material, goal, aid, pid, limits, *, _graph_read=None):')
text=text.replace('                           goal.snapshot["content"], limits, proof["output_fingerprint"])\n    value["manifest"]',
                  '                           goal.snapshot["content"], limits, proof["output_fingerprint"])\n    _checkpoint_graph_owner(_graph_read)\n    value["manifest"]',1)
text=text.replace('def _review_from_facts(user, pid, body, limits, binding, proof, material, goal):',
                  'def _review_from_facts(user, pid, body, limits, binding, proof, material, goal, *, _graph_read=None):')
text=text.replace('    value = candidate(body, proof, material, goal, aid, pid, approved)\n    _, _, report = natural.compile_candidate(value, limits)',
                  '    value = candidate(body, proof, material, goal, aid, pid, approved,\n        **({"_graph_read": _graph_read} if _graph_read is not None else {}))\n    _checkpoint_graph_owner(_graph_read)\n    compiled = natural.compile_candidate(value, limits)\n    _checkpoint_graph_owner(_graph_read)\n    _, _, report = compiled',1)
text=text.replace('preview=natural.preview(material, value, {}), consent=CONSENT,',
                  'preview=_review_preview(material, value, _graph_read), consent=CONSENT,',1)
pos=text.index('\ndef frozen_for(')
text=text[:pos]+'''\ndef _review_preview(material, value, guard):
    preview = natural.preview(material, value, {})
    _checkpoint_graph_owner(guard)
    return preview

''' + text[pos:]

replace('@controlled\ndef verify(', '\ndef receipt(', '''def _verify_prefix(store, c, user, draft, *, _graph_read=None):
    from . import pa_spec_apps as spec

    _checkpoint_graph(store, c, _graph_read)
    scoped = spec.scope_gate(store, c, user, draft["id"])
    _checkpoint_graph(store, c, _graph_read)
    require(scoped)
    result = c.execute(select(task_extractions).where(task_extractions.c.app_id == draft["id"]))
    _checkpoint_graph(store, c, _graph_read)
    marker = result.mappings().one()
    paired = pair(c, user, draft["id"], EXTRACT, marker["request_key"], ExtractInput)
    _checkpoint_graph(store, c, _graph_read)
    body, frozen = paired
    paired = pair(c, user, draft["id"], META, "scope", Metadata)
    _checkpoint_graph(store, c, _graph_read)
    meta, _ = paired
    require(marker["principal_id"] == user and marker["task_id"] == body.review.source_run_id == meta.source_run_id
            and marker["request_key"] == body.review.request_key
            and marker["request_fingerprint"] == fingerprint(body.model_dump()))
    return marker, body, frozen, meta


def _extraction_name(store, c, draft, guard):
    result = c.execute(select(app_drafts.c.name).where(app_drafts.c.id == draft["id"]))
    _checkpoint_graph(store, c, guard)
    return result.scalar_one()


def _verify_from_review(store, c, user, draft, limits, marker, body, frozen, meta,
                        checked, material, goal, *, _graph_read=None):
    _checkpoint_graph(store, c, _graph_read)
    require(body.expected_review_fingerprint == checked["review_fingerprint"]
            and frozen == frozen_for(user, draft["project_id"], body, checked)
            and fingerprint(marker["snapshot"]) == fingerprint(frozen)
            and draft["id"] == checked["app_id"] and draft["runtime_id"] == checked["runtime_id"]
            and fingerprint(draft["candidate"]) == draft["fingerprint"] == checked["candidate_fingerprint"]
            and _extraction_name(store, c, draft, _graph_read) == body.review.name
            and meta.resource_id == material["resource_id"])
    compiled = natural.compile_candidate(draft["candidate"], limits)
    _checkpoint_graph(store, c, _graph_read)
    manifest, _, report = compiled
    return manifest, report, material, goal.model_dump()


@controlled
def verify(store, c, user, draft, limits):
    marker, body, frozen, meta = _verify_prefix(store, c, user, draft)
    checked, material, goal = review(store, c, user, draft["project_id"], body.review, limits, draft["runtime_id"])
    return _verify_from_review(store, c, user, draft, limits,
        marker, body, frozen, meta, checked, material, goal)


@dataclass(frozen=True)
class _ColdExtractionPrefix:
    guard: Any
    key: str
    user: str
    draft: Any
    limits: Limits
    role: str
    marker: Any
    body: ExtractInput
    frozen: dict
    meta: Metadata

    def fields(self):
        return dict(user=self.user, draft=dict(self.draft), limits=self.limits.model_dump(), role=self.role,
                    marker=dict(self.marker), body=self.body.model_dump(), frozen=self.frozen, meta=self.meta.model_dump())


@dataclass(frozen=True)
class _ColdExtractionReview:
    prefix: _ColdExtractionPrefix
    source: _ColdSourceFacts
    key: str
    checked: dict
    material: dict
    goal: Any

    def fields(self):
        return dict(prefix=self.prefix.fields(), source=self.source.fields(), checked=self.checked,
                    material=self.material, goal=self.goal.model_dump())


def _cold_verify_prefix(store, c, user, draft, limits, guard, role):
    """Stop after exact extraction identity and before its Source dependency."""
    try:
        require(guard is not None)
        _checkpoint_graph(store, c, guard)
        require(type(limits) is Limits and role in {"source", "generate", "cold"})
        marker, body, frozen, meta = _verify_prefix(store, c, user, draft, _graph_read=guard)
        key = ":".join(("pb-extraction", role, user, draft["id"], fingerprint(limits.model_dump())))
        prefix = _ColdExtractionPrefix(guard, key, user, draft, limits, role, marker, body, frozen, meta)
        guard.add(prefix.key, prefix.fields())
        return prefix
    except BaseException:
        _invalidate_graph(guard)
        raise


def _cold_review_from_source(store, c, user, prefix, source_facts):
    """Compare Source first, then original current target gates and full review."""
    from . import pa_spec_apps as spec

    guard = prefix.guard if type(prefix) is _ColdExtractionPrefix else None
    try:
        require(type(prefix) is _ColdExtractionPrefix and type(source_facts) is _ColdSourceFacts)
        _cold_fields(store, c, guard, prefix.key, prefix.fields())
        _cold_fields(store, c, guard, source_facts.key, source_facts.fields())
        source_prefix = source_facts.typed.prefix
        require(user == prefix.user == source_prefix.user and guard is source_prefix.guard
                and prefix.draft["project_id"] == source_prefix.pid
                and prefix.body.review.source_run_id == source_prefix.rid
                and prefix.limits is source_prefix.limits and prefix.role == source_prefix.role)
        _review_source_from_facts(prefix.body.review, source_facts.proof)
        _checkpoint_graph(store, c, guard)
        targeted = spec.target(store, c, user, prefix.draft["project_id"], prefix.body.review.card_id,
            prefix.body.review.expected_goal_version, prefix.body.review.expected_goal_fingerprint,
            prefix.draft["runtime_id"], family=natural.VERSION)
        _checkpoint_graph(store, c, guard)
        material, goal = targeted
        reviewed = _review_from_facts(user, prefix.draft["project_id"], prefix.body.review, prefix.limits,
            source_facts.binding, source_facts.proof, material, goal, _graph_read=guard)
        _checkpoint_graph(store, c, guard)
        checked, material, goal = reviewed
        facts = _ColdExtractionReview(prefix, source_facts, prefix.key + ":review", checked, material, goal)
        guard.add(facts.key, facts.fields())
        return facts
    except BaseException:
        _invalidate_graph(guard)
        raise


def _cold_verify_from_review(store, c, user, prefix, review_facts):
    guard = prefix.guard if type(prefix) is _ColdExtractionPrefix else None
    try:
        require(type(prefix) is _ColdExtractionPrefix and type(review_facts) is _ColdExtractionReview)
        _cold_fields(store, c, guard, prefix.key, prefix.fields())
        _cold_fields(store, c, guard, review_facts.key, review_facts.fields())
        require(review_facts.prefix is prefix and user == prefix.user)
        value = _verify_from_review(store, c, user, prefix.draft, prefix.limits,
            prefix.marker, prefix.body, prefix.frozen, prefix.meta,
            review_facts.checked, review_facts.material, review_facts.goal, _graph_read=guard)
        _checkpoint_graph(store, c, guard)
        return value
    except BaseException:
        _invalidate_graph(guard)
        raise


def _audit_prefix(store, c, user, draft, *, _graph_read=None):
    from . import pa_spec_apps as spec

    _checkpoint_graph(store, c, _graph_read)
    scoped = spec.scope_gate(store, c, user, draft["id"])
    _checkpoint_graph(store, c, _graph_read)
    require(scoped)
    paired = pair(c, user, draft["id"], META, "scope", Metadata)
    _checkpoint_graph(store, c, _graph_read)
    meta, meta_seal = paired
    result = c.execute(select(task_extractions).where(task_extractions.c.app_id == draft["id"]))
    _checkpoint_graph(store, c, _graph_read)
    marker = result.mappings().one()
    paired = pair(c, user, draft["id"], EXTRACT, marker["request_key"], ExtractInput)
    _checkpoint_graph(store, c, _graph_read)
    body, frozen = paired
    result = c.execute(select(app_drafts).where(app_drafts.c.id == draft["id"],
        app_drafts.c.project_id == draft["project_id"], app_drafts.c.runtime_id == draft["runtime_id"]))
    _checkpoint_graph(store, c, _graph_read)
    actual = result.mappings().one()
    return meta, meta_seal, marker, body, frozen, actual


def _audit_from_source(meta, meta_seal, marker, body, frozen, actual, source_digest, *, _audit_out=None):
    digest = fingerprint(dict(source_audit=source_digest,
        metadata=meta.model_dump(), metadata_seal=meta_seal,
        marker=dict(marker), request=body.model_dump(), frozen=frozen, draft=dict(actual)))
    if _audit_out is not None:
        _audit_out.update(base=copy.deepcopy(dict(actual)), digest=digest)
    return digest


def audit_fingerprint(store, c, user, draft, *, _audit_out=None):
    meta, meta_seal, marker, body, frozen, actual = _audit_prefix(store, c, user, draft)
    source_digest = source_audit(store, c, user, draft["project_id"], meta.source_run_id)
    return _audit_from_source(meta, meta_seal, marker, body, frozen, actual, source_digest,
                              _audit_out=_audit_out)


@dataclass(frozen=True)
class _ColdExtractionAuditPrefix:
    guard: Any
    key: str
    user: str
    draft: Any
    meta: Metadata
    meta_seal: dict
    marker: Any
    body: ExtractInput
    frozen: dict
    actual: Any

    def fields(self):
        return dict(user=self.user, draft=dict(self.draft), metadata=self.meta.model_dump(),
                    metadata_seal=self.meta_seal, marker=dict(self.marker), body=self.body.model_dump(),
                    frozen=self.frozen, actual=dict(self.actual))


def _cold_audit_prefix(store, c, user, draft, guard):
    """Stop at the original Source audit field before collecting that dependency."""
    try:
        require(guard is not None)
        _checkpoint_graph(store, c, guard)
        meta, meta_seal, marker, body, frozen, actual = _audit_prefix(store, c, user, draft, _graph_read=guard)
        prefix = _ColdExtractionAuditPrefix(guard, "pb-extraction-audit:" + user + ":" + draft["id"],
            user, draft, meta, meta_seal, marker, body, frozen, actual)
        guard.add(prefix.key, prefix.fields())
        return prefix
    except BaseException:
        _invalidate_graph(guard)
        raise


def _cold_audit_from_source(store, c, user, prefix, source_facts, *, _audit_out=None):
    guard = prefix.guard if type(prefix) is _ColdExtractionAuditPrefix else None
    try:
        require(type(prefix) is _ColdExtractionAuditPrefix and type(source_facts) is _ColdSourceAuditFacts)
        _cold_fields(store, c, guard, prefix.key, prefix.fields())
        _cold_fields(store, c, guard, source_facts.key, source_facts.fields())
        require(user == prefix.user == source_facts.prefix.user and guard is source_facts.prefix.guard
                and prefix.draft["project_id"] == source_facts.prefix.pid
                and prefix.meta.source_run_id == source_facts.prefix.rid)
        digest = _audit_from_source(prefix.meta, prefix.meta_seal, prefix.marker, prefix.body,
            prefix.frozen, prefix.actual, source_facts.digest, _audit_out=_audit_out)
        _checkpoint_graph(store, c, guard)
        return digest
    except BaseException:
        _invalidate_graph(guard)
        raise''')

ast.parse(original)
ast.parse(text)
(root/'original.py').write_text(original)
(root/'proposed.py').write_text(text)
(root/'implementation.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),text.splitlines(True),fromfile='a/src/sim2act/pb_natural_specs.py',tofile='b/src/sim2act/pb_natural_specs.py')))
(root/'source.sha256').write_text(hashlib.sha256(original.encode()).hexdigest()+'  src/sim2act/pb_natural_specs.py\n')
print('original lines',len(original.splitlines()),'proposed lines',len(text.splitlines()))
print('patch sha256',hashlib.sha256((root/'implementation.patch').read_bytes()).hexdigest())
