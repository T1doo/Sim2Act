# Same-epoch complete Limits facets: single-file delta

Apply `facet-delta.patch` to the already-applied `pb_natural_specs.py` whose
SHA256 is `40c2641de42ab56dfafa588c7cf3eab62ece02666b8d1b9bdf512fc3a08f0365`.
This delta changes only that module. Root remains the only repository writer.

## New Source Limits facet

```python
source_for_limits = pb._cold_source_facet_from_source(
    store, c, user, complete_source, new_limits,
    new_verified_binding, new_outputs, new_proved,
    role="cold",  # optional: defaults to complete_source.typed.prefix.role
)
```

Input `complete_source` must be the exact `_ColdSourceFacts` from this same
active `_ColdGraphRead`. `new_limits` is an exact, complete `Limits` object.
Root independently constructs the **complete new** role-specific verified
binding/outputs/proved result first, retaining the original source Binding,
clock, counter, pending-aware receipts, typed/output/result predicates and all
required fresh authority gates. This adapter does not infer those predicates
from old success, a digest, or equality of limits.

The adapter reuses the original exact Run object, exact complete typed row,
and exact complete Source/native audit packet. It reconstructs the full Source
proof from the supplied new complete binding/receipts and the original typed
row; it applies the original natural/non-extraction predicate and the exact
original typed SELECT's instance/AppRun selection predicates. It performs no
SQL, ancestor call or audit recollection. Return type is `_ColdSourceFacts`,
with full `.binding`, `.proof`, `.typed` and `.audit` rather than a hash-only
stand-in. The new Limits object itself is also pinned, in addition to the full
serialized facet.

Different role/full-Limits values use distinct fixed producer keys. A duplicate
producer key fails closed; reuse an already completed identical facet instead
of producing it twice. The role enum remains `source`, `generate`, `cold`.

## New extraction Limits facet

```python
facet_prefix, facet_review, origin = pb._cold_verify_facet_from_review(
    store, c, user,
    original_exact_extraction_prefix, original_complete_review,
    new_limits, source_for_limits,
    role="cold",  # optional: defaults to original prefix role
)
# origin == (manifest, report, material, goal_dump)
```

The original prefix and `_ColdExtractionReview` must be an exact matching
pair in the same active epoch. The new complete Source packet must match the
same user/project/source Run, same guard, chosen role, and **same new Limits
object**. Root retains fresh scope/current authority checks at the original
role edges.

The adapter reuses complete original extraction marker, request/frozen pair,
metadata pair, actual draft, and full target material/Goal objects. It invokes
`_review_source_from_facts` for the new Source proof, then shared
`_review_from_facts` under the new caller Limits, and shared
`_verify_from_review` under those Limits. Thus the source proof comparison,
inherited source declared Limits, all full review/frozen/marker/app/candidate
predicates and both original compilations remain independent for this facet.
The name scalar SQL remains in the exact original AND short-circuit position.
No metadata/body/target/Source/audit collection is replayed. The new prefix,
complete review packet, and origin tuple are returned explicitly.

## Source audit full raw reuse

The existing strict audit suffix now accepts an optional exact Run reader:

```python
audit = pb._cold_source_audit_from_original(
    store, c, user, audit_prefix, complete_original_native_audit_rows,
    source_reader=source_run_facts,
)
```

`source_run_facts` must be exact `natural_spec_runtime._ColdRunFacts`, with
same Store/Connection/job/guard and same user/project/source Run. At the
original `attempts` iteration, it supplies full `attempt_rows(ledger=True)`;
at the original `operations` iteration, it supplies full
`receipt_operations()` sorted by id using a copy. Complete byte/row fields,
cardinality and duplicates are retained. Those reader methods load at that
original position if not yet reached, and otherwise reuse pinned full raw rows.
All other complete audit SQL remains in its original order, including all
intents, effects, all events (not projected anchors), reservations and current
Goal/version bodies. No field is removed. The default `source_reader=None`
continues the original SQL branch.

## Strict cleanup and model/body continuity

Every strict producer now keeps parameter extraction, exact-type checks and
work inside its `BaseException` region. Guard narrowing uses explicit
`if guard is None: raise DomainError(...)`; no ignore/cast or broad Any workaround
was added to conceal the reported mypy errors. Mypy itself was not run here.

Cleanup follows a fixed closed list of exact known guards/packets/Run readers;
it does not call an arbitrary input's invalidation hook. Both exact input sides
are invalidated on mismatches. Prefixes retain their original guard separately,
reject guard replacement, and invalidate both known current/original guards.
The original exception is re-raised unchanged. Catching a producer's error
inside the graph context cannot make the guard usable again.

Strict shared review now retains a fixed `_ColdReviewRead` over full original
request, actual caller/source-declared Limits, complete binding/proof,
material and full mutable Goal model. It reserializes those actual objects
immediately after expand, compile and preview, before consuming their results.
The expanded candidate is pinned before compilation. This closes the gap where
a Goal/request `.model_dump()` copy could stay unchanged while a callee mutated
the original model. Default `None` paths create no read packet, add no guard
input, and supply no new private keyword to public dependencies.

## Evidence and limits

`static-check.json` records stdlib AST parse, exact unchanged default entry/
leaf checks, exact complete audit query shapes/order, strict producer outer
BaseException structure, and absence of direct SQL/ancestor replay in the two
new facet producers. `git apply --check` passed against the captured applied
base. Source, extraction verification, extraction writes and audit default
entry functions and their principal shared predicates retain exact AST; the
review pure core gains only optional strict continuity handling.

No repository files were changed by this agent. No product imports, DB calls,
model calls, network operations, Ruff, mypy or tests were run. Root must apply,
run the gates, independently review, and integrate the complete graph. This
patch alone is not a P2 or acceptance claim.
