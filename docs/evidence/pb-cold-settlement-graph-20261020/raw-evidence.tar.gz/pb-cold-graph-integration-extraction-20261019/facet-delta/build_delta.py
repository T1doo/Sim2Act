from pathlib import Path
import ast,difflib,hashlib,json

root=Path('/workspace/pb-cold-graph-integration-extraction-20261019/facet-delta')
source=Path('/workspace/Sim2Act/src/sim2act/pb_natural_specs.py')
original=source.read_text()
s=original

def replace(start,end,new):
    global s
    i=s.index(start); j=s.index(end,i)
    s=s[:i]+new.rstrip()+'\n\n\n'+s[j:]

s=s.replace('        guard.invalidate()\n\n\ndef _cold_fields', '        _ColdGraphRead.invalidate(guard)\n\n\ndef _cold_fields',1)
# A fixed closed list of exact facts classes, used only for sticky failure cleanup.
pos=s.index('\ndef _cold_fields(')
s=s[:pos]+'''
def _invalidate_cold_inputs(*values):
    """Invalidate only known exact local facts; never invoke an impostor hook."""
    from .natural_spec_runtime import _ColdGraphRead, _ColdRunFacts

    pending, seen = list(values), set()
    while pending:
        value = pending.pop()
        if id(value) in seen:
            continue
        seen.add(id(value))
        kind = type(value)
        if kind is _ColdGraphRead:
            _ColdGraphRead.invalidate(value)
        elif kind is _ColdRunFacts:
            pending.extend((getattr(value, "guard", None), getattr(value, "_origin_guard", None)))
        elif kind in {_ColdSourcePrefix, _ColdSourceAuditPrefix,
                      _ColdExtractionPrefix, _ColdExtractionAuditPrefix}:
            pending.append(getattr(value, "guard", None))
        elif kind in {_ColdSourceTyped, _ColdSourceAuditFacts}:
            pending.append(getattr(value, "prefix", None))
        elif kind is _ColdSourceFacts:
            pending.extend((getattr(value, "typed", None), getattr(value, "audit", None)))
        elif kind is _ColdExtractionReview:
            pending.extend((getattr(value, "prefix", None), getattr(value, "source", None)))

''' + s[pos:]

# Optional exact reader supplies only complete raw Attempts and Operations at
# their original positions. Other original audit queries remain unchanged.
s=s.replace('                       *, _graph_read=None):\n    from . import pa_spec_apps as spec\n    from .db import delivery_graph_requests, goal_card_versions, goal_cards',
            '                       *, _graph_read=None, _source_reader=None):\n    from . import pa_spec_apps as spec\n    from .db import delivery_graph_requests, goal_card_versions, goal_cards',1)
old='''    for name, query in queries.items():
        result = c.execute(query)
        _checkpoint_graph(store, c, _graph_read)
        rows[name] = [dict(row) for row in result.mappings()]
    return rows'''
new='''    for name, query in queries.items():
        if _source_reader is not None and name in {"attempts", "operations"}:
            from .natural_spec_runtime import _ColdRunFacts
            require(type(_source_reader) is _ColdRunFacts)
            _source_reader.check(store, c, _source_reader.job)
            require(_source_reader.guard is _graph_read
                and _source_reader.job["id"] == rid
                and _source_reader.job["principal_id"] == user
                and _source_reader.job["project_id"] == pid)
            if name == "attempts":
                raw = _source_reader.attempt_rows(ledger=True)
            else:
                raw = sorted(_source_reader.receipt_operations(), key=lambda row: row["id"])
            _checkpoint_graph(store, c, _graph_read)
            _source_reader.check(store, c, _source_reader.job)
            rows[name] = [dict(row) for row in raw]
        else:
            result = c.execute(query)
            _checkpoint_graph(store, c, _graph_read)
            rows[name] = [dict(row) for row in result.mappings()]
    return rows'''
assert s.count(old)==1
s=s.replace(old,new,1)
replace('def _cold_source_audit_from_original(', '\ndef scope_gate(', '''def _cold_source_audit_from_original(store, c, user, prefix, original_audit_rows, *, source_reader=None):
    """Collect every original row after a complete, explicitly supplied native audit.

    Only the exact same-epoch Run reader may supply complete Attempt/Operation
    raw rows at their original positions. It supplies no authority or proof.
    """
    guard = None
    try:
        from .natural_spec_runtime import _ColdRunFacts

        require(type(prefix) is _ColdSourceAuditPrefix)
        guard = prefix.guard
        if guard is None:
            raise DomainError("VERSION_CONFLICT", "Exact Cold graph read scope required")
        _cold_fields(store, c, guard, prefix.key, prefix.fields())
        require(user == prefix.user and (source_reader is None or type(source_reader) is _ColdRunFacts))
        require(type(original_audit_rows) is dict and set(original_audit_rows) == {
            "run", "contract", "original", "attempts", "operations", "intents", "events",
            "confirmation", "goal_head", "goal_version"}, "Complete original native audit rows required")
        guard.add(prefix.key + ":native", original_audit_rows)
        rows = _source_audit_rows(store, c, user, prefix.pid, prefix.rid,
            prefix.scope, prefix.original, prefix.rows, fingerprint(original_audit_rows),
            _graph_read=guard, _source_reader=source_reader)
        _checkpoint_graph(store, c, guard)
        facts = _ColdSourceAuditFacts(prefix, prefix.key + ":complete", original_audit_rows,
                                      rows, fingerprint(rows))
        guard.add(facts.key, facts.fields())
        return facts
    except BaseException:
        _invalidate_cold_inputs(guard, prefix, source_reader)
        raise''')

replace('def _cold_source_typed(', '\ndef _source_proof_fields(', '''def _cold_source_typed(store, c, user, prefix, binding, outputs, proved):
    """Consume complete verify_job facts, then read the original typed row."""
    guard = None
    try:
        require(type(prefix) is _ColdSourcePrefix)
        guard = prefix.guard
        if guard is None:
            raise DomainError("VERSION_CONFLICT", "Exact Cold graph read scope required")
        _cold_fields(store, c, guard, prefix.key, prefix.fields())
        require(user == prefix.user)
        require(type(binding) is dict and type(outputs) is dict and type(proved) is list)
        guard.add(prefix.key + ":verified", dict(binding=binding, outputs=outputs, proved=proved))
        typed, proof = _source_typed(store, c, user, prefix.pid, prefix.rid,
            prefix.job, binding, proved, _graph_read=guard)
        facts = _ColdSourceTyped(prefix, prefix.key + ":typed", binding, outputs, proved, typed, proof)
        guard.add(facts.key, facts.fields())
        return facts
    except BaseException:
        _invalidate_cold_inputs(guard, prefix)
        raise


def _cold_source_from_audit(store, c, user, typed, audit):
    """Append only the original full Source audit at its original dependency edge."""
    guard = None
    try:
        require(type(typed) is _ColdSourceTyped and type(typed.prefix) is _ColdSourcePrefix
            and type(audit) is _ColdSourceAuditFacts and type(audit.prefix) is _ColdSourceAuditPrefix)
        prefix = typed.prefix
        guard = prefix.guard
        if guard is None:
            raise DomainError("VERSION_CONFLICT", "Exact Cold graph read scope required")
        _cold_fields(store, c, guard, typed.key, typed.fields())
        _cold_fields(store, c, guard, audit.key, audit.fields())
        require(user == prefix.user == audit.prefix.user and guard is audit.prefix.guard
                and prefix.pid == audit.prefix.pid and prefix.rid == audit.prefix.rid)
        proof = _source_from_audit(dict(typed.proof), audit.digest)
        facts = _ColdSourceFacts(typed, audit, prefix.key + ":complete", proof)
        guard.add(facts.key, facts.fields())
        return facts
    except BaseException:
        _invalidate_cold_inputs(guard, typed, audit)
        raise


def _cold_source_facet_from_source(store, c, user, source_facts, limits, binding, outputs, proved, *, role=None):
    """Rebuild one full Limits facet from complete new verify_job facts.

    Root must independently prove bound/clock/counters/receipts/result for this
    exact Limits facet before supplying binding/outputs/proved. Only the same
    epoch's complete Run/typed/native+Source audit raw facts are reused here.
    """
    guard = None
    try:
        require(type(source_facts) is _ColdSourceFacts
            and type(source_facts.typed) is _ColdSourceTyped
            and type(source_facts.typed.prefix) is _ColdSourcePrefix
            and type(source_facts.audit) is _ColdSourceAuditFacts
            and type(source_facts.audit.prefix) is _ColdSourceAuditPrefix)
        original = source_facts.typed.prefix
        guard = original.guard
        if guard is None:
            raise DomainError("VERSION_CONFLICT", "Exact Cold graph read scope required")
        _cold_fields(store, c, guard, source_facts.key, source_facts.fields())
        require(user == original.user == source_facts.audit.prefix.user
            and guard is source_facts.audit.prefix.guard
            and original.pid == source_facts.audit.prefix.pid
            and original.rid == source_facts.audit.prefix.rid
            and type(limits) is Limits and type(binding) is dict
            and type(outputs) is dict and type(proved) is list)
        facet_role = original.role if role is None else role
        require(facet_role in {"source", "generate", "cold"})
        key = ":".join(("pb-source", facet_role, user, original.pid, original.rid,
                        fingerprint(limits.model_dump())))
        prefix = _ColdSourcePrefix(guard, key, user, original.pid, original.rid,
                                    limits, facet_role, original.job)
        guard.add(prefix.key, prefix.fields())
        guard.add(prefix.key + ":limits", limits)
        guard.add(prefix.key + ":verified", dict(binding=binding, outputs=outputs, proved=proved))
        draft, snap, app_run = binding["draft"], binding["snapshot"], binding["app_run"]
        is_natural = natural.is_candidate(draft["candidate"])
        _checkpoint_graph(store, c, guard)
        require(is_natural and "spec_task" not in draft["candidate"])
        typed = source_facts.typed.typed
        # These are the exact predicates of the original typed row SELECT.
        require(typed["instance_id"] == snap["instance_id"] and typed["run_id"] == app_run["id"])
        proof = _source_proof_fields(user, original.pid, original.rid, binding,
            draft, snap, app_run, original.job, typed, proved)
        _checkpoint_graph(store, c, guard)
        typed_facts = _ColdSourceTyped(prefix, prefix.key + ":typed", binding, outputs, proved, typed, proof)
        guard.add(typed_facts.key, typed_facts.fields())
        return _cold_source_from_audit(store, c, user, typed_facts, source_facts.audit)
    except BaseException:
        _invalidate_cold_inputs(guard, source_facts)
        raise''')

replace('def _cold_review_from_source(', '\ndef _audit_prefix(', '''def _cold_review_from_source(store, c, user, prefix, source_facts):
    """Compare Source first, then original current target gates and full review."""
    guard = None
    try:
        from . import pa_spec_apps as spec

        require(type(prefix) is _ColdExtractionPrefix and type(source_facts) is _ColdSourceFacts
            and type(source_facts.typed) is _ColdSourceTyped
            and type(source_facts.typed.prefix) is _ColdSourcePrefix)
        guard = prefix.guard
        if guard is None:
            raise DomainError("VERSION_CONFLICT", "Exact Cold graph read scope required")
        _cold_fields(store, c, guard, prefix.key, prefix.fields())
        _cold_fields(store, c, guard, source_facts.key, source_facts.fields())
        source_prefix = source_facts.typed.prefix
        require(user == prefix.user == source_prefix.user and guard is source_prefix.guard
                and prefix.draft["project_id"] == source_prefix.pid
                and prefix.body.review.source_run_id == source_prefix.rid
                and prefix.limits is source_prefix.limits and prefix.role == source_prefix.role)
        _review_source_from_facts(prefix.body.review, source_facts.proof)
        _checkpoint_graph(store, c, guard)
        targeted = spec.target(store, c, user, prefix.draft["project_id"], prefix.body.review.card_id,
            prefix.body.review.expected_goal_version, prefix.body.review.expected_goal_fingerprint,
            prefix.draft["runtime_id"], family=natural.VERSION, _graph_read=guard)
        _checkpoint_graph(store, c, guard)
        material, goal = targeted
        guard.add(prefix.key + ":target", dict(material=material, goal=goal.model_dump()))
        reviewed = _review_from_facts(user, prefix.draft["project_id"], prefix.body.review, prefix.limits,
            source_facts.binding, source_facts.proof, material, goal, _graph_read=guard)
        _checkpoint_graph(store, c, guard)
        checked, material, goal = reviewed
        facts = _ColdExtractionReview(prefix, source_facts, prefix.key + ":review", checked, material, goal)
        guard.add(facts.key, facts.fields())
        return facts
    except BaseException:
        _invalidate_cold_inputs(guard, prefix, source_facts)
        raise


def _cold_verify_from_review(store, c, user, prefix, review_facts):
    guard = None
    try:
        require(type(prefix) is _ColdExtractionPrefix and type(review_facts) is _ColdExtractionReview)
        guard = prefix.guard
        if guard is None:
            raise DomainError("VERSION_CONFLICT", "Exact Cold graph read scope required")
        _cold_fields(store, c, guard, prefix.key, prefix.fields())
        _cold_fields(store, c, guard, review_facts.key, review_facts.fields())
        require(review_facts.prefix is prefix and user == prefix.user)
        value = _verify_from_review(store, c, user, prefix.draft, prefix.limits,
            prefix.marker, prefix.body, prefix.frozen, prefix.meta,
            review_facts.checked, review_facts.material, review_facts.goal, _graph_read=guard)
        _checkpoint_graph(store, c, guard)
        manifest, report, material, goal = value
        guard.add(prefix.key + ":verified", dict(manifest=manifest.model_dump(),
            report=report, material=material, goal=goal))
        return value
    except BaseException:
        _invalidate_cold_inputs(guard, prefix, review_facts)
        raise


def _cold_verify_facet_from_review(store, c, user, prefix, review_facts, limits, source_facts, *, role=None):
    """Recompile a new Limits facet over the same full metadata and target facts.

    Fresh original scope/authority gates remain root-owned at the role edge.
    Complete new Source proof is required; no earlier compile/review digest is
    used as a substitute for this Limits facet's complete comparison/compile.
    """
    guard = None
    try:
        require(type(prefix) is _ColdExtractionPrefix and type(review_facts) is _ColdExtractionReview
            and type(source_facts) is _ColdSourceFacts
            and type(source_facts.typed) is _ColdSourceTyped
            and type(source_facts.typed.prefix) is _ColdSourcePrefix)
        guard = prefix.guard
        if guard is None:
            raise DomainError("VERSION_CONFLICT", "Exact Cold graph read scope required")
        _cold_fields(store, c, guard, prefix.key, prefix.fields())
        _cold_fields(store, c, guard, review_facts.key, review_facts.fields())
        _cold_fields(store, c, guard, source_facts.key, source_facts.fields())
        source_prefix = source_facts.typed.prefix
        facet_role = prefix.role if role is None else role
        require(user == prefix.user == source_prefix.user and review_facts.prefix is prefix
            and type(limits) is Limits and facet_role in {"source", "generate", "cold"}
            and guard is source_prefix.guard and limits is source_prefix.limits
            and facet_role == source_prefix.role
            and prefix.draft["project_id"] == source_prefix.pid
            and prefix.body.review.source_run_id == source_prefix.rid)
        key = ":".join(("pb-extraction", facet_role, user, prefix.draft["id"],
                        fingerprint(limits.model_dump())))
        facet = _ColdExtractionPrefix(guard, key, user, prefix.draft, limits, facet_role,
            prefix.marker, prefix.body, prefix.frozen, prefix.meta)
        guard.add(facet.key, facet.fields())
        guard.add(facet.key + ":limits", limits)
        _review_source_from_facts(facet.body.review, source_facts.proof)
        _checkpoint_graph(store, c, guard)
        # Original complete target bytes and Goal identity; no repeated target IO.
        material, goal = review_facts.material, review_facts.goal
        guard.add(facet.key + ":target", dict(material=material, goal=goal.model_dump()))
        reviewed = _review_from_facts(user, facet.draft["project_id"], facet.body.review, limits,
            source_facts.binding, source_facts.proof, material, goal, _graph_read=guard)
        _checkpoint_graph(store, c, guard)
        checked, material, goal = reviewed
        review = _ColdExtractionReview(facet, source_facts, facet.key + ":review", checked, material, goal)
        guard.add(review.key, review.fields())
        # Shared exact AND order retains the name scalar at the original point.
        value = _cold_verify_from_review(store, c, user, facet, review)
        _checkpoint_graph(store, c, guard)
        return facet, review, value
    except BaseException:
        _invalidate_cold_inputs(guard, prefix, review_facts, source_facts)
        raise''')

replace('def _cold_audit_from_source(', '\ndef receipt(', '''def _cold_audit_from_source(store, c, user, prefix, source_facts, *, _audit_out=None):
    guard = None
    try:
        require(type(prefix) is _ColdExtractionAuditPrefix
            and type(source_facts) is _ColdSourceAuditFacts
            and type(source_facts.prefix) is _ColdSourceAuditPrefix)
        guard = prefix.guard
        if guard is None:
            raise DomainError("VERSION_CONFLICT", "Exact Cold graph read scope required")
        _cold_fields(store, c, guard, prefix.key, prefix.fields())
        _cold_fields(store, c, guard, source_facts.key, source_facts.fields())
        require(user == prefix.user == source_facts.prefix.user and guard is source_facts.prefix.guard
                and prefix.draft["project_id"] == source_facts.prefix.pid
                and prefix.meta.source_run_id == source_facts.prefix.rid)
        digest = _audit_from_source(prefix.meta, prefix.meta_seal, prefix.marker, prefix.body,
            prefix.frozen, prefix.actual, source_facts.digest, _audit_out=_audit_out)
        _checkpoint_graph(store, c, guard)
        return digest
    except BaseException:
        _invalidate_cold_inputs(guard, prefix, source_facts)
        raise''')
# Existing strict producers also use exact-only cleanup; no default bodies change.
for name in ('_cold_source_audit_prefix','_cold_source_prefix','_cold_verify_prefix','_cold_audit_prefix'):
    a=s.index('def '+name+'(')
    b=s.index('\n\n\n',s.index('    except BaseException:',a))
    part=s[a:b]
    part=part.replace('        require(guard is not None)',
        '        if guard is None:\n            raise DomainError("VERSION_CONFLICT", "Exact Cold graph read scope required")')
    part=part.replace('        _invalidate_graph(guard)', '        _invalidate_cold_inputs(guard)')
    s=s[:a]+part+s[b:]
while '\n\n\n\n' in s: s=s.replace('\n\n\n\n','\n\n\n')

ast.parse(s)
(root/'base.py').write_text(original)
(root/'proposed.py').write_text(s)
(root/'facet-delta.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile='a/src/sim2act/pb_natural_specs.py',tofile='b/src/sim2act/pb_natural_specs.py')))
print('base',hashlib.sha256(original.encode()).hexdigest())
print('proposed',hashlib.sha256(s.encode()).hexdigest())
print('patch',hashlib.sha256((root/'facet-delta.patch').read_bytes()).hexdigest())
