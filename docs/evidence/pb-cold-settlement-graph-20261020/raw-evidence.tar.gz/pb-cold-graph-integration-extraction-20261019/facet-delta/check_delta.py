from pathlib import Path
import ast,difflib,hashlib,json
root=Path('/workspace/pb-cold-graph-integration-extraction-20261019/facet-delta')
a=(root/'base.py').read_text(); b=(root/'proposed.py').read_text(); at=ast.parse(a); bt=ast.parse(b)
af={n.name:n for n in at.body if isinstance(n,ast.FunctionDef)}; bf={n.name:n for n in bt.body if isinstance(n,ast.FunctionDef)}
names=['source','source_audit','source_gate','scope_gate','_source_prefix','_source_typed','_source_from_audit','_source','_source_audit','_source_audit_prefix','_source_proof_fields','review','_review_source_from_facts','frozen_for','_verify_prefix','_extraction_name','_verify_from_review','verify','_audit_prefix','_audit_from_source','audit_fingerprint','receipt','_extract','extract']
checks={n:ast.dump(af[n],include_attributes=False)==ast.dump(bf[n],include_attributes=False) for n in names}; assert all(checks.values()),checks
def querydefs(n):
 return [ast.dump(t,include_attributes=False) for t in n.body if isinstance(t,ast.Assign) and any(isinstance(v,ast.Name) and v.id=='queries' or isinstance(v,ast.Subscript) and isinstance(v.value,ast.Name) and v.value.id=='queries' for v in t.targets)]
checks['audit_query_shapes_and_order']=querydefs(af['_source_audit_rows'])==querydefs(bf['_source_audit_rows']); assert checks['audit_query_shapes_and_order']
facet_apis=['_cold_source_facet_from_source','_cold_verify_facet_from_review']
for name in facet_apis:
 calls=[n for n in ast.walk(bf[name]) if isinstance(n,ast.Call)]
 assert not any(isinstance(n.func,ast.Attribute) and n.func.attr in {'execute','target'} for n in calls),name
 assert not any(isinstance(n.func,ast.Name) and n.func.id in {'pair','source','source_audit','source_gate','_verify_prefix','_source_prefix','_source_typed'} for n in calls),name
# Only a docstring / guard=None assignment precede strict producers' outer try.
producer_names=[n for n in bf if n.startswith('_cold_') and n not in {'_cold_fields'}]
outer_try_checks={}
for name in producer_names:
 n=bf[name]; body=list(n.body)
 if body and isinstance(body[0],ast.Expr) and isinstance(body[0].value,ast.Constant) and isinstance(body[0].value.value,str):body=body[1:]
 if body and isinstance(body[0],ast.Assign) and isinstance(body[0].value,ast.Constant) and body[0].value.value is None:body=body[1:]
 ok=len(body)==1 and isinstance(body[0],ast.Try) and len(body[0].handlers)==1 and isinstance(body[0].handlers[0].type,ast.Name) and body[0].handlers[0].type.id=='BaseException'
 outer_try_checks[name]=ok
assert all(outer_try_checks.values()),outer_try_checks
patch=''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/src/sim2act/pb_natural_specs.py',tofile='b/src/sim2act/pb_natural_specs.py'))
(root/'facet-delta.patch').write_text(patch)
report={'ast_parse':'PASS','base_sha256':hashlib.sha256(a.encode()).hexdigest(),'proposed_sha256':hashlib.sha256(b.encode()).hexdigest(),'patch_sha256':hashlib.sha256(patch.encode()).hexdigest(),'unchanged_default_ast':checks,'strict_producer_outer_try':outer_try_checks,'facet_apis_have_no_direct_sql_or_ancestor_replay':True,'no_product_imports_or_runs':True,'db_calls':0,'models':0,'tests':0,'mypy_or_ruff_run':False,'new_facet_apis':facet_apis}
(root/'static-check.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
