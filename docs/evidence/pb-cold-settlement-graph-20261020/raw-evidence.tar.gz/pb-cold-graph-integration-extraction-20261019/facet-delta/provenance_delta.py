from pathlib import Path
p=Path('/workspace/pb-cold-graph-integration-extraction-20261019/facet-delta/proposed.py')
s=p.read_text()
s=s.replace('            pending.append(getattr(value, "guard", None))',
            '            pending.extend((getattr(value, "guard", None), getattr(value, "_origin_guard", None)))',1)
# Original guard identity is a fixed local fact; retain both known guards for
# cleanup when a malformed packet replaces its visible guard.
for cls in ('_ColdSourcePrefix','_ColdSourceAuditPrefix','_ColdExtractionPrefix','_ColdExtractionAuditPrefix','_ColdReviewRead'):
    a=s.index('class '+cls+':')
    b=s.index('\n\n    def fields(self):',a)
    s=s[:b]+'''\n    _origin_guard: Any = field(init=False, repr=False)

    def __post_init__(self):
        object.__setattr__(self, "_origin_guard", self.guard)
''' +s[b:]
# Every strict consumer verifies the current packet guard is its original guard.
s=s.replace('        guard = prefix.guard\n        if guard is None:',
            '        guard = prefix.guard\n        require(guard is prefix._origin_guard, "Cold extraction read scope cannot be replaced")\n        if guard is None:')
s=s.replace('        guard = original.guard\n        if guard is None:',
            '        guard = original.guard\n        require(guard is original._origin_guard, "Cold Source read scope cannot be replaced")\n        if guard is None:',1)
s=s.replace('            guard = self.guard\n            require(type(guard) is _ColdGraphRead)',
            '            guard = self.guard\n            require(guard is self._origin_guard, "Cold review read scope cannot be replaced")\n            if guard is None:\n                raise DomainError("VERSION_CONFLICT", "Exact Cold graph read scope required")\n            require(type(guard) is _ColdGraphRead)',1)
# The secondary side's guard must also retain its original identity.
s=s.replace('        require(user == prefix.user == audit.prefix.user and guard is audit.prefix.guard',
            '        require(user == prefix.user == audit.prefix.user and guard is audit.prefix.guard\n                and audit.prefix.guard is audit.prefix._origin_guard',1)
s=s.replace('            and guard is source_facts.audit.prefix.guard\n            and original.pid',
            '            and guard is source_facts.audit.prefix.guard\n            and source_facts.audit.prefix.guard is source_facts.audit.prefix._origin_guard\n            and original.pid',1)
s=s.replace('        require(user == prefix.user == source_prefix.user and guard is source_prefix.guard',
            '        require(user == prefix.user == source_prefix.user and guard is source_prefix.guard\n                and source_prefix.guard is source_prefix._origin_guard',1)
s=s.replace('            and guard is source_prefix.guard and limits is source_prefix.limits',
            '            and guard is source_prefix.guard and source_prefix.guard is source_prefix._origin_guard\n            and limits is source_prefix.limits',1)
s=s.replace('        require(user == prefix.user == source_facts.prefix.user and guard is source_facts.prefix.guard',
            '        require(user == prefix.user == source_facts.prefix.user and guard is source_facts.prefix.guard\n                and source_facts.prefix.guard is source_facts.prefix._origin_guard',1)
while '\n\n\n\n' in s: s=s.replace('\n\n\n\n','\n\n\n')
p.write_text(s)
