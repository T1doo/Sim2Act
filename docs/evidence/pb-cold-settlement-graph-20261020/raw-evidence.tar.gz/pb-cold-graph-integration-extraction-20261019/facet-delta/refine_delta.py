from pathlib import Path
p=Path('/workspace/pb-cold-graph-integration-extraction-20261019/facet-delta/proposed.py')
s=p.read_text()
# Internal continuity checks are sticky even when a caller catches inside with.
a=s.index('def _cold_fields('); b=s.index('\ndef source_gate(',a)
s=s[:a]+'''def _cold_fields(store, c, guard, key, value):
    """Only continuity of full explicit facts; never an authority or resolver."""
    try:
        from .natural_spec_runtime import _model_inputs
        _checkpoint_graph(store, c, guard)
        require(guard is not None and type(key) is str and key in guard.inputs,
                "Cold extraction facts belong to a different read segment")
        require(_model_inputs(value) == _model_inputs(guard.inputs[key]),
                "Cold extraction facts changed in this read segment")
    except BaseException:
        _invalidate_cold_inputs(guard)
        raise


''' + s[b:]
s=s.replace('_ColdExtractionPrefix, _ColdExtractionAuditPrefix}:',
            '_ColdExtractionPrefix, _ColdExtractionAuditPrefix, _ColdReviewRead}:',1)
# Fixed complete review inputs are reserialized immediately after each pure
# callee, so mutable Pydantic body/Goal fields cannot drift behind a dump copy.
pos=s.index('\ndef candidate(')
s=s[:pos]+'''
@dataclass(frozen=True)
class _ColdReviewRead:
    guard: Any
    key: str
    body: ReviewInput
    limits: Limits
    approved: Limits
    binding: dict
    proof: dict
    material: dict
    goal: Any

    def fields(self):
        return dict(body=self.body.model_dump(), limits=self.limits, approved=self.approved,
                    binding=self.binding, proof=self.proof, material=self.material,
                    goal=self.goal.model_dump())

    def check(self):
        guard = None
        try:
            from .natural_spec_runtime import _ColdGraphRead
            require(type(self) is _ColdReviewRead)
            guard = self.guard
            require(type(guard) is _ColdGraphRead)
            _cold_fields(guard.store, guard.connection, guard, self.key, self.fields())
        except BaseException:
            _invalidate_cold_inputs(guard, self)
            raise


def _check_review_read(guard, read):
    try:
        if read is not None:
            require(type(read) is _ColdReviewRead and read.guard is guard)
            read.check()
        else:
            require(guard is None, "Complete strict review inputs required")
    except BaseException:
        _invalidate_cold_inputs(guard, read)
        raise

''' + s[pos:]
s=s.replace('def candidate(body, proof, material, goal, aid, pid, limits, *, _graph_read=None):',
            'def candidate(body, proof, material, goal, aid, pid, limits, *, _graph_read=None, _review_read=None):',1)
s=s.replace('    _checkpoint_graph_owner(_graph_read)\n    value["manifest"]["origin"]',
            '    _checkpoint_graph_owner(_graph_read)\n    if _review_read is not None:\n        _check_review_read(_graph_read, _review_read)\n    value["manifest"]["origin"]',1)
s=s.replace('def _review_from_facts(user, pid, body, limits, binding, proof, material, goal, *, _graph_read=None):',
            'def _review_from_facts(user, pid, body, limits, binding, proof, material, goal, *, _graph_read=None, _graph_key=None):',1)
old='''    approved = Limits(**binding["draft"]["candidate"]["manifest"]["runtime_limits"])
    value = candidate(body, proof, material, goal, aid, pid, approved,
        **({"_graph_read": _graph_read} if _graph_read is not None else {}))
    _checkpoint_graph_owner(_graph_read)
    compiled = natural.compile_candidate(value, limits)
    _checkpoint_graph_owner(_graph_read)
    _, _, report = compiled'''
new='''    approved = Limits(**binding["draft"]["candidate"]["manifest"]["runtime_limits"])
    review_read = None
    if _graph_read is not None:
        from .contracts import GoalCardRunSource
        _checkpoint_graph_owner(_graph_read)
        require(type(_graph_key) is str and type(body) is ReviewInput
            and type(limits) is Limits and type(goal) is GoalCardRunSource)
        review_read = _ColdReviewRead(_graph_read, _graph_key + ":inputs", body, limits,
            approved, binding, proof, material, goal)
        _graph_read.add(review_read.key, review_read.fields())
    value = candidate(body, proof, material, goal, aid, pid, approved,
        **({"_graph_read": _graph_read, "_review_read": review_read} if _graph_read is not None else {}))
    _checkpoint_graph_owner(_graph_read)
    if review_read is not None:
        review_read.check()
        _graph_read.add(review_read.key + ":candidate", value)
    compiled = natural.compile_candidate(value, limits)
    _checkpoint_graph_owner(_graph_read)
    if review_read is not None:
        review_read.check()
    _, _, report = compiled'''
assert s.count(old)==1
s=s.replace(old,new,1)
s=s.replace('preview=_review_preview(material, value, _graph_read), consent=CONSENT,',
            'preview=_review_preview(material, value, _graph_read,\n            **({"_review_read": review_read} if review_read is not None else {})), consent=CONSENT,',1)
s=s.replace('def _review_preview(material, value, guard):\n    preview = natural.preview(material, value, {})\n    _checkpoint_graph_owner(guard)\n    return preview',
            'def _review_preview(material, value, guard, *, _review_read=None):\n    preview = natural.preview(material, value, {})\n    _checkpoint_graph_owner(guard)\n    if _review_read is not None:\n        _check_review_read(guard, _review_read)\n    return preview',1)
s=s.replace('source_facts.binding, source_facts.proof, material, goal, _graph_read=guard)',
            'source_facts.binding, source_facts.proof, material, goal,\n            _graph_read=guard, _graph_key=prefix.key + ":review")',1)
s=s.replace('source_facts.binding, source_facts.proof, material, goal, _graph_read=guard)',
            'source_facts.binding, source_facts.proof, material, goal,\n            _graph_read=guard, _graph_key=facet.key + ":review")',1)
while '\n\n\n\n' in s: s=s.replace('\n\n\n\n','\n\n\n')
p.write_text(s)
