from pathlib import Path
import ast,difflib,hashlib,json
root=Path('/workspace/pb-cold-graph-integration-extraction-20261019')
p=root/'proposed.py'; s=p.read_text()
s=s.replace('    _checkpoint_graph(store, c, guard)\n    require(_model_inputs(value) == _model_inputs(guard.inputs[key]),',
            '    _checkpoint_graph(store, c, guard)\n    require(guard is not None and type(key) is str and key in guard.inputs,\n            "Cold extraction facts belong to a different read segment")\n    require(_model_inputs(value) == _model_inputs(guard.inputs[key]),',1)
s=s.replace('        require(type(typed) is _ColdSourceTyped and type(audit) is _ColdSourceAuditFacts)\n        prefix = typed.prefix\n        _cold_fields',
            '        require(type(typed) is _ColdSourceTyped and type(audit) is _ColdSourceAuditFacts)\n        prefix = typed.prefix\n        require(user == prefix.user == audit.prefix.user and guard is audit.prefix.guard\n                and prefix.pid == audit.prefix.pid and prefix.rid == audit.prefix.rid)\n        _cold_fields',1)
s=s.replace('        _cold_fields(store, c, guard, audit.key, audit.fields())\n        require(user == prefix.user == audit.prefix.user and guard is audit.prefix.guard\n                and prefix.pid == audit.prefix.pid and prefix.rid == audit.prefix.rid)\n        proof =',
            '        _cold_fields(store, c, guard, audit.key, audit.fields())\n        proof =',1)
a=s.index('def _cold_review_from_source('); b=s.index('\ndef _cold_verify_from_review(',a)
part=s[a:b]
part=part.replace('        _cold_fields(store, c, guard, prefix.key, prefix.fields())\n        _cold_fields(store, c, guard, source_facts.key, source_facts.fields())\n        source_prefix = source_facts.typed.prefix',
                  '        source_prefix = source_facts.typed.prefix')
part=part.replace('                and prefix.limits is source_prefix.limits and prefix.role == source_prefix.role)\n        _review_source_from_facts',
                  '                and prefix.limits is source_prefix.limits and prefix.role == source_prefix.role)\n        _cold_fields(store, c, guard, prefix.key, prefix.fields())\n        _cold_fields(store, c, guard, source_facts.key, source_facts.fields())\n        _review_source_from_facts')
s=s[:a]+part+s[b:]
s=s.replace('        require(type(prefix) is _ColdExtractionPrefix and type(review_facts) is _ColdExtractionReview)\n        _cold_fields',
            '        require(type(prefix) is _ColdExtractionPrefix and type(review_facts) is _ColdExtractionReview\n                and review_facts.prefix is prefix and user == prefix.user)\n        _cold_fields',1)
s=s.replace('        _cold_fields(store, c, guard, review_facts.key, review_facts.fields())\n        require(review_facts.prefix is prefix and user == prefix.user)\n        value =',
            '        _cold_fields(store, c, guard, review_facts.key, review_facts.fields())\n        value =',1)
a=s.index('def _cold_audit_from_source('); b=s.index('\ndef receipt(',a)
part=s[a:b]
part=part.replace('        _cold_fields(store, c, guard, prefix.key, prefix.fields())\n        _cold_fields(store, c, guard, source_facts.key, source_facts.fields())\n        require(user ==',
                  '        require(user ==')
part=part.replace('                and prefix.meta.source_run_id == source_facts.prefix.rid)\n        digest =',
                  '                and prefix.meta.source_run_id == source_facts.prefix.rid)\n        _cold_fields(store, c, guard, prefix.key, prefix.fields())\n        _cold_fields(store, c, guard, source_facts.key, source_facts.fields())\n        digest =')
s=s[:a]+part+s[b:]
p.write_text(s)
original=(root/'original.py').read_text()
tree=ast.parse(s)
original_tree=ast.parse(original)
patch=''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile='a/src/sim2act/pb_natural_specs.py',tofile='b/src/sim2act/pb_natural_specs.py'))
(root/'implementation.patch').write_text(patch)
# Compare original invariant-only leaves and the complete ordered Source audit SQL statements.
def named(tree,name): return next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
def adump(n): return ast.dump(n,include_attributes=False)
checks={}
for name in ('_source_proof_fields','_review_source_from_facts','frozen_for','receipt','_extract','source_audit','source','_source_reads','_source_reads_current','_source_transaction'):
    checks[name]=adump(named(tree,name))==adump(named(original_tree,name))
def source_queries(node):
    found=[]
    for statement in node.body:
        if isinstance(statement,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='queries' or isinstance(t,ast.Subscript) and isinstance(t.value,ast.Name) and t.value.id=='queries' for t in statement.targets):
            found.append(adump(statement))
    return found
checks['source_audit_complete_query_shapes_and_order']=source_queries(named(tree,'_source_audit_rows'))==source_queries(named(original_tree,'_source_audit'))
assert all(checks.values()),checks
report={'ast_parse':'PASS','original_sha256':hashlib.sha256(original.encode()).hexdigest(),'proposed_sha256':hashlib.sha256(s.encode()).hexdigest(),'patch_sha256':hashlib.sha256(patch.encode()).hexdigest(),'modified_module':'src/sim2act/pb_natural_specs.py','product_imports':0,'db_calls':0,'models':0,'tests':0,'unchanged_ast_checks':checks,'new_private_functions':[n.name for n in tree.body if isinstance(n,ast.FunctionDef) and n.name.startswith('_cold_')]}
(root/'static-check.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
