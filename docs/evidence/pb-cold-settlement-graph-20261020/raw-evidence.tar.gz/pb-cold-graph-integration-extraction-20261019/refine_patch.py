from pathlib import Path
p=Path('/workspace/pb-cold-graph-integration-extraction-20261019/proposed.py')
s=p.read_text()
s=s.replace('def scope_gate(store, c, user, aid, location):',
            'def scope_gate(store, c, user, aid, location, *, _graph_read=None):')
a=s.index('def scope_gate(')
b=s.index('\n\n@dataclass\nclass _SourceReads',a)
s=s[:a]+'''def scope_gate(store, c, user, aid, location, *, _graph_read=None):
    """Called by spec dispatch before full candidate or extraction ledger reads."""
    _checkpoint_graph(store, c, _graph_read)
    store.own_project(c, user, location["project_id"])
    _checkpoint_graph(store, c, _graph_read)
    store.authorize(c, user, location["runtime_id"], location["project_id"],
                    location["resource"], natural.READ)
    _checkpoint_graph(store, c, _graph_read)
    store.authorize(c, user, location["runtime_id"], location["project_id"],
                    location["project_id"], natural.SAVE)
    _checkpoint_graph(store, c, _graph_read)
    result = c.execute(select(task_extractions.c.snapshot["kind"].as_string())
                     .where(task_extractions.c.app_id == aid))
    _checkpoint_graph(store, c, _graph_read)
    kind = result.scalar()
    require(kind == KIND and location["family"] == natural.VERSION and location["task"] == KIND)
    paired = pair(c, user, aid, META, "scope", Metadata)
    _checkpoint_graph(store, c, _graph_read)
    meta, seal = paired
    require(fingerprint(meta.model_dump()) == fingerprint(seal)
            and meta.app_id == aid and meta.principal_id == user
            and meta.project_id == location["project_id"]
            and meta.runtime_id == location["runtime_id"] and meta.resource_id == location["resource"])
    source_gate(store, c, user, meta.project_id, meta.source_run_id,
                **({"_graph_read": _graph_read} if _graph_read is not None else {}))
    _checkpoint_graph(store, c, _graph_read)
    return True
''' + s[b:]
s=s.replace('scoped = spec.job_scope_gate(store, c, user, rid)',
            'scoped = spec.job_scope_gate(store, c, user, rid,\n        **({"_graph_read": _graph_read} if _graph_read is not None else {}))')
s=s.replace('scoped = spec.scope_gate(store, c, user, draft["id"])',
            'scoped = spec.scope_gate(store, c, user, draft["id"],\n        **({"_graph_read": _graph_read} if _graph_read is not None else {}))')
s=s.replace('    require(natural.is_candidate(draft["candidate"]) and "spec_task" not in draft["candidate"])\n    result = c.execute(select(internal_instance_data)',
            '    is_natural = natural.is_candidate(draft["candidate"])\n    _checkpoint_graph(store, c, _graph_read)\n    require(is_natural and "spec_task" not in draft["candidate"])\n    result = c.execute(select(internal_instance_data)')
s=s.replace('        require(type(binding) is dict and type(outputs) is dict and type(proved) is list)\n        typed, proof =',
            '        require(type(binding) is dict and type(outputs) is dict and type(proved) is list)\n        guard.add(prefix.key + ":verified", dict(binding=binding, outputs=outputs, proved=proved))\n        typed, proof =')
s=s.replace('        material, goal = targeted\n        reviewed =',
            '        material, goal = targeted\n        guard.add(prefix.key + ":target", dict(material=material, goal=goal.model_dump()))\n        reviewed =')
s=s.replace('            "confirmation", "goal_head", "goal_version"}, "Complete original native audit rows required")\n        rows =',
            '            "confirmation", "goal_head", "goal_version"}, "Complete original native audit rows required")\n        guard.add(prefix.key + ":native", original_audit_rows)\n        rows =')
s=s.replace('        _checkpoint_graph(store, c, guard)\n        return value\n    except BaseException:\n        _invalidate_graph(guard)\n        raise\n\n\ndef _audit_prefix',
            '        _checkpoint_graph(store, c, guard)\n        manifest, report, material, goal = value\n        guard.add(prefix.key + ":verified", dict(manifest=manifest.model_dump(),\n            report=report, material=material, goal=goal))\n        return value\n    except BaseException:\n        _invalidate_graph(guard)\n        raise\n\n\ndef _audit_prefix')
# Preserve scope.model_dump evaluation before the original native audit dependency.
s=s.replace('    require("spec_task" not in original["candidate"])\n    return scope, seal, original',
            '    require("spec_task" not in original["candidate"])\n    rows = dict(scope=scope.model_dump(), seal=seal)\n    return scope, seal, original, rows',1)
s=s.replace('def _source_audit_rows(store, c, user, pid, rid, scope, seal, original, original_audit,',
            'def _source_audit_rows(store, c, user, pid, rid, scope, original, rows, original_audit,')
s=s.replace('    rows = dict(scope=scope.model_dump(), seal=seal, original_audit=original_audit)',
            '    rows = dict(rows)\n    rows["original_audit"] = original_audit',1)
s=s.replace('    scope, seal, original = _source_audit_prefix(store, c, user, pid, rid)\n    original_audit',
            '    scope, seal, original, rows = _source_audit_prefix(store, c, user, pid, rid)\n    original_audit',1)
s=s.replace('        scope, seal, original, original_audit))',
            '        scope, original, rows, original_audit))',1)
s=s.replace('    original: Any\n\n    def fields(self):\n        return dict(user=self.user, pid=self.pid, rid=self.rid, scope=self.scope.model_dump(),\n                    seal=self.seal, original=dict(self.original))',
            '    original: Any\n    rows: dict\n\n    def fields(self):\n        return dict(user=self.user, pid=self.pid, rid=self.rid, scope=self.scope.model_dump(),\n                    seal=self.seal, original=dict(self.original), rows=self.rows)',1)
s=s.replace('        scope, seal, original = _source_audit_prefix(store, c, user, pid, rid, _graph_read=guard)',
            '        scope, seal, original, rows = _source_audit_prefix(store, c, user, pid, rid, _graph_read=guard)',1)
s=s.replace('                                        user, pid, rid, scope, seal, original)',
            '                                        user, pid, rid, scope, seal, original, rows)',1)
s=s.replace('            prefix.scope, prefix.seal, prefix.original, fingerprint(original_audit_rows), _graph_read=guard)',
            '            prefix.scope, prefix.original, prefix.rows, fingerprint(original_audit_rows), _graph_read=guard)',1)
# Collapse only accidental splice-added four-blank separators.
while '\n\n\n\n' in s:
    s=s.replace('\n\n\n\n','\n\n\n')
p.write_text(s)
