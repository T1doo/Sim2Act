# Current authority at every full Limits role edge

Only `_cold_binding_limits_facet` in `natural_spec_runtime.py` changes.
Patch: `runtime-role-scope.patch`. Base SHA256:
`4fa6e925bc8bfd5751b4d2d699d7d21ff778e9d6bc41d0c15db2e5aa0973bba0`.
Root remains the only repository writer; the patch has not been applied by
this agent.

## Confirmed missing edges

1. The equal-values branch returned before any current role scope/Grant check.
2. The different-values cold/source `_cold_binding_facet` calls reused complete
   queue facts and therefore skipped the actual original pre-queue job scope.
3. Extraction facet reuse skipped the original `spec.scope_gate` dispatch into
   actual `pb.scope_gate` before the Source dependency.
4. Extraction and per-use facet reviews reused the correct full target raw
   facts but did not execute their original current target runtime authorities.

## Inserted order

Both equal and different Limits first execute actual
`spec.job_scope_gate(store, c, user, cold_run_id, _graph_read=guard)` before
queue reuse/creation. Its current independent metadata, material/SAVE and parent
artifact authorities remain the original helper's responsibility.

The different-values sequence is:

1. Cold job scope -> cold queue facet -> cold Release/candidate Limits compile.
2. Actual `spec.scope_gate(extraction_app_id, _graph_read=guard)`; the original
   scalar classification dispatches to actual `pb.scope_gate`, retaining its
   metadata identity, READ/SAVE and original Source gate ordering.
3. Actual Source `spec.job_scope_gate(source_run_id, _graph_read=guard)` before
   Source queue facet -> Source Release/origin and complete new verified Source.
4. Original full `_review_source_from_facts` comparison -> extraction target
   current authorities -> shared extraction facet. The original facet repeats
   the same pure comparison; the extra original-leaf invocation is necessary to
   place fresh target authorization after the Source comparison using a
   runtime-only patch, without an arbitrary callback/hook in the review API.
5. Cold Release completion -> original per-use identity predicates -> per-use
   current target authorities -> shared per-use facet.

The equal-values shortcut executes these actual role scope/authority edges in
the same order before returning the already completed semantic graph. Since it
skips the different-values original-GA confirmation callee, it explicitly calls
actual original app `spec.scope_gate` and refreshes that confirmation target's
authorities at the corresponding Source position as well.

Every target authority refresh is the original fixed sequence:

```text
own_project(user, pid)
authorize(user, target_runtime, pid, pid, artifact.save_text)
[original complete Goal head/version/reference raw facts already proved/pinned]
own_project(user, pid)
authorize(user, target_runtime, pid, material.resource_id, resource.read)
```

The extraction runtime comes from the saved extraction draft; its material is
the complete extraction review target. The per-use runtime is the accepted
current Run runtime; its material is the complete per-use review target. Equal
semantic Source reuse uses the original frozen source draft's runtime and the
complete source binding's material. No old Grant digest/boolean supplies these
actual authorizations.

Every sensitive helper/own_project/authorize return is followed by the exact
read checkpoint before result consumption. Original metadata/identity and
Source proof comparisons stay before their later target authorities. The
existing outer BaseException cleanup remains unchanged and invalidates the
exact known guard on any failed gate. This patch does not add a grant, change
budgets/TTLs, reload target bodies or replay histories/public proof ancestors.

## Required root-owned companion fix (pending)

Current `pb_natural_uses.scope_gate` line 394 unconditionally calls:

```python
_graph_read.add("pb-use-scope:" + rid, ...full header/meta/seal...)
```

The first fresh cold job scope can pin this key; the next role's actual fresh
cold job scope reaches the same key, and the correct no-rebinding guard rejects
it. To execute repeated actual role gates, root must make this one fixed scope
collector add on its first read and compare the complete **newly reread**
header/meta/seal against the original pin on a later call, using the existing
`_scope_inputs_current` helper. It must still execute the full current gate and
actual authorities each time. Do not skip the scope, remove the pin, pass None,
or replace the guard to avoid the rejection.

Exact pending action: make this fixed full-scope reread reentrant in
`pb_natural_uses.scope_gate`. Reason: required second role otherwise fails on
`Cold graph read inputs cannot be rebound`. Status: pending integration fix;
not denied and not an uncertain execution. No such companion source edit was
made here because this delegation permits a runtime-only patch.

## Evidence

`static-check.json`: AST parse passed; only the intended existing top-level
function changed; new fixed helper bodies contain no execute/body/history/
public proof ancestor call; target authorize order is SAVE then READ.
`git apply --check` passed against the captured current base.

No repository mutation, product import/run, DB call, model call, network
operation, test, Ruff or mypy execution was performed. Root still owns apply,
runtime gates, independent review and complete integration acceptance.
