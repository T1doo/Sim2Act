from pathlib import Path
import ast,difflib,hashlib,json
root=Path('/workspace/pb-cold-graph-integration-extraction-20261019/role-scope-delta')
p=Path('/workspace/Sim2Act/src/sim2act/natural_spec_runtime.py');original=p.read_text();s=original
start=s.index('def _cold_binding_limits_facet(');end=s.index('\ndef _cold_trial_binding(',start)
old=s[start:end];new=old
needle='''        user = completed.binding['snapshot']['principal_id']
        current = completed.counter_reader.job
        if completed.binding_prefix.limits.model_dump() == limits.model_dump():'''
replacement='''        user = completed.binding['snapshot']['principal_id']
        current = completed.counter_reader.job

        def extraction_scope():
            # Original extraction verify starts with this scalar scope gate;
            # its P-B branch executes the actual pb.scope_gate, not its proof.
            scoped = spec.scope_gate(store, c, user,
                completed.extraction_prefix.draft['id'], _graph_read=guard)
            _cold_read_checkpoint(store, c, guard)
            require(scoped)

        def source_queue_scope():
            scoped = spec.job_scope_gate(store, c, user,
                completed.source_counter_reader.job['id'], _graph_read=guard)
            _cold_read_checkpoint(store, c, guard)
            require(scoped)

        def extraction_target(source_facts):
            # The original Source comparison precedes every target authority.
            # Reuse its exact leaf here before the shared facet's comparison;
            # no body, historical proof or public ancestor is reconstructed.
            prefix, review = completed.extraction_prefix, completed.extraction_review
            require(type(prefix) is pb._ColdExtractionPrefix
                and type(review) is pb._ColdExtractionReview
                and type(source_facts) is pb._ColdSourceFacts)
            pb._cold_fields(store, c, guard, prefix.key, prefix.fields())
            pb._cold_fields(store, c, guard, review.key, review.fields())
            pb._cold_fields(store, c, guard, source_facts.key, source_facts.fields())
            pb._review_source_from_facts(prefix.body.review, source_facts.proof)
            _cold_read_checkpoint(store, c, guard)
            pb._cold_fields(store, c, guard, prefix.key, prefix.fields())
            pid, runtime = prefix.draft['project_id'], prefix.draft['runtime_id']
            # spec.target: own_project -> SAVE; read_target's already proved
            # Goal metadata -> own_project -> authorized READ. Full raw target
            # bytes stay reused; each actual five-tuple remains current here.
            store.own_project(c, user, pid)
            _cold_read_checkpoint(store, c, guard)
            store.authorize(c, user, runtime, pid, pid, codec.SAVE)
            _cold_read_checkpoint(store, c, guard)
            store.own_project(c, user, pid)
            _cold_read_checkpoint(store, c, guard)
            store.authorize(c, user, runtime, pid, review.material['resource_id'], codec.READ)
            _cold_read_checkpoint(store, c, guard)
            pb._cold_fields(store, c, guard, review.key, review.fields())

        def per_use_target():
            prefix, review = completed.use_prefix, completed.use_review
            require(type(prefix) is use._ColdUseBoundPrefix
                and type(review) is use._ColdUseReviewFacts)
            prefix.check(store, c, user)
            review.check(store, c, user)
            saved = review.prefix
            # Original per-use identity predicates precede target authority.
            use._review_identity_from_facts(prefix.accepted_instance, prefix.release,
                prefix.body.review, saved.base, saved.saved, use.PB)
            _cold_read_checkpoint(store, c, guard)
            prefix.check(store, c, user)
            review.check(store, c, user)
            pid, runtime = prefix.accepted_instance['project_id'], current['runtime_id']
            store.own_project(c, user, pid)
            _cold_read_checkpoint(store, c, guard)
            store.authorize(c, user, runtime, pid, pid, codec.SAVE)
            _cold_read_checkpoint(store, c, guard)
            store.own_project(c, user, pid)
            _cold_read_checkpoint(store, c, guard)
            store.authorize(c, user, runtime, pid, saved.material['resource_id'], codec.READ)
            _cold_read_checkpoint(store, c, guard)
            prefix.check(store, c, user)
            review.check(store, c, user)

        # _cold_binding_facet supplies raw queue facts only. Preserve the
        # original current Run scope before either queue facet or fast reuse.
        scoped = spec.job_scope_gate(store, c, user, current['id'], _graph_read=guard)
        _cold_read_checkpoint(store, c, guard)
        require(scoped)
        if completed.binding_prefix.limits.model_dump() == limits.model_dump():'''
assert new.count(needle)==1;new=new.replace(needle,replacement,1)
needle='''            # This does not replace any current permission/source/Stage gate.
            _cold_read_checkpoint(store, c, guard)
            return completed'''
replacement='''            # This does not replace any current permission/source/Stage gate.
            extraction_scope()
            source_queue_scope()
            source_draft = completed.source_release.release['snapshot']['draft']
            scoped = spec.scope_gate(store, c, user, source_draft['id'], _graph_read=guard)
            _cold_read_checkpoint(store, c, guard)
            require(scoped)
            # The different-Limits path executes the original confirmation
            # target callee below. Equal semantic reuse still checks its
            # actual target five-tuples at that same role position.
            pid, runtime = source_draft['project_id'], source_draft['runtime_id']
            store.own_project(c, user, pid)
            _cold_read_checkpoint(store, c, guard)
            store.authorize(c, user, runtime, pid, pid, codec.SAVE)
            _cold_read_checkpoint(store, c, guard)
            store.own_project(c, user, pid)
            _cold_read_checkpoint(store, c, guard)
            store.authorize(c, user, runtime, pid,
                completed.source_binding['source']['resource_id'], codec.READ)
            _cold_read_checkpoint(store, c, guard)
            extraction_target(completed.source_facts)
            per_use_target()
            _cold_read_checkpoint(store, c, guard)
            return completed'''
assert new.count(needle)==1;new=new.replace(needle,replacement,1)
needle='''        cold_release, cold_candidate = lifecycle._cold_release_facet_prefix(store, c, user, completed.release, limits)
        source_queue = app_jobs._cold_binding_facet'''
replacement='''        cold_release, cold_candidate = lifecycle._cold_release_facet_prefix(store, c, user, completed.release, limits)
        extraction_scope()
        source_queue_scope()
        source_queue = app_jobs._cold_binding_facet'''
assert new.count(needle)==1;new=new.replace(needle,replacement,1)
needle='''        source_facts = pb._cold_source_facet_from_source(store, c, user, completed.source_facts, limits,
            source_binding, source_outputs, source_proved, role='cold')
        extraction, extraction_review, extraction_origin ='''
replacement='''        source_facts = pb._cold_source_facet_from_source(store, c, user, completed.source_facts, limits,
            source_binding, source_outputs, source_proved, role='cold')
        extraction_target(source_facts)
        extraction, extraction_review, extraction_origin ='''
assert new.count(needle)==1;new=new.replace(needle,replacement,1)
needle='''        app_jobs._cold_binding_release_prefix(store, c, user, cold_queue, cold_complete.release)
        use_review = use._cold_review_facet_from_review'''
replacement='''        app_jobs._cold_binding_release_prefix(store, c, user, cold_queue, cold_complete.release)
        per_use_target()
        use_review = use._cold_review_facet_from_review'''
assert new.count(needle)==1;new=new.replace(needle,replacement,1)
s=s[:start]+new+s[end:]
ast.parse(s)
(root/'base.py').write_text(original);(root/'proposed.py').write_text(s)
patch=''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile='a/src/sim2act/natural_spec_runtime.py',tofile='b/src/sim2act/natural_spec_runtime.py'))
(root/'runtime-role-scope.patch').write_text(patch)
print(json.dumps({'base_sha256':hashlib.sha256(original.encode()).hexdigest(),'proposed_sha256':hashlib.sha256(s.encode()).hexdigest(),'patch_sha256':hashlib.sha256(patch.encode()).hexdigest()},indent=2))
