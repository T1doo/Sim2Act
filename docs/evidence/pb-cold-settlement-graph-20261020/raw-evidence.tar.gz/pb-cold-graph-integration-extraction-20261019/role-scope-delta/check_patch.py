from pathlib import Path
import ast,hashlib,json
root=Path('/workspace/pb-cold-graph-integration-extraction-20261019/role-scope-delta')
a=(root/'base.py').read_text(); b=(root/'proposed.py').read_text();at=ast.parse(a);bt=ast.parse(b)
# The single affected top-level definition is the intended existing coordinator.
def top(tree):return {n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
av,bv=top(at),top(bt); changed=[n for n in av if av[n]!=bv[n]]
assert changed==['_cold_binding_limits_facet'],changed
fn=next(n for n in bt.body if isinstance(n,ast.FunctionDef) and n.name=='_cold_binding_limits_facet')
body=next(n for n in fn.body if isinstance(n,ast.Try)).body
# Nested helpers contain only current scalar scope / authority calls and exact
# existing pure leaves; no body/history/origin/target public verifier call.
nested={n.name:n for n in body if isinstance(n,ast.FunctionDef)}
assert set(nested)=={'extraction_scope','source_queue_scope','extraction_target','per_use_target'}
for name,node in nested.items():
 for call in [n for n in ast.walk(node) if isinstance(n,ast.Call)]:
  if isinstance(call.func,ast.Attribute):
   assert call.func.attr not in {'source','source_audit','review','verify','verify_job','target','load_binding','load_draft','read_release','execute'},(name,call.func.attr)
# Every inserted target uses SAVE then READ; no ad-hoc permit/cache/grant writes.
for name in ('extraction_target','per_use_target'):
 calls=[n for n in ast.walk(nested[name]) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='authorize']
 assert len(calls)==2
 assert [n.args[-1].attr for n in calls]==['SAVE','READ']
report={'ast_parse':'PASS','only_changed_top_level_definition':changed,'new_helpers_have_no_body_history_or_public_ancestor_calls':True,'target_authorize_order':['SAVE','READ'],'base_sha256':hashlib.sha256(a.encode()).hexdigest(),'proposed_sha256':hashlib.sha256(b.encode()).hexdigest(),'patch_sha256':hashlib.sha256((root/'runtime-role-scope.patch').read_bytes()).hexdigest(),'product_imports':0,'db_calls_executed':0,'models':0,'tests':0,'mypy_or_ruff_run':False,'known_dependency':'pb_natural_uses.scope_gate repeated pb-use-scope key must validate fresh full scope against first pin instead of guard.add rebinding'}
(root/'static-check.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
