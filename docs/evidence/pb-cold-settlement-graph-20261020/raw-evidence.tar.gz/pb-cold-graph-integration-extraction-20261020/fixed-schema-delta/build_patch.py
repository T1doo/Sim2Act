import ast
import difflib
import hashlib
import json
from pathlib import Path


root = Path(__file__).parent
prior = root.parent / "typed-callback-delta" / "proposed.py"
base = prior.read_text().replace(
    'raise DomainError("VERSION_CONFLICT", "Malformed persisted DeliveryGraph binding")\n',
    'raise DomainError("VERSION_CONFLICT", "Malformed persisted DeliveryGraph binding") from None\n',
)
text = base
old = '''def _persisted_extract_input(value):
    """Only the owned persisted request parser inherits verify's old mapping."""
    try:
        return ExtractInput.model_validate(value)
    except (ValidationError, KeyError, TypeError, ValueError):
        raise DomainError("VERSION_CONFLICT", "Malformed persisted DeliveryGraph binding") from None


def _cold_extract_pair(store, c, user, aid, key, guard):
    """Original fixed ExtractInput pair with IO/checkpoints outside parse mapping."""
    try:
        require(guard is not None, "Exact Cold extraction read scope required")
        from . import delivery_graph_apps as graph

        _checkpoint_graph(store, c, guard)
        rows = []
        for kind in (EXTRACT, EXTRACT + "_seal"):
            row = graph.lookup(c, user, aid, kind, key)
'''
new = '''def _persisted_pair_input(expected, value):
    """Only the three fixed owned persisted schemas inherit the old mapping."""
    from .text_workflows import RunScopeInput

    require(any(expected is kind for kind in (ExtractInput, Metadata, RunScopeInput)),
            "Fixed owned Cold persisted schema required")
    try:
        if expected is ExtractInput:
            return ExtractInput.model_validate(value)
        if expected is Metadata:
            return Metadata.model_validate(value)
        return RunScopeInput.model_validate(value)
    except (ValidationError, KeyError, TypeError, ValueError):
        raise DomainError("VERSION_CONFLICT", "Malformed persisted DeliveryGraph binding") from None


def _persisted_extract_input(value):
    # Retain the existing fixed ExtractInput parser boundary and its callers.
    return _persisted_pair_input(ExtractInput, value)


def _cold_persisted_pair(store, c, user, aid, kind, key, expected, guard):
    """Fixed existing pairs; IO/checkpoints and external callees are not mapped."""
    try:
        require(guard is not None, "Exact Cold extraction read scope required")
        from . import delivery_graph_apps as graph
        from . import pa_spec_apps as spec
        from .text_workflows import RunScopeInput

        require((expected is ExtractInput and kind == EXTRACT)
                or (expected is Metadata and kind == META and key == "scope")
                or (expected is RunScopeInput and kind == spec.RUN_META and key == "accepted"),
                "Fixed owned Cold persisted pair required")
        _checkpoint_graph(store, c, guard)
        rows = []
        for stored_kind in (kind, kind + "_seal"):
            row = graph.lookup(c, user, aid, stored_kind, key)
'''
assert text.count(old) == 1
text = text.replace(old, new)
old = '''        body = _persisted_extract_input(left["request"])
        _checkpoint_graph(store, c, guard)
        for row in rows:
            request_fingerprint = fingerprint(ExtractInput.model_dump(body))
'''
new = '''        body = (_persisted_extract_input(left["request"]) if expected is ExtractInput
                else _persisted_pair_input(expected, left["request"]))
        _checkpoint_graph(store, c, guard)
        for row in rows:
            request_fingerprint = fingerprint(expected.model_dump(body))
'''
assert text.count(old) == 1
text = text.replace(old, new)
old = '''def _verify_prefix(store, c, user, draft, *, _graph_read=None):'''
new = '''def _cold_extract_pair(store, c, user, aid, key, guard):
    return _cold_persisted_pair(store, c, user, aid, EXTRACT, key, ExtractInput, guard)


def _verify_prefix(store, c, user, draft, *, _graph_read=None):'''
assert text.count(old) == 1
text = text.replace(old, new)
old = '    paired = pair(c, user, rid, spec.RUN_META, "accepted", RunScopeInput)'
new = '''    paired = (pair(c, user, rid, spec.RUN_META, "accepted", RunScopeInput)
        if _graph_read is None else _cold_persisted_pair(store, c, user,
            rid, spec.RUN_META, "accepted", RunScopeInput, _graph_read))'''
assert text.count(old) == 2
text = text.replace(old, new)
old = '    paired = pair(c, user, aid, META, "scope", Metadata)'
new = '''    paired = (pair(c, user, aid, META, "scope", Metadata)
        if _graph_read is None else _cold_persisted_pair(store, c, user,
            aid, META, "scope", Metadata, _graph_read))'''
assert text.count(old) == 1
text = text.replace(old, new)
old = '    paired = pair(c, user, draft["id"], META, "scope", Metadata)'
new = '''    paired = (pair(c, user, draft["id"], META, "scope", Metadata)
        if _graph_read is None else _cold_persisted_pair(store, c, user,
            draft["id"], META, "scope", Metadata, _graph_read))'''
assert text.count(old) == 2
text = text.replace(old, new)
old = '    paired = pair(c, user, draft["id"], EXTRACT, marker["request_key"], ExtractInput)'
new = '''    paired = (pair(c, user, draft["id"], EXTRACT, marker["request_key"], ExtractInput)
        if _graph_read is None else _cold_extract_pair(store, c, user,
            draft["id"], marker["request_key"], _graph_read))'''
assert text.count(old) == 1
text = text.replace(old, new)

base_ast = ast.parse(base)
new_ast = ast.parse(text)
def definitions(tree):
    return {n.name: ast.dump(n, include_attributes=False) for n in tree.body
            if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
before, after = definitions(base_ast), definitions(new_ast)
changed = [name for name in before if before[name] != after[name]]
added = [name for name in after if name not in before]
assert set(changed) == {"source_gate", "_source_audit_prefix", "scope_gate",
                        "_persisted_extract_input", "_cold_extract_pair",
                        "_verify_prefix", "_audit_prefix"}, changed
assert set(added) == {"_persisted_pair_input", "_cold_persisted_pair"}, added
assert before["_cold_fields"] == after["_cold_fields"]
mapper = next(n for n in new_ast.body if isinstance(n, ast.FunctionDef)
              and n.name == "_persisted_pair_input")
mapping_try = next(n for n in mapper.body if isinstance(n, ast.Try))
calls = [ast.unparse(n.func) for n in ast.walk(ast.Module(body=mapping_try.body, type_ignores=[]))
         if isinstance(n, ast.Call)]
assert calls == ["RunScopeInput.model_validate", "ExtractInput.model_validate",
                 "Metadata.model_validate"], calls
assert len([n for n in ast.walk(mapper) if isinstance(n, ast.Try)]) == 1

(root / "base.py").write_text(base)
(root / "proposed.py").write_text(text)
patch = ''.join(difflib.unified_diff(base.splitlines(keepends=True),
                                  text.splitlines(keepends=True),
                                  fromfile="a/src/sim2act/pb_natural_specs.py",
                                  tofile="b/src/sim2act/pb_natural_specs.py"))
(root / "production.patch").write_text(patch)
tests = (root / "test_cold_persisted_schemas.py").read_text()
tests_ast = ast.parse(tests)
test_names = [n.name for n in tests_ast.body if isinstance(n, ast.FunctionDef)
              and n.name.startswith("test_")]
assert len(test_names) == 2, test_names
tests_patch = ''.join(difflib.unified_diff([], tests.splitlines(keepends=True),
                                        fromfile="/dev/null",
                                        tofile="b/tests/test_cold_persisted_schemas.py"))
(root / "tests.patch").write_text(tests_patch)
(root / "implementation.patch").write_text(patch + tests_patch)
report = dict(changed_definitions=changed, added_definitions=added,
              mapped_try_calls=calls, tests=test_names,
              typed_callback_candidate_based=True, root_from_none_retained=True,
              product_imports=0, db_runs=0, model_calls=0, test_runs=0,
              cold_fields_ast_unchanged=True)
(root / "static-check.json").write_text(json.dumps(report, indent=2) + "\n")
manifest = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(root.iterdir()) if p.is_file() and p.name != "MANIFEST.json"}
(root / "MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps(report, indent=2))
print(json.dumps(manifest, indent=2))
