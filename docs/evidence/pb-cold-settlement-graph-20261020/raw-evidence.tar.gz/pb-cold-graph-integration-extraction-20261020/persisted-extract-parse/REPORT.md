# Owned persisted ExtractInput error mapping

`implementation.patch` contains only the P-B module delta and
`tests/test_cold_extract_parse.py`. Production-only and tests-only patches are
also available. Base P-B module SHA256 is
`2bc05bc7cf017e4aa971e8e6d870f3b21516b2d7978955964d10605ca0e1bf25`.

The public old `verify@controlled` maps malformed persisted ExtractInput parse
failures to `DomainError(VERSION_CONFLICT, Malformed persisted DeliveryGraph
binding)`. The new strict prefix bypassed that broad decorator, and a consistent
pair with a missing required request field could instead leak Pydantic's
ValidationError into `advance_model` rejection ownership.

The patch changes only the strict ExtractInput branch in `_verify_prefix`.
With guard None it calls the original pair unchanged. The strict fixed
collector preserves the original two lookups, existence/seal/shape/complete
fingerprint checks, parse, and per-row request-fingerprint order. It checks the
exact read guard after every lookup and trusted callee, before consuming the
result or doing the next IO.

Only `ExtractInput.model_validate(value)` is inside the narrow error-mapping
try. The caught owned parse classes match the old controlled decorator:
ValidationError, KeyError, TypeError, ValueError. No guard check, SQL, lookup,
checked callback or fingerprint callback is inside that mapping region. The
collector's outer BaseException catches only to invalidate exact known facts
and rethrow the identical original exception. There is no graph-level
controlled decorator or general resolver/parser callback.

Two unexecuted short tests use synthetic local SQLite fixtures and forbid all
model transports:

- Persist two identical correctly fingerprinted seals with only required
  `expected_review_fingerprint` removed; compare the old public controlled
  error's complete public payload with the strict prefix's mapped error.
- After the first actual ledger lookup, make the next guard check raise one
  specific ValueError object. Assert identical propagation, inactive guard,
  zero second seal lookup and zero owned parse calls.

AST parse, the single existing changed definition, and the exact one-statement
owned parse mapping region passed static checks. `git apply --check` passed.
No repository edit, product import, DB execution, model, test, Ruff or mypy run
was performed by this agent. Runtime/test results remain root-owned.
