from pathlib import Path
import ast,difflib,hashlib,json
root=Path('/workspace/pb-cold-graph-integration-extraction-20261020/persisted-extract-parse')
p=Path('/workspace/Sim2Act/src/sim2act/pb_natural_specs.py');a=p.read_text();s=a
s=s.replace('from pydantic import Field','from pydantic import Field, ValidationError',1)
pos=s.index('\ndef _verify_prefix(')
s=s[:pos]+'''
def _persisted_extract_input(value):
    """Only the owned persisted request parser inherits verify's old mapping."""
    try:
        return ExtractInput.model_validate(value)
    except (ValidationError, KeyError, TypeError, ValueError):
        raise DomainError("VERSION_CONFLICT", "Malformed persisted DeliveryGraph binding")


def _cold_extract_pair(store, c, user, aid, key, guard):
    """Original fixed ExtractInput pair with IO/checkpoints outside parse mapping."""
    from . import delivery_graph_apps as graph

    _checkpoint_graph(store, c, guard)
    rows = []
    for kind in (EXTRACT, EXTRACT + "_seal"):
        row = graph.lookup(c, user, aid, kind, key)
        _checkpoint_graph(store, c, guard)
        rows.append(row)
    require(all(rows), "Independent text logic seals missing")
    values = []
    for row in rows:
        value = graph.checked(row)
        _checkpoint_graph(store, c, guard)
        values.append(value)
    left, right = values
    require(set(left) == {"request", "response"})
    left_fingerprint = fingerprint(left)
    _checkpoint_graph(store, c, guard)
    right_fingerprint = fingerprint(right)
    _checkpoint_graph(store, c, guard)
    require(left_fingerprint == right_fingerprint)
    # No checkpoint, SQL or external callback is enclosed by this mapper.
    body = _persisted_extract_input(left["request"])
    _checkpoint_graph(store, c, guard)
    for row in rows:
        request_fingerprint = fingerprint(ExtractInput.model_dump(body))
        _checkpoint_graph(store, c, guard)
        require(row["request_fingerprint"] == request_fingerprint)
    return body, left["response"]

''' +s[pos:]
old='''    paired = pair(c, user, draft["id"], EXTRACT, marker["request_key"], ExtractInput)
    _checkpoint_graph(store, c, _graph_read)
    body, frozen = paired'''
new='''    paired = (pair(c, user, draft["id"], EXTRACT, marker["request_key"], ExtractInput)
        if _graph_read is None else _cold_extract_pair(store, c, user,
            draft["id"], marker["request_key"], _graph_read))
    _checkpoint_graph(store, c, _graph_read)
    body, frozen = paired'''
assert s.count(old)==2
# Only verify's strict path inherits old verify@controlled parse mapping;
# do not broaden audit/default behavior or arbitrary callback handling.
s=s.replace(old,new,1)
while '\n\n\n\n' in s:s=s.replace('\n\n\n\n','\n\n\n')
ast.parse(s);(root/'base.py').write_text(a);(root/'proposed.py').write_text(s)
patch=''.join(difflib.unified_diff(a.splitlines(True),s.splitlines(True),fromfile='a/src/sim2act/pb_natural_specs.py',tofile='b/src/sim2act/pb_natural_specs.py'))
(root/'production.patch').write_text(patch)
print(json.dumps({'base_sha256':hashlib.sha256(a.encode()).hexdigest(),'proposed_sha256':hashlib.sha256(s.encode()).hexdigest(),'patch_sha256':hashlib.sha256(patch.encode()).hexdigest()},indent=2))
