# Fixed typed callback cohorts after real owned-callee gaps

Apply `implementation.patch` after the owned persisted parse candidate whose
P-B module SHA256 is `0b569d1a0ab19661ae2b5ef2b44a335b0fe7122b080d58c11befdecd4797b54c`.
It contains the production module delta and two test definitions (three cases).
Production-only and tests-only patches are also provided.

The existing `_cold_fields` complete `_model_inputs` barrier already separates
bool/int/float. Its AST and full hashing behavior are unchanged. No packet is
changed to Python equality and no new full-root hash is added.

The actual gaps were after owned callbacks, where guard.check saw only an
earlier model_dump snapshot and did not reserialize the still-live model:

1. `_cold_review_from_source` returned from `_review_source_from_facts` and
   immediately consumed ExtractInput target arguments in `spec.target` IO.
2. `_verify_from_review` returned from name SQL or compile, then continued
   consuming/exporting the still-live Goal model without comparing its new
   dump against the previous complete review pin.

The fixed `_cold_typed_checkpoint` first performs the unchanged exact global
pin, then compares only complete fixed ExtractInput/Metadata/GoalCardRunSource
JSON subtrees using `natural_live_admission._trial_typed_equal`. It permits only
those exact expected classes and plain saved dicts. Each actual dump is made
with fixed `expected.model_dump(model)`, not a subclass/instance serializer
hook. Guard/callback exceptions are invalidated and rethrown unchanged, never
mapped to a malformed-persisted error.

The Source comparison return is checked before target argument consumption/IO,
and target/review returns are checked before their results are registered. The
Limits-facet variant uses the same original full body/meta/Goal pins. Final
verification passes the fixed cohort through name SQL and compile, checking it
before the next consumer and again before the result export. The name scalar
keeps its original AND short-circuit position and all original predicates stay
in order. With guard None no model cohort is constructed or compared.

Owned strict packet fields for Source audit scope, source Limits, extraction
body/meta/Goal and review read use the same fixed exact-class serializer; their
existing full-packet barrier stays in place. Complete Limits objects and SQL
RowMapping packets are never passed to the JSON-only typed comparator.

Unexecuted synthetic callback tests cover:

- Source comparison changes expected_goal_version from integer 1 to boolean
  True; target IO must be zero and the guard inactive.
- Name SQL changes Goal.version from 1 to True; compilation must be zero.
- Compile changes Goal.version from 1 to True; no verified/export slot exists.

These are boundary units with explicit synthetic packets, not a complete Source
proof, permission, model allowance, accepted Run or P-B integration claim.
AST checks passed, `_cold_fields` remained identical, and exact patch hunk
composition was checked against the parse candidate without mutating a checkout.
No repository edit, product import, DB execution, model, test, Ruff or mypy run
was performed. Root must run the gates and independent review.
