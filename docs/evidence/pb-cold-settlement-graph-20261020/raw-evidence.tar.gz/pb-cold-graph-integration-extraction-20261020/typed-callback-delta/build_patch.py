from pathlib import Path
import ast,difflib,hashlib,json
root=Path('/workspace/pb-cold-graph-integration-extraction-20261020/typed-callback-delta')
base=Path('/workspace/pb-cold-graph-integration-extraction-20261020/persisted-extract-parse/proposed.py')
a=base.read_text();s=a
s=s.replace('from .contracts import Limits, Strict','from .contracts import GoalCardRunSource, Limits, Strict',1)
pos=s.index('\ndef source_gate(')
s=s[:pos]+'''
def _cold_model_dump(expected, model):
    """Only fixed known model serializers; no instance/subclass dump hook."""
    from .text_workflows import RunScopeInput
    allowed = (ExtractInput, ReviewInput, Metadata, GoalCardRunSource, RunScopeInput, Limits)
    require(any(expected is kind for kind in allowed) and type(model) is expected,
            "Exact owned Cold typed model required")
    if expected is ExtractInput:
        require(type(model.review) is ReviewInput and type(model.review.recipe) is natural.Recipe)
    elif expected is ReviewInput:
        require(type(model.recipe) is natural.Recipe)
    return expected.model_dump(model)


def _cold_typed_checkpoint(store, c, guard, models):
    """Check only fixed typed JSON subtrees at owned callee return boundaries."""
    try:
        _checkpoint_graph(store, c, guard)
        if guard is None:
            return
        from .natural_live_admission import _trial_typed_equal
        require(type(models) is list)
        for expected, model, raw in models:
            require(any(expected is kind for kind in (ExtractInput, Metadata, GoalCardRunSource))
                    and type(raw) is dict, "Complete owned typed subtree pin required")
            require(_trial_typed_equal(_cold_model_dump(expected, model), raw),
                    "Owned Cold typed model changed after its complete raw proof")
    except BaseException:
        _invalidate_cold_inputs(guard)
        raise

''' +s[pos:]
# The original full-packet _model_inputs barrier is deliberately untouched.
# Private fields already needing dumps now select fixed known serializers.
s=s.replace('''    def fields(self):
        return dict(user=self.user, pid=self.pid, rid=self.rid, scope=self.scope.model_dump(),''',
'''    def fields(self):
        from .text_workflows import RunScopeInput
        return dict(user=self.user, pid=self.pid, rid=self.rid, scope=_cold_model_dump(RunScopeInput, self.scope),''',1)
s=s.replace('limits=self.limits.model_dump(), job=dict(self.job))',
            'limits=_cold_model_dump(Limits, self.limits), job=dict(self.job))',1)
s=s.replace('return dict(body=self.body.model_dump(), limits=self.limits, approved=self.approved,',
            'return dict(body=_cold_model_dump(ReviewInput, self.body), limits=self.limits, approved=self.approved,',1)
s=s.replace('goal=self.goal.model_dump())','goal=_cold_model_dump(GoalCardRunSource, self.goal))',1)
s=s.replace('''return dict(user=self.user, draft=dict(self.draft), limits=self.limits.model_dump(), role=self.role,
                    marker=dict(self.marker), body=self.body.model_dump(), frozen=self.frozen, meta=self.meta.model_dump())''',
'''return dict(user=self.user, draft=dict(self.draft), limits=_cold_model_dump(Limits, self.limits), role=self.role,
                    marker=dict(self.marker), body=_cold_model_dump(ExtractInput, self.body),
                    frozen=self.frozen, meta=_cold_model_dump(Metadata, self.meta))''',1)
s=s.replace('material=self.material, goal=self.goal.model_dump())',
            'material=self.material, goal=_cold_model_dump(GoalCardRunSource, self.goal))',1)
s=s.replace('''return dict(user=self.user, draft=dict(self.draft), metadata=self.meta.model_dump(),
                    metadata_seal=self.meta_seal, marker=dict(self.marker), body=self.body.model_dump(),''',
'''return dict(user=self.user, draft=dict(self.draft), metadata=_cold_model_dump(Metadata, self.meta),
                    metadata_seal=self.meta_seal, marker=dict(self.marker), body=_cold_model_dump(ExtractInput, self.body),''',1)
# First real callback gap: old ExtractInput/meta dumps must be checked again
# before reading target args or invoking the next actual target IO.
a1=s.index('def _cold_review_from_source(');b1=s.index('\ndef _cold_verify_from_review(',a1)
chunk=s[a1:b1]
old='''        _review_source_from_facts(prefix.body.review, source_facts.proof)
        _checkpoint_graph(store, c, guard)
        targeted ='''
new='''        models = [(ExtractInput, prefix.body, guard.inputs[prefix.key]["body"]),
                  (Metadata, prefix.meta, guard.inputs[prefix.key]["meta"])]
        _review_source_from_facts(prefix.body.review, source_facts.proof)
        _cold_typed_checkpoint(store, c, guard, models)
        targeted ='''
assert chunk.count(old)==1;chunk=chunk.replace(old,new,1)
chunk=chunk.replace('''        _checkpoint_graph(store, c, guard)
        material, goal = targeted
        guard.add(prefix.key + ":target", dict(material=material, goal=goal.model_dump()))''',
'''        _cold_typed_checkpoint(store, c, guard, models)
        material, goal = targeted
        target = dict(material=material, goal=_cold_model_dump(GoalCardRunSource, goal))
        guard.add(prefix.key + ":target", target)
        models.append((GoalCardRunSource, goal, target["goal"]))''',1)
chunk=chunk.replace('''        _checkpoint_graph(store, c, guard)
        checked, material, goal = reviewed''',
'''        _cold_typed_checkpoint(store, c, guard, models)
        checked, material, goal = reviewed''',1)
s=s[:a1]+chunk+s[b1:]
# Facet variant reuses a complete old target; check it immediately after the
# same Source-comparison callback, before adding/consuming a new target view.
a1=s.index('def _cold_verify_facet_from_review(');b1=s.index('\ndef _audit_prefix(',a1)
chunk=s[a1:b1]
chunk=chunk.replace('''        _review_source_from_facts(facet.body.review, source_facts.proof)
        _checkpoint_graph(store, c, guard)''',
'''        models = [(ExtractInput, prefix.body, guard.inputs[prefix.key]["body"]),
                  (Metadata, prefix.meta, guard.inputs[prefix.key]["meta"]),
                  (GoalCardRunSource, review_facts.goal, guard.inputs[review_facts.key]["goal"])]
        _review_source_from_facts(facet.body.review, source_facts.proof)
        _cold_typed_checkpoint(store, c, guard, models)''',1)
chunk=chunk.replace('''        guard.add(facet.key + ":target", dict(material=material, goal=goal.model_dump()))''',
'''        guard.add(facet.key + ":target", dict(material=material, goal=_cold_model_dump(GoalCardRunSource, goal)))''',1)
chunk=chunk.replace('''        _checkpoint_graph(store, c, guard)
        checked, material, goal = reviewed''',
'''        _cold_typed_checkpoint(store, c, guard, models)
        checked, material, goal = reviewed''',1)
s=s[:a1]+chunk+s[b1:]
# Final verification: pass the exact inbound typed cohort through both owned
# callbacks. Guard None path still invokes its original four-argument helper.
s=s.replace('def _extraction_name(store, c, draft, guard):',
            'def _extraction_name(store, c, draft, guard, *, _typed_models=None):',1)
s=s.replace('''    _checkpoint_graph(store, c, guard)
    return result.scalar_one()


def _verify_from_review''',
'''    _cold_typed_checkpoint(store, c, guard, _typed_models)
    return result.scalar_one()


def _verify_from_review''',1)
s=s.replace('''                        checked, material, goal, *, _graph_read=None):
    _checkpoint_graph(store, c, _graph_read)''',
'''                        checked, material, goal, *, _graph_read=None, _typed_models=None):
    _cold_typed_checkpoint(store, c, _graph_read, _typed_models)''',1)
s=s.replace('''and _extraction_name(store, c, draft, _graph_read) == body.review.name''',
'''and _extraction_name(store, c, draft, _graph_read,
                **({"_typed_models": _typed_models} if _graph_read is not None else {})) == body.review.name''',1)
s=s.replace('''    compiled = natural.compile_candidate(draft["candidate"], limits)
    _checkpoint_graph(store, c, _graph_read)
    manifest, _, report = compiled
    return manifest, report, material, goal.model_dump()''',
'''    compiled = natural.compile_candidate(draft["candidate"], limits)
    _cold_typed_checkpoint(store, c, _graph_read, _typed_models)
    manifest, _, report = compiled
    return manifest, report, material, goal.model_dump()''',1)
a1=s.index('def _cold_verify_from_review(');b1=s.index('\ndef _cold_verify_facet_from_review(',a1)
chunk=s[a1:b1]
chunk=chunk.replace('''        value = _verify_from_review(store, c, user, prefix.draft, prefix.limits,''',
'''        models = [(ExtractInput, prefix.body, guard.inputs[prefix.key]["body"]),
                  (Metadata, prefix.meta, guard.inputs[prefix.key]["meta"]),
                  (GoalCardRunSource, review_facts.goal, guard.inputs[review_facts.key]["goal"])]
        value = _verify_from_review(store, c, user, prefix.draft, prefix.limits,''',1)
chunk=chunk.replace('''review_facts.checked, review_facts.material, review_facts.goal, _graph_read=guard)
        _checkpoint_graph(store, c, guard)''',
'''review_facts.checked, review_facts.material, review_facts.goal,
            _graph_read=guard, _typed_models=models)
        _cold_typed_checkpoint(store, c, guard, models)''',1)
s=s[:a1]+chunk+s[b1:]
while '\n\n\n\n' in s:s=s.replace('\n\n\n\n','\n\n\n')
ast.parse(s)
(root/'base.py').write_text(a);(root/'proposed.py').write_text(s)
patch=''.join(difflib.unified_diff(a.splitlines(True),s.splitlines(True),fromfile='a/src/sim2act/pb_natural_specs.py',tofile='b/src/sim2act/pb_natural_specs.py'))
(root/'production.patch').write_text(patch)
print(json.dumps({'base_sha256':hashlib.sha256(a.encode()).hexdigest(),'proposed_sha256':hashlib.sha256(s.encode()).hexdigest(),'patch_sha256':hashlib.sha256(patch.encode()).hexdigest()},indent=2))
