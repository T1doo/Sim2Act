"""Pure codec/DTO benchmark. No sim2act import, DB, Worker or model execution."""
import ast
import copy
import hashlib
import json
from pathlib import Path
import statistics
import sys
import time
import types

out = Path('/workspace/pb-cold-graph-integration-history-20261019')
blocked = []
def audit(event, args):
    if event in {'sqlite3.connect','socket.connect','subprocess.Popen','os.system'}:
        blocked.append(event)
        raise RuntimeError('Pure codec audit forbids ' + event)
    if event == 'import' and args and str(args[0]).split('.')[0] == 'sim2act':
        blocked.append('product import')
        raise RuntimeError('Product import forbidden')
sys.addaudithook(audit)

from pydantic import BaseModel, ConfigDict
from sqlalchemy.engine import RowMapping
from sqlalchemy.engine.result import SimpleResultMetaData
from sqlalchemy.sql.elements import quoted_name

class Limits(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)
    max_requests: int
    max_tools: int
    max_repairs: int
    max_total_tokens: int
    max_output_tokens: int
    run_seconds: int

class PureError(Exception):
    pass

def require(ok, message='pure codec check'):
    if not ok:
        raise PureError(message)

def fingerprint(value):
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,
        separators=(',',':'),allow_nan=False).encode()).hexdigest()

module = types.ModuleType('_cold_graph_codec_benchmark')
sys.modules[module.__name__] = module
module.__dict__.update(dict(Limits=Limits,require=require,DomainError=PureError,
    hashlib=hashlib, fingerprint=fingerprint))
old_source = (out/'cold-graph-codec-base.py').read_text()
old_tree=ast.parse(old_source)
old_node=next(n for n in old_tree.body if isinstance(n,ast.FunctionDef) and n.name=='_cold_graph_inputs')
old_node=copy.deepcopy(old_node)
old_node.name='_old_dag'
fragment=ast.parse((out/'cold_graph_codec_candidate.py').read_text())
new_source=(out/'cold-graph-codec-proposed.py').read_text()
validator=next(n for n in ast.parse(new_source).body if isinstance(n,ast.FunctionDef) and n.name=='_cold_graph_validate_inputs')
selected=[old_node,copy.deepcopy(validator)] + [n for n in fragment.body if isinstance(n,ast.FunctionDef)]
exec(compile(ast.fix_missing_locations(ast.Module(body=selected,type_ignores=[])),str(out/'pure-codec-fragment'), 'exec'),module.__dict__)
old=module._old_dag
encode=module._cold_graph_bytes
new=module._cold_graph_inputs
validate=module._cold_graph_validate_inputs
sample=Path('/workspace/pb-cold-graph-integration-20261019/repeat-dag-v3-90/source-database-before.json')
raw=sample.read_bytes()
snapshot=json.loads(raw)
limits=Limits(max_requests=4,max_tools=4,max_repairs=1,max_total_tokens=64000,max_output_tokens=1024,run_seconds=300)
keys=[quoted_name('id',True),'data','limits']
meta=SimpleResultMetaData(keys)
row=RowMapping(meta,None,meta._key_to_index,('native-row',snapshot['tables'],limits))
graph=dict(rows=snapshot['tables'],native_row=row,limits=limits,none_role=None,
    wire_bytes=b'full wire\x00\xff'*4096,unicode='complete UTF8: 中文 quote " & < >',
    multiset=[snapshot['tables']['attempts'],snapshot['tables']['attempts']])
for _ in range(8):
    graph=dict(first=graph,second=graph,raw=snapshot['tables'])
validate(graph)
assert old(graph)==old(graph)
native=encode(graph)
assert all(encode(graph)==native for _ in range(5))
assert row['id']=='native-row'
assert module._cold_graph_row_values(row)==tuple((key,row[key]) for key in row.keys())
durations={}
for name,func in [('old_dag',old),('new_native',new)]:
    values=[]
    for _ in range(5):
        start=time.perf_counter();func(graph);values.append(time.perf_counter()-start)
    durations[name]=dict(samples=values,median=statistics.median(values))

callback_calls=[]
class Bad:
    def __reduce__(self):
        callback_calls.append('reduce');raise AssertionError('unknown reducer called')
    def __reduce_ex__(self,*args):
        callback_calls.append('reduce_ex');raise AssertionError('unknown reducer called')
class BadDict(dict):
    def __reduce_ex__(self,*args):
        callback_calls.append('dict reduce');raise AssertionError('unknown dict reducer called')
class BadStr(str):
    def __reduce_ex__(self,*args):
        callback_calls.append('str reduce');raise AssertionError('unknown string reducer called')
negatives=[]
for label,value in [('unknown',Bad()),('dict-subclass',BadDict(a=1)),('str-subclass',BadStr('x')),
        ('foreign-function',lambda: callback_calls.append('function'))]:
    try:encode(dict(payload=value))
    except PureError:negatives.append(label)
    else:raise AssertionError('unknown object accepted: '+label)
assert callback_calls==[]
shadowed=limits.model_copy(deep=True)
shadowed.__dict__['model_dump']=lambda:callback_calls.append('serializer')
try:encode(shadowed)
except PureError:negatives.append('shadowed-Limits')
else:raise AssertionError('shadowed Limits accepted')
class BadMeta:
    @property
    def _keys(self):
        callback_calls.append('metadata getter');raise AssertionError('forged metadata called')
forged=RowMapping(BadMeta(),None,{},())
try:encode(forged)
except PureError:negatives.append('forged-row-metadata')
else:raise AssertionError('forged RowMapping accepted')
assert callback_calls==[]

cyclic=[];cyclic.append(cyclic)
try:validate(cyclic)
except PureError:negatives.append('initial-cycle')
else:raise AssertionError('initial cycle accepted')
try:validate({'x':{1,2}})
except PureError:negatives.append('initial-set')
else:raise AssertionError('initial unsupported builtin accepted')
plain={'x':[1,2], 'none':None, 'bytes':b'full'}
pinned=new(plain)
plain['x'].append(plain)
assert new(plain)!=pinned
changed=dict(source=snapshot['tables'])
prior=new(changed)
changed['new_field']={'retained':True}
assert new(changed)!=prior
assert new({'role':None})!=new({'role':limits})
assert new({'x':b'one'})!=new({'x':b'two'})
assert new({'x':[1,2]})!=new({'x':(1,2)})
assert not blocked and callback_calls==[]
proof=dict(scope='PURE_HELPER_FROZEN_JSON_AND_SYNTHETIC_DTOS_NOT_PRODUCT_OR_DB',
    sample=str(sample),sample_bytes=len(raw),sample_sha256=hashlib.sha256(raw).hexdigest(),
    encoded_bytes=len(native),encoded_sha256=hashlib.sha256(native).hexdigest(),
    timings=durations,speed_ratio=durations['old_dag']['median']/durations['new_native']['median'],
    unknown_refused=negatives,callback_calls=callback_calls,blocked_attempts=blocked,
    cycle_policy='init/add validator rejects; introduced check cycle changes pinned full bytes',
    row_type='real SQLAlchemy RowMapping constructed directly without database',
    limits_type='independent exact six-field Pydantic DTO, not product Limits',
    product_imports=False,db_calls=False,model_calls=False,
    actual_CGR_or_stage_qualification=False)
(out/'cold-codec-pure-benchmark.json').write_text(json.dumps(proof,indent=2)+'\n')
(out/'cold-codec-pure-sample.bin').write_bytes(native)
print(json.dumps(proof,indent=2))
