"""Stdlib-only local-function patch; never writes the repository."""
import ast
import difflib
import hashlib
import json
import textwrap
from pathlib import Path

out = Path('/workspace/pb-cold-graph-integration-history-20261019')
path = Path('/workspace/Sim2Act/src/sim2act/pa_spec_apps.py')
before = path.read_text()
lines = before.splitlines(keepends=True)
edits = []
for fn in ast.parse(before).body:
    if not isinstance(fn, ast.FunctionDef) or fn.name not in {'_cold_original_model_source','_native_audit_facts'}:
        continue
    value = ''.join(lines[fn.lineno-1:fn.end_lineno])
    if fn.name == '_cold_original_model_source':
        pos = value.index('    reader = _cold_generation_reader(')
        value = value[:pos] + '    try:\n' + textwrap.indent(value[pos:], '    ') + (
            '    except BaseException:\n'
            '        from .goal_applications import _GenerationFactsReader\n'
            '        if type(reader) is _GenerationFactsReader:\n'
            '            reader.invalidate()\n'
            '        raise\n')
    else:
        value = value.replace('*, _graph_read=None):', '*, _graph_read=None, _generation_reader=None):', 1)
        needle = '    checkpoint()\n    from .db import attempts, goal_card_versions, goal_cards\n'
        assert needle in value
        value = value.replace(needle,
            '    from .goal_applications import _GenerationFactsReader, _cold_generation_reader\n'
            '    if _generation_reader is not None:\n'
            '        require(type(_generation_reader) is _GenerationFactsReader\n'
            '            and _graph_read is not None and _generation_reader.guard is _graph_read\n'
            '            and _generation_reader.store is store and _generation_reader.c is c,\n'
            '            "Exact Generation audit reader required")\n'
            '        _generation_reader.check()\n' + needle, 1)
        needle = '    checkpoint()\n    contract = c.execute(select(run_contracts)'
        assert needle in value
        value = value.replace(needle,
            '    checkpoint()\n'
            '    if _generation_reader is not None:\n'
            '        _cold_generation_reader(store, c, source_run, _generation_reader)\n'
            '        require(_generation_reader.history_value is not None, "Complete Generation audit history required")\n'
            '    contract = c.execute(select(run_contracts)', 1)
        needle = '        loaded = c.execute(query).mappings().all()\n'
        assert needle in value
        value = value.replace(needle,
            '        if _generation_reader is not None and name in {"attempts", "operations"}:\n'
            '            raw_key = _generation_reader._raw_key(\n'
            '                "attempts" if name == "attempts" else "counter-operations")\n'
            '            require(_generation_reader._raw_present(raw_key), "Complete audit raw rows were not pinned")\n'
            '            loaded = sorted(\n'
            '                (copy.deepcopy(dict(r)) for r in _generation_reader._raw_get(raw_key)),\n'
            '                key=lambda r: r["id"])\n'
            '        else:\n'
            '            loaded = c.execute(query).mappings().all()\n', 1)
        # The default body keeps its SQL/error order. Only strict errors poison.
        doc_end = value.index('    def checkpoint():')
        body = value[doc_end:]
        value = value[:doc_end] + '    try:\n' + textwrap.indent(body, '    ') + (
            '    except BaseException:\n'
            '        from .goal_applications import _GenerationFactsReader\n'
            '        from .natural_spec_runtime import _ColdGraphRead\n'
            '        if type(_generation_reader) is _GenerationFactsReader:\n'
            '            _generation_reader.invalidate()\n'
            '        if type(_graph_read) is _ColdGraphRead:\n'
            '            _graph_read.invalidate()\n'
            '        raise\n')
    edits.append((fn.lineno-1, fn.end_lineno, value))
assert len(edits) == 2
for a,b,value in reversed(edits):
    lines[a:b] = [value]
after = ''.join(lines)
ast.parse(after)
old_ast, new_ast = ast.parse(before), ast.parse(after)
allowed = {'_native_audit_facts','_cold_original_model_source'}
def unrelated(tree):
    return [ast.dump(n, include_attributes=False) for n in tree.body
        if not (isinstance(n,ast.FunctionDef) and n.name in allowed)]
assert unrelated(old_ast) == unrelated(new_ast)
(out/'generation-audit-v2-base.py').write_text(before)
(out/'generation-audit-memo-proposed.py').write_text(after)
diff = ''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),
    fromfile='a/src/sim2act/pa_spec_apps.py',tofile='b/src/sim2act/pa_spec_apps.py'))
(out/'generation-native-audit-memo.patch').write_text(diff)
combined = (out/'generation-reader-memo.patch').read_text() + diff
(out/'generation-facts-v2-delta.patch').write_text(combined)
(out/'generation-audit-memo-static.json').write_text(json.dumps(dict(
    kind='STDLIB_AST_ONLY_NOT_PRODUCT_EXECUTION', before_sha256=hashlib.sha256(before.encode()).hexdigest(),
    after_sha256=hashlib.sha256(after.encode()).hexdigest(),
    ast_other_top_level_nodes_equal=True, functions=sorted(allowed), tests_run=False,
    combined_patch_sha256=hashlib.sha256(combined.encode()).hexdigest(),combined_patch_bytes=len(combined.encode())),indent=2)+'\n')
print(json.dumps(dict(patch=str(out/'generation-facts-v2-delta.patch'),bytes=len(combined.encode()),sha256=hashlib.sha256(combined.encode()).hexdigest())))
