"""Generate an external patch only; do not import or execute product/tests."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

root = Path('/workspace/Sim2Act')
out = Path('/workspace/pb-cold-graph-integration-history-20261019')
source_path = Path('src/sim2act/natural_spec_runtime.py')
test_path = Path('tests/test_cold_graph_fingerprint.py')
source = (root / source_path).read_text()
tests = (root / test_path).read_text()
old = '''    require(type(keys) is list and all(type(key) is str or type(key) is quoted_name for key in keys)
        and all(type(index.get(key)) is int and 0 <= index[key] < len(data) for key in keys),
        "Complete Cold graph SQL row keys required")
    # The exact C row/metadata storage is read directly, avoiding arbitrary
    # Mapping.items/__iter__/__getitem__ callbacks in a forged wrapper.
    return tuple((key, data[index[key]]) for key in keys)
'''
new = '''    require(type(keys) is list and all(type(key) is str or type(key) is quoted_name for key in keys),
        "Complete Cold graph SQL row keys required")
    # SQLAlchemy also indexes by Column objects. Never hash/compare an unknown
    # index key: a forged colliding key could run __eq__ during index.get().
    # Iterating an exact dict is safe; lookup only in our exact-string copy.
    lookup = {}
    for key, position in dict.items(index):
        if type(key) is str or type(key) is quoted_name:
            lookup[str(key)] = position
    require(all(type(lookup.get(str(key))) is int
        and 0 <= lookup[str(key)] < len(data) for key in keys),
        "Complete Cold graph SQL row keys required")
    # The exact C row/metadata storage is read directly, avoiding arbitrary
    # Mapping.items/__iter__/__getitem__ callbacks in a forged wrapper.
    return tuple((key, data[lookup[str(key)]]) for key in keys)
'''
assert source.count(old) == 1
changed_source = source.replace(old, new)
needle = '@pytest.mark.parametrize("mutation", ["cycle", "unsupported_builtin"])\n'
addition = '''def test_actual_row_index_collision_never_dispatches_foreign_hash_or_equality():
    from sqlalchemy.engine.result import SimpleResultMetaData

    calls = []

    class CollidingKey:
        def __hash__(self):
            calls.append("hash")
            return hash("id")

        def __eq__(self, other):
            calls.append("eq")
            raise AssertionError("Native row index must not compare a foreign key")

    # Native metadata and RowMapping, but a deliberately forged index key. Its
    # construction hashes once; neither codec may hash or compare it again.
    index = {CollidingKey(): 0}
    forged = RowMapping(SimpleResultMetaData(["id"]), None, index, ("complete-id",))
    assert calls == ["hash"]
    calls.clear()
    with pytest.raises(DomainError):
        runtime._cold_graph_bytes(forged)
    with pytest.raises(DomainError):
        runtime._cold_graph_validate_inputs(forged)
    assert calls == []


@pytest.mark.parametrize("mutation", ["cycle", "unsupported_builtin",
    "add_direct_backedge", "add_nested_backedge"])
'''
assert tests.count(needle) == 1
changed_tests = tests.replace(needle, addition).replace(
    'Two exact local CGR scope checks use synthetic SQLite/Worker identity pins.',
    'Exact local CGR scope checks use synthetic SQLite/Worker identity pins.')
old_tail = '''                if mutation == "cycle":
                    payload["changed"] = payload
                else:
                    payload["changed"] = {1, 2}
                with pytest.raises(DomainError):
                    guard.check(store, c)
                assert not guard.active
                del payload["changed"]
                with pytest.raises(DomainError):
                    guard.check(store, c)
'''
new_tail = '''                if mutation in ("add_direct_backedge", "add_nested_backedge"):
                    incoming = guard.inputs if mutation == "add_direct_backedge" else dict(edge=guard.inputs)
                    # Incoming alone is acyclic. Insertion creates the back-edge,
                    # so add must validate the complete post-insertion graph.
                    with pytest.raises(DomainError):
                        guard.add("backedge", incoming)
                    assert not guard.active
                    guard.inputs.pop("backedge", None)
                else:
                    if mutation == "cycle":
                        payload["changed"] = payload
                    else:
                        payload["changed"] = {1, 2}
                    with pytest.raises(DomainError):
                        guard.check(store, c)
                    assert not guard.active
                    del payload["changed"]
                # Even after removing the bad value, this scope stays poisoned.
                with pytest.raises(DomainError):
                    guard.check(store, c)
'''
assert changed_tests.count(old_tail) == 1
changed_tests = changed_tests.replace(old_tail, new_tail)

ast.parse(changed_source)
ast.parse(changed_tests)
# Static scope proof: no accidental changes outside the one helper and tests.
def funcs(value):
    tree = ast.parse(value)
    return {node.name: ast.dump(node, include_attributes=False) for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))}
a, b = funcs(source), funcs(changed_source)
changed_top = sorted(name for name in a.keys() | b.keys() if a.get(name) != b.get(name))
assert changed_top == ['_cold_graph_row_values'], changed_top
patch = ''.join(difflib.unified_diff(source.splitlines(True), changed_source.splitlines(True),
    fromfile='a/' + str(source_path), tofile='b/' + str(source_path)))
patch += ''.join(difflib.unified_diff(tests.splitlines(True), changed_tests.splitlines(True),
    fromfile='a/' + str(test_path), tofile='b/' + str(test_path)))
patch_path = out / 'cold-codec-collision-backedge.patch'
patch_path.write_text(patch)
verification = dict(kind='STATIC_EXTERNAL_PATCH_ONLY', product_or_test_execution=False,
    repository_modified=False, source_changed_top_level=changed_top,
    inputs={str(source_path): hashlib.sha256(source.encode()).hexdigest(),
        str(test_path): hashlib.sha256(tests.encode()).hexdigest()},
    patch=dict(path=str(patch_path), bytes=len(patch.encode()), sha256=hashlib.sha256(patch.encode()).hexdigest()),
    test_additions=['actual RowMapping with colliding unknown native index key: zero callbacks',
        'exact CGR direct add backedge: reject and sticky poison',
        'exact CGR nested add backedge: reject and sticky poison'],
    checks=['ast.parse source and tests', 'only product helper AST changed',
        'parent post-insertion full validation preserved unchanged'])
(out / 'cold-codec-collision-backedge-static.json').write_text(json.dumps(verification, indent=2) + '\n')
print(json.dumps(verification, indent=2))
