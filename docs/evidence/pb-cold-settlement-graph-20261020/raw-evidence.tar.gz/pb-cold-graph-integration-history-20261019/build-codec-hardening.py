import ast
import difflib
import hashlib
import json
from pathlib import Path

out=Path('/workspace/pb-cold-graph-integration-history-20261019')
p=Path('/workspace/Sim2Act/src/sim2act/natural_spec_runtime.py')
before=p.read_text()
tree=ast.parse(before)
lines=before.splitlines(keepends=True)
edits=[]
allowed={'_cold_graph_validate_inputs','_cold_graph_limit_values','_cold_graph_row_values'}
for n in tree.body:
    if not isinstance(n,ast.FunctionDef) or n.name not in allowed:continue
    body=''.join(lines[n.lineno-1:n.end_lineno])
    if n.name=='_cold_graph_validate_inputs':
        body=body.replace('if kind in (str, int, float, bool, type(None)):',
            'if any(kind is allowed for allowed in (str, int, float, bool, type(None))):',1)
        body=body.replace('require(kind in (dict, RowMapping, list, tuple, Limits, bytes),',
            'require(any(kind is allowed for allowed in (dict, RowMapping, list, tuple, Limits, bytes)),',1)
        body=body.replace('elif kind in (dict, RowMapping):\n            keys = list(value.keys())\n'
            '            require(all(type(key) in (str, quoted_name) for key in keys), "Cold graph keys changed")\n'
            '            body = [\'mapping\', [[str(key), visit(value[key])] for key in sorted(keys, key=str)]]',
            'elif kind is dict or kind is RowMapping:\n'
            '            mapping = value if kind is dict else dict(_cold_graph_row_values(value))\n'
            '            keys = list(mapping.keys())\n'
            '            require(all(type(key) is str or type(key) is quoted_name for key in keys), "Cold graph keys changed")\n'
            '            body = [\'mapping\', [[str(key), visit(mapping[key])] for key in sorted(keys, key=str)]]',1)
        assert 'kind in (' not in body and 'type(key) in (' not in body
    elif n.name=='_cold_graph_limit_values':
        body=body.replace('type(raw) is dict and set(raw) == set(names)',
            'type(raw) is dict and all(type(key) is str for key in raw) and set(raw) == set(names)',1)
    else:
        body=body.replace('type(parent) in (CursorResultMetaData, SimpleResultMetaData)',
            '(type(parent) is CursorResultMetaData or type(parent) is SimpleResultMetaData)',1)
        body=body.replace('type(key) in (str, quoted_name)', 'type(key) is str or type(key) is quoted_name',1)
    edits.append((n.lineno-1,n.end_lineno,body))
assert len(edits)==3
for a,b,body in reversed(edits):lines[a:b]=[body]
after=''.join(lines)
new=ast.parse(after)
def rest(t):return [ast.dump(n,include_attributes=False) for n in t.body
    if not(isinstance(n,ast.FunctionDef) and n.name in allowed)]
assert rest(tree)==rest(new)
diff=''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),
    fromfile='a/src/sim2act/natural_spec_runtime.py',tofile='b/src/sim2act/natural_spec_runtime.py'))
(out/'cold-codec-hardening-base.py').write_text(before)
(out/'cold-codec-hardening-proposed.py').write_text(after)
(out/'cold-codec-hardening.patch').write_text(diff)
proof=dict(scope='EXTERNAL_AST_ONLY_NO_PRODUCT',source_before=hashlib.sha256(before.encode()).hexdigest(),
    source_after=hashlib.sha256(after.encode()).hexdigest(),patch_sha256=hashlib.sha256(diff.encode()).hexdigest(),
    patch_bytes=len(diff.encode()),outside_three_private_functions_ast_equal=True)
(out/'cold-codec-hardening-static.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof))
