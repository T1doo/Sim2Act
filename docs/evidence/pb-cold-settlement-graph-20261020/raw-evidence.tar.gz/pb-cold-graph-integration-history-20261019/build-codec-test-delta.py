"""Stdlib-only test patch builder. Repository/tests are never executed here."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

out=Path('/workspace/pb-cold-graph-integration-history-20261019')
path=Path('/workspace/Sim2Act/tests/test_cold_graph_fingerprint.py')
before=path.read_text()
after=before.replace('import gc\n','import hashlib\nimport threading\nimport time\n',1)
after=after.replace('from sqlalchemy.sql.elements import quoted_name\n',
    'from sqlalchemy.sql.elements import quoted_name\n'
    'from test_natural_spec_apps import recipe\n'
    'from test_pb_live_source_contract import material\n',1)
after=after.replace('from sim2act import natural_spec_runtime as runtime\n',
    'from sim2act import natural_live_admission as admission\n'
    'from sim2act import natural_spec_runtime as runtime\n'
    'from sim2act import pb_natural_specs as pb\n',1)
after=after.replace('from sim2act.db import runs\n', 'from sim2act.db import new_id, runs\n',1)
after=after.replace('from sim2act.errors import DomainError\n',
    'from sim2act.errors import DomainError\n'
    'from sim2act.production_trial_admission import canonical_quota_subject\n'
    'from sim2act.spec_production import ProductionTrialBinding\n'
    'from sim2act.worker import Worker\n',1)
after=after.replace('No Store/Worker/authority, graph producer or semantic P-B acceptance.\n',
    'No model/claim/authority, graph producer or semantic P-B acceptance.\n'
    'Two exact local CGR scope checks use synthetic SQLite/Worker identity pins.\n',1)
replacements={
'test_memo_is_per_call_and_complete_limits_dump_is_shared_only_within_call': '''def test_native_memo_per_call_reads_exact_limits_without_instance_serializer(monkeypatch):
    calls = []

    def forbidden(*args, **kwargs):
        calls.append("model_dump")
        raise AssertionError("Native codec must read exact Limits fields directly")

    full = limits()
    monkeypatch.setattr(Limits, "model_dump", forbidden)
    value = dict(first=full, second=[full, dict(third=full)])
    first = runtime._cold_graph_inputs(value)
    encoded = runtime._cold_graph_bytes(value)
    assert hashlib.sha256(encoded).hexdigest() == first
    assert runtime._cold_graph_inputs(value) == first
    assert runtime._cold_graph_bytes(value) == encoded
    full.max_output_tokens -= 1
    assert runtime._cold_graph_inputs(value) != first
    assert calls == []
''',
'test_key_order_does_not_change_complete_alias_graph': '''def test_key_order_is_a_stricter_local_pin_with_complete_alias_graph():
    shared = dict(z=[1, 2], a=dict(full=b"bytes"))
    left = dict(z=shared, a=dict(z=shared, a=limits()))
    right = dict(a=dict(a=left["a"]["a"], z=shared), z=shared)
    assert runtime._model_inputs(left) == runtime._model_inputs(right)
    assert runtime._cold_graph_inputs(left) != runtime._cold_graph_inputs(right)
''',
'test_expanded_temporary_dicts_remain_alive_until_final_hash': '''def test_unknown_reducers_and_shadowed_limits_never_dispatch():
    calls = []

    class Foreign:
        def __reduce__(self):
            calls.append("reduce")
            raise AssertionError("Unknown reducer must never execute")

        def __reduce_ex__(self, protocol):
            calls.append("reduce_ex")
            raise AssertionError("Unknown reducer must never execute")

    class ForeignDict(dict):
        def __reduce_ex__(self, protocol):
            calls.append("dict-reduce")
            raise AssertionError("Unknown dict reducer must never execute")

    class ForeignStr(str):
        def __reduce_ex__(self, protocol):
            calls.append("str-reduce")
            raise AssertionError("Unknown str reducer must never execute")

    class HostileMeta(type):
        def __eq__(cls, other):
            calls.append("metaclass-equality")
            raise AssertionError("Type gates must use identity")

    class ForeignType(metaclass=HostileMeta):
        pass

    def callback(*args, **kwargs):
        calls.append("callable")
        raise AssertionError("Foreign callable must never execute")

    shadowed = limits().model_copy(update={"model_dump": callback})
    for value in (Foreign(), ForeignDict(x=1), ForeignStr("x"), callback, shadowed, ForeignType()):
        with pytest.raises(DomainError):
            runtime._cold_graph_bytes(dict(value=value))
        with pytest.raises(DomainError):
            runtime._cold_graph_validate_inputs(dict(value=value))
    assert calls == []
''',
}
tree=ast.parse(after)
lines=after.splitlines(keepends=True)
edits=[]
for node in tree.body:
    if isinstance(node,ast.FunctionDef) and node.name in replacements:
        edits.append((node.lineno-1,node.end_lineno,replacements[node.name]))
assert len(edits)==3
for a,b,text in reversed(edits):lines[a:b]=[text]
after=''.join(lines)
after=after.replace('        runtime._cold_graph_inputs(value)\n\n\ndef test_custom_mapping',
    '        runtime._cold_graph_validate_inputs(value)\n\n\ndef test_custom_mapping',1)
after=after.replace('        runtime._cold_graph_inputs(dict(value=value))\n\n\ndef test_unknown_reducers',
    '        runtime._cold_graph_validate_inputs(dict(value=value))\n\n\ndef test_unknown_reducers',1)
needle='''            assert runtime._cold_graph_inputs(complete) == expected
            assert runtime._cold_graph_inputs(plain) == expected
'''
assert needle in after
after=after.replace(needle,'''            assert runtime._cold_graph_inputs(row) == expected
            runtime._cold_graph_validate_inputs(row)
            complete_key = runtime._cold_graph_inputs(complete)
            assert complete_key != expected  # Exact SQL row marker is a stricter pin.
            assert runtime._cold_graph_inputs(plain) != expected
''',1)
after=after.replace('assert runtime._cold_graph_inputs(changed) != expected\n',
    'assert runtime._cold_graph_inputs(changed) != complete_key\n',1)
after=after.replace('    import hashlib\n    projected =', '    projected =',1)
# Keep a forged native row isolated from an actual query/Store. Its getter must
# remain uncalled in both initial validation and every native encoder check.
after += '''

def test_forged_native_row_metadata_cannot_run_key_callback():
    calls = []

    class ForeignMeta:
        @property
        def _keys(self):
            calls.append("keys")
            raise AssertionError("Forged native row metadata getter must not execute")

    forged = RowMapping(ForeignMeta(), None, {}, ())
    with pytest.raises(DomainError):
        runtime._cold_graph_bytes(forged)
    with pytest.raises(DomainError):
        runtime._cold_graph_validate_inputs(forged)
    assert calls == []


@pytest.mark.parametrize("mutation", ["cycle", "unsupported_builtin"])
def test_exact_cgr_check_poison_on_new_cycle_or_builtin(env, mutation):
    store, settings, _, user, _, pid, _ = env
    assert store.sqlite
    trial = admission.PBTrialContract(trial_key="synthetic-codec-pin", project_id=pid,
        principal_id=user, runtime_id=new_id("runtime"),
        quota_subject=canonical_quota_subject("synthetic-codec-account"),
        software_fingerprint="b" * 64, authorization_fingerprint="c" * 64,
        bindings=[material(1), material(2)], stage_keys=dict(generate="g", source="s", cold="c"),
        expires_at=time.time() + 300, path="P-B", extraction_request_key="x",
        extraction_recipe=recipe("ordered"))
    binding = ProductionTrialBinding(trial, "synthetic-unapproved-pin", "synthetic-codec-account")
    worker = object.__new__(Worker)
    worker.store, worker.s, worker.pa_trial = store, settings, binding
    worker.id, worker.stop, worker.goal_planner_transport = "synthetic-codec-reader", threading.Event(), None
    worker._journal_trial_store, worker._journal_trial_binding = store, binding
    worker._journal_trial_drift = False
    full = limits()
    payload = dict(original=[1, 2])
    with store.tx() as c, pb._source_reads(store, c):
        with pytest.raises(DomainError):
            with runtime._cold_graph_read(worker, c, dict(payload=payload),
                    dict(source=full, generate=None, platform=full, trial=full, per_use=None), "pre") as guard:
                original_bytes = guard.input_bytes()
                assert hashlib.sha256(original_bytes).hexdigest() == guard.key
                assert guard.input_bytes() == original_bytes
                if mutation == "cycle":
                    payload["changed"] = payload
                else:
                    payload["changed"] = {1, 2}
                with pytest.raises(DomainError):
                    guard.check(store, c)
                assert not guard.active
                del payload["changed"]
                with pytest.raises(DomainError):
                    guard.check(store, c)
'''
ast.parse(after)
patch=''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),
    fromfile='a/tests/test_cold_graph_fingerprint.py',tofile='b/tests/test_cold_graph_fingerprint.py'))
(out/'cold-codec-tests-base.py').write_text(before)
(out/'cold-codec-tests-proposed.py').write_text(after)
(out/'cold-codec-tests.patch').write_text(patch)
proof=dict(kind='EXTERNAL_AST_ONLY_TESTS_NOT_RUN',source_before=hashlib.sha256(before.encode()).hexdigest(),
    source_after=hashlib.sha256(after.encode()).hexdigest(),patch_sha256=hashlib.sha256(patch.encode()).hexdigest(),
    patch_bytes=len(patch.encode()),original_9_field_and_30_limits_parameters_unchanged=True,
    scope='native local strict identity/insertion, no dump callback; init validator cycles/nonfinite; exact CGR late builtin/cycle sticky')
(out/'cold-codec-tests-static.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof))
