"""External-only AST/diff builder. Never imports product or executes its tests."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

repo = Path('/workspace/Sim2Act')
out = Path('/workspace/pb-cold-graph-integration-history-20261019')
source_path = Path('src/sim2act/natural_spec_runtime.py')
test_path = Path('tests/test_cold_graph_fingerprint.py')
source = (repo / source_path).read_text()
tests = (repo / test_path).read_text()

old = 'def _cold_graph_validate_inputs(values):\n'
new = 'def _cold_graph_validate_inputs(values, *, _forbid_root=None):\n'
assert source.count(old) == 1
changed = source.replace(old, new)
old = '''    from sqlalchemy.engine import RowMapping
    from sqlalchemy.sql.elements import quoted_name

    memo: dict[int, tuple[Any, int]] = {}
'''
new = '''    from sqlalchemy.engine import RowMapping
    from sqlalchemy.sql.elements import quoted_name

    require(_forbid_root is None or type(_forbid_root) is dict,
        "Cold graph forbidden root must be an exact input dict")
    memo: dict[int, tuple[Any, int]] = {}
'''
assert changed.count(old) == 1
changed = changed.replace(old, new)
old = '''    def visit(value):
        kind = type(value)
'''
new = '''    def visit(value):
        # Before memo reuse: an incoming edge to the actual inputs root would
        # close a cycle when add installs the root -> incoming edge.
        if _forbid_root is not None:
            require(value is not _forbid_root, "Incoming Cold graph reaches its input root")
        kind = type(value)
'''
assert changed.count(old) == 1
changed = changed.replace(old, new)
old = '''            _cold_graph_validate_inputs(value)
            self.inputs[name] = value
            # Insertion can create a back-edge to this existing input graph.
            # Validate the complete resulting graph before installing a new pin.
            self.key = self.input_key(_validate=True)
'''
new = '''            # Existing full bytes were checked above. Only this new edge can
            # form a new cycle: validate all incoming values and reject any
            # direct/nested path to the actual root before inserting it.
            _cold_graph_validate_inputs(value, _forbid_root=self.inputs)
            self.inputs[name] = value
            # Re-pin complete current bytes, retaining every field and alias.
            self.key = self.input_key()
'''
assert changed.count(old) == 1
changed = changed.replace(old, new)

needle = '''@pytest.mark.parametrize("mutation", ["cycle", "unsupported_builtin",
    "add_direct_backedge", "add_nested_backedge"])
def test_exact_cgr_check_poison_on_new_cycle_or_builtin(env, mutation):
'''
replacement = '''@pytest.mark.parametrize("path", ["direct", "dict", "list", "tuple", "row"])
def test_incoming_validator_forbids_actual_root_by_identity_on_every_value_path(path):
    from sqlalchemy.engine.result import SimpleResultMetaData

    root = dict(existing=dict(full=b"complete", limits=limits()))
    if path == "direct":
        incoming = root
    elif path == "dict":
        incoming = dict(edge=root)
    elif path == "list":
        incoming = [root]
    elif path == "tuple":
        incoming = (root,)
    else:
        incoming = RowMapping(SimpleResultMetaData(["edge"]), None, {"edge": 0}, (root,))
    # Before insertion each input is an ordinary acyclic graph.
    runtime._cold_graph_validate_inputs(incoming)
    with pytest.raises(DomainError):
        runtime._cold_graph_validate_inputs(incoming, _forbid_root=root)
    # Equal content in another object does not create a root back-edge.
    runtime._cold_graph_validate_inputs(dict(edge=copy.deepcopy(root)), _forbid_root=root)


@pytest.mark.parametrize("mutation", ["cycle", "unsupported_builtin",
    "add_direct_backedge", "add_nested_backedge", "add_row_backedge", "add_shared_dag"])
def test_exact_cgr_check_poison_on_new_cycle_or_builtin(env, mutation, monkeypatch):
'''
assert tests.count(needle) == 1
changed_tests = tests.replace(needle, replacement)
old = '''                if mutation in ("add_direct_backedge", "add_nested_backedge"):
                    incoming = guard.inputs if mutation == "add_direct_backedge" else dict(edge=guard.inputs)
                    # Incoming alone is acyclic. Insertion creates the back-edge,
                    # so add must validate the complete post-insertion graph.
                    with pytest.raises(DomainError):
                        guard.add("backedge", incoming)
                    assert not guard.active
                    guard.inputs.pop("backedge", None)
                else:
'''
new = '''                if mutation in ("add_direct_backedge", "add_nested_backedge", "add_row_backedge"):
                    from sqlalchemy.engine.result import SimpleResultMetaData

                    if mutation == "add_direct_backedge":
                        incoming = guard.inputs
                    elif mutation == "add_nested_backedge":
                        incoming = dict(edge=guard.inputs)
                    else:
                        incoming = RowMapping(SimpleResultMetaData(["edge"]), None,
                            {"edge": 0}, (guard.inputs,))
                    # Acyclic alone, but the new root -> incoming edge would
                    # create a cycle. Reject it before mutating the inputs.
                    runtime._cold_graph_validate_inputs(incoming)
                    with pytest.raises(DomainError):
                        guard.add("backedge", incoming)
                    assert not guard.active and "backedge" not in guard.inputs
                elif mutation == "add_shared_dag":
                    fresh = limits()
                    shared = dict(original=payload["original"], full=fresh, absent=None)
                    incoming = dict(left=shared, right=shared)
                    calls = []
                    original_validate = runtime._cold_graph_validate_inputs

                    def observe(value, *, _forbid_root=None):
                        calls.append((value, _forbid_root))
                        return original_validate(value, _forbid_root=_forbid_root)

                    with monkeypatch.context() as patch:
                        patch.setattr(runtime, "_cold_graph_validate_inputs", observe)
                        guard.add("shared", incoming)
                    assert len(calls) == 1
                    assert calls[0][0] is incoming and calls[0][1] is guard.inputs
                    assert guard.active and guard.input_key() == guard.key
                    assert guard.inputs["shared"]["left"] is guard.inputs["shared"]["right"]
                    assert shared["original"] is payload["original"]
                    # Complete bytes still cover newly accepted full Limits.
                    fresh.max_output_tokens -= 1
                    with pytest.raises(DomainError):
                        guard.check(store, c)
                    assert not guard.active
                    fresh.max_output_tokens += 1
                else:
'''
assert changed_tests.count(old) == 1
changed_tests = changed_tests.replace(old, new)

old_tree, new_tree = ast.parse(source), ast.parse(changed)
ast.parse(changed_tests)
def top(tree):
    return {node.name: node for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))}
a, b = top(old_tree), top(new_tree)
changed_top = sorted(name for name in a.keys() | b.keys()
    if ast.dump(a.get(name), include_attributes=False) != ast.dump(b.get(name), include_attributes=False))
assert changed_top == ['_ColdGraphRead', '_cold_graph_validate_inputs'], changed_top
old_class, new_class = a['_ColdGraphRead'], b['_ColdGraphRead']
old_methods = {node.name: ast.dump(node, include_attributes=False) for node in old_class.body
    if isinstance(node, ast.FunctionDef)}
new_methods = {node.name: ast.dump(node, include_attributes=False) for node in new_class.body
    if isinstance(node, ast.FunctionDef)}
assert sorted(name for name in old_methods if old_methods[name] != new_methods[name]) == ['add']
# All original private/public ModelRead, byte codec and check bodies remain exact.
for name in ('_model_value', '_model_inputs', '_cold_graph_bytes', '_cold_graph_row_values',
        '_cold_graph_limit_values', '_cold_graph_inputs'):
    assert ast.dump(a[name], include_attributes=False) == ast.dump(b[name], include_attributes=False)
assert old_methods['check'] == new_methods['check']
assert old_methods['input_bytes'] == new_methods['input_bytes']
assert old_methods['input_key'] == new_methods['input_key']
patch = ''.join(difflib.unified_diff(source.splitlines(True), changed.splitlines(True),
    fromfile='a/' + str(source_path), tofile='b/' + str(source_path)))
patch += ''.join(difflib.unified_diff(tests.splitlines(True), changed_tests.splitlines(True),
    fromfile='a/' + str(test_path), tofile='b/' + str(test_path)))
patch_path = out / 'cold-add-forbidden-root.patch'
patch_path.write_text(patch)
verification = dict(kind='EXTERNAL_STATIC_CANDIDATE_ONLY', repository_modified=False,
    product_or_test_execution=False, changed_product_functions=['_cold_graph_validate_inputs', '_ColdGraphRead.add'],
    unchanged_complete_checks=['_ColdGraphRead.check', '_ColdGraphRead.input_bytes',
        '_ColdGraphRead.input_key', '_cold_graph_bytes', '_cold_graph_row_values',
        '_cold_graph_limit_values', '_model_value', '_model_inputs'],
    inputs={str(source_path): hashlib.sha256(source.encode()).hexdigest(),
        str(test_path): hashlib.sha256(tests.encode()).hexdigest()},
    patch=dict(path=str(patch_path), bytes=len(patch.encode()), sha256=hashlib.sha256(patch.encode()).hexdigest()),
    tests=dict(existing_collision_and_unknown_callback_tests_retained=True,
        forbidden_root_paths=['direct', 'dict', 'list', 'tuple', 'actual native RowMapping'],
        actual_guard_add_cases=['direct backedge', 'nested backedge', 'RowMapping backedge',
            'valid shared DAG with exactly one incoming-only validator call and full-byte mutation detection']),
    checks=['AST parse source/tests', 'product change limited to validator/add',
        'original complete check/codec/6-field Limits/RowMapping/ModelRead AST identical'],
    limitations=['No product/test/DB execution', 'No performance qualification',
        'Candidate requires sole writer review/application and actual tests'])
(out / 'cold-add-forbidden-root-static.json').write_text(json.dumps(verification, indent=2) + '\n')
print(json.dumps(verification, indent=2))
