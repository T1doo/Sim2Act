"""Stdlib AST patch builder only; no product imports, DB or test execution."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

out = Path('/workspace/pb-cold-graph-integration-history-20261019')
path = Path('/workspace/Sim2Act/src/sim2act/natural_spec_runtime.py')
before = path.read_text()
start = before.index('def _cold_graph_inputs(values):')
end = before.index('\n\nclass _ColdGraphRead:', start)
old = before[start:end]
validator = old.replace('def _cold_graph_inputs(values):', 'def _cold_graph_validate_inputs(values):', 1)
validator = validator.replace("body = ['limits', visit(Limits.model_dump(value))]",
    "body = ['limits', visit(dict(_cold_graph_limit_values(value)))]", 1)
assert 'Limits.model_dump(value)' not in validator
validator = validator.replace('if kind in (str, int, float, bool, type(None)):',
    'if any(kind is allowed for allowed in (str, int, float, bool, type(None))):', 1)
validator = validator.replace('require(kind in (dict, RowMapping, list, tuple, Limits, bytes),',
    'require(any(kind is allowed for allowed in (dict, RowMapping, list, tuple, Limits, bytes)),', 1)
validator = validator.replace('elif kind in (dict, RowMapping):\n            keys = list(value.keys())\n'
    '            require(all(type(key) in (str, quoted_name) for key in keys), "Cold graph keys changed")\n'
    '            body = [\'mapping\', [[str(key), visit(value[key])] for key in sorted(keys, key=str)]]',
    'elif kind is dict or kind is RowMapping:\n'
    '            mapping = value if kind is dict else dict(_cold_graph_row_values(value))\n'
    '            keys = list(mapping.keys())\n'
    '            require(all(type(key) is str or type(key) is quoted_name for key in keys), "Cold graph keys changed")\n'
    '            body = [\'mapping\', [[str(key), visit(mapping[key])] for key in sorted(keys, key=str)]]', 1)
assert 'kind in (' not in validator and 'type(key) in (' not in validator
candidate = (out/'cold_graph_codec_candidate.py').read_text()
tree = ast.parse(candidate)
lines = candidate.splitlines(keepends=True)
fragment = '\n\n'.join(''.join(lines[n.lineno-1:n.end_lineno]).rstrip() for n in tree.body
    if isinstance(n, ast.FunctionDef))
after = before[:start] + validator + '\n\n\n' + fragment + before[end:]
begin = after.index('class _ColdGraphRead:')
end = after.index('\n\n@contextmanager\ndef _cold_graph_read(', begin)
section = after[begin:end]
assert section.count('        self.key = self.input_key()\n') == 2
section = section.replace('        self.key = self.input_key()\n',
    '        self.key = self.input_key(_validate=True)\n', 1)
section = section.replace('    def input_key(self):\n', '    def input_key(self, *, _validate=False):\n', 1)
needle = '        return _cold_graph_inputs(dict(inputs=self.inputs, role_limits=self.role_limits, phase=self.phase,\n'
assert needle in section
section = section.replace(needle,
    '        values = dict(inputs=self.inputs, role_limits=self.role_limits, phase=self.phase,\n', 1)
needle = '                account=b.account_id, version=b.version, fingerprint=b.contract_fingerprint)))\n'
assert needle in section
section = section.replace(needle,
    '                account=b.account_id, version=b.version, fingerprint=b.contract_fingerprint))\n'
    '        if _validate:\n'
    '            _cold_graph_validate_inputs(values)\n'
    '        return _cold_graph_inputs(values)\n', 1)
needle = '            self.inputs[name] = value\n'
assert needle in section
section = section.replace(needle,
    '            _cold_graph_validate_inputs(value)\n' + needle, 1)
after = after[:begin] + section + after[end:]
old_tree, new_tree = ast.parse(before), ast.parse(after)
def find(tree,name): return next(n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name==name)
for name in ('_model_inputs','_model_value','_ModelSettlementRead'):
    assert ast.dump(find(old_tree,name),include_attributes=False)==ast.dump(find(new_tree,name),include_attributes=False)
allowed={'_cold_graph_inputs','_cold_graph_validate_inputs','_cold_graph_bytes','_cold_graph_pickle_marker',
    '_cold_graph_limit_values','_cold_graph_row_values','_ColdGraphRead'}
def outside(tree):return [ast.dump(n,include_attributes=False) for n in tree.body
    if not (isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in allowed)]
assert outside(old_tree)==outside(new_tree)
patch=''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),
    fromfile='a/src/sim2act/natural_spec_runtime.py',tofile='b/src/sim2act/natural_spec_runtime.py'))
(out/'cold-graph-codec-base.py').write_text(before)
(out/'cold-graph-codec-proposed.py').write_text(after)
(out/'cold-graph-codec.patch').write_text(patch)
proof=dict(kind='PURE_STDLIB_AST_ONLY_EXTERNAL_PATCH',source_before=hashlib.sha256(before.encode()).hexdigest(),
    source_after=hashlib.sha256(after.encode()).hexdigest(),patch_sha256=hashlib.sha256(patch.encode()).hexdigest(),
    patch_bytes=len(patch.encode()),original_model_read_and_model_inputs_ast_equal=True,
    outside_codec_and_cgr_ast_equal=True,product_or_db_or_model_execution=False)
(out/'cold-graph-codec-static.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof))
