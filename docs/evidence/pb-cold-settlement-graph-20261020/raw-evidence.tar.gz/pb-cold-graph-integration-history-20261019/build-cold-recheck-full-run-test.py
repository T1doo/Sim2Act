"""Create external test-only patch; do not import product or execute tests."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

repo=Path('/workspace/Sim2Act')
out=Path('/workspace/pb-cold-graph-integration-history-20261019')
path=Path('tests/test_cold_trial_guard_delta.py')
original=(repo/path).read_text()
changed=original.replace('import inspect\n', 'import inspect\nimport json\nimport time\n', 1)
assert changed != original
changed=changed.replace('from sim2act import natural_live_admission as gate\n',
    'from sim2act import app_jobs\nfrom sim2act import natural_live_admission as gate\n',1)
changed=changed.replace('from sim2act import pa_trial_dispatch as dispatch\n',
    'from sim2act import pa_spec_apps as spec\nfrom sim2act import pa_trial_dispatch as dispatch\n',1)
changed=changed.replace('from sim2act.db import fingerprint, internal_instances, internal_releases, new_id\n',
    'from sim2act.db import fingerprint, internal_instances, internal_releases, new_id, runs\n',1)
changed+='''\n\ndef test_cold_recheck_full_run_matches_actual_lock_live_prefix_before_context_consumer(
        typed_trial_inputs, monkeypatch, tmp_path):
    """One real SQLite full-row boundary, NOT a trial/Stage/permit proof.

    Approval/source/prefix semantics before the row comparison are explicit
    isolated stand-ins. The next original context predicate is a stop sentinel,
    so no fake Stage ACK, RunCheck, Permit, sender or model can be produced.
    Actual lock_live/Store.guard and both fresh runs SELECTs remain unpatched.
    """
    t, f = typed_trial_inputs, typed_trial_inputs.f
    rid, now = new_id('run'), time.time()
    full = dict(id=rid, project_id=t.contract.project_id, principal_id=f.user,
        runtime_id=f.draft['runtime_id'], goal='complete persisted goal outside the 13-column projection',
        resource_refs=[t.contract.bindings[1].resource_id], status='RUNNING',
        request_key='synthetic-full-row-only', fingerprint='d' * 64,
        created_at=now - 1, lease_until=now + t.contract.caps.lease_seconds - 1,
        fence=1, worker_id=f.worker.id,
        context=dict(messages=[], tools=0, full={'retained': ['one', 'two', 'two']}),
        result=None, error=None, cancel_intent=False, version=1)
    assert set(full) == set(runs.c.keys())
    with f.store.tx() as c:
        c.execute(insert(runs).values(**full))

    trace, consumers, queries = [], [], []
    stopped = RuntimeError('synthetic stop at original full Run context consumer')
    cold_authority = SimpleNamespace(run_id=rid, stage='cold')
    source_authority = SimpleNamespace(run_id=new_id('run'), stage='source')
    cold = SimpleNamespace(approval_key=f.worker.pa_trial.approval_key,
        authority=cold_authority, expected_authority_fingerprint=fingerprint(vars(cold_authority)))
    source = SimpleNamespace(approval_key=f.worker.pa_trial.approval_key,
        authority=source_authority, expected_authority_fingerprint=fingerprint(vars(source_authority)))

    def requirements(*args, **kwargs):
        trace.append('requirements-standin')
        return t.contract, t.expected

    def approved(*args, **kwargs):
        trace.append('approval-standin')
        return SimpleNamespace(synthetic_not_an_approval=True)

    def saved_phase(c, user, entity, kind, key, model, **kwargs):
        trace.append(key + '-phase-standin')
        return cold if key == 'cold' else source

    def journal_source(*args, **kwargs):
        trace.append('source-standin')
        return SimpleNamespace(synthetic_not_a_verified_source=True)

    def frozen_only(connection, job):
        # Isolate the unrelated frozen/semantic proof. Store.guard must still
        # obtain its own complete actual SQLite row before this fixture edge.
        assert connection is c and set(job) == set(runs.c.keys())
        trace.append('prefix-frozen-standin')
        return None

    def prefix_before_semantics(worker, connection, run, binding, delta=0, **kwargs):
        assert worker is f.worker and connection is c
        job = app_jobs.lock_live(worker.store, connection, run)
        trace.append('actual-lock-live-full-row')
        return job, f.limits

    def consumer(user, contract, stage, actual, version, fence, approval, phase, at, **kwargs):
        assert user == f.user and contract is t.contract and stage == 'cold'
        assert set(actual) == set(runs.c.keys()) and dict(actual) == database_row
        assert runtime._model_inputs(dict(actual)) == runtime._model_inputs(dict(prefix.job))
        assert actual['goal'] == full['goal'] and actual['context'] == full['context']
        consumers.append('original-context-consumer')
        raise stopped

    monkeypatch.setattr(policy, '_requirements', requirements)
    monkeypatch.setattr(gate, '_approved', approved)
    monkeypatch.setattr(gate, '_keys', lambda *a, **k: {'source', 'cold'})
    monkeypatch.setattr(gate, '_saved', saved_phase)
    monkeypatch.setattr(gate, '_graph_trial_produced', lambda *a, **k: None)
    monkeypatch.setattr(dispatch, '_journal_source', journal_source)
    monkeypatch.setattr(gate, '_require_run_context_row', consumer)
    monkeypatch.setattr(f.store, '_frozen_contract_after_scope', frozen_only)
    monkeypatch.setattr(spec, '_commit_guard_prefix', prefix_before_semantics)

    with f.store.tx() as c, pb._source_reads(f.store, c):
        database_row = dict(c.execute(select(runs).where(runs.c.id == rid)).mappings().one())
        assert set(database_row) == set(runs.c.keys())
        with read_scope(f, c) as guard:
            prefix = spec._cold_commit_prefix(f.worker, c, database_row,
                {'synthetic_not_a_business_binding': True}, guard, 'second')
            assert type(prefix) is spec._ColdCommitPrefix
            assert set(prefix.job) == set(runs.c.keys()) and prefix.job == database_row
            assert 'actual-lock-live-full-row' in trace
            graph = object.__new__(runtime._ColdTrialGraph)
            # These stand-ins only isolate the already-reviewed earlier Stage
            # checks. They deliberately cannot assert a complete graph or ACK.
            graph.__dict__.update(worker=f.worker, c=c, guard=guard,
                cold_authority=dict(vars(cold_authority)), source_authority=dict(vars(source_authority)),
                authorities=set(), check=lambda: gate._graph_trial_pin(guard, f.store, c),
                _dump=lambda value: dict(vars(value)), _fingerprint=fingerprint,
                _source_value=lambda value: trace.append('source-observation-standin'))

            def observe(conn, cursor, statement, params, context, executemany):
                queries.append(statement)

            event.listen(f.store.engine, 'before_cursor_execute', observe)
            try:
                with pytest.raises(RuntimeError) as reached:
                    graph._recheck(prefix.job)
                assert reached.value is stopped
                assert consumers == ['original-context-consumer'] and guard.active
                positive = list(queries)
                queries.clear()
                # Mutate only a top-level field of the actual prefix's job;
                # the canonical copied prefix facts and DB stay unchanged.
                # The old 13-column projection never contained this field.
                prefix.job['goal'] = 'changed complete caller goal'
                gate._graph_trial_pin(guard, f.store, c)
                with pytest.raises(DomainError) as rejected:
                    graph._recheck(prefix.job)
                assert rejected.value.code == 'VERSION_CONFLICT'
                assert consumers == ['original-context-consumer']
                negative = list(queries)
                prefix.job['goal'] = database_row['goal']
            finally:
                event.remove(f.store.engine, 'before_cursor_execute', observe)
            for statements in (positive, negative):
                complete_reads = [s for s in statements if s.startswith('SELECT runs.id,')
                    and 'runs.goal' in s and 'runs.context' in s]
                assert len(complete_reads) == 1
            assert dict(c.execute(select(runs).where(runs.c.id == rid)).mappings().one()) == database_row
            proof = dict(classification='ISOLATED_FULL_RUN_RECHECK_BOUNDARY_NO_STAGE_ACK',
                full_columns=list(runs.c.keys()), prefix_job=dict(prefix.job),
                positive_consumer_count=1, drift_consumer_count=0,
                positive_sql=positive, drift_sql=negative, prior_standins=trace,
                actual_worker_claims=0, model_requests=0, admitted_execution=False)
            (tmp_path / 'full-run-recheck-boundary.json').write_text(
                json.dumps(proof, indent=2, ensure_ascii=False) + '\\n')
'''
ast.parse(changed)
a={n.name:ast.dump(n,include_attributes=False) for n in ast.parse(original).body
    if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
b={n.name:ast.dump(n,include_attributes=False) for n in ast.parse(changed).body
    if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
added=sorted(n for n in b if n not in a)
assert added==['test_cold_recheck_full_run_matches_actual_lock_live_prefix_before_context_consumer']
assert all(a[name]==b[name] for name in a)
patch=''.join(difflib.unified_diff(original.splitlines(True),changed.splitlines(True),
    fromfile='a/'+str(path),tofile='b/'+str(path)))
patch_path=out/'test-cold-recheck-full-run.patch'
patch_path.write_text(patch)
report=dict(kind='EXTERNAL_TEST_ONLY_STATIC_PATCH',product_or_test_execution=False,
    repository_modified=False,input=dict(path=str(path),sha256=hashlib.sha256(original.encode()).hexdigest()),
    patch=dict(path=str(patch_path),bytes=len(patch.encode()),sha256=hashlib.sha256(patch.encode()).hexdigest()),
    added_tests=added,checks=['AST parsed','all previous test/fixture AST unchanged','only one test file changes'],
    actual_edges=['SQLite full runs row','app_jobs.lock_live and Store.guard full job',
        'actual spec._cold_commit_prefix','actual _ColdTrialGraph._recheck',
        'real fresh select and full-row _model_inputs comparison'],
    isolated_edges=['prior approval/phase/source/semantic checks are explicit stand-ins',
        'original context consumer is a stop sentinel; no ACK/RunCheck/Permit'],
    branches=['equal complete row reaches original consumer once',
        'goal field outside old 13-column projection drifts and reaches consumer zero times'])
(out/'test-cold-recheck-full-run-static.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
