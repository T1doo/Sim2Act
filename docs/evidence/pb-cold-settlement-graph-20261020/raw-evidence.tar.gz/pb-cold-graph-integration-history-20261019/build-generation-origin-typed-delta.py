"""External patch builder only: standard-library source/AST work, no product import."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

repo = Path('/workspace/Sim2Act')
out = Path('/workspace/pb-cold-graph-integration-history-20261019')
paths = [Path('src/sim2act/goal_applications.py'), Path('src/sim2act/pa_spec_apps.py'),
    Path('tests/test_cold_generation_facts.py')]
original = {path: (repo / path).read_text() for path in paths}
ga, pa, tests = (original[path] for path in paths)

def replace_once(value, old, new):
    assert value.count(old) == 1, (old[:110], value.count(old))
    return value.replace(old, new)

def transform_function(value, name, transform):
    node = next(n for n in ast.parse(value).body if isinstance(n, ast.FunctionDef) and n.name == name)
    lines = value.splitlines(True)
    old = ''.join(lines[node.lineno - 1:node.end_lineno])
    new = transform(old)
    return ''.join(lines[:node.lineno - 1]) + new + ''.join(lines[node.end_lineno:])

ga = replace_once(ga, '    AppManifest,\n    Strict,', '    AppManifest,\n    FrozenRunContract,\n    Strict,')
ga = replace_once(ga, '''            if contract is not None:
                if (type(contract) is not FrozenRunContract
                        or raw_contract["snapshot"] != contract.model_dump(exclude_none=True)
                        or raw_contract["fingerprint"] != fingerprint(contract.model_dump(exclude_none=True))):
''', '''            if contract is not None:
                if (type(contract) is not FrozenRunContract
                        or raw_contract["snapshot"] != FrozenRunContract.model_dump(contract, exclude_none=True)
                        or raw_contract["fingerprint"] != fingerprint(FrozenRunContract.model_dump(contract, exclude_none=True))):
''')
ga = replace_once(ga, '''                if self.contract is None:
                    raise DomainError("VERSION_CONFLICT", "Missing complete generation contract")
                if (self.authorities != tuple(self.source_pin["authorities"])
                        or dict(self.run) != self.source_pin["run"]
                        or self.contract.model_dump() != self.source_pin["contract"]
''', '''                if type(self.contract) is not FrozenRunContract:
                    raise DomainError("VERSION_CONFLICT", "Missing complete generation contract")
                from .natural_live_admission import _trial_typed_equal
                if (self.authorities != tuple(self.source_pin["authorities"])
                        or dict(self.run) != self.source_pin["run"]
                        or not _trial_typed_equal(FrozenRunContract.model_dump(self.contract), self.source_pin["contract"])
''')
ga = replace_once(ga, '''        if (contract.application_generation.version != GENERATION
''', '''        if (type(contract) is not FrozenRunContract
                or contract.application_generation.version != GENERATION
''')
ga = replace_once(ga, '''            contract=copy.deepcopy(contract.model_dump()), material=copy.deepcopy(material),
''', '''            contract=copy.deepcopy(FrozenRunContract.model_dump(contract)), material=copy.deepcopy(material),
''')

relay = '''@dataclass(frozen=True)
class _ColdOriginalOriginRead:
    """Exact lexical original-Manifest/Generation pin, never a callback or authority."""
    guard: Any
    prefix: _ColdOriginalOriginPrefix
    reader: Any
    key: str
    pin: dict

    def check(self, store, c, user):
        from .goal_applications import _cold_generation_reader, _GenerationFactsReader
        from .natural_live_admission import _trial_typed_equal
        from .natural_spec_runtime import _ColdGraphRead

        try:
            require(type(self.guard) is _ColdGraphRead
                and type(self.prefix) is _ColdOriginalOriginPrefix
                and type(self.reader) is _GenerationFactsReader)
            prefix, reader = self.prefix, self.reader
            require(prefix.guard is self.guard and reader.guard is self.guard
                and prefix.user == user == reader.run["principal_id"],
                "Original origin read scope changed")
            _cold_generation_reader(store, c, reader.run, reader)
            require(type(prefix.manifest) is AppManifest and type(prefix.limits) is Limits
                and type(self.pin) is dict and type(self.key) is str)
            key = "original-origin-prefix:" + prefix.draft["id"] + ":" + fingerprint(Limits.model_dump(prefix.limits))
            require(self.key == key and self.guard.inputs.get(key) is self.pin
                and self.pin["draft"] is prefix.draft and self.pin["limits"] is prefix.limits
                and self.pin["report"] is prefix.report
                and _trial_typed_equal(AppManifest.model_dump(prefix.manifest), self.pin["manifest"]),
                "Complete typed original Manifest changed before consumption")
        except BaseException:
            if type(self.guard) is _ColdGraphRead:
                _ColdGraphRead.invalidate(self.guard)
            if type(self.prefix) is _ColdOriginalOriginPrefix and type(self.prefix.guard) is _ColdGraphRead:
                _ColdGraphRead.invalidate(self.prefix.guard)
            if type(self.reader) is _GenerationFactsReader:
                _GenerationFactsReader.invalidate(self.reader)
            raise


def _original_origin_checkpoint(store, c, user, origin_read):
    # This is a fixed private object, not a widened _graph_read/callback hook.
    require(type(origin_read) is _ColdOriginalOriginRead, "Exact original origin read pin required")
    _ColdOriginalOriginRead.check(origin_read, store, c, user)


'''
pa = replace_once(pa, 'def _cold_original_origin_prefix(store, c, user, draft, limits, guard):\n',
    relay + 'def _cold_original_origin_prefix(store, c, user, draft, limits, guard):\n')

# All original _graph_read calls remain exact-type and in place. The new pin is
# separate and runs only on the private original chain after each old boundary.
def model_source(old):
    old = replace_once(old,
        'def _cold_original_model_source(store, c, user, run, original, marker, raw, reader):',
        'def _cold_original_model_source(store, c, user, run, original, marker, raw, reader, *, _origin_read=None):')
    old = replace_once(old, '        reader = _cold_generation_reader(store, c, run, reader)\n',
        '        reader = _cold_generation_reader(store, c, run, reader)\n'
        '        if _origin_read is not None:\n'
        '            _original_origin_checkpoint(store, c, user, _origin_read)\n')
    old = old.replace('        reader.check()\n', '        reader.check()\n'
        '        if _origin_read is not None:\n'
        '            _original_origin_checkpoint(store, c, user, _origin_read)\n')
    return old
pa = transform_function(pa, '_cold_original_model_source', model_source)

def target(old):
    old = replace_once(old, 'def target(', 'def _target_core(')
    old = replace_once(old, 'family=VERSION, _graph_read=None):',
        'family=VERSION, _graph_read=None, _origin_read=None):')
    old = replace_once(old, '    project = store.own_project(c, user, pid)\n',
        '    if _graph_read is not None:\n'
        '        from .natural_spec_runtime import _ColdGraphRead\n'
        '        require(type(_graph_read) is _ColdGraphRead)\n'
        '    if _origin_read is not None:\n'
        '        _original_origin_checkpoint(store, c, user, _origin_read)\n'
        '        require(_graph_read is _origin_read.guard)\n'
        '    project = store.own_project(c, user, pid)\n')
    old = old.replace('    _bound_checkpoint(store, c, _graph_read)\n',
        '    _bound_checkpoint(store, c, _graph_read)\n'
        '    if _origin_read is not None:\n'
        '        _original_origin_checkpoint(store, c, user, _origin_read)\n')
    old = replace_once(old,
        '    store.authorize(c, user, runtime or project["runtime_id"], pid, pid, SAVE)',
        '    store.authorize(c, user, _target_runtime(project, runtime), pid, pid, SAVE)')
    old = replace_once(old, '    source_check(source, family)',
        '    _target_source_check(source, family)')
    wrappers = '''def target(*args, **kwargs):
    # Fixed forwarding only. Strict guards stay outside persisted-data mappers;
    # default calls retain the original controlled argument/error semantics.
    if kwargs.get("_graph_read") is None and kwargs.get("_origin_read") is None:
        return _target_default(*args, **kwargs)
    return _target_core(*args, **kwargs)


@controlled
def _target_default(*args, **kwargs):
    return _target_core(*args, **kwargs)


@controlled
def _target_runtime(project, runtime):
    # Owned persisted scalar projection only; no guard or IO in this mapper.
    return runtime or project["runtime_id"]


@controlled
def _target_source_check(source, family):
    # The original pure bounded source parser; no guard/authority callback.
    return source_check(source, family)


'''
    return wrappers + old
# Only target's former outer mapper is split; scope/job/receipts are untouched.
pa = replace_once(pa, '@controlled\ndef target(', 'def target(')
pa = transform_function(pa, 'target', target)

def confirmation(old):
    old = replace_once(old, '*, _graph_read=None):', '*, _graph_read=None, _origin_read=None):')
    old = replace_once(old, '    goal = contract.source_goal_card\n',
        '    if _origin_read is not None:\n'
        '        _original_origin_checkpoint(store, c, user, _origin_read)\n'
        '        require(_graph_read is _origin_read.guard and contract is _origin_read.reader.contract)\n'
        '    goal = contract.source_goal_card\n')
    old = old.replace('    _bound_checkpoint(store, c, _graph_read)\n',
        '    _bound_checkpoint(store, c, _graph_read)\n'
        '    if _origin_read is not None:\n'
        '        _original_origin_checkpoint(store, c, user, _origin_read)\n')
    old = replace_once(old, '        **({"_graph_read": _graph_read} if _graph_read is not None else {}))',
        '        **({"_graph_read": _graph_read} if _graph_read is not None else {}),\n'
        '        **({"_origin_read": _origin_read} if _origin_read is not None else {}))')
    return old
pa = transform_function(pa, '_original_confirmation_target', confirmation)

def original_prefix(old):
    old = replace_once(old, '    manifest, _, report = compile_candidate(draft["candidate"], limits)\n',
        '    manifest, _, report = compile_candidate(draft["candidate"], limits)\n'
        '    if _graph_read is not None:\n'
        '        from .natural_live_admission import _trial_typed_equal\n'
        '        require(type(manifest) is AppManifest)\n'
        '        manifest_pin = copy.deepcopy(AppManifest.model_dump(manifest))\n')
    old = old.replace('    _bound_checkpoint(store, c, _graph_read)\n',
        '    _bound_checkpoint(store, c, _graph_read)\n'
        '    if _graph_read is not None:\n'
        '        require(_trial_typed_equal(AppManifest.model_dump(manifest), manifest_pin),\n'
        '            "Complete typed original Manifest changed at prefix read")\n')
    return old
pa = transform_function(pa, '_original_origin_prefix', original_prefix)

def prefix(old):
    old = replace_once(old,
        '        guard.add(key, dict(draft=draft, limits=limits, manifest=manifest.model_dump(), report=report, marker=marker))',
        '        require(type(manifest) is AppManifest)\n'
        '        guard.add(key, dict(draft=draft, limits=limits, manifest=AppManifest.model_dump(manifest), report=report, marker=marker))')
    return old
pa = transform_function(pa, '_cold_original_origin_prefix', prefix)

def from_generation(old):
    old = replace_once(old, '        reader = _cold_generation_reader(store, c, reader.run, reader)\n',
        '        reader = _cold_generation_reader(store, c, reader.run, reader)\n'
        '        key = "original-origin-prefix:" + prefix.draft["id"] + ":" + fingerprint(Limits.model_dump(prefix.limits))\n'
        '        origin_read = _ColdOriginalOriginRead(guard, prefix, reader, key, guard.inputs[key])\n'
        '        _original_origin_checkpoint(store, c, user, origin_read)\n')
    old = replace_once(old,
        '        _cold_original_model_source(store, c, user, reader.run, prefix.draft, marker, raw, reader)\n',
        '        _cold_original_model_source(store, c, user, reader.run, prefix.draft, marker, raw, reader, _origin_read=origin_read)\n'
        '        _original_origin_checkpoint(store, c, user, origin_read)\n')
    # After each original SQL/authority callback, check the real typed cohort
    # before the next IO or actual Manifest consumption.
    old = old.replace('        _bound_checkpoint(store, c, guard)\n',
        '        _bound_checkpoint(store, c, guard)\n'
        '        if "origin_read" in locals():\n'
        '            _original_origin_checkpoint(store, c, user, origin_read)\n')
    # Avoid a locals-dependent protocol: the first checkpoint precedes creation.
    old = replace_once(old,
        '        _bound_checkpoint(store, c, guard)\n'
        '        if "origin_read" in locals():\n'
        '            _original_origin_checkpoint(store, c, user, origin_read)\n'
        '        require(reader.guard is guard and prefix.user == user)',
        '        _bound_checkpoint(store, c, guard)\n'
        '        require(reader.guard is guard and prefix.user == user)')
    old = old.replace('        if "origin_read" in locals():\n'
        '            _original_origin_checkpoint(store, c, user, origin_read)\n',
        '        _original_origin_checkpoint(store, c, user, origin_read)\n')
    old = replace_once(old,
        '        source, goal = _original_confirmation_target(store, c, user, prefix.draft, contract, _graph_read=guard)\n',
        '        source, goal = _original_confirmation_target(store, c, user, prefix.draft, contract,\n'
        '            _graph_read=guard, _origin_read=origin_read)\n'
        '        _original_origin_checkpoint(store, c, user, origin_read)\n')
    old = replace_once(old, 'dict(manifest=prefix.manifest.model_dump(), report=prefix.report, source=source, goal=goal.model_dump()))',
        'dict(manifest=AppManifest.model_dump(prefix.manifest), report=prefix.report, source=source, goal=goal.model_dump()))')
    old = replace_once(old, '        return result\n',
        '        _original_origin_checkpoint(store, c, user, origin_read)\n'
        '        return result\n')
    return old
pa = transform_function(pa, '_cold_original_origin_from_generation', from_generation)

tests = replace_once(tests, 'from sim2act.db import Store, app_drafts, attempts, events, fingerprint, new_id, operations, runs',
    'from sim2act.db import Store, app_drafts, attempts, events, fingerprint, goal_application_candidates, new_id, operations, runs')
tests += '''\n\ndef test_typed_generation_contract_drift_stops_before_next_authority_io(generated, monkeypatch, tmp_path):
    f = generated
    before = snapshot(f.store)
    observed, callbacks = [], []
    with f.store.tx() as c:
        with pytest.raises(DomainError):
            with scope(f, c) as guard:
                contract, _, reader = generation._cold_generation_source(f.store, c, f.run, guard)
                original = f.store.own_project
                number = contract.limits.max_requests

                def forbidden_dump(*args, **kwargs):
                    callbacks.append("instance-dump")
                    pytest.fail("Typed pin must use the exact FrozenRunContract class serializer")

                object.__getattribute__(contract, "__dict__")["model_dump"] = forbidden_dump
                reader.check()

                def mutate_after_project(*args, **kwargs):
                    value = original(*args, **kwargs)
                    observed.append("own_project")
                    contract.limits.max_requests = float(number)
                    assert contract.limits.max_requests == reader.source_pin["contract"]["limits"]["max_requests"]
                    assert type(contract.limits.max_requests) is float
                    return value

                def later_authority(*args, **kwargs):
                    observed.append("later-authority")
                    pytest.fail("Typed contract drift must stop before the next authority IO")

                with monkeypatch.context() as patch:
                    patch.setattr(f.store, "own_project", mutate_after_project)
                    patch.setattr(f.store, "recheck_proof_authorities", later_authority)
                    assert denied(reader.source) == "VERSION_CONFLICT"
                assert not guard.active and observed == ["own_project"] and callbacks == []
                assert denied(reader.check) == "VERSION_CONFLICT"
                write(tmp_path / "typed-contract-next-io.json", dict(observed=observed,
                    callback_calls=callbacks, actual_type=type(contract.limits.max_requests).__name__,
                    saved_type=type(reader.source_pin["contract"]["limits"]["max_requests"]).__name__,
                    sticky=not guard.active))
    assert snapshot(f.store) == before and len(f.sent) == 3


def test_original_manifest_numeric_drift_stops_after_prefix_and_confirmation_sql(generated, monkeypatch, tmp_path):
    f = generated
    before = snapshot(f.store)
    proofs = []
    for edge in ("prefix-marker", "confirmation"):
        sql_after_drift, changed, compiled = [], [], []
        with f.store.tx() as c:
            with pytest.raises(DomainError):
                with scope(f, c) as guard:
                    if edge == "confirmation":
                        contract, source, reader, history = strict_history(f, c, guard)
                        raw = generation._cold_candidate_from_history(f.store, c, f.run,
                            contract, source, history, f.full, reader)
                        prefix = spec._cold_original_origin_prefix(f.store, c, f.user, f.draft, f.full, guard)
                        marker = c.execute(select(goal_application_candidates).where(
                            goal_application_candidates.c.app_id == f.draft["id"])).mappings().one()
                        compiled.append(prefix.manifest)
                    original_compile = spec.compile_candidate

                    def observe_compile(*args, original_compile=original_compile, compiled=compiled, **kwargs):
                        value = original_compile(*args, **kwargs)
                        compiled.append(value[0])
                        return value

                    def before_sql(conn, cursor, statement, parameters, context, executemany,
                            changed=changed, sql_after_drift=sql_after_drift):
                        if changed:
                            sql_after_drift.append(statement)

                    def after_sql(conn, cursor, statement, parameters, context, executemany,
                            edge=edge, changed=changed, compiled=compiled):
                        selected = ("FROM task_extractions" in statement if edge == "prefix-marker"
                            else statement.startswith("SELECT goal_application_candidates.confirmation"))
                        if compiled and not changed and selected:
                            manifest = compiled[-1]
                            original = manifest.revision
                            manifest.revision = float(original)
                            changed.append(statement)
                            assert manifest.revision == original and type(manifest.revision) is float

                    event.listen(f.store.engine, "before_cursor_execute", before_sql)
                    event.listen(f.store.engine, "after_cursor_execute", after_sql)
                    try:
                        with monkeypatch.context() as patch:
                            if edge == "prefix-marker":
                                patch.setattr(spec, "compile_candidate", observe_compile)
                                call = partial(spec._cold_original_origin_prefix,
                                    f.store, c, f.user, f.draft, f.full, guard)
                            else:
                                call = partial(spec._cold_original_origin_from_generation,
                                    f.store, c, f.user, prefix, reader, raw, marker)
                            assert denied(call) == "VERSION_CONFLICT"
                    finally:
                        event.remove(f.store.engine, "before_cursor_execute", before_sql)
                        event.remove(f.store.engine, "after_cursor_execute", after_sql)
                    assert len(changed) == 1 and sql_after_drift == [] and not guard.active
                    if edge == "confirmation":
                        assert denied(reader.check) == "VERSION_CONFLICT"
                    proofs.append(dict(edge=edge, changed_after_sql=changed, later_sql=sql_after_drift,
                        actual_type=type(compiled[-1].revision).__name__, sticky=not guard.active))
        assert snapshot(f.store) == before
    write(tmp_path / "typed-original-manifest-next-io.json", proofs)
    assert len(f.sent) == 3


def test_original_target_strict_relay_keeps_guard_valueerror_identity(generated, monkeypatch, tmp_path):
    f = generated
    before = snapshot(f.store)
    same_error = ValueError("synthetic original relay guard error")
    completed, later_sql, later_calls = [], [], []
    with f.store.tx() as c:
        with pytest.raises(DomainError):
            with scope(f, c) as guard:
                _, _, reader = generation._cold_generation_source(f.store, c, f.run, guard)
                prefix = spec._cold_original_origin_prefix(f.store, c, f.user, f.draft, f.full, guard)
                key = "original-origin-prefix:" + f.draft["id"] + ":" + fingerprint(f.full.model_dump())
                relay = spec._ColdOriginalOriginRead(guard, prefix, reader, key, guard.inputs[key])
                spec._original_origin_checkpoint(f.store, c, f.user, relay)
                original_own, original_check = f.store.own_project, reader.check

                def owned_project(*args, **kwargs):
                    value = original_own(*args, **kwargs)
                    completed.append("owned-project")
                    return value

                def actual_reader_guard():
                    original_check()
                    if completed:
                        raise same_error

                def later_authorize(*args, **kwargs):
                    later_calls.append("authorize")
                    pytest.fail("Relay failure must stop before the next authority IO")

                def before_sql(conn, cursor, statement, parameters, context, executemany):
                    if completed:
                        later_sql.append(statement)

                event.listen(f.store.engine, "before_cursor_execute", before_sql)
                try:
                    with monkeypatch.context() as patch:
                        patch.setattr(f.store, "own_project", owned_project)
                        patch.setattr(f.store, "authorize", later_authorize)
                        patch.setattr(reader, "check", actual_reader_guard)
                        with pytest.raises(ValueError) as error:
                            spec.target(f.store, c, f.user, f.run["project_id"], "unused-after-guard",
                                _graph_read=guard, _origin_read=relay)
                        assert error.value is same_error
                finally:
                    event.remove(f.store.engine, "before_cursor_execute", before_sql)
                assert completed == ["owned-project"] and later_sql == [] and later_calls == []
                assert not guard.active and denied(reader.check) == "VERSION_CONFLICT"

                def malformed_owned_row(*args, **kwargs):
                    raise same_error

                # The same error remains mapped on the original default path;
                # even argument-binding TypeError retains its prior mapping.
                with monkeypatch.context() as patch:
                    patch.setattr(f.store, "own_project", malformed_owned_row)
                    assert denied(partial(spec.target, f.store, c, f.user,
                        f.run["project_id"], "unused-default")) == "VERSION_CONFLICT"
                    assert denied(spec.target) == "VERSION_CONFLICT"
                write(tmp_path / "original-target-guard-error-identity.json", dict(
                    same_exception_object=True, completed=completed, later_sql=later_sql,
                    later_calls=later_calls, default_error="VERSION_CONFLICT", sticky=not guard.active))
    assert snapshot(f.store) == before and len(f.sent) == 3

'''

changed = dict(zip(paths, (ga, pa, tests), strict=True))
def definitions(text):
    return {node.name: ast.dump(node, include_attributes=False) for node in ast.parse(text).body
        if isinstance(node, (ast.FunctionDef, ast.ClassDef, ast.AsyncFunctionDef))}
changes = {}
for path in paths:
    ast.parse(changed[path])
    left, right = definitions(original[path]), definitions(changed[path])
    changes[str(path)] = sorted(name for name in left.keys() | right.keys() if left.get(name) != right.get(name))
assert changes[str(paths[0])] == ['_ColdGenerationRawSeed', '_GenerationFactsReader', '_cold_generation_source']
assert changes[str(paths[1])] == ['_ColdOriginalOriginRead', '_cold_original_model_source',
    '_cold_original_origin_from_generation', '_cold_original_origin_prefix',
    '_original_confirmation_target', '_original_origin_checkpoint', '_original_origin_prefix',
    '_target_core', '_target_default', '_target_runtime', '_target_source_check', 'target']
# Do not widen the root guard or touch semantic binding/commit gates.
for name in ('_bound_checkpoint', 'bound', 'commit_guard'):
    if name in definitions(original[paths[1]]):
        assert definitions(original[paths[1]])[name] == definitions(pa)[name]
# Erasing only the new optional relay restores exact original target/confirmation
# function ASTs, including original IO order and argument shape.
def erase_relay(node):
    import copy
    node = copy.deepcopy(node)
    node.args.kwonlyargs = [arg for arg in node.args.kwonlyargs if arg.arg != '_origin_read']
    # Both touched functions append exactly one new optional keyword at the end.
    node.args.kw_defaults = node.args.kw_defaults[:-1]
    class Strip(ast.NodeTransformer):
        def visit_If(self, current):
            if (isinstance(current.test, ast.Compare) and isinstance(current.test.left, ast.Name)
                    and current.test.left.id == '_origin_read'):
                return None
            return self.generic_visit(current)
        def visit_Call(self, current):
            current = self.generic_visit(current)
            current.keywords = [k for k in current.keywords if not (k.arg is None
                and isinstance(k.value, ast.IfExp) and isinstance(k.value.test, ast.Compare)
                and isinstance(k.value.test.left, ast.Name) and k.value.test.left.id == '_origin_read')]
            return current
    return Strip().visit(node)
for name in ('_original_confirmation_target',):
    left = next(n for n in ast.parse(original[paths[1]]).body if isinstance(n, ast.FunctionDef) and n.name == name)
    right = next(n for n in ast.parse(pa).body if isinstance(n, ast.FunctionDef) and n.name == name)
    assert ast.dump(left, include_attributes=False) == ast.dump(erase_relay(right), include_attributes=False), name
# The default target calls the same strict-signature core through controlled.
# Normalize the two pure owned-data mapper leaves back to the original expressions.
left = next(n for n in ast.parse(original[paths[1]]).body if isinstance(n, ast.FunctionDef) and n.name == 'target')
right = next(n for n in ast.parse(pa).body if isinstance(n, ast.FunctionDef) and n.name == '_target_core')
right = erase_relay(right)
right.name, right.decorator_list = left.name, left.decorator_list
class RestoreTargetData(ast.NodeTransformer):
    def visit_If(self, node):
        if (isinstance(node.test, ast.Compare) and isinstance(node.test.left, ast.Name)
                and node.test.left.id == '_graph_read'):
            return None
        return self.generic_visit(node)
    def visit_Call(self, node):
        node = self.generic_visit(node)
        if isinstance(node.func, ast.Name) and node.func.id == '_target_runtime':
            return ast.BoolOp(op=ast.Or(), values=[ast.Name(id='runtime', ctx=ast.Load()),
                ast.Subscript(value=ast.Name(id='project', ctx=ast.Load()),
                    slice=ast.Constant(value='runtime_id'), ctx=ast.Load())])
        if isinstance(node.func, ast.Name) and node.func.id == '_target_source_check':
            node.func.id = 'source_check'
        return node
assert ast.dump(left, include_attributes=False) == ast.dump(RestoreTargetData().visit(right), include_attributes=False)
# Strict core itself has no decorator; wrapper dispatch can only call these
# two fixed functions. Original public material target remains its own mapper.
core = next(n for n in ast.parse(pa).body if isinstance(n, ast.FunctionDef) and n.name == '_target_core')
assert core.decorator_list == []
dispatch = next(n for n in ast.parse(pa).body if isinstance(n, ast.FunctionDef) and n.name == 'target')
assert sorted(n.func.id for n in ast.walk(dispatch) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name)) == ['_target_core', '_target_default']
# Strict prefix-local pin branches erase to the unchanged shared/default IO.
import copy
left = next(n for n in ast.parse(original[paths[1]]).body if isinstance(n, ast.FunctionDef) and n.name == '_original_origin_prefix')
right = next(n for n in ast.parse(pa).body if isinstance(n, ast.FunctionDef) and n.name == '_original_origin_prefix')
class StripPrefixPin(ast.NodeTransformer):
    def visit_If(self, node):
        if (isinstance(node.test, ast.Compare) and isinstance(node.test.left, ast.Name)
                and node.test.left.id == '_graph_read'):
            return None
        return self.generic_visit(node)
assert ast.dump(left, include_attributes=False) == ast.dump(StripPrefixPin().visit(copy.deepcopy(right)), include_attributes=False)
patch = ''.join(''.join(difflib.unified_diff(original[path].splitlines(True), changed[path].splitlines(True),
    fromfile='a/' + str(path), tofile='b/' + str(path))) for path in paths)
patch_path = out / 'generation-origin-typed-pin.patch'
patch_path.write_text(patch)
report = dict(kind='EXTERNAL_STATIC_PATCH_ONLY', repository_modified=False, product_or_test_execution=False,
    patch=dict(path=str(patch_path), bytes=len(patch.encode()), sha256=hashlib.sha256(patch.encode()).hexdigest()),
    source_inputs={str(path): hashlib.sha256(original[path].encode()).hexdigest() for path in paths},
    changed_definitions=changes, tests_added=3,
    preserved=['RawSeed original snapshot fingerprint check', '_bound_checkpoint exact root guard',
        'default target/confirmation IO and keyword shape (AST erased optional relay equals original)',
        'bound/commit_guard', 'apps candidate-prefix numeric fingerprint', 'all root codec checks'],
    checks=['AST parsed 3 candidates', 'exact changed definition scope', 'default-path AST equivalence including prefix SQL', 'strict target core unmapped / fixed default dispatch'])
(out / 'generation-origin-typed-pin-static.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
