"""Build a goal-only external delta without importing/executing product code."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

out = Path('/workspace/pb-cold-graph-integration-history-20261019')
path = Path('/workspace/Sim2Act/src/sim2act/goal_applications.py')
before = path.read_text()
assert 'class _ColdGenerationRawSeed:' not in before
seed_class = '''class _ColdGenerationRawSeed:
    """Pinned complete native audit rows; no history, candidate or authority.

    The root collects and pins these raw rows at its original audit position.
    Later Source still proves its original current authorities before attaching
    the seed. Only complete Attempts/Operations are reused, lazily at their old
    first-read positions. No callback, SQL or selected projection is accepted.
    """

    def __init__(self, store, c, user, rows, guard):
        self.store, self.connection, self.user = store, c, user
        self.rows, self.guard, self._origin_guard = rows, guard, guard
        self.name = None
        try:
            self.check(store, c, user)
            self.name = "original-native-audit:" + rows["original"]["id"]
            self.check(store, c, user)
        except BaseException:
            self.invalidate()
            raise

    def invalidate(self):
        from .natural_spec_runtime import _ColdGraphRead

        if type(self._origin_guard) is _ColdGraphRead:
            self._origin_guard.invalidate()
        if type(self.guard) is _ColdGraphRead and self.guard is not self._origin_guard:
            self.guard.invalidate()

    def check(self, store, c, user, run=None, contract=None):
        from .contracts import FrozenRunContract
        from .db import goal_card_versions
        from .natural_spec_runtime import _ColdGraphRead, _cold_read_checkpoint

        try:
            if (type(self.guard) is not _ColdGraphRead or self.guard is not self._origin_guard
                    or self.store is not store or self.connection is not c or self.user != user):
                raise DomainError("VERSION_CONFLICT", "Exact Generation raw seed scope required")
            _cold_read_checkpoint(store, c, self.guard)
            rows = self.rows
            if type(rows) is not dict or set(rows) != {
                    "run", "contract", "original", "attempts", "operations", "intents", "events",
                    "confirmation", "goal_head", "goal_version"}:
                raise DomainError("VERSION_CONFLICT", "Complete native audit rows required")
            for name, table in (("run", runs), ("contract", run_contracts), ("original", app_drafts)):
                if type(rows[name]) is not dict or set(rows[name]) != set(table.c.keys()):
                    raise DomainError("VERSION_CONFLICT", "Complete native audit scalar row required")
            for name, table in (("attempts", attempts), ("operations", operations),
                    ("intents", operation_intents), ("events", events),
                    ("confirmation", goal_application_candidates), ("goal_head", goal_cards),
                    ("goal_version", goal_card_versions)):
                if type(rows[name]) is not list or any(type(row) is not dict
                        or set(row) != set(table.c.keys()) for row in rows[name]):
                    raise DomainError("VERSION_CONFLICT", "Complete native audit raw row list required")
            original, raw_run, raw_contract = rows["original"], rows["run"], rows["contract"]
            name = "original-native-audit:" + original["id"]
            if ((self.name is not None and self.name != name)
                    or self.guard.inputs.get(name) is not rows
                    or user != self.guard.binding.contract.principal_id
                    or raw_run["principal_id"] != user
                    or raw_run["project_id"] != self.guard.binding.contract.project_id
                    or original["project_id"] != raw_run["project_id"]
                    or raw_contract["run_id"] != raw_run["id"]):
                raise DomainError("VERSION_CONFLICT", "Generation raw seed binding changed")
            if run is not None and dict(run) != raw_run:
                raise DomainError("VERSION_CONFLICT", "Generation raw seed complete Run changed")
            if contract is not None:
                if (type(contract) is not FrozenRunContract
                        or raw_contract["snapshot"] != contract.model_dump(exclude_none=True)
                        or raw_contract["fingerprint"] != fingerprint(contract.model_dump(exclude_none=True))):
                    raise DomainError("VERSION_CONFLICT", "Generation raw seed frozen contract changed")
            _cold_read_checkpoint(store, c, self.guard)
        except BaseException:
            self.invalidate()
            raise


'''
after = before.replace('class _GenerationFactsReader:', seed_class + 'class _GenerationFactsReader:', 1)
after = after.replace('        self._raw_cache = {}\n',
    '        self._raw_cache = {}\n        self.raw_seed = self._raw_seed_initial = None\n', 1)
needle = '            if dict(self.run) != self.run_pin:\n'
assert after.count(needle) == 1
after = after.replace(needle,
    '            if self.raw_seed is not self._raw_seed_initial:\n'
    '                raise DomainError("VERSION_CONFLICT", "Generation raw seed pointer changed")\n'
    '            if self.raw_seed is not None:\n'
    '                if type(self.raw_seed) is not _ColdGenerationRawSeed:\n'
    '                    raise DomainError("VERSION_CONFLICT", "Exact Generation raw seed required")\n'
    '                self.raw_seed.check(self.store, self.c, self.run["principal_id"], self.run, self.contract)\n'
    + needle, 1)
needle = '        if self._guard_initial is not None:\n            self._guard_initial.invalidate()\n\n    def _raw_key('
assert after.count(needle) == 1
after = after.replace(needle,
    '        if self._guard_initial is not None:\n            self._guard_initial.invalidate()\n'
    '        for seed in (self.raw_seed, self._raw_seed_initial):\n'
    '            if type(seed) is _ColdGenerationRawSeed:\n'
    '                seed.invalidate()\n\n    def _raw_key(', 1)
needle = '''            value = self.c.execute(select(attempts).where(attempts.c.run_id == self.run["id"])
                .order_by(attempts.c.created_at, attempts.c.id)).mappings().all()
'''
assert after.count(needle) == 1
after = after.replace(needle,
    '            if self.raw_seed is None:\n' + ''.join('    '+line if line.strip() else line for line in needle.splitlines(keepends=True)) +
    '            else:\n'
    '                self.raw_seed.check(self.store, self.c, self.run["principal_id"], self.run, self.contract)\n'
    '                # Native audit ordered by id; history keeps SQL created_at/id order, NULL first.\n'
    '                value = sorted(copy.deepcopy(self.raw_seed.rows["attempts"]),\n'
    '                    key=lambda row: (row["created_at"] is not None, row["created_at"], row["id"]))\n', 1)
needle = '            value = self.c.execute(select(operations).where(operations.c.run_id == self.run["id"])).mappings().all()\n'
assert after.count(needle) == 1
after = after.replace(needle,
    '            if self.raw_seed is None:\n    ' + needle +
    '            else:\n'
    '                self.raw_seed.check(self.store, self.c, self.run["principal_id"], self.run, self.contract)\n'
    '                value = copy.deepcopy(self.raw_seed.rows["operations"])\n', 1)
after = after.replace('def _cold_generation_source(store, c, run, guard):',
    'def _cold_generation_source(store, c, run, guard, *, raw_seed=None):', 1)
needle = '''    if type(guard) is not _ColdGraphRead:
        raise DomainError("VERSION_CONFLICT", "Exact Cold read scope required")
    try:
        reader = _GenerationFactsReader(store, c, run, guard)
'''
assert after.count(needle) == 1
after = after.replace(needle,
    '    try:\n'
    '        if type(guard) is not _ColdGraphRead:\n'
    '            raise DomainError("VERSION_CONFLICT", "Exact Cold read scope required")\n'
    '        reader = _GenerationFactsReader(store, c, run, guard)\n', 1)
needle = '        reader.contract, reader.material = contract, material\n'
assert after.count(needle) == 1
after = after.replace(needle, needle +
    '        if raw_seed is not None:\n'
    '            if type(raw_seed) is not _ColdGenerationRawSeed:\n'
    '                raise DomainError("VERSION_CONFLICT", "Exact Generation raw seed required")\n'
    '            raw_seed.check(store, c, run["principal_id"], run, contract)\n'
    '            if raw_seed.guard is not guard:\n'
    '                raise DomainError("VERSION_CONFLICT", "Generation raw seed belongs to another read scope")\n'
    '            reader.raw_seed = reader._raw_seed_initial = raw_seed\n', 1)
start = after.index('def _cold_generation_source(')
end = after.index('\ndef _cold_history_from_source(', start)
section = after[start:end]
needle = '    except BaseException:\n        guard.invalidate()\n        raise\n'
assert section.count(needle) == 1
section = section.replace(needle,
    '    except BaseException:\n'
    '        if type(guard) is _ColdGraphRead:\n'
    '            guard.invalidate()\n'
    '        if type(raw_seed) is _ColdGenerationRawSeed:\n'
    '            raw_seed.invalidate()\n'
    '        raise\n', 1)
after = after[:start] + section + after[end:]
old, new = ast.parse(before), ast.parse(after)
allow = {'_GenerationFactsReader', '_ColdGenerationRawSeed', '_cold_generation_source'}
def outside(tree):
    return [ast.dump(n,include_attributes=False) for n in tree.body
        if not (isinstance(n,(ast.ClassDef,ast.FunctionDef)) and n.name in allow)]
assert outside(old) == outside(new)
def execute_calls(tree):
    return sorted(ast.dump(n,include_attributes=False) for n in ast.walk(tree)
        if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='execute')
assert execute_calls(old) == execute_calls(new)
diff = ''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),
    fromfile='a/src/sim2act/goal_applications.py',tofile='b/src/sim2act/goal_applications.py'))
(out/'generation-raw-seed-base.py').write_text(before)
(out/'generation-raw-seed-proposed.py').write_text(after)
(out/'generation-raw-seed.patch').write_text(diff)
proof = dict(kind='EXTERNAL_GOAL_ONLY_STDLIB_AST_NOT_PRODUCT',
    before_sha256=hashlib.sha256(before.encode()).hexdigest(),after_sha256=hashlib.sha256(after.encode()).hexdigest(),
    patch_sha256=hashlib.sha256(diff.encode()).hexdigest(),patch_bytes=len(diff.encode()),
    outside_allowed_nodes_ast_equal=True,all_existing_execute_calls_ast_equal=True,
    new_seed_sql_calls=0,tests_or_product_imports_run=False)
(out/'generation-raw-seed-static.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof))
