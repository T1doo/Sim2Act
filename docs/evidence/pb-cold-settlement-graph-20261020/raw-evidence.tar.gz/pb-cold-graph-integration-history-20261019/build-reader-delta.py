"""Stdlib-only external patch builder. Does not import or modify repository code."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import textwrap

out = Path('/workspace/pb-cold-graph-integration-history-20261019')
path = Path('/workspace/Sim2Act/src/sim2act/goal_applications.py')
before = path.read_text()
start = before.index('class _GenerationFactsReader:')
end = before.index('\ndef read_receipt(store, c, run, call):', start)
section = before[start:end]
section = section.replace('        self.raw_reads = []\n', '        self.raw_reads = []\n        self._raw_cache = {}\n', 1)
at = section.index('    def source(self):')
helpers = '''    def invalidate(self):
        # Always poison the originally installed scope, even if a pointer drifted.
        if self._guard_initial is not None:
            self._guard_initial.invalidate()

    def _raw_key(self, name, *parts):
        self.check()
        if self.guard is None:
            return (name, *parts)
        return (self.run_pin["principal_id"], self.run_pin["project_id"],
                self.run_pin["runtime_id"], self.run_pin["id"], name, *parts)

    def _raw_present(self, key):
        self.check()
        return self.guard is not None and key in self._raw_cache

    def _raw_get(self, key):
        self.check()
        name, entry = self._raw_cache[key]
        if (self.guard.inputs.get(name) is not entry
                or tuple(entry["key"]) != key):
            raise DomainError("VERSION_CONFLICT", "Generation raw fact rebound")
        self.check()
        return entry["value"]

    def _raw_put(self, key, label, value):
        self.check()
        if self.guard is None:
            return value
        if key in self._raw_cache:
            raise DomainError("VERSION_CONFLICT", "Generation raw fact cannot be replaced")
        name = "generation:" + self.run["id"] + ":" + str(len(self.raw_reads)) + ":raw-" + label
        entry = self.record("raw-" + label, dict(key=list(key), value=value))
        self._raw_cache[key] = (name, entry)
        self.check()
        return entry["value"]

'''
section = section[:at] + helpers + section[at:]

# Each method retains its own original SQL and read position. No supplied query,
# selector or callback is introduced; absent values and whole event lists cache too.
names = {
    'ordered_attempts': ('"attempts"', '"attempts"'),
    'counter_operations': ('"counter-operations"', '"counter-operations"'),
    '_anchors': ('"anchors", kind', 'kind'),
    'read_operation': ('"read-operation", "ga_read"', '"read-operation"'),
    'checker_operation': ('"checker-operation", "ga_spec_check"', '"checker-operation"'),
    'intent': ('"operation-intent", op["id"]', '"operation-intent"'),
    'checker_response': ('"checker-response", 1', '"checker-response"'),
}
tree = ast.parse(section)
klass = tree.body[0]
lines = section.splitlines(keepends=True)
edits = []
for item in klass.body:
    if not isinstance(item, ast.FunctionDef) or item.name not in names:
        continue
    text = ''.join(lines[item.lineno-1:item.end_lineno])
    args, label = names[item.name]
    # Keep original kind validation before its first raw SQL access.
    needle = '        self.check()\n        value = self.c.execute('
    assert needle in text, item.name
    text = text.replace(needle,
        '        key = self._raw_key(' + args + ')\n'
        '        if self._raw_present(key):\n'
        '            return self._raw_get(key)\n'
        '        self.check()\n        value = self.c.execute(', 1)
    old = 'return self.record(' + label + ', value)'
    assert old in text, item.name
    text = text.replace(old, 'return self._raw_put(key, ' + label + ', value)', 1)
    edits.append((item.lineno-1,item.end_lineno,text))
for a,b,value in reversed(edits):
    lines[a:b] = [value]
section = ''.join(lines)

# Sticky failure applies even when a caller catches within the same with block.
# Defaults have no guard, so original IO/error order and result values remain.
tree = ast.parse(section)
lines = section.splitlines(keepends=True)
edits = []
for item in tree.body[0].body:
    if not isinstance(item, ast.FunctionDef) or item.name in {'__init__', 'invalidate'}:
        continue
    text = ''.join(lines[item.lineno-1:item.end_lineno])
    head, body = text.split('\n',1)
    wrapped = head + '\n        try:\n' + textwrap.indent(body, '    ')
    wrapped += ('        except BaseException:\n'
                '            self.invalidate()\n'
                '            raise\n')
    edits.append((item.lineno-1,item.end_lineno,wrapped))
for a,b,value in reversed(edits):
    lines[a:b]=[value]
section = ''.join(lines)

section = section.replace('                if (self.authorities != tuple(self.source_pin["authorities"])',
    '                if self.contract is None:\n'
    '                    raise DomainError("VERSION_CONFLICT", "Missing complete generation contract")\n'
    '                if (self.authorities != tuple(self.source_pin["authorities"])', 1)

# Extend the existing producer try blocks to cover validation/role computation,
# including exceptions before the first history read or candidate SQL.
source_old = '    reader = _GenerationFactsReader(store, c, run, guard)\n    try:\n'
assert source_old in section
section = section.replace(source_old, '    try:\n        reader = _GenerationFactsReader(store, c, run, guard)\n', 1)
tree = ast.parse(section)
lines = section.splitlines(keepends=True)
edits=[]
for fn in tree.body:
    if not isinstance(fn,ast.FunctionDef) or fn.name not in {'_cold_generation_reader', '_cold_history_from_source','_cold_candidate_from_history'}:
        continue
    text = ''.join(lines[fn.lineno-1:fn.end_lineno])
    head, body = text.split('\n',1)
    if fn.name == '_cold_generation_reader':
        merged = body
    else:
        old_try = body.index('    try:\n')
        old_except = body.rindex('    except BaseException:\n')
        prefix = body[:old_try]
        original_body = textwrap.dedent(body[old_try+len('    try:\n'):old_except])
        # Body before the old try already used 4-space indentation; inner code used 8.
        merged = prefix + textwrap.indent(original_body, '    ')
    wrapped = head + '\n    try:\n' + textwrap.indent(merged, '    ')
    wrapped += ('    except BaseException:\n'
                '        if type(reader) is _GenerationFactsReader:\n'
                '            reader.invalidate()\n'
                '        raise\n')
    edits.append((fn.lineno-1,fn.end_lineno,wrapped))
for a,b,value in reversed(edits):
    lines[a:b] = [value]
section = ''.join(lines)
after = before[:start] + section + before[end:]
ast.parse(after)
assert before[:start] == after[:start]
assert before[end:] == after[after.index('\ndef read_receipt(store, c, run, call):', start):]

for text, name in [(before,'generation-reader-v2-base.py'), (after,'generation-reader-memo-proposed.py')]:
    (out/name).write_text(text)
diff = ''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),
    fromfile='a/src/sim2act/goal_applications.py',tofile='b/src/sim2act/goal_applications.py'))
(out/'generation-reader-memo.patch').write_text(diff)
(out/'generation-reader-memo-static.json').write_text(json.dumps(dict(
    kind='STDLIB_AST_ONLY_NOT_PRODUCT_EXECUTION', path=str(path),
    before_sha256=hashlib.sha256(before.encode()).hexdigest(),
    after_sha256=hashlib.sha256(after.encode()).hexdigest(),
    patch_sha256=hashlib.sha256(diff.encode()).hexdigest(),
    patch_bytes=len(diff.encode()), parse='PASS', scope='goal reader + its three strict producers only',
    default_sql='original fixed SQL expressions retained at original first-use positions',
    strict_memo=['ordered_attempts','counter_operations','anchors(kind)','read_operation','checker_operation','intent(operation_id)','checker_response(generation_index=1)'],
    tests_run=False), indent=2)+'\n')
print(json.dumps(dict(patch=str(out/'generation-reader-memo.patch'),bytes=len(diff.encode()),sha256=hashlib.sha256(diff.encode()).hexdigest())))
