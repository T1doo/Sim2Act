from pathlib import Path
import ast, difflib, hashlib, json, re
root=Path('/workspace/Sim2Act');out=Path(__file__).parent
paths=['src/sim2act/goal_applications.py','src/sim2act/pa_spec_apps.py']
original={p:(root/p).read_text() for p in paths};edited=dict(original)
def fn(src,name):
 t=ast.parse(src);n=next(n for n in t.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name)
 return ast.get_source_segment(src,n)
def replace_fn(path,name,value):
 old=fn(edited[path],name);assert edited[path].count(old)==1;edited[path]=edited[path].replace(old,value)
def once(s,old,new):
 pattern=(r"(?m)^" if old.startswith(" ") else "")+re.escape(old)
 matches=list(re.finditer(pattern,s));assert len(matches)==1,(old[:100],len(matches))
 match=matches[0];return s[:match.start()]+new+s[match.end():]
ga,pa=paths
# Preserve the public source gate and move only its remaining exact body.
s=fn(edited[ga],'source');s=once(s,'    source_scope_gate(store, c, run["id"])\n','')
s=s.replace('def source(store, c, run):','def _source_body(store, c, run, reader=None):',1)
s=once(s,'    contract = store.frozen_contract(c, run)\n','    contract = store.frozen_contract(c, run)\n    if reader is not None:\n        reader.check()\n')
s=once(s,'    frozen_source = [','    if reader is not None:\n        reader.check()\n    frozen_source = [')
replace_fn(ga,'source','def source(store, c, run):\n    source_scope_gate(store, c, run["id"])\n    return _source_body(store, c, run)\n\n\n'+s)
# Same initial-message body; keep default SPEC delegated public IO unchanged.
s=fn(edited[ga],'initial_messages');split=s.index('    from .agent_apps import schemas')
leaf='def _initial_messages_from_facts(contract, material):\n    if contract.application_generation.version in SPEC_GENERATIONS:\n        from .pa_spec_apps import _initial_messages_from_facts as spec_messages\n        return spec_messages(contract, material)\n'+s[split:]
wrapper=s[:split]+'    return _initial_messages_from_facts(contract, material)'
replace_fn(ga,'initial_messages',wrapper+'\n\n\n'+leaf)
reader='''class _GenerationFactsReader:
    """Fixed original Generation SQL positions; no callback/selector or authority token."""

    def __init__(self, store, c, run, guard=None):
        self.store, self.c, self.run, self.guard = store, c, run, guard
        self._guard_initial = guard
        self.source_record_name = None
        self.contract = self.material = self.source_pin = None
        self.authorities = ()
        self.history_value = None
        self.candidate_values = {}
        self.run_pin = copy.deepcopy(dict(run))
        self.raw_reads = []
        self.check()
        if guard is not None:
            guard.add("generation:" + run["id"] + ":run", self.run_pin)
            self.check()

    def check(self):
        if self.guard is not self._guard_initial:
            if self._guard_initial is not None:
                self._guard_initial.invalidate()
            raise DomainError("VERSION_CONFLICT", "Generation read scope pointer changed")
        if self.guard is None:
            return
        from .natural_spec_runtime import _cold_read_checkpoint
        _cold_read_checkpoint(self.store, self.c, self.guard)
        if dict(self.run) != self.run_pin:
            self.guard.invalidate()
            raise DomainError("VERSION_CONFLICT", "Generation Run input changed")
        if self.source_pin is not None:
            if (self.source_record_name is not None
                    and self.guard.inputs.get(self.source_record_name) is not self.source_pin):
                self.guard.invalidate()
                raise DomainError("VERSION_CONFLICT", "Generation source anchor rebound")
            if (self.authorities != tuple(self.source_pin["authorities"])
                    or dict(self.run) != self.source_pin["run"]
                    or self.contract.model_dump() != self.source_pin["contract"]
                    or self.material != self.source_pin["material"]):
                self.guard.invalidate()
                raise DomainError("VERSION_CONFLICT", "Generation source facts changed")

    def record(self, label, value):
        self.check()
        if self.guard is not None:
            raw = copy.deepcopy(value)
            self.guard.add("generation:" + self.run["id"] + ":" + str(len(self.raw_reads)) + ":" + label, raw)
            self.raw_reads.append((label, raw))
        self.check()
        return raw if self.guard is not None else value

    def source(self):
        if self.guard is None:
            return source(self.store, self.c, self.run)
        self.check()
        if self.source_pin is None:
            raise DomainError("VERSION_CONFLICT", "Missing complete generation source")
        self.store.own_project(self.c, self.run["principal_id"], self.run["project_id"])
        self.check()
        self.store.recheck_proof_authorities(self.c, {"_call_authorities": self.authorities})
        self.check()
        return self.contract, self.material

    def frozen(self):
        if self.guard is None:
            return self.store.frozen_contract(self.c, self.run)
        self.check()
        if self.source_pin is None:
            raise DomainError("VERSION_CONFLICT", "Missing frozen generation contract")
        return self.contract

    def initial(self):
        if self.guard is None:
            return initial_messages(self.store, self.c, self.run)
        contract, material = self.source()
        value = _initial_messages_from_facts(contract, material)
        self.check()
        return value

    def ordered_attempts(self):
        self.check()
        value = self.c.execute(select(attempts).where(attempts.c.run_id == self.run["id"])
            .order_by(attempts.c.created_at, attempts.c.id)).mappings().all()
        self.check()
        return self.record("attempts", value)

    def counter_operations(self):
        self.check()
        value = self.c.execute(select(operations).where(operations.c.run_id == self.run["id"])).mappings().all()
        self.check()
        return self.record("counter-operations", value)

    def _anchors(self, kind):
        if kind not in {"GA_RECEIVED", "GA_WIRE_RESERVED", "GA_DIAGNOSTIC", "GA_SPEC_CHECKED",
                        "GA_CANDIDATE_VALIDATED", "GA_APP_CONFIRMED"}:
            raise DomainError("VERSION_CONFLICT", "Unknown generation evidence kind")
        self.check()
        value = self.c.execute(select(events.c.data).where(events.c.run_id == self.run["id"],
            events.c.kind == kind)).scalars().all()
        self.check()
        return self.record(kind, value)

    def read_operation(self):
        self.check()
        value = self.c.execute(select(operations).where(operations.c.run_id == self.run["id"],
            operations.c.call_id == "ga_read")).mappings().first()
        self.check()
        return self.record("read-operation", value)

    def checker_operation(self):
        self.check()
        value = self.c.execute(select(operations).where(operations.c.run_id == self.run["id"],
            operations.c.call_id == "ga_spec_check")).mappings().first()
        self.check()
        return self.record("checker-operation", value)

    def intent(self, op):
        self.check()
        value = self.c.execute(select(operation_intents.c.request).where(
            operation_intents.c.operation_id == op["id"])).scalar()
        self.check()
        return self.record("operation-intent", value)

    def checker_response(self):
        self.check()
        value = self.c.execute(select(attempts.c.response).where(attempts.c.run_id == self.run["id"],
            attempts.c.parameters["generation_index"].as_integer() == 1)).scalar()
        self.check()
        return self.record("checker-response", value)

    def parsed_generation(self, raw, selected):
        value = parse_generation(raw, selected)
        self.check()
        return value

    def normalized_usage(self, raw):
        value = normalize_usage(raw)
        self.check()
        return value

    def read_receipt(self, call):
        if self.guard is None:
            return read_receipt(self.store, self.c, self.run, call)
        return _read_receipt_core(self, call)

    def check_receipt(self, call):
        from .pa_spec_apps import check_receipt, _check_receipt_core
        value = (check_receipt(self.store, self.c, self.run, call) if self.guard is None
                 else _check_receipt_core(self, call))
        self.check()
        return value


def _cold_generation_reader(store, c, run, reader):
    if (type(reader) is not _GenerationFactsReader or reader.guard is None
            or reader.store is not store or reader.c is not c or dict(reader.run) != dict(run)):
        if type(reader) is _GenerationFactsReader and reader.guard is not None:
            reader.guard.invalidate()
        raise DomainError("VERSION_CONFLICT", "Exact original generation facts reader required")
    reader.check()
    return reader


def _cold_generation_source(store, c, run, guard):
    """One full original source proof; no candidate/history or app proof is published."""
    from .natural_spec_runtime import _ColdGraphRead
    from .natural_specs import GENERATION
    if type(guard) is not _ColdGraphRead:
        raise DomainError("VERSION_CONFLICT", "Exact Cold read scope required")
    reader = _GenerationFactsReader(store, c, run, guard)
    try:
        # The original scalar family/owner/authority gate; never a candidate verifier.
        with store.proof_authorities(c) as authorities:
            _source_scope_gate(store, c, run["id"])
            reader.check()
            contract, material = _source_body(store, c, run, reader)
            reader.check()
        if (contract.application_generation.version != GENERATION
                or contract.application_generation.activation is not None
                or run["principal_id"] != guard.binding.contract.principal_id
                or run["project_id"] != guard.binding.contract.project_id):
            raise DomainError("VERSION_CONFLICT", "Cold Generation source role changed")
        reader.contract, reader.material = contract, material
        reader.authorities = tuple(sorted(authorities))
        reader.source_pin = dict(run=copy.deepcopy(dict(run)),
            contract=copy.deepcopy(contract.model_dump()), material=copy.deepcopy(material),
            authorities=list(reader.authorities))
        reader.source_pin = reader.record("complete-source", reader.source_pin)
        reader.source_record_name = "generation:" + run["id"] + ":0:complete-source"
        reader.check()
        return contract, material, reader
    except BaseException:
        guard.invalidate()
        raise


def _cold_history_from_source(store, c, run, contract, material, reader):
    reader = _cold_generation_reader(store, c, run, reader)
    if reader.contract is not contract or reader.material is not material or reader.history_value is not None:
        reader.guard.invalidate()
        raise DomainError("VERSION_CONFLICT", "Generation history inputs missing or rebound")
    try:
        value = _history_core(reader)
        reader.check()
        reader.history_value = reader.record("complete-history",
            (value[0], [dict(row) for row in value[1]]))
        return reader.history_value
    except BaseException:
        reader.guard.invalidate()
        raise


def _cold_candidate_from_history(store, c, run, contract, material, history_value, limits, reader):
    reader = _cold_generation_reader(store, c, run, reader)
    from .contracts import Limits
    if limits is not None and type(limits) is not Limits:
        reader.guard.invalidate()
        raise DomainError("VERSION_CONFLICT", "Exact complete candidate Limits required")
    role = ("NONE",) if limits is None else ("LIMITS", fingerprint(limits.model_dump()))
    if (reader.contract is not contract or reader.material is not material
            or reader.history_value is not history_value or role in reader.candidate_values):
        reader.guard.invalidate()
        raise DomainError("VERSION_CONFLICT", "Complete Generation history missing or rebound")
    try:
        # Preserve None as a separate role; history always used frozen generation Limits.
        reader.record("candidate-role", None if limits is None else limits.model_dump())
        _, rows = history_value
        last = _candidate_attempt_from_history(contract, rows)
        reader.check()
        value = _parse_candidate_core(reader, last["response"], limits or contract.limits)
        reader.check()
        seal = _candidate_validation_seal(rows[-1], value)
        reader.check()
        recorded = reader._anchors("GA_CANDIDATE_VALIDATED")
        value = _candidate_from_checked_facts(value, seal, recorded)
        reader.check()
        reader.candidate_values[role] = reader.record("complete-candidate", value)
        return reader.candidate_values[role]
    except BaseException:
        reader.guard.invalidate()
        raise
'''
# Shared complete history: identical statements/predicates, fixed reader IO at old positions.
s=fn(edited[ga],'_history')
s=s.replace('def _history(store, c, run):','def _history_core(reader):',1)
s=once(s,'    messages = initial_messages(store, c, run)','    store, c, run = reader.store, reader.c, reader.run\n    messages = initial_messages(store, c, run)')
s=once(s,'messages = initial_messages(store, c, run)','messages = reader.initial()')
s=s.replace('store.frozen_contract(c, run)','reader.frozen()')
a=s.index('    rows = (');b=s.index('    if len(rows) > 3:',a)
s=s[:a]+'    rows = reader.ordered_attempts()\n    _check_counters_core(reader, rows)\n'+s[b:]
a=s.index('        seals = (');b=s.index('        expected = {',a)
s=s[:a]+'        seals = reader._anchors("GA_RECEIVED")\n'+s[b:]
a=s.index('        reserved = (');b=s.index('        wire_seal = {',a)
s=s[:a]+'        reserved = reader._anchors("GA_WIRE_RESERVED")\n'+s[b:]
s=once(s,'receipt = read_receipt(store, c, run, calls[0])','receipt = reader.read_receipt(calls[0])')
s=once(s,'                from .pa_spec_apps import check_receipt\n','')
s=once(s,'receipt = check_receipt(store, c, run, calls[0])','receipt = reader.check_receipt(calls[0])')
a=s.index('                sealed = (');b=s.index('                if {"attempt_id"',a)
s=s[:a]+'                sealed = reader._anchors("GA_DIAGNOSTIC")\n'+s[b:]
# Fixed pin immediately after callbacks whose output is then consumed.
s=s.replace('        tools = stage_tools(selected, index)\n','        tools = stage_tools(selected, index)\n        reader.check()\n')
s=s.replace('        wire = body(messages, tools, parameters["max_tokens"])\n','        wire = body(messages, tools, parameters["max_tokens"])\n        reader.check()\n')
s=s.replace('            canonical, metadata = response_archive(archived)\n','            canonical, metadata = response_archive(archived)\n            reader.check()\n')
s=s.replace('parse_generation(archived, selected)[0]', 'reader.parsed_generation(archived, selected)[0]')
s=s.replace('normalize_usage(archived)', 'reader.normalized_usage(archived)')
s=s.replace('        require_returned_model(identity)\n','        reader.check()\n        require_returned_model(identity)\n        reader.check()\n')
s=s.replace('        messages.append(copy.deepcopy(attempt["response"]))\n','        reader.check()\n        messages.append(copy.deepcopy(attempt["response"]))\n')
s=s.replace('        validate_run(store, c, run)\n','        validate_run(store, c, run)\n        reader.check()\n')
s=s.replace('    return messages, rows','    reader.check()\n    return messages, rows')
replace_fn(ga,'_history','def _history(store, c, run):\n    return _history_core(_GenerationFactsReader(store, c, run))\n\n\n'+s+'\n\n\n'+reader)
# Shared original read-receipt predicate, default IO unchanged and no public source for graph.
s=fn(edited[ga],'read_receipt');s=s.replace('def read_receipt(store, c, run, call):','def _read_receipt_core(reader, call):\n    run = reader.run',1)
a=s.index('    op = (');b=s.index('    expected = {',a)
s=s[:a]+'    op = reader.read_operation()\n    intent = None if not op else reader.intent(op)\n'+s[b:]
s=s.replace('"data": source(store, c, run)[1]','"data": reader.source()[1]')
s=s.replace('    return op["receipt"]','    reader.check()\n    return op["receipt"]')
replace_fn(ga,'read_receipt','def read_receipt(store, c, run, call):\n    return _read_receipt_core(_GenerationFactsReader(store, c, run), call)\n\n\n'+s)
# Shared parser, preserves source locations and default delegated family IO.
s=fn(edited[ga],'parse_candidate');s=s.replace('def parse_candidate(store, c, run, message, limits):','def _parse_candidate_core(reader, message, limits):\n    store, c, run = reader.store, reader.c, reader.run',1)
s=s.replace('source(store, c, run)','reader.source()')
s=s.replace('        from .pa_spec_apps import check_receipt, from_response','        from .pa_spec_apps import from_response, _from_response_from_facts')
a=s.index('        checked = c.execute(');b=s.index('        if checked:',a)
s=s[:a]+'        checked = reader.checker_response()\n'+s[b:]
s=s.replace('receipt = check_receipt(store, c, run, call)','receipt = reader.check_receipt(call)')
s=once(s,'        return from_response(store, c, run, value)','        if reader.guard is None:\n            return from_response(store, c, run, value)\n        contract, material = reader.source()\n        result = _from_response_from_facts(run, contract, material, value, reader=reader)\n        reader.check()\n        return result')
s=s.replace('    manifest, action, _ = compile_preview(value, limits)\n','    manifest, action, _ = compile_preview(value, limits)\n    reader.check()\n')
s=s.replace('    return value','    reader.check()\n    return value')
replace_fn(ga,'parse_candidate','def parse_candidate(store, c, run, message, limits):\n    return _parse_candidate_core(_GenerationFactsReader(store, c, run), message, limits)\n\n\n'+s)
# Counters retain frozen contract and typed-row-before-Operations ordering.
s=fn(edited[ga],'check_counters');s=s.replace('def check_counters(store, c, run, rows):','def _check_counters_core(reader, rows):\n    run = reader.run',1)
s=s.replace('contract = store.frozen_contract(c, run)','contract = reader.frozen()')
s=once(s,'    count_tools = (\n        c.execute(select(operations).where(operations.c.run_id == run["id"])).mappings().all()\n    )','    reader.check()\n    count_tools = reader.counter_operations()')
s+='\n    reader.check()'
replace_fn(ga,'check_counters','def check_counters(store, c, run, rows):\n    return _check_counters_core(_GenerationFactsReader(store, c, run), rows)\n\n\n'+s)
# pa-spec pure message/from_response cores; public natural default still performs original source IO.
checkpoint='''def _generation_reader_checkpoint(reader):
    if reader is None:
        return
    from .goal_applications import _GenerationFactsReader
    require(type(reader) is _GenerationFactsReader, "Exact Generation facts reader required")
    reader.check()


'''
edited[pa]=edited[pa].replace('def initial_messages(store, c, run):',checkpoint+'def initial_messages(store, c, run):',1)
s=fn(edited[pa],'initial_messages');cut=s.index('    oracle.source_checklist(material)')
leaf='def _initial_messages_from_facts(contract, material):\n    if contract.application_generation.version == natural.GENERATION:\n        return natural._initial_messages_from_facts(contract, material)\n'+s[cut:]
replace_fn(pa,'initial_messages',s[:cut]+'    return _initial_messages_from_facts(contract, material)\n\n\n'+leaf)
s=fn(edited[pa],'from_response');cut=s.index('    if not isinstance(value, dict)')
leaf='def _from_response_from_facts(run, contract, material, value, *, reader=None):\n    if contract.application_generation.version == natural.GENERATION:\n        result = natural._from_response_from_facts(run, contract, material, value)\n        if reader is not None:\n            reader.check()\n        return result\n'+s[cut:]
for line in ['    checked = oracle.verify_candidate(material, json.dumps(value["sample_checklist"], ensure_ascii=False))\n','    compile_candidate(result, selected.app_limits)\n','    preview(material, result, {})\n']:
 leaf=once(leaf,line,line+'    if reader is not None:\n        reader.check()\n')
# expand spans two source lines; pin before any next use.
leaf=once(leaf,'        selected.app_limits, fingerprint(checked))\n','        selected.app_limits, fingerprint(checked))\n    if reader is not None:\n        reader.check()\n')
replace_fn(pa,'from_response',s[:cut]+'    return _from_response_from_facts(run, contract, material, value)\n\n\n'+leaf)
# Shared checker report: exact original catch list and compilation branch.
s=fn(edited[pa],'check_report');s=s.replace('def check_report(store, c, run, candidate):\n    from .goal_applications import source\n\n    contract, material = source(store, c, run)','def _check_report_core(reader, candidate):\n    store, c, run = reader.store, reader.c, reader.run\n    contract, material = reader.source()',1)
s=once(s,'        compiled = from_response(store, c, run, candidate)','        if reader.guard is None:\n            compiled = from_response(store, c, run, candidate)\n        else:\n            current_contract, current_material = reader.source()\n            compiled = _from_response_from_facts(run, current_contract, current_material, candidate, reader=reader)\n        reader.check()')
s=s.replace('        status, diagnostic, plan_hash = "FAIL", exc.public(), None','        status, diagnostic, plan_hash = "FAIL", exc.public(), None\n    reader.check()')
replace_fn(pa,'check_report','def check_report(store, c, run, candidate):\n    from .goal_applications import _GenerationFactsReader\n    return _check_report_core(_GenerationFactsReader(store, c, run), candidate)\n\n\n'+s)
s=fn(edited[pa],'check_receipt');s=s.replace('def check_receipt(store, c, run, call):','def _check_receipt_core(reader, call):\n    store, c, run = reader.store, reader.c, reader.run',1)
s=s.replace('    args = check_call(store, c, run, call)\n','    args = check_call(store, c, run, call)\n    reader.check()\n')
a=s.index('    op = c.execute(');b=s.index('    if not op:',a)
s=s[:a]+'    op = reader.checker_operation()\n'+s[b:]
s=once(s,'    intent = c.execute(select(operation_intents.c.request).where(operation_intents.c.operation_id == op["id"])).scalar()','    intent = reader.intent(op)')
s=once(s,'    report = check_report(store, c, run, args["candidate"])','    report = (check_report(store, c, run, args["candidate"]) if reader.guard is None\n              else _check_report_core(reader, args["candidate"]))\n    reader.check()')
s=once(s,'    anchors = c.execute(select(events.c.data).where(events.c.run_id == run["id"], events.c.kind == "GA_SPEC_CHECKED")).scalars().all()','    anchors = reader._anchors("GA_SPEC_CHECKED")')
s=s.replace('    return receipt','    reader.check()\n    return receipt')
replace_fn(pa,'check_receipt','def check_receipt(store, c, run, call):\n    from .goal_applications import _GenerationFactsReader\n    return _check_receipt_core(_GenerationFactsReader(store, c, run), call)\n\n\n'+s)
# Original GA confirmation only; not a generic material-binding verifier.
extra='''def _cold_original_model_source(store, c, user, run, original, marker, raw, reader):
    """Original GA app confirmation using the complete candidate, never public ancestors.

    Root must have loaded the owned marker before Generation at its old position,
    and separately prove the original draft/platform/source after this confirmation.
    No rebind/spec_task/logic/correction family is accepted by this private facet.
    """
    from .goal_applications import _cold_generation_reader
    from .text_apps import (_goal_confirmation, _goal_acceptance_from_facts,
                            _verify_goal_origin_from_facts)
    reader = _cold_generation_reader(store, c, run, reader)
    require(any(value is raw for value in reader.candidate_values.values()) and marker is not None
        and marker["run_id"] == run["id"] and marker["app_id"] == original["id"]
        and marker["principal_id"] == user == run["principal_id"]
        and original["project_id"] == run["project_id"]
        and natural.is_candidate(raw) and natural.is_candidate(original["candidate"])
        and not {"spec_task", "spec_binding"}.intersection(original["candidate"])
        and not {"natural_logic_origin", "correction_run_id", "pb_use_run_id", "pa_use_run_id"}.intersection(original),
        "Exact original GA candidate facts required")
    reader.check()
    confirmation = _goal_confirmation(marker)
    reader.check()
    accepted = _goal_acceptance_from_facts(user, original, run, raw, confirmation)
    reader.check()
    sealed = reader._anchors("GA_APP_CONFIRMED")
    _verify_goal_origin_from_facts(user, original, marker, run, raw, confirmation, accepted, sealed)
    reader.check()
    # This is a confirmation facet, not full original App/Release authority.
    return raw, dict(project_id=run["project_id"], principal_id=user,
                     runtime_id=run["runtime_id"], resource_refs=copy.deepcopy(run["resource_refs"]))
'''
# Place after facade; its existing public implementation is unchanged.
s=fn(edited[pa],'model_source');replace_fn(pa,'model_source',s+'\n\n\n'+extra)
# Native audit remains a single complete row producer shared by public/strict callers.
s=fn(edited[pa],'audit_fingerprint')
cut=s.index('    from .db import attempts, goal_card_versions, goal_cards')
tail=s[cut:]
helper='def _native_audit_facts(store, c, user, draft, *, _graph_read=None):\n    """Original native audit rows; never an Authority or summary substitute."""\n    def checkpoint():\n        if _graph_read is not None:\n            from .natural_spec_runtime import _cold_read_checkpoint\n            _cold_read_checkpoint(store, c, _graph_read)\n\n    checkpoint()\n'+tail
helper=once(helper,'    return fingerprint(rows)','    checkpoint()\n    return rows')
# Each original query/callee must finish its read pin before a later body is consumed.
helper=once(helper,'    if marker:\n','    checkpoint()\n    if marker:\n')
helper=once(helper,'        rid = meta.source_run_id\n','        checkpoint()\n        rid = meta.source_run_id\n')
helper=once(helper,'        require(aid is not None)\n','        checkpoint()\n        require(aid is not None)\n')
helper=once(helper,'    require(scope_gate(store, c, user, aid))\n','    scoped = scope_gate(store, c, user, aid)\n    checkpoint()\n    require(scoped)\n')
helper=once(helper,'    source_scope_gate(store, c, rid)\n','    source_scope_gate(store, c, rid)\n    checkpoint()\n')
helper=once(helper,'    contract = c.execute(select(run_contracts).where(run_contracts.c.run_id == rid)).mappings().one()\n','    checkpoint()\n    contract = c.execute(select(run_contracts).where(run_contracts.c.run_id == rid)).mappings().one()\n    checkpoint()\n')
helper=once(helper,'    goal = contract["snapshot"]["source_goal_card"]\n','    checkpoint()\n    goal = contract["snapshot"]["source_goal_card"]\n')
helper=once(helper,'        rows[name] = [dict(r) for r in c.execute(query).mappings()]','        loaded = c.execute(query).mappings().all()\n        checkpoint()\n        rows[name] = [dict(r) for r in loaded]')
replace_fn(pa,'audit_fingerprint',s[:cut]+'    return fingerprint(_native_audit_facts(store, c, user, draft))\n\n\n'+helper)
edited[pa]=edited[pa].replace('    if reader is not None:\n        reader.check()','    _generation_reader_checkpoint(reader)')
edited[pa]=edited[pa].replace('        if reader is not None:\n            reader.check()','        _generation_reader_checkpoint(reader)')
edited[pa]=edited[pa].replace('def _from_response_from_facts(run, contract, material, value, *, reader=None):\n','def _from_response_from_facts(run, contract, material, value, *, reader=None):\n    _generation_reader_checkpoint(reader)\n')
edited[pa]=edited[pa].replace('def _check_report_core(reader, candidate):\n','def _check_report_core(reader, candidate):\n    _generation_reader_checkpoint(reader)\n')
edited[pa]=edited[pa].replace('def _check_receipt_core(reader, call):\n','def _check_receipt_core(reader, call):\n    _generation_reader_checkpoint(reader)\n')
# Explicit strict scope path; default calls do not send the new keyword.
s=fn(edited[ga],'source_scope_gate')
s=once(s,'def source_scope_gate(store, c, rid):','def source_scope_gate(store, c, rid, *, _graph_read=None):')
needle_scope='    from .pb_natural_specs import _source_reads_current\n'
strict='    if _graph_read is not None:\n        from .natural_spec_runtime import _cold_read_checkpoint\n        _cold_read_checkpoint(store, c, _graph_read)\n        result = _source_scope_gate(store, c, rid, _graph_read=_graph_read)\n        _cold_read_checkpoint(store, c, _graph_read)\n        return result\n'
s=once(s,needle_scope,strict+needle_scope);replace_fn(ga,'source_scope_gate',s)
s=fn(edited[ga],'_source_scope_gate')
s=once(s,'def _source_scope_gate(store, c, rid):','def _source_scope_gate(store, c, rid, *, _graph_read=None):')
s=once(s,'    from .local_record_apps import job_scope_gate as record_scope_gate\n','    def checkpoint():\n        if _graph_read is not None:\n            from .natural_spec_runtime import _cold_read_checkpoint\n            _cold_read_checkpoint(store, c, _graph_read)\n\n    checkpoint()\n    from .local_record_apps import job_scope_gate as record_scope_gate\n')
s=once(s,'    if record_scope_gate(store, c, rid):','    record_scoped = record_scope_gate(store, c, rid)\n    checkpoint()\n    if record_scoped:')
s=once(s,'    if metadata is not None:\n','    checkpoint()\n    if metadata is not None:\n')
s=once(s,'        if job_scope_gate(store, c, metadata["principal_id"], rid):','        spec_scoped = job_scope_gate(store, c, metadata["principal_id"], rid,\n            **({"_graph_read": _graph_read} if _graph_read is not None else {}))\n        checkpoint()\n        if spec_scoped:')
for old in [
 '        store.own_project(c, metadata["principal_id"], metadata["project_id"])\n',
 '        csv_revision_gate(store,c,metadata["principal_id"],rid)\n',
 '        csv_full_report_scope_gate(store, c, rid)\n',
 '        report_instance_gate(store, c, rid)\n',
 '        refs = c.execute(select(runs.c.resource_refs).where(runs.c.id == rid)).scalar_one()\n',
 '            store.authorize(c, metadata["principal_id"], metadata["runtime_id"], metadata["project_id"], resource_id, "resource.read")\n',
 '        correction_scope_gate(store, c, rid)\n']:
 indent=old[:len(old)-len(old.lstrip())];s=once(s,old,old+indent+'checkpoint()\n')
s=once(s,'    anchored = c.execute(select(\n','    checkpoint()\n    anchored = c.execute(select(\n')
s=once(s,'    marked = any(','    checkpoint()\n    marked = any(')
s=once(s,'        job_scope_gate(store, c, metadata["principal_id"], rid) if metadata else None','        if metadata:\n            job_scope_gate(store, c, metadata["principal_id"], rid,\n                **({"_graph_read": _graph_read} if _graph_read is not None else {}))\n            checkpoint()')
s=once(s,'    store.own_project(c, metadata["principal_id"], metadata["project_id"])\n','    store.own_project(c, metadata["principal_id"], metadata["project_id"])\n    checkpoint()\n')
s=once(s,'        metadata["project_id"], metadata["resource_refs"][0], "resource.read")\n','        metadata["project_id"], metadata["resource_refs"][0], "resource.read")\n    checkpoint()\n')
s=once(s,'        meta = _meta(store, c, metadata["principal_id"], aid, content=True)\n','        meta = _meta(store, c, metadata["principal_id"], aid, content=True)\n        checkpoint()\n')
s=once(s,'        store.authorize(c, metadata["principal_id"], metadata["runtime_id"], metadata["project_id"], metadata["project_id"], "artifact.save_text")\n','        store.authorize(c, metadata["principal_id"], metadata["runtime_id"], metadata["project_id"], metadata["project_id"], "artifact.save_text")\n        checkpoint()\n')
replace_fn(ga,'_source_scope_gate',s)
# The strict source producer must request these inner checkpoints, not merely wrap the whole gate.
s=fn(edited[ga],'_cold_generation_source');s=once(s,'            _source_scope_gate(store, c, run["id"])','            _source_scope_gate(store, c, run["id"], _graph_read=guard)');replace_fn(ga,'_cold_generation_source',s)
s=fn(edited[pa],'scope_gate');s=once(s,'def scope_gate(store, c, user, aid):','def scope_gate(store, c, user, aid, *, _graph_read=None):')
s=once(s,'    from . import pb_natural_specs as pb\n','    def checkpoint():\n        if _graph_read is not None:\n            from .natural_spec_runtime import _cold_read_checkpoint\n            _cold_read_checkpoint(store, c, _graph_read)\n\n    checkpoint()\n    from . import pb_natural_specs as pb\n')
for old in [
 '    location = c.execute(_SCOPE_LOCATION, {"scope_app_id": aid}).mappings().first()\n',
 '    kind = c.execute(_SCOPE_KIND, {"scope_app_id": aid}).scalar()\n',
 '            pb.META, pb.META + "_seal", pb.EXTRACT, pb.EXTRACT + "_seal"])).first()\n',
 '        scope_kinds=[pb.META, pb.META + "_seal", pb.EXTRACT, pb.EXTRACT + "_seal"])).first()\n',
 '    confirmed = c.execute(_SCOPE_CONFIRMED, {"scope_app_id": aid}).first()\n',
 '        store.own_project(c, user, location["project_id"])\n',
 '        store.authorize(c, user, location["runtime_id"], location["project_id"], location["resource"], "resource.read")\n',
 '    gen = c.execute(_SCOPE_GENERATION, {"scope_app_id": aid}).scalar()\n',
 '    store.own_project(c, user, location["project_id"])\n',
 '        meta, sealed = pair(c, user, aid, META, "scope", Metadata)\n',
 '        origin = c.execute(_SCOPE_ORIGIN, {"scope_app_id": aid, "scope_principal": user}).scalar()\n',
 '    store.authorize(c, user, location["runtime_id"], location["project_id"], location["resource"], "resource.read")\n',
 '    store.authorize(c, user, location["runtime_id"], location["project_id"], location["project_id"], SAVE)\n']:
 # Multiline SQL terminal indentation is 4, rather than its closing continuation indent.
 indent='    ' if ')).first()' in old and old.lstrip().startswith(('pb.META','scope_kinds=')) else old[:len(old)-len(old.lstrip())]
 s=once(s,old,old+indent+'checkpoint()\n')
s=once(s,'        return pb.scope_gate(store, c, user, aid, location)','        result = pb.scope_gate(store, c, user, aid, location,\n            **({"_graph_read": _graph_read} if _graph_read is not None else {}))\n        checkpoint()\n        return result')
s=once(s,'        source_scope_gate(store, c, origin)','        source_scope_gate(store, c, origin,\n            **({"_graph_read": _graph_read} if _graph_read is not None else {}))\n        checkpoint()')
replace_fn(pa,'scope_gate',s)
# Strict raw native audit must also forward to these callee-owned checkpoints.
s=fn(edited[pa],'_native_audit_facts')
s=once(s,'    scoped = scope_gate(store, c, user, aid)','    scoped = scope_gate(store, c, user, aid,\n        **({"_graph_read": _graph_read} if _graph_read is not None else {}))')
s=once(s,'    source_scope_gate(store, c, rid)','    source_scope_gate(store, c, rid,\n        **({"_graph_read": _graph_read} if _graph_read is not None else {}))')
replace_fn(pa,'_native_audit_facts',s)
for rel,src in edited.items():
 ast.parse(src)
 base=out/'implementation-base'/rel;target=out/'implementation-edited'/rel
 base.parent.mkdir(parents=True,exist_ok=True);target.parent.mkdir(parents=True,exist_ok=True)
 base.write_text(original[rel]);target.write_text(src)
patch=''.join(''.join(difflib.unified_diff(original[p].splitlines(True),edited[p].splitlines(True),fromfile='a/'+p,tofile='b/'+p,n=3)) for p in paths)
(out/'implementation.patch').write_text(patch)
(out/'implementation-source-map.json').write_text(json.dumps({p:{'before':hashlib.sha256(original[p].encode()).hexdigest(),'after':hashlib.sha256(edited[p].encode()).hexdigest()} for p in paths},indent=2)+'\n')
print(json.dumps({'patch_bytes':len(patch.encode()),'paths':paths,'AST_parse':'PASS'},indent=2))
