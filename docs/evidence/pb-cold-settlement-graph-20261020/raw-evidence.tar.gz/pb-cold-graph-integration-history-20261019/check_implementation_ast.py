from pathlib import Path
import ast,hashlib,json,re
root=Path(__file__).parent
paths=['src/sim2act/goal_applications.py','src/sim2act/pa_spec_apps.py']
def nodes(s):return {n.name:n for n in ast.parse(s).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}
def dump(n):return ast.dump(n,include_attributes=False)
def fns(rel,kind):return nodes((root/kind/rel).read_text())
ga,pa=paths
changes={};protected={}
allowed={ga:{'source','initial_messages','_history','read_receipt','parse_candidate','check_counters','source_scope_gate','_source_scope_gate'},pa:{'initial_messages','from_response','check_report','check_receipt','audit_fingerprint','scope_gate'}}
for p in paths:
 a,b=fns(p,'implementation-base'),fns(p,'implementation-edited')
 changes[p]=[k for k in a if dump(a[k])!=dump(b[k])]
 assert set(changes[p])==allowed[p],changes[p]
 protected[p]={k:dump(a[k])==dump(b[k]) for k in a if k not in allowed[p]}
 assert all(protected[p].values())
# Compare complete original history If predicates/raises after replacing only reader access names.
class Norm(ast.NodeTransformer):
 def visit_Call(self,n):
  self.generic_visit(n)
  if isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='reader':
   name=n.func.attr
   if name=='frozen':return ast.parse('store.frozen_contract(c, run)',mode='eval').body
   if name in ('parsed_generation','normalized_usage'):
    return ast.Call(func=ast.Name(id={'parsed_generation':'parse_generation','normalized_usage':'normalize_usage'}[name],ctx=ast.Load()),args=n.args,keywords=n.keywords)
  return n
old=fns(ga,'implementation-base')['_history'];new=fns(ga,'implementation-edited')['_history_core']
def conditions(n):return [dump(Norm().visit(ast.fix_missing_locations(ast.parse(ast.unparse(x.test),mode='eval').body))) for x in ast.walk(n) if isinstance(x,ast.If)]
assert conditions(old)==conditions(new),'history conditional predicates changed'
def raises(n):return [dump(x) for x in ast.walk(n) if isinstance(x,ast.Raise)]
assert raises(old)==raises(new),'history exception predicates changed'
# The full history core still calls the original identity/usage/wire builders.
required={'body','stage_tools','returned_model_identity','require_returned_model','checked_usage','_check_counters_core'}
calls={n.func.id for n in ast.walk(new) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name)}
assert required<=calls
# Ensure history has exactly one ordered-Attempt read, original counter op ordering,
# and no direct public source/history/verified verifier calls in strict producer bodies.
for name in ('_cold_generation_source','_cold_history_from_source','_cold_candidate_from_history'):
 node=fns(ga,'implementation-edited')[name]
 called={n.func.id for n in ast.walk(node) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name)}
 assert not called & {'source','history','verified_candidate','_verified_candidate'}
# Four protected original business functions were not touched.
pb=fns(pa,'implementation-base');pe=fns(pa,'implementation-edited')
for name in ('bound','_bound','commit_guard','_commit_guard','receipts','verify_job'):
 if name in pb:assert dump(pb[name])==dump(pe[name])
# Native audit tail reproduces every original table/ordering predicate; only query materialization
# checkpoints and whole-row return are new. Preserve list specification AST exactly.
old_audit=pb['audit_fingerprint'];new_audit=pe['_native_audit_facts']
old_for=next(x for x in ast.walk(old_audit) if isinstance(x,ast.For) and isinstance(x.target,ast.Tuple))
new_for=next(x for x in ast.walk(new_audit) if isinstance(x,ast.For) and isinstance(x.target,ast.Tuple))
assert dump(old_for.iter)==dump(new_for.iter)
assert all(s in ast.unparse(new_audit) for s in ('"GA_' if False else 'goal_head','goal_version','confirmation','intents','attempts','operations','events'))
# Scope optional guards are explicit and default adds no actual keyword.
for rel,name in [(ga,'source_scope_gate'),(ga,'_source_scope_gate'),(pa,'scope_gate')]:
 n=fns(rel,'implementation-edited')[name]
 assert '_graph_read' in [a.arg for a in n.args.kwonlyargs]
 assert any(isinstance(x,ast.Call) and isinstance(x.func,ast.Name) and x.func.id in ('checkpoint','_cold_read_checkpoint') for x in ast.walk(n))
# Every newly forwarded guard uses conditional **{} on the default path.
for rel,name in [(ga,'_source_scope_gate'),(pa,'scope_gate'),(pa,'_native_audit_facts')]:
 n=fns(rel,'implementation-edited')[name]
 for call in (x for x in ast.walk(n) if isinstance(x,ast.Call)):
  for keyword in call.keywords:
   if keyword.arg is None and isinstance(keyword.value,ast.IfExp):
    assert isinstance(keyword.value.orelse,ast.Dict) and keyword.value.orelse.keys==[]
# Apply the generated unified diff in memory only and prove exact edited bytes.
patch=(root/'implementation.patch').read_text().splitlines(keepends=True);i=0;applied={}
while i<len(patch):
 assert patch[i].startswith('--- a/');rel=patch[i][6:].rstrip('\n');i+=1
 assert patch[i].startswith('+++ b/');i+=1
 base=(root/'implementation-base'/rel).read_text().splitlines(keepends=True);dst=[];pos=0
 while i<len(patch) and not patch[i].startswith('--- a/'):
  m=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',patch[i]);assert m,patch[i]
  start=int(m.group(1))-1;dst.extend(base[pos:start]);pos=start;i+=1
  while i<len(patch) and not patch[i].startswith(('@@ ','--- a/')):
   line=patch[i];i+=1
   if line[0] in ' -':assert base[pos]==line[1:];pos+=1
   if line[0] in ' +':dst.append(line[1:])
  
 dst.extend(base[pos:]);value=''.join(dst)
 assert value==(root/'implementation-edited'/rel).read_text()
 ast.parse(value);applied[rel]=hashlib.sha256(value.encode()).hexdigest()
report={'verdict':'PASS_STDLIB_AST_AND_IN_MEMORY_PATCH_ONLY','changed_existing_functions':changes,'all_other_existing_functions_AST_unchanged':all(all(v.values()) for v in protected.values()),'full_history_original_conditionals_and_errors_equal':True,'original_native_audit_table_query_sequence_AST_equal':True,'scope_optional_guard_forwarding_and_default_no_keyword':True,'bound_receipts_commit_guard_unchanged':True,'patch_reconstructs_edited_sources_exactly':applied,'patch_sha256':hashlib.sha256((root/'implementation.patch').read_bytes()).hexdigest(),'product_import_test_DB_network_execution':0,'limitations':['No product import, pytest, Ruff, mypy, DB or complete integration executed','Root must review/apply against matching baseline; this is implementation draft, not independent runtime qualification']}
print(json.dumps(report,indent=2))
