"""Proposed pure encoder units. Not run by the independent reviewer.

No Store/Worker/authority, graph producer or semantic P-B acceptance.
One isolated in-memory SQLite metadata copy checks actual full RowMapping keys.
The private helper must first be applied by the repository's sole writer.
"""

import copy
import gc
from collections.abc import Mapping

import httpx
import pytest
from sqlalchemy import Column, MetaData, Table, create_engine, insert, select
from sqlalchemy.engine import RowMapping
from sqlalchemy.sql.elements import quoted_name

from sim2act import natural_spec_runtime as runtime
from sim2act.contracts import Limits
from sim2act.db import runs
from sim2act.errors import DomainError


@pytest.fixture(autouse=True)
def no_transports(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("CGR encoder units forbid every HTTP/Mock transport")

    for cls, name in ((httpx.HTTPTransport, "handle_request"),
            (httpx.AsyncHTTPTransport, "handle_async_request"),
            (httpx.MockTransport, "handle_request"),
            (httpx.MockTransport, "handle_async_request")):
        monkeypatch.setattr(cls, name, forbidden)


def limits():
    return Limits(max_requests=4, max_tools=4, max_repairs=1,
        max_total_tokens=64000, max_output_tokens=1024, run_seconds=300)


def inputs():
    first = dict(id="synthetic-attempt-A", usage=dict(input_tokens=100,
        output_tokens=20, total_tokens=120), wire=b"complete-request-A",
        response=b"complete-response-A")
    second = {**copy.deepcopy(first), "id": "synthetic-attempt-B"}
    shared = dict(goal=dict(version=1, fingerprint="synthetic-goal-fp",
        snapshot=dict(content="full current Goal", clauses=["one", "two"])),
        attempts=[first, second], anchors=[dict(kind="NS_RECEIVED",
        attempt_id=first["id"], data=dict(owner="owner-A", values=[1, 2]))])
    return dict(source=shared, cold=dict(ancestor=shared), roles={
        role: limits() for role in ("source", "generate", "platform", "trial", "per_use")})


@pytest.mark.parametrize("change", ["shared_deep", "goal", "usage", "wire",
    "response", "duplicate_anchor", "remove_anchor", "anchor_field", "attempt_order"])
def test_complete_current_fields_remain_detectable(change):
    value = inputs()
    before = copy.deepcopy(value)
    key, oracle = runtime._cold_graph_inputs(value), runtime._model_inputs(value)
    assert value == before and runtime._cold_graph_inputs(value) == key
    shared = value["source"]
    assert value["cold"]["ancestor"] is shared
    if change == "shared_deep":
        shared["goal"]["snapshot"]["clauses"][1] = "changed"
    elif change == "goal":
        shared["goal"]["snapshot"]["content"] += " changed"
    elif change == "usage":
        shared["attempts"][0]["usage"]["total_tokens"] += 1
    elif change == "wire":
        shared["attempts"][0]["wire"] += b" changed"
    elif change == "response":
        shared["attempts"][0]["response"] += b" changed"
    elif change == "duplicate_anchor":
        shared["anchors"].append(shared["anchors"][0])
    elif change == "remove_anchor":
        shared["anchors"].clear()
    elif change == "anchor_field":
        shared["anchors"][0]["data"]["owner"] = "owner-B"
    else:
        shared["attempts"].reverse()
    assert runtime._model_inputs(value) != oracle
    assert runtime._cold_graph_inputs(value) != key


@pytest.mark.parametrize("role", ["source", "generate", "platform", "trial", "per_use"])
@pytest.mark.parametrize("field", list(Limits.model_fields))
def test_each_full_role_limits_field_is_read_on_every_call(role, field):
    value = inputs()
    key, oracle = runtime._cold_graph_inputs(value), runtime._model_inputs(value)
    old = value["roles"][role]
    changed = old.model_dump()
    changed[field] -= 1
    value["roles"][role] = Limits(**changed)
    assert runtime._model_inputs(value) != oracle
    assert runtime._cold_graph_inputs(value) != key


def test_memo_is_per_call_and_complete_limits_dump_is_shared_only_within_call(monkeypatch):
    original = Limits.model_dump
    calls = []

    def dump(value, *args, **kwargs):
        calls.append(id(value))
        return original(value, *args, **kwargs)

    monkeypatch.setattr(Limits, "model_dump", dump)
    full = limits()
    value = dict(first=full, second=[full, dict(third=full)])
    first = runtime._cold_graph_inputs(value)
    assert calls == [id(full)]
    assert runtime._cold_graph_inputs(value) == first
    assert calls == [id(full), id(full)]
    full.max_output_tokens -= 1
    assert runtime._cold_graph_inputs(value) != first
    assert calls == [id(full)] * 3


def test_key_order_does_not_change_complete_alias_graph():
    shared = dict(z=[1, 2], a=dict(full=b"bytes"))
    left = dict(z=shared, a=dict(z=shared, a=limits()))
    right = dict(a=dict(a=left["a"]["a"], z=shared), z=shared)
    assert runtime._model_inputs(left) == runtime._model_inputs(right)
    assert runtime._cold_graph_inputs(left) == runtime._cold_graph_inputs(right)


def test_alias_topology_keeps_all_edges_and_list_tuple_kind():
    shared = dict(goal=dict(content="same"))
    aliased = dict(a=shared, b=shared)
    independent = dict(a=copy.deepcopy(shared), b=copy.deepcopy(shared))
    assert runtime._model_inputs(aliased) == runtime._model_inputs(independent)
    assert runtime._cold_graph_inputs(aliased) != runtime._cold_graph_inputs(independent)
    assert runtime._cold_graph_inputs([shared]) != runtime._cold_graph_inputs((shared,))


@pytest.mark.parametrize("kind", ["dict", "list", "mixed"])
def test_cycles_fail_instead_of_emitting_completed_refs(kind):
    if kind == "dict":
        value = {}
        value["self"] = value
    elif kind == "list":
        value = []
        value.append(value)
    else:
        value = []
        value.append((value,))
    with pytest.raises(DomainError):
        runtime._cold_graph_inputs(value)


def test_custom_mapping_and_string_key_methods_never_run():
    calls = []

    class Foreign(Mapping):
        def __iter__(self):
            calls.append("iter")
            raise AssertionError("Custom Mapping must be rejected before callback")

        def __getitem__(self, key):
            calls.append("get")
            raise AssertionError("Custom Mapping must be rejected before callback")

        def __len__(self):
            calls.append("len")
            raise AssertionError("Custom Mapping must be rejected before callback")

    class ForeignKey(str):
        def __lt__(self, other):
            calls.append("sort")
            raise AssertionError("Custom key must be rejected before sort")

    class ForeignDict(dict):
        def keys(self):
            calls.append("keys")
            raise AssertionError("dict subclass must be rejected before callback")

    for value in (Foreign(), ForeignDict(a=1), {ForeignKey("z"): 1, "a": 2}):
        with pytest.raises(DomainError):
            runtime._cold_graph_inputs(value)
    assert calls == []


@pytest.mark.parametrize("value", [float("nan"), float("inf"), -float("inf")])
def test_nonfinite_values_remain_rejected_by_original_json_fingerprint(value):
    with pytest.raises(ValueError):
        runtime._cold_graph_inputs(dict(value=value))


def test_expanded_temporary_dicts_remain_alive_until_final_hash(monkeypatch):
    """Liveness, not probabilistic id reuse: no gc.collect/disable/tuning."""
    dump_original, hash_original = Limits.model_dump, runtime.fingerprint
    temporary_ids = []
    checked = []

    def dump(value, *args, **kwargs):
        result = dump_original(value, *args, **kwargs)
        # This synthetic dump-only key makes exact dicts GC tracked. No product
        # object is mutated and all original Limits fields remain present.
        result["__cgr_temporary_probe__"] = [len(temporary_ids)]
        temporary_ids.append(id(result))
        return result

    def hash_complete_dag(document):
        alive = {id(obj): obj["__cgr_temporary_probe__"] for obj in gc.get_objects()
            if type(obj) is dict and "__cgr_temporary_probe__" in obj}
        assert len(temporary_ids) == 5
        assert all(alive.get(identity) == [number]
            for number, identity in enumerate(temporary_ids))
        checked.append(True)
        return hash_original(document)

    monkeypatch.setattr(Limits, "model_dump", dump)
    monkeypatch.setattr(runtime, "fingerprint", hash_complete_dag)
    value = [limits() for _ in range(5)]
    assert runtime._cold_graph_inputs(value)
    assert checked == [True]


def test_actual_full_sqlalchemy_row_mapping_and_trusted_quoted_keys():
    """Full column set, synthetic metadata copy only; no Store or actual Run."""
    synthetic = Table("synthetic_cgr_row", MetaData(),
        *(Column(column.name, column.type) for column in runs.c))
    engine = create_engine("sqlite://")
    try:
        with engine.begin() as c:
            synthetic.create(c)
            values = {column.name: None for column in synthetic.c}
            values.update(id="synthetic-row", goal="full Goal",
                context=dict(messages=[dict(content="complete body")],
                    usage=dict(input_tokens=1, output_tokens=2, total_tokens=3)),
                resource_refs=["synthetic-resource-A", "synthetic-resource-A"])
            c.execute(insert(synthetic).values(values))
            row = c.execute(select(synthetic)).mappings().one()
            assert type(row) is RowMapping and set(row) == set(runs.c.keys())
            assert any(type(key) is quoted_name for key in row)
            complete = dict(row)
            plain = {str(key): value for key, value in row.items()}
            expected = runtime._cold_graph_inputs(row)
            assert runtime._cold_graph_inputs(complete) == expected
            assert runtime._cold_graph_inputs(plain) == expected
            assert runtime._model_inputs(complete) == runtime._model_inputs(plain)
            changed = copy.deepcopy(complete)
            changed["context"]["usage"]["input_tokens"] = 4
            assert runtime._cold_graph_inputs(changed) != expected
            assert row["context"]["usage"]["input_tokens"] == 1
    finally:
        engine.dispose()


def test_literal_values_cannot_collide_with_ref_or_bytes_node_shapes():
    assert runtime._cold_graph_inputs("ref") != runtime._cold_graph_inputs(["ref", 0])
    raw = b"complete bytes"
    import hashlib
    projected = dict(sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))
    assert runtime._model_inputs(raw) == runtime._model_inputs(projected)
    assert runtime._cold_graph_inputs(raw) != runtime._cold_graph_inputs(projected)
