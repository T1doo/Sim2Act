"""Pure codec source fragment for external review; never unpickle these bytes."""


def _cold_graph_pickle_marker(*args):
    raise TypeError("Cold graph serialization is fingerprint-only and must never be loaded")


def _cold_graph_limit_values(value):
    names = ("max_requests", "max_tools", "max_repairs", "max_total_tokens",
        "max_output_tokens", "run_seconds")
    raw = object.__getattribute__(value, "__dict__")
    require(type(raw) is dict and all(type(key) is str for key in raw) and set(raw) == set(names)
        and object.__getattribute__(value, "__pydantic_extra__") is None
        and object.__getattribute__(value, "__pydantic_private__") is None
        and all(type(raw[name]) is int for name in names), "Exact complete Cold graph Limits required")
    # Never invoke instance model_dump, __reduce__, or a Pydantic serializer.
    return tuple((name, raw[name]) for name in names)


def _cold_graph_row_values(value):
    from sqlalchemy.engine.cursor import CursorResultMetaData
    from sqlalchemy.engine.result import SimpleResultMetaData
    from sqlalchemy.sql.elements import quoted_name

    parent = object.__getattribute__(value, "_parent")
    data = object.__getattribute__(value, "_data")
    index = object.__getattribute__(value, "_key_to_index")
    require((type(parent) is CursorResultMetaData or type(parent) is SimpleResultMetaData)
        and type(data) is tuple and type(index) is dict, "Exact Cold graph SQL row storage required")
    keys = object.__getattribute__(parent, "_keys")
    require(type(keys) is list and all(type(key) is str or type(key) is quoted_name for key in keys)
        and all(type(index.get(key)) is int and 0 <= index[key] < len(data) for key in keys),
        "Complete Cold graph SQL row keys required")
    # The exact C row/metadata storage is read directly, avoiding arbitrary
    # Mapping.items/__iter__/__getitem__ callbacks in a forged wrapper.
    return tuple((key, data[index[key]]) for key in keys)


def _cold_graph_bytes(values):
    """Full per-call graph encoding. No loads, previous-check cache or permission.

    The CGR constructor and every add first use the restricted DAG validator.
    During checks, a newly introduced pure built-in/cycle changes these bytes
    and fails the pinned digest; unknown objects are refused before __reduce__.
    Insertion order/alias layout are intentionally stricter local pin facts.
    """
    from io import BytesIO
    from pickle import Pickler

    from sqlalchemy.engine import RowMapping
    from sqlalchemy.sql.elements import quoted_name

    class ColdGraphPickler(Pickler):
        def reducer_override(self, value):
            kind = type(value)
            if value is _cold_graph_pickle_marker:
                return NotImplemented
            if kind is Limits:
                return (_cold_graph_pickle_marker, ("limits-v1", _cold_graph_limit_values(value)))
            if kind is RowMapping:
                return (_cold_graph_pickle_marker, ("row-mapping-v1", _cold_graph_row_values(value)))
            if kind is quoted_name:
                return (_cold_graph_pickle_marker, ("quoted-name-v1", str(value)))
            # C handles exact primitive/built-in containers itself; every other
            # reducer path stops before user __reduce__/__reduce_ex__ executes.
            raise DomainError("VERSION_CONFLICT", "Unsupported Cold graph reducer")

    output = BytesIO()
    ColdGraphPickler(output, protocol=5).dump(values)
    return b"SIM2ACT_COLD_GRAPH_PICKLE_V1\x00" + output.getvalue()


def _cold_graph_inputs(values):
    return hashlib.sha256(_cold_graph_bytes(values)).hexdigest()
