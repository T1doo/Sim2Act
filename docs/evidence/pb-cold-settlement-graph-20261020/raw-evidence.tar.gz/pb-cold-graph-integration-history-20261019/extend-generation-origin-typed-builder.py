from pathlib import Path
out=Path('/workspace/pb-cold-graph-integration-history-20261019')
for name in ('generation-origin-typed-pin.patch','generation-origin-typed-pin-static.json'):
    (out/name.replace('.', '-v1.', 1)).write_bytes((out/name).read_bytes())
p=out/'build-generation-origin-typed-delta.py'
s=p.read_text()
needle="pa = transform_function(pa, '_original_confirmation_target', confirmation)\n\ndef prefix(old):"
insert='''pa = transform_function(pa, '_original_confirmation_target', confirmation)

def original_prefix(old):
    old = replace_once(old, '    manifest, _, report = compile_candidate(draft["candidate"], limits)\\n',
        '    manifest, _, report = compile_candidate(draft["candidate"], limits)\\n'
        '    if _graph_read is not None:\\n'
        '        from .natural_live_admission import _trial_typed_equal\\n'
        '        require(type(manifest) is AppManifest)\\n'
        '        manifest_pin = copy.deepcopy(AppManifest.model_dump(manifest))\\n')
    old = old.replace('    _bound_checkpoint(store, c, _graph_read)\\n',
        '    _bound_checkpoint(store, c, _graph_read)\\n'
        '    if _graph_read is not None:\\n'
        '        require(_trial_typed_equal(AppManifest.model_dump(manifest), manifest_pin),\\n'
        '            "Complete typed original Manifest changed at prefix read")\\n')
    return old
pa = transform_function(pa, '_original_origin_prefix', original_prefix)

def prefix(old):'''
assert s.count(needle)==1
s=s.replace(needle,insert)
start=s.index('def test_original_manifest_numeric_drift_stops_after_confirmation_sql(')
end=s.index("\n'''",start)
new='''def test_original_manifest_numeric_drift_stops_after_prefix_and_confirmation_sql(generated, monkeypatch, tmp_path):
    f = generated
    before = snapshot(f.store)
    proofs = []
    for edge in ("prefix-marker", "confirmation"):
        sql_after_drift, changed, compiled = [], [], []
        with f.store.tx() as c:
            with pytest.raises(DomainError):
                with scope(f, c) as guard:
                    if edge == "confirmation":
                        contract, source, reader, history = strict_history(f, c, guard)
                        raw = generation._cold_candidate_from_history(f.store, c, f.run,
                            contract, source, history, f.full, reader)
                        prefix = spec._cold_original_origin_prefix(f.store, c, f.user, f.draft, f.full, guard)
                        marker = c.execute(select(goal_application_candidates).where(
                            goal_application_candidates.c.app_id == f.draft["id"])).mappings().one()
                        compiled.append(prefix.manifest)
                    original_compile = spec.compile_candidate

                    def observe_compile(*args, **kwargs):
                        value = original_compile(*args, **kwargs)
                        compiled.append(value[0])
                        return value

                    def before_sql(conn, cursor, statement, parameters, context, executemany):
                        if changed:
                            sql_after_drift.append(statement)

                    def after_sql(conn, cursor, statement, parameters, context, executemany):
                        selected = ("FROM task_extractions" in statement if edge == "prefix-marker"
                            else statement.startswith("SELECT goal_application_candidates.confirmation"))
                        if compiled and not changed and selected:
                            manifest = compiled[-1]
                            original = manifest.revision
                            manifest.revision = float(original)
                            changed.append(statement)
                            assert manifest.revision == original and type(manifest.revision) is float

                    event.listen(f.store.engine, "before_cursor_execute", before_sql)
                    event.listen(f.store.engine, "after_cursor_execute", after_sql)
                    try:
                        with monkeypatch.context() as patch:
                            if edge == "prefix-marker":
                                patch.setattr(spec, "compile_candidate", observe_compile)
                                call = partial(spec._cold_original_origin_prefix,
                                    f.store, c, f.user, f.draft, f.full, guard)
                            else:
                                call = partial(spec._cold_original_origin_from_generation,
                                    f.store, c, f.user, prefix, reader, raw, marker)
                            assert denied(call) == "VERSION_CONFLICT"
                    finally:
                        event.remove(f.store.engine, "before_cursor_execute", before_sql)
                        event.remove(f.store.engine, "after_cursor_execute", after_sql)
                    assert len(changed) == 1 and sql_after_drift == [] and not guard.active
                    if edge == "confirmation":
                        assert denied(reader.check) == "VERSION_CONFLICT"
                    proofs.append(dict(edge=edge, changed_after_sql=changed, later_sql=sql_after_drift,
                        actual_type=type(compiled[-1].revision).__name__, sticky=not guard.active))
        assert snapshot(f.store) == before
    write(tmp_path / "typed-original-manifest-next-io.json", proofs)
    assert len(f.sent) == 3'''
s=s[:start]+new+s[end:]
s=s.replace("'_original_confirmation_target', '_original_origin_checkpoint', 'target']", "'_original_confirmation_target', '_original_origin_checkpoint', '_original_origin_prefix', 'target']")
# This expected list is sorted; origin prefix precedes target as inserted.
assert "'_original_origin_checkpoint', '_original_origin_prefix', 'target']" in s
p.write_text(s)
