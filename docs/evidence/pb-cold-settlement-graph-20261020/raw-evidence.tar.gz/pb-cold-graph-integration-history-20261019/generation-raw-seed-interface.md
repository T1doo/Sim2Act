# G1 raw seed delta

`generation-raw-seed.patch` is relative to the currently applied G v2 + memo source. It changes only `goal_applications.py`: the new raw container, `_GenerationFactsReader`, and `_cold_generation_source`. No repository files were edited or imported.

At the original nontrial audit edge, root must finish the existing permission/order checks, collect all ten full native-audit fields and pin that **same dictionary object** in the same `_ColdGraphRead`:

```python
guard.add("original-native-audit:" + native_rows["original"]["id"], native_rows)
seed = ga._ColdGenerationRawSeed(store, c, user, native_rows, guard)
```

At the later original Generation source edge:

```python
contract, material, reader = ga._cold_generation_source(
    store, c, generation_run, guard, raw_seed=seed,
)
history = ga._cold_history_from_source(store, c, generation_run, contract, material, reader)
```

The container validates complete raw-row shape, scope/pin identity and raw associations. It performs no SQL, history parsing, provider/usage/counter validation or candidate proof. It is not an authority or a published history facet. All row lists retain full fields, duplicates and original multiplicity.

`_cold_generation_source` completes its original current source/authority protocol before accepting a supplied seed, then binds its full Run and exact freshly checked FrozenRunContract snapshot/fingerprint, using the existing persisted `model_dump(exclude_none=True)` representation. Only the reader's original `ordered_attempts()` and `counter_operations()` positions can consume the seed. Attempts are copied into the old SQL `(created_at, id)` order (including NULL-first ordering); Operations are copied in full without collapsing entries. The old strict memo then pins each complete raw result once.

Per-operation and anchor projections retain their original first-needed SQL. No future history/candidate condition is parsed early, and no callback/query/selector argument exists. `raw_seed=None` preserves all previous SQL expressions and default behavior. Wrong known exact guard/seed pointers, drift, or any escaping producer/read failure poison the implicated exact scopes; catching within the same `with` does not restore reuse.

Root still owns the original first-needed audit permissions/order, initial pin, role facets and integration call. Tests/product/DB/model/network were not executed here. `generation-raw-seed-static.json` records only stdlib AST and byte checks.
