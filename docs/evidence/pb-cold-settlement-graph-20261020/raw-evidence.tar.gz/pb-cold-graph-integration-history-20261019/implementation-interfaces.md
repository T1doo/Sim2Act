仓库外实现交付（尚未应用/运行）

`implementation.patch` 是仅两个既有产品文件的 unified diff；base/edited 完整副本及 source map 在同目录。根线程是唯一 repo writer，请按相符的函数/hunk审后应用；本代理没有写仓库。natural_specs 的两个所属 facts helper 已由根提供，本补丁直接调用它们，不复制样本循环。

建议根在每个新 G0 / W5后新G1 内的实际调用顺序：

```python
contract, material, reader = ga._cold_generation_source(store, c, generation_run, graph_read)
history = ga._cold_history_from_source(store, c, generation_run, contract, material, reader)
raw = ga._cold_candidate_from_history(store, c, generation_run,
    contract, material, history, caller_limits, reader)
# 同一history允许另一个完整Limits角色或原None；同一角色再次调用拒绝，不做隐式resolve。
raw_none = ga._cold_candidate_from_history(store, c, generation_run,
    contract, material, history, None, reader)
# 原GA确认facet（marker必须在原先owner/confirmed位置由root读取，不能延后改变首错）
raw, metadata = spec._cold_original_model_source(store, c, user,
    generation_run, original_draft, full_confirmation_marker, raw, reader)
# 原生审计供SourceAuditFacts；不是hash替代
rows = spec._native_audit_facts(store, c, user, original_draft,
    _graph_read=graph_read)
graph_read.add("original-native-audit:" + original_draft["id"], rows)
```

如caller_limits本身为None，只调用一次该角色，勿再重复示例的raw_none。严格reader每个Generation Run每个graph_read只创建一次；run/source/history/每角色candidate和所有真实SQL返回值逐个add到原exact pin。None与显式同值Limits不同key，history始终按完整frozen generation Limits，spec样本编译仍按selected.app_limits。reader不提供public verifier fallback、callback/selector、Authority、Permit、LIVE事实或跨写缓存。

固定reader是原SQL执行器，不接受外部查询/回调：Attempt完整(created_at,id)排序；typed counter门后才读Operations；GA_RECEIVED/GA_WIRE_RESERVED/GA_DIAGNOSTIC/GA_SPEC_CHECKED/GA_CANDIDATE_VALIDATED/GA_APP_CONFIRMED原data列表在各原位置读取。read/check op和intent按原缺失/typed/权限前置读取。body、反馈、returned model、known usage、全部caps和最终唯一候选seal仍用同一核心；默认public wrappers仍走原public IO顺序，strict branch改用本段已完整证明source及fresh own_project/authorities复核。

原生audit helper保留marker fallback、完整scope/source_scope、Run→contract→original以及attempts/operations/intents/events/confirmation/goal_head/goal_version原查询顺序、排序和全字段；返回原完整rows。public原生分支仅fingerprint该helper。strict每callee/SQL后用exact cold checkpoint，不把rows视成完成态；根必须立刻pin raw rows，在全部原Source/Binding/Authority边完成后才发布相应图节点。

`_cold_original_model_source` 仅复用原text三叶验证original GA候选确认，明确排除spec_task/spec_binding、logic/correction/per-use。不覆盖完整原App的compile/权限/current Goal/consent/Release证明，不能将其单独发布为完整model_source/Source/Release节点；根仍需其余已授权callee链。通用pa_material_bindings路径未改变，也没有复制其泛化谓词。

W5前后的reader完全分离；写后旧read pin由driver changes/epoch拒绝，不能把G0 history/candidate/raw rows或完成位给G1。caller仍须原Run/stop/version/fence/lease/deadline、fresh production source/approval及scope权限的实际门，不能把read pin当这些门。

自检只执行stdlib AST/hash和内存unified diff重建：所有其它原函数AST不变，包括bound/_bound/receipts/commit_guard/verify_job；完整_history原If条件及raise、原audit表查询序列一致。未import产品，未运行Ruff/mypy/pytest/DB/模型/网络。根需按自身有界short gates检查默认路径/首错/数据与权限漂移，再决定唯一完整Mock链。没有预签运行PASS。

建议根短测试最小关注：完整三行中逐个改raw/wire/usage/feedback/typed counter须拒绝；None/显式同值Limits分别构造facet；compile/receipt/source SQL返回后变更任一原pin或事务必须在下一消费前拒绝；W5后重用reader拒绝；原native audit rows与旧原生hash完全对应；原text确认 malformed与坏G并存时G先错。以上是测试建议，未由本代理执行。

保留implementation-initial.patch与builder初稿为未交付版本；当前唯一交付是implementation.patch及implementation-ast-check.json中的SHA。目录暂不封存，以便后续独审闭合实际应用字节。

v2 唯一补丁补充（替代已保存v1）：pa_spec_apps.scope_gate 与 goal_applications.source_scope_gate/_source_scope_gate 现在都有 keyword-only `_graph_read=None`。严格路径在每个SQL、own_project、authorize、pair及家族callback返回后先checkpoint；pa PB分支将guard传给pb.scope_gate，pa原生分支传goal source_scope；goal向根负责的pa job_scope_gate透传。所有这些新callee关键字只在非None时发出，默认不加实际kwargs。strict source_scope直接执行带inner pins的完整原scope body，避免用旧缓存假作strict首证。

依赖根与PB代理同时落地：pa.job_scope_gate(...,_graph_read=guard)和pb.scope_gate(...,_graph_read=guard)的当前默认/严格分支；本补丁没有修改job_scope_gate/_job_scope_gate。nativeaudit严格路径同样向这两个本文件scope gate透传。v2 source-map与AST检查已重算；唯一patch SHA见implementation-ast-check.json。

构造v2期间一次外部builder字符串匹配未锚定，4空格行误匹配8空格行而触发exact-one断言；失败在写patch前，旧patch仍保留。原builder、明确转录错误及修正见build-scope-v2-failed.py/implementation-tool-errors.json。改为行首锚定后builder和stdlib AST/内存应用均成功；没有产品/测试/仓库写入。
