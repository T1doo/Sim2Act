可执行最小切口：完整 G 事实核心

当前不能把 `_candidate_attempt_from_history`、seal 或 counters 尾叶当完整 G。`goal_applications._history:497–684` 仍验证全部有序 Attempt、每次真实 wire、raw/usage/identity、两次实际工具回执、诊断及计数；`_verified_candidate:813` 还必须先完成该 history、再按本次 Limits 编译完整末候选、最后核唯一 GA_CANDIDATE_VALIDATED。

先明确一项文件边界：`pa_spec_apps.from_response:337` 在自然分支调用 `natural_specs.from_response:755`，其中759硬调 public `goal_applications.source`；`natural_specs.initial_messages:727/730` 同样如此。natural_specs 不在本次 preflight 的13文件中。若不允许第14文件两个小切口，则“无 public 祖先重入且不复制原样本编译谓词”不能同时满足。应明确批准该必要所属文件；不要在 pa_spec_apps 复制 natural 的编译循环，或用 monkeypatch/临时假 Store 代替 source。

建议接口均为 server-private，放在原所属模块，无新 registry/API/许可类：

```python
# goal_applications；返回原消息序列与全部原行，不只末 Attempt
_history_from_facts(run, contract, material, initial_messages,
    ordered_attempts, counter_operations, *, received_anchors,
    wire_reserved_anchors, diagnostic_anchors,
    read_operation, read_intent, checker_operation, checker_intent,
    checker_anchors) -> tuple[messages, ordered_attempts]

_parse_candidate_from_facts(run, contract, material, message,
    caller_limits, *, checker_response, checker_operation,
    checker_intent, checker_anchors) -> candidate

_candidate_from_complete_facts(run, contract, material, checked_history,
    caller_limits, validation_anchors, checker_facts) -> candidate

# pa_spec_apps：自然分支调用 natural 同名纯核心
_from_response_from_facts(run, contract, material, value) -> candidate
_check_report_from_facts(run, contract, material, candidate) -> report
_check_receipt_from_facts(run, contract, material, call, op, intent,
    anchors) -> receipt

# natural_specs（需最小扩大文件授权）
_initial_messages_from_facts(contract, material) -> messages
_from_response_from_facts(run, contract, material, value) -> candidate
```

这些名称是切口建议，不是新实现或资格。`checked_history` 表示上一完整核心的实际输出，不能接受 bool、digest、权限标记或 projected final response。checker_facts 必须包括原中间 response/完整 Operation/intent/全部 GA_SPEC_CHECKED，core 自行构造 report 与 receipt 并比原字节；不要把 caller 给的“已通过 receipt”当事实。原 `from_response` wrapper 继续先 `source` 后同核心，compile/sample/Goal/raw 型别判断只保留一个实现。原 natural 的 sample_nodes 顺序/数量、两种 node focus、全部 resolve/pure/schema 检查及 app_limits 编译循环必须逐行移入共享核心。

原 IO 与首错次序必须保留：

| 原位置 | 原 IO / 依赖 | 核心保持的检查顺序 |
| --- | --- | --- |
| history 起点 | initial_messages 的 source；frozen contract；activation validate_run；Attempt 按 created_at,id 全量取 | 不把 generation_index 当排序；不省 literal 2/3 与 SPEC 恰3的区别 |
| counters | frozen generation Limits；先 typed `_check_counter_rows`，再全 Operations | ctx requests/reserved/tools/repairs 的 exact int、工具白名单/VERIFIED、全部 caps；然后才 len>3 |
| 每个 Attempt | GA_RECEIVED 原完整 data 列表 | RECEIVED/typed→raw JSON archive/canonical/parse/usage/返回model→raw anchor；STARTED/UNKNOWN 不能跳过 |
| 每个 wire | GA_WIRE_RESERVED 原完整 data 列表 | 原 messages/tools/max_tokens 重建字节；wire bytes/characters/hash、requestFP、mode、index/fence、reserved_tokens、returned identity、checked_usage 全保留 |
| index0 | read_op(ga_read)→其 intent→实际 source receipt | call 名和 exact resource args 先查；不再调用 public source，使用本读段完整 source 节点的原 material，加 current/authority 原边 |
| index1 SPEC | check_call→ga_spec_check op→intent→原 check_report→GA_SPEC_CHECKED | missing op 在 report 编译前拒绝；report 仅捕原 INVALID_INPUT/INVALID_MANIFEST/VERIFICATION_FAILED，不能吞权限、VERSION_CONFLICT、预算；PASS 候选不能被最终 response 静默替换 |
| 诊断 | GA_DIAGNOSTIC 原完整列表 | 保留 spec feedback/诊断FP及额外 repair 用户消息的原顺序；不能“清理”看似重复 prompt |
| final candidate | 先 source；完整 history；候选角色/解析；GA_CANDIDATE_VALIDATED 最后读 | 内容-only assistant 门→strict_json→source门→SPEC checker/PASS同候选→原 compile；完整 anchor 列表须严格等于单一原seal，不只 membership |

不要为一个大 signature 把所有私有 op/event 读提前到typed或call检查之前。若必须逐原 SQL/异常位置完全等价，保留原 wrapper 的固定加载顺序，让同一完整核心暴露固定阶段（begin/attempt/raw/wire/feedback/final）并由唯一完整 orchestrator 强制跑完；或用固定私有 facts reader 在原读取位置取值。reader 只能是本模块固定 SQL/graph 原始事实适配，不能是新公开 callback/selector/任意 callable。完整 G 完成态只在所有阶段与最终 anchor 后设置；不能让阶段叶自己签“G完成”。图路径读事实后也要原 pin/当前权限检查，G1 在 W5 后重读，不拿 G0 完成位或 parsed JSON 跨 epoch。

Limits 必须拆清：history/counters/wire/checked_usage 用 frozen contract.limits；parse_candidate 接原 caller `limits or contract.limits`（None 与显式同值 Limits 仍是两个 role key，完整 Limits 字段参与）；SPEC recipe/sample compile 仍是 selected.app_limits。不要只拿 max_tokens/run_seconds，不能把 app/源/目标/平台限制取一个最小值后替掉原逐角色检查。

text_apps 已抽叶可以直接接：在完整 candidate G 之后调用 `_goal_confirmation(marker)`；再 `_goal_acceptance_from_facts(user,draft,run,raw,confirmation)`；原位置加载完整 GA_APP_CONFIRMED；最后 `_verify_goal_origin_from_facts(...)`。必须传完整 marker/run/raw/draft/confirmation 和 sealed 列表，保留 confirmation 首错、Run PARTIAL/error/cancel/result、draft 全等/FP。不要从 run.result.candidate 直接取 raw，或调用 public text.verify_origin 再进入 G。

`pa_spec_apps.model_source:569` 只是 `pa_material_bindings.model_source:115` 的 facade。后者的实际顺序为 owner/project/原resource READ→confirmed marker→完整 Run/G→family→原App load_draft→Run状态及 goal_application/confirmedFP。图孩子不能回它以补证。对本片明确 original GA app 的路径，可用上面的 text 确认叶及完整原 draft 节点接通；若要支持所有 rebind/material family，须在 pa_material_bindings 所属文件另抽该尾谓词，不能在 pa_spec_apps 复制它。当前13清单不包含该文件，应把是否需要它作为选定路径条件，不能默开通用分支。

调用者至少保留：完整 frozen contract、material 与 source authorities；完整有序 Attempts/全部 parameters/usage/raw；所有 counters Operations、对应 intents 和原 event data 列表；原确认 marker/draft；原 compiled candidate；本次完整 Limits/None role。消息与 rows 都返回独立 copy，任何结果不授权 LIVE/source/Grant，也不提供跨事务 cache。history 自身不是 candidate 完成态；candidate、确认及原 App 是后续不同事实。

本次仅静态建议，具体字节/行号在 source-observations.json；没有源码修改、DB/模型/测试/网络/Git执行。两处原本猜测不存在路径的 rg exit2 已记录为只读搜索错误，不是产品失败。本新目录未封存，等待根决定实际接口与额外文件授权。
