from pathlib import Path
out=Path('/workspace/pb-cold-graph-integration-history-20261019')
for name in ('generation-origin-typed-pin.patch','generation-origin-typed-pin-static.json'):
    (out/name.replace('.', '-v2.', 1)).write_bytes((out/name).read_bytes())
p=out/'build-generation-origin-typed-delta.py'
s=p.read_text()
start=s.index('def target(old):\n')
end=s.index('\ndef confirmation(old):\n',start)
replacement='''def target(old):
    old = replace_once(old, 'def target(', 'def _target_core(')
    old = replace_once(old, 'family=VERSION, _graph_read=None):',
        'family=VERSION, _graph_read=None, _origin_read=None):')
    old = replace_once(old, '    project = store.own_project(c, user, pid)\\n',
        '    if _graph_read is not None:\\n'
        '        from .natural_spec_runtime import _ColdGraphRead\\n'
        '        require(type(_graph_read) is _ColdGraphRead)\\n'
        '    if _origin_read is not None:\\n'
        '        _original_origin_checkpoint(store, c, user, _origin_read)\\n'
        '        require(_graph_read is _origin_read.guard)\\n'
        '    project = store.own_project(c, user, pid)\\n')
    old = old.replace('    _bound_checkpoint(store, c, _graph_read)\\n',
        '    _bound_checkpoint(store, c, _graph_read)\\n'
        '    if _origin_read is not None:\\n'
        '        _original_origin_checkpoint(store, c, user, _origin_read)\\n')
    old = replace_once(old,
        '    store.authorize(c, user, runtime or project["runtime_id"], pid, pid, SAVE)',
        '    store.authorize(c, user, _target_runtime(project, runtime), pid, pid, SAVE)')
    old = replace_once(old, '    source_check(source, family)',
        '    _target_source_check(source, family)')
    wrappers = \'\'\'def target(*args, **kwargs):
    # Fixed forwarding only. Strict guards stay outside persisted-data mappers;
    # default calls retain the original controlled argument/error semantics.
    if kwargs.get("_graph_read") is None and kwargs.get("_origin_read") is None:
        return _target_default(*args, **kwargs)
    return _target_core(*args, **kwargs)


@controlled
def _target_default(*args, **kwargs):
    return _target_core(*args, **kwargs)


@controlled
def _target_runtime(project, runtime):
    # Owned persisted scalar projection only; no guard or IO in this mapper.
    return runtime or project["runtime_id"]


@controlled
def _target_source_check(source, family):
    # The original pure bounded source parser; no guard/authority callback.
    return source_check(source, family)


\'\'\'
    return wrappers + old
# Only target's former outer mapper is split; scope/job/receipts are untouched.
pa = replace_once(pa, '@controlled\\ndef target(', 'def target(')
pa = transform_function(pa, 'target', target)
'''
s=s[:start]+replacement+s[end:]
# Insert one focused real-relay exception item into the existing fixture module.
start=s.index("\n'''\n\nchanged = dict(zip(paths, (ga, pa, tests), strict=True))")
addition='''


def test_original_target_strict_relay_keeps_guard_valueerror_identity(generated, monkeypatch, tmp_path):
    f = generated
    before = snapshot(f.store)
    same_error = ValueError("synthetic original relay guard error")
    completed, later_sql, later_calls = [], [], []
    with f.store.tx() as c:
        with pytest.raises(DomainError):
            with scope(f, c) as guard:
                _, _, reader = generation._cold_generation_source(f.store, c, f.run, guard)
                prefix = spec._cold_original_origin_prefix(f.store, c, f.user, f.draft, f.full, guard)
                key = "original-origin-prefix:" + f.draft["id"] + ":" + fingerprint(f.full.model_dump())
                relay = spec._ColdOriginalOriginRead(guard, prefix, reader, key, guard.inputs[key])
                spec._original_origin_checkpoint(f.store, c, f.user, relay)
                original_own, original_check = f.store.own_project, reader.check

                def owned_project(*args, **kwargs):
                    value = original_own(*args, **kwargs)
                    completed.append("owned-project")
                    return value

                def actual_reader_guard():
                    original_check()
                    if completed:
                        raise same_error

                def later_authorize(*args, **kwargs):
                    later_calls.append("authorize")
                    pytest.fail("Relay failure must stop before the next authority IO")

                def before_sql(conn, cursor, statement, parameters, context, executemany):
                    if completed:
                        later_sql.append(statement)

                event.listen(f.store.engine, "before_cursor_execute", before_sql)
                try:
                    with monkeypatch.context() as patch:
                        patch.setattr(f.store, "own_project", owned_project)
                        patch.setattr(f.store, "authorize", later_authorize)
                        patch.setattr(reader, "check", actual_reader_guard)
                        with pytest.raises(ValueError) as error:
                            spec.target(f.store, c, f.user, f.run["project_id"], "unused-after-guard",
                                _graph_read=guard, _origin_read=relay)
                        assert error.value is same_error
                finally:
                    event.remove(f.store.engine, "before_cursor_execute", before_sql)
                assert completed == ["owned-project"] and later_sql == [] and later_calls == []
                assert not guard.active and denied(reader.check) == "VERSION_CONFLICT"

                def malformed_owned_row(*args, **kwargs):
                    raise same_error

                # The same error remains mapped on the original default path;
                # even argument-binding TypeError retains its prior mapping.
                with monkeypatch.context() as patch:
                    patch.setattr(f.store, "own_project", malformed_owned_row)
                    assert denied(partial(spec.target, f.store, c, f.user,
                        f.run["project_id"], "unused-default")) == "VERSION_CONFLICT"
                    assert denied(spec.target) == "VERSION_CONFLICT"
                write(tmp_path / "original-target-guard-error-identity.json", dict(
                    same_exception_object=True, completed=completed, later_sql=later_sql,
                    later_calls=later_calls, default_error="VERSION_CONFLICT", sticky=not guard.active))
    assert snapshot(f.store) == before and len(f.sent) == 3
'''
s=s[:start]+addition+s[start:]
s=s.replace("'_original_confirmation_target', '_original_origin_checkpoint', '_original_origin_prefix', 'target']",
    "'_original_confirmation_target', '_original_origin_checkpoint', '_original_origin_prefix',\n"
    "    '_target_core', '_target_default', '_target_runtime', '_target_source_check', 'target']")
s=s.replace("for name in ('target', '_original_confirmation_target'):", "for name in ('_original_confirmation_target',):")
needle="# Strict prefix-local pin branches erase to the unchanged shared/default IO.\n"
insert='''# The default target calls the same strict-signature core through controlled.
# Normalize the two pure owned-data mapper leaves back to the original expressions.
left = next(n for n in ast.parse(original[paths[1]]).body if isinstance(n, ast.FunctionDef) and n.name == 'target')
right = next(n for n in ast.parse(pa).body if isinstance(n, ast.FunctionDef) and n.name == '_target_core')
right = erase_relay(right)
right.name, right.decorator_list = left.name, left.decorator_list
class RestoreTargetData(ast.NodeTransformer):
    def visit_If(self, node):
        if (isinstance(node.test, ast.Compare) and isinstance(node.test.left, ast.Name)
                and node.test.left.id == '_graph_read'):
            return None
        return self.generic_visit(node)
    def visit_Call(self, node):
        node = self.generic_visit(node)
        if isinstance(node.func, ast.Name) and node.func.id == '_target_runtime':
            return ast.BoolOp(op=ast.Or(), values=[ast.Name(id='runtime', ctx=ast.Load()),
                ast.Subscript(value=ast.Name(id='project', ctx=ast.Load()),
                    slice=ast.Constant(value='runtime_id'), ctx=ast.Load())])
        if isinstance(node.func, ast.Name) and node.func.id == '_target_source_check':
            node.func.id = 'source_check'
        return node
assert ast.dump(left, include_attributes=False) == ast.dump(RestoreTargetData().visit(right), include_attributes=False)
# Strict core itself has no decorator; wrapper dispatch can only call these
# two fixed functions. Original public material target remains its own mapper.
core = next(n for n in ast.parse(pa).body if isinstance(n, ast.FunctionDef) and n.name == '_target_core')
assert core.decorator_list == []
dispatch = next(n for n in ast.parse(pa).body if isinstance(n, ast.FunctionDef) and n.name == 'target')
assert sorted(n.func.id for n in ast.walk(dispatch) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name)) == ['_target_core', '_target_default']
# Strict prefix-local pin branches erase to the unchanged shared/default IO.
'''
assert s.count(needle)==1
s=s.replace(needle,insert)
s=s.replace('tests_added=2,', 'tests_added=3,')
s=s.replace("'default-path AST equivalence including prefix SQL'])", "'default-path AST equivalence including prefix SQL', 'strict target core unmapped / fixed default dispatch'])")
p.write_text(s)
