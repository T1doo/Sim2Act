# One bounded complete P-B run: passthrough measurement plan

Read-only base: `dc34ce4b1311810e27cd33a0cd156b6f84333666`. This plan and draft were written outside the repository. No database, model, test, chain or network was run. The graph's integration function names do not yet exist at this base; bind the G0/G1 entrypoints to their final actual names after author implementation, then freeze that exact observer manifest before the one run. Do not infer G0 from a late legacy bound result.

## Exactly one unchanged test

`tests/test_pb_spec_production_controller.py::test_pb_production_original_source_extraction_explicit_use_and_cold` (line 274 at base).

This is the complete Generate -> Source -> extraction/explicit use -> newly opened Cold Store -> Cold -> owner PENDING flow. It uses `configured` from `tests/test_spec_production_controller.py:59`, the test's original fake account/qualification substitutions and `no_real_http` tripwire. Actual transport is finite MockTransport, although durable Attempts deliberately have mode LIVE. Do not count mode LIVE as a real model request.

Keep every test assertion, its original 30/300/1800 contract bounds, 60-second quota gaps, original data and HTTP guards. No saved-prefix DB, old Worker/Run continuation, drive-to-success retry loop, alternative test or first-local-read shortcut. The original test itself performs bounded archive-refusal copies; preserve them as original assertions, but exclude their costs from Cold execution settlement partitions and label those calls with their distinct Store/driver identity.

## Actual invocation counts without transport substitution

Wrap the test module's imported `configured` with a function that calls it exactly once and retains the returned `fixture['sends']` list by reference. Do not replace that list, factory, worker, transport, resolver or guard. Wrap `Worker.process` passthrough to capture its actual run, worker, principal/project/runtime, created_at/fence/version, binding contract stage keys and len(fixture['sends']) at entry/exit. The difference is actual MockTransport handler invocations for that original stage. Classify Generate by the original runtime and generate key; classify Source/Cold by original exact stage key/material identity. Never borrow an outer parent Run ID to identify an ancestor call.

After return/failure compare counts against original `mock-exchanges.jsonl` line count and, if the original test completed, `pb-controller-proof.json` journal identities. Expected successful counts are Generate=3, Source=2, extraction and duplicate submission=0, Cold=2, total=7. `sends` records transport entry before the finite handler returns; exchange lines record returned bodies. Report entered/returned separately on failure. Do not query the DB during measurement just to count requests.

## Probe locations

| Target | Base original location | Required observation |
| --- | --- | --- |
| Stage body | Worker.process; module.approve_stage | process run identity and actual call stage; approval wrapper calls original first, then registers original Source/Cold IDs; it does not approve twice |
| Settlement TX | Store.tx passthrough, main-thread Cold `advance_model` settlement connection | attempt/acquired/body_end/committed/error separately; UUID/counter tx handle plus real Connection/get_transaction/driver identities; acquisition wait is separate from body duration |
| First complete proof G0 | final integrated graph G0 entry before legacy first bound/commit guard and before all five writes | enter/complete/error, exact current run/aid/operation/step, phase G0, connection/transaction/driver/thread, start/end write epoch and total_changes |
| Five writes | engine before_cursor_execute and after_cursor_execute, restricted to the watched settlement TX | recognized original statements below, each enter/return/error and actual rowcount; parent graph must not mask a failed statement |
| Fresh complete proof G1 | final integrated G1 graph entry after fifth original write, before existing settlement consumer | same IDs/epochs, independent enter/complete/error; distinguish graph build completion from READY |
| Consumer/final guard | trial.settle_verified, spec.commit_guard(_model_after), _ModelSettlementRead.settle/tail/live, TX commit return | real callback entry/exit/error, tail READY/SETTLED/TAIL_DONE/CLOSED or INVALID state; original final finite predicate times and actual observed lease/Run/source deadline margins |
| Check/hash cost | _ModelSettlementRead.check, binding_key; runtime._model_inputs | calls, inclusive and direct-child-exclusive wall and thread CPU by phase/current aid; instrument exact original functions, not copies |
| Recursive ancestor proof | ga.history, ga.verified_candidate, spec.bound, pb.source, gate._stage_current, trial._journal_chain | calls/max same-function recursion depth, actual callee IDs and full Limits role, not only parent scope aid; record whether old verifier is entered from an active integrated graph |

The five original statements are: UPDATE Attempts RECEIVED->VERIFIED; INSERT NS_SETTLED event; UPDATE Operation DISPATCHED->VERIFIED with receipt; UPDATE internal_app_runs RUNNING; INSERT SPEC_STEP_VERIFIED event. They are not five arbitrary non-SELECT statements. Identify table/statement kind via compiled SQLAlchemy context and original event name/record params; keep only identifiers and event kind, not raw payloads. At base these appear in natural_spec_runtime.advance_model around lines 1279-1332. The Store's pre-existing proof_write_boundary listener executes before the new observer, so log actual epoch before/after; do not assume listener order or add +1 to manufacture epochs.

The G0/G1 instrumented functions must be exact final graph functions from the frozen candidate. Record their qualified names/code hashes. If a graph is a contextmanager, its constructor call time is not graph execution time: enter when the original context __enter__ begins, complete at its real yield/validated result, and close when original __exit__ returns. Do not substitute _ModelSettlementRead.check entry for G1 or READY for TX commit.

## Current aid, actual callee aid and role

Every span carries two separate identities: `settlement=(cold_run, current_aid, step, ordinal)` and actual `callee=(run, aid, runtime, role)`. For trial._journal_chain signature `(store,c,b,run,aid,raw)`, use args[3]['id'] and args[4]. For scope input use inputs['current']['id'], inputs['aid'], inputs['meta']['operation_id']/step/ordinal. For _ModelSettlementRead methods use self.connection and self.inputs, never an outer variable. For functions without aid parameters record null and the actual source run; do not imply current aid. Distinguish Generate, successful Source, current Cold, prior Cold, extraction base/effective per-use candidate and current/ancestor Limits vectors. Use existing call arguments/validated facts, never extra protected-body reads.

## Byte and recursion measurement without extra security work

runtime._model_inputs calls db.fingerprint(_model_value(values)). Capture outermost _model_inputs inclusive time; an optional thin _model_value wrapper only counts recursive calls/current/max depth while that outer call is active. It calls the exact original once and retains no values. Do not timestamp or emit an event for every scalar recursion.

To obtain canonical UTF-8 bytes without reserializing/rehashing the proof, a passthrough hashlib.sha256 tap can observe len(data) only when its immediate caller code is the original db.fingerprint code and a thread-local outer _model_inputs or binding_key span is active. Call original sha256 exactly once and return its actual object. Separately count raw-byte hashing by original runtime._model_value; never mix raw embedded bytes with canonical JSON bytes. No calls to _model_inputs, binding_key, model_dump, json.dumps, fingerprint or check merely to log state. In particular never call check() in the check observer.

This tap is optional until author review approves the exact draft: if omitted, report byte count UNKNOWN, not inferred from Python repr/sizeof. The passthrough implementation adds small observation overhead; the observed times include that overhead, and this is not an uninstrumented benchmark. Avoid sys.setprofile/sys.settrace for the entire chain, per-SQL stack extraction and per-recursion JSON disk output.

## Cost accounting

Use time.monotonic_ns for wall and time.thread_time_ns for current-thread CPU. Never use time.time for duration and never replace the product clock. Record time.time only for original lease/deadline margins. Process CPU belongs in its own total; it cannot be substituted for per-thread CPU or added to it.

For each Cold model settlement transaction partition on the same thread:

1. acquired -> G0 complete;
2. G0 complete -> first write entry;
3. first write entry -> fifth write return;
4. fifth write return -> G1 complete;
5. G1 complete -> final guard complete;
6. final guard complete -> TX body_end;
7. body_end -> actual commit return.

Also report TX attempt->acquired and, separately, G0/G1 graph build spans. These disjoint partitions sum to TX acquired->commit. If any boundary is absent, report incomplete and its last boundary; do not treat absent duration as zero. `G0/G1 graph build` is a nested breakdown and must not be added again to partitions that already contain it. Likewise check/binding_key/_model_inputs/ancestor inclusive totals overlap and are explanatory breakdowns, not additive TX cost. The small draft demonstrates parent/direct-child accounting for instrumented wrappers; its exclusive time includes uninstrumented descendants, so label it accurately.

## Bound and engineering evidence

Recommend a harness hard cap of 1200 seconds for the one full pytest node, shorter than the unchanged 1800-second fixture trial. Existing quota pacing alone needs at least six real 60-second gaps; a fast unit-style timeout would be invalid. The previous complete attempt ended FAIL after 622.735 seconds with six exchanges. Use faulthandler periodic stack dump at 300 seconds and an explicit own-child dump on timeout. No reruns or automatic retry plugin.

Design v3 proposed settlement TX <=20 seconds and actual precommit lease margin >=8 seconds as a candidate engineering criterion, not a product bound or already-approved pass. Root should explicitly retain or revise that review criterion before launch. Report all actual margins and totals even if the functional assertions pass; no claimed Windows/PG/real semantics or real free-account acceptance.

## Failure preservation and exactly-once launch

Before launch freeze source/test/observer hashes and actual HEAD, list the exact one node and synthetic SQLite URL (no credentials), save command/environment-name-only manifest. Put the one child PID/process group and deadline in a new run directory. Preserve original pytest stdout/stderr, XML, every existing fixture receipt, mock-exchanges, fixture DB and journals; do not reopen/resume old fixtures or copy unknown bundles.

Keep observer aggregates in memory during critical DB transactions; flush only at Worker stage exit or after original rollback/commit and pytest-call finalization. Do not add file IO inside a guarded proof. Native crash may lose the active in-memory window; preserve stderr/faulthandler and classify that window UNKNOWN rather than claim complete metrics. Record active observer frames at finalization, because old probes could undo wrappers while a background call was still entered.

On Python exception, wrappers re-raise unchanged and finally retain completed spans; the original product rollback/rejection runs as before. On timeout, dump only the recorded own child, then interrupt that child for bounded pytest finalization; if it remains alive after a short recorded grace period, terminate only that child/process group. Never delete locks, kill unknown processes, replay a Run, retry a model, broaden permissions, extend leases or alter assertions to finish. Mark TIMEOUT/CRASH/FAIL distinctly. Freeze after-hashes and compare before/after; changed inputs invalidate qualification. Only after the process ended may root perform an explicitly read-only diagnostic export of that new fixture, keeping DB hashes before/after and not treating diagnostic reads as admission.

## Existing ended evidence read

The older observer `/workspace/pb-model-settlement-implementation-20261019/model_full_stage_probe.py` and ColdReadProbe demonstrate passthrough call locations but are not to be copied wholesale. The prior full result at source 2b67733e was exit 1 / 622.734943 seconds / six Mock exchanges. Its Cold TX body measured 30.308420 seconds, G1 READY at 29.651944 and lease margin 0.332998. Old _journal_chain logs used the parent scope aid and included ancestor traversals. The design arithmetic explicitly recorded check/binding_key/_model_inputs cost UNKNOWN. This plan fixes those attribution gaps; it does not retroactively qualify that ended run.
