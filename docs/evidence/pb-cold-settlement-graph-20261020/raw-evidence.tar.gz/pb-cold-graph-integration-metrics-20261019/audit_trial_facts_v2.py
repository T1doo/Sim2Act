"""Static structural evidence only; this script never imports product code."""
from pathlib import Path
import ast, copy, hashlib, json
O=Path('/workspace/pb-cold-graph-integration-metrics-20261019')
P=O/'candidate-trial-facts-v2/src/sim2act'
V=O/'v1/candidate-trial-facts/src/sim2act'
report=json.loads((O/'trial-facts-static-check.json').read_text())
checks={};shared_restored={}
skip_names={'require','_require','dict','tuple','list','set','str','int','float','bytes','bool','type','isinstance','len','all','any','next','iter','min','max','getattr','sorted','select','DomainError','ValueError','Exception','BaseException','_guard','_trial_result','_graph_trial_pin'}
skip_attrs={'require','get','pop','append','index','where','select_from','join','order_by','with_for_update','in_','as_string','as_integer','as_boolean','label','_graph_trial_pin','_trial_result'}
for n in ('production_trial_policy.py','pa_trial_dispatch.py','natural_source_archives.py','natural_live_admission.py'):
 tree=ast.parse((P/n).read_text());before=ast.parse((V/n).read_text())
 old={f.name:f for f in before.body if isinstance(f,ast.FunctionDef)}
 fs={f.name:f for f in tree.body if isinstance(f,ast.FunctionDef)}
 per={}
 for name,f in fs.items():
  strict=name.startswith('_graph_') and name!='_graph_trial_pin'
  optional=any(a.arg=='_guard' for a in f.args.kwonlyargs)
  if not strict and not optional:continue
  # Inspect only normal proof body, excluding fixed closure and exception cleanup.
  body=next((x.body for x in f.body if strict and isinstance(x,ast.Try)),f.body)
  parent={child:node for stmt in body for node in ast.walk(stmt) for child in ast.iter_child_nodes(node)}
  unguarded=[];guarded=0
  for stmt in body:
   for call in ast.walk(stmt):
    if not isinstance(call,ast.Call):continue
    nm=call.func.id if isinstance(call.func,ast.Name) else call.func.attr if isinstance(call.func,ast.Attribute) else None
    if isinstance(call.func,ast.Name) and nm in skip_names or isinstance(call.func,ast.Attribute) and nm in skip_attrs:continue
    owner=parent.get(call)
    if isinstance(owner,ast.Call) and owner.args and owner.args[0] is call and isinstance(owner.func,(ast.Name,ast.Attribute)) and (owner.func.id if isinstance(owner.func,ast.Name) else owner.func.attr)=='_trial_result':guarded+=1
    else:unguarded.append(ast.unparse(call.func))
  assert not unguarded,(n,name,unguarded)
  per[name]={'eligible_callees_wrapped':guarded,'unguarded_eligible_calls':unguarded}
  # For previously existing shared helpers without newly extracted predicates,
  # stripping only result pins/optional guard restores their exact v1 AST.
  if optional and name in old:
   class Restore(ast.NodeTransformer):
    def visit_Call(self,node):
     node=self.generic_visit(node)
     nm=node.func.id if isinstance(node.func,ast.Name) else node.func.attr if isinstance(node.func,ast.Attribute) else None
     if nm=='_trial_result':return node.args[0]
     node.keywords=[x for x in node.keywords if x.arg!='_guard']
     return node
   restored=Restore().visit(copy.deepcopy(f))
   restored.args.kwonlyargs=[];restored.args.kw_defaults=[]
   # Optional source-local gate imports carry no behavior and prevent cycles.
   prior=old[name]
   if n=='natural_source_archives.py' and not any(isinstance(x,ast.ImportFrom) and any(a.name=='natural_live_admission' for a in x.names) for x in prior.body):
    restored.body=[x for x in restored.body if not(isinstance(x,ast.ImportFrom) and any(a.name=='natural_live_admission' for a in x.names))]
   equal=ast.dump(restored,include_attributes=False)==ast.dump(prior,include_attributes=False)
   shared_restored[n+':'+name]=equal
 checks[n]=per
# These helpers intentionally changed only by calls to separately shared original predicates.
allowed_changed={'natural_source_archives.py:_source_bodies_from_rows'}
assert {k for k,v in shared_restored.items() if not v} <= allowed_changed,shared_restored
report.update({'apply_check':'PASS (read-only git apply --check; not applied)', 'sensitive_call_structure':'PASS', 'shared_guard_strip_restores_v1_ast':shared_restored, 'call_boundary_audit':checks,'patch_sha256':hashlib.sha256((O/'trial-facts-v2.patch').read_bytes()).hexdigest()})
(O/'trial-facts-static-check.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'guard_structure':'PASS','eligible_call_sites':sum(x['eligible_callees_wrapped'] for fs in checks.values() for x in fs.values()),'shared_ast_restored':sum(shared_restored.values()),'intentional_shared_leaf_extractions':sorted(k for k,v in shared_restored.items() if not v),'tests':'NOT_RUN'},indent=2))
