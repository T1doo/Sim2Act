from pathlib import Path
import ast, difflib, hashlib, json, textwrap
R=Path('/workspace/Sim2Act')
O=Path('/workspace/pb-cold-graph-integration-metrics-20261019')
names=['production_trial_policy.py','pa_trial_dispatch.py','natural_source_archives.py','natural_live_admission.py']
old={n:(R/'src/sim2act'/n).read_text() for n in names}
new=dict(old)

def replace(n,a,b):
 assert new[n].count(a)==1,(n,a[:100],new[n].count(a))
 new[n]=new[n].replace(a,b,1)

def append(n,s): new[n]+='\n\n'+textwrap.dedent(s).strip()+'\n'

def extract(n,fn,start,end,signature,call):
 tree=ast.parse(new[n]); f=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name==fn)
 lines=new[n].splitlines(True); source=''.join(lines[f.lineno-1:f.end_lineno])
 i=source.index(start); j=source.index(end,i) if end else len(source)
 block=source[i:j]
 replace(n,block,call)
 append(n,signature+'\n'+block)
 return block

# Preserve the default check_run SQL and first error; share its pure result only.
n='production_trial_policy.py'
f=next(x for x in ast.parse(old[n]).body if isinstance(x,ast.FunctionDef) and x.name=='check_run')
s=''.join(old[n].splitlines(True)[f.lineno-1:f.end_lineno]); pos=s.index('    return RunCheck(')
ret=s[pos:]
replace(n,ret,'    return _run_check_from_facts(original, expected, approval, phase, run, at, stage,\n                                 run_id, version, fence, worker_id)\n')
append(n,'def _run_check_from_facts(original, expected, approval, phase, run, at, stage,\n                          run_id, version, fence, worker_id):\n    """Original result fields only, after fresh complete Run/phase predicates."""\n'+ret)
append(n,'''def _graph_check_run(graph, store, c, user, contract, key, stage, run_id,
                     version, fence, worker_id, stage_facts):
    """Consume an assembled complete graph stage; never accept an Authority DTO.

    stage_facts is (job,bound,Generate candidate,Generate metadata,
    Generate job,Generate frozen,accounted Generate,accounted Source,extraction).
    Its producers are fixed graph nodes; _graph_stage_current replays every
    original cross-role predicate, not an opaque checked flag or hash summary.
    """
    from . import natural_live_admission as admission
    admission._graph_trial_pin(graph, store, c)
    _require(stage == "cold")
    original, expected = _requirements(user, contract, key)
    approval, phase, run, at = admission._graph_run_context(
        graph, store, c, user, original, key, stage, run_id, version, fence, stage_facts)
    _require(type(worker_id) is str and bool(worker_id) and run["worker_id"] == worker_id)
    admission._graph_trial_pin(graph, store, c)
    return _run_check_from_facts(original, expected, approval, phase, run, at, stage,
                                 run_id, version, fence, worker_id)
''')

# Shared same-aid scalar and body predicates, extracted at the old call positions.
n='pa_trial_dispatch.py'
f=next(x for x in ast.parse(new[n]).body if isinstance(x,ast.FunctionDef) and x.name=='_journal_owner')
s=''.join(new[n].splitlines(True)[f.lineno-1:f.end_lineno]);i=s.index('    gate.require(header is not None');block=s[i:s.index('    return header',i)]
replace(n,block,'    _journal_owner_from_facts(b, run, header)\n')
append(n,'def _journal_owner_from_facts(b, run, header):\n'+block)
# Slot phase predicate is shared without moving its original reads.
f=next(x for x in ast.parse(new[n]).body if isinstance(x,ast.FunctionDef) and x.name=='_journal_slot')
s=''.join(new[n].splitlines(True)[f.lineno-1:f.end_lineno]);i=s.index('    gate.require(item.run_id');block=s[i:s.index('    return slot',i)]
replace(n,block,'    _journal_slot_identity_from_facts(b, run, header, item, approval, phase_fp)\n')
append(n,'def _journal_slot_identity_from_facts(b, run, header, item, approval, phase_fp):\n'+block)
# Complete body leaf at same request/response loop point.
f=next(x for x in ast.parse(new[n]).body if isinstance(x,ast.FunctionDef) and x.name=='_journal_chain')
s=''.join(new[n].splitlines(True)[f.lineno-1:f.end_lineno]);i=s.index('        gate.require(saved["request"]');j=s.index('        payloads.append(payload)',i)
block=s[i:j]
replace(n,block,'        payload = _journal_body_from_facts(b, run, aid, kind, scope, meta, saved)\n')
append(n,'def _journal_body_from_facts(b, run, aid, kind, scope, meta, saved):\n'+textwrap.dedent(block).replace('\n','\n    ').join(['    ','']) if False else 'def _journal_body_from_facts(b, run, aid, kind, scope, meta, saved):\n'+textwrap.indent(textwrap.dedent(block),'    ')+'    return payload\n')
# Stage header through the exact old ownership/phase/key checks.
f=next(x for x in ast.parse(new[n]).body if isinstance(x,ast.FunctionDef) and x.name=='journal_stage_accounted')
s=''.join(new[n].splitlines(True)[f.lineno-1:f.end_lineno]);i=s.index('    gate.require(stage in');j=s.index('    actual = c.execute',i);block=s[i:j]
replace(n,block,'    _journal_stage_header(store, c, user, contract, key, rid, stage)\n')
append(n,'def _journal_stage_header(store, c, user, contract, key, rid, stage):\n'+block)
# No new parsing framework: graph reuses the complete existing journal producer.
append(n,'''def _graph_journal_state(graph, store, c, b):
    gate._graph_trial_pin(graph, store, c)
    gate.require(_production_binding(b) and type(b.contract) is gate.PBTrialContract)
    value = _journal_state(store, c, b)
    gate._graph_trial_pin(graph, store, c)
    return value


def _graph_journal_chain(graph, store, c, b, run, aid, state, cursor, raw=None):
    """Original complete same-aid proof with one already loaded complete J.

    Fresh owned scalar gate, body/seal/event bytes, checked policy binding,
    capture and actual Attempt all remain. No source/stage ancestor is rebuilt.
    """
    from . import production_trial_policy as policy
    from . import production_trial_sender as sender
    gate._graph_trial_pin(graph, store, c)
    header = _journal_owner(c, b, run, aid)
    scope = budget.scope_for(b.contract, b.approval_key)
    payloads = []
    for kind in (REQUEST, RESPONSE):
        meta = _metadata(c, run, aid, kind)
        gate.require(meta is not None and meta["trial_fp"] == b.contract_fingerprint
            and meta["complete"] and meta["omission"] == "NONE")
        saved = budget._load(c, run["principal_id"], run["id"], kind, aid)
        payloads.append(_journal_body_from_facts(b, run, aid, kind, scope, meta, saved))
        gate._graph_trial_pin(graph, store, c)
    wire, payload = payloads
    matches = tuple(s for s in state.slots if s.identity.attempt_id == aid)
    gate.require(len(matches) == 1, "Exact natural trial changed")
    slot = matches[0]
    original, expected = policy._requirements(run["principal_id"], b.contract, b.approval_key)
    policy._bound_from_checked_facts(store, c, run["principal_id"], original, expected,
                                    state, cursor, slot.identity, wire)
    approval = gate._saved(c, run["principal_id"], gate.entity(b.contract), gate.APPROVE,
                           "approve", gate.Approval)
    phase_fp = None
    if slot.identity.stage != "generate":
        phase = gate._saved(c, run["principal_id"], gate.entity(b.contract), gate.PHASE,
                            slot.identity.stage, gate.StageApproveInput)
        phase_fp = fingerprint(phase.authority.model_dump())
    _journal_slot_identity_from_facts(b, run, header, slot.identity, approval, phase_fp)
    capture = sender._captured(c, run["principal_id"], slot.identity)
    gate.require(slot.accepted and slot.attempted and capture is not None
        and slot.settlement == capture.outcome and capture.complete
        and capture.raw_sha256 == hashlib.sha256(payload).hexdigest()
        and capture.body_b64 == base64.b64encode(payload).decode("ascii"))
    parsed = strict_json(payload, 131072)
    canonical, evidence = response_archive(parsed)
    response = _metadata(c, run, aid, RESPONSE)
    gate.require(canonical is not None and response["canonical_sha256"] == evidence["sha256"]
        == capture.canonical_sha256 and capture.canonical_ascii_bytes == evidence["bytes"])
    if raw is not None:
        gate.require(response_archive(raw) == (canonical, evidence))
    actual = c.execute(select(attempts).where(attempts.c.run_id == run["id"],
                                               attempts.c.id == aid)).mappings().one()
    _journal_attempt_from_facts(b, wire, slot, actual)
    gate._graph_trial_pin(graph, store, c)
    return slot, capture, parsed, actual, wire, payload


def _graph_stage_accounted(graph, store, c, b, state, cursor, rid, stage):
    """Complete Generate/Source V accounting, retaining every actual aid.

    Returns (full Run, ordered actual Attempts, ordered complete chains,
    ordered NS reads). No stage Authority is accepted as a substitute.
    """
    gate._graph_trial_pin(graph, store, c)
    gate.require(stage in ("generate", "source") and _production_binding(b))
    user, contract, key = b.contract.principal_id, b.contract, b.approval_key
    _journal_stage_header(store, c, user, contract, key, rid, stage)
    actual = tuple(c.execute(select(attempts).where(attempts.c.run_id == rid)
                   .order_by(attempts.c.created_at, attempts.c.id)).mappings().all())
    gate.require(len(actual) == (3 if stage == "generate" else 2))
    markers = [a["parameters"].get("pa_trial_binding", {}) for a in actual]
    gate.require(all(m.get("version") == b.version and m.get("account_id") == b.account_id
        and m.get("trial_fingerprint") == b.contract_fingerprint
        and m.get("approval_key") == key for m in markers))
    run = c.execute(select(runs).where(runs.c.id == rid)).mappings().one()
    _stage_slots_from_facts(state, actual, rid, stage)
    chains, ns_reads = [], []
    for a in actual:
        chain = _graph_journal_chain(graph, store, c, b, run, a["id"], state, cursor)
        slot, capture, parsed, checked, wire, payload = chain
        _stage_usage_from_facts(a, stage, slot, parsed, checked)
        if stage == "generate":
            gate.require(a["parameters"].get("generation_raw_evidence") == response_archive(parsed)[1]
                and a["parameters"].get("generation_received_raw") == response_archive(parsed)[0])
        else:
            from . import natural_source_archives as archive
            from .db import operations
            request, original_wire = archive._read(c, user, run, a["id"], archive.REQUEST)
            body, archived = archive._read(c, user, run, a["id"], archive.RESPONSE)
            _stage_source_archive_from_facts(a, body, archived, original_wire, slot, capture, parsed)
            gate.require(original_wire == wire and archived == payload)
            op = c.execute(select(operations.c.status).where(operations.c.run_id == rid,
                operations.c.id == a["parameters"]["natural_spec"]["operation_id"])).scalar_one()
            gate.require(op == "VERIFIED")
            ns_reads.append((a["id"], request, original_wire, body, archived))
        chains.append(chain)
        gate._graph_trial_pin(graph, store, c)
    return run, actual, tuple(chains), tuple(ns_reads)


def _graph_pb_accounting(graph, store, c, b, generation, state):
    """Production J/Generate marker selection with all original fresh edges."""
    from .spec_production import VERSION
    gate._graph_trial_pin(graph, store, c)
    gate.require(_production_binding(b) and type(b.contract) is gate.PBTrialContract)
    user, contract, key = b.contract.principal_id, b.contract, b.approval_key
    gate._approved(store, c, user, contract, key)
    gate.require(generation["principal_id"] == user
        and generation["project_id"] == contract.project_id
        and generation["runtime_id"] == contract.runtime_id
        and generation["request_key"] == contract.stage_keys.generate)
    markers = c.execute(select(*[attempts.c.parameters["pa_trial_binding"][k].as_string().label(k)
        for k in ("version", "trial_fingerprint", "approval_key", "account_id")])
        .where(attempts.c.run_id == generation["id"])).mappings().all()
    gate.require(len(markers) == 3 and all(m["version"] == VERSION
        and m["trial_fingerprint"] == fingerprint(contract.model_dump())
        and m["approval_key"] == key and m["account_id"] == b.account_id for m in markers))
    _journal_source(store, c, b)
    gate._graph_trial_pin(graph, store, c)
    first = [s for s in state.slots if s.identity.stage in ("generate", "source")]
    source_ids = {s.identity.run_id for s in first if s.identity.stage == "source"}
    gate.require(not state.halted and len(first) == 5 and all(s.accepted for s in first)
        and len(source_ids) == 1)
    return next(iter(source_ids))


def _graph_pb_archive_chain(graph, store, c, b, state, resolved, source_facts):
    """Join full NS/controller byte sets; not only their public digests."""
    gate._graph_trial_pin(graph, store, c)
    receipt = resolved.public_receipt
    source, actual, chains, ns_reads = source_facts
    slots = [s for s in state.slots if s.identity.stage == "source"]
    gate.require(_production_binding(b) and not state.halted
        and len(slots) == len(receipt["attempts"]) == len(chains) == len(ns_reads) == 2
        and receipt["verification"] == "SPEC_PRODUCTION_CONTROLLER_ARCHIVE"
        and receipt["live_allowed"] is False and receipt["source_run_id"] == source["id"])
    for slot, proof in zip(slots, receipt["attempts"], strict=True):
        matching = tuple(chain for chain in chains if chain[3]["id"] == proof["attempt_id"])
        gate.require(len(matching) == 1)
        linked, capture, parsed, checked, wire, payload = matching[0]
        gate.require(linked == slot and checked in actual
            and slot.identity.run_id == source["id"]
            and slot.identity.attempt_id == proof["attempt_id"]
            and slot.identity.wire_sha256 == proof["request_sha256"]
            and slot.identity.wire_bytes == proof["request_bytes"]
            and capture.raw_sha256 == proof["decoded_body_sha256"]
            and capture.raw_bytes == proof["decoded_body_bytes"]
            and capture.canonical_sha256 == proof["canonical_ascii_sha256"]
            and capture.canonical_ascii_bytes == proof["canonical_ascii_bytes"])
        index = receipt["attempts"].index(proof)
        gate.require(resolved.request_bodies[index] == wire
            and resolved.response_bodies[index] == payload)
    gate._graph_trial_pin(graph, store, c)
''')

# Source body rows/keys/exchanges remain shared with the default wrapper.
n='natural_source_archives.py'
f=next(x for x in ast.parse(new[n]).body if isinstance(x,ast.FunctionDef) and x.name=='_source_bodies')
s=''.join(new[n].splitlines(True)[f.lineno-1:f.end_lineno]);i=s.index('    production = type(ledger) is Ledger');tail=s[i:]
replace(n,tail,'    return _source_bodies_from_rows(c, user, contract, job, ledger, rows)\n')
new[n]=new[n].replace('    from . import natural_live_admission as gate\n    from .production_trial_policy import Ledger\n    from .spec_production import evidence_mode\n\n    source_id = job["id"]\n    rows = c.execute', '    source_id = job["id"]\n    rows = c.execute', 1)
append(n,'def _source_bodies_from_rows(c, user, contract, job, ledger, rows):\n    from . import natural_live_admission as gate\n    from .production_trial_policy import Ledger\n    from .spec_production import evidence_mode\n\n    source_id = job["id"]\n'+tail)
# Pure shared extraction target predicate at the original location.
f=next(x for x in ast.parse(new[n]).body if isinstance(x,ast.FunctionDef) and x.name=='_resolve_trial_source')
s=''.join(new[n].splitlines(True)[f.lineno-1:f.end_lineno]);i=s.index('        require(extracted.review.source_run_id');j=s.index('        requests, responses, public',i);block=s[i:j]
replace(n,block,'        _source_extraction_from_facts(contract, source_id, source_proof, extracted, target, goal)\n')
append(n,'def _source_extraction_from_facts(contract, source_id, source_proof, extracted, target, goal):\n    cold = contract.bindings[1]\n'+textwrap.indent(textwrap.dedent(block),'    '))
append(n,'''def _graph_source_bodies(graph, store, c, user, contract, ledger, source_facts):
    """Use full ordered NS reads from the actual accounted Source producer."""
    from . import natural_live_admission as gate
    from .production_trial_policy import Ledger
    from .spec_production import evidence_mode
    gate._graph_trial_pin(graph, store, c)
    job, rows, chains, ns_reads = source_facts
    require(type(ledger) is Ledger and evidence_mode(c, job) == "LIVE")
    slots = _source_slots_from_facts(rows, ledger, True)
    expected_ids = {r["id"] for r in rows}
    for kind in (REQUEST, RESPONSE):
        _source_keys_from_facts(expected_ids, gate._keys(c, user, job["id"], kind))
    require(len(rows) == len({r["id"] for r in rows}) == len(ns_reads) == len(chains) == 2)
    requests, responses, public = [], [], []
    for slot in slots:
        aid = slot["reservation"]["request_key"]
        own_rows = tuple(r for r in rows if r["id"] == aid)
        own_reads = tuple(r for r in ns_reads if r[0] == aid)
        own_chains = tuple(r for r in chains if r[3]["id"] == aid)
        require(len(own_rows) == len(own_reads) == len(own_chains) == 1)
        row, read, chain = own_rows[0], own_reads[0], own_chains[0]
        _, request, wire, response, received = read
        require(row["mode"] == "LIVE" and row["status"] == "VERIFIED"
            and row["request_model"] == row["response_model"] == contract.model
            and slot["accepted"] is True and slot["settlement"] is not None
            and chain[3] == row and chain[4] == wire and chain[5] == received)
        canonical = _source_exchange_from_facts(contract, row, slot, request, wire,
                                               response, received, True)
        requests.append(wire)
        responses.append(received)
        public.append(dict(attempt_id=aid, request_bytes=len(wire), request_sha256=request.sha256,
            decoded_body_bytes=len(received), decoded_body_sha256=response.sha256,
            canonical_ascii_bytes=canonical["bytes"], canonical_ascii_sha256=canonical["sha256"]))
        gate._graph_trial_pin(graph, store, c)
    return tuple(requests), tuple(responses), public


def _graph_resolve_trial_source(graph, store, c, user, contract, approval_key,
                                ledger, source_stage_facts, source_proof, source_facts, extraction_facts):
    """Assemble the original receipt from complete Source V + extraction V.

    source_stage_facts contains the complete original role facts; Authority is
    constructed here, never accepted as a DTO. source_proof is produced only
    by full Source receipt/result validation. The
    extraction tuple is (owned full draft,typed ExtractInput,full target,Goal)
    produced by the complete extraction/origin node, never by a paired P alone.
    """
    from . import natural_live_admission as gate
    from . import pa_spec_apps as spec
    gate._graph_trial_pin(graph, store, c)
    require(type(contract) is gate.PBTrialContract
        and gate.PBTrialContract.model_validate(contract.model_dump()) == contract)
    with store.proof_authorities(c) as authorities:
        approval = gate._approved(store, c, user, contract, approval_key)
        require(gate._keys(c, user, gate.entity(contract), gate.PHASE) <= {"source", "cold"})
        current, job = gate._graph_stage_current(
            graph, store, c, user, contract, "source", source_stage_facts)
        require(source_facts[0] == job)
        accepted = gate._saved(c, user, gate.entity(contract), gate.PHASE, "source", gate.StageApproveInput)
        require(accepted.approval_key == approval_key and accepted.authority == current
            and accepted.expected_authority_fingerprint == fingerprint(current.model_dump())
            and job["status"] == "SUCCEEDED" and not job["cancel_intent"])
        draft, extracted, target, goal = extraction_facts
        ids = c.execute(select(delivery_graph_requests.c.app_id).join(app_drafts,
            app_drafts.c.id == delivery_graph_requests.c.app_id).where(
            app_drafts.c.project_id == contract.project_id,
            delivery_graph_requests.c.principal_id == user,
            delivery_graph_requests.c.kind == __import__(__package__ + ".pb_natural_specs", fromlist=["EXTRACT"]).EXTRACT,
            delivery_graph_requests.c.request_key == contract.extraction_request_key)).scalars().all()
        require(ids == [draft["id"]] and spec.scope_gate(store, c, user, draft["id"]))
        from . import pb_natural_specs as pb
        original, _ = pair(c, user, draft["id"], pb.EXTRACT, contract.extraction_request_key, pb.ExtractInput)
        require(original == extracted)
        _source_extraction_from_facts(contract, job["id"], source_proof, extracted, target, goal)
        requests, responses, public = _graph_source_bodies(graph, store, c, user, contract, ledger, source_facts)
        cold = contract.bindings[1]
        receipt = dict(version=VERSION, verification=_source_verification(ledger),
            trial_fingerprint=fingerprint(contract.model_dump()),
            approval_fingerprint=fingerprint(approval.model_dump()), source_run_id=job["id"],
            source_app_id=current.app_id, extraction_app_id=draft["id"],
            extraction_request_key=contract.extraction_request_key,
            source_proof_fingerprint=fingerprint(source_proof),
            extraction_recipe_fingerprint=fingerprint(contract.extraction_recipe.model_dump()),
            cold_goal_fingerprint=cold.goal_fingerprint, attempts=public,
            live_allowed=False, dispatch_authorized=False, new_model_requests=0,
            new_reservations=0, project_writes=0, formal_publication_enabled=False)
        gate._approved(store, c, user, contract, approval_key)
        require(spec.job_scope_gate(store, c, user, job["id"])
            and spec.scope_gate(store, c, user, draft["id"]))
        store.recheck_proof_authorities(c, {"_call_authorities": tuple(sorted(authorities))})
        require(time.time() < contract.expires_at, "Original trial approval expired during source proof")
        gate._graph_trial_pin(graph, store, c)
        return ResolvedSourceArchive(receipt, requests, responses)
''')
# avoid dynamic import: collector already owns the explicit module, not a resolver.
new[n]=new[n].replace('    from . import pa_spec_apps as spec\n    gate._graph_trial_pin(graph, store, c)\n    require(type(contract)', '    from . import pa_spec_apps as spec\n    from . import pb_natural_specs as pb\n    gate._graph_trial_pin(graph, store, c)\n    require(type(contract)',1)
new[n]=new[n].replace('__import__(__package__ + ".pb_natural_specs", fromlist=["EXTRACT"]).EXTRACT','pb.EXTRACT')

# Explicit graph stage assembly from full role inputs; no ancestor full verifier.
n='natural_live_admission.py'
append(n,'''def _graph_trial_pin(graph, store, c):
    """Continuity only. The graph never supplies a Grant, permit or source."""
    from .natural_spec_runtime import _ColdGraphRead
    require(type(graph) is _ColdGraphRead)
    graph.check(store, c)


def _graph_stage_current(graph, store, c, user, contract, stage, stage_facts):
    """Original PB stage cross-role predicates after complete graph producers.

    No paired Authority is an input. Generate/Source accounting are full actual
    row/chain/NS-byte tuples from _graph_stage_accounted. Cold extraction facts
    are the complete pb.verify-equivalent graph node, not a request fingerprint.
    """
    from . import natural_specs, pa_spec_apps
    _graph_trial_pin(graph, store, c)
    require(type(contract) is PBTrialContract and stage in ("source", "cold"))
    (job, bound, raw, metadata, gen, frozen, generated, source, extraction) = stage_facts
    require(pa_spec_apps.job_scope_gate(store, c, user, job["id"]))
    require(job["principal_id"] == user and job["project_id"] == contract.project_id)
    snapshot, draft, release = bound["snapshot"], bound["draft"], bound["release"]
    require(natural_specs.is_candidate(draft["candidate"]))
    # Every Release/family/dependency/input predicate was completed by the exact
    # role's graph binding node. Recheck only its current owned pointers here.
    inst, current_release = _stage_instance_after_bound(store, c, user, contract.project_id,
        job, snapshot, release, c.info.get("source_proof_write_epoch", 0))
    require(current_release["id"] == release["id"]
        and current_release["fingerprint"] == release["fingerprint"]
        and bound["app_run"]["request_key"] == getattr(contract.stage_keys, stage))
    target = contract.bindings[1 if stage == "cold" else 0]
    _stage_target_from_facts(bound, target)
    gen_id = c.execute(select(runs.c.id).where(runs.c.principal_id == user,
        runs.c.project_id == contract.project_id,
        runs.c.request_key == contract.stage_keys.generate)).scalar()
    require(gen_id is not None and gen["id"] == gen_id)
    require(metadata["runtime_id"] == contract.runtime_id
        and metadata["resource_refs"] == [contract.bindings[0].resource_id])
    approval = _saved(c, user, entity(contract), APPROVE, "approve", Approval)
    _stage_generate_from_facts(contract, approval, gen, frozen)
    require(generated[0] == gen and len(generated[1]) == len(generated[2]) == 3)
    from .pa_trial_dispatch import _stage_usage_from_facts
    for chain in generated[2]:
        require(chain[3] in generated[1])
        _stage_usage_from_facts(chain[3], "generate", chain[0], chain[2], chain[3])
    original = draft["candidate"]
    if stage == "cold":
        require(type(extraction) is tuple and len(extraction) == 4)
        extraction_draft, body, extraction_target, extraction_goal = extraction
        source_run, source_actual, source_chains, source_ns = source
        require(extraction_draft["id"] == draft["id"]
            and body.review.source_run_id == source_run["id"]
            and body.review.request_key == contract.extraction_request_key
            and body.review.recipe == contract.extraction_recipe,
            "P-B requires this original trial's successful source and exact extraction")
        require(len(source_actual) == len(source_chains) == len(source_ns) == 2)
        for chain in source_chains:
            require(chain[3] in source_actual)
            _stage_usage_from_facts(chain[3], "source", chain[0], chain[2], chain[3])
    else:
        require("spec_task" not in original, "Only P-B cold may use an extracted task")
        if "spec_binding" in original:
            ids = c.execute(select(task_extractions.c.task_id).where(
                task_extractions.c.app_id == draft["id"], task_extractions.c.principal_id == user)).scalars().all()
            require(ids == [gen_id])
        else:
            require(original.get("goal_application", {}).get("run_id") == gen_id)
    expected_recipe = contract.extraction_recipe.model_dump(exclude_none=True) if stage == "cold" else raw["spec_recipe"]
    require(fingerprint(expected_recipe) == fingerprint(draft["candidate"]["spec_recipe"]))
    if stage == "cold":
        accepted = _saved(c, user, entity(contract), PHASE, "source", StageApproveInput)
        require(accepted.approval_key == approval.request.request_key
            and accepted.authority.contract_fingerprint == fingerprint(contract.model_dump())
            and accepted.authority.generation_run_id == gen_id
            and accepted.authority.run_id == source[0]["id"])
    timing = _stage_deadlines(c, user, contract, stage, gen_id)
    fields = _stage_authority_fields_from_facts(contract, stage, timing, job, bound, inst,
                                               draft, release, gen_id, raw, target)
    authority = StageAuthority(**fields, authorization_fingerprint=authorization_fingerprint(
        c, user, contract.project_id, job["runtime_id"], [x.resource_id for x in contract.bindings]))
    _graph_trial_pin(graph, store, c)
    return authority, job


def _graph_run_context(graph, store, c, user, contract, approval_key, stage, run_id,
                       expected_version, fence, stage_facts):
    """Original live edges around complete graph stage reconstruction."""
    _graph_trial_pin(graph, store, c)
    require(type(contract) is PBTrialContract and stage == "cold")
    approval = _approved(store, c, user, contract, approval_key)
    require(_keys(c, user, entity(contract), PHASE) <= {"source", "cold"})
    accepted = _saved(c, user, entity(contract), PHASE, stage, StageApproveInput)
    require(accepted.approval_key == approval_key)
    phase, _ = _graph_stage_current(graph, store, c, user, contract, stage, stage_facts)
    require(phase == accepted.authority
        and fingerprint(phase.model_dump()) == accepted.expected_authority_fingerprint)
    run = c.execute(select(runs.c.id, runs.c.project_id, runs.c.principal_id,
        runs.c.runtime_id, runs.c.request_key, runs.c.status, runs.c.cancel_intent,
        runs.c.version, runs.c.fence, runs.c.lease_until, runs.c.created_at, runs.c.worker_id,
        runs.c.resource_refs).where(runs.c.id == run_id).with_for_update()).mappings().first()
    at = time.time()
    _require_run_context_row(user, contract, stage, run, expected_version, fence, approval, phase, at)
    _graph_trial_pin(graph, store, c)
    return approval, phase, run, at
''')

# Share remaining original capture predicates at their exact default positions.
n='pa_trial_dispatch.py'
tree=ast.parse(new[n]); f=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='_journal_chain')
src=''.join(new[n].splitlines(True)[f.lineno-1:f.end_lineno])
i=src.index('    gate.require(slot.accepted'); j=src.index('    parsed = strict_json',i)
block=src[i:j]
assert new[n].count(block)==2
new[n]=new[n].replace(block,'    _journal_capture_from_facts(slot, capture, payload)\n')
append(n,'def _journal_capture_from_facts(slot, capture, payload):\n'+block)
i=src.index('    gate.require(canonical is not None'); j=src.index('    actual = c.execute',i)
block=src[i:j]
assert new[n].count(block)==2
new[n]=new[n].replace(block,'    _journal_canonical_from_facts(response, capture, canonical, evidence, raw)\n')
append(n,'def _journal_canonical_from_facts(response, capture, canonical, evidence, raw):\n'+block)

# AST-only validation and unified diff. No product imports, tests, DB or network.
patch=''
metadata={}
for n in names:
 ast.parse(new[n],filename=n)
 p=O/'candidate-trial-facts'/'src'/'sim2act'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(new[n])
 patch+=''.join(difflib.unified_diff(old[n].splitlines(True),new[n].splitlines(True),
   fromfile='a/src/sim2act/'+n,tofile='b/src/sim2act/'+n))
 metadata[n]={'base_sha256':hashlib.sha256(old[n].encode()).hexdigest(),
              'candidate_sha256':hashlib.sha256(new[n].encode()).hexdigest(),
              'new_functions':[f.name for f in ast.parse(new[n]).body if isinstance(f,ast.FunctionDef)
               and f.name not in {x.name for x in ast.parse(old[n]).body if isinstance(x,ast.FunctionDef)}]}
(O/'trial-facts.patch').write_text(patch)
(O/'trial-facts-metadata.json').write_text(json.dumps({'status':'EXTERNAL_CANDIDATE_AST_ONLY_NOT_APPLIED_NOT_TESTED',
 'base_head':'dc34ce4b1311810e27cd33a0cd156b6f84333666','files':metadata,'patch_sha256':hashlib.sha256(patch.encode()).hexdigest()},indent=2)+'\n')
print(json.dumps({'ast':'PASS','patch_bytes':len(patch.encode()),'patch_sha256':hashlib.sha256(patch.encode()).hexdigest(),
 'new_functions':{n:metadata[n]['new_functions'] for n in names}},indent=2))
