"""External candidate only: AST/text transformations, no product imports or execution."""
from pathlib import Path
import ast, difflib, hashlib, json, textwrap
O=Path('/workspace/pb-cold-graph-integration-metrics-20261019')
R=Path('/workspace/Sim2Act')
names=['production_trial_policy.py','pa_trial_dispatch.py','natural_source_archives.py','natural_live_admission.py']
old={n:(R/'src/sim2act'/n).read_text() for n in names}
new={n:(O/'v1/candidate-trial-facts/src/sim2act'/n).read_text() for n in names}

def functions(n):return {f.name:f for f in ast.parse(new[n]).body if isinstance(f,ast.FunctionDef)}
def getfn(n,name):
 f=functions(n)[name];return ''.join(new[n].splitlines(True)[f.lineno-1:f.end_lineno])
def putfn(n,name,s):
 original=getfn(n,name);assert new[n].count(original)==1
 new[n]=new[n].replace(original,s.rstrip()+'\n',1)
def append(n,s):new[n]+='\n\n'+textwrap.dedent(s).strip()+'\n'
def replfn(n,name,a,b,count=1):
 s=getfn(n,name);assert s.count(a)==count,(n,name,a[:100],s.count(a));putfn(n,name,s.replace(a,b))
def shared(n,name,a,signature,call):
 replfn(n,name,a,call)
 append(n,signature+'\n'+textwrap.indent(textwrap.dedent(a),'    '))

# Single source for the original stage cross-role predicates. Original wrappers
# retain these checks at their exact prior positions; graph callers use the same leaves.
n='natural_live_admission.py'
shared(n,'_stage_current_bound','''    require(current_release["id"] == release["id"]
            and current_release["fingerprint"] == release["fingerprint"]
            and bound["app_run"]["request_key"] == getattr(contract.stage_keys, stage))
''','def _stage_release_from_facts(contract, stage, bound, current_release, release):',
 '    _stage_release_from_facts(contract, stage, bound, current_release, release)\n')
shared(n,'_stage_current_bound','''    require(metadata["runtime_id"] == contract.runtime_id
            and metadata["resource_refs"] == [contract.bindings[0].resource_id])
''','def _stage_generation_metadata_from_facts(contract, metadata):',
 '    _stage_generation_metadata_from_facts(contract, metadata)\n')
shared(n,'_stage_current_bound','''        require("spec_task" not in original, "Only P-B cold may use an extracted task")
''','def _stage_plain_origin_from_facts(original):',
 '        _stage_plain_origin_from_facts(original)\n')
shared(n,'_stage_current_bound','''        require(origin == gen_id)
''','def _stage_generation_origin_from_facts(origin, gen_id):',
 '        _stage_generation_origin_from_facts(origin, gen_id)\n')
shared(n,'_stage_current_bound','''        require(original.get("goal_application", {}).get("run_id") == gen_id)
''','def _stage_goal_origin_from_facts(original, gen_id):',
 '        _stage_goal_origin_from_facts(original, gen_id)\n')
shared(n,'_stage_current_bound','''    require(fingerprint(expected_recipe) == fingerprint(draft["candidate"]["spec_recipe"]))
''','def _stage_recipe_from_facts(expected_recipe, draft):',
 '    _stage_recipe_from_facts(expected_recipe, draft)\n')
shared(n,'_stage_current_bound','''        require(source.approval_key == approval.request.request_key
            and source.authority.contract_fingerprint == fingerprint(contract.model_dump())
            and source.authority.generation_run_id == gen_id)
''','def _stage_source_phase_from_facts(contract, approval, gen_id, source):',
 '        _stage_source_phase_from_facts(contract, approval, gen_id, source)\n')
shared(n,'_run_context','''        require(phase == accepted.authority
                and fingerprint(phase.model_dump()) == accepted.expected_authority_fingerprint)
''','def _stage_accepted_from_facts(phase, accepted):',
 '        _stage_accepted_from_facts(phase, accepted)\n')
shared(n,'_pb_origin','''        require(source_id is not None
            and body.review.source_run_id == source_id
            and body.review.request_key == contract.extraction_request_key
            and body.review.recipe == contract.extraction_recipe,
            "P-B requires this original trial's successful source and exact extraction")
''','def _stage_pb_origin_from_facts(contract, body, source_id):',
 '        _stage_pb_origin_from_facts(contract, body, source_id)\n')
# Rewrite only duplicated predicates in the graph assembler.
replfn(n,'_graph_stage_current','''    require(current_release["id"] == release["id"]
        and current_release["fingerprint"] == release["fingerprint"]
        and bound["app_run"]["request_key"] == getattr(contract.stage_keys, stage))
''','    _stage_release_from_facts(contract, stage, bound, current_release, release)\n')
replfn(n,'_graph_stage_current','''    require(metadata["runtime_id"] == contract.runtime_id
        and metadata["resource_refs"] == [contract.bindings[0].resource_id])
''','    _stage_generation_metadata_from_facts(contract, metadata)\n')
replfn(n,'_graph_stage_current','''        require(extraction_draft["id"] == draft["id"]
            and body.review.source_run_id == source_run["id"]
            and body.review.request_key == contract.extraction_request_key
            and body.review.recipe == contract.extraction_recipe,
            "P-B requires this original trial's successful source and exact extraction")
''','''        require(extraction_draft["id"] == draft["id"])
        _stage_pb_origin_from_facts(contract, body, source_run["id"])
''')
replfn(n,'_graph_stage_current','''        require("spec_task" not in original, "Only P-B cold may use an extracted task")
''','        _stage_plain_origin_from_facts(original)\n')
replfn(n,'_graph_stage_current','''            require(ids == [gen_id])
''','''            require(len(ids) == 1)
            _stage_generation_origin_from_facts(ids[0], gen_id)
''')
replfn(n,'_graph_stage_current','''            require(original.get("goal_application", {}).get("run_id") == gen_id)
''','            _stage_goal_origin_from_facts(original, gen_id)\n')
replfn(n,'_graph_stage_current','''    require(fingerprint(expected_recipe) == fingerprint(draft["candidate"]["spec_recipe"]))
''','    _stage_recipe_from_facts(expected_recipe, draft)\n')
replfn(n,'_graph_stage_current','''        require(accepted.approval_key == approval.request.request_key
            and accepted.authority.contract_fingerprint == fingerprint(contract.model_dump())
            and accepted.authority.generation_run_id == gen_id
            and accepted.authority.run_id == source[0]["id"])
''','''        _stage_source_phase_from_facts(contract, approval, gen_id, accepted)
        require(accepted.authority.run_id == source[0]["id"])
''')
replfn(n,'_graph_run_context','''    require(phase == accepted.authority
        and fingerprint(phase.model_dump()) == accepted.expected_authority_fingerprint)
''','    _stage_accepted_from_facts(phase, accepted)\n')
# Share the exact scalar Run query; no query/lock/default error ordering changes.
s=getfn(n,'_run_context');start=s.index('    run = c.execute');end=s.index('    at = time.time()',start)
query=s[start:end]
replfn(n,'_run_context',query,'    run = _run_context_row(c, run_id)\n')
replfn(n,'_graph_run_context',query,'    run = _run_context_row(c, run_id)\n')
append(n,'def _run_context_row(c, run_id):\n'+query+'    return run\n')

# Common production accounting markers and five-slot prefix, no duplicated rules.
n='pa_trial_dispatch.py'
s=getfn(n,'_pb_accounting');start=s.index('        gate.require(len(markers)');end=s.index('        binding = ProductionTrialBinding',start);block=s[start:end]
replfn(n,'_pb_accounting',block,'        _pb_markers_from_facts(contract, key, markers)\n')
append(n,'def _pb_markers_from_facts(contract, key, markers):\n    from .spec_production import VERSION\n'+textwrap.indent(textwrap.dedent(block),'    '))
s=getfn(n,'_pb_accounting');start=s.index('        first = [s');end=s.index('        return binding, state,',start);block=s[start:end]
replfn(n,'_pb_accounting',block,'        source_id = _pb_prefix_source_from_facts(state)\n')
replfn(n,'_pb_accounting','        return binding, state, next(iter(source_ids))\n','        return binding, state, source_id\n')
append(n,'def _pb_prefix_source_from_facts(state):\n'+textwrap.indent(textwrap.dedent(block),'    ')+'    return next(iter(source_ids))\n')
replfn(n,'_graph_pb_accounting','''    gate.require(len(markers) == 3 and all(m["version"] == VERSION
        and m["trial_fingerprint"] == fingerprint(contract.model_dump())
        and m["approval_key"] == key and m["account_id"] == b.account_id for m in markers))
''','''    _pb_markers_from_facts(contract, key, markers)
    gate.require(all(m["account_id"] == b.account_id for m in markers))
''')
s=getfn(n,'_graph_pb_accounting');start=s.index('    first = [s');end=s.index('    return next(iter(source_ids))',start)
replfn(n,'_graph_pb_accounting',s[start:end]+'    return next(iter(source_ids))\n','    return _pb_prefix_source_from_facts(state)\n')
# Shared archive accepted-phase and mode/status predicates also remain single-source.
n='natural_source_archives.py'
shared(n,'_source_prefix','''    require(accepted.approval_key == approval_key and accepted.authority == current
            and accepted.expected_authority_fingerprint == fingerprint(current.model_dump())
            and job["status"] == "SUCCEEDED" and not job["cancel_intent"])
''','def _source_accepted_from_facts(approval_key, accepted, current, job):',
 '    _source_accepted_from_facts(approval_key, accepted, current, job)\n')
replfn(n,'_graph_resolve_trial_source','''        require(accepted.approval_key == approval_key and accepted.authority == current
            and accepted.expected_authority_fingerprint == fingerprint(current.model_dump())
            and job["status"] == "SUCCEEDED" and not job["cancel_intent"])
''','        _source_accepted_from_facts(approval_key, accepted, current, job)\n')
shared(n,'_source_bodies_from_rows','''        require(row["mode"] == ("LIVE" if production else "MOCK") and row["status"] == "VERIFIED"
                and row["request_model"] == row["response_model"] == contract.model
                and slot["accepted"] is True and slot["settlement"] is not None)
''','def _source_row_from_facts(contract, row, slot, production):',
 '        _source_row_from_facts(contract, row, slot, production)\n')
replfn(n,'_graph_source_bodies','''        require(row["mode"] == "LIVE" and row["status"] == "VERIFIED"
            and row["request_model"] == row["response_model"] == contract.model
            and slot["accepted"] is True and slot["settlement"] is not None
            and chain[3] == row and chain[4] == wire and chain[5] == received)
''','''        _source_row_from_facts(contract, row, slot, True)
        require(chain[3] == row and chain[4] == wire and chain[5] == received)
''')
# Remove a redundant local module import only.
n='natural_source_archives.py'
s=getfn(n,'_graph_resolve_trial_source');s=s.replace('        from . import pb_natural_specs as pb\n','');s=s.replace('        return ResolvedSourceArchive(receipt, requests, responses)', '        resolved = ResolvedSourceArchive(receipt, requests, responses)\n    gate._graph_trial_pin(graph, store, c)\n    return resolved');putfn(n,'_graph_resolve_trial_source',s)
n='pa_trial_dispatch.py'
replfn(n,'_metadata','    values = [dict(r) for r in selected.mappings()]\n','    values = gate._trial_result([dict(r) for r in selected.mappings()], _guard)\n')

# Exact pin and fixed sticky cleanup. No methods on an unknown graph are called.
n='natural_live_admission.py'
putfn(n,'_graph_trial_pin','''def _graph_trial_pin(graph, store, c):
    """Continuity only; exact local type, never a Grant, permission or resolver."""
    from .natural_spec_runtime import _ColdGraphRead
    require(type(graph) is _ColdGraphRead)
    try:
        _ColdGraphRead.check(graph, store, c)
    except BaseException:
        _ColdGraphRead.invalidate(graph)
        raise
''')
append(n,'''def _trial_result(value, _guard=None):
    """Post-callee pin before its result is consumed; None keeps original behavior.

    Strict callers pass only a fixed local exact-graph pin closure. This leaf
    does not validate a predicate, resolve anything, or grant authority.
    """
    if _guard is not None:
        _guard()
    return value
''')

# Every multi-step shared private helper reachable in these files accepts the
# same optional guard; all original entry points leave it None.
shared_names={
 'production_trial_policy.py':{'_bound_from_checked_facts','_run_check_from_facts'},
 'pa_trial_dispatch.py':{'_metadata','_journal_source','_journal_state','_journal_owner',
 '_journal_owner_from_facts','_journal_slot_identity_from_facts','_journal_body_from_facts',
 '_journal_stage_header','_journal_attempt_from_facts','_journal_capture_from_facts',
 '_journal_canonical_from_facts','_stage_slots_from_facts','_stage_usage_from_facts',
 '_stage_source_archive_from_facts','_pb_markers_from_facts','_pb_prefix_source_from_facts'},
 'natural_source_archives.py':{'_read','_body_payload_from_facts','_source_bodies_from_rows',
 '_source_extraction_from_facts','_source_exchange_from_facts','_source_slots_from_facts',
 '_source_keys_from_facts','_source_accepted_from_facts','_source_row_from_facts'},
 'natural_live_admission.py':{'_stage_instance_after_bound','_stage_deadlines',
 '_stage_target_from_facts','_stage_generate_from_facts','_stage_authority_fields_from_facts',
 '_stage_release_from_facts','_stage_generation_metadata_from_facts','_stage_plain_origin_from_facts',
 '_stage_generation_origin_from_facts','_stage_goal_origin_from_facts','_stage_recipe_from_facts',
 '_stage_source_phase_from_facts','_stage_accepted_from_facts','_stage_pb_origin_from_facts',
 '_run_context_row','_require_run_context_row'},
}
# Call guard passthrough is by the fixed private function's name, including
# imported aliases. Public ancestor verifiers are never added by this pass.
all_shared=set().union(*shared_names.values())
skip_names={'require','_require','dict','tuple','list','set','str','int','float','bytes','bool',
 'type','isinstance','len','all','any','next','iter','min','max','getattr','sorted','select',
 'DomainError','ValueError','Exception','BaseException','_guard','_trial_result','_graph_trial_pin'}
skip_attrs={'require','get','pop','append','index','where','select_from','join','order_by',
 'with_for_update','in_','as_string','as_integer','as_boolean','label','_graph_trial_pin','_trial_result'}

class GuardCalls(ast.NodeTransformer):
 def __init__(self, module):self.module=module;self.count=0;self.boundaries=[]
 def expr(self, s):return ast.parse(s, mode='eval').body
 def visit_Call(self,node):
  # Preserve lazy predicates/comprehensions: each callee result is pinned at
  # its exact original expression position before any parent can consume it.
  node=self.generic_visit(node)
  name=node.func.id if isinstance(node.func,ast.Name) else node.func.attr if isinstance(node.func,ast.Attribute) else None
  if name in all_shared and not any(k.arg=='_guard' for k in node.keywords):
   node.keywords.append(ast.keyword(arg='_guard',value=ast.Name('_guard',ast.Load())))
  if isinstance(node.func,ast.Name) and name in skip_names or isinstance(node.func,ast.Attribute) and name in skip_attrs:
   return node
  self.count+=1;self.boundaries.append(ast.unparse(node.func))
  call='_trial_result' if self.module=='natural_live_admission.py' else 'gate._trial_result'
  return ast.copy_location(ast.Call(func=self.expr(call),args=[node,ast.Name('_guard',ast.Load())],keywords=[]),node)
 def visit_With(self,node):
  node=self.generic_visit(node)
  check=ast.Expr(ast.Call(func=self.expr('_trial_result' if self.module=='natural_live_admission.py' else 'gate._trial_result'),args=[ast.Constant(None),ast.Name('_guard',ast.Load())],keywords=[]))
  node.body.insert(0,check)
  return [node,check]

boundary_report={}
for n in names:
 graph_names={x for x in functions(n) if x.startswith('_graph_') and x!='_graph_trial_pin'}
 targets=shared_names[n]|graph_names
 boundary_report[n]={}
 for name in sorted(targets):
  f=ast.parse(getfn(n,name)).body[0]
  strict=name in graph_names
  if not strict:
   f.args.kwonlyargs.append(ast.arg(arg='_guard'));f.args.kw_defaults.append(ast.Constant(None))
  tr=GuardCalls(n);f=tr.visit(f)
  # Source module doesn't have a global gate import; local imports avoid new
  # circular dependencies and precede any use of the optional result leaf.
  if n=='natural_source_archives.py' and not any(isinstance(x,ast.ImportFrom) and any(a.name=='natural_live_admission' for a in x.names) for x in f.body):
   imp=ast.parse('from . import natural_live_admission as gate').body[0]
   f.body.insert(1 if ast.get_docstring(f,clean=False) is not None else 0,imp)
  if strict:
   doc=[f.body.pop(0)] if ast.get_docstring(f,clean=False) is not None else []
   pin='_graph_trial_pin(graph, store, c)' if n=='natural_live_admission.py' else 'gate._graph_trial_pin(graph, store, c)'
   closure=ast.parse('_guard = lambda: '+pin).body[0]
   handler=ast.parse('''try:
    pass
except BaseException:
    from .natural_spec_runtime import _ColdGraphRead
    if type(graph) is _ColdGraphRead:
        _ColdGraphRead.invalidate(graph)
    raise
''').body[0]
   handler.body=f.body
   f.body=doc+[closure,handler]
  ast.fix_missing_locations(f)
  putfn(n,name,ast.unparse(f)+'\n')
  boundary_report[n][name]={'strict_sticky':strict,'guarded_call_results':tr.count,'callees':tr.boundaries}

# AST-only invariants, evidence and diff. No product import or execution.
metadata={};patch=''
for n in names:
 tree=ast.parse(new[n],filename=n)
 p=O/'candidate-trial-facts-v2/src/sim2act'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(new[n])
 patch+=''.join(difflib.unified_diff(old[n].splitlines(True),new[n].splitlines(True),fromfile='a/src/sim2act/'+n,tofile='b/src/sim2act/'+n))
 metadata[n]={'base_sha256':hashlib.sha256(old[n].encode()).hexdigest(),'candidate_sha256':hashlib.sha256(new[n].encode()).hexdigest()}
# These execution-family nodes must be byte/AST unchanged by this patch.
preserved={'production_trial_policy.py':['reserve','record_attempt','settle'], 'pa_trial_dispatch.py':['reject','request_captured','_journal_exchange'], 'natural_live_admission.py':['_generation_accounted','admit']}
for n,fs in preserved.items():
 a={f.name:ast.dump(f,include_attributes=False) for f in ast.parse(old[n]).body if isinstance(f,ast.FunctionDef)}
 b={f.name:ast.dump(f,include_attributes=False) for f in ast.parse(new[n]).body if isinstance(f,ast.FunctionDef)}
 for f in fs:assert a[f]==b[f],(n,f,'EXECUTION_NODE_CHANGED')
# Strict helpers all have fixed exact-type sticky invalidation.
for n in names:
 for f in ast.parse(new[n]).body:
  if isinstance(f,ast.FunctionDef) and f.name.startswith('_graph_') and f.name!='_graph_trial_pin':
   s=ast.unparse(f)
   assert 'if type(graph) is _ColdGraphRead:' in s and '_ColdGraphRead.invalidate(graph)' in s
   assert not any(isinstance(x,ast.Call) and isinstance(x.func,ast.Attribute) and isinstance(x.func.value,ast.Name) and x.func.value.id=='graph' for x in ast.walk(f)),(n,f.name)
(O/'trial-facts.patch').write_text(patch)
(O/'trial-facts-v2.patch').write_text(patch)
meta={'status':'EXTERNAL_V2_CANDIDATE_AST_ONLY_NOT_APPLIED_NOT_TESTED','base_head':'dc34ce4b1311810e27cd33a0cd156b6f84333666','files':metadata,'patch_bytes':len(patch.encode()),'patch_sha256':hashlib.sha256(patch.encode()).hexdigest()}
(O/'trial-facts-metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
(O/'trial-facts-v2-boundaries.json').write_text(json.dumps(boundary_report,indent=2)+'\n')
(O/'trial-facts-static-check.json').write_text(json.dumps({'ast':'PASS','execution_nodes_unchanged':preserved,'strict_exact_type_cleanup':'PASS','tests':'NOT_RUN','applied':False},indent=2)+'\n')
print(json.dumps(meta,indent=2))
