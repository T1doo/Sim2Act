# One closing-check clock counterexample

External test-only patch; not applied or executed by this subagent. No product import, DB/model operation, pytest, sleeps or full trial proof was run to author or check it.

- File: `clock-tail.patch`
- SHA256: `d2d1588b661c4c4cf5729c831c1a27517f0642fa1f76f91d19b75509ccc587fc`
- Bytes: 5675
- Exact target: `tests/test_cold_trial_guard_delta.py::test_cold_model_before_rechecks_clock_after_owned_graph_close_before_w5`
- Test baseline SHA256: `f7c9c7223bccf4d4a48174331150d9c5da75ebf4859881d3007e35f99c401cd7`

The test reuses `local_origin` and its existing no-transport fixture. Real `_cold_model_eligible`, roles, `_cold_model_before`, `_cold_graph_read` and exact `_ColdGraphRead` stay active. Only first-binding production and trial construction are replaced with explicitly isolated fixtures; the trial fixture pins its complete synthetic finite deadline vector in the real guard and exposes `authority_record['deadlines']` as an exact tuple at the fixed `commit:second:trial-output` key, with record identity preserved. The actual call input includes its original `meta.deadline` and complete node Limits, and current includes created_at/lease_until; both original node deadline values are retained in the full finite tuple. It neither commits, issues Stage Authority, nor verifies a full production graph.

The check observer invokes the original exact guard check, then advances the runtime-local clock only when its caller is the real `_cold_graph_read` normal closing generator. Constructor/add/body checks cannot trigger the advance. The check's full source/pin validation is retained. The controlled time becomes `min(deadlines) + 0.25`; the lease constant and role run limits are read from existing exact contract/roles, not extended.

The actual `with _cold_model_before(...)` must raise DomainError on normal exit. The next five-write entry is a zero-write tripwire and must never run. Assertions additionally require the real guard to be inactive, stop still false, time beyond the finite bound, and a fresh runtime clock read after the owned closing check. Thus an earlier clock check or rejection from an unrelated fixture failure cannot satisfy the test.

This regression is expected to fail against the inspected pre-fix `_cold_model_before`, which ends directly after normal graph closure without a fresh clock gate. That pre-fix failure is an inference from source, not an executed result. It targets the parent's planned `authority_record['deadlines']` scalar interface and the final post-closure clock/stop gate. Existing test functions/fixtures are AST-identical; only imports and this single test are added.

Completed static checks: parse and compile without execution, old-function AST equality, exact four fixture/clock/check monkeypatch boundaries, one new case, git apply --check. `STATIC-CHECKS.json` and `MANIFEST.json` preserve evidence. Root may run only the exact target above before the already planned bounded suite. No matrix or default-path case was added.
