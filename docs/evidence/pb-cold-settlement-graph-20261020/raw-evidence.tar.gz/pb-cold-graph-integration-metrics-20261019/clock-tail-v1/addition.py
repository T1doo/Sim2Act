

def test_cold_model_before_rechecks_clock_after_owned_graph_close_before_w5(
        local_origin, monkeypatch):
    """Synthetic adapter timing only; no complete trial, Authority or model IO."""
    f, calls, writes = local_origin, [], []
    contract = f.worker.pa_trial.contract
    start = contract.expires_at - contract.caps.run_seconds
    clock = [start]
    seen = dict(guard=None, trial=None, armed=False, advanced=False)
    current = dict(id=new_id('run'), principal_id=f.user,
        project_id=f.draft['project_id'], runtime_id=f.draft['runtime_id'],
        created_at=start, lease_until=start + contract.caps.lease_seconds,
        resource_refs=[contract.bindings[1].resource_id])
    inputs = dict(operation_id='synthetic-no-write-boundary', body=b'complete original input',
        meta=dict(deadline=start + contract.caps.run_seconds), node=f.roles['per_use'])
    completed = object()
    original_check = runtime._ColdGraphRead.check
    closing_code = runtime._cold_graph_read.__wrapped__.__code__

    def first_binding(worker, c, guard, job, platform):
        assert worker is f.worker and job is current and platform is f.limits
        assert guard.connection is c and guard.active
        calls.append('first-binding-fixture')
        seen['guard'] = guard
        return completed

    class IsolatedClockTrial:
        def __init__(self, worker, c, guard, *, completed):
            assert worker is f.worker and c is guard.connection
            assert completed is first_completed and guard is seen['guard']
            calls.append('trial-construction-fixture')
            self.guard = guard
            # Full synthetic finite vector is an in-memory continuity input,
            # never a substitute for a successful commit or Stage Authority.
            finite = [current['lease_until'], contract.expires_at,
                inputs['meta']['deadline'], current['created_at'] + inputs['node'].run_seconds]
            finite.extend(start + value.run_seconds
                for value in guard.role_limits.values() if value is not None)
            self.authority_record = dict(deadlines=tuple(finite))
            self.authority_record_key = 'commit:second:trial-output'
            guard.add(self.authority_record_key, self.authority_record)
            seen['trial'] = self

    first_completed = completed

    def checked(guard, store, c):
        # Execute the real exact-CGR check first. Only its normal context exit
        # is slow: constructor/add/body checks cannot trigger this clock jump.
        original_check(guard, store, c)
        frame = inspect.currentframe()
        caller = None if frame is None else frame.f_back
        try:
            closing = caller is not None and caller.f_code is closing_code
        finally:
            del caller
            del frame
        if (closing and seen['armed'] and not seen['advanced']
                and guard is seen['guard']):
            assert guard.active and not f.worker.stop.is_set()
            calls.append('owned-close-check')
            clock[0] = min(seen['trial'].authority_record['deadlines']) + 0.25
            seen['advanced'] = True

    def now():
        calls.append('clock-after-close' if seen['advanced'] else 'clock-before-close')
        return clock[0]

    def five_writes_tripwire():
        writes.append('W5-entered')
        pytest.fail('Expired G0 context returned to the five-write boundary')

    # Keep actual eligibility, roles, _cold_model_before, _cold_graph_read and
    # exact CGR check. Only the semantically unrelated first graph producers
    # are isolated; they cannot create a verified/admitted production graph.
    monkeypatch.setattr(runtime, '_cold_first_binding', first_binding)
    monkeypatch.setattr(runtime, '_ColdTrialGraph', IsolatedClockTrial)
    monkeypatch.setattr(runtime._ColdGraphRead, 'check', checked)
    # Replace this module alias only; global time and DB/source clocks stay real.
    monkeypatch.setattr(runtime, 'time', SimpleNamespace(time=now))
    with f.store.tx() as c, pb._source_reads(f.store, c):
        assert runtime._cold_model_eligible(f.worker, c, current)
        with pytest.raises(DomainError):
            with runtime._cold_model_before(f.worker, c, current, inputs, f.limits) as graph:
                assert graph is seen['trial'] and graph.guard.active
                assert clock[0] < min(graph.authority_record['deadlines'])
                calls.append('G0-body-complete')
                seen['armed'] = True
            five_writes_tripwire()
    assert seen['advanced'] and not seen['guard'].active
    assert not f.worker.stop.is_set() and not writes
    assert clock[0] > min(seen['trial'].authority_record['deadlines'])
    assert calls.index('G0-body-complete') < calls.index('owned-close-check')
    assert calls.index('owned-close-check') < calls.index('clock-after-close')
