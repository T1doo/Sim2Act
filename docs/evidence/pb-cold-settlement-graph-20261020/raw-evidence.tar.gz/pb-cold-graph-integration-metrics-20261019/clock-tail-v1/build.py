from pathlib import Path
import ast,difflib,hashlib,json
R=Path('/workspace/Sim2Act')
O=Path('/workspace/pb-cold-graph-integration-metrics-20261019/clock-tail-v1')
path='tests/test_cold_trial_guard_delta.py'
old=(R/path).read_text()
new=old.replace('import hashlib\n','import hashlib\nimport inspect\n',1)
new=new.replace('from sim2act import natural_source_archives as archive\n',
 'from sim2act import natural_source_archives as archive\nfrom sim2act import natural_spec_runtime as runtime\n',1)
assert new!=old
new+=(O/'addition.py').read_text()
parsed=ast.parse(new);compile(parsed,'external clock-tail candidate','exec')
for folder,text in [('baseline',old),('candidate',new)]:
 p=O/folder/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
patch=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+path,tofile='b/'+path))
(O/'clock-tail.patch').write_text(patch)
meta=dict(status='EXTERNAL_TEST_CANDIDATE_NOT_APPLIED_NOT_EXECUTED',file=path,
 base_sha256=hashlib.sha256(old.encode()).hexdigest(),candidate_sha256=hashlib.sha256(new.encode()).hexdigest(),
 patch_bytes=len(patch.encode()),patch_sha256=hashlib.sha256(patch.encode()).hexdigest(),
 target='tests/test_cold_trial_guard_delta.py::test_cold_model_before_rechecks_clock_after_owned_graph_close_before_w5',
 new_case_count=1,expected_interface="graph.authority_record['deadlines']",
 product_source_sha256=hashlib.sha256((R/'src/sim2act/natural_spec_runtime.py').read_bytes()).hexdigest(),
 syntax_compile_without_execution=True,product_or_database_or_model_or_pytest_executed=False)
(O/'MANIFEST.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta,indent=2))
