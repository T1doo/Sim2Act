# Fixed `_ColdTrialGraph` insertion candidate

External only; **not applied, imported or executed**. `coordinator.patch` inserts one class before `_model_source_key` in runtime. It changes no existing function/class AST. Root's concurrent G1 audit-seed/facet work is neither copied nor patched.

## Minimal actual wiring

The root-owned eligible ordinary PB graph scope remains the only entry. Retain the original eligibility/association exclusion, the real five writes, and existing ModelSettlementRead live/settle/tail checks.

G0 (pre-write):

```python
completed = _cold_first_binding(worker, c, guard, current, platform_limits)
# ... original receipts/model parse positions, no trial/J preloading ...
prefix = spec._cold_commit_prefix(worker, c, call_run, completed.binding,
                                  guard, 'first')
trial = _ColdTrialGraph(worker, c, guard, completed=completed)
fresh = trial.commit(prefix)
# ... original intervening checks; no writes ...
second = spec._cold_commit_prefix(worker, c, call_run, current_binding,
                                  guard, 'second')
fresh = trial.commit(second)
```

G1 (new post-write epoch):

```python
prefix = spec._cold_commit_prefix(worker, c, call_run, current_binding,
                                  guard, 'post')
# Original audit edge: root's actual complete raw audit producer, before trial.
seed = _cold_audit_seed(worker, c, guard, current_binding['draft'])
trial = _ColdTrialGraph(worker, c, guard, audit_seed=seed)
fresh = trial.commit(prefix)
# trial.trial is now the complete actual trial-Limits Binding graph.
# Root generalizes its existing facet helper for the subsequent platform edge:
# platform = _cold_trial_binding(..., trial.trial, platform_limits, _role='platform')
```

Constructor itself does not build dependencies. `commit(prefix)` first finishes the existing `_cold_commit_from_audit` at its original after-audit position. Thus lock/live, stored binding, current Release/Goal/material, audit, Instance/frozen/budget and association checks retain their parent order. It then enters the original trial check_commit/admission position. Prefixes remain exact `spec._ColdCommitPrefix` with the same graph; a boundary cannot be consumed twice.

`commit` returns the original fresh job. `trial.admission` has the original `_model_out` fields: approval/phase/requirements fingerprints, **fresh** source identity and source deadline. It is not a permit. Each actual context/source observation is stored under the actual commit boundary; semantic Source/Generation bodies are registered only once, not cloned with new boundary names.

## First complete trial sequence

1. Original `_binding`, owner/project gate, outer `_approved`, and admission's second exact binding gate.
2. Original policy `_requirements`, inner `_approved`, exact phase key set and paired Cold approval before any trial Binding expansion.
3. At that first Stage-bound edge only: G0 builds the complete trial Limits facet from its completed platform facts; G1 calls `_cold_first_binding(... trial_limits, audit_seed=seed)`. If the complete semantic Limits values are identical, reuse that already completed facet while retaining the distinct pinned role values and all current scope/Instance/target/native-GA checks. No subset comparison is used.
4. Shared `_graph_stage_before_generation`, then `_cold_generated_model_facet`, then shared `_graph_stage_before_accounting`. No J is read before these original early failures.
5. Preserve Cold `_pb_origin` order: actual fresh approval; owned Generate scalar selection; exact production markers via original `_pb_markers_from_facts`; fresh `_journal_source`; **first full J** via `_graph_journal_state`; original five accepted slot prefix and exact extraction/Source relation.
6. Full **Source** actual accounting first, then original extraction recipe equality, original generation version SELECT, then full **Generate** actual accounting. The Source-before-Generate order follows Cold's original `_pb_origin`, which precedes recipe and `_generation_accounted`.
7. Complete `_graph_run_context` reconstructs Cold Stage Authority and performs actual locked Run/time checks. Original worker owner predicate and `_run_check_from_facts` construct the full policy RunCheck. No Authority DTO is accepted.
8. At the original `_pb_source` position: fresh PB accounting edges, restore Source's original input-schema validation (earlier extraction verify_job deliberately used validate_input=False), full `_graph_resolve_trial_source` and `_graph_pb_archive_chain`. Source Authority is reconstructed by that full archive verifier; paired Source P becomes usable as a completed comparison only after V succeeds.
9. Fresh final source, stop and all pinned role/clock/frozen/declared/lease/trial deadlines. Capture the complete first proof's authority tuples. Register full constructed Cold/Source Authority values and complete receipt/controller/NS bytes.

## Fixed repeated scalar continuation

Second G0 and later G1 boundaries call `_recheck` from `commit`. There is **no** source/history/receipts/archive/Stage rebuild or fixed semantic helper add:

- Actual policy requirements; inner current approval and key set.
- Actual Cold P, compared in full to the completed constructed Cold Authority; actual Source P compared to the first complete Source V's authority.
- Actual fresh `_journal_source`; refresh every captured five-field Grant tuple with original `store.authorize`.
- Actual association exclusion and locked full Run row. Exact ID/full row/owner/version/fence/cancellation/finite lease are checked using the original full row predicate.
- Actual role, clock, frozen, declared, source and trial deadlines plus stop; construct a new RunCheck from those fresh rows.

The root-owned ModelSettlementRead fullchecks remain. It can use `trial.sealed_fields` as the complete raw graph input and the fresh `trial.admission` as original output, and use the exposed complete `trial.journal` with existing `_graph_journal_chain` at its original current-aid position. The coordinator does not replace the current-aid model/result/intent/schema/receipt/settlement checks or issue a new settlement capability.

## Full facts and scope

`cold-trial:complete` contains complete Binding/Source Binding, typed/result/proof/audit rows, Generation Run/frozen/material/history/raw/metadata/marker, extraction request/material/full Goal/prefix/review/audit, per-use prefix/review/effective draft/manifest/material/full Goal, complete J ledger/cursor/revision, and every actual ordered Attempt/slot/Capture/parsed body/request and response **bytes**/NS BodyArchive pair. Multisets remain ordered tuples; no aid dictionary discards duplicates. Pydantic values are stored as their full model_dump because the existing `_model_inputs` supports raw mappings/Limits, not arbitrary model objects.

Typed intermediate values are rechecked against that complete raw registration while the first proof is being assembled. After full SourceArchive V, only the same registered raw values and constructed Authority dictionaries are consumed by repeated scalar continuation. No cached ALLOW, fallback, dynamic dependency resolver or cross-epoch state is introduced. Every exception invalidates only the exact `_ColdGraphRead` and is re-raised unchanged.

## Actual evidence and remaining integration

MANIFEST.json records exact baseline/candidate hashes and confirms every existing runtime AST node is unchanged. STATIC-CHECKS.json records AST PASS, read-only git apply --check PASS, first source-before-J order and no semantic replay/fixed-key adds in `_recheck`. No product import, DB, HTTP/model, test or full-chain execution occurred; performance is **unknown**.

Root must review the complete role/Grant capture and first-error sequence, wire the two actual commit entry points and platform facet, retain current-aid checks/ModelSettlementRead live/settle/tail, and run its one bounded qualification. This is an insertion-only implementation candidate, not a claim that the integration is finished or qualified.
