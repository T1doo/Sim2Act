from pathlib import Path
import ast,difflib,hashlib,json
O=Path('/workspace/pb-cold-graph-integration-metrics-20261019/coordinator-v1')
p=Path('/workspace/Sim2Act/src/sim2act/natural_spec_runtime.py')
a=p.read_text();fragment=(O/'helper.py').read_text();ast.parse(fragment)
anchor='def _model_source_key(source):'
assert a.count(anchor)==1
b=a.replace(anchor,fragment+'\n\n'+anchor,1)
t1,t2=ast.parse(a),ast.parse(b)
old={n.name:ast.dump(n,include_attributes=False) for n in t1.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
new={n.name:ast.dump(n,include_attributes=False) for n in t2.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
assert all(new[n]==v for n,v in old.items())
assert set(new)-set(old)=={'_ColdTrialGraph'}
patch=''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/src/sim2act/natural_spec_runtime.py',tofile='b/src/sim2act/natural_spec_runtime.py'))
(O/'coordinator.patch').write_text(patch)
(O/'candidate-natural_spec_runtime.py').write_text(b)
(O/'baseline-natural_spec_runtime.py').write_text(a)
meta=dict(status='EXTERNAL_INSERT_ONLY_AST_ONLY_NOT_APPLIED_NOT_RUN',base_head='dc34ce4b1311810e27cd33a0cd156b6f84333666',base_sha256=hashlib.sha256(a.encode()).hexdigest(),candidate_sha256=hashlib.sha256(b.encode()).hexdigest(),patch_bytes=len(patch.encode()),patch_sha256=hashlib.sha256(patch.encode()).hexdigest(),all_existing_top_level_ast_unchanged=True)
(O/'MANIFEST.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta,indent=2))
