class _ColdTrialGraph:
    """Fixed ordinary production P-B trial guard continuation for one read epoch.

    Root retains eligibility, the actual five-write group, and graph lifetime.
    This class neither resolves dependencies dynamically nor supplies a permit.
    """

    def __init__(self, worker, c, guard, *, completed=None, audit_seed=None):
        try:
            require(type(guard) is _ColdGraphRead)
            _ColdGraphRead.check(guard, worker.store, c)
            require(worker is guard.worker and c is guard.connection)
            require(completed is None or type(completed) is _ColdBindingGraph)
            require(audit_seed is None or type(audit_seed) is _ColdAuditSeed)
            require((guard.phase == 'pre' and type(completed) is _ColdBindingGraph
                     and audit_seed is None)
                or (guard.phase == 'post' and completed is None
                    and type(audit_seed) is _ColdAuditSeed))
            if completed is not None:
                require(completed.guard is guard)
            if audit_seed is not None:
                audit_seed.check(worker.store, c, guard)
            self.worker, self.c, self.guard = worker, c, guard
            self.platform, self.audit_seed = completed, audit_seed
            self.trial = None
            self.journal = self.source_accounted = self.generate_accounted = None
            self.raw = self.metadata = self.extraction = None
            self.cold_stage_facts = self.source_stage_facts = None
            self.source_proof = self.context = self.resolved = None
            self.cold_authority = self.source_authority = None
            self.sealed_fields = self.authority_fields = None
            self.authorities = set()
            self.authority_record = self.authority_record_key = None
            self.context_record = self.context_record_key = None
            self.admission = None
            self.phase, self.boundaries = 'EMPTY', set()
        except BaseException:
            if type(guard) is _ColdGraphRead:
                _ColdGraphRead.invalidate(guard)
            raise

    def _base(self):
        require(type(self.guard) is _ColdGraphRead)
        _ColdGraphRead.check(self.guard, self.worker.store, self.c)
        require(self.worker is self.guard.worker and self.c is self.guard.connection)

    def _dump(self, model):
        value = model.model_dump()
        self._base()
        return value

    def _read_fields(self, facts):
        value = facts.fields()
        self._base()
        return value

    def _fingerprint(self, value):
        result = fingerprint(value)
        self._base()
        return result

    def _accounted_fields(self, value):
        """Concrete complete per-aid models/rows/bytes; preserves multiplicity."""
        from . import natural_source_archives as archive
        from . import production_trial_policy as policy
        from . import production_trial_sender as sender
        run, actual, chains, ns_reads = value
        full_chains, full_ns = [], []
        for slot, capture, parsed, checked, wire, payload in chains:
            require(type(slot) is policy.Slot and type(capture) is sender.Capture
                and type(wire) is bytes and type(payload) is bytes)
            full_chains.append((self._dump(slot), self._dump(capture), parsed,
                dict(checked), wire, payload))
        for aid, request, wire, response, payload in ns_reads:
            require(type(request) is archive.BodyArchive
                and type(response) is archive.BodyArchive
                and type(wire) is bytes and type(payload) is bytes)
            full_ns.append((aid, self._dump(request), wire,
                self._dump(response), payload))
        return dict(run=dict(run), actual=tuple(dict(a) for a in actual),
            chains=tuple(full_chains), ns_reads=tuple(full_ns))

    def _fields(self):
        """Only fixed completed nodes; every model is retained in full."""
        b = self.trial
        ledger, cursor, revision = self.journal
        draft, body, target, goal = self.extraction
        return dict(binding=b.binding, source_binding=b.source_binding,
            source_facts=self._read_fields(b.source_facts), source_audit=self._read_fields(b.source_audit),
            native_audit=b.native_audit, source_outputs=b.source_outputs,
            source_proved=b.source_proved, generation=dict(
                run=dict(b.generation_reader.run), frozen=self._dump(b.generation_contract),
                material=b.generation_material, history=b.generation_history,
                raw=self.raw, metadata=self.metadata, marker=dict(b.generation_marker)),
            extraction=dict(draft=draft, request=self._dump(body), target=target, goal=goal,
                prefix=self._read_fields(b.extraction_prefix), review=self._read_fields(b.extraction_review),
                audit=self._read_fields(b.extraction_audit_prefix), audit_digest=b.extraction_audit),
            use=dict(prefix=self._read_fields(b.use_prefix), review=self._read_fields(b.use_review),
                value=dict(draft=b.use_value[0], manifest=self._dump(b.use_value[1]),
                    report=b.use_value[2], material=b.use_value[3], goal=b.use_value[4]),
                audit=self._read_fields(b.use_audit_prefix)),
            journal=dict(ledger=self._dump(ledger), cursor=self._dump(cursor), revision=revision),
            generated=self._accounted_fields(self.generate_accounted),
            source=self._accounted_fields(self.source_accounted),
            source_proof=self.source_proof, roles=self.guard.role_limits)

    def check(self):
        try:
            self._base()
            require(self.platform is None or type(self.platform) is _ColdBindingGraph
                and self.platform.guard is self.guard)
            require(self.trial is None or type(self.trial) is _ColdBindingGraph
                and self.trial.guard is self.guard)
            require(self.audit_seed is None or type(self.audit_seed) is _ColdAuditSeed
                and self.audit_seed.guard is self.guard)
            require(self.phase in {'EMPTY', 'BUILDING', 'COMPLETE', 'BUSY'})
            if self.trial is not None and self.phase in {'COMPLETE', 'BUSY'}:
                if self.sealed_fields is None:
                    require(_model_inputs(self._fields()) ==
                        _model_inputs(self.guard.inputs['cold-trial:complete']),
                        'Complete trial raw models, bytes or role inputs changed')
                else:
                    require(self.sealed_fields is self.guard.inputs['cold-trial:complete']
                        and self.authority_fields is self.guard.inputs['cold-trial:semantic-authorities']
                        and self.cold_authority is self.authority_fields['cold']
                        and self.source_authority is self.authority_fields['source'])
            if self.context_record is not None:
                require(self.context_record is self.guard.inputs[self.context_record_key]
                    and self._dump(self.context) == self.context_record)
            if self.authority_record is not None:
                require(self.authority_record is self.guard.inputs[self.authority_record_key]
                    and tuple(sorted(self.authorities)) == self.authority_record['authorities'])
            if self.audit_seed is not None:
                self.audit_seed.check(self.worker.store, self.c, self.guard)
        except BaseException:
            if type(self.guard) is _ColdGraphRead:
                _ColdGraphRead.invalidate(self.guard)
            self.phase = 'INVALID'
            raise

    def _prepare(self, job):
        """Called only at the first original admission Stage-bound edge."""
        from . import natural_live_admission as gate
        from . import pa_trial_dispatch as dispatch
        from . import production_trial_policy as policy
        from .db import runs
        from .spec_production import VERSION
        worker, store, c, g = self.worker, self.worker.store, self.c, self.guard
        b, user = worker.pa_trial, job['principal_id']
        contract, key = b.contract, b.approval_key
        pin = self._base
        self.phase = 'BUILDING'
        # The original policy requirements/inner current approval/paired phase
        # precede bound, before reading any new trial Binding dependency.
        original, expected = policy._requirements(user, contract, key, _guard=pin)
        pin()
        self.original, self.expected = original, expected
        inner = gate._approved(store, c, user, contract, key, _guard=pin)
        pin()
        eid = gate.entity(contract, _guard=pin)
        pin()
        phase_keys = gate._keys(c, user, eid, gate.PHASE, _guard=pin)
        pin()
        require(phase_keys <= {'source', 'cold'})
        accepted = gate._saved(c, user, eid,
            gate.PHASE, 'cold', gate.StageApproveInput, _guard=pin)
        pin()
        require(accepted.approval_key == key)
        g.add('cold-trial:admission-prefix', dict(original=self._dump(original),
            expected=self._dump(expected), approval=self._dump(inner), phase=self._dump(accepted)))
        limits = g.role_limits['trial']
        expected_limits = gate._limits(contract)
        pin()
        require(type(limits) is Limits and limits == expected_limits)
        if self.platform is None:
            self.trial = _cold_first_binding(worker, c, g, job, limits,
                audit_seed=self.audit_seed)
        elif self.platform.binding_prefix.limits == limits:
            # Same complete semantic Limits, distinct pinned role identity.
            # Current scope, Instance, target and native GA role gates still run.
            self.trial = self.platform
        else:
            self.trial = _cold_trial_binding(worker, c, self.platform, limits)
        pin()
        t = self.trial
        require(t.guard is g and dict(t.counter_reader.job) == dict(job))
        g.add('cold-trial:bound', dict(binding=t.binding,
            source_binding=t.source_binding, limits=limits,
            actual_binding_limits=t.binding_prefix.limits))
        before = gate._graph_stage_before_generation(g, store, c, user,
            contract, 'cold', job, t.binding)
        pin()
        g.add('cold-trial:before-generation', dict(instance=dict(before[0]),
            release=dict(before[1]), target=self._dump(before[2]), generation_run_id=before[3]))
        self.raw, self.metadata = _cold_generated_model_facet(worker, c, t)
        pin()
        generation = t.generation_reader.run
        frozen = t.generation_contract
        require(generation['id'] == before[3])
        preceding = gate._graph_stage_before_accounting(g, store, c, user,
            contract, 'cold', job, t.binding, self.raw, self.metadata, generation, frozen, before)
        pin()
        g.add('cold-trial:before-accounting', dict(instance=dict(preceding[0]),
            release=dict(preceding[1]), target=self._dump(preceding[2]),
            generation_run_id=preceding[3], approval=self._dump(preceding[4])))
        # Cold's original _pb_origin occurs BEFORE recipe/Generate accounting.
        # Keep approval -> scalar Gen/markers -> fresh source -> FIRST J order.
        gate._approved(store, c, user, contract, key, _guard=pin)
        pin()
        gen_id = c.execute(select(runs.c.id).where(runs.c.principal_id == user,
            runs.c.project_id == contract.project_id, runs.c.runtime_id == contract.runtime_id,
            runs.c.request_key == contract.stage_keys.generate)).scalar_one_or_none()
        pin()
        require(gen_id is not None)
        fields = ('version', 'trial_fingerprint', 'approval_key', 'account_id')
        markers = c.execute(select(*[attempts.c.parameters['pa_trial_binding'][k]
            .as_string().label(k) for k in fields]).where(attempts.c.run_id == gen_id)).mappings().all()
        pin()
        dispatch._pb_markers_from_facts(contract, key, markers, _guard=pin)
        pin()
        require(all(m['account_id'] == b.account_id for m in markers))
        entitlement = dispatch._journal_source(store, c, b, _guard=pin)
        pin()
        g.add('cold-trial:pb-before-journal', dict(generation_id=gen_id,
            markers=tuple(dict(m) for m in markers), source=self._dump(entitlement)))
        self.journal = dispatch._graph_journal_state(g, store, c, b)
        pin()
        ledger, cursor, revision = self.journal
        g.add('cold-trial:journal', dict(ledger=self._dump(ledger),
            cursor=self._dump(cursor), revision=revision))
        source_id = dispatch._pb_prefix_source_from_facts(ledger, _guard=pin)
        pin()
        gate._stage_pb_origin_from_facts(contract, t.extraction_prefix.body, source_id, _guard=pin)
        pin()
        self.source_accounted = dispatch._graph_stage_accounted(g, store, c, b,
            ledger, cursor, source_id, 'source')
        pin()
        g.add('cold-trial:accounted-source', self._accounted_fields(self.source_accounted))
        expected_recipe = contract.extraction_recipe.model_dump(exclude_none=True)
        pin()
        gate._stage_recipe_from_facts(expected_recipe, t.binding['draft'], _guard=pin)
        pin()
        versions = c.execute(select(attempts.c.parameters['pa_trial_binding']['version']
            .as_string()).where(attempts.c.run_id == gen_id)).scalars().all()
        pin()
        gate.require(versions == [VERSION] * 3,
            'Mixed or unknown actual trial backends cannot prove a stage')
        self.generate_accounted = dispatch._graph_stage_accounted(g, store, c, b,
            ledger, cursor, gen_id, 'generate')
        pin()
        g.add('cold-trial:accounted-generate', self._accounted_fields(self.generate_accounted))
        require(self.source_accounted[0]['id'] == t.source_counter_reader.job['id']
            and self.generate_accounted[0]['id'] == generation['id'])
        self.extraction = (t.extraction_prefix.draft, t.extraction_prefix.body,
            t.extraction_review.material, t.extraction_review.goal.model_dump())
        pin()
        self.source_proof = t.source_facts.proof
        self.cold_stage_facts = (job, t.binding, self.raw, self.metadata, generation,
            frozen, self.generate_accounted, self.source_accounted, self.extraction)
        self.source_stage_facts = (t.source_counter_reader.job, t.source_binding,
            self.raw, self.metadata, generation, frozen, self.generate_accounted, None, None)
        g.add('cold-trial:complete', self._fields())
        self.phase = 'COMPLETE'
        self.check()

    def _context(self, key, value):
        fields = self._dump(value)
        self.guard.add(key + ':context', fields)
        self.context, self.context_record = value, fields
        self.context_record_key = key + ':context'

    def _recheck(self, job):
        """Fresh fixed scalar/authority continuation; no semantic-node replay."""
        from . import natural_live_admission as gate
        from . import pa_trial_dispatch as dispatch
        from . import production_trial_policy as policy
        from .db import runs
        from .natural_trial_runs import associated_sql
        self.check()
        store, c, b = self.worker.store, self.c, self.guard.binding
        user, pin = job['principal_id'], self.check
        original, expected = policy._requirements(user, b.contract, b.approval_key, _guard=pin)
        pin()
        approval = gate._approved(store, c, user, b.contract, b.approval_key, _guard=pin)
        pin()
        eid = gate.entity(b.contract, _guard=pin)
        pin()
        phase_keys = gate._keys(c, user, eid, gate.PHASE, _guard=pin)
        pin()
        require(phase_keys <= {'source', 'cold'})
        accepted = gate._saved(c, user, eid, gate.PHASE,
            'cold', gate.StageApproveInput, _guard=pin)
        pin()
        require(accepted.approval_key == b.approval_key
            and accepted.authority.run_id == job['id'] and accepted.authority.stage == 'cold'
            and self._dump(accepted.authority) == self.cold_authority
            and self._fingerprint(self.cold_authority) == accepted.expected_authority_fingerprint)
        pin()
        # Full Source V was completed at the first archive boundary. Keep its
        # original paired approval current without reconstructing Source again.
        source_phase = gate._saved(c, user, eid, gate.PHASE,
            'source', gate.StageApproveInput, _guard=pin)
        pin()
        require(source_phase.approval_key == b.approval_key
            and self._dump(source_phase.authority) == self.source_authority
            and self._fingerprint(self.source_authority) == source_phase.expected_authority_fingerprint)
        pin()
        source = dispatch._journal_source(store, c, b, _guard=pin)
        pin()
        for authority in sorted(self.authorities):
            store.authorize(c, *authority)
            pin()
        associated = c.execute(select(runs.c.id).where(runs.c.id == job['id'],
            associated_sql())).first()
        pin()
        require(associated is None, 'Qualified associations cannot use the ordinary Cold graph')
        actual = gate._run_context_row(c, job['id'], _guard=pin)
        pin()
        require(actual is not None and actual['id'] == job['id']
            and actual['worker_id'] == self.worker.id
            and _model_inputs(dict(actual)) == _model_inputs(dict(job)))
        at = time.time()
        pin()
        gate._require_run_context_row(user, b.contract, 'cold', actual,
            job['version'], job['fence'], approval, accepted.authority, at, _guard=pin)
        pin()
        deadlines = [actual['lease_until'], b.contract.expires_at, source.expires_at,
            self.trial.binding['snapshot']['natural_spec_clock']['deadline']]
        for role in ('source', 'generate', 'platform', 'trial', 'per_use'):
            limits = self.guard.role_limits[role]
            if limits is not None:
                deadlines.append(actual['created_at'] + limits.run_seconds)
        frozen = store._frozen_contract_after_scope(c, actual)
        pin()
        declared = Limits(**self.trial.binding['draft']['candidate']['manifest']['runtime_limits'])
        pin()
        deadlines.extend((actual['created_at'] + frozen.limits.run_seconds,
            actual['created_at'] + declared.run_seconds))
        end = time.time()
        pin()
        require(not self.worker.stop.is_set() and end < min(deadlines),
            'Production scalar continuation expired')
        pin()
        context = policy._run_check_from_facts(original, expected, approval,
            accepted.authority, actual, at, 'cold', actual['id'], job['version'],
            job['fence'], self.worker.id, _guard=pin)
        pin()
        return context, source

    def commit(self, prefix):
        """Finish one original commit prefix after its original full audit edge.

        First call completes all semantic nodes. Later calls use only fresh
        approval/P/source/Grant/Run/version/fence/stop/finite-deadline checks.
        Existing ModelSettlementRead.live/settle/tail remain root-owned.
        """
        from . import natural_live_admission as gate
        from . import natural_source_archives as archive
        from . import pa_spec_apps as spec
        from . import pa_trial_dispatch as dispatch
        from . import production_trial_policy as policy
        try:
            require(type(prefix) is spec._ColdCommitPrefix and prefix.guard is self.guard)
            self.check()
            require(prefix.key not in self.boundaries)
            audit = (self.audit_seed.audit if self.audit_seed is not None
                else self.platform.binding['audit_fingerprint'])
            job = spec._cold_commit_from_audit(self.worker, self.c, prefix, audit)
            self.check()
            b = dispatch._binding(self.worker)
            self.check()
            require(b is self.guard.binding and job['principal_id'] == b.contract.principal_id
                and job['project_id'] == b.contract.project_id)
            store, c, g, user = self.worker.store, self.c, self.guard, job['principal_id']
            first = self.phase == 'EMPTY'
            with store.proof_authorities(c) as authorities:
                self.check()
                gate._approved(store, c, user, b.contract, b.approval_key, _guard=self.check)
                self.check()
                current_binding = dispatch._binding(self.worker)
                self.check()
                require(current_binding is b)
                if first:
                    self._prepare(job)
                    self.check()
                    self.phase = 'BUSY'
                    approval, phase, actual, at = gate._graph_run_context(g, store, c,
                        user, b.contract, b.approval_key, 'cold', job['id'], job['version'],
                        job['fence'], self.cold_stage_facts)
                    self.check()
                    require(actual['worker_id'] == self.worker.id)
                    context = policy._run_check_from_facts(self.original, self.expected,
                        approval, phase, actual, at, 'cold', actual['id'], actual['version'],
                        actual['fence'], self.worker.id, _guard=self.check)
                    self._context(prefix.key, context)
                    self.check()
                    source_id = dispatch._graph_pb_accounting(g, store, c, b,
                        self.trial.generation_reader.run, self.journal[0])
                    self.check()
                    require(source_id == self.source_accounted[0]['id'])
                    source_bound = self.trial.source_binding
                    manifest, _, _ = codec.compile_candidate(source_bound['draft']['candidate'],
                        g.role_limits['trial'])
                    self.check()
                    validate_value(manifest.input_schema, source_bound['snapshot']['input'])
                    self.check()
                    self.resolved = archive._graph_resolve_trial_source(g, store, c, user,
                        b.contract, b.approval_key, self.journal[0], self.source_stage_facts,
                        self.source_proof, self.source_accounted, self.extraction)
                    self.check()
                    dispatch._graph_pb_archive_chain(g, store, c, b, self.journal[0],
                        self.resolved, self.source_accounted)
                    self.check()
                    # This P has just been compared to the fully reconstructed
                    # Source Authority by successful archive V in this epoch.
                    source_entity = gate.entity(b.contract, _guard=self.check)
                    self.check()
                    source_phase = gate._saved(c, user, source_entity,
                        gate.PHASE, 'source', gate.StageApproveInput, _guard=self.check)
                    self.check()
                    raw_authorities = dict(cold=self._dump(phase),
                        source=self._dump(source_phase.authority))
                    g.add('cold-trial:semantic-authorities', raw_authorities)
                    self.authority_fields = raw_authorities
                    self.cold_authority, self.source_authority = raw_authorities['cold'], raw_authorities['source']
                    # Only full raw completed values remain inputs to repeated
                    # continuation. Typed intermediates are never replayed.
                    self.sealed_fields = g.inputs['cold-trial:complete']
                    source = dispatch._journal_source(store, c, b, _guard=self.check)
                    self.check()
                else:
                    self.phase = 'BUSY'
                    context, source = self._recheck(job)
                    self._context(prefix.key, context)
                    self.check()
                # All role/clock bounds stay actual at the final boundary,
                # including when the first complete semantic proof took time.
                finite = [self.context.deadline, source.expires_at,
                    self.trial.binding['snapshot']['natural_spec_clock']['deadline']]
                for role in ('source', 'generate', 'platform', 'trial', 'per_use'):
                    role_limits = g.role_limits[role]
                    if role_limits is not None:
                        finite.append(job['created_at'] + role_limits.run_seconds)
                final_frozen = store._frozen_contract_after_scope(c, job)
                self.check()
                finite.append(job['created_at'] + final_frozen.limits.run_seconds)
                finite.append(job['created_at'] +
                    self.trial.binding['draft']['candidate']['manifest']['runtime_limits']['run_seconds'])
                end = time.time()
                self.check()
                require(not self.worker.stop.is_set() and end < min(finite),
                    'Production admission expired during verification')
                self.check()
                source_identity = _model_source_key(source)
                self.check()
                self.admission = dict(approval=self.context.approval_fingerprint,
                    phase=self.context.stage_fingerprint,
                    requirements=self.context.requirements_fingerprint,
                    source_identity=source_identity, source_deadline=source.expires_at)
                self.check()
                self.authorities.update(authorities)
                output = dict(run=dict(job), context=self._dump(self.context),
                    source=self._dump(source), authorities=tuple(sorted(self.authorities)),
                    admission=self.admission)
                if first:
                    output['archive'] = dict(public_receipt=self.resolved.public_receipt,
                        request_bodies=self.resolved.request_bodies,
                        response_bodies=self.resolved.response_bodies)
                g.add(prefix.key + ':trial-output', output)
                self.authority_record, self.authority_record_key = output, prefix.key + ':trial-output'
            self.check()
            self.boundaries.add(prefix.key)
            self.phase = 'COMPLETE'
            return job
        except BaseException:
            if type(self.guard) is _ColdGraphRead:
                _ColdGraphRead.invalidate(self.guard)
            self.phase = 'INVALID'
            raise
