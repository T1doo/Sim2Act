"""Unexecuted observer building blocks; no product imports or automatic hooks.

Author must bind frozen actual function names and passthrough decorators. This
draft does not start pytest, access a database, or generate a proof/authority.
"""
import functools
import threading
import time
from collections import defaultdict


class Counters:
    def __init__(self):
        self.local = threading.local()
        self.rows = defaultdict(lambda: dict(calls=0, wall_ns=0, cpu_ns=0,
            exclusive_wall_ns=0, exclusive_cpu_ns=0, max_recursion=0, errors=0))

    def wrap(self, original, label, identity):
        """identity reads only existing arguments/TLS; never calls a verifier."""
        @functools.wraps(original)
        def call(*args, **kwargs):
            key = identity(args, kwargs)
            stack = getattr(self.local, "stack", None)
            if stack is None:
                self.local.stack = stack = []
            depth = 1 + sum(frame["label"] == label for frame in stack)
            frame = dict(label=label, child_wall=0, child_cpu=0)
            stack.append(frame)
            start_wall, start_cpu = time.monotonic_ns(), time.thread_time_ns()
            error = False
            try:
                return original(*args, **kwargs)
            except BaseException:
                error = True
                raise
            finally:
                wall = time.monotonic_ns() - start_wall
                cpu = time.thread_time_ns() - start_cpu
                stack.pop()
                row = self.rows[(threading.get_ident(), key, label)]
                row["calls"] += 1
                row["errors"] += error
                row["wall_ns"] += wall
                row["cpu_ns"] += cpu
                row["exclusive_wall_ns"] += wall - frame["child_wall"]
                row["exclusive_cpu_ns"] += cpu - frame["child_cpu"]
                row["max_recursion"] = max(row["max_recursion"], depth)
                if stack:
                    stack[-1]["child_wall"] += wall
                    stack[-1]["child_cpu"] += cpu
        return call

# Installation must preserve original call arguments, original return objects
# and original exceptions, including contextmanager __enter__/__exit__. The
# counter deliberately has no disk flush, product callback, or source lookup.
# Multiple-thread snapshots require quiescent finalization or an independent
# observer mutex; never acquire product metadata/DB locks just to snapshot it.
