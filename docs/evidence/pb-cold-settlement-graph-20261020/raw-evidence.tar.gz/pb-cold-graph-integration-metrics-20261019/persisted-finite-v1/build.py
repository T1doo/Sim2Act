from pathlib import Path
import ast,difflib,hashlib,json
R=Path('/workspace/Sim2Act');O=Path('/workspace/pb-cold-graph-integration-metrics-20261019/persisted-finite-v1')
names=['pa_spec_apps.py','pb_natural_specs.py','pb_natural_uses.py']
old={name:(R/'src/sim2act'/name).read_text() for name in names};new=dict(old)
for name,func,prefix in [('pa_spec_apps.py','_cold_scope_pair',''),('pb_natural_specs.py','_cold_persisted_pair','spec.'),('pb_natural_uses.py','_use_pair','spec.')]:
 text=new[name];f=next(x for x in ast.parse(text).body if isinstance(x,ast.FunctionDef) and x.name==func)
 body=''.join(text.splitlines(True)[f.lineno-1:f.end_lineno]);needle='            value = graph.checked(row)'
 assert body.count(needle)==1,(name,func)
 changed=body.replace(needle,"            "+prefix+"_persisted_snapshot_finite(row['snapshot'])\n"+needle)
 new[name]=text.replace(body,changed,1)
new['pa_spec_apps.py']=new['pa_spec_apps.py'].replace('def _cold_scope_pair(', (O/'helper.py').read_text().strip()+'\n\n\ndef _cold_scope_pair(',1)
patch='';manifest={}
for name in names:
 tree=ast.parse(new[name]);compile(tree,'external finite candidate '+name,'exec')
 for folder,text in [('baseline',old[name]),('candidate',new[name])]:
  p=O/folder/'src/sim2act'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
 patch+=''.join(difflib.unified_diff(old[name].splitlines(True),new[name].splitlines(True),fromfile='a/src/sim2act/'+name,tofile='b/src/sim2act/'+name))
 manifest[name]=dict(base_sha256=hashlib.sha256(old[name].encode()).hexdigest(),candidate_sha256=hashlib.sha256(new[name].encode()).hexdigest())
(O/'persisted-finite.patch').write_text(patch)
meta=dict(status='EXTERNAL_CANDIDATE_NOT_APPLIED_NOT_EXECUTED',files=manifest,patch_bytes=len(patch.encode()),patch_sha256=hashlib.sha256(patch.encode()).hexdigest(),syntax_compile_without_execution=True,product_or_database_or_model_or_pytest_executed=False)
(O/'MANIFEST.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta,indent=2))
