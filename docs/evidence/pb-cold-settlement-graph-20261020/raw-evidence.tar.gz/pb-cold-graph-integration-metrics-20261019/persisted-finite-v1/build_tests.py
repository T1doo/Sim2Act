from pathlib import Path
import ast,difflib,hashlib,json
R=Path('/workspace/Sim2Act');O=Path('/workspace/pb-cold-graph-integration-metrics-20261019/persisted-finite-v1')
path='tests/test_cold_persisted_schemas.py';old=(R/path).read_text()
new=old.replace('import copy\n','import copy\nimport math\n',1)
new=new.replace('from sim2act import pb_natural_specs as pb\n','from sim2act import pa_spec_apps as spec\nfrom sim2act import pb_natural_specs as pb\nfrom sim2act import pb_natural_uses as use\n',1)
new=new.replace('from sim2act.db import delivery_graph_requests, fingerprint, task_extractions','from sim2act.db import delivery_graph_requests, fingerprint, new_id, task_extractions',1)
new+=(O/'test_addition.py').read_text()
tree=ast.parse(new);compile(tree,'external nonfinite tests candidate','exec')
a={x.name:ast.dump(x,include_attributes=False) for x in ast.parse(old).body if isinstance(x,ast.FunctionDef)};b={x.name:ast.dump(x,include_attributes=False) for x in tree.body if isinstance(x,ast.FunctionDef)}
assert all(a[name]==b[name] for name in a)
for folder,text in [('baseline',old),('candidate',new)]:
 p=O/folder/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
patch=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+path,tofile='b/'+path))
(O/'persisted-finite-tests.patch').write_text(patch)
meta=dict(status='EXTERNAL_TEST_CANDIDATE_NOT_APPLIED_NOT_EXECUTED',file=path,
 base_sha256=hashlib.sha256(old.encode()).hexdigest(),candidate_sha256=hashlib.sha256(new.encode()).hexdigest(),
 patch_bytes=len(patch.encode()),patch_sha256=hashlib.sha256(patch.encode()).hexdigest(),
 target='tests/test_cold_persisted_schemas.py::test_owned_nested_nonfinite_snapshot_matches_old_error_in_three_collectors',new_case_count=2,
 original_test_function_AST_unchanged=True,syntax_compile_without_execution=True,
 product_or_database_or_model_or_pytest_executed=False)
(O/'TEST-MANIFEST.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta,indent=2))
