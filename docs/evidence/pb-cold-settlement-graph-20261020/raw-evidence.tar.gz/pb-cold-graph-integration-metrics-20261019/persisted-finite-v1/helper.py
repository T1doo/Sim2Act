def _persisted_snapshot_finite(snapshot):
    """Map only non-finite floats in a completely controlled JSON snapshot.

    Unsupported shapes and cycles stay with the original checked protocol.
    This pure walk neither hashes nor grants permission to use the snapshot.
    """
    if type(snapshot) is not dict:
        return
    pending = [(snapshot, False)]
    active: set[int] = set()
    seen: set[int] = set()
    nonfinite = False
    while pending:
        value, leaving = pending.pop()
        if leaving:
            active.remove(id(value))
            continue
        kind = type(value)
        if kind is dict or kind is list:
            marker = id(value)
            if marker in active:
                return
            if marker in seen:
                continue
            if kind is dict:
                if any(type(key) is not str for key in value):
                    return
                children = value.values()
            else:
                children = value
            seen.add(marker)
            active.add(marker)
            pending.append((value, True))
            pending.extend((child, False) for child in children)
        elif kind is float:
            if not math.isfinite(value):
                nonfinite = True
        elif kind is str or kind is int or kind is bool or kind is type(None):
            continue
        else:
            return
    if nonfinite:
        raise DomainError('VERSION_CONFLICT', 'Malformed persisted DeliveryGraph binding')
