# Relative V2 delta — implementation, not applied or executed

Baseline is root-applied V2 plus root's Ruff changes, HEAD `dc34ce4b1311810e27cd33a0cd156b6f84333666`. This is a **relative** four-file patch, not the previous full patch. Exact baseline/candidate hashes are in MANIFEST.json. Root's lifecycle changes are neither copied nor patched.

## Fixed first-needed sequence

1. Root finishes complete current role Binding facts at the original binding position.
2. Call `gate._graph_stage_before_generation(graph, store, c, user, contract, stage, job, bound)`.
   It runs original current owned scope, Instance/current immutable Release, exact target and Generate-ID SELECT. It returns `(inst, current_release, target, gen_id)` only. It does not read model source, J, accounting or construct Authority.
3. Root now performs the complete original native Generate model-source/candidate/confirmation/frozen facet, using the selected Gen ID and exact full role Limits.
4. Call `gate._graph_stage_before_accounting(graph, store, c, user, contract, stage, job, bound, raw, metadata, gen, frozen, stage_prefix)` with the actual four-tuple from step 2.
   It runs original Gen-ID link, metadata runtime/resource check, saved original approval and full frozen Generate/Goal check. Returns `(inst, current_release, target, gen_id, approval)`. It reads no J/accounting and constructs no Authority.
5. Root may now perform the first complete J/accounted Generate and Source/P-B accounting nodes, in their original order. Each actual result remains complete raw facts and is registered in this graph/epoch; a prefix is never an Authority or a finished Stage V.
6. `_graph_stage_current` uses these **same two functions**, then retains its original complete accounting/origin/recipe/source-phase/deadlines/authorization-fingerprint/Authority construction. Source stages use the same shared prefix. There is no copied prefix predicate, dynamic resolver or fallback. A complete Stage call rechecks the cheap current prefix; root's earlier first-needed calls prevent the first J read from being scheduled before an original early failure.

Both new cores use the fixed exact-CGR pin and original-exception sticky cleanup. Inputs and returned partial facts must belong to root's same graph/transaction/epoch; root retains node registration and full role provenance. No DTO/boolean grants completion.

## P2 fixes

- `_graph_run_context` requires input stage job ID equal requested Run **before approval**, reconstructed `phase.run_id` equal requested Run before phase equality, and locked row ID equal requested Run before the full row predicate.
- Existing owned internal guards now receive the actual graph: pa scope/job gates, generation source scope, lifecycle owned/immutable Release pointers. `_stage_instance_after_bound` and `_journal_stage_header` each gain `_graph_read=None`; default calls omit the new callee keyword when None. Root's fixed lifecycle `release-pointer:user:rid` key and full repeat comparison remain the implementation that owns repeat registration.
- gate `_approved/_current/_authorize/_keys/_saved/authorization_fingerprint`, plus pure `entity/parse_contract` and policy `_requirements`, gain optional `_guard=None`. Their entire sensitive call/SQL chain uses the same fixed closure; all guarded/strict callers relay it. Conditional kwargs keep the old default call shape when None. Grant cursor iteration is completed and pinned before fingerprinting.
- `_body_payload_from_facts` retains `try: payload = base64.b64decode(...) / except ValueError: original DomainError` exactly. The success-result pin is outside that try, so a guard ValueError cannot be relabeled as a decoding failure.
- External `spec_production.source`, `journal._context/_quota/_ledger`, sender `_captured` remain unchanged trusted original protocols with immediate result pins. No sender, reserve, reject, TTL or other execution family is altered.

## External tests draft

`test-draft.patch` adds `tests/test_cold_trial_guard_delta.py`; it is not executed. It reuses existing `local_origin` and saved Release fixtures and their no-transport guard. It includes wrong-Run joins (input/phase/locked-row), stage pointer release-gate drift with zero Release-body reads, approval metadata SELECT drift before any pair payload, and exact original ValueError identity after successful decoding. All stands-ins are explicitly isolated boundary probes, not mock full Stage Authority or admission claims.

## Evidence

`STATIC-CHECKS.json`: AST PASS, both read-only `git apply --check` PASS, 45 new guard relay sites with none missing; nine new optional helpers restore the baseline AST when guard plumbing is stripped. Original execution-family ASTs remain unchanged (MANIFEST.json). No repository write, product import, DB, model, network or test execution occurred. Root must review/apply and run the actual bounded tests.
