from pathlib import Path
import ast, copy, hashlib, json
O=Path('/workspace/pb-cold-graph-integration-metrics-20261019/relative-v2delta')
B=O/'baseline/src/sim2act';C=O/'candidate/src/sim2act'
names=['production_trial_policy.py','pa_trial_dispatch.py','natural_source_archives.py','natural_live_admission.py']
relay={'_approved','_current','_authorize','_keys','_saved','authorization_fingerprint','entity','parse_contract','_requirements'}
def fmap(p):return {f.name:f for f in ast.parse(p.read_text()).body if isinstance(f,ast.FunctionDef)}
def guarded(k):
 return k.arg=='_guard' or k.arg is None and isinstance(k.value,ast.IfExp) and isinstance(k.value.body,ast.Dict) and any(isinstance(x,ast.Constant) and x.value=='_guard' for x in k.value.body.keys)
missing=[];sites=[];restored={}
class Restore(ast.NodeTransformer):
 def visit_Call(self,node):
  node=self.generic_visit(node)
  name=node.func.id if isinstance(node.func,ast.Name) else node.func.attr if isinstance(node.func,ast.Attribute) else None
  if name=='_trial_result':return node.args[0]
  node.keywords=[k for k in node.keywords if not guarded(k)]
  return node
for n in names:
 before=fmap(B/n);after=fmap(C/n)
 for name,f in after.items():
  active=any(a.arg=='_guard' for a in f.args.kwonlyargs) or name.startswith('_graph_') and name!='_graph_trial_pin'
  if active:
   for call in ast.walk(f):
    if not isinstance(call,ast.Call):continue
    callee=call.func.id if isinstance(call.func,ast.Name) else call.func.attr if isinstance(call.func,ast.Attribute) else None
    if callee in relay:
     sites.append(n+':'+name+'->'+callee)
     if not any(guarded(k) for k in call.keywords):missing.append(sites[-1])
  if name in relay and name in before:
   v=Restore().visit(copy.deepcopy(f))
   idx=next(i for i,a in enumerate(v.args.kwonlyargs) if a.arg=='_guard')
   v.args.kwonlyargs.pop(idx);v.args.kw_defaults.pop(idx)
   # authorization_fingerprint's explicit completed iteration/pin is the same
   # original expression; reconstruct for exact default-only AST comparison.
   if name=='authorization_fingerprint':
    v.body[-2:]=ast.parse('return fingerprint([dict(row) for row in rows])').body
   restored[n+':'+name]=ast.dump(v,include_attributes=False)==ast.dump(before[name],include_attributes=False)
assert not missing,missing
assert all(restored.values()),restored
# Decoder try contains only the original decoding assignment. Guard is outside.
a=fmap(C/'natural_source_archives.py')['_body_payload_from_facts']
t=next(x for x in a.body if isinstance(x,ast.Try));assert len(t.body)==1
assert ast.unparse(t.body[0])=='payload = base64.b64decode(body.body_b64, validate=True)'
i=a.body.index(t);assert ast.unparse(a.body[i+1])=='payload = gate._trial_result(payload, _guard)'
# Guarded Scope/Release functions relay the exact graph object at their owned
# internal boundary; originals outside four-file scope receive no new protocol.
g=fmap(C/'natural_live_admission.py');d=fmap(C/'pa_trial_dispatch.py')
for fn,expected in [(g['_graph_stage_before_generation'],{'job_scope_gate','_stage_instance_after_bound'}),(d['_graph_stage_accounted'],{'_journal_stage_header'})]:
 for name in expected:
  calls=[x for x in ast.walk(fn) if isinstance(x,ast.Call) and (x.func.id if isinstance(x.func,ast.Name) else x.func.attr if isinstance(x.func,ast.Attribute) else None)==name]
  assert calls and all(any(k.arg=='_graph_read' and isinstance(k.value,ast.Name) and k.value.id=='graph' for k in x.keywords) for x in calls)
for name in ('_graph_stage_before_generation','_graph_stage_before_accounting'):
 f=g[name]
 # No J/model source/actual-accounting entry in either partial constructor.
 forbidden={'_graph_journal_state','_journal_state','_graph_stage_accounted','journal_stage_accounted','_generation_accounted','model_source','StageAuthority','_graph_check_run'}
 assert not forbidden.intersection(x.func.id if isinstance(x.func,ast.Name) else x.func.attr if isinstance(x.func,ast.Attribute) else None for x in ast.walk(f) if isinstance(x,ast.Call))
 assert 'if type(graph) is _ColdGraphRead:' in ast.unparse(f)
result={'status':'STATIC_ONLY_NOT_EXECUTED','ast':'PASS','apply_check':'PASS_READ_ONLY','guard_relay_sites':len(sites),'missing_guard_relay':missing,'default_none_ast_restored':restored,'decoder_guard_outside_original_try':'PASS','two_partial_prefix_no_J_or_Authority':'PASS','root_owned_lifecycle':'NOT_MODIFIED','product_tests':'NOT_RUN','test_draft_ast':'PASS','patch_sha256':hashlib.sha256((O/'relative-v2delta.patch').read_bytes()).hexdigest(),'test_patch_sha256':hashlib.sha256((O/'test-draft.patch').read_bytes()).hexdigest()}
(O/'STATIC-CHECKS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
