"""Generate a relative patch only. No product imports, DB, models or test runs."""
from pathlib import Path
import ast, copy, difflib, hashlib, json
O=Path('/workspace/pb-cold-graph-integration-metrics-20261019/relative-v2delta')
R=Path('/workspace/Sim2Act')
names=['production_trial_policy.py','pa_trial_dispatch.py','natural_source_archives.py','natural_live_admission.py']
old={n:(R/'src/sim2act'/n).read_text() for n in names}
new=dict(old)

def fns(n):return {f.name:f for f in ast.parse(new[n]).body if isinstance(f,ast.FunctionDef)}
def get(n,name):
 f=fns(n)[name];return ''.join(new[n].splitlines(True)[f.lineno-1:f.end_lineno])
def put(n,name,s):
 a=get(n,name);assert new[n].count(a)==1;new[n]=new[n].replace(a,s.rstrip()+'\n',1)
def replace(n,name,a,b):
 s=get(n,name);assert s.count(a)==1,(n,name,a[:80],s.count(a));put(n,name,s.replace(a,b))

# P2-1: exact current Run identity at all three joins, before body/row use.
n='natural_live_admission.py'
replace(n,'_graph_run_context',"        require(type(contract) is PBTrialContract and stage == 'cold')\n", "        require(type(contract) is PBTrialContract and stage == 'cold')\n        require(stage_facts[0]['id'] == run_id, 'Stage facts belong to another Run')\n")
replace(n,'_graph_run_context',"        _trial_result(_stage_accepted_from_facts(phase, accepted, _guard=_guard), _guard)\n", "        require(phase.run_id == run_id, 'Reconstructed stage belongs to another Run')\n        _trial_result(_stage_accepted_from_facts(phase, accepted, _guard=_guard), _guard)\n")
replace(n,'_graph_run_context',"        at = _trial_result(time.time(), _guard)\n", "        require(run is not None and run['id'] == run_id, 'Locked row belongs to another Run')\n        at = _trial_result(time.time(), _guard)\n")

# P2-3: only the decoder's ValueError is translated. The guard keeps its exact
# exception type/object and sits outside the original decoder try/except.
n='natural_source_archives.py'
replace(n,'_body_payload_from_facts',"        payload = gate._trial_result(base64.b64decode(body.body_b64, validate=True), _guard)\n", "        payload = base64.b64decode(body.body_b64, validate=True)\n")
replace(n,'_body_payload_from_facts',"        raise DomainError('VERSION_CONFLICT', 'Body archive encoding changed') from error\n", "        raise DomainError('VERSION_CONFLICT', 'Body archive encoding changed') from error\n    payload = gate._trial_result(payload, _guard)\n")

# P2-2a: these existing multi-callee helpers now retain the same optional pin
# throughout the full original authorization/approval chain.
added={
 'natural_live_admission.py':{'authorization_fingerprint','_authorize','_current','_keys','_saved','_approved','entity','parse_contract'},
 'production_trial_policy.py':{'_requirements'},
}
all_added=set().union(*added.values())
for n,targets in added.items():
 for name in sorted(targets):
  f=ast.parse(get(n,name)).body[0]
  assert '_guard' not in {a.arg for a in f.args.kwonlyargs}
  f.args.kwonlyargs.append(ast.arg(arg='_guard'));f.args.kw_defaults.append(ast.Constant(None))
  ast.fix_missing_locations(f);put(n,name,ast.unparse(f)+'\n')

skip_names={'require','_require','dict','tuple','list','set','str','int','float','bytes','bool','type','isinstance','len','all','any','next','iter','min','max','getattr','sorted','select','DomainError','ValueError','Exception','BaseException','_guard','_trial_result','_graph_trial_pin'}
skip_attrs={'require','get','pop','append','index','where','select_from','join','order_by','with_for_update','in_','as_string','as_integer','as_boolean','label','_graph_trial_pin','_trial_result'}

def conditional_kw(name,value):
 return ast.keyword(arg=None,value=ast.IfExp(test=ast.Compare(left=ast.Name(value,ast.Load()),ops=[ast.IsNot()],comparators=[ast.Constant(None)]),body=ast.Dict(keys=[ast.Constant(name)],values=[ast.Name(value,ast.Load())]),orelse=ast.Dict(keys=[],values=[])))
class NewGuard(ast.NodeTransformer):
 def __init__(self,n):self.n=n;self.calls=[]
 def visit_Call(self,node):
  node=self.generic_visit(node)
  name=node.func.id if isinstance(node.func,ast.Name) else node.func.attr if isinstance(node.func,ast.Attribute) else None
  if name in all_added:node.keywords.append(conditional_kw('_guard','_guard'))
  if isinstance(node.func,ast.Name) and name in skip_names or isinstance(node.func,ast.Attribute) and name in skip_attrs:return node
  self.calls.append(ast.unparse(node.func))
  wrap=ast.parse('_trial_result' if self.n=='natural_live_admission.py' else 'gate._trial_result',mode='eval').body
  return ast.copy_location(ast.Call(func=wrap,args=[node,ast.Name('_guard',ast.Load())],keywords=[]),node)

boundaries={}
for n,targets in added.items():
 boundaries[n]={}
 for name in sorted(targets):
  f=ast.parse(get(n,name)).body[0];tr=NewGuard(n);f=tr.visit(f)
  # Cursor iteration is lazy: collect and pin before fingerprinting Grant rows.
  if name=='authorization_fingerprint':
   f.body[-1:]=ast.parse("values = _trial_result([dict(row) for row in rows], _guard)\nreturn _trial_result(fingerprint(values), _guard)").body
  ast.fix_missing_locations(f);put(n,name,ast.unparse(f)+'\n')
  boundaries[n][name]=tr.calls

# Propagate optional guards through all already guarded shared and strict nodes.
# None preserves original keyword/call shape; only fixed strict closures are used.
class Relay(ast.NodeTransformer):
 def visit_Call(self,node):
  node=self.generic_visit(node)
  name=node.func.id if isinstance(node.func,ast.Name) else node.func.attr if isinstance(node.func,ast.Attribute) else None
  if name in all_added and not any(k.arg=='_guard' or k.arg is None and isinstance(k.value,ast.IfExp) and isinstance(k.value.body,ast.Dict) and any(isinstance(v,ast.Constant) and v.value=='_guard' for v in k.value.body.keys) for k in node.keywords):
   node.keywords.append(conditional_kw('_guard','_guard'))
  return node
for n in names:
 for name,f in list(fns(n).items()):
  if name in added.get(n,set()):continue
  if not any(a.arg=='_guard' for a in f.args.kwonlyargs) and not(name.startswith('_graph_') and name!='_graph_trial_pin'):continue
  f=Relay().visit(ast.parse(get(n,name)).body[0]);ast.fix_missing_locations(f);put(n,name,ast.unparse(f)+'\n')

# P2-2b: pass the exact graph into callees that already own their internal pins.
# Parent owns lifecycle's fixed release-pointer key/repeat comparison behavior.
n='natural_live_admission.py'
f=ast.parse(get(n,'_stage_instance_after_bound')).body[0]
f.args.kwonlyargs.append(ast.arg(arg='_graph_read'));f.args.kw_defaults.append(ast.Constant(None))
class LifeRelay(ast.NodeTransformer):
 def visit_Call(self,node):
  node=self.generic_visit(node)
  if isinstance(node.func,ast.Name) and node.func.id in {'owned_release_pointer','immutable_release_pointer'}:node.keywords.append(conditional_kw('_graph_read','_graph_read'))
  return node
f=LifeRelay().visit(f);ast.fix_missing_locations(f);put(n,'_stage_instance_after_bound',ast.unparse(f)+'\n')
class StrictRelay(ast.NodeTransformer):
 def visit_Call(self,node):
  node=self.generic_visit(node)
  name=node.func.id if isinstance(node.func,ast.Name) else node.func.attr if isinstance(node.func,ast.Attribute) else None
  if name in {'job_scope_gate','scope_gate','source_scope_gate','_stage_instance_after_bound','_journal_stage_header'} and not any(k.arg=='_graph_read' for k in node.keywords):node.keywords.append(ast.keyword(arg='_graph_read',value=ast.Name('graph',ast.Load())))
  return node
for n in names:
 for name in list(fns(n)):
  if not(name.startswith('_graph_') and name!='_graph_trial_pin'):continue
  f=StrictRelay().visit(ast.parse(get(n,name)).body[0]);ast.fix_missing_locations(f);put(n,name,ast.unparse(f)+'\n')
n='pa_trial_dispatch.py';f=ast.parse(get(n,'_journal_stage_header')).body[0]
f.args.kwonlyargs.append(ast.arg(arg='_graph_read'));f.args.kw_defaults.append(ast.Constant(None))
class StageRelay(ast.NodeTransformer):
 def visit_Call(self,node):
  node=self.generic_visit(node)
  name=node.func.id if isinstance(node.func,ast.Name) else None
  if name in {'source_scope_gate','job_scope_gate'}:node.keywords.append(conditional_kw('_graph_read','_graph_read'))
  return node
f=StageRelay().visit(f);ast.fix_missing_locations(f);put(n,'_journal_stage_header',ast.unparse(f)+'\n')

# Required original first-needed sequencing: current Instance/target before any
# native model_source; metadata/approval/frozen before first accounting/J.
n='natural_live_admission.py'
f=ast.parse(get(n,'_graph_stage_current')).body[0]
block=next(x for x in f.body if isinstance(x,ast.Try))
b=block.body
call_names=lambda stmt:{x.func.attr if isinstance(x.func,ast.Attribute) else x.func.id for x in ast.walk(stmt) if isinstance(x,ast.Call) and isinstance(x.func,(ast.Name,ast.Attribute))}
start=next(i for i,x in enumerate(b) if 'job_scope_gate' in call_names(x))
gen=next(i for i,x in enumerate(b) if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='gen_id' for t in x.targets))
metadata=next(i for i,x in enumerate(b) if '_stage_generation_metadata_from_facts' in call_names(x))
end=next(i for i,x in enumerate(b) if '_stage_generate_from_facts' in call_names(x))+1
snapshot=next(copy.deepcopy(x) for x in b[start:gen] if isinstance(x,ast.Assign) and any(isinstance(t,ast.Tuple) and [e.id for e in t.elts if isinstance(e,ast.Name)]==['snapshot','draft','release'] for t in x.targets))

def fixed_graph_helper(signature,doc,body):
 g=ast.parse(signature+':\n    pass\n').body[0]
 g.body=[ast.Expr(ast.Constant(doc)),copy.deepcopy(next(x for x in f.body if isinstance(x,ast.FunctionDef)))]
 protected=copy.deepcopy(block);protected.body=body
 g.body.append(protected);ast.fix_missing_locations(g)
 new[n]+='\n\n'+ast.unparse(g)+'\n'

initial=[copy.deepcopy(b[0]),copy.deepcopy(b[1]),copy.deepcopy(b[2])]
first=initial+copy.deepcopy(b[start:gen+1])+ast.parse("require(gen_id is not None)\nreturn inst, current_release, target, gen_id").body
fixed_graph_helper('def _graph_stage_before_generation(graph, store, c, user, contract, stage, job, bound)',
 'Original current Instance/Release/target and Generate-ID prefix only; no model source, J or Authority.',first)
second=ast.parse("_graph_trial_pin(graph, store, c)\nrequire(type(contract) is PBTrialContract and stage in ('source', 'cold'))\ninst, current_release, target, gen_id = stage_prefix\nrequire(gen['id'] == gen_id)").body+copy.deepcopy(b[metadata:end])+ast.parse('return inst, current_release, target, gen_id, approval').body
fixed_graph_helper('def _graph_stage_before_accounting(graph, store, c, user, contract, stage, job, bound, raw, metadata, gen, frozen, stage_prefix)',
 'Original Generate metadata/approval/frozen prefix after complete native source; no J, accounting or Authority.',second)
reused=ast.parse("stage_prefix = _trial_result(_graph_stage_before_generation(graph, store, c, user, contract, stage, job, bound), _guard)").body+[snapshot]+ast.parse("inst, current_release, target, gen_id, approval = _trial_result(_graph_stage_before_accounting(graph, store, c, user, contract, stage, job, bound, raw, metadata, gen, frozen, stage_prefix), _guard)").body
block.body=[x for x in b[:start]+reused+b[end:] if not (isinstance(x,ast.ImportFrom) and any(a.name in {'natural_specs','pa_spec_apps'} for a in x.names))]
ast.fix_missing_locations(f);put(n,'_graph_stage_current',ast.unparse(f)+'\n')

# Pure AST checks and relative patch generation; no product import/execution.
patch='';manifest={}
for n in names:
 ast.parse(new[n]);p=O/'candidate/src/sim2act'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(new[n])
 base=O/'baseline/src/sim2act'/n;base.parent.mkdir(parents=True,exist_ok=True);base.write_text(old[n])
 patch+=''.join(difflib.unified_diff(old[n].splitlines(True),new[n].splitlines(True),fromfile='a/src/sim2act/'+n,tofile='b/src/sim2act/'+n))
 manifest[n]={'base_sha256':hashlib.sha256(old[n].encode()).hexdigest(),'candidate_sha256':hashlib.sha256(new[n].encode()).hexdigest()}
# Execution families stay identical; defaultNone helper semantics preserved.
preserved={'production_trial_policy.py':['reserve','record_attempt','settle'], 'pa_trial_dispatch.py':['reject','request_captured','_journal_exchange'], 'natural_live_admission.py':['_generation_accounted','admit']}
for n,fs in preserved.items():
 a={f.name:ast.dump(f,include_attributes=False) for f in ast.parse(old[n]).body if isinstance(f,ast.FunctionDef)}
 b={f.name:ast.dump(f,include_attributes=False) for f in ast.parse(new[n]).body if isinstance(f,ast.FunctionDef)}
 for name in fs:assert a[name]==b[name],(n,name)
(O/'relative-v2delta.patch').write_text(patch)
meta={'status':'EXTERNAL_RELATIVE_V2_DELTA_AST_ONLY_NOT_APPLIED_NOT_TESTED','base_head':'dc34ce4b1311810e27cd33a0cd156b6f84333666','files':manifest,'patch_bytes':len(patch.encode()),'patch_sha256':hashlib.sha256(patch.encode()).hexdigest(),'execution_ast_unchanged':preserved,'new_helper_guarded_calls':boundaries}
(O/'MANIFEST.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps({k:v for k,v in meta.items() if k not in {'files','new_helper_guarded_calls','execution_ast_unchanged'}},indent=2))
