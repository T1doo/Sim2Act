"""Isolated synthetic boundary units, not a complete Stage proof or trial permit.

Draft only: not executed. Reuses existing local SQLite pin/release fixtures;
no Worker construction, claim, model, HTTP, sender, J or full P-B chain.
"""

import copy
from types import SimpleNamespace

import pytest
from sqlalchemy import event, insert, select
from test_cold_binding_fact_leaves import local_origin as local_origin
from test_cold_binding_fact_leaves import no_external_transport as no_external_transport
from test_cold_release_stages import read_scope, saved as saved

from sim2act import natural_live_admission as gate
from sim2act import natural_source_archives as archive
from sim2act import pb_natural_specs as pb
from sim2act import text_continuations
from sim2act.db import fingerprint, internal_instances, internal_releases, new_id
from sim2act.errors import DomainError


@pytest.mark.parametrize('where', ['input', 'phase', 'locked-row'])
def test_graph_run_context_rejects_each_wrong_run_join_before_next_consumer(
        local_origin, monkeypatch, where):
    f, calls = local_origin, []
    rid, other = new_id('run'), new_id('run')
    stage_facts = ({'id': other if where == 'input' else rid},) + (None,) * 8
    f.inputs['stage_facts'] = stage_facts
    key = f.worker.pa_trial.approval_key
    # Explicit isolated stand-ins stop at the identity join under test. These
    # cannot produce or claim a valid Authority, RunCheck or admitted execution.
    phase = SimpleNamespace(run_id=other if where == 'phase' else rid)
    accepted = SimpleNamespace(approval_key=key)

    def approved(*args, **kwargs):
        calls.append('approval')
        return SimpleNamespace()

    def staged(*args, **kwargs):
        calls.append('phase')
        return phase, stage_facts[0]

    def accepted_join(*args, **kwargs):
        calls.append('accepted-join')

    def locked(*args, **kwargs):
        calls.append('locked-row')
        return {'id': other}

    def row_consumer(*args, **kwargs):
        pytest.fail('Wrong Run identity reached full row consumer')

    monkeypatch.setattr(gate, '_approved', approved)
    monkeypatch.setattr(gate, '_keys', lambda *a, **k: set())
    monkeypatch.setattr(gate, '_saved', lambda *a, **k: accepted)
    monkeypatch.setattr(gate, '_graph_stage_current', staged)
    monkeypatch.setattr(gate, '_stage_accepted_from_facts', accepted_join)
    monkeypatch.setattr(gate, '_run_context_row', locked)
    monkeypatch.setattr(gate, '_require_run_context_row', row_consumer)
    with f.store.tx() as c, pb._source_reads(f.store, c):
        with pytest.raises(DomainError) as caught:
            with read_scope(f, c) as guard:
                gate._graph_run_context(guard, f.store, c, f.user,
                    f.worker.pa_trial.contract, key, 'cold', rid, 1, 1, stage_facts)
    assert caught.value.code == 'VERSION_CONFLICT' and not guard.active
    assert calls == {'input': [], 'phase': ['approval', 'phase'],
        'locked-row': ['approval', 'phase', 'accepted-join', 'locked-row']}[where]


@pytest.fixture
def stage_instance(saved):
    f = saved
    f.iid = new_id('instance')
    with f.store.tx() as c:
        c.execute(insert(internal_instances).values(id=f.iid,
            principal_id=f.user, project_id=f.draft['project_id'],
            source_app_id=f.draft['id'], runtime_id=f.draft['runtime_id'],
            release_id=f.rid, revision=1, data_version=0, history=[]))
        f.pointer_release = dict(c.execute(select(internal_releases).where(
            internal_releases.c.id == f.rid)).mappings().one())
    f.pointer_job = dict(project_id=f.draft['project_id'], runtime_id=f.draft['runtime_id'])
    f.pointer_snapshot = dict(instance_id=f.iid)
    f.inputs['pointer'] = (f.pointer_release, f.pointer_job, f.pointer_snapshot)
    return f


def test_trial_stage_release_gate_drift_reads_zero_release_bodies(stage_instance, monkeypatch):
    f, bodies = stage_instance, []

    def drift(*args):
        f.worker.s = copy.copy(f.worker.s)

    def after_sql(c, cursor, statement, params, context, executemany):
        if 'FROM internal_releases' in statement:
            bodies.append(statement)

    monkeypatch.setattr(text_continuations, 'release_gate', drift)
    event.listen(f.store.engine, 'after_cursor_execute', after_sql)
    try:
        with f.store.tx() as c, pb._source_reads(f.store, c):
            with pytest.raises(DomainError):
                with read_scope(f, c) as guard:
                    def pin():
                        gate._graph_trial_pin(guard, f.store, c)
                    gate._stage_instance_after_bound(f.store, c, f.user,
                        f.draft['project_id'], f.pointer_job, f.pointer_snapshot,
                        f.pointer_release, c.info.get('source_proof_write_epoch', 0),
                        _guard=pin, _graph_read=guard)
        assert not bodies and not guard.active
    finally:
        event.remove(f.store.engine, 'after_cursor_execute', after_sql)


def test_trial_approval_sql_drift_stops_before_any_paired_payload(local_origin, monkeypatch):
    f, bodies, changed = local_origin, [], [False]

    def after_sql(c, cursor, statement, params, context, executemany):
        if 'FROM delivery_graph_requests' in statement:
            f.inputs['history'].append({'id': 'drift', 'body': b'changed'})
            changed[0] = True

    def payload(*args, **kwargs):
        bodies.append('pair')
        pytest.fail('Approval payload was read after the metadata SQL drift')

    # The current material/Goal protocol is outside this boundary test. Keep the
    # actual original _approved -> _keys SQL -> guard -> _saved ordering.
    monkeypatch.setattr(gate, '_current', lambda *a, **k: None)
    monkeypatch.setattr(gate, 'pair', payload)
    event.listen(f.store.engine, 'after_cursor_execute', after_sql)
    try:
        with f.store.tx() as c, pb._source_reads(f.store, c):
            with pytest.raises(DomainError):
                with read_scope(f, c) as guard:
                    def pin():
                        gate._graph_trial_pin(guard, f.store, c)
                    gate._approved(f.store, c, f.user, f.worker.pa_trial.contract,
                        f.worker.pa_trial.approval_key, _guard=pin)
        assert changed[0] and not bodies and not guard.active
    finally:
        event.remove(f.store.engine, 'after_cursor_execute', after_sql)


def test_archive_decode_guard_preserves_original_valueerror_identity(local_origin, monkeypatch):
    f, decoded = local_origin, [False]
    original = ValueError('synthetic successful-decode guard failure')
    job = dict(id=new_id('run'), principal_id=f.user, project_id=f.draft['project_id'],
        runtime_id=f.draft['runtime_id'])
    aid = new_id('attempt')
    body = archive._body(job, aid, b'{}', True, None, archive.RESPONSE)
    anchors = [dict(attempt_id=aid, archive_fingerprint=fingerprint(body.model_dump()))]
    decode = archive.base64.b64decode

    def observed_decode(*args, **kwargs):
        value = decode(*args, **kwargs)
        decoded[0] = True
        return value

    monkeypatch.setattr(archive.base64, 'b64decode', observed_decode)
    with f.store.tx() as c, pb._source_reads(f.store, c):
        with pytest.raises(ValueError) as caught:
            with read_scope(f, c) as guard:
                def pin():
                    if decoded[0]:
                        raise original
                    gate._graph_trial_pin(guard, f.store, c)
                archive._body_payload_from_facts(body, anchors, aid, _guard=pin)
    assert decoded[0] and caught.value is original and not guard.active
