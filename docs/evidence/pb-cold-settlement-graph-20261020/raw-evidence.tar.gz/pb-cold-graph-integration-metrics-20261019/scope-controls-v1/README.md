# Scoped controlled-error ownership candidate

External candidates only. No repository write, product import, DB/model operation, Worker execution, pytest or network call was performed by this subagent. AST compile means compile without execution.

Product patch: `scope-controls.patch`, SHA256 `15acca256e2a2090768ba9a6cb334623bf3f9f653eb3f1851e60cf87c7684fc0`, 7693 bytes.

Test patch: `scope-controls-tests.patch`, SHA256 `a6c22cac9864c4202d5d0f761a800d034281d4a12340d450d443620d200fda02`, 12185 bytes.

The source baseline SHA256 is `6f049ea1a8f9dcc259aec922ddcf332fd0b0ddd12c11ad6fdcff00800fab9d5f`. Target is concurrently owned by another agent: this patch leaves its AST and every unrelated existing function unchanged. New leaves are inserted next to the scope/receipt sections, not appended into another agent's EOF helper region.

## Exact source scope

- `scope_gate`: `_graph_read=None` enters a controlled default wrapper and the shared original `_scope_gate_core`. A strict caller directly enters that same core, with exact-CGR-only sticky cleanup and a bare re-raise. All original SQL, authorities, default child argument shapes and ordered predicates remain in the one core.
- `job_scope_gate`: same dispatch, retaining the entire original proof-authorities protocol in `_job_scope_gate_with_authorities`. The existing `_job_scope_gate` body remains shared.
- Strict Metadata/RunScopeInput pairs use one fixed two-choice private scope reader. Both SQL lookups, raw seal checks and checkpoints are outside controlled mapping; only `_persisted_scope_metadata` and `_persisted_run_scope` perform mapped fixed model parsing. No arbitrary model/parser is accepted. The default branches still call the original `pair` with the original arguments.
- `_cold_receipts` and `_cold_verify_job_from_receipts` lose only the total controlled decorator. Their original try/invalidate/bare-raise bodies are identical.
- `_receipt_data` maps only the original persisted `op['receipt']['data']` indexing. Strict `_receipts` calls it inline at the original `validate_value` second-argument position. Input-schema evaluation and earlier intent/read predicates keep their old first-error order. The later data read follows successful schema validation plus the original checkpoint.
- `_receipt_output` maps only the original unchanged pure `output_for` data-indexing function. Strict `_verify_job_from_receipts` uses it at the original output assembly position. Schema validators, IO and checkpoints remain outside the mapper.
- Both receipt cores select their original expressions unchanged when `_facts is None`. No natural executor, sender, reserve, TTL, Grant or other execution family is added.

The existing optional project branch of `_job_scope_gate` is unchanged, including `project.Reference` pair and its Limits construction. This candidate deliberately does not expand that separate family. The parent has been told about this branch; if all strict callers across that family must also inherit the old parse mapping, that requires an explicit additional scope decision rather than claiming it is covered here.

The known persisted-data exceptions before original node proof are receipt=None / missing receipt.data and output indexing; the narrow mappers cover those original points. Other post-validation accesses retain complete bound/counter/receipt prerequisites, and later step event reads select the fixed operation_id from stored JSON; no blanket mapping or early whole-receipt revalidation was introduced.

## Exact test targets (9 bounded cases)

Run target: `pytest -q tests/test_cold_spec_controlled.py` after the parent applies both candidates.

- `test_strict_scope_sql_guard_valueerror_is_original_before_next_lookup` (scope/job): after the first real SQL, the real exact guard's callback raises a specific ValueError. Its object identity escapes; no second SQL or owned parser runs; sticky invalidation is asserted before context cleanup.
- `test_strict_receipt_entry_guard_valueerror_is_original_and_reads_zero_sql` (receipts/verify): actual `_ColdRunFacts` plus real read scope. The entry guard fails with the original ValueError before either core or any SELECT.
- `test_fixed_owned_scope_parse_matches_original_paired_malformed_mapping` (Metadata/RunScopeInput): two real persisted matching seals with correct hashes and one missing required field. The old controlled(pair) and strict fixed pair must yield identical domain errors. Exactly one owned parser runs in strict mode.
- `test_owned_receipt_data_malformed_maps_before_output_validation_or_node_proof` (None/missing data): exact RawFacts seeds and original first-node intent/receipt logic. Only the independent counter precondition is isolated, with no counter proof installed and no successful receipt/Authority possible. The original data-expression mapper error matches, before output validation or model proof.
- `test_owned_receipt_output_malformed_maps_before_schema_consumer`: exact RawFacts plus an isolated independent receipt precondition (no proof installed). The actual cold verify wrapper reaches the original output indexing point and rejects missing output with the old pure output mapping, before schema consumption.

The tests reuse `local_origin`, `read_scope` and the existing no-transport fixture. They do not claim full counters/receipts/Stage or production acceptance.

## Static evidence and limits

Completed: source/test AST parse and compile without executing; both git apply --check calls; original target/unrelated function AST equality; default-path shared-core AST equality after selecting only default branches; both cold wrappers identical except removed decorators; fixed pure mapper call shapes; exact nine-case count. See STATIC-CHECKS.json, MANIFEST.json and TEST-MANIFEST.json.

No runtime success, timing, source stability or full P-B pass is claimed. Parent review, application, lint/type checking and the bounded tests remain necessary. Optional project-family behavior remains outside the candidate's claimed coverage.
