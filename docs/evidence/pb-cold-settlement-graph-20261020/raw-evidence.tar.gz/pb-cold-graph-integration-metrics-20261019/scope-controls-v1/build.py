from pathlib import Path
import ast,difflib,hashlib,json
R=Path('/workspace/Sim2Act');O=Path('/workspace/pb-cold-graph-integration-metrics-20261019/scope-controls-v1')
path='src/sim2act/pa_spec_apps.py';old=(R/path).read_text();new=old

def take(text,name):
 f=next(x for x in ast.parse(text).body if isinstance(x,ast.FunctionDef) and x.name==name)
 start=min([f.lineno]+[d.lineno for d in f.decorator_list])-1
 return ''.join(text.splitlines(True)[start:f.end_lineno])

def replace(name,text):
 global new
 previous=take(new,name);assert new.count(previous)==1
 new=new.replace(previous,text.rstrip()+'\n',1)

for public,core in [('scope_gate','_scope_gate_core'),('job_scope_gate','_job_scope_gate_with_authorities')]:
 original=take(new,public)
 assert original.startswith('@controlled\n')
 body=original.removeprefix('@controlled\n').replace('def '+public+'(', 'def '+core+'(',1)
 if public=='scope_gate':
  body=body.replace('meta, sealed = pair(c, user, aid, META, "scope", Metadata)',
   'meta, sealed = (pair(c, user, aid, META, "scope", Metadata)\n            if _graph_read is None else _cold_scope_pair(store, c, user, aid, _graph_read))')
 arg='aid' if public=='scope_gate' else 'rid'
 dispatcher=f'''def {public}(store, c, user, {arg}, *, _graph_read=None):
    if _graph_read is None:
        return _{public}_default(store, c, user, {arg})
    try:
        return {core}(store, c, user, {arg}, _graph_read=_graph_read)
    except BaseException:
        from .natural_spec_runtime import _ColdGraphRead
        if type(_graph_read) is _ColdGraphRead:
            _ColdGraphRead.invalidate(_graph_read)
        raise


@controlled
def _{public}_default(store, c, user, {arg}):
    return {core}(store, c, user, {arg})


'''
 replace(public,dispatcher+body)
s=take(new,'_job_scope_gate')
needle='meta, seal = pair(c, user, rid, RUN_META, "accepted", RunScopeInput)'
assert s.count(needle)==1
replace('_job_scope_gate',s.replace(needle,'meta, seal = (pair(c, user, rid, RUN_META, "accepted", RunScopeInput)\n        if _graph_read is None else _cold_scope_pair(store, c, user, rid, _graph_read, run_scope=True))'))
for name in ['_cold_receipts','_cold_verify_job_from_receipts']:
 s=take(new,name);assert s.startswith('@controlled\n');replace(name,s.removeprefix('@controlled\n'))
s=take(new,'_receipts');needle='validate_value(action["output_schema"], op["receipt"]["data"])';assert s.count(needle)==1
replace('_receipts',s.replace(needle,'validate_value(action["output_schema"],\n            _receipt_data(op) if _facts is not None else op["receipt"]["data"])'))
s=take(new,'_verify_job_from_receipts');needle='output = output_for(b["plan"], outputs)';assert s.count(needle)==1
replace('_verify_job_from_receipts',s.replace(needle,'output = (_receipt_output(b["plan"], outputs) if _facts is not None\n            else output_for(b["plan"], outputs))'))
leaves=(O/'leaves.py').read_text()
scope_leaves,receipt_leaves=leaves.split('\n\n@controlled\ndef _receipt_data',1)
new=new.replace('def scope_gate(',scope_leaves.strip()+'\n\n\ndef scope_gate(',1)
new=new.replace('def _receipt_checkpoint(', '@controlled\ndef _receipt_data'+receipt_leaves.strip('\n')+'\n\n\ndef _receipt_checkpoint(',1)
parsed=ast.parse(new);compile(parsed,'external scope-control candidate','exec')
a={x.name:ast.dump(x,include_attributes=False) for x in ast.parse(old).body if isinstance(x,(ast.FunctionDef,ast.ClassDef))};b={x.name:ast.dump(x,include_attributes=False) for x in parsed.body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
assert a['target']==b['target']
allowed={'scope_gate','job_scope_gate','_job_scope_gate','_cold_receipts','_cold_verify_job_from_receipts','_receipts','_verify_job_from_receipts'}
assert all(a[name]==b[name] for name in a if name not in allowed)
for kind,text in [('baseline',old),('candidate',new)]:
 p=O/kind/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
patch=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+path,tofile='b/'+path))
(O/'scope-controls.patch').write_text(patch)
meta=dict(status='EXTERNAL_PRODUCT_CANDIDATE_NOT_APPLIED_NOT_EXECUTED',file=path,
 base_sha256=hashlib.sha256(old.encode()).hexdigest(),candidate_sha256=hashlib.sha256(new.encode()).hexdigest(),
 patch_bytes=len(patch.encode()),patch_sha256=hashlib.sha256(patch.encode()).hexdigest(),target_AST_unchanged=True,
 changed_existing=sorted(name for name in a if a[name]!=b[name]),added_functions=sorted(b.keys()-a.keys()),
 syntax_compile_without_execution=True,product_or_database_or_model_or_pytest_executed=False)
(O/'MANIFEST.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta,indent=2))
