from pathlib import Path
import ast,difflib,hashlib,json
O=Path('/workspace/pb-cold-graph-integration-metrics-20261019/scope-controls-v1')
path='tests/test_cold_spec_controlled.py';new=(O/'tests.py').read_text()
tree=ast.parse(new);compile(tree,'external spec controlled tests','exec')
p=O/'candidate'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(new)
patch=''.join(difflib.unified_diff([],new.splitlines(True),fromfile='/dev/null',tofile='b/'+path))
(O/'scope-controls-tests.patch').write_text(patch)
targets={}
for f in tree.body:
 if isinstance(f,ast.FunctionDef) and f.name.startswith('test_'):
  count=1
  for d in f.decorator_list:
   if isinstance(d,ast.Call) and isinstance(d.func,ast.Attribute) and d.func.attr=='parametrize':count*=len(d.args[1].elts)
  targets[path+'::'+f.name]=count
assert sum(targets.values())==9
meta=dict(status='EXTERNAL_TEST_CANDIDATE_NOT_APPLIED_NOT_EXECUTED',file=path,
 patch_bytes=len(patch.encode()),patch_sha256=hashlib.sha256(patch.encode()).hexdigest(),targets=targets,new_cases=9,
 syntax_compile_without_execution=True,product_or_database_or_model_or_pytest_executed=False)
(O/'TEST-MANIFEST.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta,indent=2))
