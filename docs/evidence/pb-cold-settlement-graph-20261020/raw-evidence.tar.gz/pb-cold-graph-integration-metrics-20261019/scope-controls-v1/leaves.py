

@controlled
def _persisted_scope_metadata(value):
    """Only the fixed owned Metadata parse inherits the old error mapping."""
    return Metadata.model_validate(value)


@controlled
def _persisted_run_scope(value):
    """Only the fixed owned RunScopeInput parse inherits the old mapping."""
    return RunScopeInput.model_validate(value)


def _cold_scope_pair(store, c, user, entity, guard, *, run_scope=False):
    """Fixed app/run scope pairs; IO and guard errors are outside parse mapping."""
    from . import delivery_graph_apps as graph
    from .text_logic_reuse import require as pair_require

    try:
        require(type(run_scope) is bool and guard is not None)
        kind, key = (RUN_META, 'accepted') if run_scope else (META, 'scope')
        _bound_checkpoint(store, c, guard)
        rows = []
        for saved_kind in (kind, kind + '_seal'):
            row = graph.lookup(c, user, entity, saved_kind, key)
            _bound_checkpoint(store, c, guard)
            rows.append(row)
        pair_require(all(rows), 'Independent text logic seals missing')
        values = []
        for row in rows:
            value = graph.checked(row)
            _bound_checkpoint(store, c, guard)
            values.append(value)
        left, right = values
        pair_require(set(left) == {'request', 'response'})
        left_fp = fingerprint(left)
        _bound_checkpoint(store, c, guard)
        right_fp = fingerprint(right)
        _bound_checkpoint(store, c, guard)
        pair_require(left_fp == right_fp)
        # No query, checkpoint or user callback is inside either fixed parser.
        body = (_persisted_run_scope(left['request']) if run_scope
            else _persisted_scope_metadata(left['request']))
        _bound_checkpoint(store, c, guard)
        for row in rows:
            request_fp = fingerprint(RunScopeInput.model_dump(body) if run_scope
                else Metadata.model_dump(body))
            _bound_checkpoint(store, c, guard)
            pair_require(row['request_fingerprint'] == request_fp)
        return body, left['response']
    except BaseException:
        from .natural_spec_runtime import _ColdGraphRead
        if type(guard) is _ColdGraphRead:
            _ColdGraphRead.invalidate(guard)
        raise


@controlled
def _receipt_data(op):
    """Original persisted data indexing only; no guard, schema validator or IO."""
    return op['receipt']['data']


@controlled
def _receipt_output(plan, outputs):
    """Map only the original pure output-indexing leaf's persisted-data errors."""
    return output_for(plan, outputs)
