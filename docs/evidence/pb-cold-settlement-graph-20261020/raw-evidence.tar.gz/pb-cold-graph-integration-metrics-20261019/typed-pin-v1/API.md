# Typed continuity candidate (external only)

Base HEAD: dc34ce4b1311810e27cd33a0cd156b6f84333666. The patch is relative to the five live files recorded in MANIFEST.json, including the parent's current runtime helpers. It changes four trial files and only `_ColdTrialGraph` in runtime. Nothing has been applied by this subagent.

The exact `_ColdGraphRead` class, serializer, lifetime and input-key semantics are unchanged. The new helpers do not return ALLOW, authorize, resolve an ancestor, reparse a body, create executor/Grant/reservation, or replay a semantic verifier.

## Fixed interfaces and ownership

| Interface | Responsibility |
| --- | --- |
| gate `_trial_typed_guard(parent, models)` | Lexical cohort of `(exact known model class, actual model, complete original raw dict)`. Invoke the exact parent pin first, then use the fixed classes' ordinary pure `model_dump` and compare every field. There is no IO/external callback inside this pass; no prior-success cache. All original sensitive callbacks retain their own post-call guard. |
| gate `_graph_trial_hold(...)` | Assemble one lexical model cohort; only redundant watcher triples with identical class/model/raw identities are omitted. It never collapses any accounting aid/slot/body list. |
| gate `_graph_trial_produced(...)` | After an original complete producer, freeze its full typed output before subsequent callback/IO and keep comparing the actual object through this lexical call. Exact class checked before serialization. |
| gate `_graph_trial_journal_models(...)` | Actual Ledger and Cursor versus full `cold-trial:journal` canonical raw. |
| gate `_graph_trial_accounted_models(...)` | Every ordered Slot/Capture and every ordered Source NS request/response BodyArchive versus canonical complete accounted raw, including all per-aid bytes, rows and cardinality. |
| gate `_graph_trial_frozen_models`, `_graph_trial_extraction_models`, `_graph_trial_stage_models` | Actual FrozenRunContract and ExtractInput/StageFacts models against the already pinned Generate/extraction/accounted nodes; not a Stage Authority. |
| gate `_graph_trial_stage_raw(graph, stage_facts)` | Fixed raw Stage tuple views retain canonical Cold/Source Run, bound, Generation raw/metadata/run and extraction raw object identities. It is called by each Stage callback guard. |
| gate `_graph_trial_models_pin(...)` | Coordinator's full actual model comparisons, with exact-CGR-only sticky invalidation and bare re-raise. |
| dispatch `_graph_journal_state` | Pins complete canonical J raw before returning its mutable typed results. |
| dispatch `_graph_stage_accounted` | Pins complete canonical accounted-stage raw before returning typed Slots/Captures/BodyArchives. The runtime compares this node rather than adding it again. |
| runtime `_ColdTrialGraph._typed_parameters` | Keeps actual J/accounted/Frozen/ExtractInput/Goal/manifest/contract/requirements/context/fresh source values tied to their existing complete raw facts after seal. Complete Stage groups activate only after `cold-trial:complete` exists. |

Shared original `_saved`, archive `_read`, journal body and stage-header readers retain their actual returned models against their original full sealed raw through their own callbacks. Default `_guard=None` retains the original SQL, parse and first-error order. Policy reserve/record/settle/bound/RunCheck construction and the original execution families are AST-unchanged.

## Coordinator sequence and performance

The first full `_prepare` computes `_fields()` exactly once, adds the full raw node, and immediately seals that raw record. This is a continuity anchor, not semantic completion or Authority. The first `commit` still executes full original Stage, policy/Run, SourceArchive, archive-chain, Grant/source/final deadline checks before it can return. Only then are semantic Authorities installed.

The later `check` uses the full raw-record identity plus every actual typed consumer comparison; it never rebuilds `_fields`. Each `_prepare`, `_recheck` and `commit` also has its own lexical current-output cohort so a current Approval/P/fresh source cannot be mutated by a later callback before consumption. Current source is registered under the actual boundary once; it is never reused as freshness permission.

`_prepare` no longer shortcuts equal platform/trial Limits by assigning `self.trial = self.platform`; it always calls the parent's role-aware `_cold_trial_binding` wrapper when a platform graph exists. All original current role scope/target authorities remain active.

Pure serialization evidence: the nine fixed model modules have no field_serializer/model_serializer/computed_field/model_dump override/json_encoders. Models' existing model validators are not called by model_dump. Consequently one entry parent pin surrounds the pure exact-model comparison pass without doubling recursive parent pins. No product module was imported to perform this check.

## Verification and limits

Completed: five-file AST parse + Python compile without executing; exact AST checks for protected execution families and runtime scope; git apply --check; one-time `_fields` AST call-count check; static serializer-hook scan. Raw outputs are in STATIC-CHECKS.json and MANIFEST.json.

Not executed by this subagent: any product import, DB read/write, model/transport call, pytest/full P-B chain, performance timing, Windows, PG or remote CI. Parent review/apply and bounded actual source/typed-drift checks remain necessary. Baseline/candidate snapshots are included for exact review. If the parent changed a baseline file, use a bounded rebase/review rather than a forced apply.

Suggested focused actual checks for the parent: mutate a typed Ledger/Cursor at the project-lock callback and require rejection before bound consumption; mutate an actual Slot/Capture/NS BodyArchive at a next sensitive callback and require rejection before payload/receipt consumption; mutate Stage Frozen/ExtractInput at a scope/approval callback and require rejection; confirm exact exception identity and graph inactive after failure. These are suggested checks, not claimed passes.
