from pathlib import Path
import ast,copy,difflib,hashlib,json
O=Path('/workspace/pb-cold-graph-integration-metrics-20261019/typed-pin-v1');R=Path('/workspace/Sim2Act')
names=['natural_live_admission.py','pa_trial_dispatch.py','natural_source_archives.py','production_trial_policy.py','natural_spec_runtime.py']
old={n:(R/'src/sim2act'/n).read_text() for n in names};new=dict(old)
def fns(n):return {f.name:f for f in ast.parse(new[n]).body if isinstance(f,ast.FunctionDef)}
def get(n,name):
 f=fns(n)[name];return ''.join(new[n].splitlines(True)[f.lineno-1:f.end_lineno])
def put(n,name,s):
 a=get(n,name);assert new[n].count(a)==1;new[n]=new[n].replace(a,s.rstrip()+'\n',1)
def repl(n,name,a,b):
 s=get(n,name);assert s.count(a)==1,(n,name,a[:80],s.count(a));put(n,name,s.replace(a,b))
def append(n,s):new[n]+='\n\n'+s.strip()+'\n'
append('natural_live_admission.py',(O/'leaves.py').read_text())
# Each strict closure compares its actual typed inputs after EVERY callee/IO.
setup={
'natural_live_admission.py':{
 '_graph_stage_current':['_graph_trial_contract_models(graph, store, c, _models, contract)','_graph_trial_stage_models(graph, store, c, _models, stage_facts)'],
 '_graph_run_context':['_graph_trial_contract_models(graph, store, c, _models, contract)','_graph_trial_stage_models(graph, store, c, _models, stage_facts)'],
 '_graph_stage_before_generation':['_graph_trial_contract_models(graph, store, c, _models, contract)'],
 '_graph_stage_before_accounting':['_graph_trial_contract_models(graph, store, c, _models, contract)','_graph_trial_frozen_models(graph, store, c, _models, frozen)'],
},
'pa_trial_dispatch.py':{
 '_graph_journal_state':['gate.require(b is graph.binding)'],
 '_graph_journal_chain':['gate.require(b is graph.binding)','gate._graph_trial_journal_models(graph, store, c, _models, state, cursor)'],
 '_graph_stage_accounted':['gate.require(b is graph.binding)','gate._graph_trial_journal_models(graph, store, c, _models, state, cursor)'],
 '_graph_pb_accounting':['gate.require(b is graph.binding)','gate._graph_trial_journal_models(graph, store, c, _models, state)'],
 '_graph_pb_archive_chain':['gate.require(b is graph.binding)','gate._graph_trial_journal_models(graph, store, c, _models, state)','gate._graph_trial_accounted_models(graph, store, c, _models, source_facts, "source")'],
},
'natural_source_archives.py':{
 '_graph_source_bodies':['gate._graph_trial_contract_models(graph, store, c, _models, contract)','gate._graph_trial_journal_models(graph, store, c, _models, ledger)','gate._graph_trial_accounted_models(graph, store, c, _models, source_facts, "source")'],
 '_graph_resolve_trial_source':['gate._graph_trial_contract_models(graph, store, c, _models, contract)','gate._graph_trial_journal_models(graph, store, c, _models, ledger)','gate._graph_trial_stage_models(graph, store, c, _models, source_stage_facts)','gate._graph_trial_accounted_models(graph, store, c, _models, source_facts, "source")','gate._graph_trial_extraction_models(graph, store, c, _models, extraction_facts)'],
},
'production_trial_policy.py':{'_graph_check_run':['gate._graph_trial_contract_models(graph, store, c, _models, contract)','gate._graph_trial_stage_models(graph, store, c, _models, stage_facts)']}}
for n,fs in setup.items():
 for name,calls in fs.items():
  f=ast.parse(get(n,name)).body[0];guard=next(x for x in f.body if isinstance(x,ast.FunctionDef) and x.name=='_guard')
  # Save the exact base pin, then add one lexical typed input cohort. No resolver.
  guard.name='_parent_pin'
  where=f.body.index(guard)
  factory='_trial_typed_guard' if n=='natural_live_admission.py' else 'gate._trial_typed_guard'
  code='_models = []\n_guard = '+factory+'(_parent_pin, _models)'
  # archive imports gate inside its try, so factory creation stays just after that import.
  if n=='natural_source_archives.py':
   body=next(x for x in f.body if isinstance(x,ast.Try)).body
   at=next(i for i,x in enumerate(body) if isinstance(x,ast.ImportFrom) and any(a.name=='natural_live_admission' for a in x.names))+1
   body[at:at]=ast.parse(code).body
  else:f.body[where+1:where+1]=ast.parse(code).body
  body=next(x for x in f.body if isinstance(x,ast.Try)).body
  # Add setup immediately after the first exact graph pin, before inputs/SQL use.
  at=next(i for i,x in enumerate(body) if isinstance(x,ast.Expr) and isinstance(x.value,ast.Call) and (x.value.func.id if isinstance(x.value.func,ast.Name) else x.value.func.attr if isinstance(x.value.func,ast.Attribute) else None)=='_graph_trial_pin')+1
  body[at:at]=ast.parse('\n'.join(calls)+'\n_guard()').body
  # Final explicit base-only checks become the same typed guard before escape.
  for x in body[at+len(calls)+1:]:
   if isinstance(x,ast.Expr) and isinstance(x.value,ast.Call) and (x.value.func.id if isinstance(x.value.func,ast.Name) else x.value.func.attr if isinstance(x.value.func,ast.Attribute) else None)=='_graph_trial_pin':x.value=ast.Call(func=ast.Name('_guard',ast.Load()),args=[],keywords=[])
  ast.fix_missing_locations(f);put(n,name,ast.unparse(f)+'\n')

# All explicit nested checkpoints in strict bodies use the same typed cohort;
# only the fixed _parent_pin implementation calls the raw exact-CGR pin.
for n,fs in setup.items():
 for name in fs:
  f=ast.parse(get(n,name)).body[0]
  protected=next(x for x in f.body if isinstance(x,ast.Try))
  class EveryPin(ast.NodeTransformer):
   def visit_Call(self,node):
    node=self.generic_visit(node)
    callee=node.func.id if isinstance(node.func,ast.Name) else node.func.attr if isinstance(node.func,ast.Attribute) else None
    if callee=='_graph_trial_pin':return ast.copy_location(ast.Call(func=ast.Name('_guard',ast.Load()),args=[],keywords=[]),node)
    return node
  EveryPin().visit(protected);ast.fix_missing_locations(f);put(n,name,ast.unparse(f)+'\n')

# Full raw Stage tuple views stay linked to canonical nodes at every boundary.
for file,func,param in [('natural_live_admission.py','_graph_stage_current','stage_facts'),
 ('natural_live_admission.py','_graph_run_context','stage_facts'),
 ('natural_source_archives.py','_graph_resolve_trial_source','source_stage_facts'),
 ('production_trial_policy.py','_graph_check_run','stage_facts')]:
 f=ast.parse(get(file,func)).body[0]
 parent=next(node for node in f.body if isinstance(node,ast.FunctionDef) and node.name=='_parent_pin')
 prefix='' if file=='natural_live_admission.py' else 'gate.'
 parent.body += ast.parse(prefix+'_graph_trial_stage_raw(graph, '+param+')').body
 if file=='natural_source_archives.py':
  parent.body += ast.parse("gate.require(source_proof is graph.inputs['cold-trial:complete']['source_proof'])").body
 ast.fix_missing_locations(f);put(file,func,ast.unparse(f)+'\n')

# Hold models returned by complete original producers before any following callee.
def after_assignment(n,name,target,code):
 f=ast.parse(get(n,name)).body[0]
 class Add(ast.NodeTransformer):
  def visit_Assign(self,node):
   node=self.generic_visit(node)
   found=any((isinstance(t,ast.Name) and t.id==target) or (isinstance(t,ast.Tuple) and any(isinstance(e,ast.Name) and e.id==target for e in t.elts)) for t in node.targets)
   if found:return [node]+ast.parse(code).body
   return node
 f=Add().visit(f);ast.fix_missing_locations(f);put(n,name,ast.unparse(f)+'\n')
P='gate._graph_trial_produced(graph, store, c, _models, '
G='_graph_trial_produced(graph, store, c, _models, '
for name in ['_graph_stage_current','_graph_run_context','_graph_stage_before_accounting']:
 if name=='_graph_stage_current':
  after_assignment('natural_live_admission.py',name,'approval',G+'Approval, approval)')
  continue
 if name=='_graph_run_context':
  after_assignment('natural_live_admission.py',name,'approval',G+'Approval, approval)')
  after_assignment('natural_live_admission.py',name,'accepted',G+'StageApproveInput, accepted)')
  after_assignment('natural_live_admission.py',name,'phase',G+'StageAuthority, phase)')
 else:after_assignment('natural_live_admission.py',name,'approval',G+'Approval, approval)')
after_assignment('natural_live_admission.py','_graph_stage_current','accepted',G+'StageApproveInput, accepted)')
# Stage-current new Authority is consumed only after constructor result pins; add local typed pin before return.
after_assignment('natural_live_admission.py','_graph_stage_current','authority',G+'StageAuthority, authority)')
for name in ['_graph_journal_chain']:
 after_assignment('pa_trial_dispatch.py',name,'scope',P+'budget.Scope, scope)')
 after_assignment('pa_trial_dispatch.py',name,'expected',P+'gate.PBTrialContract, original)\n'+P+'policy.evidence.EvidenceRequirements, expected)')
 after_assignment('pa_trial_dispatch.py',name,'approval',P+'gate.Approval, approval)')
 after_assignment('pa_trial_dispatch.py',name,'phase',P+'gate.StageApproveInput, phase)')
 after_assignment('pa_trial_dispatch.py',name,'capture',P+'sender.Capture, capture)')
after_assignment('pa_trial_dispatch.py','_graph_stage_accounted','chain','from . import production_trial_policy as policy\nfrom . import production_trial_sender as sender\n'+P+'policy.Slot, chain[0])\n'+P+'sender.Capture, chain[1])')
after_assignment('pa_trial_dispatch.py','_graph_stage_accounted','request',P+'archive.BodyArchive, request)')
after_assignment('pa_trial_dispatch.py','_graph_stage_accounted','body',P+'archive.BodyArchive, body)')
for name in ['_graph_resolve_trial_source']:
 after_assignment('natural_source_archives.py',name,'approval',P+'gate.Approval, approval)')
 after_assignment('natural_source_archives.py',name,'current',P+'gate.StageAuthority, current)')
 after_assignment('natural_source_archives.py',name,'accepted',P+'gate.StageApproveInput, accepted)')
after_assignment('production_trial_policy.py','_graph_check_run','expected',P+'gate.PBTrialContract, original)\n'+P+'evidence.EvidenceRequirements, expected)')
after_assignment('production_trial_policy.py','_graph_check_run','phase',P+'gate.Approval, approval)\n'+P+'gate.StageAuthority, phase)')

# Original shared readers retain sealed complete raw bodies through their own callbacks.
n='natural_live_admission.py'
f=ast.parse(get(n,'_saved')).body[0]
# Place after pair return and its original parent callback, before model_dump/fingerprint.
f.body[1:1]=ast.parse("if _guard is not None:\n    _guard = _trial_typed_guard(_guard, [(model, body, response)])\n    _guard()").body
ast.fix_missing_locations(f);put(n,'_saved',ast.unparse(f)+'\n')
n='natural_source_archives.py';f=ast.parse(get(n,'_read')).body[0]
for i,x in enumerate(f.body):
 if isinstance(x,ast.Assign) and any(isinstance(t,ast.Tuple) and any(isinstance(e,ast.Name) and e.id=='body' for e in t.elts) for t in x.targets):
  f.body[i+1:i+1]=ast.parse("if _guard is not None:\n    _guard = gate._trial_typed_guard(_guard, [(BodyArchive, body, saved)])\n    _guard()").body;break
ast.fix_missing_locations(f);put(n,'_read',ast.unparse(f)+'\n')
n='pa_trial_dispatch.py';f=ast.parse(get(n,'_journal_body_from_facts')).body[0]
for i,x in enumerate(f.body):
 if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='body' for t in x.targets):
  f.body[i+1:i+1]=ast.parse("if _guard is not None:\n    _guard = gate._trial_typed_guard(_guard, [(BodyArchive, body, saved['response'])])\n    _guard()").body;break
ast.fix_missing_locations(f);put(n,'_journal_body_from_facts',ast.unparse(f)+'\n')
# _journal_stage_header's Source phase persists across owned scope and app-key IO.
f=ast.parse(get(n,'_journal_stage_header')).body[0]
class Header(ast.NodeTransformer):
 def visit_Assign(self,node):
  if any(isinstance(t,ast.Name) and t.id=='phase' for t in node.targets):
   return [node]+ast.parse("if _guard is not None:\n    value = gate.StageApproveInput.model_dump(phase)\n    _guard()\n    _guard = gate._trial_typed_guard(_guard, [(gate.StageApproveInput, phase, value)])\n    _guard()").body
  return self.generic_visit(node)
f=Header().visit(f);ast.fix_missing_locations(f);put(n,'_journal_stage_header',ast.unparse(f)+'\n')

# Complete producers own their full raw pin BEFORE handing mutable typed results back.
n='pa_trial_dispatch.py'
repl(n,'_graph_journal_state',"        return value\n", "        state, cursor, revision = value\n        from . import production_trial_policy as policy\n        ledger_raw = gate._graph_trial_produced(graph, store, c, _models, policy.Ledger, state)\n        cursor_raw = gate._graph_trial_produced(graph, store, c, _models, policy.AccountQuotaCursor, cursor)\n        completed_raw = dict(ledger=ledger_raw, cursor=cursor_raw, revision=revision)\n        if 'cold-trial:journal' in graph.inputs:\n            gate.require(completed_raw == graph.inputs['cold-trial:journal'])\n        else:\n            graph.add('cold-trial:journal', completed_raw)\n        _guard()\n        return value\n")
repl(n,'_graph_stage_accounted',"        return (run, actual, tuple(chains), tuple(ns_reads))\n", "        completed_value = (run, actual, tuple(chains), tuple(ns_reads))\n        completed_raw = gate._graph_trial_accounted_raw(graph, store, c, completed_value, _models)\n        key = 'cold-trial:accounted-' + stage\n        if key in graph.inputs:\n            gate.require(completed_raw == graph.inputs[key])\n        else:\n            graph.add(key, completed_raw)\n        _guard()\n        return completed_value\n")

# Runtime changes stay strictly within root's new coordinator class.
n='natural_spec_runtime.py';tree=ast.parse(new[n]);cl=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='_ColdTrialGraph')
ls=new[n].splitlines(True);a=''.join(ls[cl.lineno-1:cl.end_lineno]);cc=ast.parse(a).body[0]
methods={m.name:m for m in cc.body if isinstance(m,ast.FunctionDef)}
# The complete node records the actual Cold Run object once, without copying bodies.
fields_return=next(node for node in methods['_fields'].body if isinstance(node,ast.Return))
assert isinstance(fields_return.value,ast.Call)
fields_return.value.keywords.append(ast.keyword(arg='cold_job',value=ast.parse('self.cold_stage_facts[0]',mode='eval').body))
methods['_base'].body+=ast.parse("self._typed_parameters()").body
# A direct pre-completion _base failure is sticky too; no unknown cleanup hook.
methods['_base'].body=[ast.Try(body=methods['_base'].body,
    handlers=ast.parse("try:\n    pass\nexcept BaseException:\n    if type(self.guard) is _ColdGraphRead:\n        _ColdGraphRead.invalidate(self.guard)\n    self.phase = 'INVALID'\n    raise").body[0].handlers, orelse=[], finalbody=[])]
newmethod=ast.parse('''def _typed_parameters(self):
    from . import natural_live_admission as gate
    from . import pb_natural_specs as pb
    from . import pb_natural_uses as use
    from . import production_trial_policy as policy
    from .contracts import AppManifest, FrozenRunContract, GoalCardRunSource
    g, store, c, models = self.guard, self.worker.store, self.c, []
    if self.journal is not None and 'cold-trial:journal' in g.inputs:
        gate._graph_trial_journal_models(g, store, c, models, self.journal[0], self.journal[1])
    if self.source_accounted is not None and 'cold-trial:accounted-source' in g.inputs:
        gate._graph_trial_accounted_models(g, store, c, models, self.source_accounted, 'source')
    if self.generate_accounted is not None and 'cold-trial:accounted-generate' in g.inputs:
        gate._graph_trial_accounted_models(g, store, c, models, self.generate_accounted, 'generate')
    if self.trial is not None:
        t = self.trial
        raw = g.inputs[t.generation_reader.source_record_name]['contract']
        gate._graph_trial_hold(g, store, c, models, FrozenRunContract, t.generation_contract, raw)
        gate._graph_trial_hold(g, store, c, models, pb.ExtractInput,
            t.extraction_prefix.body, g.inputs[t.extraction_prefix.key]['body'])
        gate._graph_trial_hold(g, store, c, models, GoalCardRunSource,
            t.extraction_review.goal, g.inputs[t.extraction_review.key]['goal'])
        gate._graph_trial_hold(g, store, c, models, use.CommitInput,
            t.use_prefix.body, g.inputs[t.use_prefix.key]['request'])
        gate._graph_trial_hold(g, store, c, models, GoalCardRunSource,
            t.use_review.value[2], g.inputs[t.use_review.prefix.key + ':review']['goal'])
        gate._graph_trial_hold(g, store, c, models, AppManifest,
            t.use_value[1], g.inputs[t.use_prefix.key + ':bound']['manifest'])
        for release in (t.release, t.source_release):
            gate._graph_trial_hold(g, store, c, models, AppManifest,
                release.origin[0], g.inputs[release.key]['origin']['manifest'])
    if self.cold_stage_facts is not None and 'cold-trial:complete' in g.inputs:
        gate._graph_trial_stage_raw(g, self.cold_stage_facts)
        gate._graph_trial_stage_models(g, store, c, models, self.cold_stage_facts)
    if self.source_stage_facts is not None and 'cold-trial:complete' in g.inputs:
        gate._graph_trial_stage_raw(g, self.source_stage_facts)
        gate._graph_trial_stage_models(g, store, c, models, self.source_stage_facts)
    if self.sealed_fields is not None:
        require(self.source_proof is g.inputs['cold-trial:complete']['source_proof'])
    if 'cold-trial:admission-prefix' in g.inputs:
        gate._graph_trial_hold(g, store, c, models, gate.PBTrialContract,
            self.original, g.inputs['cold-trial:admission-prefix']['original'])
        gate._graph_trial_hold(g, store, c, models, policy.evidence.EvidenceRequirements,
            self.expected, g.inputs['cold-trial:admission-prefix']['expected'])
    if self.live_source is not None:
        require(self.source_record is g.inputs[self.source_record_key])
        gate._graph_trial_hold(g, store, c, models, policy.SourceVerificationResult,
            self.live_source, self.source_record)
    if self.context_record is not None:
        gate._graph_trial_hold(g, store, c, models, policy.RunCheck,
            self.context, self.context_record)
    gate._graph_trial_models_pin(g, store, c, models)
''').body[0]
cc.body.insert(cc.body.index(methods['_base'])+1,newmethod)
# Fresh source observations are actual scalar evidence, not copied semantic bodies.
methods['__init__'].body[0].body += ast.parse('self.live_source = self.source_record = self.source_record_key = None\nself.current_boundary = None').body
cc.body[1:1]=ast.parse('live_source: Any\nsource_record: Any\nsource_record_key: Any\ncurrent_boundary: Any').body
source_method=ast.parse('''def _source_value(self, value):
    from . import production_trial_policy as policy
    require(type(value) is policy.SourceVerificationResult)
    raw = policy.SourceVerificationResult.model_dump(value)
    self._base()
    key = self.current_boundary + ':source-observation'
    self.guard.add(key, raw)
    self.live_source, self.source_record, self.source_record_key = value, raw, key
    self._base()
''').body[0]
cc.body.insert(cc.body.index(methods['_base'])+2,source_method)
# Only the live final result, not unused earlier entitlement returns, is consumed.
for method_name in ['_recheck','commit']:
 method=methods[method_name]
 class FreshSource(ast.NodeTransformer):
  def visit_Assign(self,node):
   if any(isinstance(t,ast.Name) and t.id=='source' for t in node.targets) and isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Attribute) and node.value.func.attr=='_journal_source':
    return [node]+ast.parse('self._source_value(source)').body
   return self.generic_visit(node)
 FreshSource().visit(method)
commit_try=methods['commit'].body[-1]
assert isinstance(commit_try,ast.Try)
# The actual prefix already exists in the exact graph before this assignment.
commit_try.body.insert(1,ast.parse('self.current_boundary = prefix.key').body[0])
# The producer registered each exact raw node already, so don't add it twice.
prepare=methods['_prepare']
class Registration(ast.NodeTransformer):
 def visit_Expr(self,node):
  if isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Attribute) and node.value.func.attr=='add' and node.value.args and isinstance(node.value.args[0],ast.Constant) and node.value.args[0].value in {'cold-trial:journal','cold-trial:accounted-source','cold-trial:accounted-generate'}:
   key=node.value.args[0].value
   comparison=ast.Compare(left=node.value.args[1],ops=[ast.Eq()],comparators=[ast.Subscript(value=ast.Attribute(value=ast.Name('g',ast.Load()),attr='inputs',ctx=ast.Load()),slice=ast.Constant(key),ctx=ast.Load())])
   return ast.Expr(ast.Call(func=ast.Name('require',ast.Load()),args=[comparison],keywords=[]))
  return self.generic_visit(node)
Registration().visit(prepare)
# Completion of the full raw graph is sealed once, before Stage Authority.
# Sealing is a continuity anchor only; the first commit still executes every
# original Stage/SourceArchive/Grant/freshness edge before successful return.
class SealRaw(ast.NodeTransformer):
 def visit_Expr(self,node):
  if isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Attribute) and node.value.func.attr=='add' and node.value.args and isinstance(node.value.args[0],ast.Constant) and node.value.args[0].value=='cold-trial:complete':
   return ast.parse("complete_raw = self._fields()\ng.add('cold-trial:complete', complete_raw)\nself.sealed_fields = complete_raw").body
  return self.generic_visit(node)
SealRaw().visit(prepare)
# Equal semantic Limits still pass the trial role's original fresh scope gate.
for node in ast.walk(prepare):
 if isinstance(node,ast.If) and ast.unparse(node.test)=='self.platform is None':
  node.orelse=ast.parse('self.trial = _cold_trial_binding(worker, c, self.platform, limits)').body
# Replace only the raw-record continuity branch, retaining every later live edge.
check=methods['check']
for node in ast.walk(check):
 if isinstance(node,ast.If) and ast.unparse(node.test)=="self.trial is not None and self.phase in {'COMPLETE', 'BUSY'}":
  node.body=ast.parse("require(self.sealed_fields is self.guard.inputs['cold-trial:complete'])\nif self.authority_fields is not None:\n    require(self.authority_fields is self.guard.inputs['cold-trial:semantic-authorities'] and self.cold_authority is self.authority_fields['cold'] and self.source_authority is self.authority_fields['source'])").body
# Lexical current-return cohorts survive the original later callbacks. They
# carry no semantic permission and never reparse or reread an earlier node.
prepare=methods['_prepare']
for i,node in enumerate(prepare.body):
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='pin' for t in node.targets):
  prepare.body[i:i+1]=ast.parse('_models = []\npin = gate._trial_typed_guard(self._base, _models)').body
  break
recheck=methods['_recheck']
for i,node in enumerate(recheck.body):
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Tuple) and any(isinstance(v,ast.Name) and v.id=='pin' for v in t.elts) for t in node.targets):
  recheck.body[i:i+1]=ast.parse("user = job['principal_id']\n_models = []\npin = gate._trial_typed_guard(self.check, _models)").body
  break
commit=methods['commit']
commit_try=next(node for node in commit.body if isinstance(node,ast.Try))
class LocalCommitPin(ast.NodeTransformer):
 def visit_Attribute(self,node):
  if isinstance(node.value,ast.Name) and node.value.id=='self' and node.attr=='check':
   return ast.copy_location(ast.Name('pin',ast.Load()),node)
  return self.generic_visit(node)
LocalCommitPin().visit(commit_try)
commit.body[commit.body.index(commit_try):commit.body.index(commit_try)]=ast.parse('_models = []\npin = gate._trial_typed_guard(self.check, _models)').body
class LocalReturns(ast.NodeTransformer):
 def __init__(self, mapping):self.mapping=mapping
 def visit_Assign(self,node):
  node=self.generic_visit(node)
  targets=[]
  for t in node.targets:
   if isinstance(t,ast.Name):targets.append(t.id)
   elif isinstance(t,ast.Tuple):targets += [v.id for v in t.elts if isinstance(v,ast.Name)]
  lines=[]
  for target,expected in self.mapping.items():
   if target in targets:
    lines.append('gate._graph_trial_produced(self.guard, self.worker.store, self.c, _models, '+expected+', '+target+')')
  return [node]+ast.parse('\n'.join(lines)).body if lines else node
LocalReturns({'original':'gate.PBTrialContract','expected':'policy.evidence.EvidenceRequirements',
    'inner':'gate.Approval','accepted':'gate.StageApproveInput',
    'entitlement':'policy.SourceVerificationResult'}).visit(prepare)
LocalReturns({'original':'gate.PBTrialContract','expected':'policy.evidence.EvidenceRequirements',
    'approval':'gate.Approval','accepted':'gate.StageApproveInput',
    'source_phase':'gate.StageApproveInput','source':'policy.SourceVerificationResult',
    'frozen':'contracts.FrozenRunContract','declared':'Limits'}).visit(recheck)
# The original frozen helper result is a known FrozenRunContract. Avoid a new
# module import outside this coordinator method.
recheck.body.insert(1,ast.ImportFrom(module='contracts',names=[ast.alias(name='FrozenRunContract')],level=1))
for node in ast.walk(recheck):
 if isinstance(node,ast.Attribute) and isinstance(node.value,ast.Name) and node.value.id=='contracts' and node.attr=='FrozenRunContract':
  node.value.id='__INVALID_CONTRACTS_ALIAS__'
class FrozenName(ast.NodeTransformer):
 def visit_Attribute(self,node):
  if isinstance(node.value,ast.Name) and node.value.id=='__INVALID_CONTRACTS_ALIAS__':return ast.copy_location(ast.Name('FrozenRunContract',ast.Load()),node)
  return self.generic_visit(node)
FrozenName().visit(recheck)
LocalReturns({'approval':'gate.Approval','phase':'gate.StageAuthority',
    'source_phase':'gate.StageApproveInput','final_frozen':'FrozenRunContract','manifest':'AppManifest'}).visit(commit_try)
commit.body.insert(1,ast.ImportFrom(module='contracts',names=[ast.alias(name='FrozenRunContract'),ast.alias(name='AppManifest')],level=1))
ast.fix_missing_locations(cc);b=ast.unparse(cc)+'\n';new[n]=new[n].replace(a,b,1)

# External evidence only; do not import product or run tests.
patch='';manifest={}
for n in names:
 ast.parse(new[n]);p=O/'candidate/src/sim2act'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(new[n])
 p=O/'baseline/src/sim2act'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(old[n])
 patch+=''.join(difflib.unified_diff(old[n].splitlines(True),new[n].splitlines(True),fromfile='a/src/sim2act/'+n,tofile='b/src/sim2act/'+n))
 manifest[n]=dict(base_sha256=hashlib.sha256(old[n].encode()).hexdigest(),candidate_sha256=hashlib.sha256(new[n].encode()).hexdigest())
# Only the coordinator is allowed to change in runtime.
a={x.name:ast.dump(x,include_attributes=False) for x in ast.parse(old['natural_spec_runtime.py']).body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
b={x.name:ast.dump(x,include_attributes=False) for x in ast.parse(new['natural_spec_runtime.py']).body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
assert set(a)==set(b) and all(a[n]==b[n] for n in a if n!='_ColdTrialGraph')
meta=dict(status='EXTERNAL_TYPED_CONTINUITY_CANDIDATE_NOT_APPLIED_NOT_EXECUTED',base_head='dc34ce4b1311810e27cd33a0cd156b6f84333666',files=manifest,patch_bytes=len(patch.encode()),patch_sha256=hashlib.sha256(patch.encode()).hexdigest(),runtime_only_coordinator_changed=True)
(O/'typed-pin.patch').write_text(patch);(O/'MANIFEST.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta,indent=2))
