def _trial_typed_classes():
    from . import natural_source_archives as archive
    from . import natural_trial_budget as budget
    from . import pb_natural_specs as pb
    from . import pb_natural_uses as use
    from . import production_trial_policy as policy
    from . import production_trial_sender as sender
    from .contracts import AppManifest, FrozenRunContract, GoalCardRunSource, Limits
    return (PBTrialContract, TrialContract, TrialContractV2, Approval,
        StageApproveInput, StageAuthority, StageAuthorityV2, MaterialGoal,
        AppManifest, FrozenRunContract, GoalCardRunSource, Limits, budget.Scope,
        pb.ExtractInput, use.CommitInput, use.ReviewInput, policy.Ledger,
        policy.AccountQuotaCursor, policy.Slot, policy.ReservationIdentity,
        policy.RunCheck, policy.SourceVerificationResult, policy.evidence.EvidenceRequirements, sender.Capture,
        archive.BodyArchive)


def _trial_typed_guard(parent, models):
    """Continuity of exact already-produced models; never parses or authorizes.

    models contains fixed (exact class, actual model, complete raw value) triples.
    Inbound triples use already pinned graph facts. Producer-local triples use
    the original full verifier's output, before any following callback/IO.
    """
    if parent is None:
        return None

    def checked():
        parent()
        allowed = _trial_typed_classes()
        require(type(models) is list)
        for expected, model, raw in models:
            require(any(expected is kind for kind in allowed) and type(model) is expected and type(raw) is dict,
                'Exact typed trial fact and complete raw pin required')
            # Exact fixed classes use the standard pure Pydantic serializer.
            # No IO or external callback occurs after the entry pin in this pass.
            value = expected.model_dump(model)
            require(value == raw, 'Typed trial fact changed after its complete raw proof')
    return checked


def _graph_trial_hold(graph, store, c, models, expected, model, raw):
    """Assemble one lexical parameter pin; caller checks the whole cohort."""
    require(type(models) is list and type(model) is expected and type(raw) is dict)
    if not any(kind is expected and actual is model and previous is raw
               for kind, actual, previous in models):
        models.append((expected, model, raw))


def _graph_trial_models_pin(graph, store, c, models):
    def parent():
        _graph_trial_pin(graph, store, c)
    try:
        _trial_typed_guard(parent, models)()
    except BaseException:
        from .natural_spec_runtime import _ColdGraphRead
        if type(graph) is _ColdGraphRead:
            _ColdGraphRead.invalidate(graph)
        raise


def _graph_trial_produced(graph, store, c, models, expected, model):
    """Freeze one newly returned original-verifier output before following IO."""
    def parent():
        _graph_trial_pin(graph, store, c)
    checked = _trial_typed_guard(parent, models)
    checked()
    # Exact type is checked before invoking a fixed class serialization method.
    require(any(expected is kind for kind in _trial_typed_classes()) and type(model) is expected)
    raw = expected.model_dump(model)
    checked()
    _graph_trial_hold(graph, store, c, models, expected, model, raw)
    checked()
    return raw


def _graph_trial_contract_models(graph, store, c, models, contract):
    _graph_trial_pin(graph, store, c)
    raw = PBTrialContract.model_dump(graph.binding.contract)
    _graph_trial_pin(graph, store, c)
    _graph_trial_hold(graph, store, c, models, PBTrialContract, contract, raw)


def _graph_trial_journal_models(graph, store, c, models, state, cursor=None):
    from . import production_trial_policy as policy
    _graph_trial_pin(graph, store, c)
    require('cold-trial:journal' in graph.inputs, 'Complete original J raw pin required')
    raw = graph.inputs['cold-trial:journal']
    _graph_trial_hold(graph, store, c, models, policy.Ledger, state, raw['ledger'])
    if cursor is not None:
        _graph_trial_hold(graph, store, c, models, policy.AccountQuotaCursor,
            cursor, raw['cursor'])


def _graph_trial_accounted_models(graph, store, c, models, value, stage):
    from . import natural_source_archives as archive
    from . import production_trial_policy as policy
    from . import production_trial_sender as sender
    _graph_trial_pin(graph, store, c)
    require(stage in ('source', 'generate'))
    key = 'cold-trial:accounted-' + stage
    require(key in graph.inputs, 'Complete accounted stage raw pin required')
    saved = graph.inputs[key]
    run, actual, chains, ns = value
    require(dict(run) == saved['run'] and tuple(dict(a) for a in actual) == saved['actual']
        and len(chains) == len(saved['chains']) and len(ns) == len(saved['ns_reads']))
    for chain, raw in zip(chains, saved['chains'], strict=True):
        slot, capture, parsed, checked, wire, payload = chain
        require(parsed == raw[2] and dict(checked) == raw[3]
            and wire == raw[4] and payload == raw[5])
        _graph_trial_hold(graph, store, c, models, policy.Slot, slot, raw[0])
        _graph_trial_hold(graph, store, c, models, sender.Capture, capture, raw[1])
    for entry, raw in zip(ns, saved['ns_reads'], strict=True):
        aid, request, wire, response, payload = entry
        require(aid == raw[0] and wire == raw[2] and payload == raw[4])
        _graph_trial_hold(graph, store, c, models, archive.BodyArchive, request, raw[1])
        _graph_trial_hold(graph, store, c, models, archive.BodyArchive, response, raw[3])


def _graph_trial_frozen_models(graph, store, c, models, frozen):
    from .contracts import FrozenRunContract
    _graph_trial_pin(graph, store, c)
    require('trial-generated-model-facet' in graph.inputs,
        'Complete native Generation facet raw pin required')
    raw = graph.inputs['trial-generated-model-facet']['frozen']
    _graph_trial_hold(graph, store, c, models, FrozenRunContract, frozen, raw)


def _graph_trial_extraction_models(graph, store, c, models, extraction):
    from . import pb_natural_specs as pb
    _graph_trial_pin(graph, store, c)
    require('cold-trial:complete' in graph.inputs)
    draft, body, target, goal = extraction
    raw = graph.inputs['cold-trial:complete']['extraction']
    require(draft == raw['draft'] and target == raw['target'] and goal == raw['goal'])
    _graph_trial_hold(graph, store, c, models, pb.ExtractInput, body, raw['request'])


def _graph_trial_stage_models(graph, store, c, models, stage_facts):
    _graph_trial_pin(graph, store, c)
    job, bound, raw, metadata, gen, frozen, generated, source, extraction = stage_facts
    _graph_trial_frozen_models(graph, store, c, models, frozen)
    _graph_trial_accounted_models(graph, store, c, models, generated, 'generate')
    if source is not None:
        _graph_trial_accounted_models(graph, store, c, models, source, 'source')
    if extraction is not None:
        _graph_trial_extraction_models(graph, store, c, models, extraction)


def _graph_trial_accounted_raw(graph, store, c, value, models):
    """One shared full serialization shape; contains every original body byte."""
    from . import natural_source_archives as archive
    from . import production_trial_policy as policy
    from . import production_trial_sender as sender
    run, actual, chains, ns = value
    full_chains, full_ns = [], []
    for slot, capture, parsed, checked, wire, payload in chains:
        a = _graph_trial_produced(graph, store, c, models, policy.Slot, slot)
        b = _graph_trial_produced(graph, store, c, models, sender.Capture, capture)
        full_chains.append((a, b, parsed, dict(checked), wire, payload))
    for aid, request, wire, response, payload in ns:
        a = _graph_trial_produced(graph, store, c, models, archive.BodyArchive, request)
        b = _graph_trial_produced(graph, store, c, models, archive.BodyArchive, response)
        full_ns.append((aid, a, wire, b, payload))
    return dict(run=dict(run), actual=tuple(dict(a) for a in actual),
        chains=tuple(full_chains), ns_reads=tuple(full_ns))


def _graph_trial_stage_raw(graph, stage_facts):
    """Actual Stage raw views retain the already pinned full producer objects."""
    require('cold-trial:complete' in graph.inputs)
    full = graph.inputs['cold-trial:complete']
    job, bound, raw, metadata, gen, frozen, generated, source, extraction = stage_facts
    if bound is full['binding']:
        require(dict(job) == dict(full['cold_job']) and source is not None
            and extraction is not None)
    else:
        require(bound is full['source_binding'] and dict(job) == full['source']['run']
            and source is None and extraction is None)
    require(raw is full['generation']['raw'] and metadata is full['generation']['metadata']
        and dict(gen) == full['generation']['run'])
    if extraction is not None:
        draft, body, target, goal = extraction
        saved = full['extraction']
        require(draft is saved['draft'] and target is saved['target'] and goal is saved['goal'])
