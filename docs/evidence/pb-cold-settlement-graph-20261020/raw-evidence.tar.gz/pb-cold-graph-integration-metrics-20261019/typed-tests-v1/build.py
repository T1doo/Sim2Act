from pathlib import Path
import ast,difflib,hashlib,json
R=Path('/workspace/Sim2Act')
O=Path('/workspace/pb-cold-graph-integration-metrics-20261019/typed-tests-v1')
path='tests/test_cold_trial_guard_delta.py'
old=(R/path).read_text()
new=old.replace('import copy\n','import base64\nimport copy\nimport hashlib\n',1)
new=new.replace('Draft only: not executed. Reuses existing local SQLite pin/release fixtures;', 'Reuses existing local SQLite pin/release fixtures;',1)
new=new.replace('from sim2act import natural_source_archives as archive\n','from sim2act import natural_source_archives as archive\nfrom sim2act import pa_trial_dispatch as dispatch\n',1)
new=new.replace('from sim2act import pb_natural_specs as pb\n','from sim2act import pb_natural_specs as pb\nfrom sim2act import production_trial_policy as policy\nfrom sim2act import production_trial_sender as sender\n',1)
needle="    monkeypatch.setattr(gate, '_approved', approved)\n"
extra="""    # This fixture isolates the original Run joins, not complete Stage proof.
    # New full-cohort boundaries use explicit stand-ins only in this test;
    # actual typed/raw drift is tested separately below without those stubs.
    monkeypatch.setattr(gate, '_graph_trial_stage_raw', lambda *a, **k: None)
    monkeypatch.setattr(gate, '_graph_trial_stage_models', lambda *a, **k: None)
    monkeypatch.setattr(gate, '_graph_trial_produced', lambda *a, **k: None)
"""
assert new.count(needle)==1
new=new.replace(needle,extra+needle,1)
new+= (O/'additions.py').read_text()
ast.parse(old);tree=ast.parse(new);compile(tree,str(O/path),'exec')
(O/'baseline/tests').mkdir(parents=True,exist_ok=True)
(O/'candidate/tests').mkdir(parents=True,exist_ok=True)
(O/'baseline'/path).write_text(old)
(O/'candidate'/path).write_text(new)
patch=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+path,tofile='b/'+path))
(O/'typed-tests.patch').write_text(patch)
functions={x.name:x for x in tree.body if isinstance(x,ast.FunctionDef)}
targets=[x for x in functions if x.startswith('test_') and x not in {f.name for f in ast.parse(old).body if isinstance(f,ast.FunctionDef)}]
meta=dict(status='EXTERNAL_TEST_CANDIDATE_NOT_APPLIED_NOT_EXECUTED',file=path,
 base_sha256=hashlib.sha256(old.encode()).hexdigest(),candidate_sha256=hashlib.sha256(new.encode()).hexdigest(),
 patch_bytes=len(patch.encode()),patch_sha256=hashlib.sha256(patch.encode()).hexdigest(),
 new_test_functions=targets,new_parameterized_cases=14,existing_wrong_run_cases_fixture_only=3,
 syntax_compile_without_execution=True,no_product_import_database_model_or_pytest_execution=True)
(O/'MANIFEST.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta,indent=2))
