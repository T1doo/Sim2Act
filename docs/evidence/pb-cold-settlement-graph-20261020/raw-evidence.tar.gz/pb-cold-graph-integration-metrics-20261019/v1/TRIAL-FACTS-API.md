# Four-file candidate: explicit complete trial facts

Status: external implementation candidate; not applied, imported or tested. Base `dc34ce4b1311810e27cd33a0cd156b6f84333666`. Root remains the only repository writer. `trial-facts.patch` modifies exactly production_trial_policy.py, pa_trial_dispatch.py, natural_source_archives.py and natural_live_admission.py. Candidate source copies are in `candidate-trial-facts/src/sim2act/`.

## Non-negotiable caller boundary

All `_graph_*` interfaces require the root's exact `natural_spec_runtime._ColdGraphRead`; `_graph_trial_pin` calls `type(graph) is _ColdGraphRead` and `graph.check(store,c)`. This proves continuity only. These interfaces do not validate a graph merely because it contains names. Root's single fixed producer must finish and register each full role node via its existing graph.add before feeding downstream data. These are private explicit data interfaces, not external DTOs, callbacks, permits or generic dynamic loaders.

No new interface accepts a StageAuthority DTO as evidence. `_graph_stage_current` constructs an Authority from full binding/Generate/accounting/extraction facts. `_graph_run_context` then performs the original approval/phase equality and fresh Run/time predicate. `_graph_resolve_trial_source` receives full Source stage facts plus the complete typed Source result proof and constructs the Source Authority internally. Paired StageApproveInput is read directly at the original permission position; it is P, not completed V.

Facts below must come from this graph's epoch. They must never be reused from G0 in G1 or a previous transaction. This candidate does not add an independent packet/cache/resolve registry: the root-owned fixed graph producer owns node completion, full role Limits, first-needed authorization order, no-reentry and per-epoch registration. It must invalidate on any producer/callback failure; there is no fallback.

## Concrete fixed data

`AccountedStage` is the actual return tuple from `_graph_stage_accounted`:

```
(full_Run,
 tuple(ordered_full_Attempt_rows),
 tuple((slot, capture, parsed_response, full_actual_Attempt, full_wire_bytes, full_response_bytes)),
 tuple((aid, NS_request_BodyArchive, NS_wire_bytes, NS_response_BodyArchive, NS_response_bytes)))
```

Generate has exactly 3 Attempts/chains and empty NS tuple; Source has exactly 2 Attempts/chains/NS reads. No dictionary keyed by aid is built before uniqueness is proved. The full J producer verifies the original ledger's uniqueness/reachability before a slot is selected; graph selection separately requires one matching slot and one matching chain/read/Attempt. `_graph_journal_chain` returns all bytes, not only digest metadata.

`ExtractionFacts` is `(owned_full_extraction_draft, original_typed_ExtractInput, full_target_material, full_Goal_identity_and_snapshot)`. Its upstream node must execute the complete pb.verify equivalent: META/EXTRACT pairs/seals, Recipe, Source success/proof/audit and inherited Limits, candidate/raw/source/Goal, declared manifest/actions and exact extraction keys. Merely reading the pair is insufficient.

`StageFacts` is exactly this **nine-position** tuple:

```
(job, complete_role_bound, Generate_candidate, Generate_metadata,
 Generate_job, Generate_frozen_contract, AccountedGenerate,
 AccountedSource_or_None_for_Source_stage, ExtractionFacts_or_None_for_Source_stage)
```

Generate_candidate/metadata must be outputs of the complete model-source equivalent for trial `_limits(contract)`, separately from platform/declared Limits facets. Complete role_bound must include original accepted Binding/Release/per-use effective candidate/input/clock/counters/plan/audit and all full origin proofs for that role; a public candidate hash is insufficient.

## New APIs and responsibility

| Function | Inputs and completed prerequisites | Actual work/output |
| --- | --- | --- |
| trial._graph_journal_state(graph,store,c,b) | fixed original Production PB binding; caller has first-needed owned scope | full original journal._context/_quota/_ledger; legacy mixing guard; returns `(Ledger,Cursor,revision)` once; not a source permit |
| trial._graph_pb_accounting(graph,store,c,b,generation,state) | actual owned Generate full row, complete J | fresh `_approved`, exact three production markers, fresh `_journal_source`, original five accepted Generate/Source prefix; returns actual source Run ID |
| trial._graph_journal_chain(graph,store,c,b,run,aid,state,cursor,raw=None) | complete J from same graph; exact current/ancestor role Run selected under its original scope | actual owner scalar checks; REQUEST then RESPONSE metadata/full pairs/seals/PA_TRIAL_BODY anchors; decode and compare full bodies; complete policy scope/wire/cursor binding; exact paired approval fingerprints; original capture full validation; actual Attempt/max_tokens/wire/fence/model checks; returns six-position chain above |
| trial._graph_stage_accounted(graph,store,c,b,state,cursor,rid,stage) | complete J; stage only Generate or successful Source | original stage ownership/phase/app-key gate; exactly 3/2 actual Attempts; precise production marker/account/key fingerprint; every actual chain once; exact known usage; Source NS byte equality and actual VERIFIED Operation; returns AccountedStage |
| gate._graph_stage_current(graph,store,c,user,contract,stage,StageFacts) | **complete full upstream nodes**, including G, binding role and AccountedGenerate; Cold additionally complete Source V/typed proof, AccountedSource and ExtractionFacts | actual family scope, current Instance/immutable Release pointers, full target, original Generate key/runtime/full Goal/frozen policy, extraction or generation origin, recipe, actual accounting cross-role comparisons, deadlines and actual authorization fingerprint; returns constructed `(Authority,job)`; never receives Authority as an input |
| archive._graph_source_bodies(graph,store,c,user,contract,ledger,AccountedSource) | Source V and J; complete NS reads produced by Source accounting | actual evidence-mode/key-set checks; exact multiset and full byte/raw/usage comparisons; returns `(tuple(request_bytes),tuple(response_bytes),public_attempts)` |
| archive._graph_resolve_trial_source(graph,store,c,user,contract,key,ledger,SourceStageFacts,complete_source_proof,AccountedSource,ExtractionFacts) | Source success/typed artifact/receipts and all extraction facets already fully proved | fresh approval; construct full Source stage from actual facts, compare paired original phase; exact extraction identity/key/Recipe/Source proof/material/full Goal; Source bytes; final actual scope/Grant rechecks/expiry; returns unchanged ResolvedSourceArchive shape |
| trial._graph_pb_archive_chain(graph,store,c,b,state,resolved,AccountedSource) | resolved Source archive and complete J + per-aid chains | Source slot/capture/public receipt fields plus exact original controller wire/response bytes equal NS bytes; no public receipt becomes authority |
| gate._graph_run_context(graph,store,c,user,contract,key,'cold',rid,version,fence,ColdStageFacts) | all Cold V dependencies complete in this graph | fresh `_approved`, exact original phase set/key, constructed Cold Authority equality, actual FOR UPDATE Run projection, original full `_require_run_context_row` at fresh time |
| policy._graph_check_run(graph,store,c,user,contract,key,'cold',rid,version,fence,worker_id,ColdStageFacts) | same as preceding row | full original requirements, preceding fresh context, actual worker owner and original RunCheck fields/deadline; no resolver or reusable permit |

The caller must complete Source V (full source binding/result/typed/artifact + reconstructed Source Authority + exact original accepted phase equality) before archive receipt, and complete Cold V (full current binding/per-use/origin/accounting + reconstructed Cold Authority + exact accepted phase equality) before returning the RunCheck or calling current business acceptance. There is no boolean proof input or `Authority` argument that can replace those nodes.

## Required root wiring order, not a new executor

Within the fixed eligible original G0 or G1 transaction:

1. Existing exact owned scalar/family/approval/Grant gates and root graph pin. Full J once at its original first-needed position; fresh source edge via `_graph_pb_accounting` remains actual.
2. Generate full frozen/raw history/candidate/confirmation under each original Limits facet; actual Generate chains/accounting. The accounting function does not replace the complete Generate semantic/protocol/history node.
3. Source complete Binding/Release, full Source receipts/result/typed/artifact and original audit, actual Source controller/NS/operation accounting. Then construct and compare the complete Source Authority. This is Source V, not paired phase P.
4. Extraction complete pb.verify-equivalent facts; graph source archive receipt and full NS/controller join. Explicit current Cold per-use material/Goal/candidate/origin/Binding and all current/prior Cold aid facts.
5. Construct complete Cold stage and policy RunCheck; original source/authority/stop/Grant/time edges remain fresh where existing ModelSettlementRead live/settle/tail calls require them. Existing five writes and all original consumer/final state checks remain root-owned; these helpers install no write path.

The root may avoid repeating pure cross-role comparisons by keeping completed graph facets, but may not pass a pair/hash as full binding/history/accounting. No call to public `bound`, `verify`, `model_source`, `journal_stage_accounted`, `_stage_current`, `_source_stage_current`, `_resolve_trial_source` or `_journal_chain` is made by these new graph data paths to fill missing nodes. `_journal_state` is intentionally the complete original non-recursive J producer, `_captured` the original same-aid body validator, and `_journal_source` the mandatory fresh source edge. Public/default execution remains on its original path.

## Shared extracted original predicates

Default functions still perform their SQL at the original positions. Shared leaves contain the original statement bodies:

- policy.check_run result fields -> `_run_check_from_facts` (worker/Generate-context checks stay before it).
- `_journal_owner` predicate -> `_journal_owner_from_facts`.
- `_journal_slot` post-phase identity predicate -> `_journal_slot_identity_from_facts`.
- `_journal_chain` original body decoder -> `_journal_body_from_facts`; capture and canonical/raw comparisons -> `_journal_capture_from_facts` / `_journal_canonical_from_facts`.
- journal_stage_accounted original owner/phase/key prefix -> `_journal_stage_header`; no SQL moved across actual Attempt loading.
- archive._source_bodies row-independent remainder -> `_source_bodies_from_rows`; row query remains first.
- archive._resolve_trial_source extraction target/proof predicate -> `_source_extraction_from_facts`, called at its old point.

Sender, reservation, receive/reject, TTL, other families, and existing `_generation_accounted` are unchanged. No Any, ignore, new Grant or permission bypass was added.

## Validation actually performed

- Stdlib AST parse of all four complete candidate files: PASS.
- `git -c core.fsmonitor=false apply --check trial-facts.patch`: PASS against the actual repository at generation time. This does not apply the patch.
- No import of sim2act, DB operation, model request, HTTP request, unit/integration test, full chain, commit or push.

Remaining: root must inspect the tuple/graph ownership contracts, integrate with the actual role producers, run bounded static/type checks and independently review before any exactly-once full-chain qualification. AST/apply success proves syntax and patch shape, not correct or fast product behavior.
