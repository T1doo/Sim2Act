# Default scope binding compatibility candidate

External candidate only. Nothing has been applied to the repository or executed as product, DB, model, pytest or network work.

`default-bind.patch` changes only the existing three public scope dispatchers and their existing controlled default wrappers to fixed `*args, **kwargs` forwarding, matching `spec.target`. Default argument binding now occurs inside the existing `@controlled` wrapper. Missing/extra arguments map to the original VERSION_CONFLICT/Malformed persisted DeliveryGraph binding before entering the core body. The strict spec paths retain exact-CGR invalidation plus the original bare raise; the use strict path retains its original core cleanup. Every core signature/body, target and permission/order predicate is AST unchanged. No selector, invocation helper, blanket strict exception mapping or new function was introduced.

`default-bind-tests.patch` adds one tiny standalone file with six cases: three public entries times missing/extra positional arguments. Explicit fixed-arity body tripwires preserve actual Python pre-body argument binding; each case expects the original controlled error and zero core-body entries. No DB/Worker/model fixture is used. Existing strict guard identity coverage is not repeated.

## Inputs and checks

Observed HEAD: `dc34ce4b1311810e27cd33a0cd156b6f84333666`. Candidate inputs are raw current source snapshots, not an old bundle.

- pa_spec_apps.py baseline SHA256: `215964dbb1437e78bed2c31e277c967e2ab21751dc723e912b149acb630d1b62`
- pb_natural_uses.py baseline SHA256: `b4319f3d6baeb8df176113775236a4f9595a23805608223c8e04e06e9ad3e5d3`
- Product patch SHA256: `a1e8d496d2ef12847fa67b08e6102ed3cb3341fc6d1503a45e839d121288ab54` (3135 bytes)
- Test patch SHA256: `590fc64ae7ea7d583dba45e70c38505cfb3c91eb43a6bcbfe020d8747f6acd62` (1751 bytes)

Both patches passed `git apply --check` separately against these current inputs. AST/syntax compilation passed without executing code. `STATIC-CHECKS.json` records source continuity and unchanged cores. The test target is `tests/test_cold_scope_default_binding.py::test_default_scope_argument_binding_keeps_original_controlled_error_before_core_body` (six parameter cases). Root remains the sole repository writer and test runner. No runtime pass is claimed.
