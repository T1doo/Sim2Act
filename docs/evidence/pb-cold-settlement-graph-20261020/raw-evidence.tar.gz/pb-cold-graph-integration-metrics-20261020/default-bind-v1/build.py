from pathlib import Path
import ast,difflib,hashlib,json
R=Path('/workspace/Sim2Act');O=Path('/workspace/pb-cold-graph-integration-metrics-20261020/default-bind-v1')
names=['pa_spec_apps.py','pb_natural_uses.py'];old={n:(R/'src/sim2act'/n).read_text() for n in names};new=dict(old)
def replace(name,func,text):
 global new
 source=new[name];node=next(x for x in ast.parse(source).body if isinstance(x,ast.FunctionDef) and x.name==func)
 start=min([node.lineno]+[d.lineno for d in node.decorator_list])-1
 previous=''.join(source.splitlines(True)[start:node.end_lineno]);assert source.count(previous)==1
 new[name]=source.replace(previous,text.strip()+'\n',1)
for public,core in [('scope_gate','_scope_gate_core'),('job_scope_gate','_job_scope_gate_with_authorities')]:
 replace('pa_spec_apps.py',public,f'''def {public}(*args, **kwargs):
    guard = kwargs.get("_graph_read")
    if guard is None:
        return _{public}_default(*args, **kwargs)
    try:
        return {core}(*args, **kwargs)
    except BaseException:
        from .natural_spec_runtime import _ColdGraphRead
        if type(guard) is _ColdGraphRead:
            _ColdGraphRead.invalidate(guard)
        raise''')
 replace('pa_spec_apps.py','_'+public+'_default',f'''@controlled
def _{public}_default(*args, **kwargs):
    return {core}(*args, **kwargs)''')
replace('pb_natural_uses.py','scope_gate','''def scope_gate(*args, **kwargs):
    if kwargs.get("_graph_read") is None:
        return _scope_gate_default(*args, **kwargs)
    return _scope_gate(*args, **kwargs)''')
replace('pb_natural_uses.py','_scope_gate_default','''@controlled
def _scope_gate_default(*args, **kwargs):
    return _scope_gate(*args, **kwargs)''')
patch='';manifest={};changed={}
for name in names:
 tree=ast.parse(new[name]);compile(tree,'external default-bind '+name,'exec')
 a={x.name:ast.dump(x,include_attributes=False) for x in ast.parse(old[name]).body if isinstance(x,(ast.FunctionDef,ast.ClassDef))};b={x.name:ast.dump(x,include_attributes=False) for x in tree.body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
 assert set(a)==set(b)
 expected={'scope_gate','_scope_gate_default'} | ({'job_scope_gate','_job_scope_gate_default'} if name=='pa_spec_apps.py' else set())
 assert {n for n in a if a[n]!=b[n]}==expected
 changed[name]=sorted(expected)
 for folder,text in [('baseline',old[name]),('candidate',new[name])]:
  p=O/folder/'src/sim2act'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
 patch+=''.join(difflib.unified_diff(old[name].splitlines(True),new[name].splitlines(True),fromfile='a/src/sim2act/'+name,tofile='b/src/sim2act/'+name))
 manifest[name]=dict(base_sha256=hashlib.sha256(old[name].encode()).hexdigest(),candidate_sha256=hashlib.sha256(new[name].encode()).hexdigest())
(O/'default-bind.patch').write_text(patch)
meta=dict(status='EXTERNAL_CANDIDATE_NOT_APPLIED_NOT_EXECUTED',files=manifest,changed_functions=changed,
 patch_bytes=len(patch.encode()),patch_sha256=hashlib.sha256(patch.encode()).hexdigest(),
 core_signatures_and_bodies_AST_unchanged=True,syntax_compile_without_execution=True,
 product_or_database_or_model_or_pytest_executed=False)
(O/'MANIFEST.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta,indent=2))
