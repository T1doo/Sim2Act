from pathlib import Path
import ast,difflib,hashlib,json
O=Path('/workspace/pb-cold-graph-integration-metrics-20261020/default-bind-v1')
path='tests/test_cold_scope_default_binding.py';text=(O/'tests.py').read_text();tree=ast.parse(text);compile(tree,'external default-bind test','exec')
p=O/'candidate'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
patch=''.join(difflib.unified_diff([],text.splitlines(True),fromfile='/dev/null',tofile='b/'+path));(O/'default-bind-tests.patch').write_text(patch)
meta=dict(status='EXTERNAL_TEST_CANDIDATE_NOT_APPLIED_NOT_EXECUTED',file=path,
 patch_bytes=len(patch.encode()),patch_sha256=hashlib.sha256(patch.encode()).hexdigest(),
 target=path+'::test_default_scope_argument_binding_keeps_original_controlled_error_before_core_body',case_count=6,
 syntax_compile_without_execution=True,product_or_database_or_model_or_pytest_executed=False)
(O/'TEST-MANIFEST.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta,indent=2))
