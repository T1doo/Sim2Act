# Run receipt facts implementation patch

`implementation.patch` modifies only `natural_spec_runtime.py` counters/anchor/node/pending/ledger regions and `pa_spec_apps.py` receipts/verify-job regions. It does not activate the graph or modify settlement, bound, audit, Generate, live admission or commit guard. The repository was read only throughout this subtask.

Patch SHA-256: `9650a0dbe154aa52ad960b03d40841881ffde2597727a49de7ed8cbec9c14ffb` (41,560 bytes).

## API

```python
reader = runtime._cold_run_facts(store, c, job, guard)
rows = runtime._counters_from_facts(store, c, job, manifest, reader)
outputs, proved = spec._cold_receipts(
    store, c, job, binding, reader,
    pending_id=None, allow_pending=True,
)
binding, outputs, proved = spec._cold_verify_job_from_receipts(
    store, c, user, job, limits, binding, outputs, proved, reader,
)
digest = runtime._ledger_digest_from_facts(store, c, job, reader)
```

`runtime._prove_node_from_facts(store,c,job,binding,op,intent,action,reader)` and `_prove_pending_from_facts` share the complete original node/pending predicates. The receipt core calls them explicitly. Internal `reader.typed_rows(instance_id,app_run_id)` returns the complete rows already read by the successful verify tail; callers must still consume them only after full Source verification. `reader.attempt_rows(ledger=True)`, `ledger_reservations()` and `ledger_events()` are full raw rows, not digests or projected completeness claims.

The reader requires the exact `_ColdGraphRead`, Store, connection, and **same job object identity**. Use one reader per Run per guard epoch. Constructor pins the job only and issues zero SQL. A write, scope drift, role-input mutation or callback mutation invalidates the guard. No result survives the epoch or substitutes for authority, approval, source freshness, Run/fence/stop/lease/deadline checks.

The coordinator must first provide the complete bound value through its explicit facts path at the original bound position and call `_counters_from_facts` there. `_cold_receipts` requires that complete counter validation to have succeeded; it pins the complete bound input before receipt SQL. Node and pending inspections rerun all original counter predicates for the declared manifest facet. Every manifest facet pins full manifest and all six Limits. A reused raw read does not skip any of those predicates.

The verify tail accepts only exact binding/outputs/proved identities produced by this reader's completed `allow_pending=True, pending_id=None` receipt proof. It does not perform or replace bound validation. Its `user` must equal the actual job principal. The `limits` parameter matches the public verify API; complete validation of that facet remains the coordinator's bound prerequisite.

## Complete predicate coverage

- Counters: full Attempts ordered by original SQL, then ordinal; exact typed natural metadata; exact context keys and association; source/cold association stage; last request fingerprint; exact integer requests/repairs/reserved/tools; request/tool Limits; complete MODEL_RESERVED data multiset; unique/subset/status-exact NS IDs for all four anchor kinds; original row status and evidence mode; model identity; unique ordinal/op/step; exactly one reservation and original Run/time; full NS_RESERVED payload and complete reservation fingerprint; contiguous ordinals; complete model Operation IDs/cardinality. All are the single shared original body. Subsequent facets use raw rows and rerun the entire body.
- Verified model node: exactly one matching Attempt; status, intent, step, plan, created/deadline, typed run version and fence; exact full NS_SETTLED/Attempt fingerprint; exact raw response shape; strict raw JSON; original raw/canonical archive equality; original parse, returned model and checked usage; actual usage/model; actual step, complete messages and body wire; bytes/characters/hash/reserved token identity; exact NS_RECEIVED and reception fingerprint. Parsing and wire construction remain actual operations, not saved success DTOs.
- Pending node: exact matching Attempt/model-kind/no receipt; original intent/step/plan; no SPEC_STEP_VERIFIED for the pending op; exact STARTED and response/Operation states, or RECEIVED/REJECTED_KNOWN states; strict raw/canonical equality; original normalized usage/model; full NS_RECEIVED; full rejected anchor key set, Attempt fingerprint and op identity. No resend or success is authorized.
- Receipts: full Run Operation collection and duplicate-step/extra-step/cardinality checks; original missing predecessor order; actual intent reconstruction and original stored intent/fingerprint/tool; original pending/unknown behavior; output schema; full local effect for SAVE; **fresh authorized artifact read every invocation**; exact hash/content/format and verify_saved; actual pure/model result and absence of side effects; complete receipt reconstruction; exactly one complete STEP anchor and correct CLAIMED fence; exact actual tool count. Authorized read and other sensitive callee returns are checked before consuming their result or issuing the next read.
- Verify tail: complete original typed rows at the original position; original residue/complete/SUCCEEDED split; actual fresh `store.has_unknown`; complete statuses/errors/cancel flag and cardinality; recomputed output and schemas; full stored data/fingerprint/release/schema/version; actual AppRun output and complete result_ref; or original clean residue/progress/CLAIMED/STEP/WORKER_LOST/error states. SQL short-circuit positions are preserved.
- Ledger: full original Run metadata and context exclusions only; full Attempt, reservation and event rows with original ID ordering and exact original kinds. Full Run reservation/event queries remain necessary to detect extra rows; per-attempt or anchor projections are never treated as complete ledger collections.

No eager later-stage event/body queries were introduced. Association and evidence-mode metadata validators run at their original first-needed positions, complete once per epoch. Separate full anchor bodies, STEP anchors, intents, effects, typed rows and full ledger queries remain lazy. Default public wrappers call the shared original cores without facts and keep every original direct SQL AST and sequence. `static-checks.json` contains every original and shared `require` expression for inspection.

## Checks actually performed

- Python stdlib AST parse for both complete before/after files: PASS.
- Original direct `c.execute` query AST and sequence for all seven original functions versus their shared bodies: PASS.
- `git apply --check` against copied base and current repository: PASS.
- No product imports, product/DB execution, tests, Mock/real model calls, or network calls executed.

Runtime regression, type/lint checks, original first-error and drift/duplicate/raw-canonical/wire negative tests, independent review and any bounded full Mock integration run remain the root writer's gates. This patch alone is not a complete graph or P2-closure acceptance.
