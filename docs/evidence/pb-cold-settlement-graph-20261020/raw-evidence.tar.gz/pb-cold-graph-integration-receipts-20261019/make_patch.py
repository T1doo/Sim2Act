from pathlib import Path
import ast
import difflib
import hashlib
import json

ROOT = Path('/workspace/pb-cold-graph-integration-receipts-20261019')
BASE = ROOT / 'base/src/sim2act'
WORK = ROOT / 'work/src/sim2act'

reader = '''class _ColdRunFacts:
    """One exact Run's lazy raw reads in an existing Cold read epoch.

    Values are full original results, pinned individually when their original
    read position is first reached. This is neither a permit nor a resolver.
    No SQL, history body or event body is read by the constructor.
    """

    def __init__(self, store, c, job, guard):
        _cold_read_checkpoint(store, c, guard)
        require(type(guard) is _ColdGraphRead, "Exact Cold Run read scope required")
        self.store, self.connection, self.job, self.guard = store, c, job, guard
        self._origin_guard = guard
        self.key = f"run-facts:{job['id']}"
        self._raw: dict = {}
        self._receipt_proofs: list[str] = []
        self._manifests: list = []
        self._counter_proofs: list[str] = []
        guard.add(self.key, dict(job=job))
        self.check(store, c, job)

    def check(self, store, c, job):
        try:
            require(self.guard is self._origin_guard, "Cold Run read scope cannot be replaced")
            _cold_read_checkpoint(store, c, self.guard)
            require(self.store is store and self.connection is c and self.job is job
                and self.key == f"run-facts:{job['id']}"
                and self.guard.inputs[self.key]["job"] is job,
                "Cold Run raw facts changed identity")
            for manifest, name in self._manifests:
                require(manifest.model_dump() == self.guard.inputs[f"{self.key}:{name}"]["manifest"]
                    and manifest.runtime_limits is self.guard.inputs[f"{self.key}:{name}"]["limits"],
                    "Complete counter Limits facet changed")
        except BaseException:
            self.invalidate()
            raise

    def invalidate(self):
        if type(self._origin_guard) is _ColdGraphRead:
            self._origin_guard.invalidate()
        if self.guard is not self._origin_guard and type(self.guard) is _ColdGraphRead:
            self.guard.invalidate()

    def _present(self, name):
        self.check(self.store, self.connection, self.job)
        return name in self._raw

    def _get(self, name):
        self.check(self.store, self.connection, self.job)
        value = self._raw[name]
        require(self.guard.inputs[f"{self.key}:{name}"] is value,
            "Cold Run raw facts cannot be replaced")
        return value

    def _put(self, name, value):
        self.check(self.store, self.connection, self.job)
        require(name not in self._raw, "Cold Run raw facts cannot be rebound")
        self.guard.add(f"{self.key}:{name}", value)
        self._raw[name] = value
        return value

    def pin_manifest(self, manifest):
        from .contracts import AppManifest

        self.check(self.store, self.connection, self.job)
        require(type(manifest) is AppManifest and type(manifest.runtime_limits) is Limits)
        for current, name in self._manifests:
            if current is manifest:
                return name
        name = f"counter-manifest:{len(self._manifests)}"
        self._put(name, dict(manifest=manifest.model_dump(), limits=manifest.runtime_limits))
        self._manifests.append((manifest, name))
        return name

    def record_counters(self, manifest):
        name = "counter-proof:" + self.pin_manifest(manifest)
        if not self._present(name):
            self._put(name, dict(manifest=self.pin_manifest(manifest)))
            self._counter_proofs.append(name)

    def checked_counters(self):
        self.check(self.store, self.connection, self.job)
        require(bool(self._counter_proofs), "Original complete counter validation required")
        for name in self._counter_proofs:
            require(name.startswith("counter-proof:"))
            value = self._get(name)
            self._get(value["manifest"])

    def pin_receipt_binding(self, binding):
        name = f"receipt-binding:{len(self._receipt_proofs)}"
        if self._present(name):
            require(self._get(name) is binding)
        else:
            self._put(name, binding)

    def attempt_rows(self, *, ledger=False):
        if not self._present("attempts"):
            query = select(attempts).where(attempts.c.run_id == self.job["id"])
            query = query.order_by(attempts.c.id) if ledger else query.order_by(
                attempts.c.created_at, attempts.c.id)
            rows = self.connection.execute(query).mappings().all()
            self.check(self.store, self.connection, self.job)
            self._put("attempts", [dict(row) for row in rows])
        rows = self._get("attempts")
        # Never sort the pinned original result in place.
        return sorted(rows, key=(lambda row: row["id"]) if ledger else (
            lambda row: (row["created_at"], row["id"])))

    def association(self):
        from .natural_trial_runs import context_association

        if not self._present("association"):
            value = context_association(self.connection, self.job)
            self.check(self.store, self.connection, self.job)
            self._put("association", None if value is None else value.model_dump())
        return self._get("association")

    def mode(self):
        from .spec_production import evidence_mode

        if not self._present("mode"):
            value = evidence_mode(self.connection, self.job)
            self.check(self.store, self.connection, self.job)
            self._put("mode", value)
        return self._get("mode")

    def model_reserved(self):
        if not self._present("model-reserved"):
            rows = self.connection.execute(select(events.c.data).where(
                events.c.run_id == self.job["id"], events.c.kind == "MODEL_RESERVED"
            )).scalars().all()
            self.check(self.store, self.connection, self.job)
            self._put("model-reserved", rows)
        return self._get("model-reserved")

    def anchor_ids(self, kind):
        require(kind in {"NS_RESERVED", "NS_RECEIVED", "NS_SETTLED", "NS_REJECTED"})
        name = f"anchor-ids:{kind}"
        if not self._present(name):
            rows = self.connection.execute(select(events.c.data["attempt_id"].as_string()).where(
                events.c.run_id == self.job["id"], events.c.kind == kind
            )).scalars().all()
            self.check(self.store, self.connection, self.job)
            self._put(name, rows)
        return self._get(name)

    def reservation(self, aid):
        name = f"reservation:{aid}"
        if not self._present(name):
            rows = self.connection.execute(select(reservations).where(
                reservations.c.id == aid)).mappings().all()
            self.check(self.store, self.connection, self.job)
            self._put(name, [dict(row) for row in rows])
        return self._get(name)

    def anchor_rows(self, kind, aid):
        require(kind in {"NS_RESERVED", "NS_RECEIVED", "NS_SETTLED", "NS_REJECTED"})
        name = f"anchor:{kind}:{aid}"
        if not self._present(name):
            rows = self.connection.execute(select(events.c.data).where(
                events.c.run_id == self.job["id"], events.c.kind == kind,
                events.c.data["attempt_id"].as_string() == aid)).scalars().all()
            self.check(self.store, self.connection, self.job)
            self._put(name, rows)
        return self._get(name)

    def model_operations(self):
        if not self._present("model-operations"):
            rows = self.connection.execute(select(operations.c.id).where(
                operations.c.run_id == self.job["id"],
                operations.c.tool_ref.in_(codec.MODEL_KINDS))).scalars().all()
            self.check(self.store, self.connection, self.job)
            self._put("model-operations", rows)
        return self._get("model-operations")

    def receipt_operations(self):
        if not self._present("receipt-operations"):
            rows = self.connection.execute(select(operations).where(
                operations.c.run_id == self.job["id"])).mappings().all()
            self.check(self.store, self.connection, self.job)
            self._put("receipt-operations", [dict(row) for row in rows])
        return self._get("receipt-operations")

    def intent(self, oid):
        name = f"intent:{oid}"
        if not self._present(name):
            value = self.connection.execute(select(operation_intents.c.request).where(
                operation_intents.c.operation_id == oid)).scalar()
            self.check(self.store, self.connection, self.job)
            self._put(name, value)
        return self._get(name)

    def effect(self, oid):
        from .db import local_effects

        name = f"effect:{oid}"
        if not self._present(name):
            value = self.connection.execute(select(local_effects).where(
                local_effects.c.operation_id == oid)).mappings().first()
            self.check(self.store, self.connection, self.job)
            self._put(name, None if value is None else dict(value))
        return self._get(name)

    def has_effect(self, oid):
        from .db import local_effects

        name = f"has-effect:{oid}"
        if not self._present(name):
            value = self.connection.execute(select(local_effects.c.operation_id).where(
                local_effects.c.operation_id == oid)).first()
            self.check(self.store, self.connection, self.job)
            self._put(name, value is not None)
        return self._get(name)

    def pending_step(self, oid):
        name = f"pending-step:{oid}"
        if not self._present(name):
            value = self.connection.execute(select(events.c.id).where(
                events.c.run_id == self.job["id"], events.c.kind == "SPEC_STEP_VERIFIED",
                events.c.data["operation_id"].as_string() == oid)).first()
            self.check(self.store, self.connection, self.job)
            self._put(name, value is not None)
        return self._get(name)

    def step_anchors(self, oid):
        name = f"step-anchors:{oid}"
        if not self._present(name):
            rows = self.connection.execute(select(events.c.data).where(
                events.c.run_id == self.job["id"], events.c.kind == "SPEC_STEP_VERIFIED",
                events.c.data["operation_id"].as_string() == oid)).scalars().all()
            self.check(self.store, self.connection, self.job)
            self._put(name, rows)
        return self._get(name)

    def progress_event(self, kind, fence):
        require(kind in {"CLAIMED", "SPEC_STEP_VERIFIED", "WORKER_LOST"})
        name = f"progress:{kind}:{fence}"
        if not self._present(name):
            value = self.connection.execute(select(events.c.id).where(
                events.c.run_id == self.job["id"], events.c.kind == kind,
                events.c.data["fence"].as_integer() == fence)).first()
            self.check(self.store, self.connection, self.job)
            self._put(name, value is not None)
        return self._get(name)

    def typed_rows(self, instance, app_run):
        from .db import internal_instance_data

        name = f"typed:{instance}:{app_run}"
        if not self._present(name):
            rows = self.connection.execute(select(internal_instance_data).where(
                internal_instance_data.c.instance_id == instance,
                internal_instance_data.c.run_id == app_run)).mappings().all()
            self.check(self.store, self.connection, self.job)
            self._put(name, [dict(row) for row in rows])
        return self._get(name)

    def ledger_reservations(self):
        # Per-attempt slot reads cannot prove absence of additional Run slots.
        if not self._present("ledger-reservations"):
            rows = self.connection.execute(select(reservations).where(
                reservations.c.run_id == self.job["id"]).order_by(
                    reservations.c.id)).mappings().all()
            self.check(self.store, self.connection, self.job)
            self._put("ledger-reservations", [dict(row) for row in rows])
        return self._get("ledger-reservations")

    def ledger_events(self):
        # Anchor projections cannot prove the full ledger row multiset.
        if not self._present("ledger-events"):
            rows = self.connection.execute(select(events).where(
                events.c.run_id == self.job["id"], events.c.kind.in_([
                    "NS_RESERVED", "NS_RECEIVED", "NS_SETTLED", "NS_REJECTED", "MODEL_RESERVED"
                ])).order_by(events.c.id)).mappings().all()
            self.check(self.store, self.connection, self.job)
            self._put("ledger-events", [dict(row) for row in rows])
        return self._get("ledger-events")

    def record_receipts(self, binding, outputs, proved, pending_id, allow_pending):
        value = dict(binding=binding, outputs=outputs, proved=proved,
            pending_id=pending_id, allow_pending=allow_pending)
        name = f"receipts:{len(self._receipt_proofs)}"
        self._put(name, value)
        self._receipt_proofs.append(name)

    def checked_receipts(self, binding, outputs, proved):
        self.check(self.store, self.connection, self.job)
        for name in self._receipt_proofs:
            value = self._get(name)
            if (value["binding"] is binding and value["outputs"] is outputs
                    and value["proved"] is proved and value["pending_id"] is None
                    and value["allow_pending"] is True):
                return
        require(False, "Complete original pending-aware receipt proof required")


def _invalidate_cold_run_facts(facts):
    if type(facts) is _ColdRunFacts:
        facts.invalidate()


def _cold_run_facts(store, c, job, guard):
    try:
        require(type(guard) is _ColdGraphRead, "Exact Cold Run read scope required")
        return _ColdRunFacts(store, c, job, guard)
    except BaseException:
        if type(guard) is _ColdGraphRead:
            guard.invalidate()
        raise


def _check_run_facts(store, c, job, facts):
    require(type(facts) is _ColdRunFacts, "Exact Cold Run raw facts required")
    facts.check(store, c, job)


def _counter_checkpoint(c, job, facts):
    if facts is not None:
        require(type(facts) is _ColdRunFacts, "Exact Cold Run raw facts required")
        _check_run_facts(facts.store, c, job, facts)


'''

runtime = (BASE / 'natural_spec_runtime.py').read_text()
runtime = runtime.replace('def anchor(c, rid, kind, aid):\n', reader + '''def anchor(c, rid, kind, aid):
    return _anchor(c, rid, kind, aid)


def _anchor(c, rid, kind, aid, *, _facts=None):
    if _facts is not None:
        require(type(_facts) is _ColdRunFacts, "Exact Cold Run raw facts required")
        _check_run_facts(_facts.store, c, _facts.job, _facts)
        require(rid == _facts.job["id"])
''', 1)
runtime = runtime.replace('''    rows = (
        c.execute(
            select(events.c.data).where(
                events.c.run_id == rid,
                events.c.kind == kind,
                events.c.data["attempt_id"].as_string() == aid,
            )
        )
        .scalars()
        .all()
    )
    require(len(rows) == 1, "Missing/duplicate natural model anchor")''', '''    rows = _facts.anchor_rows(kind, aid) if _facts is not None else (
        c.execute(
            select(events.c.data).where(
                events.c.run_id == rid,
                events.c.kind == kind,
                events.c.data["attempt_id"].as_string() == aid,
            )
        )
        .scalars()
        .all()
    )
    require(len(rows) == 1, "Missing/duplicate natural model anchor")''', 1)
runtime = runtime.replace('''def counters(c, job, manifest):
''', '''def counters(c, job, manifest):
    return _counters(c, job, manifest)


def _counters_from_facts(store, c, job, manifest, facts):
    try:
        _check_run_facts(store, c, job, facts)
        rows = _counters(c, job, manifest, _facts=facts)
        facts.record_counters(manifest)
        return rows
    except BaseException:
        _invalidate_cold_run_facts(facts)
        raise


def _counters(c, job, manifest, *, _facts=None):
''', 1)
start = runtime.index('def _counters(c, job, manifest, *, _facts=None):')
end = runtime.index('\ndef messages(', start)
part = runtime[start:end]
part = part.replace('''    rows = (
        c.execute(
            select(attempts)''', '''    _counter_checkpoint(c, job, _facts)
    if _facts is not None:
        _facts.pin_manifest(manifest)
    rows = _facts.attempt_rows() if _facts is not None else (
        c.execute(
            select(attempts)''', 1)
part = part.replace('''    associated = context_association(c, job) if MARKER in ctx else None
    if associated is not None:
        require(associated.stage in {"source", "cold"})''', '''    associated = ((_facts.association() if _facts is not None else context_association(c, job))
        if MARKER in ctx else None)
    _counter_checkpoint(c, job, _facts)
    if associated is not None:
        stage = associated["stage"] if _facts is not None else associated.stage
        require(stage in {"source", "cold"})''', 1)
part = part.replace('''    reserved_events = (
''', '''    reserved_events = _facts.model_reserved() if _facts is not None else (
''', 1)
part = part.replace('''        ids = (
''', '''        ids = _facts.anchor_ids(kind) if _facts is not None else (
''', 1)
# Preserve the original left-to-right require: mode is not read if earlier clauses fail.
part = part.replace('''and row["mode"] == evidence_mode(c, job)''', '''and row["mode"] == (_facts.mode() if _facts is not None else evidence_mode(c, job))''', 1)
part = part.replace('''        slots = (
''', '''        slots = _facts.reservation(row["id"]) if _facts is not None else (
''', 1)
part = part.replace('''stored = anchor(c, job["id"], "NS_RESERVED", row["id"])''', '''stored = _anchor(c, job["id"], "NS_RESERVED", row["id"], _facts=_facts)''', 1)
part = part.replace('''    ops = (
''', '''    ops = _facts.model_operations() if _facts is not None else (
''', 1)
part = part.replace('''    return rows
''', '''    _counter_checkpoint(c, job, _facts)
    return rows
''', 1)
runtime = runtime[:start] + part + runtime[end:]

runtime = runtime.replace('''def prove_node(store, c, job, binding, op, intent, action):
''', '''def prove_node(store, c, job, binding, op, intent, action):
    return _prove_node(store, c, job, binding, op, intent, action)


def _prove_node_from_facts(store, c, job, binding, op, intent, action, facts):
    try:
        _check_run_facts(store, c, job, facts)
        return _prove_node(store, c, job, binding, op, intent, action, _facts=facts)
    except BaseException:
        _invalidate_cold_run_facts(facts)
        raise


def _prove_node(store, c, job, binding, op, intent, action, *, _facts=None):
''', 1)
start = runtime.index('def _prove_node(store, c, job, binding, op, intent, action, *, _facts=None):')
end = runtime.index('\ndef ledger_digest(', start)
part = runtime[start:end]
part = part.replace('''    rows = counters(
        c, job, spec.AppManifest.model_validate(binding["draft"]["candidate"]["manifest"])
    )''', '''    manifest = spec.AppManifest.model_validate(binding["draft"]["candidate"]["manifest"])
    _counter_checkpoint(c, job, _facts)
    rows = (_counters(c, job, manifest, _facts=_facts) if _facts is not None
        else counters(c, job, manifest))''', 1)
part = part.replace('''anchor(c, job["id"], "NS_SETTLED", a["id"])''', '''_anchor(c, job["id"], "NS_SETTLED", a["id"], _facts=_facts)''')
part = part.replace('''anchor(c, job["id"], "NS_RECEIVED", a["id"])''', '''_anchor(c, job["id"], "NS_RECEIVED", a["id"], _facts=_facts)''')
part = part.replace('''    original, evidence = response_archive(raw)
''', '''    _counter_checkpoint(c, job, _facts)
    original, evidence = response_archive(raw)
    _counter_checkpoint(c, job, _facts)
''', 1)
part = part.replace('''    require(a["usage"] == usage''', '''    _counter_checkpoint(c, job, _facts)
    require(a["usage"] == usage''', 1)
part = part.replace('''    wire = body(messages(binding, step, action, intent), [], node_limits.max_output_tokens)
''', '''    current_messages = messages(binding, step, action, intent)
    _counter_checkpoint(c, job, _facts)
    wire = body(current_messages, [], node_limits.max_output_tokens)
    _counter_checkpoint(c, job, _facts)
''', 1)
part = part.replace('''    return expected
''', '''    _counter_checkpoint(c, job, _facts)
    return expected
''', 1)
runtime = runtime[:start] + part + runtime[end:]

runtime = runtime.replace('''def ledger_digest(c, job):
''', '''def ledger_digest(c, job):
    return _ledger_digest(c, job)


def _ledger_digest_from_facts(store, c, job, facts):
    try:
        _check_run_facts(store, c, job, facts)
        value = _ledger_digest(c, job, _facts=facts)
        _check_run_facts(store, c, job, facts)
        return value
    except BaseException:
        _invalidate_cold_run_facts(facts)
        raise


def _ledger_digest(c, job, *, _facts=None):
''', 1)
start = runtime.index('def _ledger_digest(c, job, *, _facts=None):')
end = runtime.index('\ndef prove_pending(', start)
part = runtime[start:end]
part = part.replace('''                for r in c.execute(
                    select(attempts).where(attempts.c.run_id == job["id"]).order_by(attempts.c.id)
                ).mappings()
''', '''                for r in (_facts.attempt_rows(ledger=True) if _facts is not None else c.execute(
                    select(attempts).where(attempts.c.run_id == job["id"]).order_by(attempts.c.id)
                ).mappings())
''', 1)
part = part.replace('''                for r in c.execute(
                    select(reservations)''', '''                for r in (_facts.ledger_reservations() if _facts is not None else c.execute(
                    select(reservations)''', 1)
part = part.replace('''                    .order_by(reservations.c.id)
                ).mappings()
''', '''                    .order_by(reservations.c.id)
                ).mappings())
''', 1)
part = part.replace('''                for r in c.execute(
                    select(events)''', '''                for r in (_facts.ledger_events() if _facts is not None else c.execute(
                    select(events)''', 1)
part = part.replace('''                    .order_by(events.c.id)
                ).mappings()
''', '''                    .order_by(events.c.id)
                ).mappings())
''', 1)
runtime = runtime[:start] + part + runtime[end:]

runtime = runtime.replace('''def prove_pending(store, c, job, binding, op, intent, action):
''', '''def prove_pending(store, c, job, binding, op, intent, action):
    """Original-key inspection only; never authorizes a resend or success."""
    return _prove_pending(store, c, job, binding, op, intent, action)


def _prove_pending_from_facts(store, c, job, binding, op, intent, action, facts):
    try:
        _check_run_facts(store, c, job, facts)
        return _prove_pending(store, c, job, binding, op, intent, action, _facts=facts)
    except BaseException:
        _invalidate_cold_run_facts(facts)
        raise


def _prove_pending(store, c, job, binding, op, intent, action, *, _facts=None):
''', 1)
start = runtime.index('def _prove_pending(store, c, job, binding, op, intent, action, *, _facts=None):')
end = runtime.index('\ndef fail_owned(', start)
part = runtime[start:end]
part = part.replace('''    rows = counters(c, job, AppManifest.model_validate(binding["draft"]["candidate"]["manifest"]))''', '''    manifest = AppManifest.model_validate(binding["draft"]["candidate"]["manifest"])
    _counter_checkpoint(c, job, _facts)
    rows = (_counters(c, job, manifest, _facts=_facts) if _facts is not None
        else counters(c, job, manifest))''', 1)
part = part.replace('''    require(
        c.execute(
            select(events.c.id)''', '''    require(
        (not _facts.pending_step(op["id"])) if _facts is not None else c.execute(
            select(events.c.id)''', 1)
part = part.replace('''        original, evidence = response_archive(raw)
''', '''        _counter_checkpoint(c, job, _facts)
        original, evidence = response_archive(raw)
        _counter_checkpoint(c, job, _facts)
''', 1)
# Preserve the original short circuit: normalize_usage runs only after archive equality.
part = part.replace('''normalize_usage(raw) == row["usage"]''', '''_pending_usage(c, job, raw, _facts) == row["usage"]''', 1)
part = part.replace('''anchor(c, job["id"], "NS_RECEIVED", row["id"])''', '''_anchor(c, job["id"], "NS_RECEIVED", row["id"], _facts=_facts)''')
part = part.replace('''anchor(c, job["id"], "NS_REJECTED", row["id"])''', '''_anchor(c, job["id"], "NS_REJECTED", row["id"], _facts=_facts)''')
part = part.rstrip() + '''

    _counter_checkpoint(c, job, _facts)


def _pending_usage(c, job, raw, facts):
    value = normalize_usage(raw)
    _counter_checkpoint(c, job, facts)
    return value

'''
runtime = runtime[:start] + part + runtime[end:]
(WORK / 'natural_spec_runtime.py').write_text(runtime)

spec = (BASE / 'pa_spec_apps.py').read_text()
spec = spec.replace('''@controlled
def receipts(store, c, job, binding, *, pending_id=None, allow_pending=False):
''', '''@controlled
def receipts(store, c, job, binding, *, pending_id=None, allow_pending=False):
    return _receipts(store, c, job, binding, pending_id=pending_id, allow_pending=allow_pending)


def _receipt_checkpoint(store, c, job, facts):
    if facts is not None:
        from .natural_spec_runtime import _check_run_facts
        _check_run_facts(store, c, job, facts)


@controlled
def _cold_receipts(store, c, job, binding, facts, *, pending_id=None, allow_pending=False):
    from .natural_spec_runtime import _check_run_facts, _invalidate_cold_run_facts

    try:
        _check_run_facts(store, c, job, facts)
        facts.checked_counters()
        facts.pin_receipt_binding(binding)
        result = _receipts(store, c, job, binding, pending_id=pending_id,
            allow_pending=allow_pending, _facts=facts)
        _check_run_facts(store, c, job, facts)
        facts.record_receipts(binding, result[0], result[1], pending_id, allow_pending)
        return result
    except BaseException:
        _invalidate_cold_run_facts(facts)
        raise


def _receipts(store, c, job, binding, *, pending_id=None, allow_pending=False, _facts=None):
''', 1)
start = spec.index('def _receipts(store, c, job, binding, *, pending_id=None, allow_pending=False, _facts=None):')
end = spec.index('\ndef output_for(', start)
part = spec[start:end]
part = part.replace('''    plan, source =''', '''    _receipt_checkpoint(store, c, job, _facts)
    plan, source =''', 1)
part = part.replace('''    ops = c.execute(select(operations).where(operations.c.run_id == job["id"])).mappings().all()''', '''    ops = (_facts.receipt_operations() if _facts is not None else
        c.execute(select(operations).where(operations.c.run_id == job["id"])).mappings().all())''', 1)
part = part.replace('''        intent = intent_for(step, action, plan, outputs, proved)
        stored = c.execute(select(operation_intents.c.request).where(operation_intents.c.operation_id == op["id"])).scalar()''', '''        intent = intent_for(step, action, plan, outputs, proved)
        _receipt_checkpoint(store, c, job, _facts)
        stored = (_facts.intent(op["id"]) if _facts is not None else
            c.execute(select(operation_intents.c.request).where(operation_intents.c.operation_id == op["id"])).scalar())''', 1)
part = part.replace('''                from .natural_spec_runtime import prove_pending
                prove_pending(store, c, job, binding, op, intent, action)''', '''                from .natural_spec_runtime import _prove_pending_from_facts, prove_pending
                if _facts is not None:
                    _prove_pending_from_facts(store, c, job, binding, op, intent, action, _facts)
                else:
                    prove_pending(store, c, job, binding, op, intent, action)
                _receipt_checkpoint(store, c, job, _facts)''', 1)
part = part.replace('''        validate_value(action["output_schema"], op["receipt"]["data"])
''', '''        validate_value(action["output_schema"], op["receipt"]["data"])
        _receipt_checkpoint(store, c, job, _facts)
''', 1)
part = part.replace('''            effect = c.execute(select(local_effects).where(local_effects.c.operation_id == op["id"])).mappings().first()''', '''            effect = (_facts.effect(op["id"]) if _facts is not None else
                c.execute(select(local_effects).where(local_effects.c.operation_id == op["id"])).mappings().first())''', 1)
part = part.replace('''                "resource.read", dict(resource_id=value["resource_id"]))
''', '''                "resource.read", dict(resource_id=value["resource_id"]))
            _receipt_checkpoint(store, c, job, _facts)
''', 1)
part = part.replace('''            verify_saved(source, actual["content"], plan["definition"])
''', '''            verify_saved(source, actual["content"], plan["definition"])
            _receipt_checkpoint(store, c, job, _facts)
''', 1)
part = part.replace('''                    from .natural_spec_runtime import prove_node
                    expected = prove_node(store, c, job, binding, op, intent, action)''', '''                    from .natural_spec_runtime import _prove_node_from_facts, prove_node
                    expected = (_prove_node_from_facts(store, c, job, binding, op, intent, action, _facts)
                        if _facts is not None else prove_node(store, c, job, binding, op, intent, action))''', 1)
part = part.replace('''            require(fingerprint(expected)''', '''            _receipt_checkpoint(store, c, job, _facts)
            require(fingerprint(expected)''', 1)
part = part.replace('''            require(c.execute(select(local_effects.c.operation_id).where(local_effects.c.operation_id == op["id"])).first() is None)''', '''            require((not _facts.has_effect(op["id"])) if _facts is not None else
                c.execute(select(local_effects.c.operation_id).where(local_effects.c.operation_id == op["id"])).first() is None)''', 1)
part = part.replace('''        wanted = receipt_for(op["id"], step, action, plan, intent, value)
''', '''        wanted = receipt_for(op["id"], step, action, plan, intent, value)
        _receipt_checkpoint(store, c, job, _facts)
''', 1)
part = part.replace('''        anchors = c.execute(select(events.c.data).where(events.c.run_id == job["id"],
            events.c.kind == "SPEC_STEP_VERIFIED", events.c.data["operation_id"].as_string() == op["id"])).scalars().all()''', '''        anchors = (_facts.step_anchors(op["id"]) if _facts is not None else
            c.execute(select(events.c.data).where(events.c.run_id == job["id"],
                events.c.kind == "SPEC_STEP_VERIFIED", events.c.data["operation_id"].as_string() == op["id"])).scalars().all())''', 1)
part = part.replace('''            and c.execute(select(events.c.id).where(events.c.run_id == job["id"], events.c.kind == "CLAIMED",
                events.c.data["fence"].as_integer() == anchors[0]["fence"])).first() is not None)''', '''            and (_facts.progress_event("CLAIMED", anchors[0]["fence"]) if _facts is not None else
                c.execute(select(events.c.id).where(events.c.run_id == job["id"], events.c.kind == "CLAIMED",
                    events.c.data["fence"].as_integer() == anchors[0]["fence"])).first() is not None))''', 1)
part = part.replace('''    return outputs, proved
''', '''    _receipt_checkpoint(store, c, job, _facts)
    return outputs, proved
''', 1)
spec = spec[:start] + part + spec[end:]

start = spec.index('@controlled\ndef verify_job(')
tail_start = spec.index('    a, s = b["app_run"], b["snapshot"]', start)
end = spec.index('\n\n@controlled\ndef instance_scope_gate', start)
wrapper = spec[start:tail_start]
wrapper += '''    return _verify_job_from_receipts(store, c, user, job, limits, b, outputs, proved)


@controlled
def _cold_verify_job_from_receipts(store, c, user, job, limits, binding, outputs, proved, facts):
    from .natural_spec_runtime import _check_run_facts, _invalidate_cold_run_facts

    try:
        _check_run_facts(store, c, job, facts)
        require(user == job["principal_id"])
        facts.checked_receipts(binding, outputs, proved)
        return _verify_job_from_receipts(store, c, user, job, limits, binding,
            outputs, proved, _facts=facts)
    except BaseException:
        _invalidate_cold_run_facts(facts)
        raise


def _verify_job_from_receipts(store, c, user, job, limits, b, outputs, proved, *, _facts=None):
    _receipt_checkpoint(store, c, job, _facts)
'''
part = spec[tail_start:end]
part = part.replace('''    rows = c.execute(select(internal_instance_data).where(internal_instance_data.c.instance_id == s["instance_id"],
        internal_instance_data.c.run_id == a["id"])).mappings().all()''', '''    rows = (_facts.typed_rows(s["instance_id"], a["id"]) if _facts is not None else
        c.execute(select(internal_instance_data).where(internal_instance_data.c.instance_id == s["instance_id"],
            internal_instance_data.c.run_id == a["id"])).mappings().all())''', 1)
part = part.replace('''not store.has_unknown(c, job["id"])''', '''not _receipt_has_unknown(store, c, job, _facts)''', 1)
part = part.replace('''        output = output_for(b["plan"], outputs)
''', '''        output = output_for(b["plan"], outputs)
        _receipt_checkpoint(store, c, job, _facts)
''', 1)
part = part.replace('''        validate_value(b["draft"]["candidate"]["manifest"]["output_schema"], output)
''', '''        validate_value(b["draft"]["candidate"]["manifest"]["output_schema"], output)
        _receipt_checkpoint(store, c, job, _facts)
''', 1)
part = part.replace('''        validate_value(b["release"]["snapshot"]["data_schema"], row["data"])
''', '''        validate_value(b["release"]["snapshot"]["data_schema"], row["data"])
        _receipt_checkpoint(store, c, job, _facts)
''', 1)
part = part.replace('''        claimed = c.execute(select(events.c.id).where(events.c.run_id == job["id"], events.c.kind == "CLAIMED",
            events.c.data["fence"].as_integer() == job["fence"])).first() is not None
        stepped = c.execute(select(events.c.id).where(events.c.run_id == job["id"], events.c.kind == "SPEC_STEP_VERIFIED",
            events.c.data["fence"].as_integer() == job["fence"])).first() is not None''', '''        claimed = (_facts.progress_event("CLAIMED", job["fence"]) if _facts is not None else
            c.execute(select(events.c.id).where(events.c.run_id == job["id"], events.c.kind == "CLAIMED",
                events.c.data["fence"].as_integer() == job["fence"])).first() is not None)
        stepped = (_facts.progress_event("SPEC_STEP_VERIFIED", job["fence"]) if _facts is not None else
            c.execute(select(events.c.id).where(events.c.run_id == job["id"], events.c.kind == "SPEC_STEP_VERIFIED",
                events.c.data["fence"].as_integer() == job["fence"])).first() is not None)''', 1)
part = part.replace('''and c.execute(
            select(events.c.id).where(events.c.run_id == job["id"], events.c.kind == "WORKER_LOST",
                events.c.data["fence"].as_integer() == job["fence"])).first() is not None''', '''and (_facts.progress_event("WORKER_LOST", job["fence"]) if _facts is not None else c.execute(
            select(events.c.id).where(events.c.run_id == job["id"], events.c.kind == "WORKER_LOST",
                events.c.data["fence"].as_integer() == job["fence"])).first() is not None)''', 1)
part = part.replace('and fingerprint(job["result"]) == fingerprint(result_ref(b, proved, row["version"])))',
    'and fingerprint(job["result"]) == fingerprint(_receipt_result_ref(store, c, job, b, proved, row["version"], _facts)))', 1)
part = part.replace('''    return b, outputs, proved
''', '''    _receipt_checkpoint(store, c, job, _facts)
    return b, outputs, proved


def _receipt_has_unknown(store, c, job, facts):
    value = store.has_unknown(c, job["id"])
    _receipt_checkpoint(store, c, job, facts)
    return value


def _receipt_result_ref(store, c, job, binding, proved, version, facts):
    value = result_ref(binding, proved, version)
    _receipt_checkpoint(store, c, job, facts)
    return value
''', 1)
spec = spec[:start] + wrapper + part + spec[end:]
(WORK / 'pa_spec_apps.py').write_text(spec)

out = []
for name in ('natural_spec_runtime.py', 'pa_spec_apps.py'):
    before = (BASE / name).read_text()
    after = (WORK / name).read_text()
    ast.parse(before)
    ast.parse(after)
    out.extend(difflib.unified_diff(before.splitlines(keepends=True), after.splitlines(keepends=True),
        fromfile=f'a/src/sim2act/{name}', tofile=f'b/src/sim2act/{name}', n=3))
patch = ''.join(out)
(ROOT / 'implementation.patch').write_text(patch)
print(json.dumps(dict(patch_sha256=hashlib.sha256(patch.encode()).hexdigest(),
    patch_bytes=len(patch.encode()), files=[str(p) for p in WORK.glob('*.py')], ast='PASS')))
