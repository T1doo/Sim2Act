# v2 delta: strict sticky failure and complete node proof reuse

Apply `delta.patch` after the v1 receipt-facts patch. It changes only the receipt reader/strict helpers and the two strict receipt-to-node calls. No repository writes or product execution occurred in this subtask.

SHA-256: `c4994646f1f940e690a7a6e10be570abc092c277def7fcf19160ed2b79b10dbb` (43,267 bytes).

## Actual API

The root-facing API is unchanged. Two existing private helpers gain an optional keyword only for complete receipt phase inputs:

```python
_prove_node_from_facts(store,c,job,binding,op,intent,action,reader, *, _receipt_phase=None)
_prove_pending_from_facts(store,c,job,binding,op,intent,action,reader, *, _receipt_phase=None)
```

The strict receipts core passes a deep copy of the complete `{pending_id,allow_pending,index,outputs,proved}` at the original model/pending position. Default branches do not construct this phase or touch the proof registry. Direct helper calls using `None` are a separate exact phase.

Internal reader methods are fixed-purpose:

- `node_proof(kind, inputs) -> (hit,value,inputs_key)` accepts only `verified` or `pending`. A hit reads the full previous input entry, normalizes the full previous and current values, compares full structural equality, checks the same exact epoch, and returns the same complete previous result object. A miss pins the complete live input map **before** original node/body/anchor work and returns its unique input key. It issues no SQL.
- `record_node_proof(kind, inputs, value, inputs_key)` accepts only that exact previously pinned input map/key and records completion after the entire original node/pending proof has succeeded. It adds no authority marker. The stored proof points to the full input entry; this avoids duplicating large input bodies in a second record.

Complete input fields: full actual Run; full plan; full draft; full source; human-correction value; full Operation; complete reconstructed intent; full action; full selected Attempt including raw/canonical response; full natural metadata; the complete node Limits dictionary; complete receipt phase. The six node Limits fields have all passed the original `Limits` construction before completion can be recorded. The raw row collections, multiset/cardinality and per-manifest budget predicates are never replaced by a proof cache entry.

The cache is consulted only **after the original complete counters invocation and original exactly-one Attempt selection**. Each manifest facet still runs every original counter predicate. First miss executes every original status/meta, NS anchor, raw/canonical, parse/usage/model, messages/body/wire, reservation and response/rejection predicate at the original positions. Pending and verified proof namespaces are separate. Different pending IDs, allow-pending flags, predecessor phase, full plan/source/action/intent/meta/node Limits or any other complete input produce a miss and a full original proof. The graph guard prohibits reuse after writes, callback drift or an epoch change.

## v1 sticky review and repair

Static review found that root-facing `_cold_*` wrappers already invalidated exact readers on errors, but direct reader helper failures (e.g. wrong manifest type, absent counters proof, wrong binding/output/proved identity, invalid anchor kind) could leave a guard active if caught inside an epoch. Direct construction, `_check_run_facts`, `_counter_checkpoint`, and `_anchor` also had type/identity assertions outside their own cleanup boundary.

The delta puts all reader method type/assert/read/validation errors inside `try/except BaseException`, and does the same for the named strict helper boundaries. Cleanup dispatches only `_ColdRunFacts.invalidate(facts)` or `_ColdGraphRead.invalidate(guard)` after an exact type check, never an unknown object's method or substituted instance callback. A partially constructed exact reader is cleaned through its known fields, and the exact local constructor guard is also invalidated. The original exception is re-raised; cleanup does not run a current-state check that could replace it.

Reader registry integrity is also checked against the exact guard input namespace. Removing/replacing a raw entry or counter/receipt/node/manifest registry now fails before another read or cached result can be used. This prevents a caught corruption from silently returning to a fresh SQL read. The namespace `run-facts:<run_id>:` remains private to this reader.

Wrong unknown reader/guard objects are rejected without cleanup dispatch to them. A known exact reader with wrong job/store/connection/guard/proof inputs invalidates its original exact guard. Root still owns actual bound completeness, live permissions/source/fence/stop/lease/deadline boundaries and graph coordination.

## Checks actually completed

- Both complete source copies parsed with stdlib AST: PASS.
- Entire default body AST is identical to v1 after selecting `_facts=None` branches for 15 public/shared functions, including parse, counters, node, pending, ledger, receipts and verify tail: PASS (`static-checks.json`). This is stronger than just matching default SQL queries.
- Every reader method except nonthrowing exact-type cleanup begins with try and an exact-self assertion: PASS.
- `git apply --check` against the copied v1/current base and current repository: PASS.
- Product imports, DB calls, tests, models, network calls: all zero. Root's runtime regression, lint/type gates and independent review remain required. No runtime P2 acceptance or timing result is claimed.
