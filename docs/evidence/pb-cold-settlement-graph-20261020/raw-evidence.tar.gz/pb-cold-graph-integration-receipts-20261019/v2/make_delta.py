from pathlib import Path
import ast
import difflib
import hashlib
import json

ROOT = Path('/workspace/pb-cold-graph-integration-receipts-20261019/v2')
BASE = ROOT / 'base/src/sim2act'
WORK = ROOT / 'work/src/sim2act'
runtime = (BASE / 'natural_spec_runtime.py').read_text()

runtime = runtime.replace('''    def __init__(self, store, c, job, guard):
        _cold_read_checkpoint(store, c, guard)
        require(type(guard) is _ColdGraphRead, "Exact Cold Run read scope required")
        self.store, self.connection, self.job, self.guard = store, c, job, guard
        self._origin_guard = guard
        self.key = f"run-facts:{job['id']}"
        self._raw: dict = {}
        self._receipt_proofs: list[str] = []
        self._manifests: list = []
        self._counter_proofs: list[str] = []
        guard.add(self.key, dict(job=job))
        self.check(store, c, job)
''', '''    def __init__(self, store, c, job, guard):
        try:
            require(type(self) is _ColdRunFacts, "Exact Cold Run raw facts required")
            require(type(guard) is _ColdGraphRead, "Exact Cold Run read scope required")
            _cold_read_checkpoint(store, c, guard)
            self.store, self.connection, self.job, self.guard = store, c, job, guard
            self._origin_guard = guard
            self.key = f"run-facts:{job['id']}"
            self._raw: dict = {}
            self._receipt_proofs: list[str] = []
            self._manifests: list = []
            self._counter_proofs: list[str] = []
            self._node_proofs: list[str] = []
            guard.add(self.key, dict(job=job))
            self.check(store, c, job)
        except BaseException:
            _invalidate_cold_run_facts(self)
            if type(guard) is _ColdGraphRead:
                _ColdGraphRead.invalidate(guard)
            raise
''', 1)
runtime = runtime.replace('''    def invalidate(self):
        if type(self._origin_guard) is _ColdGraphRead:
            self._origin_guard.invalidate()
        if self.guard is not self._origin_guard and type(self.guard) is _ColdGraphRead:
            self.guard.invalidate()
''', '''    def invalidate(self):
        # Cleanup never dispatches an attribute on an unknown input object.
        if type(self) is not _ColdRunFacts:
            return
        for guard in (vars(self).get("_origin_guard"), vars(self).get("guard")):
            if type(guard) is _ColdGraphRead:
                _ColdGraphRead.invalidate(guard)
''', 1)
runtime = runtime.replace('''        except BaseException:
            self.invalidate()
            raise

    def invalidate(self):''', '''        except BaseException:
            _invalidate_cold_run_facts(self)
            raise

    def invalidate(self):''', 1)

node_methods = '''    def node_proof(self, kind, inputs):
        require(type(kind) is str and kind in {"verified", "pending"}, "Exact node proof role required")
        self.check(self.store, self.connection, self.job)
        current = _model_value(inputs)
        self.check(self.store, self.connection, self.job)
        for name in self._node_proofs:
            require(type(name) is str and (name.startswith("node-proof:verified:")
                or name.startswith("node-proof:pending:")))
            if not name.startswith(f"node-proof:{kind}:"):
                continue
            proof = self._get(name)
            saved = self._get(proof["inputs_key"])
            original = _model_value(saved)
            self.check(self.store, self.connection, self.job)
            if original == current:
                return True, proof["value"], None
        name = f"node-input:{kind}:{len(self._raw)}"
        self._put(name, inputs)
        return False, None, name

    def record_node_proof(self, kind, inputs, value, inputs_key):
        require(type(kind) is str and kind in {"verified", "pending"}, "Exact node proof role required")
        self.check(self.store, self.connection, self.job)
        require(type(inputs_key) is str and inputs_key.startswith(f"node-input:{kind}:"))
        require(self._get(inputs_key) is inputs, "Original complete node inputs required")
        name = f"node-proof:{kind}:{len(self._node_proofs)}"
        self._put(name, dict(inputs_key=inputs_key, value=value))
        self._node_proofs.append(name)

'''
runtime = runtime.replace('    def record_receipts(self, binding, outputs, proved, pending_id, allow_pending):\n',
    node_methods + '    def record_receipts(self, binding, outputs, proved, pending_id, allow_pending):\n', 1)

runtime = runtime.replace('    def check(self, store, c, job):\n        try:\n',
    '    def check(self, store, c, job):\n        try:\n            require(type(self) is _ColdRunFacts, "Exact Cold Run raw facts required")\n', 1)

runtime = runtime.replace('            for manifest, name in self._manifests:\n', '''            require(type(self._raw) is dict and type(self._manifests) is list
                and type(self._receipt_proofs) is list and type(self._counter_proofs) is list
                and type(self._node_proofs) is list, "Cold Run fact registries changed")
            prefix = self.key + ":"
            names = [key[len(prefix):] for key in self.guard.inputs if key.startswith(prefix)]
            require(set(self._raw) == set(names)
                and all(self.guard.inputs[prefix + name] is value for name, value in self._raw.items()),
                "Cold Run facts cannot be forgotten or replaced")
            require(self._receipt_proofs == [name for name in names if name.startswith("receipts:")]
                and self._counter_proofs == [name for name in names if name.startswith("counter-proof:")]
                and self._node_proofs == [name for name in names if name.startswith("node-proof:")]
                and [name for _, name in self._manifests]
                    == [name for name in names if name.startswith("counter-manifest:")],
                "Cold Run proof registries changed")
            for manifest, name in self._manifests:
''', 1)

# Every externally reachable private reader method fails sticky even if its
# caller catches the original exception inside the epoch and then continues.
tree = ast.parse(runtime)
cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == '_ColdRunFacts')
lines = runtime.splitlines(keepends=True)
for method in reversed(cls.body):
    if not isinstance(method, ast.FunctionDef) or method.name in {'__init__', 'invalidate', 'check'}:
        continue
    first, last = method.body[0].lineno - 1, method.end_lineno
    old = lines[first:last]
    wrapped = ['        try:\n',
        '            require(type(self) is _ColdRunFacts, "Exact Cold Run raw facts required")\n']
    wrapped.extend('    ' + line if line.strip() else line for line in old)
    wrapped.extend(['        except BaseException:\n',
        '            _invalidate_cold_run_facts(self)\n', '            raise\n'])
    lines[first:last] = wrapped
runtime = ''.join(lines)

runtime = runtime.replace('''    if type(facts) is _ColdRunFacts:
        facts.invalidate()
''', '''    if type(facts) is _ColdRunFacts:
        _ColdRunFacts.invalidate(facts)
''', 1)
runtime = runtime.replace('''        if type(guard) is _ColdGraphRead:
            guard.invalidate()
        raise


def _check_run_facts''', '''        if type(guard) is _ColdGraphRead:
            _ColdGraphRead.invalidate(guard)
        raise


def _check_run_facts''', 1)
runtime = runtime.replace('''def _check_run_facts(store, c, job, facts):
    require(type(facts) is _ColdRunFacts, "Exact Cold Run raw facts required")
    facts.check(store, c, job)
''', '''def _check_run_facts(store, c, job, facts):
    try:
        require(type(facts) is _ColdRunFacts, "Exact Cold Run raw facts required")
        _ColdRunFacts.check(facts, store, c, job)
    except BaseException:
        _invalidate_cold_run_facts(facts)
        raise
''', 1)
runtime = runtime.replace('''def _counter_checkpoint(c, job, facts):
    if facts is not None:
        require(type(facts) is _ColdRunFacts, "Exact Cold Run raw facts required")
        _check_run_facts(facts.store, c, job, facts)
''', '''def _counter_checkpoint(c, job, facts):
    if facts is not None:
        try:
            require(type(facts) is _ColdRunFacts, "Exact Cold Run raw facts required")
            _check_run_facts(facts.store, c, job, facts)
        except BaseException:
            _invalidate_cold_run_facts(facts)
            raise
''', 1)

old_anchor_start = runtime.index('def _anchor(c, rid, kind, aid, *, _facts=None):')
old_anchor_end = runtime.index('\n\ndef counters(', old_anchor_start)
anchor = runtime[old_anchor_start:old_anchor_end]
anchor = anchor.replace('''    if _facts is not None:
        require(type(_facts) is _ColdRunFacts, "Exact Cold Run raw facts required")
        _check_run_facts(_facts.store, c, _facts.job, _facts)
        require(rid == _facts.job["id"])
    rows = _facts.anchor_rows(kind, aid) if _facts is not None else (
''', '''    if _facts is not None:
        return _anchor_from_facts(c, rid, kind, aid, _facts)
    rows = (
''', 1)
anchor += '''


def _anchor_from_facts(c, rid, kind, aid, facts):
    try:
        require(type(facts) is _ColdRunFacts, "Exact Cold Run raw facts required")
        _check_run_facts(facts.store, c, facts.job, facts)
        require(rid == facts.job["id"])
        rows = facts.anchor_rows(kind, aid)
        require(len(rows) == 1, "Missing/duplicate natural model anchor")
        return rows[0]
    except BaseException:
        _invalidate_cold_run_facts(facts)
        raise
'''
runtime = runtime[:old_anchor_start] + anchor + runtime[old_anchor_end:]

proof_inputs = '''def _node_proof_inputs(job, binding, op, intent, action, attempt, receipt_phase):
    # Full values, not fingerprints, projections or an ALLOW/READY marker.
    # get() does not introduce a missing later input's exception before its
    # original predicate; only a previously complete identical proof can hit.
    meta = attempt["parameters"]["natural_spec"]
    return dict(run=job, plan=binding.get("plan"), draft=binding.get("draft"),
        source=binding.get("source"), human_correction=binding.get("human_correction"),
        operation=op, intent=intent, action=action, attempt=attempt,
        meta=meta, node_limits=meta.get("limits"), receipt_phase=receipt_phase)


'''
runtime = runtime.replace('def _prove_node_from_facts(store, c, job, binding, op, intent, action, facts):\n',
    proof_inputs + 'def _prove_node_from_facts(store, c, job, binding, op, intent, action, facts, *, _receipt_phase=None):\n', 1)
runtime = runtime.replace('''        return _prove_node(store, c, job, binding, op, intent, action, _facts=facts)
''', '''        require(_receipt_phase is None or type(_receipt_phase) is dict,
            "Exact receipt node phase required")
        return _prove_node(store, c, job, binding, op, intent, action,
            _facts=facts, _receipt_phase=_receipt_phase)
''', 1)
runtime = runtime.replace('def _prove_node(store, c, job, binding, op, intent, action, *, _facts=None):\n',
    'def _prove_node(store, c, job, binding, op, intent, action, *, _facts=None, _receipt_phase=None):\n', 1)
node_start = runtime.index('def _prove_node(store,')
node_end = runtime.index('\n\ndef ledger_digest(', node_start)
node = runtime[node_start:node_end]
node = node.replace('''    a = selected[0]
    meta = a["parameters"]["natural_spec"]
''', '''    a = selected[0]
    if _facts is not None:
        node_inputs = _node_proof_inputs(job, binding, op, intent, action, a, _receipt_phase)
        hit, value, inputs_key = _facts.node_proof("verified", node_inputs)
        if hit:
            return value
    meta = a["parameters"]["natural_spec"]
''', 1)
node = node.replace('''    _counter_checkpoint(c, job, _facts)
    return expected
''', '''    _counter_checkpoint(c, job, _facts)
    if _facts is not None:
        _facts.record_node_proof("verified", node_inputs, expected, inputs_key)
    return expected
''', 1)
runtime = runtime[:node_start] + node + runtime[node_end:]

runtime = runtime.replace('def _prove_pending_from_facts(store, c, job, binding, op, intent, action, facts):\n',
    'def _prove_pending_from_facts(store, c, job, binding, op, intent, action, facts, *, _receipt_phase=None):\n', 1)
runtime = runtime.replace('''        return _prove_pending(store, c, job, binding, op, intent, action, _facts=facts)
''', '''        require(_receipt_phase is None or type(_receipt_phase) is dict,
            "Exact receipt pending phase required")
        return _prove_pending(store, c, job, binding, op, intent, action,
            _facts=facts, _receipt_phase=_receipt_phase)
''', 1)
runtime = runtime.replace('def _prove_pending(store, c, job, binding, op, intent, action, *, _facts=None):\n',
    'def _prove_pending(store, c, job, binding, op, intent, action, *, _facts=None, _receipt_phase=None):\n', 1)
pending_start = runtime.index('def _prove_pending(store,')
pending_end = runtime.index('\n\ndef _pending_usage(', pending_start)
pending = runtime[pending_start:pending_end]
pending = pending.replace('''    row = chosen[0]
    meta = row["parameters"]["natural_spec"]
''', '''    row = chosen[0]
    if _facts is not None:
        node_inputs = _node_proof_inputs(job, binding, op, intent, action, row, _receipt_phase)
        hit, _, inputs_key = _facts.node_proof("pending", node_inputs)
        if hit:
            return
    meta = row["parameters"]["natural_spec"]
''', 1)
pending = pending.rstrip() + '''
    if _facts is not None:
        _facts.record_node_proof("pending", node_inputs, None, inputs_key)
'''
runtime = runtime[:pending_start] + pending + runtime[pending_end:]
(WORK / 'natural_spec_runtime.py').write_text(runtime)

spec = (BASE / 'pa_spec_apps.py').read_text()
spec = spec.replace('''                    _prove_pending_from_facts(store, c, job, binding, op, intent, action, _facts)
''', '''                    _prove_pending_from_facts(store, c, job, binding, op, intent, action, _facts,
                        _receipt_phase=copy.deepcopy(dict(pending_id=pending_id,
                            allow_pending=allow_pending, index=index, outputs=outputs, proved=proved)))
''', 1)
spec = spec.replace('''expected = (_prove_node_from_facts(store, c, job, binding, op, intent, action, _facts)
''', '''expected = (_prove_node_from_facts(store, c, job, binding, op, intent, action, _facts,
                        _receipt_phase=copy.deepcopy(dict(pending_id=pending_id,
                            allow_pending=allow_pending, index=index, outputs=outputs, proved=proved)))
''', 1)
(WORK / 'pa_spec_apps.py').write_text(spec)

patch=[]
for name in ('natural_spec_runtime.py','pa_spec_apps.py'):
    before=(BASE/name).read_text(); after=(WORK/name).read_text()
    ast.parse(before); ast.parse(after)
    patch.extend(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),
        fromfile=f'a/src/sim2act/{name}',tofile=f'b/src/sim2act/{name}',n=3))
text=''.join(patch)
(ROOT/'delta.patch').write_text(text)
print(json.dumps(dict(patch_sha256=hashlib.sha256(text.encode()).hexdigest(),bytes=len(text.encode()),ast='PASS')))
