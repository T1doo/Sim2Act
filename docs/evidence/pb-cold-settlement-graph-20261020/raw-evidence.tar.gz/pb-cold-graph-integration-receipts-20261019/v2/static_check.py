from pathlib import Path
import ast
import copy
import hashlib
import json

ROOT = Path('/workspace/pb-cold-graph-integration-receipts-20261019/v2')


class DefaultFacts(ast.NodeTransformer):
    def condition(self, test):
        if (isinstance(test, ast.Compare) and len(test.ops) == 1
                and isinstance(test.left, ast.Name) and test.left.id == '_facts'
                and isinstance(test.comparators[0], ast.Constant)
                and test.comparators[0].value is None):
            if isinstance(test.ops[0], ast.Is):
                return True
            if isinstance(test.ops[0], ast.IsNot):
                return False
        return None

    def visit_If(self, node):
        value = self.condition(node.test)
        if value is None:
            return self.generic_visit(node)
        result=[]
        for child in node.body if value else node.orelse:
            selected=self.visit(child)
            if isinstance(selected,list): result.extend(selected)
            elif selected is not None: result.append(selected)
        return result

    def visit_IfExp(self,node):
        value=self.condition(node.test)
        return self.generic_visit(node) if value is None else self.visit(node.body if value else node.orelse)


def funcs(path):
    return {n.name:n for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef)}


def default_body(node):
    value=DefaultFacts().visit(copy.deepcopy(node))
    return [ast.dump(n,include_attributes=False) for n in value.body]


pairs={'natural_spec_runtime.py': ['anchor','_anchor','counters','_counters','prove_node',
    '_prove_node','ledger_digest','_ledger_digest','prove_pending','_prove_pending','parse'],
    'pa_spec_apps.py':['receipts','_receipts','verify_job','_verify_job_from_receipts']}
result={}
for file,names in pairs.items():
    before,after=funcs(ROOT/'base/src/sim2act'/file),funcs(ROOT/'work/src/sim2act'/file)
    entries={}
    for name in names:
        assert default_body(before[name])==default_body(after[name]),(file,name,'default body AST differs')
        entries[name]='PASS: entire default body AST identical after selecting _facts=None branches'
    result[file]=entries

runtime=ast.parse((ROOT/'work/src/sim2act/natural_spec_runtime.py').read_text())
cls=next(n for n in runtime.body if isinstance(n,ast.ClassDef) and n.name=='_ColdRunFacts')
for method in cls.body:
    if isinstance(method,ast.FunctionDef) and method.name!='invalidate':
        assert isinstance(method.body[0],ast.Try),method.name
        assert method.body[0].handlers,method.name
        first=method.body[0].body[0]
        assert isinstance(first,ast.Expr) and isinstance(first.value,ast.Call)
        assert isinstance(first.value.func,ast.Name) and first.value.func.id=='require'
result['sticky_reader_entries']='PASS: every reader method except nonthrowing exact cleanup starts with try and exact self require'
result['executed']=dict(product_imports=0,product_DB=0,tests=0,models=0,network=0)
result['patch']=dict(sha256=hashlib.sha256((ROOT/'delta.patch').read_bytes()).hexdigest(),bytes=(ROOT/'delta.patch').stat().st_size)
(ROOT/'static-checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result['patch']))
