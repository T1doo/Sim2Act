# v3: fixed Source audit raw seed (relative to applied v2)

Patch: `delta.patch`, SHA-256 `1e04c5b76c0da7ff0b823146a1d4b068420b2cb00887fb4e90b5f0bfe0425994` (12,566 bytes). Only `natural_spec_runtime.py` receipt reader region changes. The repository remained read only.

## Actual API

```python
seed = runtime._cold_run_raw_seed(store, c, guard, source_audit_facts)
reader = runtime._cold_run_facts(store, c, source_job, guard, raw_seed=seed)
```

The optional `raw_seed` is keyword only and defaults to `None`. Existing callers keep the same behavior. `_ColdRunFacts.__init__` has the same optional keyword for direct internal construction. One exact seed per Source audit/Run/guard epoch is expected; factory keys cannot be overwritten.

`source_audit_facts` must be exact `pb_natural_specs._ColdSourceAuditFacts`, with exact prefix and original guard identity. A dict, typed summary/DTO, different guard, different Store/connection, absent prefix/native/complete guard pin, replaced full rows, wrong Run/principal/project, or non-full table-row projection is rejected. The seed derives its full Run from `rows['run'][0]`; attaching accepts an equal complete current Source Run mapping and the same exact Store/connection/guard. The reader then continues to pin the actual current job object's identity normally.

The new frozen `_ColdRunRawSeed` contains only full job and full Attempts/Operations copied from those exact pinned Source audit rows. The factory preserves the raw audit ID order, duplicate rows and every column/value; it performs no sort, SQL, counters, response parse, receipts, typed/result or Source-V proof. Structural full-row and scope/provenance checks are not semantic completion claims. Status/context/meta/anchors/usage/wire/cardinality/budgets remain the original later predicates.

Attaching installs only reader raw entries `attempts`, `receipt-operations`, and a `raw-seed` provenance link. Counter, receipt and node proof registries remain empty. Every subsequent projection, mode check, anchor, intent/effect, typed/result and receipt proof retains its original needed position. Seeding full Operations does not collapse them into a step/id dict: the existing duplicate-step/cardinality predicate still receives the entire collection.

The reader and seed check exact provenance and full guard pins, including the complete original Source audit namespace. Wrong known seeds/readers invalidate only exact known `_ColdGraphRead` objects through unbound class cleanup and re-raise the original exception. Unknown objects never receive method dispatch for cleanup. Removing/replacing an attached seed fails before another read/result can be consumed. A raw seed never replaces Source typed/receipts completion or fresh authorization/source/fence/stop/lease/deadline boundaries.

## Sorting and first-error boundary

Per root steering, factory sorting was deliberately deferred. The first `reader.attempt_rows()` at the original needed position returns a `(created_at,id)` sorted **copy**; ledger callers request ID order. `_cold_sqlite_order` now supplies fixed SQLite ASC storage-class ranks: NULL, numeric INTEGER/REAL, TEXT using the schema's BINARY order, then BLOB. It avoids coercing strings to numbers and avoids comparing incompatible Python classes. SQLite-bound NaN follows NULL handling. Opaque non-driver Python classes are stable in a final rank so ordering does not introduce their validation error; existing typed predicates retain that responsibility. The actual driver scope remains the existing exact SQLite guard.

This repairs the existing strict reader's potential Python mixed-type comparison before its original typed predicates, for seeded and ordinary strict readers. Public/default counters and all other original top-level functions are untouched. No PG/other collation or platform compatibility claim is made. Actual SQLite comparison and corrupt-storage regressions remain root's short-test gate; this subtask only inspected the code statically.

## Actual checks

- Full before/after source stdlib AST parse: PASS.
- Every existing top-level function except the optional-seed factory is AST-identical; all counter/prove/pending/ledger/parse/settlement logic is untouched: PASS.
- All reader methods except constructor/check/invalidate/sort-copy method are AST-identical: PASS.
- New seed helpers/class and reader constructor contain zero direct SQL execution calls. Factory contains no sort or semantic proof call: PASS.
- `git apply --check` against copied v2 base and current repository: PASS.
- Product imports, DB calls, tests, models and network executions: zero.

See `static-checks.json` for exact function/method lists and hashes. Applying, lint/type/runtime regressions, independent review and the bounded full Mock gate remain root work; no runtime acceptance is claimed here.
