from pathlib import Path
import ast
import difflib
import hashlib
import json

ROOT = Path('/workspace/pb-cold-graph-integration-receipts-20261019/v3')
BASE = ROOT / 'base/src/sim2act/natural_spec_runtime.py'
WORK = ROOT / 'work/src/sim2act/natural_spec_runtime.py'
source = BASE.read_text().replace('from typing import TYPE_CHECKING, cast', 'from typing import TYPE_CHECKING, Any, cast', 1)

seed = '''def _cold_seed_audit_rows(store, c, guard, audit):
    """Locate exact already-read raw rows; do not perform Source verification."""
    from .db import runs
    from .pb_natural_specs import _ColdSourceAuditFacts, _ColdSourceAuditPrefix

    require(type(guard) is _ColdGraphRead and type(audit) is _ColdSourceAuditFacts,
        "Exact Cold source audit raw facts required")
    _cold_read_checkpoint(store, c, guard)
    prefix = audit.prefix
    require(type(prefix) is _ColdSourceAuditPrefix
        and prefix.guard is guard and prefix._origin_guard is guard,
        "Cold source raw audit belongs to a different read scope")
    require(prefix.user == guard.binding.contract.principal_id
        and prefix.pid == guard.binding.contract.project_id
        and prefix.key == f"pb-source-audit:{prefix.user}:{prefix.pid}:{prefix.rid}"
        and audit.key == prefix.key + ":complete"
        and guard.inputs[prefix.key] == _ColdSourceAuditPrefix.fields(prefix)
        and guard.inputs[prefix.key + ":native"] is audit.original_audit_rows
        and guard.inputs[audit.key] == _ColdSourceAuditFacts.fields(audit)
        and guard.inputs[audit.key]["rows"] is audit.rows,
        "Cold source raw audit pin changed")
    _cold_read_checkpoint(store, c, guard)
    rows = audit.rows
    require(type(rows) is dict and set(rows) == {
        "scope", "seal", "original_audit", "original", "run", "contract", "binding",
        "app_run", "typed", "release", "attempts", "operations", "intents", "effects",
        "events", "reservations", "origin_marker", "origin_seals", "current_goal",
        "current_goal_versions"}, "Complete original source audit rows required")
    require(type(rows["run"]) is list and len(rows["run"]) == 1
        and type(rows["run"][0]) is dict and set(rows["run"][0]) == set(runs.c.keys())
        and rows["run"][0]["id"] == prefix.rid
        and rows["run"][0]["principal_id"] == prefix.user
        and rows["run"][0]["project_id"] == prefix.pid,
        "Complete original source Run row required")
    require(type(rows["attempts"]) is list and all(type(row) is dict
        and set(row) == set(attempts.c.keys()) and row["run_id"] == prefix.rid
        for row in rows["attempts"]), "Complete source Attempt raw rows required")
    require(type(rows["operations"]) is list and all(type(row) is dict
        and set(row) == set(operations.c.keys()) and row["run_id"] == prefix.rid
        for row in rows["operations"]), "Complete source Operation raw rows required")
    return rows


@dataclass(frozen=True)
class _ColdRunRawSeed:
    """Only two complete raw collections from a pinned Source audit, never V."""

    store: Store
    connection: Connection
    guard: Any
    audit: Any
    key: str
    job: dict
    attempt_rows: list[dict]
    operation_rows: list[dict]
    _origin_guard: Any = field(init=False, repr=False)

    def __post_init__(self):
        try:
            require(type(self) is _ColdRunRawSeed, "Exact Cold Run raw seed required")
            require(type(self.guard) is _ColdGraphRead, "Exact Cold Run raw seed scope required")
            object.__setattr__(self, "_origin_guard", self.guard)
        except BaseException:
            _invalidate_cold_run_raw_seed(self)
            raise

    def fields(self):
        try:
            from .pb_natural_specs import _ColdSourceAuditFacts

            require(type(self) is _ColdRunRawSeed and type(self.audit) is _ColdSourceAuditFacts,
                "Exact Cold Run source audit raw seed required")
            return dict(audit_key=self.audit.key, job=self.job,
                attempts=self.attempt_rows, operations=self.operation_rows)
        except BaseException:
            _invalidate_cold_run_raw_seed(self)
            raise

    def check(self, store, c, job, guard):
        try:
            require(type(self) is _ColdRunRawSeed, "Exact Cold Run raw seed required")
            require(type(guard) is _ColdGraphRead and self.guard is self._origin_guard
                and self.guard is guard and self.store is store and self.connection is c,
                "Cold Run raw seed changed read scope")
            rows = _cold_seed_audit_rows(store, c, guard, self.audit)
            require(self.key == "run-raw-seed:" + self.audit.key
                and guard.inputs[self.key] == _ColdRunRawSeed.fields(self)
                and guard.inputs[self.key]["job"] is self.job
                and guard.inputs[self.key]["attempts"] is self.attempt_rows
                and guard.inputs[self.key]["operations"] is self.operation_rows,
                "Cold Run raw seed pin changed")
            require(self.job == rows["run"][0] == dict(job)
                and self.attempt_rows == rows["attempts"]
                and self.operation_rows == rows["operations"],
                "Cold Run raw seed changed complete Run or raw collections")
            _cold_read_checkpoint(store, c, guard)
        except BaseException:
            _invalidate_cold_run_raw_seed(self)
            if type(guard) is _ColdGraphRead:
                _ColdGraphRead.invalidate(guard)
            raise

    def invalidate(self):
        if type(self) is not _ColdRunRawSeed:
            return
        for guard in (vars(self).get("_origin_guard"), vars(self).get("guard")):
            if type(guard) is _ColdGraphRead:
                _ColdGraphRead.invalidate(guard)


def _invalidate_cold_run_raw_seed(seed):
    if type(seed) is _ColdRunRawSeed:
        _ColdRunRawSeed.invalidate(seed)


def _cold_run_raw_seed(store, c, guard, audit_facts):
    """Copy only full raw Attempts/Operations already read at the audit edge."""
    value = None
    try:
        require(type(guard) is _ColdGraphRead, "Exact Cold Run raw seed scope required")
        rows = _cold_seed_audit_rows(store, c, guard, audit_facts)
        value = _ColdRunRawSeed(store, c, guard, audit_facts,
            "run-raw-seed:" + audit_facts.key, copy.deepcopy(rows["run"][0]),
            copy.deepcopy(rows["attempts"]),
            copy.deepcopy(rows["operations"]))
        _cold_read_checkpoint(store, c, guard)
        guard.add(value.key, _ColdRunRawSeed.fields(value))
        _ColdRunRawSeed.check(value, store, c, value.job, guard)
        return value
    except BaseException:
        _invalidate_cold_run_raw_seed(value)
        if type(guard) is _ColdGraphRead:
            _ColdGraphRead.invalidate(guard)
        raise


'''
seed_lines = seed.splitlines(keepends=True)
helper = next(n for n in ast.parse(seed).body if isinstance(n, ast.FunctionDef) and n.name == '_cold_seed_audit_rows')
start, end = helper.body[1].lineno - 1, helper.end_lineno
# Preserve the helper docstring; imports and all assertions are inside try.
body = seed_lines[start:end]
seed_lines[start:end] = ['    try:\n'] + ['    ' + line if line.strip() else line for line in body] + [
    '    except BaseException:\n', '        if type(guard) is _ColdGraphRead:\n',
    '            _ColdGraphRead.invalidate(guard)\n', '        raise\n']
seed = ''.join(seed_lines)
sqlite_order = '''def _cold_sqlite_order(value):
    """SQLite ASC storage-class order without coercing malformed raw values."""
    if value is None or (type(value) is float and value != value):
        return 0, 0
    if type(value) in {int, float, bool}:
        return 1, value
    if type(value) is str:
        # Unicode scalar order equals UTF-8 BINARY order for driver TEXT.
        return 2, value
    if type(value) is bytes:
        return 3, value
    # SQLite driver columns cannot return another class. Keep opaque values
    # stable for the original typed predicates; never compare them here.
    return 4, 0


def _cold_attempt_order(row):
    return _cold_sqlite_order(row["created_at"]), _cold_sqlite_order(row["id"])


'''
source = source.replace('class _ColdRunFacts:\n', sqlite_order + seed + 'class _ColdRunFacts:\n', 1)

source = source.replace('''    def __init__(self, store, c, job, guard):
''', '''    def __init__(self, store, c, job, guard, *, raw_seed=None):
''', 1)
source = source.replace('''            require(type(guard) is _ColdGraphRead, "Exact Cold Run read scope required")
            _cold_read_checkpoint(store, c, guard)
''', '''            require(type(guard) is _ColdGraphRead, "Exact Cold Run read scope required")
            require(raw_seed is None or type(raw_seed) is _ColdRunRawSeed,
                "Exact Cold Run raw seed required")
            _cold_read_checkpoint(store, c, guard)
            if raw_seed is not None:
                _ColdRunRawSeed.check(raw_seed, store, c, job, guard)
''', 1)
source = source.replace('''            self.check(store, c, job)
        except BaseException:
            _invalidate_cold_run_facts(self)
''', '''            self.check(store, c, job)
            if raw_seed is not None:
                self._put("attempts", raw_seed.attempt_rows)
                self._put("receipt-operations", raw_seed.operation_rows)
                self._put("raw-seed", dict(key=raw_seed.key))
                self._raw_seed = raw_seed
                self.check(store, c, job)
        except BaseException:
            _invalidate_cold_run_facts(self)
            _invalidate_cold_run_raw_seed(raw_seed)
''', 1)
source = source.replace('''            for manifest, name in self._manifests:
''', '''            raw_seed = vars(self).get("_raw_seed")
            if "raw-seed" in self._raw:
                require(type(raw_seed) is _ColdRunRawSeed, "Exact attached Cold raw seed required")
                _ColdRunRawSeed.check(raw_seed, store, c, job, self.guard)
                require(self._raw["raw-seed"] == dict(key=raw_seed.key)
                    and self._raw["attempts"] is raw_seed.attempt_rows
                    and self._raw["receipt-operations"] is raw_seed.operation_rows,
                    "Cold reader raw seed attachment changed")
            else:
                require(raw_seed is None, "Cold reader raw seed attachment changed")
            for manifest, name in self._manifests:
''', 1)
source = source.replace('''                _ColdGraphRead.invalidate(guard)

    def _present(self, name):''', '''                _ColdGraphRead.invalidate(guard)
        _invalidate_cold_run_raw_seed(vars(self).get("_raw_seed"))

    def _present(self, name):''', 1)
source = source.replace('''def _cold_run_facts(store, c, job, guard):
    try:
        require(type(guard) is _ColdGraphRead, "Exact Cold Run read scope required")
        return _ColdRunFacts(store, c, job, guard)
    except BaseException:
        if type(guard) is _ColdGraphRead:
''', '''def _cold_run_facts(store, c, job, guard, *, raw_seed=None):
    try:
        require(type(guard) is _ColdGraphRead, "Exact Cold Run read scope required")
        require(raw_seed is None or type(raw_seed) is _ColdRunRawSeed,
            "Exact Cold Run raw seed required")
        return _ColdRunFacts(store, c, job, guard, raw_seed=raw_seed)
    except BaseException:
        _invalidate_cold_run_raw_seed(raw_seed)
        if type(guard) is _ColdGraphRead:
''', 1)
source = source.replace('''            return sorted(rows, key=(lambda row: row["id"]) if ledger else (
                lambda row: (row["created_at"], row["id"])))
''', '''            return sorted(rows, key=(lambda row: _cold_sqlite_order(row["id"]))
                if ledger else _cold_attempt_order)
''', 1)
ast.parse(source)
WORK.write_text(source)
delta=''.join(difflib.unified_diff(BASE.read_text().splitlines(keepends=True),
    source.splitlines(keepends=True),fromfile='a/src/sim2act/natural_spec_runtime.py',
    tofile='b/src/sim2act/natural_spec_runtime.py',n=3))
(ROOT/'delta.patch').write_text(delta)
print(json.dumps(dict(sha256=hashlib.sha256(delta.encode()).hexdigest(),bytes=len(delta.encode()),ast='PASS')))
