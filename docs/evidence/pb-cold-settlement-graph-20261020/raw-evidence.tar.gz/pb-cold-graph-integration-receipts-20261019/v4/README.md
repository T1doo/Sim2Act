# Audit-first seed read review and targeted tests (unexecuted)

`targeted-tests.patch` SHA-256: `5830e43e2f73b5476c5af9268076ba580413c0664c68edeadbd61ee938e0aca0` (8,979 bytes).

This subtask read production/tests only and wrote this outside directory. No product imports, DB/test/model execution or network calls occurred.

## Static review

The new audit-first producer preserves the original nontrial ancestry order: per-use audit prefix → extraction audit prefix → Source audit prefix → complete original native audit raw rows → complete Source audit raw rows/digest → extraction digest → use digest. Only after those original audit results does it construct Generation and Source raw seeds. No Source-V, successful typed result or receipt completion is fabricated by either seed.

The first-binding seeded path still executes the actual Generation contract/material/history/candidate, source origin/release, complete Source bound/counters/receipts/verify tail/typed proof, then extraction review/origin and per-use bound. At the original audit positions it explicitly consumes the same guard's full prior audit rows/digests. Thus static inspection found no Raw-to-Source-V shortcut. This is not runtime acceptance or an independent full P2 ACK.

Initial static review reported a narrow Generation seeded-sort boundary: its `(created_at is not None,created_at,id)` key handled NULL but could compare numeric/TEXT/BLOB classes before history typed predicates. A final read confirmed root has changed that original Generation read position to reuse `_cold_attempt_order`. The SQLite short test exercises the shared key directly; the fresh audit-first positive test exercises the valid Generation seeded branch. Neither has been executed by this subtask, and no corrupt Generation-history integration result is claimed.

The top `_ColdAuditSeed.fields()` does not include its two raw adapter object pointers. Their downstream exact guard/Run/full-row checks remain necessary and present at their own first-needed positions; the tests verify correct adapters are actually attached. The directed positive test does not establish every pointer-tampering negative case.

## Tests authored

1. The existing first-binding test retains its ordinary unapproved explicit Mock fixture (3 Generate + 2 Source; no Cold send). It adds a **second independent transaction/token/guard**, collects `_cold_audit_seed` before any first binding, then calls `_cold_first_binding(audit_seed=...)`. It repeats every original complete oracle assertion: Cold/Source complete bindings; outputs and all proved receipts; Source proof and audit/native raw fields; extraction origin/audit; per-use result; full Generation Attempts; actual typed result. It also verifies exact raw adapter attachment and same audit objects, no counters/Generation producer registry before the first binding, scope invalidation, unchanged complete 55-table snapshot, Cold still QUEUED/Attempt0, and unchanged actual Mock count 5.

The existing complete-public-ancestor tripwires remain active across both epochs. Runtime public `counters/prove_node/prove_pending/ledger_digest` are added to the tripwire set. HTTP/Async/Mock transports are all blocked after the finite fixture. The second proof is dumped to `dormant-audit-seed-first-binding-proof.json` in pytest's own temp directory.

This second epoch is a queued-Cold **read-only producer** check, even though the local guard phase is `post` to exercise the audit-first branch. It does not execute a model settlement, write group, live trial source resolver/permission edge, Cold callback, actual G1 or full P-B trial. Root's bounded full Mock gate remains separate.

2. `test_cold_sqlite_order.py` uses an actual stdlib in-memory SQLite table with typeless raw columns. It reads driver-returned mixed NULL/integer/real/TEXT/BLOB values, obtains actual `ORDER BY created_at,attempt_id`, and compares complete row identities to `_cold_attempt_order` and explicit `_cold_sqlite_order` composition. It includes numeric-looking text, Unicode and secondary-key mixed classes. No Worker, model, remote service or trial authority is used. The typeless columns deliberately retain malformed storage classes without silently applying affinity first.

Suggested root selectors (not run here):

```text
tests/test_cold_sqlite_order.py
tests/test_cold_binding_graph_integration.py::test_plain_pb_first_binding_producer_equals_public_complete_ancestry
```

## Actual checks

- stdlib AST parse of both authored complete test files: PASS.
- `git apply --check` against copied current test base and current repository: PASS.
- Product/DB/tests/models/network executed by this subtask: all zero.

`static-review-source-hashes.json` pins the read production/test snapshots. Runtime failure/success, lint/test gates, Windows/PG, semantic/human acceptance and full integration are not claimed.
