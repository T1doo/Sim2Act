from pathlib import Path
import ast
import difflib
import hashlib
import json

ROOT = Path('/workspace/pb-cold-graph-integration-receipts-20261019/v4')
BASE = ROOT / 'base/tests/test_cold_binding_graph_integration.py'
WORK = ROOT / 'work/tests/test_cold_binding_graph_integration.py'
source = BASE.read_text()
source = source.replace('''                    (use, ("bound", "review", "audit")),
''', '''                    (use, ("bound", "review", "audit")),
                    (runtime, ("counters", "prove_node", "prove_pending", "ledger_digest")),
''', 1)
start = source.index('                            assert graph.guard is guard')
end = source.index('                            dump(tmp_path / "dormant-first-binding-proof.json"', start)
assertions = source[start:end].replace('graph.', 'seeded_graph.').replace(
    ' is guard', ' is seed_guard').replace('and guard.active', 'and seed_guard.active')
second = '''                    first_guard = guard
                    # A second independent transaction/token/guard collects the
                    # original audit edge before any complete binding producer.
                    # No prior graph/facts object is passed into this epoch.
                    with store.tx() as c, pb._source_reads(store, c):
                        roles = dict(source=full.model_copy(deep=True), generate=None,
                            platform=full, trial=full.model_copy(deep=True), per_use=full.model_copy(deep=True))
                        with runtime._cold_graph_read(worker, c, dict(current=current), roles, "post") as seed_guard:
                            assert seed_guard is not first_guard
                            assert seed_guard.transaction is not first_guard.transaction
                            assert seed_guard.token is not first_guard.token
                            audit_seed = runtime._cold_audit_seed(worker, c, seed_guard, expected_cold["draft"])
                            assert audit_seed.guard is seed_guard and seed_guard.active
                            assert audit_seed.native == expected_native
                            assert audit_seed.source_audit.digest == expected_source_audit
                            assert audit_seed.extraction_audit == expected_extraction_audit
                            assert audit_seed.audit == expected_cold["audit_fingerprint"]
                            assert not any(key.startswith("run-facts:") for key in seed_guard.inputs)
                            assert not any(key.startswith("generation:") for key in seed_guard.inputs)
                            seeded_graph = runtime._cold_first_binding(worker, c, seed_guard, current, full,
                                audit_seed=audit_seed)
'''
second += assertions
second += '''                            assert seeded_graph.source_counter_reader._raw_seed is audit_seed.source_seed
                            assert seeded_graph.generation_reader.raw_seed is audit_seed.generation_seed
                            assert seeded_graph.native_audit is audit_seed.native
                            assert seeded_graph.source_audit is audit_seed.source_audit
                            assert seeded_graph.extraction_audit_prefix is audit_seed.extraction_prefix
                            assert seeded_graph.use_audit_prefix is audit_seed.use_prefix
                            assert len(mock_calls) == 5 and not blocked
                            dump(tmp_path / "dormant-audit-seed-first-binding-proof.json", dict(
                                scope="FRESH_SECOND_EPOCH_AUDIT_FIRST_RAW_ONLY_G3_SOURCE2_QUEUED_COLD",
                                trial_authority=False, cold_processed=False, blocked_ancestors=blocked,
                                mock_calls=mock_calls, audit_seed=audit_seed.fields(),
                                source_binding=seeded_graph.source_binding, cold_binding=seeded_graph.binding,
                                source_outputs=seeded_graph.source_outputs, source_proved=seeded_graph.source_proved,
                                source_proof=seeded_graph.source_facts.proof,
                                source_typed=dict(seeded_graph.source_facts.typed.typed),
                                generation_history=seeded_graph.generation_history,
                                extraction_origin=[seeded_graph.extraction_origin[0].model_dump(),
                                    *seeded_graph.extraction_origin[1:]],
                                use_value=[seeded_graph.use_value[0], seeded_graph.use_value[1].model_dump(),
                                    *seeded_graph.use_value[2:]]))
                        assert not seed_guard.active
'''
needle='''                        assert not guard.active
                after = snapshot(store)
'''
assert needle in source
source = source.replace(needle, '                        assert not guard.active\n' + second +
    '                after = snapshot(store)\n', 1)
ast.parse(source)
WORK.write_text(source)

sort_test = '''"""Small actual-SQLite storage-class order boundary; no Worker/model execution."""

import sqlite3

from sim2act import natural_spec_runtime as runtime


def test_cold_attempt_order_matches_actual_sqlite_mixed_storage_classes():
    # Typeless raw columns retain corrupt storage classes instead of applying
    # affinity before the comparison. Sort actual driver readback values.
    pairs = [
        (None, None), (None, -1), (None, 0.5), (None, "2"), (None, b"2"),
        (-7, "low"), (-3.5, "real"), (0, "zero"), (2, "integer"), (2.0, "real-tie"),
        (4, None), (4, -2), (4, 0.5), (4, "0"), (4, b"\\x00"),
        ("10", "lexical"), ("2", "numeric-looking-text"), ("é", "unicode"),
        ("𝄞", "astral"), (b"\\x00", "blob-low"), (b"\\xff", "blob-high"),
    ]
    with sqlite3.connect(":memory:") as connection:
        connection.execute("CREATE TABLE raw_order (seq INTEGER PRIMARY KEY, created_at, attempt_id)")
        connection.executemany("INSERT INTO raw_order VALUES (?, ?, ?)",
            [(index, created, aid) for index, (created, aid) in enumerate(pairs)])
        raw = connection.execute("SELECT seq, created_at, attempt_id FROM raw_order").fetchall()
        expected = connection.execute(
            "SELECT seq FROM raw_order ORDER BY created_at ASC, attempt_id ASC").fetchall()
    rows = [dict(seq=seq, created_at=created, id=aid) for seq, created, aid in raw]
    actual = sorted(rows, key=runtime._cold_attempt_order)
    assert [row["seq"] for row in actual] == [row[0] for row in expected]
    assert len(actual) == len(rows) == len(pairs)
    # Explicit scalar-key composition must agree with the fixed Attempt key.
    assert actual == sorted(rows, key=lambda row: (
        runtime._cold_sqlite_order(row["created_at"]), runtime._cold_sqlite_order(row["id"])))
'''
ast.parse(sort_test)
(ROOT / 'work/tests/test_cold_sqlite_order.py').write_text(sort_test)

patch = list(difflib.unified_diff(BASE.read_text().splitlines(keepends=True),
    source.splitlines(keepends=True), fromfile='a/tests/test_cold_binding_graph_integration.py',
    tofile='b/tests/test_cold_binding_graph_integration.py', n=3))
patch += difflib.unified_diff([], sort_test.splitlines(keepends=True), fromfile='/dev/null',
    tofile='b/tests/test_cold_sqlite_order.py', n=3)
text=''.join(patch)
(ROOT / 'targeted-tests.patch').write_text(text)
print(json.dumps(dict(sha256=hashlib.sha256(text.encode()).hexdigest(),bytes=len(text.encode()),ast='PASS')))
