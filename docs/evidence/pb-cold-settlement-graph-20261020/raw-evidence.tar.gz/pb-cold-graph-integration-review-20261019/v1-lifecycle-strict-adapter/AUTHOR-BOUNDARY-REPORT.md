# 第四批单入口集成：runtime-only 边界不足（未启图）

结论：在实际 `dc34ce4b1311810e27cd33a0cd156b6f84333666` 源码上，**仅修改 natural_spec_runtime.py 不能同时满足“显式同 epoch 全事实、共用唯一谓词、无 fallback/shadow/完整祖先重放、每个敏感内部回调后先拒绝漂移”**。本轮按委派第 5 项要求先报告确切接合缺口；没有修改产品或测试，没有启图，也没有执行短门或完整 P-B。不能把第三批基础叶 ACK 当作完整生产者已具备。

## 已核实际状态

本机及 actual remote 都是上述完整 SHA，分支 `dev/production-trial-stages-20261018`，dirty/ahead/behind=0，约18GiB可用。没有其他仓库写入者；独审仅写自己的新报告目录。现有 codex-index-refresh.lock 只观察未删除；未发现适用本地 AGENTS.md/SKILL.md。`preflight.json` 保留原始查询。`baseline/` 的13个相关文件逐字节取自该 Git SHA并与工作树相等；`CALL-INDEX.json` 是56个原函数/类的静态 AST 调用索引，不能冒充动态递归次数或完整图。

## 已确认的三个决定性切口

| 切口 | dc34 实际位置与阻塞 | 最小必要设计（尚待扩大范围授权） |
| --- | --- | --- |
| Binding → Release/per-use 的严格输入到不了消费点 | runtime 1254 调 spec.bound；spec._bound 806 调 app_jobs.load_binding。后者签名 520 没有 strict/checked-facts 输入，600–603 只把 `_origin_out` 输出交给 read_release，629 再硬调 pb_use.bound。lifecycle 594/606 已有 `_reuse_origin` 透传，但上游不传它。 | app_jobs.py 在原 scope/queue/AppRun/request/frozen 顺序后新增 exact 私有 checked Release/per-use 输入或局部 adapter，保持4个已抽叶与全部原 gates；只在完整证明后透传 exact origin，不接受 dict 许可，不用旧 origin_out 反向当事实。pa_spec_apps.py 相应增加完整 bound 的 facts 接合，原公开默认路径依旧完整验证；不能由 runtime 复制 load_binding/_bound 的剩余内联谓词。 |
| 完整 nontrial/trial guard 仍强制递归 | pa_spec_apps._bound 883–893 的完整 Goal/frozen/resource/runtime/模式短路谓词尚内联（generation_mode 在892实际读库）；909 调完整 audit。_commit_guard 1234 调 audit_fingerprint，1250 调 trial.check_commit。trial 210/227–229→_admission 158→policy.check_run→gate._run_context 940→_stage_current；gate 415 再调 pa.bound；_stage_current_bound 494/520 等又实际取 Gen/Source/accounting。 | pa_spec_apps.py 抽完整 bound/完整 audit/原 nontrial guard 的显式 facts 叶，在原短路位置保留 generation_mode 与每个 fresh授权/当前 source/Run/期限边。trial/gate 在各所属文件增加“已完整同 epoch Binding/Generate/Source/J/B事实→原完整谓词/Authority”的私有适配；P pair/seal 不替完整Authority。保留各原完整公开入口默认路径；图子节点不回 public verifier 补证。 |
| lifecycle 的 apps 外回调/早返回没有 strict 边界 | owned_release_pointer 379/380 调两个 gate后读 Release，385 own_project；_read_release 607/613/615/628–637/647 有 owned/immutable/family/schema调用，609–612 archival、615–616 full-report、643–646 execution_source会早返回。apps649之外，650 validate_source_bytes 内部 authorized_read、652/655变体验证、663/664 independent/index仍在后续执行；没有 exact graph/current检查。 | 必须另授权 lifecycle.py：新增私有 strict adapter/固定检查点，或在该所属文件提取非递归事实步骤供 runtime 显式按序调用。先 owned scalar 身份/家族与权限，排除 archival/execution_source/full-report/logic/correction/project/offline/qualified等非目标；严格模式不得走这些早返回。每个敏感 callee 返回后、下一次正文/事实消费前固定 current 并实际重核必要原权限/来源/时间。不能只在 runtime 包 read_release 前后，也不能在 runtime 复制该文件原谓词。 |

这是**必要接合下界**，不是“加三个可选参数就已能启图”的承诺；下面的完整事实子链也必须闭合之后，才能给最终集成授权。已抽基础叶只覆盖各局部原谓词，未抽/未接的 inline 条件不能被省掉。

## 仍需接通的完整事实子链（精确现有硬边）

- `pb_natural_uses.review:347–392` 仍构造/编译有效候选、按原位置取 Grant状态和 base_audit；`base_audit:102–105` 直调 pb.audit_fingerprint。现 `_review_identity_from_facts`、`_bound_review_from_facts`、`_audit_from_facts` 不包完整 review/base audit。需要该所属文件提供完整 reviewed 结果的 facts 步骤，保持 target→expand→compile→Grant→base audit 及PA/PB原分支顺序，不把 frozen approved_grant_state 当当前权限。
- `pb_natural_specs.verify:475` 直调 review，`review:405` 直调 source；verify 的 marker/meta/request 与候选/name尾部仍内联。`audit_fingerprint:496` 直调完整 source_audit，`_source_audit:193` 又取原应用完整 audit，随后收集包括 Run/contract/Binding/AppRun/typed/Release/全部Attempts/ops/intents/effects/events/reservations/源marker/seals/Goal版本的完整行列表。需要在该所属文件抽可消费完整 Source/G/raw审计事实的唯一谓词与摘要构造，保留所有多重集/排序/基数/名称短路，不能只传一个未证明的 hash。
- `natural_source_archives._source_prefix:216` 直调完整 `_source_stage_current`；`_resolve_trial_source:376` 取 prefix，389 再调 pb.verify。原 Source full Authority/成功结果/提取 proof 和 NS 双正文必须显式接通，不能用已经看到 Source/Cold阶段或同app ID短路。body/exchange事实叶已存在，但不包含 prefix 的完整Authority与提取绑定。
- `pa_trial_dispatch._admission:160` 仍调 `_pb_source`（425→443→archive resolver）；`_journal_chain:1448` 仍通过 _journal_slot 完整解析 policy/ledger，之后 capture/NS/controller/usage/actual Attempt 成链。已有 attempt/stage usage/source archive 叶不是完整 J/B。需要所属文件显式接完整 ledger、每实际aid的独立B事实；fresh `_journal_source:161` 原边继续实际调用，绝不缓存 ALLOW。

- `goal_applications._history:497` 仍内含完整三次请求重建、初始 messages/frozen/Source、反馈与响应/锚点校验；`_verified_candidate:814–818` 调 source/history/parse_candidate，而 `parse_candidate:729` 再取 source。第一批只抽候选最后一次/validation seal/计数尾叶，并没有整个无 IO history/parse 核心。完整 G 节点还须在该所属文件拆出这些剩余唯一谓词，或证明现有已抽叶已覆盖全部核心；不能把公开历史缓存命中算成图生产者的一次完整解析。None 与显式同值 Limits 的原 fallback 语义必须分开。

因此可行的最小后续工作是**补私有接合**：app_jobs / pa_spec_apps / lifecycle 三个决定性边界先抽与独审；然后仅在以上实测硬边所属的 pb_use、pb、gate/trial/archive 补完完整 facts 接合并逐边静态证明无 public 祖先重入。goal/text/policy 已有叶不因此新增权限或改变默认路径。是否能够进一步减少扩文件数应以实际共享谓词证明为准，当前没有把“至多 N 文件”作为已闭合结论。需要父侧明确范围后才可改这些产品文件。

## 单入口与验收设计保留

最终仍应在 receive/archive/原renew之后、原结算TX开头创建G0；按原次序 lock_live→版本/created/deadline→平台bound角色→首次完整guard→enabled→pending receipts→RECEIVED/meta→parse→usage→schema→receipt→第二完整guard→原五写。第一写使所有G0事实失效；五写原顺序、中间Attempt SELECT、单一外层TX不变。

G1从最后实际写epoch重新读取**全部**事实、完整历史/正文/accounting/权限；不接G0 Binding/parsed history/Grant/ALLOW/完成位。保留 postguard后立即 pin version/created/deadline及source identity/期限，再平台bound/receipts/current aid/journal/Operation/frozen及独立Limits/live/消费者的原逻辑顺序。原 _ModelSettlementRead.check/binding_key/full inputs 不削减；现有尾continuation必须等新G1完整首证后才能用，不能伪造READY先跳过check_commit。

source/generate/cold runtime与提取基稿/per-use candidate、Source/Generate/platform/trial/per-use完整六维Limits及None分别成facet。任何图完成态只由完整生产者发布；strict pin只防漂移、不证明完整或fresh授权。所有敏感回调后及最后边界实际核五元权限、批准、fresh固定source、Run/version/fence/stop/lease与全部期限。

之后先短防漂移/权限/跨写/首错对照与独审；确认边界闭合再仅一次有界完整P-B显式Mock集成。完整测须按实际采样保留全SHA、原始日志、语义分类、各阶段实际Mock数、G0/五写/G1/最终guard分段和递归/指纹计数；计数只能passthrough，禁止删检查、改租约/预算/权限。当前没有执行该门，不能先跑完整链碰运气。

## 本轮动作/阻塞状态

- 待执行动作：在 `src/sim2act/natural_spec_runtime.py` 启用第四批完整单入口并执行一次完整Mock集成。
- 状态：**未执行；因明确文件授权边界待扩大而阻塞**，不是工具自动审批拒绝，也没有不确定已执行的写/模型动作。
- 已完成：实际Git/远端/容量/单writer检查、dc34十三文件原始Git快照、56函数AST硬边索引、具体接合下界与最小设计、独立只读复核（报告单独封存）。
- 未改生产/测试/Git引用；无新提交或推送，HEAD与remote继续dc34；最终dirty/ahead/behind另存实际查询。
- 本轮产品/DB/短测/Mock完整集成/真实模型调用均未执行。各阶段实际Mock数量、语义成败、分段耗时、递归/指纹运行计数 **NOT_RUN/UNKNOWN**，不写成0或通过；真实模型未调用。
- 历史完整P-B仍 FAIL_NOT_ACCEPTED，指纹独占成本仍UNKNOWN；旧满盘缺失最终独审未补回。Windows/PG/远端CI/真实语义场景人工验收均没有新证据。
