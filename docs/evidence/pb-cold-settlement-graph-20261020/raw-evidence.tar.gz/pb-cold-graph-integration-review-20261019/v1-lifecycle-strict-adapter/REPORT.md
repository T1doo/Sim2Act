# lifecycle 严格边界：13 文件内可实施的最小私有拆法

基线 `dc34ce4b1311810e27cd33a0cd156b6f84333666`。父侧已批准原12文件加 lifecycle.py 的最大13生产文件边界，根线程唯一写入者。此报告给可直接实施的接合建议，**不是再请求设计循环，也不是冻结候选代码 ACK**；后续按实际分段源码与短门独审。审查者未改仓库、旧 seal 或作者原件，未导入/运行产品、测试、DB、模型、benchmark 或网络。

作者 BOUNDARY-REPORT 的三个决定性切口与本次源一致。已读版本 SHA256 为 `890c805f6e2efafa6073c4aa5bd51066a7820dd782cbb63889c0ae27780c8c3f`；其“必要下界，不是加三个参数即可启图”的限定正确。本次批准的13文件足以容纳下面的 lifecycle/apps/private graph 接合，不需要改 Store、tools、text_continuations、HTTP 或新增通用框架。

## 立即采用的拆分

推荐**前置连续性 pin → lifecycle 前缀 → apps 前缀 → 完整角色 origin → exact origin 消费 → lifecycle 后缀**。不要把完整 origin 延迟为任意 resolver/check callback；这些阶段由 runtime 单入口显式调用。

### 1. 前置 read guard 只固定连续性，绝不声称 origin 已完成

`apps._ColdGraphOriginFacts` 当前构造器要求完整 origin 四元组，且 constructor 会立即 `.check()`。完整 Source/Generate proof 尚未得出时，不可用占位 tuple、假 manifest、空 origin 或先设置 READY 后补字段来启动它。

在已批准 runtime/apps 内复用本次目的专用图的固定 read pin：固定 exact Worker/Settings/Store/原 engine/controller、stop/transport/worker id、c/实际 SQLAlchemy TX/SQLite driver/thread、token/epoch/total_changes、nonce、完整初始 inputs 与五种角色完整 Limits/None。此 pin 可以处于 BUILDING，不含 origin 完成位、权限或 stage 许可。若图已有同样固定 pin，直接复用它的固定方法，不再造平行框架。lifecycle 只接受 exact 目的专用私有类型并调用固定 current 方法，不接受任意 callable/check/resolve 回调，也不靠 c.info 全局图或 monkeypatch。

它在原 scope/owner 标量与权限顺序内取得 Release，并将实际返回行及其嵌套 draft **一次固定**到对应角色。加字段只能在 BUILDING 的明确未使用槽；先检查既有输入仍 current，再登记该次实际值，禁止覆盖/重定向。登记只固定事实身份，不意味着 own_project、完整 Release 或 origin 已验证。每个真正权限/来源/期限仍在原位置实际执行。

### 2. lifecycle 抽前缀和后缀，复用同一个实际 Release/draft

现 `_read_release` 的第一句是 `r=owned_release_pointer(...)`，随后 s=r['snapshot']、draft=s['draft']。把原代码在 apps 校验处切开，共享私有前缀/后缀；默认入口按原顺序调用，保留原早返回。图入口在两段之间构造 origin，**不重新 SELECT Release**。

建议接口形状（名字可调整；不是新增许可 DTO）：

- `_read_release_prefix(..., _graph_read=None)`：保留原 owned pointer、immutable pointer、report/logic/family/schema 检查，返回该次实际 r/s/draft。默认路径仍保留原 archival/full-report/execution-source 分支；exact graph 路径只允许已选择的普通自然目标，进入后发现变体/漂移直接拒绝。
- `_read_release_suffix(..., r, s, draft, ..., _graph_read=None)`：在原位置执行 validate_source_bytes、原必要后续变体/independent 检查并返回同一 r。
- `owned_release_pointer`、`immutable_release_pointer` 只增加私有可选 guard/checkpoint，或提取与默认共享的步骤；原普通调用不改变权限/正文/错误顺序。

`r/s/draft` 是事实值，不能作为“已授权 Release”任意调用凭据。graph 的 exact 类型/nonce/阶段/current pin 约束私有消费；公开默认入口仍完整读取和验证。

关键对象身份：完整 origin 得出后，用**这个实际 Release 的 `r['snapshot']['draft']` 对象**创建 `_cold_graph_origin_facts`。当前 strict 要求 `draft is self.draft`；另一次 SELECT 即使全字段等值也可能解码出新的嵌套 dict，不能因此放宽为 `==`，也不能把 per-use effective draft 偷换成提取基稿。每个 source/generate/cold/平台/trial角色单独 facet，保留该次实际 Limits 对象及完整向量。

### 3. apps 也在原 origin 位置切开，不提前验证祖先

原 apps 顺序是 draft_gate→own_project→candidate fingerprint→source family→compile_preview→spec family 判断→verify_origin/复用→输出。若 runtime 先计算完整 Source/Generate origin，再首次调用现 strict validate_frozen_candidate，就把原本较后的 origin 错误和受保护读取提前到了 draft gate/compile 之前；这不满足原首错和权限顺序。

在 apps 所属文件抽共享 `_frozen_candidate_prefix` 和严格 `_frozen_candidate_from_origin`（设计名）：

1. prefix 在该次实际 draft 上执行原 draft_gate、own_project、candidate hash、source-family、compile、spec classification，每个可能回调返回后先检查前置 read pin，再消费；得到该角色实际 manifest/action/report。
2. runtime **在这个原 origin 语义位置**显式生成完整 Source/Generate/PB origin，保留其全历史/typed/result/NS-controller/accounting/独立 Limits；不调用公开 ancestor verifier 兜底、不 shadow。
3. 原 scope/role inputs 一直 current 后才构造 exact `_ColdGraphOriginFacts`，包含完整 origin 和该次 prefix 结果及完整指纹（或由图的显式只读输入槽固定它们）。完整事实在成功后才发布，不能仅用“prefix完成”的标志替代其全字段。
4. 严格 consume 用同一 draft/limits/prefix/origin current pin 继续原输出；不复跑整个公开前缀、不回 public verify_origin。默认/dict 路径保留原匹配和 fallback，不被图严格错误处理改变。

这不是新增 Authority：prefix 的编译结果、origin 四元组和局部连续性都不授予发送、写、阶段批准或 Grant。完整 origin 的 producer 前置责任继续存在；初次和 W5 后各自从真实数据全量取得。

## lifecycle 必须放置的 current 检查点

下表是最小闭合位置。检查在 callee 正常返回后、下一次消费之前执行；callee 自身抛异常则立即保留原异常对象，finally 只清理，不用新检查覆盖它。

| 原位置 | exact graph 检查要求 |
| --- | --- |
| 调 owned_release_pointer 前 | 前置 read pin current，原项目/角色和连接上下文仍正确 |
| owned pointer 内 reject_legacy / report_gate / release_gate 之后 | 每个 callee 返回后检查，再读/跟随 Release；不能仅等整个 owned pointer 返回 |
| Release SELECT 返回后 | 在消费行/嵌套正文前检查；真实查询已有 owner predicate。把实际 Release/draft 绑定一次，不能用将来重查的等值 draft替代 |
| store.own_project 返回后 | 检查实际绑定的 Release/输入没漂移；这次 pin 不替代 own_project 的真实授权 |
| immutable_release_pointer 内 approval SELECT 之后 | 检查后再消费 approval payload、hash、consumed 与 r snapshot；原完整 immutable 谓词保留 |
| full_report.release_gate / logic trace / validate_snapshot（默认分支）之后 | 默认行为原样；graph非目标在进入前分流，进入后识别到变体就拒绝，不执行早返回成功或 fallback |
| validate_family / validate_logic_family / csv_revision.validate_family 后 | 逐个 current，再使用 snapshot/dependency_lock。不能合成“全部 family 调完再检查” |
| record_schema 后 | current，然后进入 apps 前缀；禁止已经生成 origin 后才检查首次 schema |
| apps 前缀/完整 origin/strict consume 每段返回后 | 图 read pin 与 exact origin pin分别检查；绑定角色、draft identity、所有完整 Limits 一致 |
| validate_source_bytes 后 | authorized_read 回调正常返回即检查，再调用其后 csv/logic/independent；不能只在 _read_release 最后检查 |
| 后续 csv/logic 校验 / text_logic_reuse.independent / verify_release_index 后 | 原必要调用保留，每个返回后检查，再消费返回值或返回 r。对独立函数的 bool 返回也要先检查再据此分支 |
| 最终返回及 scope 退出 | current；scope异常永久失效；正常完成不赋予下一 epoch/下一次调用复用权 |

`validate_source_bytes` 内部 authorized_read 返回后无其他值消费，可以在它返回处立即检查；但 owned_release_pointer 和 immutable_release_pointer 内部还有后续消费，需要在其内部增加上述检查点，外层单个检查不够。这些修改均在已批准 lifecycle.py 内。

SQLAlchemy/Store 的受信事务协议是边界；实际写/失败写由原 epoch/token 失效，driver.total_changes 仅补充实际行写 pin。不要宣称能防任意恶意 Python 原生 COMMIT/re-BEGIN 或无需修改任何回调所在内部函数就拦住其内部每一条指令。

## 非目标与早返回

archival_software、full-report、execution_source、natural_logic_source、correction/project/offline/qualified 等应按原 owned scalar/权限 gate 在严格图进入前分流原实现。不要在尚未授权时先读完整 Release/candidate 来做全局 eager eligibility，也不要对所有默认调用新增严格拒绝。

一旦 exact graph 进入，任何变体 marker 出现、移除或变化、callback drift、缺完整 origin 或 epoch/连接/角色变化，均终止该图并保留原错误/回滚；不准因为曾经不适用而在中途退回旧 verifier。针对 full-report/execution_source 的原成功早返回，严格分支必须在它之前确认非目标并拒绝，不能只靠 factory 最后一个 check，因为 factory 当前不证明分支已完成 origin。

普通 P-B Cold Release 的提取基稿和逐次有效 per-use candidate 即使 app ID 相同也不是同一事实角色。lifecycle/apps 校验实际 Release draft；pb_use 后续有效 draft/新材料/完整 Goal/approvalGrant 状态和 compile角色必须独立完整验证。不要通过重绑 origin draft来省掉这一步。

## 最小必要的定向门建议（本审未执行）

- 旧 default/dict 路径以 AST 还原/调用顺序短测证明共享拆分无重排；严格正向 spy确认生命周期前缀→apps前缀→origin完整生成→consume→sourcebytes→后缀，公开 verify_origin/fallback调用数0。
- 每个新增 checkpoint 以顺序观察覆盖；挑实际 own_project 与 sourcebytes 回调漂移分别验证在下一个 callee/受保护消费前拒绝，并保留原回调异常对象。不要将全部 callback矩阵扩成恢复/故障矩阵。
- 使用实际 SQLite Release返回行，断言 factory draft 与后续消费 draft is 同一对象；等值独立 draft、缺 origin、prefix/完整角色Limits改变均拒绝，不能靠字典宽松相等。
- strict前置 pin覆盖 origin未完成阶段的 NoOp/失败写，origin完成后复用原 exact形状/原engine/nonce/退出测试；G0/W5/G1的原子与全量新首证由后续图集成门验证，不能把这几个生命周期单元当完整PB。
- 一个非目标早返回样本保留默认成功语义，exact图进入后同marker漂移拒绝；不需要为这处API再跑旧长Cold或650秒恢复矩阵。

这些是实现接受所需的具体可执行边界；根线程可在已经批准的13文件内直接按共享主体、显式阶段推进实施，不需再等一轮泛设计。静态建议不替代冻结源审查：后续重点检查没有用“完整 origin”占位、没有改变实际 draft identity、没有提前 origin/compile错误、没有漏内部 checkpoint、没有绕 fresh权限/source/Run/全部期限。

当前所有动态计数、耗时和性能成效为 NOT_RUN/UNKNOWN；完整 P-B 历史仍 FAIL_NOT_ACCEPTED。本次不提供运行通过或性能 ACK。
