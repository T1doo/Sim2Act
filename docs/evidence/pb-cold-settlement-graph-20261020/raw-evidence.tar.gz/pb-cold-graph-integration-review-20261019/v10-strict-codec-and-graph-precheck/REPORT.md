# v10 局部门补充与完整图静态预审

结论为 **LOCAL_GATES_ACK / FULL_GRAPH_P2_PENDING**。本报告补齐 v9 后的实际 3+1 局部门证据，并保留完整 G0/W5/G1 尚未接受的状态。没有完整图、完整 P-B、性能、真实模型、Windows、PostgreSQL或远端 CI 接受结论。此处没有执行产品、导入产品模块、运行测试、访问数据库或网络；仅读取源码、Git 原件和已结束 receipt/JUnit，使用标准库 AST/哈希生成本报告。

## 输入身份与证据范围

`SOURCE-INDEX.json` 是本轮初始14文件逐文件观察；`FOLLOWUP-SOURCE-INDEX.json` 是后续5文件的逐文件观察。父线程当时仍在修订，二者都不代表冻结全树或最终候选。所有后续改动的最终安全接受仍需要明确冻结源码和相应门。没有改动 v9 或更早封存目录。

`strict-codec-v1` 标准 pytest 3 PASS/0 skip（JUnit 4.756秒，外层7.919437秒）；`codec-foreign-limit-v1` 标准 pytest 1 PASS/0 skip（JUnit0.412秒，外层2.684476秒）。两组均 exit0、未超时、122项输入前后相同，其 apps.py 与 natural_spec_runtime.py 全文件哈希均等于 v9 已审版本，见 `LOCAL-GATE-V9-BRIDGE.json`。因此补齐 Origin strict 通道实际局部回归，以及 Limits 外来键不得触发 hash/equality 的指定反例。不扩大为全图或任意恶意 Python/原生事务逃逸保证。

另读取后续已闭合门：`incoming-only-codec-v1` 66 PASS；`typed-drift-v1` 20 PASS；两者 exit0/0 skip、122项输入前后相同。各自针对各自 receipt 所列源码，不把不同批次相加为一组唯一90项测试或最终候选全绿。原始 stdout/stderr/JUnit/receipt 已复制在 gates；汇总及所有 test 名见 `GATE-SUMMARY.json`。

`first-binding-fresh-v3` 标准 pytest 实际1 FAIL（外层116.685359秒，122输入稳定）保留。失败发生在新增 extraction draft 与 review base 的同形全字典假设。父线程报告本轮实际 Generate3+Source2 Mock/Cold0；本审阅没有读取DB独立认证该发送计数。此失败不回填为 G1/full P-B通过，修正后的当前代码尚未由本报告认证。

## 已核结构与局部成立项

1. 初始观察的 `advance_model` 中 W5五个DML和原finalAttempt读回、已提交 NS_RECEIVED 接收事务、DomainError拒绝 handler，与基线 dc34ce4b1311810e27cd33a0cd156b6f84333666 三组 AST逐字结构相同，见 `W5-AND-RECEPTION-AST.json` 和对应完整提取文本。不能据此认为新私有路径的异常一定仍进入原 handler。
2. G0 scope 在原W5之前关闭；五写保持同一SQLite事务。G1在写后新 epoch/read-scope重新建立，先 post guard，再完整 binding/receipts/current journal 和 ModelRead消费者。原 ModelRead 完整输入/binding/身份校验未删，其 live 末尾仍有实际 fresh时间门。跨写只传原调用意图和反漂移比较字段，不能将G0 permit/facts作为G1 Authority。
3. 五角色完整 Limits 保持独立，不能因同值或当前同role而合并 worker4/stage3键。P为配对DTO，不能被当作完整stage Authority。实际Controller/NS bytes、使用/账本基数和每个当前 Attempt journal 的完整证明不能由局部DTO或摘要替代。
4. incoming-only add 的安全归纳可成立：旧根在入口完整检查；仅新增根→incoming一条边；incoming完整受控类型/循环校验且在任何memo/type分派之前以`is`拒绝实际根，覆盖dict/list/tuple/RowMapping暴露值。旧图和incoming分别无环且incoming不可达旧根，则新增边不会成环。每次仍完整 bytes重pin，不是持久结果缓存。共享DAG阳性允许；任意并发恶意Python修改或绕过Store的原生事务操作不在此保证内。

## 必须闭合的P2与本轮建议

**P2-1：实际typed参数不得仅用Python值相等。** 初始 `_trial_typed_guard` 的完整model_dump与raw使用`==`，会接受1/True、1/1.0等相等数值而不同类型；部分 per-use prefix/scope/review 同样以dump快照相等检查实际model，CGR只pin分离后的raw时不能替代typed连续性。建议固定模型class的完整dump逐层exact类型比较，dict所有键先exactstr，list/tuple区分且保序，未知类型拒绝；只保护拥有的typed子树，不复制全root验证。父线程已加入共享`_trial_typed_equal`并对trial路径跑20例，但其余自有typed子树修订仍须最终冻结复审。当前补充源码仅作为修订观察，不签全部闭合。

**P2-2：私有图绕过旧controlled边界时，必须保留错误归属且不吞guard异常。** 旧pb.verify受controlled保护，sealed ExtractInput或Metadata解析失败会映成VERSION_CONFLICT；新私有路径绕过旧装饰器时raw ValidationError可越过advance_model内部DomainError拒绝分支，改变已收到事实的拒绝/CAS归属。已观察父线程新增窄 `_persisted_extract_input` / `_cold_extract_pair`，把真实ExtractInput持久解析映射与IO/checkpoint分开，方向正确；后续 Metadata pair、owned malformed字段边界仍须核全。相反，整个 `_cold_receipts` / `_cold_verify_job_from_receipts`套controlled可能把新checkpoint ValueError改成DomainError，也必须用原异常identity反例闭合。不能以包住整个图的blanket catch解决。无动态复现由审阅者执行。

**P2-3：最后有限时间采样必须晚于昂贵完整pin/scope退出。** 初始commit先取`end=time.time()`，随后完整pin、序列化、记录output和scope finalcheck；若此间跨原lease/Run/contract/source截止，G0可能在过期后进入W5（G1仍可拒绝并回滚，未证明非法VERIFIED提交）。建议原finite完整tuple纳入固定second trial-output全pin；所有正常finalcheck/序列化/with退出后、紧贴W5再实际读取time/stop并核所有原截止，包括已pin的meta.deadline与node/run_seconds，不增加IO、不改变任何原数值。异常退出只清理并原样raise，不能在finally替换异常。G1原`self.check(); fresh time<min(all deadlines)`保留。父线程已接受方向，待当前diagnostic结束后修订，未签实测效果。

**已知组合缺陷而非授权放宽：role/header和draft schema。** audit三字段header与job四字段header不能共用同一个固定完整pin键；修订应按固定audit/job角色分别精确字段集合，保留各自全部输入，未知形状拒绝，guardNone默认行为不变。实际native draft全row含name/created_at，而Release冻结projection合法不含它们，不能新增全dict同形要求。关系应为冻结Release全部原keys均存在并严格类型等值；native/Release两份完整raw仍各自pin，不能白名单丢字段或`.get(None)`掩盖缺键。剩余相等比较需先说明两侧来源是否同schema，不以重复长前缀逐项猜测。

## 限制与下一步

本报告没有最终冻结树、full PB或性能ACK。全图完整input fingerprint（含codec/strict origin/ModelRead）必须保留；当前按阶段独立计时仍有UNKNOWN，66P或查询/字段数量不能外推实际30秒事务保证。父线程的pure codec bench/不同CPU并发profile均不由本报告签性能接受。下一步应先冻结上述具体修订和callback drift/原异常identity/最后时钟的短门，再按父级已授权的唯一有界实际诊断推进；本报告不批准任何额外长链、真实模型、Grant、TTL/lease变更或生产部署。
