# 固定 typed cohort 重复完整检查的静态设计意见

结论：**可按本文边界实施共享纯core提取；不是当前实现、性能或完整图ACK。** 当前source仍为父线程WIP，本报告仅逐文件观察两个文件并解析AST；未执行产品、测试、DB、模型、网络或benchmark，未写仓库。

现有完整态在所有journal/accounted/stage/context都已建立时，`_base` 的一次完整CGR检查加嵌套typed helper入口检查，调用图合计约13次；`check`通过`_dump(context)→_base`再来同轮，audit_seed.check另一次，合计约27次。该数是满足所列条件的源码路径计数，非采样次数、耗时或性能保证。字段未建立时会少于此数。完整input bytes/key仍必须每次边界检查，不能删原ModelRead.check、binding_key或_model_inputs。

建议最小拆法：

1. 抽固定`_trial_typed_values(models)`，只承载现有exact期望class、完整fixed-class model_dump及type-aware全raw比较；原`_trial_typed_guard(parent,models)`仍先调用parent再执行该纯core。禁止用bool/int、tuple/list宽松相等替代。
2. journal/accounted/frozen/extraction/stage的raw装配各抽无IO/回调的私有core。原各外部helper仍先完整`_graph_trial_pin`再调用同一core；stage core只调用子core。不得通过`_pinned=True`、scope许可位或旧snapshot跳过入口责任。
3. coordinator `_base`自己完成完整CGR.check后，直接执行这些pure core和完整typed cohort验证，不再调用同区间带pin的外部wrapper。可在纯区间末追加一次完整CGR.check收口；这仍能去掉大量重复，不引入结果缓存。
4. `check`中context保留其完整record身份和固定`RunCheck`全值比较，使用同一纯core，而非调用会再次`_base`的通用`_dump`。`audit_seed.check`暂保留；通用`_read_fields`/`_fields`以及其它可能回调的方法不能因本次结论一并免检。

必要安全边界：

- 现有代码不能原样当pure core：`dict(run)`、`dict(checked)`、一般Mapping迭代、未知`fields()`或实例`model_dump()`可能执行自定义代码。先exact类型门，再字段访问/迭代/相等；exactdict安全键及完整受控嵌套containers，SQLAlchemy RowMapping用既有exact类型和受控metadata投影；不调用任意Mapping协议。固定model调用应为`ExpectedClass.model_dump(actual)`，所有实际嵌套值也必须在已知固定模型/受控JSON范围，不能仅凭outer model类型即声称无回调。
- 完整raw、每actualaid、多重集、顺序、全部bytes和角色Limits均保留。models重复合并仍只按原三元组identity语义，不以数值相等合并不同角色或模型对象。
- 无IO、权限读取、解析/编译/producer或未知callback可夹在被合并的完整检查之间。原owned callee返回后先pin再消费/下一IO的边界保持；`_graph_trial_produced`首次结果的前后pin仍保留；原fixed source、当前审批、全部Grant、Run谓词及最终实际时间门完全不变。
- 首次/写后全新epoch和fullfacts仍完整建立；本提取仅同次纯计算区间，不能持久存储ALLOW、typed校验成功标志或使用旧token。任何异常仍invalidate真实knownexact对象并原样抛，不额外包controlled。
- 如果某个model序列化或owned字段收集无法证明上述pure前提，应保留其原返回后pin；不能以“通常无callback”推导可以合并。

最小定向证据建议（由唯一writer另行实施/执行）：原/新cohort完整输出和拒绝等值，嵌套int→bool/float与list↔tuple拒绝；实际RowMapping全字段保留；未知Mapping/碰撞键/未知model子类回调计数为零且sticky；原外部入口及任何真实callback后的pin计数保留。可记录同纯core区间完整CGR调用次数减少，但不能把它等同端到端30秒事务通过。现有Models/源权限/期限回归无需为统一manifest机械重跑长PB矩阵。

本报告没有发现该受限提取方向本身必须阻断的新P1/P2；直接删当前wrapper中的检查而不抽共享纯core/不补exact形状门则仍不满足上述设计条件。具体代码需后续冻结差异与短门独审。
