# 完整图冻结前静态阻塞记录（v13）

分类 **FULL_GRAPH_CODE_ACK_BLOCKED_PENDING_NARROW_CORRECTIONS**。不是运行接受或最终候选独审；父线程仍准备窄修。本审阅未执行产品/测试/DB/模型/网络。唯一微例为Python标准库JSON编码，与可见db.fingerprint参数相同，不是DB持久化试验或性能benchmark。

1. **P2：第二G0 guard的Run行形状必不等。** _ColdTrialGraph._recheck使用gate._run_context_row（13列）与prefix job的完整Run行比较全_model_inputs。job由_commit_guard_prefix→lock_live→Store.guard(select(runs))取得，真实多出goal/context/result/error/fingerprint等字段，故必然拒绝。已有fresh-v4仅完整binding双role/epoch比较，不覆盖second commit。应仅在新_recheck取fresh完整select(runs).with_for_update并pin，再比较完整FP，随后保留原Run谓词/权限/时间；不能缩小比较投影或改通用gate函数。

2. **P2：新pin内部instance serializer。** 新CGR.input_bytes与Origin.input_key动态调用contract/manifest实例model_dump，可能在其前置epoch检查后执行shadow回调。父线程已接纳外部v7窄修：每次3个字段完整typed_storage raw，初次既有_validate支路fixedclass.dump(warnings=False)完整等值桥，保原ModelRead等旧函数。外部patch静态合理，actual gate和最终源需另核，当前记录不声称已闭合。

3. **P2：同一owned canonical leaf还需保留UnicodeEncodeError映射。** exact JSON树可含未配对surrogate。默认json转义序列可roundtrip还原此str；db.fingerprint ensure_ascii=False后encode会抛UnicodeEncodeError，属于旧controlled捕获的ValueError。当前float-only叶漏映射会越过内部DomainError拒绝处理。建议只在同一pure owned叶exactstr分支做UTF8可编码检查并记录malformed，确认整树受控JSON后才映成原VERSION_CONFLICT；不要包graph.checked/guard/callback。不需新的Source/PB或邻接矩阵。标准库证据见OWNED-UNICODE-CANONICAL-PROOF.json；未执行实际DB写。

4. 默认错签名TypeError因explicit dispatcher在函数体前失败，失去旧controlled映射。父线程已裁定照target的固定*args/**kwargs strict/default转发修复三入口；不得包strict core或改实际guard异常identity。该兼容差异非权限绕过，仍不能声称所有默认输入等值。

其它已核：v10 W5/reception/reject AST等值、G1新epoch、全部角色Limits、stage/accounted/NS-controller字节及full ModelRead检查均继续保留；pure cohort局部实现已由v12单独ACK。跨callerLimits的plainPB effective draft确由saved declared Limits展开，caller Limits只做compile验证；最后全type-aware draft比较可成立，不能据此合并角色或丢native/release全raw。

本报告是精确阻塞记录，不是最终fullgraph否定。修订需要在同一新冻结源用短门及AST窄桥闭合，不机械重跑155秒前缀。完整P-B/性能尚未接受。
