# v14 完整 Cold settlement 图代码独审

**FULL_CODE_REVIEW_ACK；无剩余确定P1/P2。** 审阅范围为当前13个修改生产文件、相关固定依赖和16个新测试；基线HEAD dc34ce4b1311810e27cd33a0cd156b6f84333666。ACK绑定AUTHOR-FINAL-FREEZE.json的131项哈希，非另一个未产生的Git提交。可在父级既定授权内进行**一次全新合成合同的原完整P-B测试**；不得续旧Run。该结论不代表Stage/完整P-B/人工语义/性能通过，也不批准真实模型、部署、main写入、付费或新授权。

审阅者只做源码/AST/已结束原件读取，未导入/执行产品、测试、DB、模型、网络或benchmark；未写repo、父证据root或旧封存目录。原full磁盘缺失独审报告仍未补回。

## 最终身份与必要门

作者最终冻结文件SHA c6d0dccd07670533fcdd3ab5110d9af8b6b2bae990723a4c0891d1c65853b866，131项实际全部复算等值并复制在frozen-inputs。

- final-recheck-sticky-v3标准pytest **9PASS/0skip**，JUnit4.267秒/外层15.922491秒，131输入稳定且与最终相同。包含真实SQLite fullRun读回比较、仅goal漂移拒绝；strict missing header原TypeError+sticky/后续IO0；真实audit/job配对及权限各10次；三dispatcher各缺/多参数共6例。
- final-sticky-type-v2：mypy src/sim2act **113文件PASS**，33.272488秒，131输入与最终相同。
- final-sticky-lint-v2：全部13生产修改+16新测试 **Ruff PASS**，131输入与最终相同。
- 前一final-key-scope-boundaries-v1为**68P1F/0skip**：失败是fixture spy漏计strict_owned collector；原配对/权限期望10未降低，仅补原样转发spy。原result/JUnit保留，不能称69全P。该批已经通过新key3、default arity6、controlled/Unicode等门，但源码版本有差异，详见GATE-SUMMARY。
- final-recheck-scope-default-v2为**20P1F/0skip**：fullrow fixture误用不存在的synthetic resource，actual Store.guard的权限门提前拒绝；最终fixture改用env已有真实授权resource及项目runtime，未新加Grant，原Store.guard/source_scope/authorize均保留。原失败不抹掉。
- first-binding-fresh-v4为**1P**（5有限Mock普通Generate/Source前缀、Cold仅排队，非settlement/完整PB）；两个完整Limits角色、两独立事务/epoch的full binding与public oracle全值等价，未在此后机械重跑。最终有窄输入key/default/fullrow修订，因此该1P仍按原129项身份单列。并行默认短门，不能作为独占性能证据。

GATE-SUMMARY逐项保留test名、原SHA差异和时间，组间存在重叠，未把它们相加冒称单次最终源全量测试。

## G0/W5/G1与完整事实

G0从原lock_live/首bound位置进入完整platform binding，按原顺序保留first完整commit guard→enabled→pending receipts→当前RECEIVED/raw/parse/value/usage/receipt→second完整guard。五角色Limits完整且分开；祖先事实包括完整Generate history、独立marker/Goal/Release、Source fullRun与每Attempt/journal/NS-controller原始bytes、usage/wire/intent/ops、多重集和基数。P只是paired DTO，不能代替完整stage重建。固定外部producer仍按原协议核resolver/_qualified/费用法律标志/expiry，默认拒绝未被放宽。

G0仅在完整second output全部原finite deadlines pin后正常退出；scope最后完整hash/失活后，紧贴原W5再实际检查time/stop。包括lease、Run/contract/source/clock、五角色、frozen/declared、meta.deadline及node截止，没有改任何数值、未跨业务事务renew。

W5五DML及原finalAttempt读回、已提交NS_RECEIVED接收事务、DomainError拒绝handler，对dc34 AST完全相同。G0 scope在W5前销毁，任一写/失败写由epoch与driver.total_changes失效；原W5仍同一原子事务，未中途commit换续租。任何后续失败回滚五写；已提交收到R事实保留。拒绝事务仍可能因owner/wire/CAS竞争失败，不无条件承诺REJECTED_KNOWN。

G1使用新epoch/token/CGR和全新raw audit seed，从原post guard语义位置开始，所有原raw表/字节重读，不用G0 DTO/permit。后续完整binding角色facet/receipts/当前实际aid journal/完整op与receipt建立后才能READY。不能将祖先journal累计次数当作当前aid次数。原ModelRead完整inputs/binding_key、source/approval/phase、实际authority并集、完整Run/currentcancel/fence/owner/lease及全部finite时间门保留；settle/tail状态机和最后live实际clock保持原样。INVARIANT-AST证明原_model_value/_model_inputs、ModelRead绑定与状态机关键方法、W5/reception/rejection等值；check只增加post_graph，live只增强guardrelay和先pin再消费。

## 本轮P2闭合

1. **typed/raw连续性**：固定模型完整storage门先于任何序列器，exact模型闭包/容器/数值/list-tuple区别/额外字段/循环，unknown Mapping/key/serializer回调不能介入纯cohort；fixedclass dump warnings=False只在受控条件下。J/accounted/Stage/RunCheck全字段与NS bytes未削薄。purecohort同次共享core保留原外部和owned callback边界完整pin，_base entry+exit双完整key，非_pinned或ALLOW缓存。
2. **错误归属**：strict callee/guard位于controlled外，BaseException只清理known exact scope并原样raise；固定persisted Extract/Metadata/RunScope parse及receipt.data/output纯索引保留原malformed映射。NaN/Inf及未配对surrogate仅在完整exact JSON的owned纯叶映原错误，不包graph.checked/回调。默认错误参数绑定保留controlled映射；strict缺参数也立即sticky，不能同with捕获后续用。
3. **scope角色与draft关系**：audit3列与job4列各固定完整header键，不丢request_key。native/extraction actual fullrow与Release冻结projection以全部冻结key存在和strict类型值比较，两个原raw仍完整pin。plainPB effective candidate由saved declared Limits展开；caller Limits只compile验证，不改candidate。最后same-schema draft用全type-aware比较，不合并各角色Limits。
4. **完整Run行**：新_recheck现在fresh select(runs)整18列并逐callee pin，与actual lock_live全行完整FP比较；通用13列_run_context_row未改。实际孤立proof的正向到下一context consumer1次、goal漂移0次且各一次完整SELECT，18列含goal/context/result/error/fingerprint。该unit前序phase/approval/source有明确stand-in并在原context consumer处sentinel停止，绝非真实Stage Authority/Permit验收。
5. **新pin内部serializer**：仅CGR.contract和Origin.contract/manifest三字段每次以已有pure typed_storage全raw进入完整key，构造既有_validate分支一次fixed schema dump(warnings=False)全等桥。instance shadow/nested unknown/warning回调0且sticky；原ModelRead.binding_key/_model_inputs等未改。不声称防御任意恶意Python替换受信模块/class实现或原生绕Store COMMIT/re-BEGIN。

## 证据纠正及尚未执行

v13是问题发现记录，其runtime逐文件快照在root快速修订后才取得，已包含fullrow修法；其中13列/全行证明及“旧_recheck调用路径”描述对应我更早实际读取到的未修表达式，不能把该快照当作未修候选。此处明确更正，未覆写v13 seal。

当前完整代码ACK的可用边界是test-only SQLite、exact Production/PB/cold、原受信fixture内的固定源/qualification stand-ins及原安全拒绝；真实账户resolver/qualification缺口保持。完整fresh P-B、真实语义/场景/人工owner验收、Windows、PG、远端CI/部署均未由本报告执行或接受。prefix155秒、read-only codec计时和静态约27→3检查次数均不能证明结算TX≤20秒或30秒租约裕量。完整字节/输入指纹成本必须在下一唯一实际运行中如实记录；失败亦须保留并独立终态审查，不无限迭代。
