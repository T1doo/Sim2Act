# 最终完整运行独审：FAIL_NOT_ACCEPTED

结论为 **FINAL_RUNTIME_TERMINAL_REVIEW / FAIL_NOT_ACCEPTED**。这次唯一新合成合同的原完整 P-B 用例确实执行至终态，失败且没有 skip；不是 timeout，也不是完整产品/Stage/性能接受。v14 的 `FULL_CODE_REVIEW_ACK` 仍仅是冻结代码范围结论，没有升级为运行通过。完整目标尚未完成；不再编码、执行测试、续旧 Run 或重跑完整链。

## 运行身份与证据边界

原件目录是 `/workspace/pb-full-gate-final-20261020`。`receipt.json` 记录 2026-10-20T01:00:49.331005Z 至 01:11:24.328208Z，外层 634.128503413 秒、exit 1、timed_out=false、owned_child_running=false。JUnit 记录唯一原测试 1F/0E/0skip，621.898 秒；stdout 四舍五入为 621.90 秒。观察器覆盖的测试 call 时间 612.771906 秒是另一个区间，不能替代 pytest 或外层时长。stderr 的 300 秒堆栈输出是 `faulthandler_timeout=300` 的诊断快照，不是外层 timeout 或 native crash。

基线 HEAD 是 `dc34ce4b1311810e27cd33a0cd156b6f84333666`；所测产品是其上的冻结工作树，不能称为已提交的新 revision。runner 的完整 footprint 为 **715 文件**：pyproject 1、schemas 7、src 142（113 个 Python 源）、tests 565（383 个 Python 文件）；这不同于最后短门/代码封存的 **131 selected 文件**。715 个文件在 invocation/receipt 前后及本次实际文件重算完全一致，131 个最终冻结文件全是同值子集。原 full 测试、原 controller 夹具、db.py、worker.py、production_trial_sender.py 与基线 Git blob 字节相同，原断言未被修改。具体哈希见 INPUT-IDENTITY.json。

runner 使用 `OUT.mkdir(exist_ok=False)` 独占新输出，实际只启动一个所选原 nodeid/child，关闭后有完整 receipt 与失败 JUnit；新 basetemp/fixture 数据库中的三阶段 ID/时间与原始事件对应，未采用旧成功 bundle 或续跑旧 Run。此结论限定已记录的这一次执行，不声称普遍证明环境外不存在任何其他程序。原 TTL1800/Run300/lease30/slot 间隔60 秒均保持。启动前记录诚实记载即时 ACK 已收到、正式代码 seal 尚在完成；本报告不倒填启动前已正式封存。

## 结束数据库与有限成功事实

经明确授权，本次只用标准库 SQLite `URI mode=ro` SELECT 读取已结束的 synthetic fixture，并在自己目录保存原始副本与原行导出；未导入产品或执行 Worker/模型。原数据库无 WAL 伴随文件，读取前后 SHA256 均为 `6c4d1651ec3a263ccc72bd383d51c195f1b87f297e737917ab7cb1a5b14820af`。ENDED-STATE-SUMMARY.json 与 ended-db/rows.json 保留实际值。

| 阶段 | 实际终态 | Attempts / Operations |
| --- | --- | --- |
| Generate | `run_419c6542cdbf42a284ba879b3497ada8`，PARTIAL，version2，有候选 result | 三个 RECEIVED Attempt；不能把 Generate 终态写成 SUCCEEDED |
| Source | `run_5c909e89ca94430b9611e986b3957e73`，SUCCEEDED，version2，有 result | 两个 VERIFIED Attempt；六个 VERIFIED Operation；两个 NS_SETTLED 与六个 SPEC_STEP_VERIFIED |
| Cold | `run_586511ff8dd24834b71b0f6362312c74`，RUNNING，version1/fence1/cancel=false，result/error 均 null | 一个 REJECTED_KNOWN Attempt；resource.read VERIFIED，首模型 Operation REJECTED_KNOWN |

Cold AppRun 也仍 RUNNING/output=null/result_version=null；Instance data_version=0。Cold 只有 `read_pick` 的一个 SPEC_STEP_VERIFIED；没有 Cold 模型 NS_SETTLED 或模型步骤 VERIFIED。已提交 NS_RECEIVED、原正文归档、已知 usage 100/900/1000 仍保留，随后有 NS_REJECTED。`REJECTED_KNOWN` 不是模型步骤成功或 Run 成功，也不能据此宣称已回收/终结这个 RUNNING Run。

原失败 traceback 和 stdout 显示已越过 Source 成功、提取 review/实际提取及同 key 重放、Source 原始 request/response 字节相等、四个归档负例、目录 NATURAL_PB、Fresh Store/client、Cold 实际 draft 指纹、材料/Goal per-use review/submit 与同 key 防重复等前置断言。这些是原机械断言的有限事实，不是语义/人工验收。Cold SUCCEEDED 断言失败之后的专用 owner-review、七槽全部 accepted、四个 reservation read segment、完整七 Attempt/二十二 body archive 断言及最终 proof 文件均 **NOT_REACHED**；公共结果中的 owner=PENDING 不等于这些专用断言已运行。

六条实际 Mock exchange 和 observer 外层六个唯一 aid 与数据库六条 Attempt 一致：Generate3 + Source2 + Cold1，全部 Mock handler 返回200；没有第二个 Cold 发送。当前夹具显式替换固定账户 source、软件资格和环境 producer，并用有限 MockTransport；原 HTTPTransport/AsyncHTTPTransport 真实请求入口为 tripwire。故本次是六次合成 Mock、真实模型0，数据库 `mode=LIVE` 仅表示所走分支，不能升级成真实账户、真实 entitlement、真实语义或场景证据。

## 首错与原子边界

failure-observations.jsonl 唯一 Cold 失败是 `VERSION_CONFLICT: Stale worker lease`：

`advance_model:3476 → cold.commit(_cold_commit_prefix(...first)) → _commit_guard_prefix → lock_live → Store.guard:1134`。

`_cold_first_binding` 在 G0 内已返回，但紧接的第一个完整 commit prefix 尚在原 `lock_live` 的 lease 检查就失败；不能说完整 G0 admission 已通过。该点在 enabled、pending receipts、RECEIVED 当前行/parse、第二个完整 commit guard，以及五个成功 DML 之前。

| 实际范围 | 结论 |
| --- | --- |
| G0 | 进入一次，first binding 返回后首个 lock_live 拒绝；phase wall37.521112227s/thread CPU37.481985296s；观测3030 SELECT、0 DML |
| W5 | NOT_REACHED；本次五写成功组根本未执行，不能误写成“五写执行后 rollback” |
| G1 | NOT_REACHED；没有写后事实图重建或完整首证运行资格 |
| finalguard / ModelRead settle/tail | NOT_REACHED，不能以预填零计数认定通过 |

这里的 G1 设计上是 **同一原子业务事务内、五写之后的新读取 epoch/token**，不是独立提交的新数据库事务；观察器的 phase 区间也不是精确 writer TX 持锁时长。本次仅 G0 实际到达，不能把静态同事务安排当作 G1 的运行证明。

最后一次真实 numeric heartbeat 记录 at1792458629.1756866、返回 lease1792458659.1644099，与结束 Run row 一致。原 guard 记录 at1792458667.7033126、RUNNING/fence1；其 trace 明确标 original_comparison_time=Unknown。两者差8.53890276秒只是 **记录时间减 lease**，不是被直接采集的谓词比较时刻。本次不补造精确原比较 time 或精确 TX span。原 Store.guard 严格拒绝和已过 lease 的事实可确认。Run 创建时间1792458501.8803318，Run+300=1792458801.8803318，合同 expiry1792459864.3276103，在该记录时仍有效；不能将首错归为 Run300/合同TTL、版本变化、取消或 fence 失主。窗口中真实 SQLITE_BUSY 记录保留，但没有逐事务跨度/无探针对照，不能把所有 CPU/等待归因于单个 BG、GC、host 或观察器。

## G0 成本及公开祖先调用

实际 observer JSON 中仅有 OTHER/G0 phase transition。W5/G1/finalguard metrics 的零值是 finish_call 的缺省补全，意味着未进入，而不是完整执行且零成本。

在本次到达的 G0，30 个已挂钩公开/祖先 verifier 入口均0，四个原预绑定 alias 已映射到同一个 canonical observer wrapper；G0 记录的 journal-chain 入口0。OTHER 的364条 chain 记录涉及其它阶段/祖先，不能说是当前 Cold aid 在 G0 重复364次。这支持“所到达的 G0 未经这些公开 verifier 重入”，不能扩大成任意未来路径或完整 G1 祖先各一次的运行证明。

| 实际 G0 指标 | 次数 / 字节 | thread CPU（秒） |
| --- | --- | --- |
| cold.first_binding | 1次返回 | 37.240321016 inclusive |
| CGR.check | 2048 | 25.268555120 inclusive；0.344918608 instrumented-child-exclusive |
| CGR.input_key | 2183 | 26.742323028 inclusive |
| CGR.input_bytes | 2183，581,208,365 返回字节 | 24.973985804 inclusive；7.207090629 instrumented-child-exclusive |
| codec.bytes | 2195，585,174,551 返回字节 | 17.871194528 |
| validate_codec | 137 | 4.495972123 inclusive |
| 原 model._model_inputs | 48 | 0.775185844 inclusive |
| SHA256 constructor（全部 G0 分类） | 3275，598,682,854 输入字节 | 1.460126973 |
| 其中 CGR.input_key 的 SHA constructor | 2183，581,208,365 输入字节 | 1.411413462 |

所有完整字段/字节重新编码和实际 hash 成本有观测，不能说完整 input fingerprint 计时仍全 Unknown，也不能因 SHA本体较小就把完整 pin 成本计为0。多层 inclusive 指标相互包含；codec.bytes 与 CGR.input_bytes 的字节视图重叠，不能相加当唯一数据量。这里记录的是 hash constructor 的输入，不监控 hash.update；也不采样每个内部字段/每个权限回调的独占因果成本。详细原值见 OBSERVED-COST-SUMMARY.json，未合成一个重复相加的“总 CPU”。

这些指标来自有探针的唯一实际运行，不是无观察器性能基准。wrapper、timestamp、mutex、计数、原 fixture 的租约日志写入有 CPU/调度开销；虽然 observer 没有增加产品 SQL/序列化/hash 调用或替换返回对象，不能称为零影响。没有本轮 observer-free 对照，不推断去掉探针便会通过，也不减算开销。secondary_observer_errors=0、56项 restoration=RESTORED 是实际记录，不等于证明任意后台线程全部已关闭。

## 交付结论与未执行项

本次唯一完整运行没有达到“完整 P-B 可接受”目标。可定位的剩余工程阻塞是完整 G0 第一绑定读取成本已经越过原30秒租约，随后原租约门正确拒绝；首个绑定内大量完整 CGR pin/编码计算是已量化的下一最小调查点，不再通过堆微优化、删字段、跨写复用旧许可、延长租约或重跑取绿来闭合本轮。此处没有提出或实施新代码，也不声称任何替代方案必然满足期限。

v14 的源码 ACK 和各短门原始 PASS/FAIL/版本桥保持原义；9P/mypy113/Ruff 均不覆盖本次未到达的 W5/G1/Stage。真实模型、Windows、PG、远端CI、真实语义/场景/人工验收未执行，默认 resolver/软件资格不匹配仍不能由测试替身升级为生产允许。旧环境满盘造成的最后独审报告未落盘仍是已知缺口，没有补回或重新签署它。

本报告基于当前已关闭原件和明确授权的 mode=ro 结束 SQLite读取；执行过的检查只有标准库文件/JSON/XML/哈希/AST/Git读取及只读SELECT，未执行产品、测试、模型或网络。新报告不修改任何旧seal或仓库。尚未构建/送审的未来 archive、普通dev commit/push、远端状态不在本次认证范围。

## 作者说明核对

已复核作者 full-result-analysis.json 与当前 docs/evidence/pb-cold-settlement-graph-20261020/README.md 的终态事实。文案原有“独立新事务的G1”已改为同一原子事务内的新读取epoch；581,208,365字节已明确为CGR input_key的SHA类别，并补全部G0构造输入598,682,854字节。复核时的具体文档副本和SHA在author/与AUTHOR-README-CHECK.json。其余FAIL/未达阶段/合成Mock/旧报告缺口的限定与原件一致；没有发现需阻止诚实保全失败结果的剩余文案误报。未来原始包成员、tar验证、commit/push尚未送审，不因README提及这些拟交付物就给包或远端认证。
