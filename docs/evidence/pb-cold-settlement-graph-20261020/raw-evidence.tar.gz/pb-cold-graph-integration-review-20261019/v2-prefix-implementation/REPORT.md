# Prefix 实现独审 v2（当前候选 P2 待修）

结论：**PREFIX_IMPLEMENTATION_P2_PENDING**。当前冻结版本不发 prefix 实现 ACK；有两个 P2，均可局部修复，无需长链。没有发现新的 P1。独审保留当前四生产文件、两个新测试及一个既有测试上下文，实际哈希与 prefix-focused-v1 receipt 的七个选中文件 before/after 相等。

基线 HEAD 为 `dc34ce4b1311810e27cd33a0cd156b6f84333666`，本候选为未提交的已冻结文件，不能冒称新 Git SHA或远端已核。父侧可继续其他不重叠文件实现；本报告只针对本目录 candidate-v1 的字节。natural_specs.py 的授权仅两个共享事实入口；没有扩大其执行功能。审查者只读源码/JSON/XML并做 stdlib AST/哈希，没有产品导入、测试、DB、模型、网络或 benchmark；唯一写入本新独审目录，旧 seal未改。

## P2 与最小修法

### PREFIX-P2-01：部分失败没有 sticky invalidation

`apps._cold_candidate_prefix` 没有包住整个阶段的 try/except。它前面的 checkpoint 成功后，draft_gate/own_project/compile 等原回调直接抛出 DomainError，会原样离开函数但不立即失效 guard。调用者若在同一个 `_cold_graph_read` with 内捕获该错误、恢复回调再调用，可以继续使用这个 guard。不能把整个 with 退出时 finally 的失效当成“任何异常立即且永久失效”。

`apps._cold_candidate_from_origin` 的 exact prefix/facts require 在 try 外，`lifecycle._cold_release_from_origin` 的 exact release/candidate/facts require 也在 try 外。传入一个正确前缀加错误 facts/第二阶段前缀时，该次拒绝不会失效已知正确前缀的 guard 或有效 facts；在 scope 内改正参数后仍可继续消费。

最小修订：入口 exact-type、role、current 检查及全部工作放入同一个 BaseException 失效边界；只按已知 exact 类型清理传入的 prefix/guard/facts 及其已知 exact guard，随后原样 raise。不要捕获后 fallback/replay。finally 中重置 busy 也必须先确认 exact facts 类型，否则入口错误又会被 finally 覆盖。不要为了清理增加 fresh resolver/授权或任何 DB 写。

新增短反例应把第一次 `pytest.raises` 放在**同一个 read/facts with 内**，随后检查 inactive 并尝试原值再次 check/consume；分别覆盖回调异常、正确前缀加错误 facts、正确 release 加错误 candidate-prefix。断言 verify_origin/fallback 仍为0、后继 sourcebytes等未执行。

### PREFIX-P2-02：错误类型 guard 的清理可能替换原异常

`lifecycle._cold_release_prefix` 捕获 BaseException 后无条件 `guard.invalidate()`。若 guard 是非None错误类型，checkpoint先抛的 DomainError随后被 AttributeError覆盖，或会调用任意对象提供的 invalidate。这个问题也必须在给前述消费者移入 try时避免。

清理仅识别 exact `_ColdGraphRead` / `_ColdCandidatePrefix` / `_ColdReleasePrefix` / `_ColdGraphOriginFacts` 等已知产品类型，再调用固定清理方法；不要 hasattr/getattr后调用任意方法。finally只清理，不新检查、不覆盖原异常。加一个 wrong-guard/foreign-invalidate 短例即可验证错误归属，不扩大故障矩阵。

两条均为静态可达反例，审查者没有执行它们。详细记录在 [FINDINGS.json](FINDINGS.json)。

## 其余源码检查

- 前置 `_ColdGraphRead` 与 complete origin facts 分开；精确 Worker/Store/原engine/Settings/controller/driver TX/thread/token/epoch/total_changes及完整角色输入固定。它没有发布完整 origin、StageAuthority或 source ALLOW。新增 add不允许替换既有输入，错误当前性在 check 内失效。
- `owned_release_pointer` 在 legacy/report/release gate、实际 Release SELECT、own_project 后加检查；实际 Release row在own_project前固定进guard输入。`immutable_release_pointer` 的 approval SELECT 后先current再消费payload；现有完整审批/hash谓词保留。
- lifecycle prefix/suffix分开，apps prefix先按原draft gate→owner→candidate hash→source family→compile，再由调用者显式提供完整 origin。consumer沿用这个实际 SQL Release draft对象，检查与candidate draft的 is 身份；未用等值另一份draft或重SELECT绕过。
- apps/lifecycle其余已进入 strict路径异常处理、sourcebytes/independent等后续checkpoint位置合理，实际权限原调用没有被pin代替。archival/full-report/logic/execution-source默认早返回保留；strict分支在对应成功早返回前拒绝，不退回完整公开verifier。
- 当前默认 split保持原函数语义检查位置；额外checkpoint在默认None路径为无动作。原namespace/formal-publication/project/dependency-lock完整if AST相同。对完整 default/dict的所有变体没有新动态全矩阵，本审未宣称其全部验证通过。
- natural 两新helper共用原 prompt 与sample/Recipe验证主体。将wrapper调用展开后，两个原函数的所有非import语句 AST完全相同，原source调用位置仍在样本形状检查前；sample/DAG循环只在单一叶中，没有复制第二套实现。`csv_dag.resolve` 固定模块导入移入leaf，位于source之后；已核同import集合，不把它说成逐字节整个函数等价。
- runtime除 `_ColdGraphRead`、factory与checkpoint三项新增，原所有函数/类AST相同；原模型结算五写、check/settle/tail、sender/reserve等没有在这份子候选被改变。apps原complete facts类与factoryAST相同。

[AST-OBSERVATIONS.json](AST-OBSERVATIONS.json) 共10项静态对照均成立。该结果不证明sticky异常边界正确，也不代替整个图血缘/Authority证明。

## 实际已有门与范围

[prefix-focused-v1 JUnit](gates/prefix-focused-v1/junit.xml) 真37PASS、0FAIL/ERROR/SKIP，JUnit 54.605s（原stdout摘要另见日志），runner57.175938s，exit0、未超时、sources_stable=true。具体节点在 [GATE-OBSERVATION.json](GATE-OBSERVATION.json)。receipt固定四生产+两个新测试+既有测试上下文七文件，不是全仓快照；本目录保留相同字节。没有把37P升级为无P2接受。

新生命周期用例为synthetic真实SQLite Release/approval/SourceReads对象；父级gate/compile/sourcebytes等有明确stubs，origin_complete是测试trace标记，**不是实际完成Source/Generate origin proof**。natural helper用例是真实API排队Generate并取得source、完整candidate/sample对照和原source错误对象，但没有Worker/Attempt/模型历史接受。新测试导入的HTTP/Async/Mock tripwire禁止模型IO，兼容项仍原CSV NoModel/default-off/权限先于私有批准读取。

现有异常用例大多在整个scope退出后断言inactive，factory finally会让它们通过，因而没有覆盖本次inside-scope catch/retry反例。新报告不冒称已运行mypy/Ruff或完整图门；本请求只提供了这份pytest结果。本审不运行补测。

## 后续判定

根线程已收到上述P2并计划只改已知对象清理/入口边界及inside-with短反例。修订后可直接给v3冻结源码和必要短门复审，不需要设计再循环或长PB复跑。当前局部前缀结构可保留，其P2修订未核前不发prefix ACK；即便修订通过，也不关闭完整图仍需完成的app_jobs/per-use/Source/history/accounting/stage接合P2，更不等于G0/G1已全量闭合、性能或完整P-B通过。

旧完整P-B继续 FAIL_NOT_ACCEPTED；完整指纹独占成本仍 UNKNOWN。旧满盘独审缺口未补回。所有本轮未运行的完整链/真实语义、Windows、PG、远端CI保持 NOT_RUN。
