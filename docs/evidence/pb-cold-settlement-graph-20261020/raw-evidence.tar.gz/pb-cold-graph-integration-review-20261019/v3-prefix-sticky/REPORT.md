# Prefix sticky 修订独审 v3

结论：**PREFIX_LOCAL_IMPLEMENTATION_ACK**。v2 报告的 PREFIX-P2-01 / PREFIX-P2-02 在本次局部源码中均已闭合，未发现本次 prefix 修订的剩余 P1/P2。该 ACK 可让根线程继续已授权的其他实现，不需要等本报告封存才继续；它不关闭完整图事实接合/G0-G1/全历史和 Authority 边界，也不是完整 P-B 或性能通过。

审查只采用本目录捕获的四生产文件、两个新测试及一个既有测试上下文。底层 HEAD 仍为 dc34；该局部候选未以新的提交 SHA宣称。根线程其他 app_jobs/pa_bound WIP明确排除在本ACK之外。审查者没有运行/导入产品、DB、测试、模型、网络或 benchmark，仅做源码diff、stdlib AST/哈希/XML/JSON核对；旧v2封存不改。

## 两项 P2 的实际闭合

apps `_cold_candidate_prefix` 的 exact guard/role检查、prefix全部回调和登记现在位于同一 try。任何 BaseException 都先对 exact `_ColdGraphRead` 失效，再 bare raise。draft_gate/own_project/source_family/compile 的原异常不再依赖外层with退出才使guard失效。

apps `_cold_candidate_from_origin`、lifecycle `_cold_release_from_origin` 的初始 exact前缀/facts检查均移入try；失败会对本次传入、可识别的 exact prefix guard及exact facts做固定清理。release consumer同时清理正确release和candidate前缀携带的已知guard。apps finally也只对exact facts重置busy，入口wrong facts不会再被finally属性赋值覆盖。

lifecycle `_cold_release_prefix` 先在try内要求 exact `_ColdGraphRead`；except不再无条件调用任意guard.invalidate。所有新清理均以明确type-is判断为条件，不调用unknown对象、任意hasattr/getattr回调，也没有fresh权限/来源/DB清理动作。所有except保持bare raise，因此原BaseException对象和归属保留。见 [P2-CLOSURE.json](P2-CLOSURE.json)。

## 实际21项短门

[prefix-sticky-v2原JUnit](gate/junit.xml) 是21PASS、0FAIL/ERROR/SKIP；JUnit27.007s，stdout摘要27.01s，runner29.354742s。exit0、未超时、sources_stable=true；receipt七选中文件before/after与本目录快照逐SHA一致。原始 [receipt](gate/receipt.json)、[stdout](gate/stdout.txt)、[stderr](gate/stderr.txt) 均保留。一个既有Starlette弃用warning保留。

其中新增8个反例：

- 四个回调分别抛同一个原DomainError，测试在**同一read with内部**捕获，断言对象identity、guard立即inactive，随后guard.check拒绝；不是只依赖with的finally。
- wrong-facts、wrong-candidate两例在同一个read/facts scope中捕获初次类型错误，检查known guard失效，随后使用原正确阶段值重新消费仍拒绝；release-candidate例还明确facts失效。
- candidate/release两个wrong-guard例提供会令测试失败的foreign invalidate；实际没有调用它，仍保留VERSION_CONFLICT且未执行后续私有trace。

另外13例仍是前版已有lifecycle10+natural3的局部门；fixture中的origin_complete为显式synthetic trace，不冒充真实Source/Generate历史完成。真实SQLite Release/approval/epoch等边界与stubbed gate/compile/sourcebytes范围沿用v2报告。没有Worker模型历史、完整Authority、Stage接受或完整PB运行证明。

## 版本桥与其余语义

v2到当前仅apps两个strict入口、lifecycle两个strict入口以及新增测试改变；default/dict共享函数、lifecycle前后缀、actualRelease draft-is约束、全部正常顺序及检查点均未再改。natural_spec_runtime.py、natural_specs.py和natural短测试/既有基础测试逐字节相同。故v2中两个共享natural核心不复制循环、source先于shape错误、runtime原五写/消费者不变的静态结论仍适用。

[AST-STICKY-CHECKS.json](AST-STICKY-CHECKS.json) 记录15项静态检查：原runtime/natural bytes不变，两文件只有四strict函数AST变化，四个入口工作均在try内，原异常bare raise，busy finally exact类型保护。手工同时核对每个cleanup type条件。它们是静态观测，不是额外执行的测试。

v2的37P是旧冻结字节的真实历史结果，不倒签为本次37P，更不把37+21累计成58个唯一当前测试。本次实际资格是21P及严格限定的源码变化桥。当前Ruff/mypy新运行未随此局部复审提供，不冒称已通过；最终完整集成仍必须满足自己的源冻结和质量门。见 [GATE-AND-BRIDGE.json](GATE-AND-BRIDGE.json)。

根线程下一阶段应继续只在父级批准的生产文件内完成显式facts/完整source与accounting、所有callback后current/fresh权限/来源/期限边界。等待最终冻结版本再审完整图；本审不查看不稳定全图草稿、不启图、不补跑旧矩阵。历史完整PB仍FAIL_NOT_ACCEPTED，指纹独占成本仍UNKNOWN，旧满盘缺失独审证据未恢复。
