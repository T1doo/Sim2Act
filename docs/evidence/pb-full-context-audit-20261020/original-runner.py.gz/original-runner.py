"""One explicitly selected synthetic full P-B test; original product limits stay intact."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

REPO = Path('/workspace/Sim2Act')
OUT = Path('/workspace/pb-full-gate-final-20261020')
NODE = 'tests/test_pb_spec_production_controller.py::test_pb_production_original_source_extraction_explicit_use_and_cold'
OBSERVER = Path('/tmp/pb-full-observer-integration-review-20261020/cold_graph_cost_full.py')
PYTHON = '/workspace/sim2act-venv/bin/python'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def sources():
    selected = [REPO / 'pyproject.toml']
    for folder in ('src/sim2act', 'tests', 'schemas'):
        selected.extend(p for p in (REPO / folder).rglob('*')
                        if p.is_file() and '__pycache__' not in p.parts
                        and '.pytest_cache' not in p.parts and p.suffix != '.pyc')
    return {str(p.relative_to(REPO)): digest(p) for p in sorted(selected)}


def git(*args):
    return subprocess.check_output(['git', '-c', 'core.fsmonitor=false', *args],
                                   cwd=REPO, text=True).strip()


def main():
    # Atomically reserve this unique output. Reinvocation cannot start a second test.
    OUT.mkdir(exist_ok=False)
    expected_observer = '2209e9a71be5341cdac68abf314c991a51262a7ee61c5079ee87d3f7fdcc6c67'
    if digest(OBSERVER) != expected_observer:
        raise RuntimeError('Reviewed observer bytes changed; no test started')
    env = os.environ.copy()
    for key in ('SIM2ACT_TEST_DATABASE_URL', 'PYTEST_PLUGINS'):
        env.pop(key, None)
    env.update(PYTEST_ADDOPTS='', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', PYTHONUNBUFFERED='1',
               PYTHONPATH=str(OBSERVER.parent) + ':' + str(REPO / 'src') + ':' + str(REPO / 'tests'),
               COLD_GRAPH_METRICS_DIR=str(OUT / 'observer'), COLD_GRAPH_METRICS_NODE=NODE)
    command = [PYTHON, '-m', 'pytest', '-p', 'cold_graph_cost_full', NODE, '-q',
               '-o', 'faulthandler_timeout=300', '--basetemp=' + str(OUT / 'pytest-tmp'),
               '--junitxml=' + str(OUT / 'junit.xml')]
    initial = sources()
    record = dict(classification='SYNTHETIC_EXPLICIT_MOCK_FULL_PB_NOT_REAL_MODEL_EVIDENCE',
                  started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  command=command, outer_timeout_seconds=1200, stackdump_seconds=300,
                  full_pb_authorized=True, real_model_authorized=False,
                  original_contract_ttl=1800, original_run_seconds=300,
                  original_lease_seconds=30, original_rpm_gap_seconds=60,
                  base_head=git('rev-parse', 'HEAD'), branch=git('branch', '--show-current'),
                  status_before=git('status', '--porcelain=v1'),
                  observer_sha256=digest(OBSERVER), runner_sha256=digest(Path(__file__)),
                  source_sha256_before=initial)
    (OUT / 'invocation.json').write_text(json.dumps(record, indent=2) + '\n')
    tick = time.monotonic()
    timed_out = False
    code, child = None, None
    try:
        with (OUT / 'stdout.txt').open('w') as stdout, (OUT / 'stderr.txt').open('w') as stderr:
            child = subprocess.Popen(command, cwd=REPO, env=env, stdout=stdout, stderr=stderr,
                                     start_new_session=True)
            record['owned_child_pid'] = child.pid
            (OUT / 'invocation.json').write_text(json.dumps(record, indent=2) + '\n')
            try:
                code = child.wait(timeout=1200)
            except subprocess.TimeoutExpired:
                timed_out = True
                try:
                    os.killpg(child.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                try:
                    code = child.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    try:
                        os.killpg(child.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    code = child.wait(timeout=5)
    except BaseException as error:
        record['runner_error_type'] = type(error).__name__
        raise
    finally:
        record.update(ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                      wall_seconds=time.monotonic()-tick, exit_code=code, timed_out=timed_out,
                      owned_child_running=child is not None and child.poll() is None)
        try:
            final = sources()
            record.update(source_sha256_after=final, sources_stable=initial == final,
                          head_after=git('rev-parse', 'HEAD'),
                          status_after=git('status', '--porcelain=v1'))
        except BaseException as error:
            record.update(after_snapshot_error_type=type(error).__name__, sources_stable=False)
        (OUT / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({key: record[key] for key in ('exit_code', 'timed_out', 'wall_seconds', 'sources_stable')}))
    print((OUT / 'stdout.txt').read_text()[-16000:])
    print((OUT / 'stderr.txt').read_text()[-5000:])
    return 1 if timed_out or not record['sources_stable'] or code is None else code


if __name__ == '__main__':
    sys.exit(main())
