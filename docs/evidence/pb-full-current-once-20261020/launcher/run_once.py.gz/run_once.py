"""Single authorized current-source full Mock PB; no retries or product edits."""
import datetime
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import re
import resource
import signal
import subprocess
import sys
import time

REPO = Path('/workspace/Sim2Act')
OUT = Path('/tmp/sim2act-pb-full-current-once-20261020')
BASE = 'a952866022a3976eedf045408778ea901760646b'
NODE = 'tests/test_pb_spec_production_controller.py::test_pb_production_original_source_extraction_explicit_use_and_cold'
OBSERVER = Path(__file__).parent / 'cold_graph_cost_full.py'
OBSERVER_SHA = '2209e9a71be5341cdac68abf314c991a51262a7ee61c5079ee87d3f7fdcc6c67'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def git(*args):
    return subprocess.check_output(['git', '-c', 'core.fsmonitor=false', *args], cwd=REPO, text=True).strip()


def sources():
    paths = [REPO / 'pyproject.toml', REPO / 'requirements.lock']
    for name in ('src/sim2act', 'tests', 'schemas'):
        paths.extend(p for p in (REPO / name).rglob('*') if p.is_file()
            and '__pycache__' not in p.parts and '.pytest_cache' not in p.parts and p.suffix != '.pyc')
    return {str(p.relative_to(REPO)): dict(bytes=p.stat().st_size, sha256=sha(p)) for p in sorted(paths)}


def dependencies(*, validate_lock=False):
    rows = {}
    for d in importlib.metadata.distributions():
        name = re.sub(r'[-_.]+', '-', d.metadata['Name']).lower()
        files = {}
        for f in d.files or ():
            p = Path(d.locate_file(f)).resolve()
            if p.is_file():
                files[str(p)] = dict(bytes=p.stat().st_size, sha256=sha(p))
        rows[name] = dict(version=d.version, files=files)
    if validate_lock:
        for line in (REPO / 'requirements.lock').read_text().splitlines():
            name, version = line.strip().split('==')
            name = re.sub(r'[-_.]+', '-', name).lower()
            assert rows[name]['version'] == version, 'Installed locked dependency differs: ' + name
    return rows


def usage():
    u = resource.getrusage(resource.RUSAGE_CHILDREN)
    return dict(user_cpu=u.ru_utime, system_cpu=u.ru_stime, max_rss=u.ru_maxrss,
        voluntary_switches=u.ru_nvcsw, involuntary_switches=u.ru_nivcsw)


def context():
    paths = ['/proc/loadavg', '/proc/stat', '/proc/self/cgroup', '/proc/meminfo',
        '/sys/fs/cgroup/cpu.max', '/sys/fs/cgroup/cpu.stat', '/sys/fs/cgroup/cpuset.cpus.effective',
        '/sys/fs/cgroup/memory.max', '/sys/fs/cgroup/memory.current', '/proc/self/status']
    values = {}
    for name in paths:
        try:
            values[name] = Path(name).read_text()
        except OSError as e:
            values[name] = type(e).__name__
    cpu = Path('/proc/cpuinfo').read_text()
    values['cpu_identity'] = [line for line in cpu.splitlines()
        if line.startswith(('model name', 'vendor_id', 'cpu cores', 'siblings', 'cpu MHz'))][:10]
    v = os.statvfs(OUT.parent)
    return dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(), uname=list(os.uname()),
        available_bytes=v.f_bavail*v.f_frsize, affinity=sorted(os.sched_getaffinity(0)),
        child_usage=usage(), proc=values, python=sys.version, executable=sys.executable)


def process_info(pid):
    try:
        text = Path(f'/proc/{pid}/stat').read_text()
    except FileNotFoundError:
        return None
    rest = text[text.rfind(')') + 2:].split()
    return dict(pid=pid, state=rest[0], parent=int(rest[1]), pgrp=int(rest[2]),
        user_ticks=int(rest[11]), system_ticks=int(rest[12]), start_ticks=int(rest[19]))


def group_members(pgid):
    result = []
    for p in Path('/proc').iterdir():
        if p.name.isdigit():
            try:
                info = process_info(int(p.name))
                if info and info['pgrp'] == pgid:
                    result.append(info)
            except (OSError, ValueError):
                pass
    return result


def stop_owned(child, record):
    # A single shared 5+5 interval. Re-entry only observes; never sends again.
    if record.get('cleanup_attempted'):
        record['remaining_owned_group'] = group_members(child.pid)
        record['cleanup_uncertain'] = bool(record['remaining_owned_group']) or 'cleanup_error' in record
        return
    record['cleanup_attempted'] = True
    started = time.monotonic()
    record['cleanup_started_monotonic'] = started
    try:
        info = process_info(child.pid)
        identity = record.get('owned_child_identity')
        if info is not None and (not identity or info['start_ticks'] != identity['start_ticks']
                or info['pgrp'] != child.pid):
            record['cleanup_error'] = 'OWNED_PROCESS_IDENTITY_MISMATCH_NO_SIGNAL'
            return
        for sig, deadline in ((signal.SIGTERM, started+5), (signal.SIGKILL, started+10)):
            if not group_members(child.pid):
                break
            try:
                os.killpg(child.pid, sig)
                record.setdefault('signals', []).append(sig.name)
            except ProcessLookupError:
                break
            except PermissionError:
                record['cleanup_error'] = 'SIGNAL_DENIED_STOP_NO_ALTERNATIVE'
                break
            try:
                child.wait(timeout=max(0.001, deadline-time.monotonic()))
            except subprocess.TimeoutExpired:
                pass
            while group_members(child.pid) and time.monotonic() < deadline:
                time.sleep(min(0.05, max(0, deadline-time.monotonic())))
    except BaseException as e:
        record['cleanup_error'] = type(e).__name__
    finally:
        record['cleanup_seconds'] = time.monotonic()-started
        record['remaining_owned_group'] = group_members(child.pid)
        record['cleanup_uncertain'] = bool(record['remaining_owned_group']) or 'cleanup_error' in record


def main():
    assert git('rev-parse', 'HEAD') == BASE and git('status', '--porcelain=v1') == ''
    assert not OUT.exists(), 'Existing output is a no-retry barrier'
    assert sha(OBSERVER) == OBSERVER_SHA
    assert os.access(OUT.parent, os.W_OK)
    assert context()['available_bytes'] >= 64 * 1024 * 1024
    initial, installed = sources(), dependencies(validate_lock=True)
    assert initial == json.loads((Path(__file__).parent / 'preflight-source.json').read_text())
    assert installed == json.loads((Path(__file__).parent / 'preflight-dependencies.json').read_text())
    before = context()
    OUT.mkdir(exist_ok=False)
    write(OUT / 'source-before.json', initial)
    write(OUT / 'dependencies-before.json', installed)
    write(OUT / 'context-before.json', before)
    env = os.environ.copy()
    for k in ('SIM2ACT_TEST_DATABASE_URL', 'SIM2ACT_RECORD_PG_CONFIG', 'PYTEST_PLUGINS'):
        env.pop(k, None)
    env.update(PYTEST_ADDOPTS='', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', PYTHONUNBUFFERED='1',
        PYTHONDONTWRITEBYTECODE='1', PYTHONPATH=str(OBSERVER.parent) + ':' + str(REPO / 'src') + ':' + str(REPO / 'tests'),
        COLD_GRAPH_METRICS_DIR=str(OUT / 'observer'), COLD_GRAPH_METRICS_NODE=NODE)
    command = [sys.executable, '-m', 'pytest', '-p', 'cold_graph_cost_full', NODE, '-q',
        '-o', 'faulthandler_timeout=300', '--basetemp=' + str(OUT / 'pytest-tmp'),
        '--junitxml=' + str(OUT / 'junit.xml')]
    record = dict(classification='AUTHORIZED_FRESH_CURRENT_SOURCE_MOCK_PB_NOT_REAL_MODEL',
        source_commit=BASE, command=command, runner_sha256=sha(Path(__file__)), observer_sha256=sha(OBSERVER),
        outer_timeout_seconds=1200, stackdump_seconds=300, product_limits=dict(ttl=1800, run=300,
        lease=30, rpm_gap=60, slots=7, output=7168, reserved=192000, wire=32768, paid_cap=0),
        cleared_selectors=['SIM2ACT_TEST_DATABASE_URL','SIM2ACT_RECORD_PG_CONFIG','PYTEST_PLUGINS'],
        pytest_autoload_disabled=True, real_model_authorized=False,
        started_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    write(OUT / 'invocation.json', record)
    tick = time.monotonic()
    timed_out, child, error = False, None, None
    start_usage = usage()
    try:
        with (OUT / 'stdout.txt').open('w') as stdout, (OUT / 'stderr.txt').open('w') as stderr:
            child = subprocess.Popen(command, cwd=REPO, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
            record['owned_child_identity'] = process_info(child.pid)
            assert record['owned_child_identity'] and record['owned_child_identity']['pgrp'] == child.pid
            write(OUT / 'invocation.json', record)
            try:
                child.wait(timeout=1200)
            except subprocess.TimeoutExpired:
                timed_out = True
                stop_owned(child, record)
    except BaseException as e:
        error = e
        record['runner_error_type'] = type(e).__name__
        if child is not None:
            stop_owned(child, record)
    finally:
        try:
            if child is not None:
                if group_members(child.pid):
                    stop_owned(child, record)
                record.update(exit_code=child.poll(), remaining_owned_group=group_members(child.pid))
        except BaseException as e:
            record['cleanup_error'] = type(e).__name__
            record['cleanup_uncertain'] = True
        record.update(ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            wall_seconds=time.monotonic()-tick, timed_out=timed_out)
        after_errors = []
        final, deps = None, None
        try:
            final = sources()
            write(OUT / 'source-after.json', final)
        except BaseException as e:
            after_errors.append(dict(item='source', error=type(e).__name__))
        try:
            deps = dependencies()  # Preserve actual versions even if now different from the lock.
            write(OUT / 'dependencies-after.json', deps)
        except BaseException as e:
            after_errors.append(dict(item='dependencies', error=type(e).__name__))
        try:
            write(OUT / 'context-after.json', context())
        except BaseException as e:
            after_errors.append(dict(item='context', error=type(e).__name__))
        try:
            end_usage = usage()
            record.update(child_usage_before=start_usage, child_usage_after=end_usage,
                owned_child_cpu=dict(user=end_usage['user_cpu']-start_usage['user_cpu'],
                    system=end_usage['system_cpu']-start_usage['system_cpu']))
        except BaseException as e:
            after_errors.append(dict(item='CPU', error=type(e).__name__))
        try:
            record.update(observer_stable=sha(OBSERVER) == OBSERVER_SHA,
                head_after=git('rev-parse','HEAD'), status_after=git('status','--porcelain=v1'))
        except BaseException as e:
            after_errors.append(dict(item='observer_or_git', error=type(e).__name__))
        record.update(sources_stable=initial == final, dependencies_stable=installed == deps,
            after_evidence_errors=after_errors)
        write(OUT / 'receipt.json', record)
    print(json.dumps({k:record.get(k) for k in ['exit_code','timed_out','wall_seconds','sources_stable',
        'dependencies_stable','observer_stable','owned_child_cpu','remaining_owned_group','cleanup_uncertain','runner_error_type']}, indent=2))
    if error is not None:
        raise error
    return 1 if (timed_out or not record.get('sources_stable') or not record.get('dependencies_stable')
        or not record.get('observer_stable') or record.get('cleanup_uncertain') or record.get('cleanup_error')
        or record.get('after_evidence_errors')
        or record.get('exit_code') is None) else record['exit_code']


if __name__ == '__main__':
    sys.exit(main())
