"""Structural helper on an actually SUCCEEDED Source from a finished PB phase."""
import hashlib
import json
import sqlite3
import sys
import time
import traceback
from pathlib import Path

import httpx
import pytest
from sqlalchemy import select

repo = Path('/workspace/Sim2Act')
sys.path.insert(0, str(repo / 'tests'))
from test_running_source_origin import check_running_source_origin
from sim2act.config import Settings
from sim2act.contracts import Limits
from sim2act.db import Store, attempts, runs

root = Path(__file__).resolve().parent
phase, name, run_id = sys.argv[1:]
assert (root / phase / 'result.json').exists(), 'Never inspect/copy a running test database'
out = root / name
out.mkdir(exist_ok=False)
original = root / phase / 'tmp/test_pb_production_original_so0/fixture.db'
target = out / 'copy.db'
original_hash = hashlib.sha256(original.read_bytes()).hexdigest()
with sqlite3.connect('file:' + str(original) + '?mode=ro', uri=True) as source, sqlite3.connect(target) as copy:
    source.backup(copy)
before_hash = hashlib.sha256(target.read_bytes()).hexdigest()
http_calls = []
def forbidden(*args, **kwargs):
    http_calls.append('FORBIDDEN_HTTP_OR_MOCK')
    raise AssertionError('Structural completed-state assertions cannot send')
httpx.HTTPTransport.handle_request = forbidden
httpx.AsyncHTTPTransport.handle_async_request = forbidden
httpx.MockTransport.handle_request = forbidden
httpx.MockTransport.handle_async_request = forbidden
store = Store('sqlite:///' + str(target), test_only=True)
settings = Settings(str(store.engine.url), out)
limits = Limits(**{k: getattr(settings, k) for k in Limits.model_fields})
record = dict(scope='ACTUAL_SUCCEEDED_SOURCE_STRUCTURAL_BINDING_NOT_LIVE_RUN_OR_PB_ACCEPTANCE',
              original_phase=phase, source_run=run_id, new_mock_exchanges=0, real_models=0)
start = time.monotonic()
try:
    with store.tx() as c:
        job = dict(c.execute(select(runs).where(runs.c.id == run_id)).mappings().one())
        assert job['status'] == 'SUCCEEDED'
        received = [dict(row) for row in c.execute(select(attempts).where(
            attempts.c.run_id == run_id)).mappings()]
        assert len(received) == 2 and all(row['status'] == 'VERIFIED' for row in received)
    with pytest.MonkeyPatch.context() as patch:
        check_running_source_origin(store, job['principal_id'], job['project_id'], job['resource_refs'][0],
                                    job, limits, out, patch, expected_source_attempts=2)
    record['assertions_passed'] = True
except BaseException as exc:
    record.update(assertions_passed=False, failure_type=type(exc).__name__, failure=str(exc))
    (out / 'traceback.txt').write_text(traceback.format_exc())
    raise
finally:
    store.engine.dispose()
    record.update(elapsed_seconds=time.monotonic()-start, http_or_mock_attempts=len(http_calls),
                  original_db_sha256=original_hash,
                  original_db_unchanged=original_hash == hashlib.sha256(original.read_bytes()).hexdigest(),
                  copy_before_sha256=before_hash, copy_after_sha256=hashlib.sha256(target.read_bytes()).hexdigest())
    (out / 'result.json').write_text(json.dumps(record, indent=2)+'\n')
    print(json.dumps(record, indent=2))
