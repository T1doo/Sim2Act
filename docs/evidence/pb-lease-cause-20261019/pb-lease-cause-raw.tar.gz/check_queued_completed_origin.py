"""Actual queued/completed Mock Source bindings, reusing retained synthetic Generate.

Only original APIs cancel the expired zero-attempt Source and create the new Run.
The retained original database is never mutated. This is not PB acceptance.
"""
import hashlib
import json
import sqlite3
import sys
import time
import traceback
from pathlib import Path

import httpx
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select

repo = Path('/workspace/Sim2Act')
sys.path.insert(0, str(repo / 'tests'))
import test_natural_spec_apps as apps
from test_running_source_origin import check_running_source_origin
from sim2act.api import create_app
from sim2act.config import Settings
from sim2act.contracts import Limits
from sim2act.db import Store, attempts, internal_instances, internal_releases, runs
from sim2act.worker import Worker

root = Path(__file__).resolve().parent
out = root / sys.argv[1]
out.mkdir(exist_ok=False)
original = root / 'same-call-origin-isolated/tmp/test_running_original_source_r0/fixture.db'
target = out / 'copy.db'
original_hash = hashlib.sha256(original.read_bytes()).hexdigest()
with sqlite3.connect('file:' + str(original) + '?mode=ro', uri=True) as source, sqlite3.connect(target) as copy:
    source.backup(copy)

http_calls = []
def forbidden(*args, **kwargs):
    http_calls.append('FORBIDDEN_REAL_HTTP')
    raise AssertionError('No real HTTP or real model is allowed')
httpx.HTTPTransport.handle_request = forbidden
httpx.AsyncHTTPTransport.handle_async_request = forbidden
store = Store('sqlite:///' + str(target), test_only=True)
settings = Settings(str(store.engine.url), out, mode='mock', goal_planner_provider='intern-s2')
limits = Limits(**{k: getattr(settings, k) for k in Limits.model_fields})
client = TestClient(create_app(store, settings))
client.headers['Authorization'] = 'Bearer synthetic-test-A'
record = dict(scope='ORIGINAL_QUEUED_COMPLETED_SOURCE_BINDING_NOT_PB_ACCEPTANCE',
              real_models=0, run_status_or_lease_directly_changed=False,
              approvals_or_qualification_rewritten=False, limits=limits.model_dump())
sent = []
start = time.monotonic()
try:
    with store.tx() as c:
        old = dict(c.execute(select(runs).where(runs.c.status == 'RUNNING')).mappings().one())
        instance = dict(c.execute(select(internal_instances)).mappings().one())
        release = dict(c.execute(select(internal_releases)).mappings().one())
        assert not c.execute(select(attempts.c.id).where(attempts.c.run_id == old['id'])).first()
    record['retained_old_run'] = old['id']
    response = client.post(f"/api/internal/instances/{instance['id']}/runs/{old['id']}/commands",
                           json=dict(command='cancel', version=old['version']))
    (out / 'cancel-response.json').write_text(response.text)
    assert response.status_code == 200, response.text
    source_run = apps.enqueue((store, settings, client), release, instance,
                              key='queued-completed-origin-16996e71')
    record['new_source_run'] = source_run
    with store.tx() as c:
        job = dict(c.execute(select(runs).where(runs.c.id == source_run)).mappings().one())
        assert job['status'] == 'QUEUED'
    queued = out / 'queued'
    queued.mkdir()
    with pytest.MonkeyPatch.context() as patch:
        check_running_source_origin(store, job['principal_id'], job['project_id'],
            job['resource_refs'][0], job, limits, queued, patch, expected_source_attempts=0)
    finite = apps.transport(sent)
    def bounded(request):
        assert len(sent) < 2, 'Source must use exactly its original two Mock exchanges'
        index = len(sent)
        (out / f'mock-request-{index}.bin').write_bytes(request.content)
        response = finite.handle_request(request)
        (out / f'mock-response-{index}.bin').write_bytes(response.content)
        return response
    worker = Worker(store, settings, goal_planner_transport=httpx.MockTransport(bounded))
    assert worker.once()
    with store.tx() as c:
        old_after = dict(c.execute(select(runs).where(runs.c.id == old['id'])).mappings().one())
        job = dict(c.execute(select(runs).where(runs.c.id == source_run)).mappings().one())
        actual_attempts = [dict(row) for row in c.execute(select(attempts).where(
            attempts.c.run_id == source_run).order_by(attempts.c.id)).mappings()]
    record.update(old_after_status=old_after['status'], new_source_status=job['status'],
                  source_attempt_ids=[row['id'] for row in actual_attempts],
                  source_attempt_statuses=[row['status'] for row in actual_attempts])
    assert old_after['status'] == 'CANCELLED'
    assert job['status'] == 'SUCCEEDED', dict(status=job['status'], error=job['error'])
    assert len(sent) == len(actual_attempts) == 2
    assert all(row['status'] in {'RECEIVED', 'VERIFIED'} for row in actual_attempts)
    completed = out / 'completed'
    completed.mkdir()
    with pytest.MonkeyPatch.context() as patch:
        check_running_source_origin(store, job['principal_id'], job['project_id'],
            job['resource_refs'][0], job, limits, completed, patch, expected_source_attempts=2)
    record['assertions_passed'] = True
except BaseException as exc:
    record.update(assertions_passed=False, failure_type=type(exc).__name__, failure=str(exc))
    (out / 'traceback.txt').write_text(traceback.format_exc())
    raise
finally:
    client.close()
    store.engine.dispose()
    record.update(elapsed_seconds=time.monotonic() - start, new_mock_exchanges=len(sent),
        real_http_attempts=len(http_calls), original_db_sha256=original_hash,
        original_db_unchanged=original_hash == hashlib.sha256(original.read_bytes()).hexdigest())
    (out / 'mock-payloads.json').write_text(json.dumps(sent, indent=2))
    (out / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record, indent=2))
