"""SELECT-only exact old/new anchor results, SQL and parameters; no Run authority."""
import ast
import hashlib
import json
import sqlite3
import subprocess
import sys
from pathlib import Path

import httpx
from sqlalchemy import event, select
from sim2act import goal_applications as generation
from sim2act.db import Store, runs

root=Path(__file__).resolve().parent
out=root/sys.argv[1];out.mkdir(exist_ok=False)
original=root/'entry-scope-pb-full-chain/tmp/test_pb_production_original_so0/fixture.db'
target=out/'copy.db';digest=hashlib.sha256(original.read_bytes()).hexdigest()
with sqlite3.connect('file:'+str(original)+'?mode=ro',uri=True) as source,sqlite3.connect(target) as copy:
    source.backup(copy)
old_sha='4813e7a4bc7a7f6a0bd7d3232e043129f4fdc5a8'
raw=subprocess.check_output(['git','-c','core.fsmonitor=false','show',old_sha+':src/sim2act/goal_applications.py'],cwd='/workspace/Sim2Act')
(out/'old-goal-applications.py').write_bytes(raw)
function=next(node for node in ast.parse(raw).body if isinstance(node,ast.FunctionDef) and node.name=='_journal_scope_anchor')
namespace=dict(generation.__dict__)
exec(compile(ast.fix_missing_locations(ast.Module(body=[function],type_ignores=[])),'original-4813-anchor','exec'),namespace)
old=namespace['_journal_scope_anchor']
def forbidden(*args,**kwargs):raise AssertionError('No HTTP, Mock or model in structural parity')
httpx.HTTPTransport.handle_request=forbidden
httpx.AsyncHTTPTransport.handle_async_request=forbidden
httpx.MockTransport.handle_request=forbidden
httpx.MockTransport.handle_async_request=forbidden
store=Store('sqlite:///'+str(target),test_only=True)
queries=[]
def record(c,cursor,statement,parameters,context,executemany):
    assert statement.lstrip().upper().startswith('SELECT ')
    queries.append(dict(sql=statement,parameters=parameters))
reports=[]
with store.engine.connect() as c:
    c.exec_driver_sql('BEGIN IMMEDIATE');c.exec_driver_sql('PRAGMA query_only=ON')
    a='run_9d83d77846674b02a8d802c27b452289';b='run_e19239c76d2d4213af8a9ee48d57d008'
    owner=dict(c.execute(select(runs.c.principal_id,runs.c.project_id,runs.c.runtime_id).where(runs.c.id==a)).mappings().one())
    event.listen(store.engine,'before_cursor_execute',record)
    try:
        for label,rid,expected in [('A',a,None),('bad-B',b,None),('A-after-B',a,owner),
            ('missing',a+'-missing',None),('A-after-missing',a,owner),
            ('wrong-owner',a,owner|dict(principal_id='wrong')),('A-after-wrong-owner',a,owner)]:
            queries.clear();before=old(store,c,rid,expected=expected);old_queries=list(queries)
            queries.clear();after=generation._journal_scope_anchor(store,c,rid,expected=expected);new_queries=list(queries)
            assert before==after and old_queries==new_queries,label
            assert (after is None)==(label in {'bad-B','missing','wrong-owner'}),label
            reports.append(dict(case=label,run_id=rid,expected=expected,value=after,queries=new_queries,
                exact_result_sql_parameters_equal=True))
    finally:
        event.remove(store.engine,'before_cursor_execute',record);c.rollback()
store.engine.dispose()
result=dict(scope='STRUCTURAL_QUERY_TEMPLATE_PARITY_NOT_RUN_OR_PB_AUTHORITY',old_sha=old_sha,
    reports=reports,real_models=0,mock_exchanges=0,writes=0,
    original_db_sha256=digest,original_db_unchanged=digest==hashlib.sha256(original.read_bytes()).hexdigest())
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(cases=len(reports),all_exact=True,real_models=0,mock_exchanges=0,writes=0)))
