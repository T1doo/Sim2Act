"""Continue only the actual completed five-slot prefix, with original authorities.

No preparation, initialization, source execution, quota reset or deadline edits.
The original Cold tail is executed from the exact frozen repository test AST.
Only its new-send/read-report counters account for this distinct process.
"""
import ast
import base64
import datetime
import hashlib
import json
import sqlite3
import subprocess
import sys
import traceback
from dataclasses import asdict, replace
from pathlib import Path
from types import SimpleNamespace

import httpx
import pytest
from sqlalchemy import event, select

repo = Path('/workspace/Sim2Act')
sys.path.insert(0, str(repo / 'tests'))
import test_pb_spec_production_controller as test
from sim2act import natural_live_admission as gate
from sim2act import natural_source_archives as archive
from sim2act import pa_trial_dispatch as trial
from sim2act import pb_natural_specs as pb
from sim2act import pb_natural_uses as use
from sim2act import production_trial_journal as journal
from sim2act import spec_production as controller
from sim2act.api import create_app
from sim2act.config import Settings
from sim2act.db import Store, attempts, delivery_graph_requests, fingerprint, internal_instances, internal_releases, runs, task_extractions
from sim2act.text_logic_reuse import pair
from fastapi.testclient import TestClient

root = Path(__file__).resolve().parent
prefix = root / 'authority-standard-pb-full-chain'
out = root / 'original-cold-continuation'
out.mkdir(exist_ok=False)
original = prefix / 'tmp/test_pb_production_original_so0/fixture.db'
prefix_result = json.loads((prefix / 'result.json').read_text())
assert prefix_result['head'] == '9fbcb6a4e682a09f916b4561795f000c609aea10'
assert prefix_result['returncode'] == 1 and prefix_result['unchanged_inputs'] and prefix_result['finished_at']
assert not subprocess.check_output(['git', '-c', 'core.fsmonitor=false', 'diff', '9fbcb6a4e682a09f916b4561795f000c609aea10', 'HEAD', '--', 'src'], cwd=repo)
original_hash = hashlib.sha256(original.read_bytes()).hexdigest()
prefix_actual = json.loads((root / 'authority-standard-pb-full-chain-actual-rows.json').read_text())
assert original_hash == prefix_actual['database_sha256']
copy = out / 'fixture.db'
with sqlite3.connect('file:' + str(original) + '?mode=ro', uri=True) as origin, sqlite3.connect(copy) as target:
    origin.backup(target)
store = Store('sqlite:///' + str(copy), test_only=True)

def forbidden(*args, **kwargs):
    raise AssertionError('Real HTTP forbidden; this is only the original finite Mock fixture')

record = dict(scope='ACTUAL_SAME_CONTRACT_PREFIX_PLUS_COLD_CONTINUATION_NOT_SINGLE_PYTEST_PASS',
    prefix_phase=prefix.name, prefix_source='9fbcb6a4e682a09f916b4561795f000c609aea10',
    current_source=subprocess.check_output(['git', '-c', 'core.fsmonitor=false', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
    real_models=0, prior_mock_exchanges=5, new_mock_limit=2)
assert record['current_source'] == '84fde1b6a5724c57ce0fa68b868ff82e445ed1d8'
assert not subprocess.check_output(['git', '-c', 'core.fsmonitor=false', 'status', '--porcelain'], cwd=repo)
try:
    with store.tx() as c:
        raw = c.execute(select(delivery_graph_requests.c.snapshot).where(
            delivery_graph_requests.c.kind == gate.SCOPE)).scalars().one()
        contract = gate.PBTrialContract.model_validate(raw['response'])
        user = contract.principal_id
        accepted = gate._saved(c, user, gate.entity(contract), gate.APPROVE, 'approve', gate.Approval)
    key = accepted.request.request_key
    original_settings = replace(Settings('sqlite:///' + str(original), original.parent),
        quota_subject=contract.quota_subject, mode='live', live_enabled=True,
        goal_planner_provider='intern-s2', application_generation_activation_enabled=True,
        token='isolated-noncredential-placeholder')
    selected = replace(original_settings, database_url=str(store.engine.url), data_dir=out)
    # Reuse exactly the original configured() stand-ins and Mock factory;
    # this loader performs no setup, preparation, initialization or granting.
    def load_only(env, where):
        base = (store, selected, None, user, contract.project_id, contract.bindings[0].resource_id, None)
        return base, SimpleNamespace(contract=contract, approval_key=key, account_id='synthetic-pb-production-shape')

    with pytest.MonkeyPatch.context() as patch:
        patch.setattr(httpx.HTTPTransport, 'handle_request', forbidden)
        patch.setattr(httpx.AsyncHTTPTransport, 'handle_async_request', forbidden)
        data, binding, fixture, original_factory = test.configured(None, out, patch, prepare_case=load_only)
        assert data[1] == selected
        old_values, new_values = asdict(original_settings), asdict(selected)
        assert {k for k in old_values if old_values[k] != new_values[k]} == {'database_url', 'data_dir'}
        with store.tx() as c:
            gate._approved(store, c, user, contract, key)
        before = journal.read(store, user, contract, key, binding.account_id)
        assert len(before.ledger.slots) == 5 and not before.ledger.halted
        assert all(slot.accepted for slot in before.ledger.slots)
        assert [slot.identity.stage for slot in before.ledger.slots] == ['generate'] * 3 + ['source'] * 2
        source_id = before.ledger.slots[3].identity.run_id
        assert [row['id'] for row in prefix_actual['runs'] if row['status'] == 'SUCCEEDED'] == [source_id]
        generation = before.ledger.slots[0].identity.run_id
        with store.tx() as c:
            gate._approved(store, c, user, contract, key)
            source_row = c.execute(select(runs).where(runs.c.id == source_id)).mappings().one()
            assert source_row['status'] == 'SUCCEEDED'
            source_attempts = c.execute(select(attempts).where(attempts.c.run_id == source_id)).mappings().all()
            assert len(source_attempts) == 2 and all(row['status'] == 'VERIFIED' for row in source_attempts)
            extraction = c.execute(select(task_extractions).where(task_extractions.c.task_id == source_id,
                task_extractions.c.principal_id == user, task_extractions.c.request_key == contract.extraction_request_key)).mappings().one()
            body, _ = pair(c, user, extraction['app_id'], pb.EXTRACT, contract.extraction_request_key, pb.ExtractInput)
            inst = dict(c.execute(select(internal_instances).where(internal_instances.c.source_app_id == extraction['app_id'],
                internal_instances.c.principal_id == user)).mappings().one())
            release = dict(c.execute(select(internal_releases).where(internal_releases.c.id == inst['release_id'],
                internal_releases.c.principal_id == user)).mappings().one())
        original_exchanges = [json.loads(s) for s in (original.parent / 'mock-exchanges.jsonl').read_text().splitlines()]
        assert len(original_exchanges) == 5 and all(e['classification'] == 'SYNTHETIC_MOCK_TRANSPORT_NOT_REAL_HTTP' for e in original_exchanges)
        resolved = archive.resolve_trial_source(store, user, contract, key)
        assert list(zip(resolved.request_bodies, resolved.response_bodies, strict=True)) == [
            (base64.b64decode(e['request_b64']), base64.b64decode(e['response_b64'])) for e in original_exchanges[3:]]
        def factory(*args, **kwargs):
            normal = kwargs.pop('goal_planner_transport')
            def limited(request):
                assert len(fixture['sends']) <= 2, 'Only two new Cold Mock replies are permitted'
                return normal.handler(request)
            return original_factory(*args, **kwargs, goal_planner_transport=httpx.MockTransport(limited))
        protected = test.snapshot(store)
        worker = factory(store, data[1], goal_planner_transport=httpx.MockTransport(forbidden))
        made = trial.extract_pb(worker, user, source_id, body)
        assert made['id'] == extraction['app_id'] and not fixture['sends']
        assert test.snapshot(store) == protected
        record.update(contract_fingerprint=fingerprint(contract.model_dump()), expires_at=contract.expires_at,
            original_approval_expires_at=accepted.expires_at, original_settings=old_values, selected_settings=new_values,
            prefix_ledger=before.model_dump(mode='json'), source_run=source_id, extraction=made['id'], instance=inst['id'])
        (out / 'verified-prefix.json').write_text(json.dumps(record, indent=2, default=str) + '\n')
        read_reports, before_sql = test.observe_reservation_reads(patch)
        event.listen(store.engine, 'before_cursor_execute', before_sql)
        target = contract.bindings[1]
        apps = test.apps
        monkeypatch, tmp_path, approve_stage = patch, out, test.approve_stage
        failures = dict(scope='Four original archive refusal assertions passed in prefix test before KeyError; not re-executed here',
            prefix_phase=prefix.name)
        function = next(n for n in ast.parse((repo / 'tests/test_pb_spec_production_controller.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'test_pb_production_original_source_extraction_explicit_use_and_cold')
        start = next(i for i, n in enumerate(function.body) if isinstance(n, ast.Assign)
            and any(isinstance(t, ast.Name) and t.id == 'cold_store' for t in n.targets))
        tail = ast.unparse(ast.Module(body=function.body[start:], type_ignores=[]))
        (out / 'original-cold-tail.py').write_text(tail + '\n')
        substitutions = {
            "assert len(history.ledger.slots) == len(fixture['sends']) == 7":
                "assert len(history.ledger.slots) == 7 and len(fixture['sends']) == 2",
            'assert len(read_reports) == 4': 'assert len(read_reports) == 2',
            "assert [r['run_id'] for r in read_reports] == [source_id] * 2 + [cold_id] * 2":
                "assert [r['run_id'] for r in read_reports] == [cold_id] * 2",
        }
        for old, new in substitutions.items():
            assert tail.count(old) == 1, old
            tail = tail.replace(old, new)
        (out / 'counter-only-substitutions.json').write_text(json.dumps(substitutions, indent=2) + '\n')
        (out / 'executed-cold-tail.py').write_text(tail + '\n')
        exec(compile(tail, str(out / 'executed-cold-tail.py'), 'exec'), globals(), locals())
        record.update(assertions_passed=True, new_mock_exchanges=len(fixture['sends']),
            source_read_reports_not_recreated=True, new_cold_read_reports=len(read_reports))
except BaseException as error:
    record.update(assertions_passed=False, error_type=type(error).__name__, error=str(error))
    (out / 'traceback.txt').write_text(traceback.format_exc())
    raise
finally:
    store.engine.dispose()
    record.update(original_database_sha256=original_hash,
        original_database_unchanged=original_hash == hashlib.sha256(original.read_bytes()).hexdigest(),
        observed_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    (out / 'result.json').write_text(json.dumps(record, indent=2, default=str) + '\n')
    print(json.dumps(record, indent=2, default=str))
