"""Seal all retained author/reviewer evidence after bounded validation completes."""
import datetime
import hashlib
import io
import json
import shutil
import subprocess
import sys
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path

repo = Path('/workspace/Sim2Act')
root = Path('/workspace/pb-lease-cause-20261019')
reviews = Path('/workspace/pb-lease-cause-review-20261019')
delivery = Path('/workspace/pb-lease-cause-delivery-20261019')
source, final_phase, final_review = sys.argv[1:]
def sha(data): return hashlib.sha256(data).hexdigest()
def git(*args, **kwargs):
    return subprocess.check_output(['git', '-c', 'core.fsmonitor=false', *args], cwd=repo, **kwargs)
assert not (root / 'RAW-SEAL.json').exists(), 'Never rewrite a sealed root'
assert git('rev-parse', 'HEAD', text=True).strip() == source
assert git('status', '--porcelain', text=True) == ''
assert (reviews / final_review / 'manifest.json').exists(), 'Independent final review must be sealed'
final = json.loads((root / final_phase / 'result.json').read_text())
assert final['head'] == source and final['unchanged_inputs']
assert final['returncode'] in (0, 1)
passed = final['returncode'] == 0
if final_phase == 'original-cold-continuation-command':
    continuation = json.loads((root / 'original-cold-continuation/result.json').read_text())
    assert continuation['current_source'] == source and continuation['original_database_unchanged']
    assert continuation['assertions_passed'] is passed
    acceptance = ('LIMITED_SAME_CONTRACT_PREFIX_PLUS_COLD_CONTINUATION_NOT_SINGLE_PYTEST_PASS' if passed
        else 'NOT_ACCEPTED: Source/extraction prefix succeeded; original Cold continuation failed')
else:
    chain_xml = ET.parse(root / final_phase / 'junit.xml')
    assert len(chain_xml.findall('.//testcase')) == 1
    assert bool(chain_xml.findall('.//failure')) is not passed
    acceptance = ('LIMITED_SYNTHETIC_PB_CONTROLLER_PASS_NOT_REAL_LIVE_OR_SEMANTIC_ACCEPTANCE' if passed
                  else 'NOT_ACCEPTED: bounded original PB chain failed; see exact final phase')
phases, identities, seen = [], [], set()
tracked = set(git('ls-files', text=True).splitlines())
for record_path in sorted(root.glob('*/result.json')):
    folder = record_path.parent
    if not (folder / 'before.json').exists():
        continue
    result = json.loads(record_path.read_text())
    before = json.loads((folder / 'before.json').read_text())
    after = json.loads((folder / 'after.json').read_text())
    stable = before == after and result['unchanged_inputs']
    if not stable:
        assert folder.name == 'completed-source-command'
        changed = sorted(p for p in set(before) | set(after) if before.get(p) != after.get(p))
        assert changed == result['changed'] == ['tests/test_pb_spec_production_controller.py']
        assert result['head'] == '9fbcb6a4e682a09f916b4561795f000c609aea10'
        assert sha(git('show', '84fde1b6a5724c57ce0fa68b868ff82e445ed1d8:' + changed[0])) == after[changed[0]]
    junit = ET.parse(folder / 'junit.xml') if (folder / 'junit.xml').exists() else None
    mock_logs = list(folder.glob('tmp/*0/mock-exchanges.jsonl'))
    direct = [json.loads(line) for p in mock_logs for line in p.read_text().splitlines()]
    assert all(e['classification'] == 'SYNTHETIC_MOCK_TRANSPORT_NOT_REAL_HTTP' for e in direct)
    phases.append(dict(phase=folder.name, head=result['head'], returncode=result['returncode'],
        elapsed_seconds=result['elapsed_seconds'], inputs=len(before), unchanged_inputs=stable,
        classification='FROZEN_INPUT_SNAPSHOT' if stable else 'NON_FROZEN_INPUT_DRIFT_NOT_A_GATE_PASS',
        junit_cases=None if junit is None else len(junit.findall('.//testcase')),
        junit_failures=None if junit is None else len(junit.findall('.//failure')),
        junit_errors=None if junit is None else len(junit.findall('.//error')),
        junit_skipped=None if junit is None else len(junit.findall('.//skipped')),
        direct_mock_transport_logs=len(direct)))
    version = result['head']
    if version in seen: continue
    seen.add(version)
    paths = sorted(set(before) & tracked)
    stream = io.BytesIO(git('cat-file', '--batch', input=''.join(version+':'+p+'\n' for p in paths).encode()))
    for name in paths:
        header = stream.readline().decode().strip().split()
        assert len(header) == 3 and header[1] == 'blob', (version, name, header)
        content = stream.read(int(header[2])); assert stream.read(1) == b'\n'
        assert sha(content) == before[name], (version, name)
        if version == source: assert content == (repo / name).read_bytes(), name
    identities.append(dict(head=version, example_phase=folder.name, listed_inputs=len(before),
        verified_git_blobs=len(paths), dependency_hash_inputs=len(set(before)-tracked),
        outside_git_paths=sorted(set(before)-tracked)))
(root / 'phase-results.json').write_text(json.dumps(phases, indent=2)+'\n')
(root / 'input-identity.json').write_text(json.dumps(dict(source=source, versions=identities,
    limitations=['Selected inputs are not a hermetic snapshot of installed Python or host.',
                 '1399 JS dependency files are hash identities; not bundled or Git blobs.',
                 'External runner/plugin/scripts are separately retained with timing of identity observations.']), indent=2)+'\n')
shutil.copy2('/workspace/package-pb-lease-cause.py', root / 'evidence-packager.py')
assert not (root / 'independent-reviews').exists()
shutil.copytree(reviews, root / 'independent-reviews', symlinks=True)
(root / 'source-history.patch').write_bytes(git('format-patch', '--stdout', '5bd438812a9914fac827014336a5ba38b63d08dc..'+source))
assert sha((root / 'check_queued_completed_origin.py').read_bytes()) == json.loads(
    (root / 'support/queued-completed-script-identity.json').read_text())['sha256']
files, aliases, omitted = [], [], []
for p in sorted(root.rglob('*')):
    name = p.relative_to(root).as_posix()
    if p.is_symlink(): aliases.append(dict(path=name, target=str(p.readlink())))
    elif p.is_file():
        if any(part in {'__pycache__', '.mypy_cache', '.pytest_cache', '.ruff_cache', 'cache'} for part in p.relative_to(root).parts):
            omitted.append(dict(path=name, bytes=p.stat().st_size, sha256=sha(p.read_bytes())))
        else: files.append(dict(path=name, bytes=p.stat().st_size, sha256=sha(p.read_bytes())))
manifest = dict(source=source, final_phase=final_phase, final_review=final_review, acceptance=acceptance,
    created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), files=files,
    symlink_aliases_not_followed=aliases, omitted_generated_cache_files=omitted,
    scope='All failures retained; finite Mock only; no real model/account probes, Windows/PG/native/CI/semantic certification')
(root / 'RAW-MANIFEST.json').write_text(json.dumps(manifest, indent=2)+'\n')
seal = dict(source=source, acceptance=acceptance, files=len(files),
    manifest_sha256=sha((root / 'RAW-MANIFEST.json').read_bytes()), mutation_policy='DO_NOT_WRITE_AGAIN')
(root / 'RAW-SEAL.json').write_text(json.dumps(seal, indent=2)+'\n')
delivery.mkdir(exist_ok=True)
archive_path = delivery / 'pb-lease-cause-raw.tar.gz'
assert not archive_path.exists()
with tarfile.open(archive_path, 'w:gz') as archive:
    for item in files:
        archive.add(root / item['path'], arcname=item['path'], recursive=False)
    for name in ('RAW-MANIFEST.json', 'RAW-SEAL.json'):
        archive.add(root / name, arcname=name, recursive=False)
with tarfile.open(archive_path) as archive:
    members = {m.name: m for m in archive.getmembers()}
    assert len(members) == len(files)+2
    for item in files:
        assert sha(archive.extractfile(members[item['path']]).read()) == item['sha256']
receipt = dict(source=source, acceptance=acceptance, archive=str(archive_path), bytes=archive_path.stat().st_size,
    sha256=sha(archive_path.read_bytes()), raw_manifest_sha256=seal['manifest_sha256'],
    raw_data_files=len(files), archive_members=len(files)+2, all_members_verified=True)
(delivery / 'package-receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(receipt), flush=True)
