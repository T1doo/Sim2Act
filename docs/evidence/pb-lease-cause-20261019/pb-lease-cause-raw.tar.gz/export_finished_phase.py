"""Read-only actual-row export from an ended synthetic phase; no product imports."""
import datetime
import hashlib
import json
import sqlite3
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
phase = sys.argv[1]
folder = root / phase
result = json.loads((folder / "result.json").read_text())
assert result["finished_at"], "Never inspect an active phase database"
database = Path(sys.argv[2]) if len(sys.argv) > 2 else folder / "tmp/test_pb_production_original_so0/fixture.db"
assert database.resolve().is_relative_to(root)
before = hashlib.sha256(database.read_bytes()).hexdigest()

def decoded(row):
    output = dict(row)
    for key, value in output.items():
        if isinstance(value, str) and value[:1] in {"{", "["}:
            try:
                output[key] = json.loads(value)
            except json.JSONDecodeError:
                pass
    return output

with sqlite3.connect("file:" + str(database) + "?mode=ro", uri=True) as connection:
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA query_only=ON")
    actual_runs = [decoded(row) for row in connection.execute("SELECT * FROM runs ORDER BY created_at,id")]
    actual_attempts = [decoded(row) for row in connection.execute("SELECT * FROM attempts ORDER BY created_at,id")]
    frozen = [decoded(row) for row in connection.execute("SELECT * FROM run_contracts ORDER BY run_id")]
after = hashlib.sha256(database.read_bytes()).hexdigest()
assert before == after
output = dict(observed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    scope="READ_ONLY_ACTUAL_ROWS_FROM_ENDED_SYNTHETIC_PHASE_NOT_AUTHORITY_OR_REAL_LIVE_EVIDENCE",
    phase=phase, executed_source=result["head"], database_sha256=before, database_unchanged=True,
    runs=actual_runs, attempts=actual_attempts, frozen_contracts=frozen)
target = root / (phase + "-actual-rows.json")
assert not target.exists()
target.write_text(json.dumps(output, indent=2) + "\n")
print(json.dumps(dict(path=str(target), runs=len(actual_runs), attempts=len(actual_attempts),
    run_statuses={row["id"]:row["status"] for row in actual_runs}, database_unchanged=True)))
