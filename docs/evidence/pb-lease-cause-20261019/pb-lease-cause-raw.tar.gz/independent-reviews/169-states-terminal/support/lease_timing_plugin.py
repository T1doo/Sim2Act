"""Passive timings for one original P-B Mock chain; no authority replacements."""
import atexit
import functools
import itertools
import json
import sys
import threading
import time
from contextlib import contextmanager

import pytest
from sqlalchemy import event

from sim2act import db, goal_applications, goal_runs
from sim2act.db import Store
from sim2act.errors import DomainError

ORIGINAL_GUARD_CODE = Store.guard.__code__
REAL_TIME = db.time


@pytest.fixture(autouse=True)
def passive_lease_transaction_timings(env, tmp_path, monkeypatch):
    store = env[0]
    assert store.test_only and store.sqlite
    stream = (tmp_path / "lease-transaction-timings.jsonl").open("w")
    atexit.register(stream.close)
    mutex, ids, active = threading.Lock(), itertools.count(), {}
    background_threads = set()
    observer_errors = []

    def record(kind, **fields):
        try:
            value = dict(kind=kind, wall=time.time(), monotonic=time.monotonic(),
                process_cpu=time.process_time(), thread_cpu=time.thread_time(),
                thread=threading.get_ident(), **fields)
            with mutex:
                stream.write(json.dumps(value) + "\n")
                if kind in {"heartbeat_error", "heartbeat_return", "probe_teardown"}:
                    stream.flush()
        except (OSError, TypeError, ValueError) as error:
            observer_errors.append(type(error).__name__)

    def stack():
        f, frames = sys._getframe(2), []
        while f is not None and len(frames) < 16:
            frames.append(dict(file=f.f_code.co_filename, function=f.f_code.co_name, line=f.f_lineno))
            f = f.f_back
        return frames

    original_tx, original_heartbeat, original_claim = Store.tx, Store.heartbeat, Store.claim

    @contextmanager
    def tx(self, *args, **kwargs):
        token = next(ids)
        thread_id = threading.get_ident()
        with mutex:
            prior = active.get(thread_id)
        entered = False
        entry = dict(transaction=token, statements=0)
        record("tx_attempt", transaction=token, store=id(self), options=kwargs, stack=stack())
        try:
            with original_tx(self, *args, **kwargs) as c:
                with mutex:
                    active[thread_id] = entry
                entered = True
                record("tx_acquired", transaction=token, connection=id(c),
                    driver=id(c.connection.driver_connection))
                try:
                    yield c
                finally:
                    record("tx_body_end", **entry)
            record("tx_committed", transaction=token)
        except Exception as error:
            record("tx_error", transaction=token, error=type(error).__name__,
                detail=error.public() if isinstance(error, DomainError) else str(error),
                sqlite_errorcode=getattr(getattr(error, "orig", None), "sqlite_errorcode", None))
            raise
        finally:
            if entered:
                with mutex:
                    if prior is None:
                        active.pop(thread_id, None)
                    else:
                        active[thread_id] = prior

    def heartbeat(self, worker_id, run_id=None, *args, **kwargs):
        token = next(ids)
        frames = stack()
        if any(f["function"] == "beat" for f in frames):
            with mutex:
                background_threads.add(threading.current_thread())
        record("heartbeat_enter", heartbeat=token, run_id=run_id, options=kwargs, stack=frames)
        try:
            result = original_heartbeat(self, worker_id, run_id, *args, **kwargs)
        except Exception as error:
            record("heartbeat_error", heartbeat=token, run_id=run_id,
                error=type(error).__name__, detail=error.public() if isinstance(error, DomainError) else str(error),
                sqlite_errorcode=getattr(getattr(error, "orig", None), "sqlite_errorcode", None))
            raise
        record("heartbeat_return", heartbeat=token, run_id=run_id, actual_committed_lease=result)
        return result

    def claim(self, *args, **kwargs):
        result = original_claim(self, *args, **kwargs)
        if result:
            record("claim_return", run_id=result["id"], worker_id=result["worker_id"],
                fence=result["fence"], lease_until=result["lease_until"], created_at=result["created_at"])
        return result

    class ClockProbe:
        def __getattr__(self, name):
            return getattr(REAL_TIME, name)

        def time(self):
            value = REAL_TIME.time()
            frame = sys._getframe(1)
            if frame.f_code is ORIGINAL_GUARD_CODE:
                row = frame.f_locals["r"]
                record("original_guard_comparison", run_id=frame.f_locals["run_id"],
                    compared_at=value, lease_until=row["lease_until"], status=row["status"],
                    row_fence=row["fence"], expected_fence=frame.f_locals["fence"], stack=stack())
            return value

    def span(owner, name):
        original = getattr(owner, name)

        @functools.wraps(original)
        def observed(*args, **kwargs):
            token = next(ids)
            record("span_enter", span=token, function=name)
            try:
                return original(*args, **kwargs)
            finally:
                record("span_exit", span=token, function=name)

        monkeypatch.setattr(owner, name, observed)

    def before_sql(c, cursor, statement, parameters, context, executemany):
        context._lease_probe = (time.monotonic(), time.process_time(), time.thread_time())
        with mutex:
            entry = active.get(threading.get_ident())
            if entry is not None:
                entry["statements"] += 1

    def after_sql(c, cursor, statement, parameters, context, executemany):
        began, cpu, thread_cpu = context._lease_probe
        elapsed = time.monotonic() - began
        if elapsed >= .02:
            record("slow_sql", elapsed=elapsed, cpu=time.process_time()-cpu,
                caller_cpu=time.thread_time()-thread_cpu, statement=statement,
                transaction=active.get(threading.get_ident(), {}).get("transaction"))

    monkeypatch.setattr(Store, "tx", tx)
    monkeypatch.setattr(Store, "heartbeat", heartbeat)
    monkeypatch.setattr(Store, "claim", claim)
    monkeypatch.setattr(db, "time", ClockProbe())
    span(Store, "_frozen_contract_after_scope")
    span(goal_applications, "source_scope_gate")
    span(goal_runs, "verify_source")
    event.listen(store.engine, "before_cursor_execute", before_sql)
    event.listen(store.engine, "after_cursor_execute", after_sql)
    try:
        yield
    finally:
        with mutex:
            remaining = [dict(item) for item in active.values()]
            live_background = [t.ident for t in background_threads if t.is_alive()]
        record("probe_teardown", observer_errors=observer_errors,
            live_transactions=remaining, live_background_threads=live_background,
            observations_closed=not remaining and not live_background)
        event.remove(store.engine, "before_cursor_execute", before_sql)
        event.remove(store.engine, "after_cursor_execute", after_sql)
        assert observer_errors == []
