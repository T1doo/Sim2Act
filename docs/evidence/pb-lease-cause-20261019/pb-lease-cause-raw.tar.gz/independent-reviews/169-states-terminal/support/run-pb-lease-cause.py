import datetime
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

repo = Path('/workspace/Sim2Act')
root = Path('/workspace/pb-lease-cause-20261019')
name = sys.argv[1]
command = sys.argv[2:]
out = root / name
out.mkdir(parents=True, exist_ok=False)

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def files():
    selected = []
    for folder in ('src', 'tests', 'scripts'):
        selected.extend(p for p in (repo / folder).rglob('*') if p.is_file()
            and p.suffix in {'.py', '.cjs', '.js', '.html', '.json'}
            and '__pycache__' not in p.parts and '.egg-info' not in str(p))
    selected.extend(p for p in repo.iterdir() if p.is_file()
        and (p.suffix in {'.toml', '.lock'} or p.name.startswith('requirements')))
    return {str(p.relative_to(repo)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(set(selected))}

before = files()
head = subprocess.check_output(['git', '-c', 'core.fsmonitor=false', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
(out / 'before.json').write_text(json.dumps(before, indent=2) + '\n')
started = time.monotonic()
record = dict(started_at=now(), head=head, command=command, cwd=str(repo), inputs=len(before),
              real_models='FORBIDDEN; finite MockTransport and ordinary HTTP tripwire in test module')
(out / 'command.json').write_text(json.dumps(record, indent=2) + '\n')
with (out / 'stdout.txt').open('w') as stdout, (out / 'stderr.txt').open('w') as stderr:
    try:
        result = subprocess.run(command, cwd=repo, stdout=stdout, stderr=stderr, timeout=1800)
        record['returncode'] = result.returncode
    except subprocess.TimeoutExpired:
        record['timeout_seconds'] = 1800
        record['returncode'] = 124
after = files()
(out / 'after.json').write_text(json.dumps(after, indent=2) + '\n')
record.update(finished_at=now(), elapsed_seconds=time.monotonic()-started, unchanged_inputs=before==after,
              changed=[p for p in set(before)|set(after) if before.get(p)!=after.get(p)])
(out / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
sys.exit(record['returncode'])
