"""Pure SELECT structural profile of retained failed/expired Source; no authority."""
import cProfile
import hashlib
import io
import json
import pstats
import sqlite3
import sys
import time
from pathlib import Path

import httpx
from sqlalchemy import event, select
from sim2act import goal_applications as generation
from sim2act import natural_live_admission as gate
from sim2act import pa_spec_apps as spec
from sim2act import pb_natural_specs as pb
from sim2act.config import Settings
from sim2act.contracts import Limits
from sim2act.db import Store, delivery_graph_requests, runs
from sim2act.errors import DomainError

root = Path(__file__).resolve().parent
out = root / sys.argv[1]
out.mkdir(exist_ok=False)
original = root / 'entry-scope-pb-full-chain/tmp/test_pb_production_original_so0/fixture.db'
target = out / 'copy.db'
original_hash = hashlib.sha256(original.read_bytes()).hexdigest()
with sqlite3.connect('file:'+str(original)+'?mode=ro', uri=True) as source, sqlite3.connect(target) as copy:
    source.backup(copy)

def forbidden(*args, **kwargs):
    raise AssertionError('No model, HTTP or Mock allowed in structural SELECT-only profile')
httpx.HTTPTransport.handle_request = forbidden
httpx.AsyncHTTPTransport.handle_async_request = forbidden
httpx.MockTransport.handle_request = forbidden
httpx.MockTransport.handle_async_request = forbidden
store = Store('sqlite:///'+str(target), test_only=True)
settings = Settings(str(store.engine.url), out)
worker_limits = Limits(**{k:getattr(settings,k) for k in Limits.model_fields})
statements = [0]
def select_only(c, cursor, statement, parameters, context, executemany):
    assert statement.lstrip().upper().startswith('SELECT '), 'SELECT only'
    statements[0] += 1
sections = []
profiler = cProfile.Profile()
with store.engine.connect() as c:
    c.exec_driver_sql('BEGIN IMMEDIATE')
    c.exec_driver_sql('PRAGMA query_only=ON')
    event.listen(store.engine,'before_cursor_execute',select_only)
    try:
        job = dict(c.execute(select(runs).where(runs.c.id=='run_e19239c76d2d4213af8a9ee48d57d008')).mappings().one())
        saved = c.execute(select(delivery_graph_requests.c.snapshot).where(
            delivery_graph_requests.c.kind==gate.SCOPE)).scalar_one()
        contract = gate.PBTrialContract.model_validate(saved['request'])
        with pb._source_reads(store,c):
            profiler.enable()
            for iteration in range(2):
                for name, call in (
                    ('source_scope', lambda:generation.source_scope_gate(store,c,job['id'])),
                    ('frozen_contract', lambda:store.frozen_contract(c,job)),
                    ('bound_worker4', lambda:spec.bound(store,c,job['principal_id'],job,worker_limits)),
                    ('bound_stage3', lambda:spec.bound(store,c,job['principal_id'],job,gate._limits(contract))),
                    ('audit', lambda:spec.audit_fingerprint(store,c,job['principal_id'],
                        spec.bound(store,c,job['principal_id'],job,worker_limits)['draft'],
                        _correction_scope_checked=True))):
                    started,cpu,count=time.monotonic(),time.thread_time(),statements[0]
                    failure=None
                    try:
                        call()
                    except DomainError as exc:
                        failure=exc.public()
                    finally:
                        sections.append(dict(iteration=iteration,section=name,error=failure,
                            elapsed=time.monotonic()-started,cpu=time.thread_time()-cpu,
                            statements=statements[0]-count))
            profiler.disable()
    finally:
        profiler.disable()
        event.remove(store.engine,'before_cursor_execute',select_only)
        c.rollback()
store.engine.dispose()
stream=io.StringIO()
pstats.Stats(profiler,stream=stream).sort_stats('cumulative').print_stats(90)
(out/'cumulative-profile.txt').write_text(stream.getvalue())
stream=io.StringIO()
pstats.Stats(profiler,stream=stream).sort_stats('tottime').print_stats(65)
(out/'self-profile.txt').write_text(stream.getvalue())
profiler.dump_stats(out/'profile.pstats')
record=dict(scope='EXPIRED_RECEIVED_SOURCE_COPY_STRUCTURAL_SELECT_ONLY_NOT_RUN_AUTHORITY_OR_ACCEPTANCE',
    sections=sections,real_models=0,mock_exchanges=0,writes=0,original_db_sha256=original_hash,
    original_db_unchanged=original_hash==hashlib.sha256(original.read_bytes()).hexdigest(),
    profiling_overhead=True,limits_distinct=True)
(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
