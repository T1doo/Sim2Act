独立只读审查结论：416432646a89ccade07bbf205ae66ebebfce3526 的 SQL 模板增量未发现新增 P1/P2。该结论仅支持源码与下列实际短门、结构等值材料；P-B 七槽工程验收仍 PENDING，不能据此宣称已解决 30 秒租约或 300 秒 Run 截止。

审查基线为 parent 4813e7a4bc7a7f6a0bd7d3232e043129f4fdc5a8。只变更 goal_applications.py 和 test_generation_scope_anchor_projection.py。独立读取时 HEAD 正确、工作树干净，/workspace 可用约 19 GiB。本审查只做 Git 只读、源码文本/AST、JSON/XML、字节哈希与新审查目录复制；没有导入产品、连接或查询数据库、执行测试/模型/网络，未更改仓库或旧 seal。作者执行的原始材料与审查方实际执行范围严格区分。

新 @lru_cache(maxsize=1) 函数无参数，返回固定两个 SQLAlchemy Select。缓存内容是表结构引用、固定 JSON 路径和 bindparam，不包含实际 Run ID、数据库行、Store/connection、Grant、binding、权限结论或 proof authority。调用方每次新建参数字典并显式绑定当前 Run ID。不会将一次 Run 的数据或授权放到新 lru 中；既有 SourceReads 结果复用机制、原 epoch/事务/线程校验不因 SQL 模板复用而扩大。

独立 AST 对照通过：owner SELECT 与完整 projection 表达式同旧版；字段、LEFT JOIN 的 ACCEPTED 过滤、独立 event/Attempt IDs、order、LIMIT 4 均一致。每次仍按 owner → expected → own_project → projection 原顺序读取，合格情形仍三次真实 SELECT。anchor 查询后所有基数、版本、activation、ordinary 资格拒绝分支逐 AST 一致。source_scope_gate 除 owner execute 表达式外逐 AST 一致，fresh Grant、双 anchor、token 当前性及异常清缓存仍在；其他原函数均未改。LIMIT 4 只限制返回行数，不保证数据库内部计算量。

新测试只加 missing Run 后再回 A 的两条断言，保留原全部负例：缺合同、0/2 ACCEPTED、0/2/4 Attempts、缺 marker/null/混版本/全缺、activation 与错误 owner。夹具中的 LIVE marker 是标量资格合成值，不构成真实发送、完整生产证明或授权证据。

已独立核原始 receipt、stdout/stderr、JUnit（适用）和 before/after：

| 同一准确 SHA 416432646a89ccade07bbf205ae66ebebfce3526 | 实际结果 | 外层秒数 |
| --- | --- | ---: |
| test_generation_scope_anchor_projection.py | 1 PASS；JUnit 1/0fail/0error/0skip；pytest 23.62 s | 71.554577 |
| 旧/新 anchor 结构对照 | 7 组返回值、完整 DBAPI SQL 与参数全等 | 31.133159 |
| retained expired Source SELECT-only profile | exit 0；0 Mock/模型/业务写 | 74.810572 |
| mypy src | 113 源文件 PASS | 122.878041 |
| Ruff 指定变更文件 | 9 文件 PASS；不是全仓 Ruff 门 | 6.242088 |

五项 receipt 均 2112 输入 before/after 逐项相同。审查方同时核当前字节哈希：713 个选中 tracked blob 与该 commit 对象一致；其余 1399 个为 scripts/engineering-ci/node_modules 依赖哈希，不能称为已提交源码。没有将选中输入集合冒称整个环境封闭。

7 组对照为 A → 不合格 Source B → A → missing → A → wrong owner → A；每组旧/新实际完整结果与 SQL/参数均相等。A 类各 3 SELECT，missing/错误 expected owner 各 1，错误 owner 未进入受保护投影。作者脚本从 4813 Git blob 只抽取原 anchor 函数，保持其依赖；在真实失败 Source 数据库的只读备份上启用 query_only 和 SELECT tripwire，HTTP/Mock 均硬拒。原 DB 哈希 e44690624a3aad50f346fdda28e7e63510a1fc785be733e82d6e60f8b6a61b72 前后不变。这是过期 retained 数据的结构对照，不是活 Run、旧软件资格或 P-B 验收；本审查只读其源码和 JSON 原件，未重新执行或查询 DB。

性能结论明确保留：新旧 profile 都是 6277 条被分析 SQL，Limits 4/3 各自首读 1588、重复 633，未合并证明键。旧/新 section thread CPU 合计 24.072050 / 34.511555 s；anchor 各 335 次，累计 8.153 / 8.499 s。作者同时运行质量/结构进程且 cProfile 有开销，数据没有证明总体节时或足够跨过 30 秒边界。模板确实静态消除了重复构造 SQL 表达式，但不能以个别 warm 路径时间外推端到端改善。

此前 4813 整链失败保持有效：Generate 3 + Source 1 Mock，已收 Source 原始包，Attempt REJECTED_KNOWN；Source RUNNING，抽取及 Cold 未到。post-receive tx4814 持有 36.969359 s / 11228 SQL，跨原有限 lease 7720.7636077，尚未到 Run300 截止 7822.209172；原 finite lease 拒绝不能被本轮静态审查抹去。该终态单独封存在 4813-known-response-terminal，旧 manifest 未改。作者新的同 SHA template-pb-full-chain 在运行；本报告不纳入未完成日志、不预签七槽 PASS，终态须另审。真实模型、受信 resolver、完整软件资格、Windows、PG、真实语义/人工场景与远端 CI 均不在本轮实际验证范围。

初始未提交编辑的括号语法 Ruff 失败单独原样保留在 evidence/support/unfrozen-template-syntax；记录明确是 4813 HEAD 的 dirty 编辑稿，修正后才生成 4164 冻结源码，不重标为冻结门通过。本审查首次组装脚本对 profile 数量错误地另加两条 profiler 外 setup SELECT，触发纯静态断言；纠正后仅重做只读汇总，过程写入 review-assembly-erratum.json，不修改作者原件或产品，不重跑任何测试。

材料索引：review-audit.json 记录所有静态检查、精确门结果与输入分类；baseline/、candidate/ 和 tracked.patch 为两版本源码；evidence/ 保留原命令/结果/输出/JUnit/输入哈希、对照脚本和结果、旧/新 profile 文本及未冻结编辑失败；manifest.json 覆盖本目录全部交付文件（不自包含）。本有限源码意见可进入下一轮真实有界整链检查，尚无完整可用性接受结论。
