416432646a89ccade07bbf205ae66ebebfce3526 的本轮 P-B 整链结论：NOT_ACCEPTED。实际 JUnit 1 FAIL，pytest 465.89 s，外层 488.562547 s；14:02:52.321228 → 14:11:00.883526 UTC。2112 个选中输入前后逐项相同，也与该 SHA 已独审的静态门输入相同（713 tracked blob、1399 node_modules 依赖）。前一份静态/投影/类型/Ruff PASS 仍只适用于其有限范围，不替代本次失败。

实际只有 4 次合成 Mock：Generate 3、Source 1、Cold 0，真实模型 0。Source run_70b677ea8971498d80da0cbb5799d7bb 的原始失败断言返回 RUNNING、error=null、result=null、owner_acceptance=PENDING、semantic_status=UNKNOWN。新材料复用、提取、Cold 及最终七槽证明未执行完成，不将部分事实称为闭环。

本次拒绝位置是 natural_spec_runtime.advance_model:1022 的最终 spec.commit_guard(worker,c,run,final_binding)，经 check_commit → production_trial_policy.check_run → natural_live_admission._run_context:934 的原有限租约复合 guard。4813 上一轮是在 advance_model:1021 的 settle_verified 内 check_commit 被拒绝。本轮已多执行 1572 条 SQL，达到更后的最终检查；不能把两次不同工作量的 30.18 / 36.97 s 当成性能基准或成功。

Source tx4802 从 1792419008.0711277 acquired 到 1792419038.2513707 body_end，持有 30.180243402 monotonic 秒，前台 CPU 30.047280997 秒，12800 条观测 SQL。最新实际 Store heartbeat return 为 1792419008.0607526，已提交 lease=1792419038.0076869。事务末与错误观测 1792419038.2518823 已超过该 lease；Run.created_at=1792418909.1952283，原 300 s 截止=1792419209.1952283，尚未到 Run300。最后一次直接保存的 Store.guard 比较在 1792419033.093954，仍小于原 lease，RUNNING/fence1 且原 guard 成功；随后 production 复合 guard 的精确内部 time.time() 比较值未单独录下，不能用错误包装时刻冒充该比较值。原有限租约/guard 没有被放宽或跳过。

首个 Source 响应已经完成 raw receive/archive，最终原事件含 NS_RECEIVED 与 NS_REJECTED，不含 NS_SETTLED；受事务回滚影响的验证没有被宣称提交。Mock 原始响应 619 bytes 的 SHA256=3b5db1ce92cbbdb7e2db7f0937224be8cbfb89d7b3f04426521a4ea69e6ff81e；规范 JSON SHA256=ef2a4eccddc203547054ac8628940c6b22819ca39e42db0496b806feac575578，与 PA_TRIAL_BODY 的原始/规范哈希及字节数相符，known usage=100/900/1000。原始 request bytes 也与 request body 事件哈希相符。本审查没有查询 Attempt 表，因此不把从异常处理源码推断的终态字段冒充独立 DB 行核验。

观察材料闭合：5413 对 span_enter/exit IDs、function 与时间方向均核对；probe_teardown observations_closed=true，observer_errors/live_transactions/live_observed_background_threads 均空。原 heartbeat 53 返回、4 个 SQLite Busy5 异常，其中 3 个 Busy 在 tx4802 内发生，没有成功续租覆盖该长业务事务。外部 plugin/runner 的实际字节哈希与启动前独立 receipt 一致；该两文件不在 2112 项源码/依赖集合内，单独封存。观察仍有文件 I/O/stack/CPU 调度开销，SQL 只监听首个 Store 的成功语句，failed driver wait 不属于 slow-SQL 数值；Cold 未到且无其 SQL 监听。闭合仅针对记录的线程/事务，不是整个环境零并发证明。

关于下一项 own_project 模板方向，原函数只做 select(projects) WHERE id=project_id AND owner_id=principal，mappings().first() 后缺行 PERMISSION_DENIED。模块级固定 Select 或零参模板、两个独立 typed bindparam、每 call 用当前 project/principal 新字典执行，可以保留原语义；必须继续返回当前完整 RowMapping，不保存 owner/行/权限结果，不改调用位置、authorize 或 lock_project 的 FOR UPDATE。最小实际验证应覆盖 A→错 B→A、missing→A，真实 owner UPDATE rowcount>0 后旧 owner 拒绝/新 owner 返回完整行，rollback 恢复，并比旧函数 SQL/参数/结果/错误代码。该共享函数 PG 调用也受影响，静态 SQL 方向可审但 PG 未运行；本方向意见不认证后续冻结源码或尚未完成门，更不保证省够 30 秒。

本次独审只读取 Git blob、源码、JSON/XML/文本，做字节解码和哈希、复制到新目录；没有导入产品、执行 DB/测试/模型/网络、修改仓库或旧封存。runtime-audit.json、source-result-from-original-assertion.json、原日志/JUnit/inputs/support 与准确 SHA 的源码副本均列入 manifest。本轮完整功能仍不可接受，后续实质新候选与必要短门/终态须另行审查。
