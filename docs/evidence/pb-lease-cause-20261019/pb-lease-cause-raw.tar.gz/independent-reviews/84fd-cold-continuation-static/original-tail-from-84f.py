cold_store = Store(data[1].database_url, test_only=True)
event.listen(cold_store.engine, 'before_cursor_execute', before_sql)
cold_client = TestClient(create_app(cold_store, data[1]))
cold_client.headers['Authorization'] = 'Bearer synthetic-test-A'
cold_data = (cold_store, data[1], cold_client, *data[3:])
original_environment = controller.environment

def cold_environment(store, settings, transport):
    if store is cold_store:
        assert settings is data[1] and transport is None and store.test_only and store.sqlite
    else:
        original_environment(store, settings, transport)
monkeypatch.setattr(controller, 'environment', cold_environment)
try:
    current = cold_client.get('/api/internal/instances/' + inst['id']).json()
    current_app = cold_client.get('/api/apps/' + made['id'])
    assert current_app.status_code == 200, current_app.text
    app = current_app.json()
    assert app['fingerprint'] == made['candidate_fingerprint']
    use_review = dict(expected_revision=current['revision'], expected_release_fingerprint=release['fingerprint'], expected_app_fingerprint=app['fingerprint'], expected_recipe_fingerprint=fingerprint(binding.contract.extraction_recipe.model_dump(exclude_none=True)), resource_id=target.resource_id, card_id=target.card_id, expected_goal_version=target.goal_version, expected_goal_fingerprint=target.goal_fingerprint, expected_source_hash=target.source_hash, request_key=binding.contract.stage_keys.cold)
    base = '/api/internal/instances/' + inst['id']
    checked = cold_client.post(base + '/pb-use-reviews', json=use_review)
    assert checked.status_code == 200, checked.text
    submitted = dict(review=use_review, expected_review_fingerprint=checked.json()['review_fingerprint'], consent=use.CONSENT)
    queued = cold_client.post(base + '/pb-use-runs', json=submitted)
    assert queued.status_code == 202, queued.text
    replayed = cold_client.post(base + '/pb-use-runs', json=submitted)
    assert replayed.status_code == 202, replayed.text
    assert queued.json()['cached'] is False and replayed.json()['cached'] is True
    assert {k: v for k, v in replayed.json().items() if k != 'cached'} == {k: v for k, v in queued.json().items() if k != 'cached'}
    cold_id = queued.json()['run_id']
    approve_stage(cold_data, binding, 'cold', cold_id)
    assert factory(cold_store, data[1], goal_planner_transport=apps.transport([], apps.COLD)).once()
    result = apps.inspect(cold_data, inst, cold_id)
    assert result.status_code == 200 and result.json()['status'] == 'SUCCEEDED', result.text
    owner = cold_client.get(base + f'/runs/{cold_id}/spec-owner-review')
    assert owner.status_code == 200 and owner.json()['owner_acceptance'] == 'PENDING', owner.text
    history = journal.read(cold_store, data[3], binding.contract, binding.approval_key, binding.account_id)
    assert len(history.ledger.slots) == len(fixture['sends']) == 7
    assert not history.ledger.halted and all((s.accepted for s in history.ledger.slots))
    assert len(read_reports) == 4
    assert [r['run_id'] for r in read_reports] == [source_id] * 2 + [cold_id] * 2
    assert [s.identity.stage for s in history.ledger.slots] == ['generate'] * 3 + ['source'] * 2 + ['cold'] * 2
    assert all((b.reserved_at - a.reserved_at >= 60 for a, b in zip(history.ledger.slots[:-1], history.ledger.slots[1:], strict=True)))
    with cold_store.tx() as c:
        rows = c.execute(select(attempts)).mappings().all()
        assert len(rows) == 7 and all((row['mode'] == 'LIVE' for row in rows))
        bodies = c.execute(select(delivery_graph_requests.c.snapshot).where(delivery_graph_requests.c.kind.in_([trial.REQUEST, trial.RESPONSE, archive.REQUEST, archive.RESPONSE]))).scalars().all()
        assert len(bodies) == 22 and all((b['response']['provenance'] == 'SPEC_PRODUCTION_CONTROLLER' for b in bodies))
    (tmp_path / 'pb-controller-proof.json').write_text(json.dumps(dict(classification='SYNTHETIC_MOCK_PRODUCTION_BRANCH_NOT_REAL_LIVE_EVIDENCE', real_models=0, generation=generation, source=source_id, extraction=made['id'], cold=cold_id, original_source=resolved.public_receipt, refusals=failures, result=result.json(), owner=owner.json(), journal=history.model_dump(mode='json'), reservation_read_segments=read_reports, same_key_no_duplicate=True, extraction_new_sends=0, cold_store_reopened=True), indent=2))
finally:
    cold_client.close()
    cold_store.engine.dispose()
    data[2].close()
