9fbcb6a4e682a09f916b4561795f000c609aea10 的有限独立审查：两项 authorize SQL 模板增量未发现新增 P1/P2，实际必要短门通过。该结论不等于完整 P-B 接受、不证明节时，更不把合成 Mock 升格为真实模型或账号权限。新的 authority-standard-pb-full-chain 尚未在此报告审查；此前 a3ee 两次真实完整链失败保持各自原 seal。

准确差异仅 src/sim2act/db.py 和新 tests/test_authorization_statement_shapes.py。读取时 HEAD 正确、工作树干净。新 _AUTHORIZED_RESOURCE_QUERY 只保存 resources.id 与原 id/project membership 谓词；_AUTHORITY_GRANTS_QUERY 只保存完整 grants 行、原 principal/project/resource/tool 四条件、order_by(grants.id)、原 FOR UPDATE。两个模块级常量只含 SQL 树与六个独立 typed bindparam，无实际身份/Store/connection/行/Grant/时钟/权限结果。每次 execute 新建参数字典，两个 identity 各重新读锁当前行，没有合并查询。

独立 AST 核对：将六个 bindparam 替回原调用参数后，两条 SELECT 的完整 AST 与原版一致。归一化这两处 execute 后，authorize 其余 AST 完全相同；Store 其余31方法逐 AST 不变。原 own_project、必要 resource.read 递归、同项目 artifact 分支、[principal,runtime] 顺序、.mappings().all()、无Grant PERMISSION_DENIED、存在但全撤销/过期 GRANT_REVOKED、原 any 中逐项当前 time.time()、全部成功后的 proof authority 登记保持。没有下推 revoked/expiry、加 LIMIT1、去重 identity、缓存 now/许可、扩 scope 或修改 lease/Run/deadline/fence。模块查询对象没有实际执行结果或 authority state。

已独立核同一准确 SHA 的作者实际 command/result/stdout/stderr、JUnit 与输入哈希：

| 实际门 | 结果 | 外层秒数 |
| --- | --- | ---: |
| authority-query-focused | 5 PASS；JUnit 0失败/错误/skip，pytest77.37 s | 87.164974 |
| mypy src | 113 源文件 PASS | 74.872257 |
| Ruff 指定变更文件 | 11 文件 PASS；不是全仓 Ruff 门 | 1.922562 |

三门2113输入各自前后相同且互相一致。独审当前字节哈希与Git blob核714个selected tracked文件，另1399个为scripts/engineering-ci/node_modules依赖。相对a3ee旧输入，仅db.py字节改变并增加新测试文件，没有将依赖或selected集合称为全部已提交环境。

5节点包括新authorization结构单测、原owner/projection两单测、默认生产source/software关闭门、真实post-wait Grant撤销门。新单测执行17组真实本地SQLite对照：资源A/missing/错project/回A，principal/runtime/缺identity/回A、错project/resource/tool/回A，两次实际matching Grant变更及rollback后的当前行。每次新旧SQL/参数逐项比较，完整Grant字典行列表相等，每侧恰1 SELECT。proof JSON存逐组行数与比较结果；原全部SQL/参数在测试内比较，没有另导出逐句transcript，不能冒称有完整独立SQL追踪文件。

实际 Store.authorize 对 data.aggregate_csv 走原resource.read递归，proof_authorities恰登记两项原逻辑authority。之后只改principal一个matching resource.read Grant.revoked=True、只改runtime一个matching Grant.expires_at=0，各次 UPDATE rowcount==1，另一identity仍有效；原 authorize 与 captured proof重核均即时 GRANT_REVOKED，savepoint rollback后原授权恢复。缺runtime真实PERMISSION_DENIED后回原runtime通过。此为实际合成权限/SQL边界验证，使用原实时比较而非改时钟。变更在测试数据库执行并回滚，不说“从未写入”；0 Mock/真实模型，不是活Run或真实生产授权接受。

复用的既有边界测试仍验证默认source缺失、软件资格VERSION_CONFLICT与无业务变化；post-wait真实Grant撤销(rowcount>0)后原heartbeat拒绝并把同一异常对象latch，0Attempt/0send且撤权后snapshot不变。这些短门实际PASS可支持本窄改动，没有为统一SHA机械重跑旧650 s V2或相邻恢复矩阵。

新模块Select被PG调用路径同样使用，不能称SQLite限定改动。FOR UPDATE完整结构静态保留；SQLite实际SQL不会提供PG行锁运行认证，PG/Windows未执行。635次authorize/9.960累计来源较旧416 retained并行profile，不是本新SHA标准链的耗时证据；消除重复表达式构建是静态事实，整体CPU/墙钟改善以及是否足以守住原30 s/300 s仍未证明。所有原权限、资格和时限边界继续有效，后续完整链必须按准确SHA另行记录真实终态。

本独审只读Git/source并做stdlib AST/JSON/XML/哈希和复制新目录，没有导入产品、执行DB/测试/模型/网络、修改仓库或旧seal。review-audit.json记录所有检查和精确门范围；baseline/candidate与tracked.patch保存准确源码；evidence含原门/输入/JUnit及各proof。manifest覆盖本目录全部新交付文件，不自包含。源码与短门意见可支持继续必要的一次标准有界合成端到端检查，尚无完整功能接受结论。
