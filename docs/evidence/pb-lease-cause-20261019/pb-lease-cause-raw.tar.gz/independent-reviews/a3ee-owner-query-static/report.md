a3eeaeddfa441ab652ab2e7948be3d196ee4d286 的有限独审结论：本轮固定 own_project SQL 结构增量未发现新增 P1/P2，必要短门实际通过。该意见不是完整 P-B 工程接受或性能证明；父提交 416432646a89ccade07bbf205ae66ebebfce3526 的实际整链失败单独保留，新的完整七槽结果未纳入本份。

准确增量只有 src/sim2act/db.py 和 tests/test_generation_scope_anchor_projection.py。独立读取时 HEAD 正确、工作树干净。新 _OWNED_PROJECT_QUERY 是模块级固定 Select，只有 projects 表、id/owner 的 AND 谓词和两个独立 typed bindparam；没有 Store、connection、当前 project/principal 值、查询结果、Grant 或权限状态。own_project 每次用当前 project_id/principal 新建参数字典，仍做真实 SELECT，原 mappings().first()、缺行 PERMISSION_DENIED、完整 RowMapping 返回和所有调用位置保留。共享的是 SQL 结构，不是 owner 或授权。

纯 AST 核对：把两个 bindparam 分别替回原方法参数后，完整 SELECT 表达式与旧版一致；归一化唯一 execute 表达式后，own_project 方法其余 AST 相同。Store 其余 31 个方法逐 AST 不变，包括 lock_project 的 FOR UPDATE 以及 authorize 的实时 Grant 与到期/撤销校验。旧 projection 测试函数逐 AST 完全不变，只新增 owner 模板单测。没有新 scope、跨事务状态、权限缓存、lease/时限/Run 状态或 StageAuthority 复用。

已核同一准确 SHA 的作者实际原始 command/result/stdout/stderr、JUnit（适用）和全部输入哈希：

| 实际范围 | 结果 | 外层秒数 |
| --- | --- | ---: |
| owner-query-projection | 2 PASS；JUnit 0失败/错误/skip，pytest 13.94 s | 25.079024 |
| owner-query-boundaries | 2 PASS；JUnit 0失败/错误/skip，pytest 20.27 s | 44.047317 |
| mypy src | 113 源文件 PASS | 41.400569 |
| Ruff 指定变更文件 | 10 文件 PASS；不是全仓 Ruff 门 | 0.850073 |

四项均 2112 输入前后相同，彼此也相同；独立核当前字节哈希和 Git blob 身份，713 selected tracked blob 属于该 SHA，1399 是 scripts/engineering-ci/node_modules 依赖，不能称为提交源码。与 4164 的选中输入差异恰为上述两文件。

owner 新测试在实际本地 SQLite 事务中逐组执行旧 SELECT 和新 own_project，比较完整返回字段（或 PERMISSION_DENIED）、DBAPI SQL 与参数，且每侧恰一 SELECT。8 组实际 authorized 序列为 true/false/true/false/true/false/true/true：A → 错 B → A → missing → A → 真实 owner UPDATE 后旧 owner 拒绝 → 新 owner 完整行通过 → savepoint rollback 后原 owner 恢复。UPDATE rowcount==1 明确断言，排除了空更新的假验证。源断言与实际通过的 JUnit 可检查，owned-project-query-proof.json 保存各组布尔结论；原完整 SQL/参数序列在测试内比较，但没有另行导出逐句 transcript。此测试有合成行更新并回滚，不称“从未执行写入”；0 Mock/真实模型，不产生资源 Grant 或活 Run 授权结论。

边界短测维持真实关闭状态：默认生产 Worker disabled、JournalTrialBinding 不接受 PB，有限 environment 替换仅用于触达 missing source 路径，No reviewed production account evidence source 仍拒绝；实际 admission._qualified() 仍 VERSION_CONFLICT；相关业务 snapshot 无变化，live_authorized=false。另一例原 API 实际创建/claim Generate，在原 wait 返回后真实撤销 Grant 且 rowcount>0，原新增 post-wait heartbeat GRANT_REVOKED，同一异常对象永久记录 state.failure，撤权后全业务 snapshot 不变、0 Attempt/0 send/0 Mock。该 wait 可立即返回，不冒称真实一整分钟等待成功。其具体 proof 与默认门 JSON 原样附后。

共享 own_project 在 PG 路径也会使用新 Select，不能称 SQLite 限定改动。独立静态看原谓词、类型绑定和行处理未放宽，但 PG、Windows、真实模型、真实语义/人工场景和远端 CI 均未执行。短门不能证明减少多少 CPU，更不能保证足够在原 30 s lease 或 300 s Run 截止内完成。没有为此重复旧恢复矩阵或 650 s V2 链；完整 PB 后续终态须单独审查，不拿此四项门替代。

本审查只运行 stdlib 文本/AST、JSON/XML、字节哈希与只读 Git，并复制到新的独立目录；没有导入产品、执行 DB/测试/模型/网络、修改仓库或旧 seal。review-audit.json 收录检查和精确运行范围；baseline/candidate 为准确 Git blob，tracked.patch 为完整差异，evidence 保留所有原始门输出/输入及三份运行 proof。manifest.json 覆盖本目录全部交付文件，不自包含。当前静态与短门范围可支持继续一次有界端到端验证，尚未取得完整可用性接受结论。
