a3eeaeddfa441ab652ab2e7948be3d196ee4d286 带外部 lease_timing_plugin 的完整 P-B 合成链终态：NOT_ACCEPTED。实际 JUnit 1 FAIL、pytest 361.42 s、外层 393.641507 s；14:18:45.410317 → 14:25:19.051756 UTC。2112 个选中输入前后完全相同，与该 SHA 已独审短门输入同一集合（713 tracked blob + 1399 node_modules 依赖）。历史 projection 2P、boundaries 2P、mypy 113P、指定 Ruff 10P 已另封 a3ee-owner-query-static，只支持各自范围，不能替代本次整链失败。

本次实际 4 个合成 Mock：Generate 3、Source 1、Cold 0；真实模型 0。结束后的只读实际行导出显示 Generate run_30af55f55e9548b1be9afb0b64b19c21=PARTIAL、三个 Attempt=RECEIVED；Source run_8faa7c56971d4d238f4c4a83b9cdb6a2=RUNNING、version1/fence1、error=null、result=null，唯一 Source Attempt attempt_073034fa43464f2c80d46e19d9b53044=REJECTED_KNOWN。4 Attempt 均 known usage 100/900/1000。行上 LIVE 是此生产分支合成夹具的模式标记；实际请求来自逐条 SYNTHETIC_MOCK_TRANSPORT_NOT_REAL_HTTP 记录，不是获得真实模型/账号资格。提取、新材料复用、Cold 和完整七槽接受均未完成。

失败的实际调用链是 natural_spec_runtime.advance_model:1021 → settle_verified:1052 → check_commit → production_trial_policy.check_run → natural_live_admission._run_context:934 原有限租约复合 guard。不是 4164 上次已到 :1022 的最后 commit_guard；本次 11228 SQL，4164 上次 12800，工作量/拒绝位置不同，不能用 walltime 或持锁时间直接比较性能。

tx4811 的 acquired=1792419841.5866961，body_end=1792419877.304769，持有 35.718073013 monotonic s，前台 thread CPU 34.524474880 s，11228 条观测 SQL。最后一次真正 heartbeat 已提交返回在 1792419841.5841153，lease=1792419871.5589015，事务结束和错误观测 1792419877.307128 已越过原 lease。Source created_at=1792419744.1129525，冻结 Run300 截止=1792420044.1129525，尚未到 300 s。最后保存的直接 Store.guard 比较为 1792419861.3200328 < lease，仍 RUNNING/fence1 并成功；随后的 policy 复合 guard 精确内部时间值未单独保存，错误包装时刻不冒充该比较值。原 30 s/300 s、owner/fence、版本和权限守卫没有为本次失败放宽。

收包事实完整保留：原 Mock response 619 bytes SHA256=3b5db1ce92cbbdb7e2db7f0937224be8cbfb89d7b3f04426521a4ea69e6ff81e，与公开原 PA_TRIAL_BODY decoded 哈希/字节数一致；规范 JSON 560 bytes SHA256=ef2a4eccddc203547054ac8628940c6b22819ca39e42db0496b806feac575578，与事件 canonical 哈希、结束后 Source Attempt.received_raw 和 raw_evidence 完整相符。请求字节也与原 request body 事件哈希相符。原失败断言中的 Source 公共视图和结束后行状态一致；不能因为已知收包与 usage 保存而称 Source 成功。

作者 ended-DB JSON 记录原数据库 SHA256=b3187d3017ba5772e01ee39d85be32d2b8301be40b0ad01e85a1cbe84c11709d，database_unchanged=true；本独审读取并校对导出的完整 Run/Attempt/冻结合同 JSON 与原日志，没有连接或查询数据库，不将作者导出误称为我重新查库。全部原件、作者阶段汇总提取和准确 SHA 的源码副本已保存在本目录。源 schema 的 Source runtime Limits.max_requests=4 与阶段合同限制的既有分离没有合并；此处只依据真实冻结 run_seconds=300 计算截止。

观察闭合核对通过：5375 对 span IDs/function/时间方向匹配，probe_teardown observations_closed=true，observer_errors/live_transactions/live_observed_background_threads 为空；54 个原 heartbeat 返回、6 个实际 Busy5 错误，未有成功续租越过该业务 writer。启动前 plugin/runner 字节哈希已核一致，二者独立于 2112 选中输入。闭合仅涵盖被观察线程和事务，不能代表整个环境封闭。外部 I/O/stack/CPU/span/SQL 监听存在开销；只监听首个 Store 成功 SQL，failed driver wait 不属于 slow-SQL 耗时，Cold 未执行且未有其 SQL 监听。没有证据把该观察开销定为失败的唯一或充分原因。

对备用标准 pytest 条件的有限判断：同一准确源码仅去掉外部 -p lease_timing_plugin，同时保留原测试/fixture、内部 heartbeat/guard 观察 wrapper、全部断言、HTTP tripwire、实际七槽/1 RPM、30 s lease/300 s Run、外层 1800 s 与独立输入哈希，属于有意义的不同执行条件。去掉额外被动观测不等于跳过产品守卫；原测试内部观察开销仍存在，不能称零观察器。若后续通过，也只能说明那一条件下的合成端到端通过，不能反推本轮失败由 plugin 导致，不能补造无插件运行的 SQL/CPU/事务 span，也不能抹掉此 FAIL 或推广到真实模型、PG/Windows、真实语义/人工验收/远端 CI。standard-pb-full-chain 的终态不在本 seal，必须另审，未提前认证。

本独审只做只读 Git、源码/JSON/XML/日志解析、字节解码/哈希及新审查目录复制，没有导入产品、执行 DB/测试/模型/网络、修改仓库或旧 seal。运行未结束时只读取命令/输入/support 和不可变 Git blob，未读取活动 DB。初次准备误用旧 support JSON 的 files-list 结构而遇 KeyError，按实际 inputs 字典纠正；仅影响未封存审查材料组装，已在 review-preparation.json 如实记录，不是作者运行错误。runtime-audit.json 明确实际状态、已知收包和证据局限，manifest.json 覆盖本次新增交付。
