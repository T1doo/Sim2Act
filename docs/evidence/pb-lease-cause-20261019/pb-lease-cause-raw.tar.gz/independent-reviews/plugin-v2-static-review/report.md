# Passive plugin v2 — limited independent source review

The preserved v1 hash matches the plugin used for the 77b full-chain evidence: `a362451e09aee7076d8e634b384f02a58e5c4ce99778e30bef4cbab848e20d95`. That evidence is not relabeled with the candidate plugin.

No new product P1/P2 is identified by this passive-plugin increment. The source is suitable for one bounded observation, subject to checking its actual completion. No runtime success or PB acceptance is certified here.

Active-transaction changes, restoration, statement increments and the teardown snapshot now use a short observer mutex. Original database calls are outside that mutex, and callers leave it before calling `record`. No observer-lock/DB-lock inversion is introduced by these blocks. The wrapper still calls the original Store transaction, claim, heartbeat and validation functions and returns original values or rethrows original exceptions. The ClockProbe delegates the original time value. It does not alter lease, deadline, approval, contract or request arguments. Registering stream closure at process exit removes the earlier fixture-close versus late background-log race. A copied active snapshot avoids the earlier concurrent dictionary-iteration risk.

Limitations remain material to evidence interpretation:

- File I/O, stack collection and CPU/timing measurements add scheduling overhead. The wrapper is not scheduling-transparent and cannot establish uninstrumented performance.
- `observations_closed` is one teardown snapshot, not a thread join or a proof that no later background work can occur. Its background set contains threads observed through a `beat` heartbeat stack; it is not an exhaustive thread inventory. If actual teardown reports live transactions/background threads, or later observer errors, observation must be marked incomplete. Event listener removal can still race a live SQL listener invocation in that situation. This is not grounds to kill or rerun unrelated processes; preserve the actual outcome.
- `after_sql` reads the current thread's active entry outside the mutex; it performs no shared dictionary iteration. This does not recreate the old teardown iteration problem, but the identifiers are diagnostic observations.
- Slow SQL records successful `after_cursor_execute` statements. Failed driver waits do not have matching successful SQL timing. SQL listeners still attach only to the first Store engine; Cold transactions/heartbeat spans can be observed, but Cold SQL timing is absent.
- Existing error collection/teardown assertion is a diagnostic check, not proof of error-free future logging after its snapshot. The run must be read to its actual end.

Review was byte/source/diff inspection only. No product module import, database query/connection, model, test, network or signal was executed. No product/tests/Git were changed. Prior review seals remain untouched. The 77b full PB chain remains failed, and the new same-call origin source increment still needs a fresh qualified bounded chain; structural retained-copy assertions do not replace it.
