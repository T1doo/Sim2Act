"""Run the shared regression assertions on a retained synthetic prefix copy."""
import hashlib
import json
import sqlite3
import sys
import time
from pathlib import Path

import httpx
import pytest
from sqlalchemy import event, select

repo = Path("/workspace/Sim2Act")
sys.path.insert(0, str(repo / "tests"))
from test_running_source_origin import check_running_source_origin  # noqa: E402

from sim2act.contracts import Limits  # noqa: E402
from sim2act.db import Store, runs  # noqa: E402

root = Path(__file__).resolve().parent
out = root / "retained-origin-check"
out.mkdir(exist_ok=False)
original = root / "same-call-origin-isolated/tmp/test_running_original_source_r0/fixture.db"
target = out / "copy.db"
with sqlite3.connect("file:" + str(original) + "?mode=ro", uri=True) as source, sqlite3.connect(target) as copy:
    source.backup(copy)
original_hash = hashlib.sha256(original.read_bytes()).hexdigest()
before_hash = hashlib.sha256(target.read_bytes()).hexdigest()


def forbidden(*args, **kwargs):
    raise AssertionError("No model or real HTTP is allowed in retained structural assertions")


httpx.HTTPTransport.handle_request = forbidden
httpx.AsyncHTTPTransport.handle_async_request = forbidden
httpx.MockTransport.handle_request = forbidden
httpx.MockTransport.handle_async_request = forbidden
store, sql = Store("sqlite:///" + str(target), test_only=True), [0]


def counted(*args):
    sql[0] += 1


event.listen(store.engine, "before_cursor_execute", counted)
with store.tx() as c:
    job = dict(c.execute(select(runs).where(runs.c.status == "RUNNING")).mappings().one())
start, cpu = time.monotonic(), time.thread_time()
try:
    with pytest.MonkeyPatch.context() as patch:
        check_running_source_origin(store, job["principal_id"], job["project_id"],
            job["resource_refs"][0], job, Limits(), out, patch)
finally:
    elapsed, used = time.monotonic()-start, time.thread_time()-cpu
    store.engine.dispose()
record = dict(scope="RETAINED_MOCK_PREFIX_COPY_SHARED_STRUCTURAL_ASSERTIONS_NOT_NEW_RUN_ACCEPTANCE",
    original_prefix_phase="same-call-origin-isolated: failed test serializer after actual 3-Mock Generate prefix",
    original_db_sha256=original_hash, original_db_unchanged=original_hash == hashlib.sha256(original.read_bytes()).hexdigest(),
    copy_before_sha256=before_hash, copy_after_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),
    head_assertions_passed=True, new_mock_exchanges=0, real_models=0, source_attempts=0,
    lease_or_run_timestamps_changed=False, approvals_or_qualification_rewritten=False,
    elapsed_seconds=elapsed, thread_cpu_seconds=used, statements=sql[0])
(out / "result.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record, indent=2))
