"""No-send, query-only profiling on a backup of the failed synthetic Source."""
import functools
import hashlib
import json
import sqlite3
import sys
import time
from pathlib import Path

import httpx
from sqlalchemy import event, select

from sim2act import goal_applications as generation
from sim2act import natural_live_admission as gate
from sim2act import natural_source_archives as archive
from sim2act import natural_spec_runtime as runtime
from sim2act import pa_spec_apps as spec
from sim2act import pb_natural_specs as pb
from sim2act.db import Store, delivery_graph_requests, runs
from sim2act.errors import DomainError

root = Path(__file__).resolve().parent
out = root / sys.argv[1]
out.mkdir(exist_ok=False)
original = root / "pb-full-chain/tmp/test_pb_production_original_so0/fixture.db"
target = out / "copy.db"
with sqlite3.connect("file:" + str(original) + "?mode=ro", uri=True) as src, sqlite3.connect(target) as dest:
    src.backup(dest)


def denied(*args, **kwargs):
    raise AssertionError("Real HTTP and models are forbidden in query-only profiling")


httpx.HTTPTransport.handle_request = denied
httpx.AsyncHTTPTransport.handle_async_request = denied
stats, stack, sql_count = {}, [], [0]


def observe(owner, name):
    original = getattr(owner, name)
    key = owner.__name__ + "." + name

    @functools.wraps(original)
    def observed(*args, **kwargs):
        start, cpu, entry = time.monotonic(), time.thread_time(), [0.0]
        stack.append(entry)
        try:
            return original(*args, **kwargs)
        finally:
            elapsed, used = time.monotonic()-start, time.thread_time()-cpu
            stack.pop()
            if stack:
                stack[-1][0] += used
            item = stats.setdefault(key, dict(calls=0, wall=0.0, inclusive_cpu=0.0, self_cpu=0.0, max_wall=0.0))
            item["calls"] += 1
            item["wall"] += elapsed
            item["inclusive_cpu"] += used
            item["self_cpu"] += used-entry[0]
            item["max_wall"] = max(item["max_wall"], elapsed)

    setattr(owner, name, observed)


for module, names in ((Store, ("_frozen_contract_after_scope", "authorize")),
    (generation, ("source_scope_gate",)),
    (spec, ("job_scope_gate", "bound", "_bound", "verify_origin", "model_source", "audit_fingerprint", "receipts")),
    (runtime, ("counters",)),
    (gate, ("_current", "_approved", "_stage_current", "_stage_current_bound", "_generation_accounted", "implementation")),
    (archive, ("_resolve_trial_source",))):
    for name in names:
        observe(module, name)

store = Store("sqlite:///" + str(target), test_only=True)


def count_sql(c, cursor, statement, parameters, context, executemany):
    assert statement.lstrip().upper().startswith("SELECT "), "Only SELECT allowed after query-only boundary"
    sql_count[0] += 1


sections, failure, values = [], None, {}
with store.engine.connect() as c:
    c.exec_driver_sql("BEGIN IMMEDIATE")
    c.exec_driver_sql("PRAGMA query_only=ON")
    event.listen(store.engine, "before_cursor_execute", count_sql)
    try:
        job = dict(c.execute(select(runs).where(runs.c.id == "run_f50b9c630669410c836f35f60c853155")).mappings().one())
        saved = c.execute(select(delivery_graph_requests.c.snapshot).where(
            delivery_graph_requests.c.kind == gate.SCOPE)).scalar_one()
        contract = gate.PBTrialContract.model_validate(saved["request"])
        approval = c.execute(select(delivery_graph_requests.c.snapshot).where(
            delivery_graph_requests.c.kind == gate.APPROVE)).scalar_one()
        key = approval["response"]["request"]["request_key"]
        with pb._source_reads(store, c):
            for name, call in (("source_scope", lambda: generation.source_scope_gate(store, c, job["id"])),
                ("bound", lambda: spec.bound(store, c, job["principal_id"], job, gate._limits(contract))),
                ("receipts", lambda: spec.receipts(store, c, job, values["bound"])),
                ("original_run_context_expected_stale_refusal", lambda: gate._run_context(store, c,
                    job["principal_id"], contract, key, "source", job["id"], job["version"], job["fence"]))):
                before, cpu, count = time.monotonic(), time.thread_time(), sql_count[0]
                try:
                    value = call()
                    if name == "bound":
                        values["bound"] = value
                except DomainError as error:
                    failure = error.public()
                    break
                finally:
                    sections.append(dict(section=name, wall=time.monotonic()-before,
                        thread_cpu=time.thread_time()-cpu, sql=sql_count[0]-count))
    finally:
        event.remove(store.engine, "before_cursor_execute", count_sql)
        c.rollback()
store.engine.dispose()
record = dict(scope="EXPIRED_FAILED_SOURCE_COPY_SELECT_ONLY_NOT_RUN_AUTHORITY_OR_PB_ACCEPTANCE",
    original_db_sha256=hashlib.sha256(original.read_bytes()).hexdigest(),
    copy_db_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),
    real_models=0, mock_exchanges=0, writes=0, sections=sections, final_error=failure, functions=stats)
(out / "profile.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record, indent=2))
