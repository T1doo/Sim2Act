# Generate 短 SQLite 冲突后的续租修复

源代码和最终测试基准：`77b54fcd10f899ac32fe57a588ba046751a79c63`，普通开发分支 `dev/production-trial-stages-20261018`。该提交的产品源码与 `a3408bcd71c0d25830cc0bd8342ac4fc70e259ae` 完全相同；前者仅修正测试字段并增加被动计时。远端基准为 `5bd438812a9914fac827014336a5ba38b63d08dc`，原始 `8fc70cc4` 和 `2b290038` 均在祖先链内。

## 因果与修复边界

`1030aade` 在原 Store/Worker/Generate 上，以测试持有的 SQLite writer 和事务外前台调度边界复现：实际 BUSY 5 后，旧 `beat` 永久停止。writer 在 `1792411050.2539933` 释放，原 beat 在 `1792411050.2594326` 返回且 stopped=true，此时距 claim 返回的原 lease `1792411064.6347628` 尚有约 14.38 秒。没有后续成功的 Run 续租返回。原 guard 的真实比较值 `1792411064.741036` 超过该 lease，原 fence 保持 1，Run 仍 RUNNING，请求/Attempt 均为 1。此例只证明故障机制，不是完成 Generate 或 P-B 验收。

Generate 现在复用既有 `Worker._heartbeat_lease` 的有限 SQLite BUSY/LOCKED 重试；同一 metadata Lock 发布实际提交的 lease 与首个永久错误。前台在业务事务外续租，逐槽等待检查锁存错误，生产 sender 使用同一状态。保留原 Store.guard、worker/fence/CAS、权限、源证明、合同和截止边界；没有延长 lease 设置、合同上限、绝对 deadline，没有新增 executor、Grant、Source 或资格锚点。

`a3408bcd` 的首个验证实际 **2F**：第一例在 Mock 发出前一笔前台 heartbeat 事务耗时 47.628 秒，50 秒内未抵达调度边界，清理时前台 daemon 仍 alive；第二例为测试错误引用不存在的 Grant runtime 字段。失败原件均保留。没有旧 CPU/SQL 细分，后来快速 span 不能补推这笔长事务的原因，也不能认定旧 v7 的具体持锁事务。本轮没有补回旧环境满盘时未落盘的独审报告。

## 同 SHA 实际验证

| 阶段 | SHA | 实际结果 | 外层耗时 | 新 Mock |
|---|---|---|---:|---:|
| 原机制定向回归 | 1030aade | 1F，保留原失败 | 43.726805 秒 | 1 |
| 首次候选验证 | a3408bcd | 2F，长事务及测试字段错误 | 221.376169 秒 | 0 |
| 补足计时的两项定向验证 | 77b54fcd | 2P | 62.435865 秒 | 1 |
| 相关安全与既有 helper 边界 | 77b54fcd | 9P | 147.215431 秒 | 1 |
| 完整 src mypy | 77b54fcd | 113 源文件通过 | 64.391940 秒 | 0 |
| 变更文件 Ruff | 77b54fcd | 5 文件通过 | 0.894974 秒 | 0 |
| 原 P-B 完整 Mock 链 | 77b54fcd | 待终态 | 待终态 | 待终态 |

2P 定向例中 writer 实持锁 `1792412132.872535 → 1792412137.9426835`，5.070149 秒，发生实际 BUSY 5 后续租恢复。在旧实际 lease `1792412152.2983975` 已过的原 guard 探针时，Run 仍 RUNNING，真实新 lease 为 `1792412178.1086988`，原 guard 无错误，请求/Attempt 均为 1，无重复发送；所有测试线程均退出，观测/前台错误为空。另一例实际撤销合成 Grant，原 GRANT_REVOKED 错误被锁存，后续续租和未预留等待不再推进，0 Mock。

9P 包含原所有权/过期检查、有限驱动错误重试、提交区间和永久错误原子发布，以及既有 **Generate** 收包后 Source 撤销用例。最后一例是 1 Mock，已收 bytes/hash、known usage、双 CAPTURE、ledger settled/halted 和不成功 Run 均按原断言保留；它不是注入 heartbeat-fatal 的新测试。

## 证据及局限

各阶段保留准确 command、result、stdout/stderr、JUnit、2111 输入前后 hash、合成数据库、Mock 原文和失败观察。三个精确源码/测试/脚本/配置快照位于 `source-snapshots/`。runner、计时插件、环境版本和摘要算法一并提供。2111 项包括 712 项仓库输入及 1399 项 JS 依赖；它不是 Python 安装、runner 和主机的封闭式清单。

被动 span、stack、SQL 计时及文件 IO 会增加调度开销。完整链插件的 SQL 监听只覆盖第一个 Store 的成功语句；失败 driver wait 无 after 事件，Cold engine SQL 未监听；事务、heartbeat 和验证 span 包含新 Store。插件收尾的并发快照及 stream 关闭局限由独审记录，任何存活事务或观测错误均需单独披露，不能声称日志闭合。

非 trial Generate 的旧 adapter guard 尚不能据本轮结果声称永久错误发布后的每个极小发送窗口都被立即阻止；本轮 P-B 走生产 sender 的显式续租检查。没有扩成相邻恢复或故障矩阵。

全部为 Linux、test-only SQLite、有限 Mock 和合成身份。真实模型/真实账号探测均为 0。未执行 Windows、真实语义/场景、PG、原生浏览器产品验收、远端 CI、部署和用户人工接受；人工验收入口的可读状态不能当成人已接受。未安装真实账户 Source，也未重写资格/软件锚点。原 Actions API 403 未改凭据重试。
