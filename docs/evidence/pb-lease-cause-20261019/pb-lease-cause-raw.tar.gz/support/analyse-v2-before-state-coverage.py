"""Summarize retained raw observations; never imports or runs Sim2Act."""
import hashlib
import json
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def paired(events, opening, closing, key):
    entered = {e[key]: e for e in events if e["kind"] == opening}
    result = []
    for end in events:
        if end["kind"] == closing and end[key] in entered:
            start = entered[end[key]]
            item = dict(identity=start[key], wall_seconds=end["wall"]-start["wall"],
                thread=start["thread"], function=start.get("function"), start=start, end=end)
            for clock in ("process_cpu", "thread_cpu"):
                item[clock+"_seconds"] = end[clock]-start[clock] if clock in start and clock in end else None
            result.append(item)
    return sorted(result, key=lambda r: r["wall_seconds"], reverse=True)


phases = {}
for phase in ("baseline-directed", "fixed-directed", "transaction-spans", "focused-boundaries", "mypy", "ruff", "pb-full-chain",
    "readonly-profile-command", "readonly-profile-corrected-command", "same-call-origin", "same-call-origin-isolated",
    "retained-origin-command", "retained-origin-corrected-command", "final-mypy", "final-ruff", "final-focused",
    "bounded-final-focused", "aligned-final-focused", "delivery-mypy", "delivery-ruff", "bounded-pb-full-chain"):
    folder = ROOT / phase
    item = dict(result=json.loads((folder / "result.json").read_text()))
    proofs = list(folder.glob("tmp/*0/directed-lease-proof.json"))
    if proofs:
        proof = json.loads(proofs[0].read_text())
        events = proof.pop("events")
        item.update(proof=proof, longest_transactions=paired(events, "tx_acquired", "tx_body_end", "transaction")[:8],
            longest_validation_spans=paired(events, "span_enter", "span_exit", "span")[:8],
            timeline=[e for e in events if e["kind"] in {"claimed", "inject_writer_requested", "owned_writer_acquired",
                "owned_writer_released", "heartbeat_error", "original_beat_return", "original_interval_probe", "test_teardown"}])
        item["actual_committed_lease_returns"] = [e for e in events if e["kind"] == "heartbeat_committed_return"]
    item["mock_exchanges"] = sum(len(p.read_text().splitlines()) for p in folder.glob("tmp/*0/mock-exchanges.jsonl"))
    if phase in {"same-call-origin", "same-call-origin-isolated"}:
        databases = list(folder.glob("tmp/*0/fixture.db"))
        with sqlite3.connect("file:" + str(databases[0]) + "?mode=ro", uri=True) as c:
            rows = c.execute("SELECT runs.id,runs.status,attempts.mode,attempts.status FROM attempts JOIN runs ON runs.id=attempts.run_id").fetchall()
        item["additional_prefix_received_mock_attempts"] = len([r for r in rows if r[1:] == ("PARTIAL", "MOCK", "RECEIVED")])
        item["prefix_receipts_without_separate_transport_counter"] = rows
    chain_proofs = list(folder.glob("tmp/*0/pb-controller-proof.json"))
    if chain_proofs:
        item["pb_proof"] = json.loads(chain_proofs[0].read_text())
    traces = list(folder.glob("tmp/*0/lease-transaction-timings.jsonl"))
    if traces:
        events = [json.loads(line) for line in traces[0].read_text().splitlines()]
        item["full_chain_timing"] = dict(
            claims=[e for e in events if e["kind"] == "claim_return"],
            heartbeat_errors=[e for e in events if e["kind"] == "heartbeat_error"],
            tx_errors=[e for e in events if e["kind"] == "tx_error"],
            teardown=[e for e in events if e["kind"] == "probe_teardown"],
            longest_transactions=paired(events, "tx_acquired", "tx_body_end", "transaction")[:12],
            longest_validation_spans=paired(events, "span_enter", "span_exit", "span")[:12],
            committed_renewals=len([e for e in events if e["kind"] == "heartbeat_return" and e["actual_committed_lease"] is not None]))
    phases[phase] = item

direct_count = sum(p["mock_exchanges"] for p in phases.values())
prefix_count = sum(p.get("additional_prefix_received_mock_attempts", 0) for p in phases.values())
report = dict(phases=phases, direct_transport_log_mock_exchanges=direct_count,
    additional_received_mock_attempts_without_separate_transport_counter=prefix_count,
    total_new_mock_exchange_evidence=direct_count+prefix_count,
    real_models=0, real_account_probes=0,
    causal_limit="The baseline reproduces transient BUSY -> permanently stopped Generate heartbeat -> expired original guard. Neither later fast spans nor this fix identify the exact old v7 long holder or reconstruct CPU for the first a340 47.628s transaction.",
    observation_limits=["Timing observers add CPU, stack and file IO overhead and may affect scheduling.",
        "The full-chain SQL observer covers the first Store engine and successful statements only; failed driver waits and Cold engine SQL are outside slow_sql.",
        "The runner hashes 2111 selected source/test/script/config/JS dependency inputs; it is not a hermetic inventory of Python dependencies, runner or host.",
        "Baseline is a scheduler-and-owned-writer mechanism test, not completed generation or P-B acceptance.",
        "Existing Generate received-source-revocation case is not a heartbeat-fatal injection."])
(ROOT / "analysis.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(dict(results={k: v["result"]["returncode"] for k,v in phases.items()},
    total_new_mock_exchange_evidence=report["total_new_mock_exchange_evidence"],
    analysis_sha256=hashlib.sha256((ROOT / "analysis.json").read_bytes()).hexdigest()), indent=2))
