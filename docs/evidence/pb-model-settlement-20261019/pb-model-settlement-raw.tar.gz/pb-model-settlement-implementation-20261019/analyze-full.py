"""Post-run arithmetic on passive observations only; no product imports/DB IO."""
import collections
import hashlib
import json
from pathlib import Path

root = Path(__file__).parent
phase = root / 'model-continuation-full-pb'
matches = list((phase / 'tmp').rglob('full-stage-probe.json'))
assert len(matches) == 1, matches
source = matches[0]
data = json.loads(source.read_text())
ended = json.loads((root/'ended-state.json').read_text())
run_rows = {row['id']:row for row in ended['tables']['runs']}
result = dict(classification='POST_RUN_OBSERVER_ARITHMETIC_NOT_ADDITIONAL_ACCEPTANCE',
    observer_source=str(source.relative_to(root)),
    observer_record_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
    phase=json.loads((phase/'result.json').read_text()), stages={})
for stage, state in data['stages'].items():
    events = state['events']
    contract_run_deadline=min(run_rows[state['run_id']]['created_at']+
        state['contract']['caps']['run_seconds'],state['contract']['expires_at'])
    scopes = []
    for position, entry in enumerate(events):
        if entry['kind'] != 'model_scope_enter':
            continue
        ending = next((i for i in range(position+1, len(events)) if
            events[i]['kind'] in {'model_scope_closed','model_scope_error'}
            and events[i].get('attempt_id') == entry['attempt_id']), None)
        segment = events[position:ending+1 if ending is not None else None]
        txid = entry['transaction']
        acquired_index = next((i for i in range(position-1,-1,-1) if
            events[i]['kind']=='tx_acquired' and events[i]['transaction']==txid
            and events[i]['thread']==entry['thread']), None)
        body_end_index = next((i for i in range(position,len(events)) if
            events[i]['kind']=='tx_body_end' and events[i]['transaction']==txid
            and events[i]['thread']==entry['thread']), None)
        acquired=None if acquired_index is None else events[acquired_index]
        body_end=None if body_end_index is None else events[body_end_index]
        outcome = next((row for row in events[position:] if
            row['kind'] in {'tx_committed','tx_error'} and row['transaction']==txid), None)
        tx_segment = events[acquired_index:body_end_index+1] if (
            acquired_index is not None and body_end_index is not None) else []
        traversal_counts = collections.Counter(row['function'] for row in segment
            if row['kind']=='model_proof_call_enter')
        post_counts = collections.Counter(row['function'] for row in segment
            if row['kind']=='model_proof_call_enter' and row.get('model_phase')=='consumers')
        tx_spans = collections.Counter(row['function'] for row in tx_segment
            if row['kind']=='span_enter')
        scopes.append(dict(run_id=entry['run_id'], attempt_id=entry['attempt_id'],
            transaction=txid, observer_sql=body_end and body_end['sql'],
            observer_writes=body_end and body_end['writes'],
            transaction_wall_seconds=None if not body_end or not acquired else
                body_end['monotonic']-acquired['monotonic'],
            transaction_thread_cpu_seconds=None if not body_end or not acquired else
                body_end['cpu']-acquired['cpu'],
            transaction_entry_lease_margin=None if not acquired else entry['lease_until']-acquired['wall'],
            entry_postwrite_lease_margin=entry['lease_margin'],
            transaction_end_lease_margin=None if not body_end else entry['lease_until']-body_end['wall'],
            transaction_end_node_run_margin=None if not body_end else entry['run_deadline']-body_end['wall'],
            transaction_end_contract_run_margin=None if not body_end else contract_run_deadline-body_end['wall'],
            scope_outcome=segment[-1]['kind'] if ending is not None else 'NO_END_RECORDED',
            transaction_outcome=None if not outcome else outcome['kind'],
            scope_wall_seconds=None if ending is None else segment[-1]['monotonic']-entry['monotonic'],
            proof_call_counts=dict(traversal_counts),
            consumer_proof_call_counts=dict(post_counts),
            whole_transaction_span_counts=dict(tx_spans),
            live_checks=sum(row['kind']=='model_live_enter' for row in segment),
            ready_states=[row['state'] for row in segment if row['kind']=='model_scope_ready'],
            final_states=[row['state'] for row in segment if row['kind']=='model_scope_closed']))
    transactions=[]
    for position,row in enumerate(events):
        if row['kind']!='tx_body_end':
            continue
        begin=next((value for value in reversed(events[:position]) if value['kind']=='tx_acquired'
            and value['transaction']==row['transaction'] and value['thread']==row['thread']),None)
        if begin is not None:
            transactions.append(dict(transaction=row['transaction'],thread=row['thread'],
                sql=row['sql'],writes=row['writes'],
                wall_seconds=row['monotonic']-begin['monotonic'],
                thread_cpu_seconds=row['cpu']-begin['cpu']))
    result['stages'][stage]=dict(run_id=state['run_id'],scopes=scopes,
        transactions=transactions,
        complete_predicate_min_lease_margin=min((row['lease_margin'] for row in events
            if row['kind']=='complete_row_predicate_return'),default=None))
result['limitations'] = [
    'Synthetic test-only SQLite, finite MockTransport; no real account/model evidence.',
    'Passive observations add overhead and cannot guarantee wall-time or CPU margin elsewhere.',
    'Scope records for Source retain original non-continuation path; only Cold may use the new continuation.',
    'tx_body_end is before the commit call; tx_committed confirms return, not a separate DB clock sample.',
    'Node and contract Run margins are reported separately; neither alone is the combined minimum of every authority deadline.',
    'Observer events are not a substitute for the original test assertions and raw DB/proofs.',
    'Previously entered background wrappers are not joined by observer undo.',
]
(root/'full-observer-metrics.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(returncode=result['phase']['returncode'],stages={
    key:dict(run_id=value['run_id'],scopes=value['scopes']) for key,value in result['stages'].items()}),indent=2))
