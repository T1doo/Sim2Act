"""Read the ended fresh test fixture only; never resume or authorize a Run."""
import datetime
import hashlib
import json
import sqlite3
from pathlib import Path

root=Path(__file__).parent
phase=root/'model-continuation-full-pb'
assert (phase/'result.json').exists(), 'Wait for the actual test process exit'
matches=list((phase/'tmp').rglob('fixture.db'))
assert len(matches)==1,matches
db=matches[0]
before=hashlib.sha256(db.read_bytes()).hexdigest()
tables={}
with sqlite3.connect(db.as_uri()+'?mode=ro',uri=True) as connection:
    connection.row_factory=sqlite3.Row
    for table in ('runs','attempts','operations','internal_app_runs','events','reservations'):
        tables[table]=[dict(row) for row in connection.execute('SELECT * FROM '+table)]
after=hashlib.sha256(db.read_bytes()).hexdigest()
assert before==after,'Diagnostic read must not change the ended fixture'
record=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    classification='ENDED_SYNTHETIC_FIXTURE_RAW_READ_ONLY_DIAGNOSTIC_NOT_RUNTIME_ADMISSION',
    fixture=str(db.relative_to(root)),database_sha256_before=before,
    database_sha256_after=after,database_unchanged=True,tables=tables,
    real_models=0,resumed_runs=0,new_sends=0,
    limitations='SQL JSON fields retain their actual stored string representation; no real account/semantic acceptance.')
(root/'ended-state.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(database_sha256=before,rows={key:len(value) for key,value in tables.items()},
    runs=[{key:row[key] for key in ('id','status','result','error','version','lease_until')}
          for row in tables['runs']]),ensure_ascii=False))
