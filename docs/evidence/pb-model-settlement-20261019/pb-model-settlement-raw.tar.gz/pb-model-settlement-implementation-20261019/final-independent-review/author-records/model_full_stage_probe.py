"""Original full P-B assertions with passive per-stage/readback observations."""
import functools
import hashlib
import json
import threading
import time
from contextlib import contextmanager
from pathlib import Path

import pytest
from sqlalchemy import event


@pytest.hookimpl(wrapper=True)
def pytest_runtest_call(item):
    if item.name != 'test_pb_production_original_source_extraction_explicit_use_and_cold':
        return (yield)
    from test_pb_cold_local_read_lease import ColdReadProbe
    from sim2act import pa_trial_dispatch as trial
    from sim2act import natural_spec_runtime as runtime
    from sim2act import natural_live_admission as gate
    module = item.module
    out = item.funcargs['tmp_path']
    original = module.approve_stage
    stages, patches = {}, {}

    def finish(stage):
        state = stages[stage]
        if state['finished']:
            return
        state['probe'].active = False
        event.remove(state['store'].engine, 'before_cursor_execute', state['sql'])
        patches[stage].undo()
        state['finished'] = True

    def approve(data, binding, stage, run_id):
        result = original(data, binding, stage, run_id)
        if stage not in {'source', 'cold'}:
            return result
        assert stage not in stages
        if stage == 'cold':
            finish('source')
        patch = pytest.MonkeyPatch()
        probe = ColdReadProbe(data[0], run_id, stop_first=False)
        sql = probe.install(patch)
        original_readback = trial.check_commit_after_readback
        local = threading.local()
        @functools.wraps(original_readback)
        def readback(worker, c, run, read_out, **kwargs):
            watched = probe.active and threading.get_ident() == probe.main and run['id'] == run_id
            stamp = read_out.get('stamp')
            if watched:
                local.readback = True
                probe.record('readback_commit_enter', run_id=run_id, stamp_present=stamp is not None,
                    stamp_consumed=None if stamp is None else stamp.consumed,
                    tail_authority_count=len(kwargs.get('_tail_authorities',())),
                    token=id(c.info.get('pb_source_reads')),epoch=c.info.get('source_proof_write_epoch',0))
            try:
                return original_readback(worker, c, run, read_out, **kwargs)
            finally:
                if watched:
                    probe.record('readback_commit_exit', run_id=run_id,
                        stamp_consumed=None if stamp is None else stamp.consumed,
                        output_cleared='stamp' not in read_out)
                    local.readback = False
        patch.setattr(trial, 'check_commit_after_readback', readback)
        original_scope = runtime._model_settlement_read
        original_predicate = gate._require_run_context_row

        def model_event(kind, c, inputs, proof=None, **values):
            entry = getattr(probe.local, 'entry', None)
            fresh = inputs.get('fresh', inputs['current'])
            at = time.time()
            probe.record(kind, run_id=fresh['id'], attempt_id=inputs['aid'],
                transaction=None if entry is None else entry['transaction'],
                sql=None if entry is None else entry['sql'],
                epoch=c.info.get('source_proof_write_epoch', 0),
                lease_until=fresh['lease_until'], lease_margin=fresh['lease_until']-at,
                run_deadline=fresh['created_at']+inputs['node'].run_seconds,
                run_margin=fresh['created_at']+inputs['node'].run_seconds-at,
                state=None if proof is None else proof.state,
                source_deadline=None if proof is None else proof.source_deadline,
                **values)

        @contextmanager
        def model_scope(worker, c, inputs):
            watched = probe.active and threading.get_ident()==probe.main and inputs['current']['id']==run_id
            if not watched:
                with original_scope(worker,c,inputs) as result:
                    yield result
                return
            local.model_inputs, local.model_proof = inputs, None
            local.model_phase = 'full_postwrite_proof'
            model_event('model_scope_enter',c,inputs)
            try:
                with original_scope(worker,c,inputs) as result:
                    local.model_proof = result[2]
                    local.model_phase = 'consumers'
                    model_event('model_scope_ready',c,inputs,result[2])
                    yield result
                model_event('model_scope_closed',c,inputs,local.model_proof)
            except BaseException as error:
                model_event('model_scope_error',c,inputs,local.model_proof,
                    error_type=type(error).__name__)
                raise
            finally:
                local.model_inputs=local.model_proof=local.model_phase=None
        patch.setattr(runtime,'_model_settlement_read',model_scope)

        def predicate(user, contract, stage, row, version, fence, approval, phase, at):
            watched = probe.active and threading.get_ident()==probe.main and row is not None and row['id']==run_id
            try:
                result=original_predicate(user,contract,stage,row,version,fence,approval,phase,at)
            except BaseException as error:
                if watched:
                    probe.record('complete_row_predicate_error',run_id=run_id,at=at,
                        lease_until=row['lease_until'],lease_margin=row['lease_until']-at,
                        error_type=type(error).__name__,model_phase=getattr(local,'model_phase',None))
                raise
            if watched:
                probe.record('complete_row_predicate_return',run_id=run_id,at=at,
                    lease_until=row['lease_until'],lease_margin=row['lease_until']-at,
                    model_phase=getattr(local,'model_phase',None))
            return result
        patch.setattr(gate,'_require_run_context_row',predicate)

        for name in ('check_commit','_journal_chain','_journal_source'):
            original_model_call=getattr(trial,name)
            def model_call(function,label):
                @functools.wraps(function)
                def call(*args,**kwargs):
                    inputs=getattr(local,'model_inputs',None)
                    watched=probe.active and threading.get_ident()==probe.main and inputs is not None
                    if watched:
                        model_event('model_proof_call_enter',args[1],inputs,
                            getattr(local,'model_proof',None),function=label,
                            model_phase=getattr(local,'model_phase',None))
                    try:
                        return function(*args,**kwargs)
                    finally:
                        if watched:
                            model_event('model_proof_call_exit',args[1],inputs,
                                getattr(local,'model_proof',None),function=label,
                                model_phase=getattr(local,'model_phase',None))
                return call
            patch.setattr(trial,name,model_call(original_model_call,name))

        original_live=runtime._ModelSettlementRead.live
        @functools.wraps(original_live)
        def live(proof):
            watched=probe.active and threading.get_ident()==probe.main and proof.inputs['current']['id']==run_id
            if watched:
                model_event('model_live_enter',proof.connection,proof.inputs,proof)
            try:
                return original_live(proof)
            finally:
                if watched:
                    model_event('model_live_exit',proof.connection,proof.inputs,proof)
        patch.setattr(runtime._ModelSettlementRead,'live',live)
        for name in ('_journal_source', 'check_commit'):
            original_call = getattr(trial, name)
            def observe_call(function, label):
                @functools.wraps(function)
                def call(*args, **kwargs):
                    watched = probe.active and getattr(local,'readback',False) and threading.get_ident()==probe.main
                    if watched:
                        probe.record('readback_nested_enter', function=label,run_id=run_id)
                    try:
                        return function(*args, **kwargs)
                    finally:
                        if watched:
                            probe.record('readback_nested_exit', function=label,run_id=run_id)
                return call
            patch.setattr(trial,name,observe_call(original_call,name))
        stages[stage] = dict(probe=probe,sql=sql,store=data[0],finished=False,
            contract=binding.contract.model_dump(mode='json'))
        patches[stage] = patch
        return result

    item.funcargs['monkeypatch'].setattr(module, 'approve_stage', approve)
    try:
        return (yield)
    finally:
        for stage in reversed(list(stages)):
            finish(stage)
        exchanges = out/'mock-exchanges.jsonl'
        record = dict(classification='UNMODIFIED_ORIGINAL_FULL_PB_TEST_WITH_PASSTHROUGH_MODEL_AND_READBACK_OBSERVATION',
            original_test_assertions='UNCHANGED',real_models='FORBIDDEN_BY_ORIGINAL_HTTP_TRIPWIRE',
            observer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            received_mock_exchanges=len(exchanges.read_text().splitlines()) if exchanges.exists() else 0,
            stop_first=False,clock_replaced=False,lease_or_contract_extended=False,
            stages={name:dict(run_id=s['probe'].run_id,contract=s['contract'],events=s['probe'].events)
                for name,s in stages.items()},
            limitations='Passive observer overhead; synthetic SQLite only; stage events beforeCold may contain otherRuns; enteredbackground wrappers are not joined byundo; nooldRun resumed')
        (out/'full-stage-probe.json').write_text(json.dumps(record,indent=2)+'\n')
