"""Seal this owned raw root, then verify every regular archive member."""
import datetime
import hashlib
import json
import tarfile
from pathlib import Path

root=Path(__file__).parent
delivery=Path('/workspace/pb-model-settlement-delivery-20261019')
delivery.mkdir(exist_ok=True)
assert not (root/'RAW-MANIFEST.json').exists()
assert not (root/'RAW-SEAL.json').exists()
assert (root/'FINAL-INDEPENDENT-REVIEW.json').exists()

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

files={}
links=[]
for path in sorted(root.rglob('*')):
    relative=str(path.relative_to(root))
    if path.is_symlink():
        links.append(dict(path=relative,target=str(path.readlink())))
    elif path.is_file():
        files[relative]=dict(bytes=path.stat().st_size,sha256=digest(path))
manifest=dict(files=files,excluded_symlinks=links)
manifest_path=root/'RAW-MANIFEST.json'
manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
review=json.loads((root/'FINAL-INDEPENDENT-REVIEW.json').read_text())
seal=dict(classification='SEALED_RAW_EVIDENCE_FAIL_NOT_ACCEPTED_DO_NOT_WRITE_AGAIN',
    source_head='2b67733eaefb8e67e3a083a5575261b52f2d4cdf',
    sealed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),files=len(files),
    raw_manifest_sha256=digest(manifest_path),final_review=review)
(root/'RAW-SEAL.json').write_text(json.dumps(seal,indent=2)+'\n')
expected=dict(files)
for name in ('RAW-MANIFEST.json','RAW-SEAL.json'):
    expected[name]=dict(bytes=(root/name).stat().st_size,sha256=digest(root/name))
archive=delivery/'pb-model-settlement-raw.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz') as stream:
    for name in sorted(expected):
        assert digest(root/name)==expected[name]['sha256']
        stream.add(root/name,arcname=root.name+'/'+name,recursive=False)
with tarfile.open(archive,'r:gz') as stream:
    members=stream.getmembers()
    expected_names={root.name+'/'+name for name in expected}
    assert {member.name for member in members}==expected_names
    assert len(members)==len(expected_names)
    for member in members:
        assert member.isfile()
        raw=stream.extractfile(member).read()
        value=expected[member.name.removeprefix(root.name+'/')]
        assert len(raw)==value['bytes']
        assert hashlib.sha256(raw).hexdigest()==value['sha256']
for name,value in expected.items():
    assert digest(root/name)==value['sha256'],name
receipt=dict(classification='AUTHOR_VERIFIED_EVIDENCE_ARCHIVE_NOT_ADDITIONAL_RUNTIME_ACCEPTANCE',
    created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),archive=str(archive),
    bytes=archive.stat().st_size,sha256=digest(archive),members=len(expected),
    every_member_name_bytes_sha256_verified=True,raw_files_unchanged_after_packaging=True,
    excluded_symlinks=len(links),raw_manifest_sha256=digest(manifest_path),
    raw_seal_sha256=digest(root/'RAW-SEAL.json'),source_head=seal['source_head'],
    runtime_classification='FAIL_NOT_ACCEPTED',final_review_scope='Pre-packaging raw runtime/source/docs; archive verification by author')
(delivery/'package-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
