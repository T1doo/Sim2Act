# 模型响应结算：窄设计调用图准备

PREPARED / AUTHOR_DRAFT_PENDING。当前9f7213d934081b860991332359d2b5c883d9577d，src树为2b。仅只读设计准备；完整P-B仍FAIL_NOT_ACCEPTED。没有实现许可、候选代码接受或运行通过结论。

当前顺序：独立receive事务先以receipt_owner/CAS保存RECEIVED/raw/knownusage/NS_RECEIVED；独立body archive事务完成；原guarded renew在业务事务外；然后结算事务内lock_live→完整bound→commit_guard→enabled/pending receipts→实际Attempt/meta/response→parse/usage/schema/receipt→commit_guard→5写原子组→新写后_journal_reads→完整commit_guard→原deadline/enabled→完整bound/audit→完整receipts→settle_verified→尾commit_guard。任一失败回滚VERIFIED组，另事务保存REJECTED_KNOWN，不重发。

5写为Attempt VERIFIED、NS_SETTLED、Operation VERIFIED/receipt、internal_app_runs RUNNING、SPEC_STEP_VERIFIED。每次nonSELECT（包括NoOp/失败写）在执行前使旧token失效并递增epoch；写前证明不可跨越这些写。

commit_guard包含真实Store.guard/owner/fence、binding/release/Goal/source/audit/instance/frozenlimits、check_worker_tx、trial.check_commit。check_commit包含完整当前consent、phase/source/run检查和固定账户来源/软件资格及最终时钟。receipts还验证每个intent/output/完整receipt、唯一step/claimed fence；模型prove_node重建wire/raw/usage/Attempt/NS_RECEIVED/NS_SETTLED/limits，SAVE读回实际效果并fresh授权。

journal settle_verified为_identity→完整check_commit→_journal_chain。后者只读同aid双正文/hash、slot/cursor/capture、parsedraw和actualAttempt/wire参数，不写入也不单独签发权限。非journal另走budget._settle写入，必须保留原路径。

具体draft必须逐项证明：

- 写后新epoch完整firstproof保留；先钉入口identity，完整成功且无漂移后才能发布单次continuation，不能事后快照吸收callback漂移。
- 不能直接套local-readback stamp：它没有当前aid/raw/operation/receipt/modelLimits绑定，既有实际运行证据仅初本地read。
- exact Store/c/driver TX/thread/token/epoch以及完整Run/binding/Worker/settings/stop/transport/sticky drift；任何写/失败写/退出/新TX失效。
- 钉同aid、operation/step/ordinal、Attempt/response/usage、wire/Capture/slot、NS_SETTLED/SPEC_STEP_VERIFIED/receipt和原binding/release/Goal/material/Recipe/plan/action完整身份；各platform/phase/node/frozen Limits独立，不合并键。
- fresh actual authorities须含binding、receipt、journal及尾部读取的并集，不假定admission覆盖额外receipt权限；每个可能影响身份/时间/权限callback后核连续性。
- 当前固定resolver/软件资格、consent/pairedPHASE、同aid journal/body/capture、owner/version/fence/取消/stop、Grant撤销/到期继续fresh；真实拒绝原样传播，不能catch后把拒绝变fallback成功。
- 全部回调结束再做原最终最小deadline检查（实际lease、Run300、合同/sourceexpiry、node deadline）；不能过期续活、使用旧checked_at或增加新发送。
- 单次continuation立即消费/移除；漂移回原完整路径或原拒绝；非目标PG/普通/其它family保持原行为。不得拆VERIFIED组、事务中途commit/heartbeat、跨写permit或跳source/阶段证明。

原最终TX计数6次Cold bound/4次嵌套Source bound/4次_pb_source/3次commit_guard只是结构事实，不证明每次都可省略，也不构成30秒性能保证。等待具体draft后再给设计问题与最终ACK。

独审未导入产品、打开/查询DB、执行测试/模型/网络、改仓库或旧sealedroot。最初目录创建少parents导致失败发生于任何写入前，已仅在自有新root修正目录创建。
