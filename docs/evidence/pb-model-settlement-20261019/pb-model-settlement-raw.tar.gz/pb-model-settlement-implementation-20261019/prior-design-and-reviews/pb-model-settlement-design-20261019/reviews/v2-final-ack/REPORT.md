# 作者v2最终窄设计独审

**FINAL DESIGN ACK：无未闭合设计P1/P2。** 此ACK仅认可v2书面结构与不变量，**不构成实现许可、代码接受、模型/测试运行许可、完整P-B通过或30秒性能保证**。父级另决是否进入实现；现有运行结论仍FAIL_NOT_ACCEPTED。

审阅精确DESIGN SHA256为90bcc595f18d8fd3822174371c1c0372424c10551f889d27d294e87d2641cefb。当前HEAD9f7213d934081b860991332359d2b5c883d9577d，工作树读取时干净，src为原2b。11份源码副本哈希逐一等source-index及当前实际文件；新增natural_trial_runs.associated_sql确实以scalar marker或任一durable association侧为准，残缺关联不能打开通用队列。所用结束探针仍为原53个主线程事件/五写epoch100–104，v1/v2观测JSON逐字节相同。没有新DB/模型/测试执行。

## v1问题闭合

v1独审的D1/P2是回滚后把REJECTED_KNOWN描述为必然终态。v2第7节现明确：验证事务W1–W5整体回滚；原已提交接收R不由该回滚撤销；之后只尝试原拒绝事务，仍须receipt_owner、wire/状态CAS、trial.reject及commit全部成功才持久化REJECTED_KNOWN。竞争/未知失败不得伪称已拒绝、已终结或重发。该设计论证问题已关闭，v1及其独审原件保留。

v2另明确TAIL_BUSY在整个non-trial tail任何回调前进入；finally只INVALID/清理并传播原BaseException，不能以状态错误遮蔽真实拒绝；原生产通用队列的qualified association在工厂前和消费者中均以实际associated_sql检查，进入后漂移失败而不fallback。此前三处精度要求均已闭合。

## 可以接受的收敛结构

受限分支仅exact ProductionTrialBinding/PBTrialContract/cold/test-only SQLite/无qualified association；其它PG、家族、旧budget写分支与未传私有参数的调用走原完整路径。保留独立RECEIVED/正文归档、写前两次完整guard/binding/response校验、W1–W5的原语句/顺序/同事务，以及W5后全新epoch完整guard/bound/receipts。

当前aid的_identity/_journal_chain只在这一次新的完整模型首证内完整执行，保留实际双正文/slot/capture/NS/usage/Attempt/receipt关系。全部完成且入口pin未漂移，才进入READY。没有直接复用local stamp，没有公开Binding/StageAuthority DTO通行证，没有把phase/trial/platform/node/frozen Limits混为一份结果。

READY→SETTLE_BUSY→SETTLED→TAIL_BUSY→TAIL_DONE→CLOSED具备单次局部nonce/所属工厂；全程exact Store/connection/SQLAlchemy TX/driver/thread/token/epoch及完整Worker/settings/binding/Run/aid/raw/wire/operation/receipt/Limits角色指纹。任意写、失败写、重入、重复消费、callback漂移或提前退出永久INVALID；进入后不fallback、不重建替代凭据。正常scope退出必须TAIL_DONE；只有可信本地清理后原Store.tx唯一commit。

每个消费仍fresh固定_journal_source/真实resolver与软件资格、审批/撤销/pairedPHASE、全部实际authority并集、owner/取消/stop/version/fence及原完整Run谓词；source新鲜检查不冒充完整PB血缘首证。tail non-trial主体完整保留并收集新增权限，在最后source回调之后重核全部实际权限及新的最小deadline（真实lease、Run300、各原frozen/declared/platform/node/trial/source期限）。这保留了原拒绝边界，而不是把旧checked_at当当前许可。

## 事务与信任边界

Store SQLAlchemy非SELECT epoch钩子继续覆盖NoOp、失败写、0row或原始SQL/CTE。拟增driver.total_changes仅为直接驱动实际行写入的额外拒绝pin，不能证明无任意raw COMMIT/re-BEGIN或恶意Python绕过。v2已将保证明确限定为所审Store.tx/SQLAlchemy和不逃逸事务协议的受信内部回调；不引入driver代理/trace框架或外围故障矩阵。

在该边界内，所有首证、两consumer和末检查都在同一原结算TX。任何失败由原Store.tx回滚五写及callback写；先前接收事实不与VERIFIED提交捆绑。commit/连接失败仍按原未知结果处理，局部对象不能补发或作为已commit回执。这个书面论证不等于SQLite/PG实际测试已完成。

## 后续允许判断的范围

拟改3产品文件和一窄测试文件在结构上足够承载该方案，尚未检查任何实现diff。若父级另授权实施，需证明入口pin不是proof后快照、tail在任何主体前BUSY、异常保持原对象/拒绝、所有实际权限覆盖、无写跨段、同aid/各Limits严格绑定、真实事务五写提交/回滚及无重复消费。当前未来门全NOT_RUN，不能据设计ACK跳过必要代码独审/质量门。

本审只读源码、文档与旧结束JSON，未导入产品、打开/查询DB、测试、模型、网络、Git写入或修改原sealedraw/旧审查。v2的ACK不覆盖未来实现，也不改变已封存最终链FAIL_NOT_ACCEPTED、未知时延原因和未执行Windows/PG/真实语义/远端CI等边界。
