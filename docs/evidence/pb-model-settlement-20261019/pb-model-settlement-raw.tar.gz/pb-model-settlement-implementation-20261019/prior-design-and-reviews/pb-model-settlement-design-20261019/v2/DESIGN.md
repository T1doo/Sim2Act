# 单个自然模型响应结算：窄设计草案

状态：AUTHOR_REVISED_DRAFT_FOR_INDEPENDENT_REVIEW。只读分析和设计；没有实现许可、没有源码修改、没有测试或模型执行。候选仓库HEAD为 `9f7213d934081b860991332359d2b5c883d9577d`，其中src/tests/scripts与原失败执行源 `2b3846d0802ef2875d9665acc1280b949d1a4131` 同树。父级决定实现前不进入编码或长链试运行。

## 1. 根因和范围

原Cold结算TX `139968843753600` 进入时尚有29.993279秒lease；墙钟30.338610秒/线程CPU30.233703秒，33,329 SELECT和5次写入。首败是 `settle_verified → check_commit → _admission` 最终有限区间门；原Run谓词最后返回时尚余1.201387秒，其后完整 `_pb_source` 结束时已超lease约0.300315秒。最终require精确时刻未记录。这不是增加入口续租的设计依据。

范围只限 [natural_spec_runtime.advance_model:921–1026](/workspace/Sim2Act/src/sim2act/natural_spec_runtime.py:921) 中模型响应已收到后的验证事务。保留先前RECEIVED/原始响应归档事务、发送、配额等待、heartbeat、拒绝记账和已结束Run；不修改30秒lease、300秒Run、trial期限、权限、Grant、schema、executor或费用许可。无新通用证明缓存。

首个可论证受限分支仅为原精确 `ProductionTrialBinding + PBTrialContract + cold`，以及现有 `_source_reads_current` 真正支持的 `Store.test_only && Store.sqlite`；沿原Production通用队列边界，工厂前用实际 `associated_sql()` 标量查询确认无qualified association，消费者也确认仍不存在；进入后的关联漂移拒绝，不fallback。此分支不扩大qualified association支持；生产环境/真实来源门不改，不以夹具门替换真实source。PG、其他家族及旧PATrialBinding预算写入分支继续原完整路径，不声明已有PG并发证明。

## 2. 实际调用图与未到达部分

```mermaid
flowchart TD
  A[921 单一Store.tx / epoch E0] --> B[922 lock_live / 929 full bound]
  B --> C[930 full commit_guard]
  C --> D[932 receipts pending / 933-956 received response parse schema usage]
  D --> E[957 full commit_guard]
  E --> W[958-1007 五写原子组 / E0失效]
  W --> F[1011 新journal read段 / E1]
  F --> G[1012 full commit_guard]
  G --> H[1020 full bound / 1022 full receipts]
  H --> I[1025 settle_verified]
  I --> J[identity / check_commit / full admission]
  J --> K[当前aid journal_chain]
  K --> L[1026 full commit_guard]
  L --> M[同一Store.tx唯一commit]
  C --> R[lock_live → Store.guard → source_scope_gate / 冻结合同]
  C --> T[check_commit → approved → admission]
  T --> U[policy.check_run → run_context → stage_current]
  U --> V[spec.bound trial Limits → 生成来源/材料Goal/实例完整证明]
  T --> P[pb_source → 完整Source提取/原文/两Source journal链]
  T --> Q[journal_source → 固定resolver/软件资格/当前截止]
```

`commit_guard` 的主体还会检查stored snapshot、Release、Goal、实际授权材料、audit、Instance revision、冻结/声明/平台预算及worker association；不是只有trial admission。见 [pa_spec_apps:1184](/workspace/Sim2Act/src/sim2act/pa_spec_apps.py:1184)。`bound(platform Limits)` 与admission内部 `bound(trial Limits)` 是不同角色的完整输入，不能因结果类似而合并。

来源递归的主边为：`bound → app_jobs.load_binding → Release/P-B逐次绑定 → P-B source/source_audit → 原Source bound/receipts`；admission的 `_run_context → _stage_current_read → bound(_limits(contract)) → _stage_current_bound → model_source` 再证明原生成/阶段；`_pb_source → _resolve_trial_source → 原Source/提取/Goals/两份原文 → _pb_journal_archive_chain → 两个Source aid的 _journal_chain`。`spec.receipts → prove_node` 重新关联实际Attempt、NS_RECEIVED/NS_SETTLED、原wire、usage、输出schema及整份Operation receipt。现有缓存只在既有读段内复用，不等同于完整admission已无递归。

原失败TX实际观察到6次Cold bound、4次嵌套Source bound、4次_pb_source、3次commit_guard及4次Run谓词返回。6次Cold bound为写前3次、写后3次。当前Cold aid的 `_journal_chain` 和最后1026的commit_guard尚未到达，不能算已执行；图中K/L是正常控制流的待到达节点。观察事件与计数见 `observed-transaction.json`，源码调用点见 `source-index.json`。

## 3. 五写与不变的事务顺序

| 顺序 | 源码 | 原写入及必须同提交的事实 |
| --- | --- | --- |
| W1 | 958 | 当前aid且run匹配、原RECEIVED Attempt → VERIFIED |
| W2 | 974 | NS_SETTLED：实际更新后Attempt完整指纹及operation_id |
| W3 | 984 | 当前run/op、原DISPATCHED Operation → VERIFIED，完整receipt |
| W4 | 993 | 同一app_run → RUNNING |
| W5 | 998 | SPEC_STEP_VERIFIED：step/op/fence锚点 |

保留W1–W5原语句、顺序和同一个外层 `Store.tx()`；W1之后旧token立即失效，任何写后证明只从W5之后的新读段开始。不能将VERIFIED先提交，不能savepoint后独立提交证明，不能中途commit给heartbeat。W1后的Attempt readback本身也不得成为写后首证。

## 4. 拟议结构：完整首证完成后才签发局部continuation

保持921–1007原控制流。1011后新私有工厂只服务本次模型响应，执行下列构建过程，全完成前不向消费者提供可用对象：

1. 在任何构建回调之前pin W5后新的Store/连接/SQLAlchemy事务/实际driver/线程/`pb_source_reads` token和epoch，以及已经持有的原Run/worker/binding/raw/wire/meta/intent/action/各角色Limits输入指纹。新增数据库正文仍只能在完整授权之后读取，读取时记录实际行与锚点指纹。对整个构建段收集实际成功授权集合；任何中途写入/换token/输入漂移/失败使本次构建作废，不能在内部换新token再把前半证明拼接回来。
2. 完整保留1012 `spec.commit_guard`，包括完整当前admission、P-B Source/提取/两Source journal链和固定source。通过只读内部out记录这次实际成功的审批、phase、requirements指纹及身份；out不是授权，不直接缓存公开Binding或StageAuthority。保留1013–1019原Run/meta/deadline/enabled检查。
3. 完整保留1020 `spec.bound(platform Limits)`、audit相等和1022 `spec.receipts`。不拿admission的trial Limits结果代替平台结果，不拿prewrite binding代替此处的重新读取。
4. 将当前生产journal分支原 `settle_verified` 内的 `_identity` 和当前aid `_journal_chain(...,raw)` 完整执行一次，作为首证的最后部分。该分支在当前源码纯读取，不产生新的账本写；只挪到同一事务/同一读段的签发之前，原完整正文/slot/capture/NS/usage关系不能省略。其他分支不迁移。
5. 对构建期间所有binding、receipt、当前及Source journal路径实际权限取并集，重核当前授权、固定source和完整Run谓词；重核所有输入/身份指纹、token/epoch及当前时钟。只有成功后局部对象进入READY。该时刻之后仍不表示已提交，也不保证剩余时长足够。

后续只有两个有序消费点：

- `settle_verified(..., _model_after=...)`：精确私有类型/活跃工厂归属、aid/raw/Run输入和READY状态匹配；先进入BUSY防重入，仍做当前实际scalar identity和下节live gate，然后进入SETTLED。此分支省去刚完成的整套admission及当前journal再次递归，其他调用无参数仍走原函数体。
- 1026 `spec.commit_guard(..., _model_after=...)`：入口在任何non-trial主体/可能执行回调的调用之前先把SETTLED消费为TAIL_BUSY，包住整个tail，禁止其间重入或第二次消费；**保留现有non-trial主体**，并在受保护读取前验证模型上下文当前性。仅其末尾调用的trial `check_commit` 改成显式模型continuation检查；动态收集该主体新增的所有实际authority，和首证并集再次重核。成功进入TAIL_DONE。无传参的commit_guard始终保持原路径。

状态严格为BUILDING→READY→SETTLE_BUSY→SETTLED→TAIL_BUSY→TAIL_DONE→CLOSED，任何BaseException或漂移进入永久INVALID，不恢复READY；BUILDING与BUSY状态不得重入或被其他消费者使用。正常退出只允许TAIL_DONE；若主体已经抛出任意BaseException，finally仅做可信本地失效/清理，保留并传播原异常，不以状态检查替换真实的撤权/来源拒绝/中断。无原异常却提前正常退出才抛状态错误。失败/中断/提前退出均使外层回滚。退出的纯本地清理之后不增加SQL/回调，原Store.tx才唯一commit。已进入本模型continuation后的失效不fallback、不重做、不中途续租；整个验证事务拒绝。只有进入工厂前的不适用分支可保留原完整代码路径。

这不是把local-readback stamp直接装到模型路径：旧stamp未证明aid/raw/Operation receipt/当前journal/NS双锚点/模型各份Limits。本设计使用独立私有类型和上述完整模型首证，不扩展旧stamp或其consumer。

## 5. 精确不变量

| 编号 | 始终成立的约束 |
| --- | --- |
| I1 事务与存储 | 原Store/engine及连接对象相同；SQLAlchemy事务对象相同且活跃；实际driver相同且仍在该事务；无嵌套提交/连接切换；线程相同。 |
| I2 写边界 | token对象相同且 `_source_reads_current` 成立；epoch等于W5后构建起点；任何SQLAlchemy非SELECT（包括失败语句、NoOp、CTE/原始SQL）都使旧token失效；异常清空，不跨写携带。 |
| I3 工厂归属 | 单次advance_model局部活跃nonce；私有对象不可持久化/返回API、不得存在Worker/全局/c.info跨调用缓存；构建中、BUSY、SETTLED对象不能作为READY使用。每个消费点只能执行一次，顺序不可交换。 |
| I4 控制器 | 同一Worker、Store、Settings、stop、transport对象和worker_id；原 `_journal_trial_store`/binding相同且sticky drift=false；配置全值、精确binding种类、合同全文/key/account/version指纹相同；每次仍 `_binding/enabled`。 |
| I5 身份 | principal/project/runtime、Run id/version/fence/worker/status/cancel/created_at/request_key/resource_refs、app/app_run/instance/release、snapshot、Goal/resource内容hash、draft/recipe/plan/audit等精确绑定；公开Binding/StageAuthority不能单独作为通行证。 |
| I6 原响应 | 同aid/op/step/action/intent；原raw、canonical/raw evidence、完整wire/hash/bytes、Attempt完整行（含mode/request_model/response_model/usage/reserved_tokens/elapsed/参数）、VERIFIED Operation及整receipt、NS_RECEIVED/NS_SETTLED/SPEC_STEP_VERIFIED锚点、current journal slot/capture/ledger及source两chain均属于本次完整首证。mutable输入在每次callback前后按原角色指纹重核。 |
| I7 Limits不混用 | 独立带角色标签保存平台Limits、trial `_limits(contract)`、节点effective/meta Limits、action Limits、manifest声明Limits、frozen合同Limits；保留原各调用的完整输入和校验选项，不能取一份min/3键投影去命中另一份4键或完整字段证明。 |
| I8 当前权限 | 每次消费重新授权完整首证+receipt+journal+尾部实际路径的authority并集；仍验证owner/project/resource和双主体Grant的撤销/到期。审批/撤销/phase key及完整指纹重新读；不只重核预先猜测的材料/SAVE集合。 |
| I9 当前来源 | 每次消费仍调用固定 `_journal_source`，包括真实resolver、精确account/quota/provider/model/endpoint、软件资格、ALLOW/revoked及source/contract截止；DENY/UNKNOWN或异常不能退回缓存ALLOW。 |
| I10 当前Run与时间 | 重新读实际Run（原锁语义）并调用原 `_require_run_context_row` 完整谓词；确认worker ownership、stop/cancel、version/fence；同一受限段保持首证阶段锚点，原frozen/declared/platform/node/trial所有截止均生效。不得用旧checked_at/曾经valid代替当前time。 |
| I11 callback后最后检查 | 每个可能执行回调的授权/source/identity/receipt函数前后验上下文、原始输入和粘性漂移。全部实际读/回调后，再做新时钟与原Run/节点/合同/source deadline检查，随后只做可信本地清理和原commit。不能在最后一次昂贵source之后只依赖它之前采样的Run时钟。 |
| I12 失效 | 写、换transaction/driver/thread/token、fingerprint变化、显式撤权、返回身份/来源不符、异常、重入、重复消费或scope退出均失效；失效后本次事务不再签发替代对象，不fallback绕过拒绝。 |

权限及时间检查必须包住读取顺序，不能先凭旧对象读私有原文再检查live gate。回调漂移还包括Settings/binding/source返回值、Run/输入/Limits变化；观测到漂移即使后续数据看起来可恢复也不能消费旧证明。

具体live gate顺序：核pin/状态并运行_binding/enabled；重新读有效审批/撤销/phase keys和阶段指纹；当前 `_journal_source` 必须真执行，固定account/requirements/实际来源evidence指纹与首证一致，变化拒绝而非延用旧ALLOW；随后重核包含此次source、全部首证、receipt/journal及tail实际路径的authority并集。实际Run按原锁语义重新读取、完整谓词校验，所有回调后再次检查pin、stop及当前deadline。末尾截止取原限制的交集：实际lease、Run.created_at加trial/platform/declared/frozen run_seconds、snapshot natural_spec_clock.deadline、meta节点deadline、合同及最新source.expires_at；不得遗漏较短的节点或冻结期限。Grant仍由原authorize的当前DB/当前时钟语义校验，不宣称把多条授权SQL变成一个全局时刻的外部原子快照。固定source的新鲜校验不能替代首证完整 `_pb_source` 血缘。

## 6. 同driver条件的证明范围（独审需明确）

既有epoch由SQLAlchemy `before_cursor_execute` 维护；`_source_reads_current` 同时绑定RootTransaction、driver和`driver.in_transaction`。拟再绑定SQLite `driver.total_changes` 起点并在callback后比较，捕获直接driver实际写入/回滚也不能复用的情况；它不能独立证明任意原始DBAPI失败写或绕开Store的 `COMMIT; BEGIN` 已被监控。

本设计的可信调用边界是现有Store.tx及源码内SQLAlchemy读写路径、不会绕开该事务协议的受信内部回调，未提供raw driver、callback或新事务控制给调用方。独立预审已静态检查所审runtime/spec/trial/admission/policy/source/sender/journal/archive/PB/goal/lifecycle/app_jobs产品路径，未发现原生COMMIT/re-BEGIN；直接事务控制集中Store.tx。禁止把仅有in_transaction布尔量宣称“检测所有任意Python绕过”。若父级要求覆盖任意恶意Python/raw事务逃逸，当前原语不足，设计应停止而不是临时添加通用driver代理/trace框架。本轮不运行此类外围故障矩阵。

## 7. 原子回滚论证

设R为先前已经提交的RECEIVED和不可变原文；T0为921事务开始状态，W为五写。W不是单独提交的成功事实。首证/两consumer/最后检查全部在同一外层Store.tx内；没有在任何 helper调用commit，也不产生独立验证事务。

- 全通过：唯一commit提交T0+W；Attempt、NS_SETTLED、Operation receipt、AppRun和STEP锚点同时可见。
- W任一位置、写后首证、journal、consumer、末尾守卫发生DomainError或任何BaseException：Store.tx rollback全部W及同事务callback写；无部分VERIFIED可见。DomainError之后只尝试原1027后新拒绝事务，仍受receipt_owner、wire/状态CAS、trial.reject及commit原守卫；仅这些检查与拒绝事务提交均成功，才持久化REJECTED_KNOWN及NS_REJECTED。拒绝事务也可能因竞争/未知错误失败，此时保留实际证据并按原错误处理传播，不捏造已拒绝或已终结状态。无条件论证仅是验证事务W全部回滚和先前R不被该回滚撤销。拒绝记账不是业务成功，不能更新原response/退预算/重发。
- 非DomainError同样回滚W；原错误处理决定后续状态，不假造一定有REJECTED_KNOWN。receive原事实R不受验证事务回滚影响。
- commit本身失败或连接丢失仍服从原Store.tx/上层未知结果处理；本局部对象不作为已commit回执，不补发或重放旧Run。

因此设计在原Store事务语义下保持原子性；不是已有实现/执行验证，也不证明事务可在30秒内完成。原已失败Run和过期合同仅保全，绝不拿它们继续验证。

## 8. 最小拟变更文件与未来窄门（均未执行）

| 文件 | 拟议变化 |
| --- | --- |
| natural_spec_runtime.py | 仅结算块的私有工厂/局部线性上下文、完整首证编排及显式传参；保留prewrite、五写、archive/receive/reject/renew位置。 |
| pa_trial_dispatch.py | 完整check_commit只读内部out；精确生产PB cold分支当前journal首证的私有调用；显式模型专用check_commit continuation与settle_verified consumer。预算/terminal/send/local-readback分支不变。 |
| pa_spec_apps.py | commit_guard增加私有模型参数，仅显式收集tail authority和切换末尾trial检查；non-trial主体仍执行，原调用默认全证。 |
| 一份窄测试文件 | 未来若授权实现，再验证真实SQLite同事务五写提交/回滚、两consumer一次有序消费、各Limits角色和identity绑定、写后再首证、撤权/expiry/callback漂移拒绝及无fallback；不扩恢复/故障矩阵。 |

未来门先应是0模型的真实事务/现有fixture定向测试及受影响Ruff/mypy；通过并独审后，由父级另决定是否运行一次原完整链。可用有限Mock但真实模型始终不得调用。当前没有新测试结果、性能数字或实现许可。

可能减少的结构是：完成写后全证之后，在settle_verified及尾部trial门重复进入 `_run_context → stage_current → bound → source lineage` 的递归；保留写前原全证、写后独立首证、tail non-trial检查及每次实时Grant/source/Run。不能从旧33329 SELECT减法推导新的耗时，尚未观察到的末尾调用也不能虚构性能收益。

## v2独审修订

v1第7节将DomainError后REJECTED_KNOWN误写为必然结果，独审记P2文档/论证缺口；v2已改为守卫和提交成功后才成立。另明确TAIL_BUSY包住整个non-trial tail、finally不遮蔽原BaseException、排除qualified association。v1原件保留；无任何实现或测试。
