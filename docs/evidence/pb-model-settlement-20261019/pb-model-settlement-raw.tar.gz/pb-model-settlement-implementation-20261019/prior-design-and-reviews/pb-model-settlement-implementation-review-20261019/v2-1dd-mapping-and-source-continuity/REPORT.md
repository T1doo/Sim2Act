# 1dd 独立只读补充审查

结论：BLOCKED_NOT_FULL_ACK。未发现新增P1；存在1项需修正P2（C2），负向门也未闭合。不得启动或认证完整P-B接受。

C1原Mapping阻塞已静态闭合：58c/1dd以递归Mapping/list/tuple、exact Limits/bytes及JSON primitives规范化全部字段，未知类型拒绝；真实SQLite RowMapping保留在unit binding，尾部Run/binding比较使用同一规范化。未使用default=str或删除字段。

C2/P2：完整成功_admission的私有_model_out只含approval/phase/requirements。factory随后执行bound/receipts/current journal，直到首次proof.live()才从None/inf建立source_identity/source_deadline。因此完整admission已验证A，构建中无SQL写的callback改成B时，首次live可吸收B；同身份更晚expires也可丢失A较短截止。这违反v2“actual来源身份与首证一致、期限只收紧”不变量。需从完整成功admission当次的实际_journal_source返回值经私有out立即pin稳定identity及expires；后续fresh source仍逐次原门并仅取min，observed_at不做相等指纹。不要增加resolver或ALLOW缓存。该发现为源码控制流推导，本独审未执行故障注入。

实际门：58c model-positive-v2 exit1/11.818s（2119稳定），advance_model已越过VERIFIED/CLOSED等断言，最终错误把BEGIN算作第六写；保留FAIL。1dd仅修断言到BEGIN+UPDATE/INSERT/UPDATE/UPDATE/INSERT，model-positive-v3标准pytest1P/22.420s外层，Junit11.457s；非完整phase/ledger ancestry接受。model-negative-v3 exit1/47.182s：source_revoke P，grant_expiry最终NoResultFound（无Attempt），-x停止，其余10项未执行；捕获的原DomainError未在失败前持久化，早拒原因未知。不可把它算READY后到期门已覆盖。

1dd Ruff4 P/2.097s，mypy实际命令mypy src/sim2act，113源P/32.921s；五个完成phase均2119输入前后相同。独立AST核对9f/1dd：原结算TX写前及W1–W5连同中间readback19节点完全相等。尾部新增独立既有CSV authority的无SQL时钟到期用例在代码上针对union盲点，尚因-x未实际运行。

限制：unit明确stub recipe/phase ancestry、sender、journal ledger、nontrial guard、parse、renew、software和trial reject accounting；真实SQLite/consent/Grant/Run谓词/NS档案配对/原五写/回滚/CAS范围须以实际通过节点为准。本独审未导入产品、访问数据库、运行测试/模型/网络或改仓库。历史完整P-B FAIL、旧满盘独审缺失和原失败门均不补签。
