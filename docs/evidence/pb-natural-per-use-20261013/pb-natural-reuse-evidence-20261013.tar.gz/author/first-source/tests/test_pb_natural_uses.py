"""The same saved P-B logic/Release/instance explicitly runs unseen third input."""
import hashlib
import json

from fastapi.testclient import TestClient
from sqlalchemy import select
from test_natural_spec_apps import material, transport
from test_pa_spec_apps import instance
from test_pb_natural_specs import drive_to_success, prepare, preview_commit
from test_spec_app_operations import snapshot

from sim2act import pb_natural_uses as use
from sim2act.api import create_app
from sim2act.db import Store, app_drafts, internal_instance_data, internal_releases

THIRD = "The field beacon transmits twice per day while solar power is available. During a storm it keeps a cached signal. The beacon night policy has yet to be agreed."


def prepared_use(env):
    prepared = prepare(env)
    data, _, _, _, _, path, _, _ = prepared
    _, extraction = preview_commit(prepared)
    saved = data[2].post(path + "/extractions", json=extraction)
    assert saved.status_code == 201, saved.text
    app = data[2].get(f"/api/apps/{saved.json()['id']}").json()
    release, inst = instance(data, app["id"])
    resource, goal = material(data[2], data[4], THIRD, "Third material for the SAME saved logic")
    body = dict(expected_revision=inst["revision"], expected_release_fingerprint=release["fingerprint"],
        expected_app_fingerprint=app["fingerprint"],
        expected_recipe_fingerprint=app["candidate"]["spec_task"]["edited_recipe_fingerprint"],
        card_id=goal["id"], expected_goal_version=goal["version"],
        expected_goal_fingerprint=goal["fingerprint"], expected_source_hash=hashlib.sha256(THIRD.encode()).hexdigest(),
        request_key="third-use-original-key")
    route=f"/api/internal/instances/{inst['id']}"
    return data, app, release, inst, resource, goal, body, route


def test_same_saved_logic_third_material_cold_worker(env, tmp_path):
    data, app, release, inst, resource, goal, body, route = prepared_use(env)
    before = snapshot(data[0])
    response = data[2].post(route + "/pb-use-reviews", json=body)
    assert response.status_code == 200, response.text
    checked = response.json()
    assert snapshot(data[0]) == before
    assert checked["app_id"] == app["id"] and checked["release_id"] == release["id"]
    assert checked["effective_candidate"]["spec_recipe"] == app["candidate"]["spec_recipe"]
    commit = dict(review=body, expected_review_fingerprint=checked["review_fingerprint"], consent=use.CONSENT)
    queued = data[2].post(route + "/pb-use-runs", json=commit)
    assert queued.status_code == 202, queued.text
    rid = queued.json()["run_id"]
    cold = Store(data[1].database_url, test_only=True)
    try:
        with TestClient(create_app(cold, data[1])) as client:
            client.headers["Authorization"] = "Bearer synthetic-test-A"
            current = (cold, data[1], client, *data[3:])
            received = client.get(route + "/pb-use-requests/" + body["request_key"])
            assert received.status_code == 200, received.text
            assert received.json()["reviewed"] == checked
            sent = []
            drive_to_success(current, rid, transport(sent, THIRD))
            result = client.get(f"/api/internal/app-run-jobs/{rid}/spec-artifact")
            assert result.status_code == 200, result.text
            assert json.loads(result.json()["resource"]["content"])["source_content"] == THIRD
            assert json.loads(result.json()["resource"]["content"])["source"]["resource_id"] == resource
            assert len(sent) == 1 and THIRD in json.dumps(sent)
            with cold.tx() as c:
                assert dict(c.execute(select(app_drafts).where(app_drafts.c.id == app["id"])).mappings().one()) == next(r for r in before["app_drafts"] if r["id"] == app["id"])
                assert [dict(r) for r in c.execute(select(internal_releases)).mappings()] == before["internal_releases"]
                rows = c.execute(select(internal_instance_data).where(internal_instance_data.c.instance_id == inst["id"])).mappings().all()
                assert len(rows) == 1 and rows[0]["version"] == 1
            (tmp_path / "third-material-proof.json").write_text(json.dumps(dict(review=checked, receipt=received.json(),
                result=result.json(), wire=sent, same_app=True, same_release=True, real_model_requests=0), ensure_ascii=False, indent=2))
    finally:
        cold.engine.dispose()
