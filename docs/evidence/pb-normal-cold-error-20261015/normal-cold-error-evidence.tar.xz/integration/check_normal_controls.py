"""Execute only exact normal wrappers with stubs; no Worker, DB or clock calls."""
import ast
import copy
import hashlib
import json
from pathlib import Path
from sqlalchemy.engine import RowMapping
from sim2act.db import Store
from sim2act.errors import DomainError

R = Path('/workspace/Sim2Act-pa-provider')
B = Path('/workspace/pb-normal-cold-error-evidence-20261015')
p = R / 'tests/test_pb_trial_dispatch.py'
tree = ast.parse(p.read_text())
fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'test_pb_full_actual_worker_extraction_and_cold')
helper = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'failure_trace')
handler = next(n for n in fn.body if isinstance(n, ast.FunctionDef) and n.name == 'normal_failure')
once = next(n for n in fn.body if isinstance(n, ast.FunctionDef) and n.name == 'normal_once')
env = dict(Store=Store, RowMapping=RowMapping)
exec(compile(ast.fix_missing_locations(ast.Module(body=[helper], type_ignores=[])), str(p), 'exec'), env)
records = []
for raises in (False, True):
    calls, errors, traces = [], [], []
    worker, run, sentinel = object(), object(), object()
    original = DomainError('SYNTHETIC_ORIGINAL')
    incoming = DomainError('SYNTHETIC_INCOMING')
    def original_failure(*args):
        calls.append(args)
        if raises:
            raise original
        return sentinel
    local = dict(env, normal_errors=errors, normal_traces=traces, original_failure=original_failure)
    exec(compile(ast.fix_missing_locations(ast.Module(body=[handler], type_ignores=[])), str(p), 'exec'), local)
    escaped = None
    result = None
    try:
        result = local['normal_failure'](worker, run, incoming)
    except DomainError as caught:
        escaped = caught
    assert len(calls) == 1 and all(a is b for a,b in zip(calls[0], (worker,run,incoming), strict=True))
    assert escaped is original if raises else escaped is None and result is sentinel
    assert len(errors) == len(traces) == 1
    records.append(dict(case='handler_raise' if raises else 'handler_return', original_calls=1, identity_preserved=True, passed=True))
factory = ast.parse('def bind(original_once):\n normal_once_result=None\n direct_exception_trace=None\n pass\n return normal_once, lambda: (normal_once_result, direct_exception_trace)\n').body[0]
factory.body[2] = copy.deepcopy(once)
exec(compile(ast.fix_missing_locations(ast.Module(body=[factory], type_ignores=[])), str(p), 'exec'), env)
for case in ('true', 'false', 'domain', 'runtime'):
    calls = []
    worker = object()
    original = DomainError('SYNTHETIC_DOMAIN') if case == 'domain' else RuntimeError('SYNTHETIC_RUNTIME')
    def original_once(actual):
        calls.append(actual)
        if case in ('domain','runtime'):
            raise original
        return case == 'true'
    bound, state = env['bind'](original_once)
    escaped = None
    result = None
    try:
        result = bound(worker)
    except Exception as caught:
        escaped = caught
    assert calls == [worker]
    value, trace = state()
    if case in ('domain','runtime'):
        assert escaped is original and value is None
        assert set(trace) == {'frames','store_guard_values'} and trace['frames'] and trace['store_guard_values'] == []
    else:
        assert escaped is None and result is (case == 'true') and value is result and trace is None
    records.append(dict(case=case, original_calls=1, identity_preserved=True, passed=True))
x = dict(scope='Synthetic exact normal wrappers only; not Worker success, guard predicate or finally I/O acceptance', source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(), pass_count=len(records), records=records)
(B/'CONTROL_RESULT.json').write_text(json.dumps(x,indent=2)+'\n')
print(json.dumps(x))
