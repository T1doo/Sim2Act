"""Redacted copies of exact saved XML/error text; no runtime or database access."""
import hashlib
import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path

B = Path('/workspace/pb-normal-cold-error-evidence-20261015')
OLD = Path('/workspace/pb-stale-guard-frame-evidence-20261015')
out = B / 'public'
out.mkdir(exist_ok=True)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def redact(value):
    value = re.sub(r'hostname="[^"]*"', 'hostname="REDACTED_HOST"', value)
    value = value.replace(str(B), '[DIAGNOSTIC_EVIDENCE_ROOT]')
    value = value.replace(str(OLD), '[PRIOR_EVIDENCE_ROOT]')
    value = value.replace('/tmp/pb-stale-guard-frame-evidence-20261015', '[PRIOR_EVIDENCE_ROOT]')
    value = value.replace('/tmp/pb-normal-cold-error-evidence-20261015', '[DIAGNOSTIC_EVIDENCE_ROOT]')
    value = re.sub(r'\b([a-z][a-z0-9_]{0,25})_[0-9a-f]{32}\b', r'\1_[REDACTED_ID]', value)
    value = re.sub(r"(?<=\.\.\.)[0-9a-f]{12,32}(?=['\"])", "[REDACTED_ID_SUFFIX]", value)
    value = re.sub(r'\b0x[0-9a-fA-F]+\b', '0xREDACTED_MEMORY', value)
    value = value.replace('synthetic-test-A', '[OFFLINE_TEST_TOKEN]')
    return value

sources = [('prior-normal-RUNNING', OLD / 'observation/original-order-frame-confirmation/results.xml')]
for name in ('original-order-normal-error',):
    new = B / 'observation' / name / 'results.xml'
    if new.exists():
        sources.append(('current-' + name, new))
records = []
for label, source in sources:
    original = source.read_bytes()
    text = original.decode()
    saved = redact(text).encode()
    ET.fromstring(saved)
    (out / (label + '.xml')).write_bytes(saved)
    errors = '\n\n'.join(n.text or '' for n in ET.fromstring(original).iter() if n.tag in ('failure', 'error'))
    public_errors = redact(errors)
    (out / (label + '-errors.txt')).write_text(public_errors)
    records.append(dict(label=label, source=str(source), original_sha256=digest(original),
        public_xml_sha256=digest(saved), original_error_text_sha256=digest(errors.encode()),
        public_error_text_sha256=digest(public_errors.encode()), failure_or_error_text_present=bool(errors)))
receipt = dict(policy='Exact saved XML text with only host, test-generated identity including truncated repr suffix, memory pointer, evidence root and synthetic test-token substitutions. No assertion, code/message, result, duration, count or traceback line removed. Parsed failure/error text also exported. Original bytes remain retained.', records=records)
(out / 'REDACTION_RECEIPT.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
