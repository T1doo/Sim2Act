"""Seal every regular evidence file; verify archived and retained bytes."""
import hashlib
import json
import tarfile
from pathlib import Path

B = Path('/workspace/pb-normal-cold-error-evidence-20261015')
OUT = Path('/workspace/Sim2Act-pa-provider/docs/evidence/pb-normal-cold-error-20261015')
OUT.mkdir(parents=True, exist_ok=False)
files = sorted(p for p in B.rglob('*') if p.is_file() and not p.is_symlink())
manifest = {str(p.relative_to(B)): dict(bytes=p.stat().st_size,
    sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files}
(OUT / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
archive = OUT / 'normal-cold-error-evidence.tar.xz'
with tarfile.open(archive, 'w:xz', preset=9) as tar:
    for p in files:
        tar.add(p, arcname=str(p.relative_to(B)), recursive=False)
with tarfile.open(archive, 'r:xz') as tar:
    assert len(tar.getmembers()) == len(manifest)
    for member in tar.getmembers():
        assert member.isfile() and member.name in manifest
        data = tar.extractfile(member).read()
        record = manifest[member.name]
        assert len(data) == record['bytes']
        assert hashlib.sha256(data).hexdigest() == record['sha256']
assert set(manifest) == {str(p.relative_to(B)) for p in B.rglob('*') if p.is_file() and not p.is_symlink()}
assert all(hashlib.sha256((B / n).read_bytes()).hexdigest() == v['sha256'] for n, v in manifest.items())
receipt = dict(file=archive.name, bytes=archive.stat().st_size,
    sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), members=len(manifest),
    all_members_readback=True, status='NOT_ACCEPTED', production_changes=False,
    baseline_sha='058ed298bdaae3978485452eb58301d14ea77970',
    tested_sha='4a0096612757499d1eab0cccd8550d426249b360')
(OUT / 'ARCHIVE.json').write_text(json.dumps(receipt, indent=2) + '\n')
# Explicit parent-review copies, in addition to the complete archive.
public = OUT / 'public'
public.mkdir()
for p in sorted((B / 'public').iterdir()):
    if p.is_file():
        (public / p.name).write_bytes(p.read_bytes())
print(json.dumps(receipt))
