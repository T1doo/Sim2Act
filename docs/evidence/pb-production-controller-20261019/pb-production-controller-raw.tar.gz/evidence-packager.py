import datetime
import hashlib
import io
import json
import shutil
import subprocess
import sys
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path

repo = Path('/workspace/Sim2Act')
root = Path('/workspace/pb-production-controller-20261019')
reviews = Path('/workspace/pb-production-controller-review-20261019')
delivery = Path('/workspace/pb-production-controller-delivery-20261019')
source, phase, review = sys.argv[1:]
h = lambda data: hashlib.sha256(data).hexdigest()
assert not (root / 'RAW-SEAL.json').exists(), 'Already sealed: do not rewrite'
assert subprocess.check_output(['git', '-c', 'core.fsmonitor=false', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == source
assert subprocess.check_output(['git', '-c', 'core.fsmonitor=false', 'status', '--porcelain'], cwd=repo, text=True) == ''
acceptance = 'NOT_ACCEPTED: original PB chain did not reach Source/extraction/Cold'
for name in (phase+'-mypy', phase+'-lint'):
    result = json.loads((root / name / 'result.json').read_text())
    assert result['returncode'] == 0 and result['unchanged_inputs'] and result['head'] == source
result = json.loads((root / (phase+'-final-nodes/result.json')).read_text())
assert result['returncode'] == 1 and result['unchanged_inputs'] and result['head'] == source
xml = ET.parse(root / (phase+'-final-nodes/junit.xml'))
cases = xml.findall('.//testcase')
assert len(cases) == 3 and len(xml.findall('.//failure')) == 1 and not xml.findall('.//error') and not xml.findall('.//skipped')
assert [c.attrib['name'] for c in cases if c.find('failure') is not None] == ['test_pb_production_original_source_extraction_explicit_use_and_cold']
assert (reviews / review / 'review-manifest.json').is_file(), 'Final independent review not sealed'
assert not list((root / (phase+'-final-nodes')).rglob('pb-controller-proof.json'))

# Reproduce listed tracked inputs independently from every exercised Git SHA.
# Dependencies remain separate hash identities, not falsely labelled Git blobs.
tracked = set(subprocess.check_output(['git', '-c', 'core.fsmonitor=false', 'ls-files'], cwd=repo, text=True).splitlines())
identities, phases = [], []
seen = set()
for path in sorted(root.glob('*/result.json')):
    result = json.loads(path.read_text())
    phase_root = path.parent
    before = json.loads((phase_root / 'before.json').read_text())
    after = json.loads((phase_root / 'after.json').read_text())
    assert result['unchanged_inputs'] and before == after, phase_root
    version = result['head']
    xml_path = phase_root / 'junit.xml'
    cases = ET.parse(xml_path) if xml_path.exists() else None
    mock_files = list(phase_root.rglob('mock-exchanges.jsonl'))
    exchanges = [json.loads(line) for p in mock_files for line in p.read_text().splitlines()]
    assert all(e['classification'] == 'SYNTHETIC_MOCK_TRANSPORT_NOT_REAL_HTTP' for e in exchanges)
    phases.append(dict(phase=phase_root.name, source=version, returncode=result['returncode'],
        elapsed_seconds=result['elapsed_seconds'], inputs=len(before), unchanged_inputs=True,
        junit_cases=None if cases is None else len(cases.findall('.//testcase')),
        junit_failures=None if cases is None else len(cases.findall('.//failure')),
        junit_errors=None if cases is None else len(cases.findall('.//error')),
        recorded_mock_exchanges=len(exchanges),
        reported_ordinary_mock_requests=sum(json.loads(p.read_text())['actual_mock_generation_requests']
            for p in phase_root.rglob('ordinary-proof-reuse.json'))))
    if version in seen:
        continue
    seen.add(version)
    paths = sorted(set(before) & tracked)
    specs = ''.join(version + ':' + name + '\n' for name in paths)
    raw = subprocess.check_output(['git', '-c', 'core.fsmonitor=false', 'cat-file', '--batch'], cwd=repo, input=specs.encode())
    stream = io.BytesIO(raw)
    name = 'frozen-tracked-inputs-' + version + '.tar.gz'
    with tarfile.open(root / name, 'w:gz') as archive:
        for relative in paths:
            header = stream.readline().decode().strip().split()
            assert len(header) == 3 and header[1] == 'blob', (relative, header)
            content = stream.read(int(header[2])); assert stream.read(1) == b'\n'
            assert h(content) == before[relative], (version, relative)
            if version == source:
                assert h(content) == h((repo / relative).read_bytes()), relative
            item = tarfile.TarInfo(relative); item.size = len(content); item.mode = 0o644
            archive.addfile(item, io.BytesIO(content))
    identities.append(dict(source=version, example_phase=phase_root.name, listed_inputs=len(before),
        exact_tracked_blobs=len(paths), archive=name, archive_sha256=h((root/name).read_bytes()),
        dependency_inputs=sorted(set(before)-tracked)))
(root / 'input-identity.json').write_text(json.dumps(dict(
    final_source=source, versions=identities,
    limitations=['Listed inputs are not a hermetic environment snapshot.',
                 'Installed Python/egg-info metadata is outside this input list.',
                 'The1399 node_modules dependency inputs are hash identities, not committed Git blobs or a full vendor archive.',
                 'External runners were retained at sealing, outside the listed input set.']), indent=2)+'\n')
(root / 'phase-results.json').write_text(json.dumps(phases, indent=2)+'\n')
shutil.copy2('/workspace/run-pb-production-validation.py', root / 'validation-runner.py')
shutil.copy2('/workspace/package-pb-production-evidence.py', root / 'evidence-packager.py')
shutil.copytree(reviews, root / 'independent-reviews', dirs_exist_ok=False)
(root / 'source-history.patch').write_bytes(subprocess.check_output(['git', '-c', 'core.fsmonitor=false',
    'format-patch', '--stdout', 'c4f9a532c7ab428abccaf0ecf748398690e789bf..'+source], cwd=repo))
(root / 'python-tools.json').write_bytes(subprocess.check_output(['/workspace/sim2act-venv/bin/python', '-B', '-c',
    'import json,sys,importlib.metadata as m; print(json.dumps(dict(executable=sys.executable,version=sys.version,packages={n:m.version(n) for n in ["pytest","sqlalchemy","httpx","fastapi","pydantic","mypy","ruff"]}),indent=2))']))

files, aliases, exclusions = [], [], []
for p in sorted(root.rglob('*')):
    relative = p.relative_to(root).as_posix()
    if p.is_symlink():
        aliases.append(dict(path=relative, target=str(p.readlink())))
    elif 'cache' in p.relative_to(root).parts:
        if p.is_file(): exclusions.append(relative)
    elif p.is_file():
        files.append(dict(path=relative, bytes=p.stat().st_size, sha256=h(p.read_bytes())))
manifest = dict(source=source, final_phase=phase, final_review=review, acceptance=acceptance,
    created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    files=files, symlink_aliases=aliases, omitted_generated_cache_files=exclusions,
    scope='BOUNDED_SYNTHETIC_PB_CONTROLLER_ONLY; real models0; no Windows/PG/CI/semantic certification')
manifest_path = root / 'RAW-MANIFEST.json'
manifest_path.write_text(json.dumps(manifest, indent=2)+'\n')
seal = dict(acceptance=acceptance, manifest_sha256=h(manifest_path.read_bytes()), files=len(files), source=source,
    sealed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), mutation_policy='DO_NOT_WRITE_AGAIN')
(root / 'RAW-SEAL.json').write_text(json.dumps(seal, indent=2)+'\n')
delivery.mkdir(exist_ok=True)
archive_path = delivery / 'pb-production-controller-raw.tar.gz'
assert not archive_path.exists()
with tarfile.open(archive_path, 'w:gz') as archive:
    for item in files:
        archive.add(root / item['path'], arcname=item['path'], recursive=False)
    for name in ('RAW-MANIFEST.json','RAW-SEAL.json'):
        archive.add(root / name, arcname=name, recursive=False)
with tarfile.open(archive_path) as archive:
    members = {m.name:m for m in archive.getmembers()}
    assert len(members) == len(files)+2
    for item in files:
        assert h(archive.extractfile(members[item['path']]).read()) == item['sha256']
final_identity = next(i for i in identities if i['source'] == source)
receipt = dict(source=source, acceptance=acceptance, archive=str(archive_path), bytes=archive_path.stat().st_size,
    sha256=h(archive_path.read_bytes()), raw_manifest_sha256=seal['manifest_sha256'],
    raw_data_files=len(files), archive_members=len(files)+2, all_members_verified=True,
    exact_tracked_input_blobs=final_identity['exact_tracked_blobs'],
    dependency_inputs=final_identity['listed_inputs']-final_identity['exact_tracked_blobs'])
(delivery / 'package-receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(receipt), flush=True)
