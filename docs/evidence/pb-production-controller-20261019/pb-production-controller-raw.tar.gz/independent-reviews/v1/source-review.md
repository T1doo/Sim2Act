# P-B production controller v1 independent source review

Reviewed immutable commit `ba0fa2a400e6289a3723256bd5f3ac913cba3cac`, base `c4f9a532c7ab428abccaf0ecf748398690e789bf`. Scope: four changed product modules, new PB test, reused production fixture change, and the pre-execution stage contract document. Source and Git reads only; no product imports, test execution, DB, models, network or process signals. This new directory is the only write target.

## Conclusion

No definite P1/P2 product defect was found in the reviewed delta. The original fixed account resolver, exact software qualification, caps/lease/deadline, authority and sender/quota machinery are unchanged. This is a limited source/security conclusion, not a runtime PASS or production/semantic acceptance.

One definite P2 exists in the new integration test and must be corrected before its intended Cold assertion can qualify. One additional targeted fallback refusal assertion remains unexecuted in v1 as written. No existing long P-A/V2 or recovery matrix needs to be rerun solely for this change.

## P2: full-response equality contradicts original cached-key contract

`tests/test_pb_spec_production_controller.py:197` asserts the second POST `/pb-use-runs` JSON equals the first POST JSON. That route directly returns `app_jobs.enqueue`: a new Run returns `cached=False` (`app_jobs.py:464`), while an existing exact key returns the same Run with `cached=True` (`app_jobs.py:236`). The two JSON objects therefore cannot be equal on the successful intended path. This is a test contract error, not a reason to alter product idempotency. It occurs after the five Generate/Source sends and before Cold approval/Worker execution.

Keep strict validation: require second status 202, first cached false, second cached true, identical run_id/app_run_id and remaining response fields, and unchanged persisted Run/send counts. Do not remove duplicate-submit coverage or change product return shape. This finding was sent to the author immediately. The running frozen v1 input must stay untouched; any failed/interrupted execution and the test-only correction need exact attribution.

## Targeted coverage gap: complete marker loss

The current `generation_marker` clone mutation removes only one marker. Two remaining production markers keep `_pb_accounting` in its `if any(version == VERSION)` branch, so this verifies marker consistency refusal. It does not execute the new all-markers-lost branch that checks for the existing production journal before permitting old-budget selection. A minimal additional short check on an actual successful Source archive copy should remove exactly all three original Generate markers while preserving the original production journal, then require refusal, no table changes and zero sends. This is a single new backend-selection boundary, not another recovery matrix. The author plans a separate bounded short check; no result is claimed here.

## Product selection and source proof

`_checked_trial_contract` preserves exact typed extraction, primitive declared data, original requirements, canonical account quota and seven-slot cap validation. JournalTrialBinding still admits only exact PA/V2; ProductionTrialBinding separately admits exact PB. No PB V1-to-V2 migration or association queue expansion occurs.

`_pb_accounting` first checks original approval, locates the original Generate Run by exact principal/project/runtime/generate key, and reads scalar actual Attempt markers. Any production marker requires exactly three consistent production version/trial fingerprint/approval/account entries. It constructs the original production binding, rechecks the fixed account source, then reads the existing journal with old-budget mixing refusal. The required five accepted Generate/Source slots and one Source Run are subsequently joined to full original stage, generation and journal proofs. Markers select the verifier; they do not authorize sends. If all production labels disappear, any original journal half/pair at this trial key blocks offline fallback; the offline path also retains test-only SQLite and old complete budget audit.

The two public/internal archive entry points no longer require offline SQLite unconditionally, but retain same-engine active transaction, exact PB contract, active original approval, current source scope/full stage proof, fixed production account/qualification and journal checks before private archive bytes. `_source_prefix` calls complete `journal_stage_accounted(source)` before body reads. `_pb_origin` verifies exact original Source ID, extraction key and recipe then the same full Source journal chain. It does not recursively validate Cold through itself.

## Raw bytes, provenance and extraction

The production journal settlement uses the actual decoded-body hash. The old synthetic budget retains its canonical ASCII hash. `_source_bodies` explicitly selects those separate comparisons while still checking stored canonical evidence, decoded NS archive hash, parsed original response, request bytes, typed usage, accepted slots and exact two actual verified Source Attempts. `_pb_journal_archive_chain` joins the source NS receipt to original same-Attempt controller request/response archives and sender Capture, including both hash/length pairs. No canonical reserialization is substituted for received bytes.

Controller BodyArchive writing and `_journal_chain` reconstruction now both select `_production` from the exact binding; NS archive reading independently selects expected provenance from actual frozen/Attempt mode and controller markers. Old incorrect tags are rejected rather than migrated. Labels alone do not authorize LIVE, and public receipts continue live_allowed=false. The default account resolver still always denies; software anchors/checker bytes are unchanged.

`extract_pb` uses its original transaction/write group, fixed original extraction key/recipe and second full Goal/material. Before/after it rechecks source archive/journal, current account/approval and authority. No extra model slot, arbitrary evidence callback, source selector, sender or Grant implementation is introduced.

## PB-use and current authority

`generation_mode` now follows validated PB spec_task.source_run_id to its original frozen mode. Existing enqueue and bound callers have already run original instance/read_release/verify_origin or complete PB-use review; this helper is a mode projection, not authority. Per-use effective candidates retain spec_task, so Cold mode follows the proven original Source; MOCK stays MOCK. Existing PA behavior is unchanged for candidates without spec_task.

Production Cold now rechecks `_pb_source` at claim, admission/commit and terminal commit. The actual source checks retain full current approval, materials/Goals, extraction, sender/capture chain, account, original scope and guards. Sender, shared quota cursor/CAS, lease/fence/revocation/expiry and UNKNOWN semantics are byte-identical. These checks add no business-transaction heartbeat or deadline/lease extension. Deep proof work can still consume the original interval; runtime proof is required and no performance guarantee is inferred.

## Test and document boundaries

The new test intentionally patches production environment selection, fixed evidence producer and qualification only within isolated synthetic SQLite. It retains MockTransport and a real-HTTP tripwire, records that its LIVE-shaped Attempt/provenance rows are simulated, and explicitly labels the result SYNTHETIC_MOCK_PRODUCTION_BRANCH_NOT_REAL_LIVE_EVIDENCE with zero real models. Those substitutions must not be interpreted as actual account entitlement, live provenance or a qualified software install.

The planned body with non-ASCII/whitespace makes decoded and canonical hashes differ, so a passing equality of original bytes would be meaningful. The test also checks original extraction idempotency without sends, explicit PB use, fresh Store, directory family, same-Run result/owner endpoint and 3/2/2 accepted journal slots with actual >=60-second spacing. The default closure test calls the unchanged resolver and actual failing software checker, preserving both blockers. All execution remains pending for this source review, including any later failure before Cold.

The stage document freezes PB V1 3/2/2 plus zero-slot extraction and acknowledges synthetic overrides. No Windows, PG, native UI, real model, paid entitlement, real semantic/human acceptance or remote CI qualification is granted.

## Bounded continuation after the P2 test-only failure

A same-product-source continuation may reuse the five actually completed slots rather than resend them merely to repair the cached flag assertion. It must preserve original contract/approval/account cursor, exact Generate/Source Attempts and raw archive identities, original Cold key/Run/created_at/deadline, and all current guards. Start only after the old process has actually exited and the original DB is preserved. Do not reset time, lease, Run or approval; an expired original Cold interval or denied qualification must stop the continuation. Reprove the original Source/extraction and original explicit stage approval before Cold. Report five-slot prefix and two-slot continuation under separate test/input hashes; never report a fresh same-SHA seven-slot pytest PASS if none occurred. This is a source-based assessment of that proposed bridge, not evidence it ran or passed.
