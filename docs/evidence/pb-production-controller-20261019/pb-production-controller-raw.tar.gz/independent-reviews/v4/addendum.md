# v4 final independent addendum — integration NOT_ACCEPTED

Exact commit 3b91e21cd2b07863d02561a0957bb7fb83feb4b4. This closes the v4 limited source review with actual terminal evidence; earlier v1/v2 seals are untouched. The reviewer read source, immutable Git blobs and raw logs/JSON/XML only. No product imports, tests, DB, models, network or signals were executed. Only this new v4 directory was written.

## Actual gates

| Execution | Actual commit | Result | Outer wall time |
| --- | --- | --- | --- |
| v3 default closure + same-transaction tripwire |91ffc55c15b6d3efb573913470db51dffbd9720e|2 PASS|31.913087820 s|
| v4 full src mypy |3b91e21cd2b07863d02561a0957bb7fb83feb4b4|113 sources PASS|78.002805624 s|
| v4 changed-file Ruff |3b91e21cd2b07863d02561a0957bb7fb83feb4b4|PASS|0.596775677 s|
| v4 PB module |3b91e21cd2b07863d02561a0957bb7fb83feb4b4|2 PASS / 1 FAIL|392.959983654 s|

The v4 two passing nodes are default disabled/missing fixed source/actual software qualification refusal, and actual same-transaction account verification under a nested-tx tripwire with no writes/sends. The PB chain failed before its first Source model send: exactly three Mock exchanges, all Generate. Source inspection returned RUNNING after a verified local read_pick, rather than SUCCEEDED. No extraction, Cold, archive-copy fault, duplicate Cold submit or final owner-review assertion was reached. Do not combine earlier different-run five slots with this run, or state seven slots passed.

All v4 2109 before/after hashes match and agree with the mypy and changed-Ruff input snapshots. Independent Git blob checks match 710 tracked inputs to this immutable commit. Another1399 inventory entries are installed node_modules files, with stable recorded hashes; they are not committed product blobs. No complete vendor archive or independent DB query is claimed. The author runner's original1800s external subprocess limit is preserved in the prior v2 seal; this run completed with exit1 rather than timing out.

## Prior P2 closure and new blocker

The self-nested account transaction P2 has a minimal source fix and targeted regression proof. Production/journal _account(connection=c) validates original engine and active transaction, then invokes the original fixed-source verifier on c. extract_pb passes c before and after its original extraction write group. Other callers and PATrial behavior remain as before. This is not a completed actual-extraction qualification: the v4 long case stopped earlier.

The preserved new traceback is natural.advance_model -> Worker.reserve -> reservation_check -> spec.commit_guard -> trial.check_commit/_admission -> policy.check_run -> gate._run_context. It rejects the original combined Run identity/cancellation/version/finite lease guard at natural_live_admission.py:932. The recorded public failure is VERSION_CONFLICT, Run identity, cancellation, version or finite lease changed; fail_owned did not commit a new terminal state, and Source remains RUNNING. There was no Source reservation/send to classify as successfully received, unknown, or safe-to-repeat.

The Source-specific actual commit-return log most recently shows at=1792408173.4975314, lease_until=1792408203.4905472. No later numeric Source renewal is recorded, while further heartbeat BUSY code5 errors occur. This supports a lost-interval concern but the original _run_context local values and exact comparison time were not observed, so this review does not isolate one predicate or quantify continuous transaction hold time. It is not a new nested-account failure and cannot be dismissed as known CPU load. No unchanged-source blind retry is recommended.

## Bounded next investigation

Static inspection of the exact failed segment shows Worker.reserve holds one original BEGIN IMMEDIATE while performing preflight, full reservation_check (bound/receipts/effective) and commit_guard, which invokes another full policy/_run_context stage proof. There is no single existing SourceReads scope around those natural reservation checks. Each bound has its shorter internal token, which exits between guards. Separately, _stage_current's outer test-only SQLite read-reuse eligibility accepts exact PA/V2 but excludes PB even when the original Generate has exactly three production markers. PB original Source already has the safe same-call instance proof continuation in _stage_current_bound.

These are concrete repeated-proof/reuse-entry candidates for a minimal fix, not measured performance attribution. Reuse only the existing token/transaction/thread/epoch/current Grant checks and complete first proof on the exact affected PB production Source path. Keep every Run/account/approval/lease/fence/expiry check fresh, reject after write/exit, do not cache permits or approval/account, do not heartbeat inside the business transaction and do not widen30/300 or modify the final combined guard. Any product change requires a fresh software-bound contract/approval, not rewriting this old trial. No extra heartbeat/recovery matrix is requested.

## Observer and qualification limits

The revised observer forwards original returns/exceptions while handling common observational I/O/JSON errors independently through teardown; no teardown observer failure is reported. File I/O and scheduling overhead remain real. It saves original guard.__code__ for type-whitelisted local matching, fixing the v2 code-identity defect. However this failing guard is _run_context, not Store.guard, so the old Store.guard frame observer does not provide its local predicates. Successful heartbeat records include Run IDs; error records do not, so error counts alone cannot establish per-Run attribution. Aggregate events: {'original_heartbeat_return': 18, 'original_heartbeat_error': 6}; heartbeat error types: {'OperationalError': 6}. None returns remain worker-only status calls, not Run renewal.

The fixed default account resolver, exact software qualifier and private source/permission/quota/sender machinery remain intact. Synthetic LIVE-shaped rows and overrides are explicitly Mock fixtures, not real account, fee or provider provenance. Full Ruff remains red; no whole-repository green claim, PG, Windows, native UI, real model, semantic/human acceptance or remote CI qualification is made. The original full-disk missing evidence, earlier native crash and all failed/interrupted attempts remain historical gaps/results.

The reviewed transaction fix is supported, but the intended P-B integration remains blocked at Source reservation. Overall NOT_ACCEPTED until that actual path is completed under unchanged safety boundaries.
