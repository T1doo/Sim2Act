# v5 final limited review — 2 PASS, 1 FAIL; PB integration blocked

Reviewed immutable source `97d6f4acc9e714ded0699853c21ca536e101a9c7`, parent `3b91e21cd2b07863d02561a0957bb7fb83feb4b4`. The previously written source review remains a time-stamped source conclusion; this addendum closes its runtime-pending statement. No definite new P1/P2 was identified in the three-file v5 read-reuse delta, but the actual PB integration still fails and is not approved as complete. The new reserve token assertions were not reached.

Reviewer actions were source/Git/AST/hash/XML/JSON/text reads and copies into this new v5 review directory. No product module was imported; no DB, test, model, network, process signal or repository mutation was performed. Exported HTTP/observer data were checked as artifacts, not independently queried from the DB. Previous seals are unchanged.

## Exact execution scope

Author receipts and JUnit agree on three nodes at this SHA: default-source/software rejection PASS (10.055s); same-transaction accounting tripwire PASS (6.614s); original Source → extraction → explicit use → Cold chain FAIL (273.284s). Pytest reports 2P/1F in293.66s; outer execution is303.98343798900896s, returncode1, 11:19:52.179171→11:24:56.161610 UTC. The bounded runner snapshot is included. No timeout or interrupted result was substituted for success.

Before/after2109 input hashes are identical. Independently compared710 input files to immutable Git blobs at97d6;1399 additional entries are stable node_modules hashes, not committed blobs. Full mypy reports113 sources PASS, exit0,55.508814373999485s. Changed-file Ruff eight files PASS, exit0,2.3564093070017407s. Both use the same2109 input hashes. These tools finished before this runtime batch started. No full-repository Ruff PASS is claimed.

The default boundary artifact reports missing-source LIVE_BLOCKED and software VERSION_CONFLICT, changed_tables0, real_models0, live_authorizedfalse. The account tripwire calls original _account twice within the original active extraction transaction while Store.tx is forbidden; it supports the earlier connection-reuse correction. Actual full extraction was not reached, so this short check is not full PB qualification.

## Actual failed path

The complete mock-exchanges file contains exactly three200 synthetic MockTransport exchanges, all original natural Generate messages. Their bytes and hashes are archived; no Source or Cold request appears. The failed HTTP assertion shows Source `run_afbca9658ca14ad19008696e04edc44c` still RUNNING, version1, cancel_intentfalse, resultnull, no known effects and no steps. Its only events are ACCEPTED and CLAIMED fence1. Thus no successful Source typed result, extraction, original-key cached selection, new Cold Store/material/Goal, PENDING acceptance, raw corruption rejection, or full-three-marker-loss rejection is qualified by this long run.

The captured failure traceback is natural_spec_runtime.advance_model→spec._advance_local→pa_spec_apps.py1389 check_commit→production policy→natural_live_admission._run_context. The final require is a combined identity/status/cancellation/version/fence/finite-lease predicate. Its individual failing term and exact comparison time were not captured. Do not claim a directly measured30s locked segment, prove causality from Busy alone, or call a specific composite term observed.

That check_commit already occurs inside the original final _journal_reads context, after the fresh final commit_guard, receipt/context readback, authority refresh and check_worker_tx. It runs before Worker.reserve, so the new four-reservation token observations did not execute. The local read_pick write group did not appear as a persisted step in the failed HTTP response; the traceback and absent steps support rollback, not independent DB verification by this reviewer.

All18 lease observations were checked. Eleven numeric committed Run renewal returns belong to Generate; none belongs to this Source. Two None returns are worker-only heartbeats and must not count as Run renewal. One original Store.guard error records fence1/row_fence1, terminal PARTIAL and lease0, followed by a DomainError heartbeat record; this is the already-terminal Generate interval, not evidence identifying the Source composite failure. Three later OperationalError records are SQLite error5 at BEGIN IMMEDIATE. Those error records lack run_id, so exact per-Run ownership cannot be independently assigned from them. No observational I/O failure was recorded, but wrappers and asserts add scheduling/I/O work and are not zero-overhead instrumentation.

Prior failed PB long runs retain10 actual Mock sends: v1Generate2, v2Generate3+Source2, v4Generate3. This v5 adds Generate3, so the failed-run total is13 (Generate11, Source2, Cold0). Short refusal checks are not counted as sends. Old failure seals, the v2 Unknown trace limitation and old disk-full missing review evidence remain unchanged.

## Bounded profile and source implications

The separate author read-only proof profile2 uses a copied failed synthetic DB, not a successful Run or acceptance. Its script and text/JSON receipts are copied, not executed by this reviewer. It denies model/HTTP and rejects non-SELECT statements during measured read calls, preserves software/contract/clock, and reports no model calls. The original profile1 failed on an invalid Limits construction and is preserved separately; it is not counted as a successful profile.

Profile2 reports6206 cumulative SELECT observations: bound-default-limits11.85066659199947s/2073queries; stage-first10.140889479996986s/4734cumulative; stage-repeat3.2628794370102696s/6206cumulative. The latter query counts are cumulative, not per-call deltas. Outer35.502144606012735s differs from cProfile24.886s. Nested cumulative times overlap and must not be added. This is a distinct copied-state experiment, not retrospective timing instrumentation of the failed final transaction. It does not identify which _run_context term failed.

Static source confirms verified_candidate reuse keys include the full original Run fingerprint and complete Limits fingerprint. Different Limits require their own complete proof; the profile's two _verified_candidate calls must not be merged by dropping this key. Scope hits still execute fresh Grant rechecks and two _journal_scope_anchor calls. Production _generation_accounted still executes full journal_stage_accounted; no new accounting/approval/current-Run cache is justified. Both final check_commit calls remain safety boundaries and must not be removed.

A proposed minimal follow-up may combine the four scalar anchor SELECTs after owner projection/expected comparison/own_project into one projected LEFT OUTER JOIN, while preserving every original field, accepted-event/Attempt cardinality, two anchor comparisons, authority refresh and token/epoch checks. Event filters belong in ON; deduplicate only join multiplication by original event.id/attempt.id, never distinct(version). Preserve missing/zero/multiple evidence refusal and the strict ordinary[None]*3 eligibility call. This is design advice, not reviewed or qualified replacement code. The measured profile motivates fewer SQL round trips; it authorizes neither a lease extension nor a weaker proof.

## Limited conclusion

Static v5 source reuse boundaries show no identified P1/P2 in their reviewed scope; mypy113 and changed-file Ruff are supported. Actual PB end-to-end engineering acceptance remains BLOCKED by the failed Source Run, with0Source/0Cold sends and unexecuted reserve assertions. Continue only after a concrete bounded source correction and fresh software-bound synthetic contract, preserving30s lease/300s Run/original quota, permissions, owner/fence, approval, raw bytes and denial behavior. Do not blindly rerun the same failing chain or rerun unrelated PA/V2 recovery matrices.

No real model, trusted-account source, real fee/semantic/human scenario, LIVE authorization, PG, Windows, native UI or remote CI qualification is asserted. This review does not certify deployment or the original user-visible app directory work.
