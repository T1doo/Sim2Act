import cProfile
import hashlib
import json
import pstats
import sqlite3
import time
from pathlib import Path

import httpx
from sqlalchemy import event, select
from sim2act import natural_live_admission as gate
from sim2act import pa_spec_apps as spec
from sim2act import pb_natural_specs as pb
from sim2act.contracts import Limits
from sim2act.config import Settings
from sim2act.db import Store, runs

root = Path('/workspace/pb-production-controller-20261019/v5-stage-profile2')
original = Path('/workspace/pb-production-controller-20261019/v5-final-nodes/tmp/test_pb_production_original_so0/fixture.db')
target = root / 'read-only-proof-copy.db'
assert not target.exists()
with sqlite3.connect('file:'+str(original)+'?mode=ro',uri=True,timeout=1) as source, sqlite3.connect(target) as dest:
    source.backup(dest)
with sqlite3.connect(target) as c:
    raw = json.loads(c.execute("select snapshot from delivery_graph_requests where kind='natural-live-trial.v1.scope'").fetchone()[0])['request']
    rid = c.execute("select id from runs where status='RUNNING'").fetchone()[0]
contract = gate.PBTrialContract.model_validate(raw)
settings = Settings('sqlite:///'+str(target), root)
platform_limits = Limits(**{k:getattr(settings,k) for k in Limits.model_fields})
store = Store('sqlite:///'+str(target), test_only=True)
model_calls = []
def deny_http(*args,**kwargs):
    model_calls.append('FORBIDDEN')
    raise AssertionError('No model/HTTP during pure read proof profiling')
httpx.HTTPTransport.handle_request = deny_http
httpx.AsyncHTTPTransport.handle_async_request = deny_http
statements = []
def only_reads(c,cursor,statement,parameters,context,executemany):
    assert statement.lstrip().upper().startswith('SELECT '), 'No SQL writes in profile segment'
    statements.append(statement.split()[0])
profile = cProfile.Profile()
timings = []
try:
    with store.tx() as c:
        event.listen(store.engine,'before_cursor_execute',only_reads)
        job = c.execute(select(runs).where(runs.c.id==rid)).mappings().one()
        profile.enable()
        with pb._source_reads(store,c):
            for name, call in (
                ('bound-default-limits',lambda:spec.bound(store,c,contract.principal_id,job,platform_limits)),
                ('stage-first',lambda:gate._stage_current(store,c,contract.principal_id,contract,'source',rid)),
                ('stage-repeat',lambda:gate._stage_current(store,c,contract.principal_id,contract,'source',rid))):
                started=time.monotonic()
                call()
                timings.append(dict(name=name,seconds=time.monotonic()-started,queries=len(statements)))
        profile.disable()
        event.remove(store.engine,'before_cursor_execute',only_reads)
finally:
    profile.disable()
    profile.dump_stats(root/'proof.pstats')
    with (root/'profile.txt').open('w') as out:
        pstats.Stats(profile,stream=out).strip_dirs().sort_stats('cumulative').print_stats(70)
    (root/'read-profile.json').write_text(json.dumps(dict(
        scope='READ_ONLY_PROOF_PROFILE_NOT_A_RUN_OR_ACCEPTANCE', source_sha='97d6f4acc9e714ded0699853c21ca536e101a9c7',
        original_db_sha256=hashlib.sha256(original.read_bytes()).hexdigest(),
        copied_db_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),
        source_run_id=rid, timings=timings, query_count=len(statements), model_calls=model_calls,
        software_or_contract_or_clock_overrides=False),indent=2)+'\n')
    store.engine.dispose()
print(json.dumps(timings),flush=True)
