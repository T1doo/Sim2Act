import ast
import hashlib
import json
import sqlite3
import subprocess
import time
from pathlib import Path

from sqlalchemy import event
from sim2act import goal_applications as generation
from sim2act.db import Store

root=Path('/workspace/pb-production-controller-20261019/v6-projection-parity')
original=Path('/workspace/pb-production-controller-20261019/v5-final-nodes/tmp/test_pb_production_original_so0/fixture.db')
target=root/'anchor-proof-copy.db'
assert not target.exists()
original_hash=hashlib.sha256(original.read_bytes()).hexdigest()
with sqlite3.connect('file:'+str(original)+'?mode=ro',uri=True,timeout=1) as source, sqlite3.connect(target) as dest:
 source.backup(dest)
with sqlite3.connect('file:'+str(target)+'?mode=ro',uri=True,timeout=1) as c:
 rid=c.execute("select id from runs where status='PARTIAL'").fetchone()[0]
old_sha='97d6f4acc9e714ded0699853c21ca536e101a9c7'
old_code=subprocess.check_output(['git','-c','core.fsmonitor=false','show',old_sha+':src/sim2act/goal_applications.py'],text=True)
(root/'old-goal-applications.py').write_text(old_code)
node=next(n for n in ast.parse(old_code).body if isinstance(n,ast.FunctionDef) and n.name=='_journal_scope_anchor')
namespace=dict(generation.__dict__)
exec(compile(ast.Module(body=[node],type_ignores=[]),str(root/'old-goal-applications.py'),'exec'),namespace)
old=namespace['_journal_scope_anchor']
store=Store('sqlite:///'+str(target),test_only=True)
queries=[]
def readonly(c,cursor,statement,parameters,context,executemany):
 assert statement.lstrip().upper().startswith('SELECT '), 'No SQL writes in parity segment'
 queries.append(statement.split()[0])
measurements=[]
try:
 with store.tx() as c:
  event.listen(store.engine,'before_cursor_execute',readonly)
  first=old(store,c,rid)
  assert first is not None and generation._journal_scope_anchor(store,c,rid)==first
  for name,call in [('old-97d6',old),('new-4767',generation._journal_scope_anchor)]:
   at=time.monotonic(); before=len(queries)
   for _ in range(20): assert call(store,c,rid,expected=first['owner'])==first
   measurements.append(dict(name=name,calls=20,seconds=time.monotonic()-at,queries=len(queries)-before))
  assert old(store,c,rid,expected=first['owner']|dict(principal_id='other')) is None
  assert generation._journal_scope_anchor(store,c,rid,expected=first['owner']|dict(principal_id='other')) is None
  event.remove(store.engine,'before_cursor_execute',readonly)
finally:
 store.engine.dispose()
assert hashlib.sha256(original.read_bytes()).hexdigest()==original_hash
(root/'parity.json').write_text(json.dumps(dict(scope='READ_ONLY_SCALAR_PROJECTION_PARITY_NOT_A_RUN_OR_AUTHORITY',
 old_source=old_sha,new_source='476733e8b9b5fa5b03320968d7ce77e3a9f763f1',old_blob_sha256=hashlib.sha256(old_code.encode()).hexdigest(),
 original_db_sha256=original_hash,original_unchanged=True,contract_or_qualification_or_clock_overrides=False,
 full_anchor_equal=True,anchor=first,measurements=measurements,real_http_or_models=0),indent=2)+'\n')
print(json.dumps(measurements),flush=True)
