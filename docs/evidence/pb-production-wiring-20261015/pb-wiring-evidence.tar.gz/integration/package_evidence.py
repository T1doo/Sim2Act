"""Archive every regular owned evidence file and verify every archived byte."""
import hashlib,json,tarfile
from pathlib import Path
b=Path('/workspace/pb-production-wiring-evidence-20261015')
out=Path('/workspace/Sim2Act-pa-provider/docs/evidence/pb-production-wiring-20261015')
out.mkdir(parents=True,exist_ok=False)
files=sorted(p for p in b.rglob('*') if p.is_file() and not p.is_symlink())
manifest={str(p.relative_to(b)):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files}
(out/'MANIFEST.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
archive=out/'pb-wiring-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(b)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(manifest)
 for member in members:
  assert member.isfile() and member.name in manifest
  data=tar.extractfile(member).read();record=manifest[member.name]
  assert len(data)==record['bytes'] and hashlib.sha256(data).hexdigest()==record['sha256']
assert all(hashlib.sha256((b/n).read_bytes()).hexdigest()==v['sha256'] for n,v in manifest.items())
assert set(manifest)=={str(p.relative_to(b)) for p in b.rglob('*') if p.is_file() and not p.is_symlink()}
receipt=dict(file=archive.name,bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),members=len(manifest),product_source_sha='e26f9a83b35f5979b89a65296d642a44f8c969e6',status='NOT_ACCEPTED_P_B_PREFIX_BLOCKED_COLD_AND_MEMO_NOT_RUN',all_members_readback=True,regular_files_only=True)
(out/'ARCHIVE.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
