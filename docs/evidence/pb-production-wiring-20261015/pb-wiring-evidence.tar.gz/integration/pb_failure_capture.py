"""Record actual caught Worker errors; preserve original failure handling."""
import json, os, traceback
from pathlib import Path

def pytest_configure(config):
    from sim2act import app_jobs
    original = app_jobs.fail_job
    def captured(worker, run, error):
        target = Path(os.environ['PB_IMPORT_RECEIPT']).parent / 'CAUGHT_WORKER_ERRORS.jsonl'
        with target.open('a') as f:
            f.write(json.dumps(dict(run_id=run['id'], type=type(error).__name__, error=str(error), public=getattr(error, 'public', None), traceback=''.join(traceback.format_exception(error))), default=str)+'\n')
        return original(worker, run, error)
    app_jobs.fail_job = captured
