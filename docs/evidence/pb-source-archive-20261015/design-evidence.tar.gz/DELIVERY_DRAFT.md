# 原 trial 来源请求/响应归档与独立冷 Store 读取（有限离线交付）

基线 `fd0ac2198986f201e05924104e7f7a7bb0908769`；开发分支 `dev/pb-source-archive-20261015`。冻结源码/测试 `7c6b89aa507580549509d159c69063031509673c`，代码提交 `8737ee41d025af542a2664b867288db476a8c019`。本轮继续原 F1-T06/F2-T03/F3-T05 与 V5/DeliveryRemainingChecklist 的实际来源归档缺口；前批项目局部列修改、受影响应用重验、取消和原 key 恢复已完成，不重复实现。

## 具体合同

新增 `natural_source_archives.py`，只对 test_only SQLite 与显式 MockTransport 的既有自然应用 Worker 生效。实际原请求序列化 bytes 在原 reservation/Attempt 事务内归档；响应归档的是 HTTPX 实际解码的 body bytes，区分完整 body 与已接收 prefix，不是 TLS/HTTP 原始网络包，也不归档 header、连接 URL、配置或凭据。旧 canonical ASCII response 与新解码 body 分别计算 hash，不以 canonical 重建冒充收到的原 body。

复用既有 `delivery_graph_requests` paired seal 命名空间，两个 family 为 `natural_source_request_body.v1` / `natural_source_response_body.v1`；以实际 Run、Attempt、principal、project、runtime 为作用域，固定 provenance=OFFLINE_MOCKTRANSPORT。private body 保存上限32768 bytes，过大/空体明确标记；网络中断只记录已收 prefix 的长度/hash，不声称完整响应长度/hash。缺失、不完整或过大归档不能通过来源解析。

写入前先从实际 Run/Attempt/reservation 读取标量证明归属与原 wire hash/size；响应还检查原 request paired seal。相同内容/完整性重放只读，冲突拒绝。新请求只允许原 STARTED 且 MODEL_RESERVED 事件前；新响应只允许 STARTED/RECEIVED；历史完成对象不补造归档。paired rows 与只含服务器 Attempt ID/归档摘要的事件同事务写入；事务失败不产生部分配对。

正常接收时，新响应归档与原 Attempt.RECEIVED/canonical response/NS_RECEIVED 在同一原事务中完成，不改变原 response 字段形状。解析失败、空体、超限与网络中断保留可证明的已接收事实，不把 UNKNOWN 升级为成功；取消/撤权的已知响应保留 REJECTED_KNOWN/usage，但仍拒绝业务提交。只在旧 asyncio TimeoutError 的既有分支恢复原 parsed response；网络异常不新增恢复成功路径。请求归档写失败则预约、Attempt、配对、上下文和事件全回滚，未发送；响应事务写失败则整个响应事务回滚，原预约/请求归档/STARTED UNKNOWN 保留。该故障下收到的 raw 未持久化，明确 `NOT_PERSISTED_IN_EXPLICIT_WRITE_FAILURE`，不称所有收到事实均可保留。

## 原 key 来源解析与 HTTP

`resolve_trial_source` 仅接受精确 PBTrialContract/原批准 key。一个只读事务内重新检查身份、项目、完整 trial、当前软件资格、材料/完整 Goal 授权、原批准输入/撤回/期限、原预算和 stage keys、成功且未取消的 source Run、完整 source 证据、实际抽取实例与原 extraction key/编辑 Recipe、不同 cold 材料和完整 Goal、两个 VERIFIED MOCK Attempts/原已接受 known source 槽。读取 body 前完成 scope/权限检查；返回前重新检查收集的 authority、原批准和真实期限，不跨事务缓存授权。

归档必须刚好对应两个原 source Attempts，request/response paired seal、事件锚、wire hash/size/字符长度、原预算 reservation、解码 JSON、旧 canonical archive/usage/settlement 全部一致，拒绝缺项、跨 Run/身份/runtime、篡改和模式翻转。成功私有结果才含2对 body；HTTP GET `/api/projects/{pid}/natural-trials/{key}/approvals/{approval_key}/source-archive` 仅从原 trial/批准读取摘要，返回 `ACTUAL_MOCK_ARCHIVE_NOT_LIVE_VERIFIED`，零新模型请求/预约/项目写入，live_allowed/dispatch_authorized/formal_publication_enabled 恒 false。没有请求方输入的 resolver、Run/Attempt、证据或授权覆盖。

生产 `LivePBSourceContract`、account/fee/sender 注册路径不变，未接入此 MOCK reader，不能翻标签获得 LIVE 资格。本轮不是供应商数据库归档或真实付费/免费调用许可。

## 实际验证（终态待填）

同冻结 SHA 定向批20 PASS/0 FAIL/ERROR/SKIP，实际 RC0、519.46秒；XML SHA256 `b60a99ba49916be9041db4fc8c0c2814eab663c02bc2b7f8f13c8b1ef740776f`。498文件 before/after/复制源码/当前 root/Git 字节经独审闭合。11项 capture 边界与9项实际 Worker 用例。实际正链 Generate3+Source2 共5次 Mock dispatch，4个预约间隔均≥60秒，Run300/lease30保持。新独立 Store engine 在同 SQLite 上读取；不是独立 OS 进程，也没有 cold 模型派发。原 key GET重复只读、所有表字节/行 hash 不变。19项内部拒绝检查属于该1项 pytest 用例，不额外累加为测试数。

8项实际 Worker 故障为 invalid_json/empty/oversize/network_prefix/cancel/revoked/request_write_failure/response_write_failure。前6保留原预约/可证明收到事实，零 typed 业务结果；后2覆盖实际写后抛错的事务回滚。故障夹具走实际 Worker，但非原 trial 费用总账，不扩大到实际账号或真实费用保证。

同SHA质量：fullsrc Ruff PASS，8 changed Python Ruff PASS，产品/夹具Node语法PASS。full mypy RC1/86源文件，仅 status_report.py3条与tools.py2条原基线错误，逐行相同，新增0。85模块精确资格 pin `dbfecdd24f9af81fcb89611dbdf4f78d29f4d9afe9ef8bd9b2bfd3bb29fe337d`；原 anchor/ANCHOR_HASH/CHANGED/config排除不变，唯一 QUALIFICATION_HASH literal zero64归一化。

完整359 = 新20 + 原339，当前仍运行，不称已PASS。终态以 COMMAND/PROCESS_EXIT/collection↔XML/RESULT/498源码/Git 封印与独审为准；独立定向20不累加359。原339文件及顺序保持。完整批各实际回执、页面请求数和计时必须从本批重新读取，禁止沿用前批339统计。

## 失败历史与边界

原始失败均单列保留：系统python缺pytest为setup NOT_RUN；初始 capture 7PASS/1FAIL 因测试错误期待 MODEL_OUTPUT_INVALID，而原 strict JSON 行为为 INVALID_INPUT，修正测试不改产品错误语义；后续8PASS只代表当时探针。独审发现并修复4项P2：实际归属标量验证、返回前真实期限、网络异常保持旧UNKNOWN、空体事实留存。最终11项capture与20项Worker组合另列，旧FAIL不被覆盖。最初mypy2新增Literal类型错误与Ruff zip/import错误的输出保留，均已修复。进度辅助脚本错误假设pytest截断目录名导致AssertionError，属于观察脚本setup，未重启测试、不是访问拒绝。

当前未新增工具访问拒绝。前批已拒绝的 `/proc/.../cwd`、原生浏览器、私有SQL/UDF/barrier路径未重试、未替代访问或扩大权限。普通只读进程存活、公开heartbeat观测与日志不会证明进程cwd；该项仍NOT_VERIFIED。

真实账号权益/强制不可收费解析、受审网络sender、真实供应商请求响应ID和实际LIVE来源resolver未实现/未注册。真实模型/费用、PostgreSQL、Windows、原生浏览器、旧源码升级、人工语义、完整真实P-A/P-B、远端CI、部署NOT_RUN。原完整MOCK链仅工程验证。整体NOT_ACCEPTED，dependency BLOCKED_UNKNOWN、owner PENDING、semantic UNKNOWN、formal publication false。
