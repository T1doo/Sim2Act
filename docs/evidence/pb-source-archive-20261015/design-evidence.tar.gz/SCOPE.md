只读范围建议：下一项选择“实际 P-B 来源证据的有界归档与冷解析”，对应原 F1-T06、F2-T03、F3-T05。先完成当前冻结批的终态、独审、归档和正常推送，再开始这项产品代码工作。

本次完整阅读了 docs/分阶段开发计划.md（505 行）、docs/sources/V5/分阶段开发计划.md（480 行）、docs/sources/V5/平台产品设计.md（547 行）、docs/F2/DeliveryRemainingChecklist.md（92 行）及本批 DELIVERY_TEMPLATE.md（76 行），并只读核对相关源码和最新有限交付报告。未运行测试、网络、Git 或诊断，未修改产品/测试。本建议依据模板标明的冻结源码 206de555e22c9a6e85c1ea87a33c1e55c0780968；未独立调用 Git 核实该 SHA，也不对正在运行的 339 项批次声明终态。

原方案将 P-B 定义为从明确目标、实际输入输出、工具调用和验证记录提取，而非重放旧答案（V5 产品 §4，117 行）；模型链须保存实际请求/返回模型、参数、轨迹及用量（§7.2，315 行）；未知结果和失败成本不能消失（§7.4—8.3）。当前分阶段计划 F2-T03 在 95 行、F3-T05 在 157 行，AT-10/23 在 358/371 行。现有项目修改、重验、取消、恢复、逐次材料绑定、自然规范提取及 owner 工程已另有后续交付，不应重复。DeliveryRemainingChecklist 最后一段仍写“自然规范 P-B 独立提取仍缺合同”，但已被 PBNaturalSpecExtraction20261013.md 和 PBNaturalPerUse20261013.md 的实际交付覆盖；不能机械照旧清单重做。

当前尚缺的产品路径有具体代码证据：

| 当前位置 | 已有实现 | 下一项要补的实际能力 |
| --- | --- | --- |
| src/sim2act/worker.py:52、215 | 实际预约保存 natural_spec_wire 的 SHA、字节数和字符数；完整发出体不是独立持久归档 | 在已有预约边界封存本次实际序列化 request bytes，明确版本、Attempt、Run、scope 和来源模式 |
| src/sim2act/model.py:178、219 | InternModel 收到内容后返回 strict_json 解析结果 | 有界记录实际接收字节/完整性与解析结果之间的关系，保留原调用与截止行为 |
| src/sim2act/goal_applications.py:66 | response_archive 将解析后的 dict 重新编码为 canonical ASCII JSON | 保留该旧合同；新增证据必须明确区分 canonical JSON 和实际 transport bytes，不能把重编码说成原 HTTP 字节 |
| src/sim2act/natural_spec_runtime.py:736、815 | 现有实际 Worker 用冻结 wire 调用适配器，持久化 received_raw/raw_evidence；enabled 只准 test-only/mock/MockTransport | 在此既有生产代码路径采集并封存真实执行的离线证据，而非由测试直接构造整份 SourceEvidence |
| src/sim2act/pb_natural_specs.py:73、124 | 已有来源 scope gate、完整 source_audit 与实际 Run/Attempt/Operation/typed/Release 审计 | 复用其先授权后读正文顺序，将有界归档与原来源、抽取请求和新 Goal/材料关联 |
| src/sim2act/pb_live_source_contract.py:117、211 | SourceResolver 只有接口；resolve_source 精确只接受 SyntheticSourceResolver | 实现从持久 Store 读取的服务端解析路径；新离线回执明确为 MOCK/NOT_LIVE_VERIFIED，不能冒充真实供应商来源 |
| src/sim2act/production_trial_admission.py:157、189 | 新桥核实际 DB 指针，但完整 proof 仍来自 resolver.evidence 固定 fixture | 消除下一项解析器对 caller/fixture 提供整份来源对象的依赖，不扩生产准入或发送能力 |

建议的最小产品合同：只支持现有同项目自然规范成功源任务和同一已批准 P-B trial 的两个 source Attempts。源请求体必须来自本次实际 serializer/send 边界；响应证据来自本次实际接收边界。绑定完整 trial/approval 指纹、原 source Run/AppRun/app、Attempt/槽位、wire 与原响应摘要、usage、完整 edited Recipe、独立 extraction key 及完整新 cold Goal/材料。已存在的全来源校验继续保留，归档不代替源任务正确性。

使用版本化、受保护的持久归档；可优先评估现有元数据/成对封印存储能否容纳原上限，避免为此重写执行器或账本。请求归档与原预约同事务；收到响应后按既有只保存回执的边界追加收到的事实，随后仍由原新鲜 owner/fence/version/lease/授权门决定能否接受结果。失败、撤权、取消和迟到的已收到证据可以保留，但不能借归档让 Operation、typed 结果或试验通过。无法完整保存、缺 usage、缺来源或未知发送时保守拒绝资格，原槽不退款；原 key 仅读恢复不得自动重发。

现有 32768 请求/规范化响应边界、各节点/Run 预算、3+2+2 和真实间隔不能提高。若另存 transport bytes，必须预先明确有界大小、完整/截断状态以及与旧 canonical SHA 的两种摘要，不能复用同一字段改变旧含义。所有公共回执只出 ID、状态、尺寸和摘要；正文按当前材料/项目/身份授权后读取，不进普通事件、错误或下载接口。旧历史缺归档须返回 MISSING/NOT_VERIFIED，不能从现代码重建后声称当时已归档，也不批量改签旧版本。

必要验收先收敛为一条实际正链：正常 SQLite、实际 Worker 和显式 MockTransport 产生源任务/两次 Attempt；独立冷 Store 仅凭原 key 和数据库持久记录读取、重验并构造同 trial 的来源回执。此切片不要求再实现或启动完整 Cold 模型链，完整 edited Recipe/新 Goal/材料仅作为原合同一致性的一部分核对。正例须证明实际发出 bytes、已收到 bytes、原 canonical response、槽位和 usage 精确对应，原 app/Release/typed 历史不改、只新增本次有权归档。不得直接 seed “VERIFIED/LIVE” 行充当正向实际执行。

最小负例包括跨主体/项目/试验/source Run/Attempt、错抽取 key/Recipe/Goal、wire/raw 摘要或大小损坏、遗漏或额外槽、unknown/partial usage、归档不完整、源撤权/到期、当前版本变化、取消/失联迟到、重复同 key 与不同请求冲突。用正常 API/SQLAlchemy 和已有允许的故障边界验证失败无部分业务写入、已知收到的证据与费用不丢失；不使用已拒私有 SQL/UDF/barrier、原生浏览器或 /proc 目标。冷读取应零发送、零新增预算、零改写原历史。原源审计、自然运行及 P-B 相关回归、精确资格 pin 和独审仍须随实际最终源码重验。

这是可在现有离线授权下完整实现和验证的“实际 Worker 证据采集→持久化→隔离 Store→同 trial 只读解析”功能；不是再追加一套 typed fixture 或默认拒绝接口。它推进本批明确列出的来源解析代码依赖，便于以后真正获准的来源复用同一持久格式，但本项工程 PASS 不能称为真实 LIVE 来源验证，也不能声称全部生产 resolver 条件已实现。

真实 production 准入仍有独立阻塞：可信 account→quota/权益与强制不可收费证明、受审网络 sender、真实模型调用授权和实际供应商来源均没有提供。本批模板 76 行明确这些未实现/未注册。natural_live_admission.py:373、410 与 natural_spec_runtime.py:44/188 仍强制 MOCK；因此“仅增加解析器就能使现有真实桥成功”是错误说法。本切片不放宽这些门、不注册生产 sender、不把 MOCK 行改标 LIVE、不配置凭据。真实正向 LIVE 桥、PG/Win11/native、真实语义/owner、完整 P-A/P-B/R0 仍 NOT_RUN 或 BLOCKED；是否以后接生产由单独具体授权和证据决定。

建议改动范围首先锁在 worker.py 的自然规范预约、natural_spec_runtime.py 的既有接收边界及一个独立有界归档/读取模块。model.py 仅在确需保留 transport bytes 时增加受控内部返回证据；goal_applications.response_archive 的旧含义不变。pb_natural_specs.py 只接入来源证明，pb_live_source_contract.py/production_trial_admission.py 最多复用解析结果结构，维持所有生产默认拒绝。无需新增通用 UI、行业模板、发布流程、调度器或账户管理页面；若上述最小范围仍无法保持旧兼容，可先收窄到 source 两节点的实际归档与冷解析，而不宣称完整生产桥已完成。

对原 wire/raw 的精确结论与最小接线：`InternModel._request_serialized` 直接对 `response.content` 调 `strict_json`；有 deadline 时 `_deadline_request` 按实际 `aiter_bytes` 累积 `payload` 后解析，最后返回 dict。当前特殊超时异常最多携带 `_received_response` 解析字典；没有携带原始 byte buffer。因此不能只调用现有 response_archive 就获得 transport 原字节。最小改动应是适配器内部增加受控、版本化接收 envelope，在原两条接收路径把实际 bytes、完整性、长度/hash 与 parsed JSON 一起交给此自然规范调用点；普通调用方继续保持原返回合同。不要另加任意 IO callback 或 caller 可供的 provider 证明。截断/超限/超时仍按原状态失败，未知不得给已验证资格。HTTPX 的解码后 body、原 HTTP 压缩传输 bytes 与 canonical JSON 三者需命名准确；使用 `response.content`/`aiter_bytes` 时，只能称“适配器实际收到的解码后 body bytes”，不能声称 TLS/HTTP 线缆原包。

防凭据归档的现存边界是：`worker.reserve` 仅序列化 model/messages/tools/stream/max_tokens 为 body；Authorization 只在 `model.py:194` 附加到 request headers，不在 body。`goal_applications.response_archive` 的注释明确只入受保护 Attempt，私有 raw 不入公共事件/日志；natural_spec_runtime 的 NS_RECEIVED 事件只写 attempt_id 与指纹。新 envelope/归档须保留这些边界：只捕获 body bytes，不保存 Request/Response 整对象、Settings、headers全集、URL带查询、Authorization/Cookie/Set-Cookie 或环境变量。需要的 response ID 从已验证 body 字段读取；若将来供应商 request ID 只在 header 中，须单独审定固定非秘密字段，缺失时 UNKNOWN，不抓取全部 header 或编造。新离线正例用合成 token 哨兵检查数据库归档、事件与公开回执不含此哨兵；不读取或搜索真实凭据。材料正文始终是有权的私有证据，不能因没有 token 就公开。

稳定验证应把字节合同单测和实际纵向测试分开：受控 MockTransport 给出空白/键顺序不同但解析等价的两份 JSON，另含 UTF-8 内容，确认 transport digest/bytes 各自保留，canonical digest按原算法，两个摘要不互换。两节点完整正链只用原预算、原 Run300/lease30、原真实时钟和正常 Worker；冷解析不依赖线程调度或新增等待。故障例优先在已有接收/提交边界明确注入，不以负载碰运气，也不为了得到绿轮延长租约、缩短原间隔或增加重取上限。保存实际 collection/XML/退出码、source 前后清单与失败史；这份建议没有运行上述任何检查。

精确资格影响已核到源码：`text_continuations.py:44` 当前 pin 为 c48978cbcbd6b7d3b4c63c8a6911d1bb0298ab36b0dc5776d27c2c9b8a363ead，`qualified_target` 要求 review_candidate 为 3284f0bd3cb0f40a1e6cb87aa662ff2c4b99c621，manifest 等于当前全部 .py（仅按原规则排除 config.py），唯一 QUALIFICATION_HASH literal 用 zero64 归一化。worker.py/model.py/natural_spec_runtime.py 的任何变更或新增归档模块都会使当前目标资格失效；下一轮必须在独审后的实际候选上重新冻结完整文件集合、精确 candidate、manifest/pin 并重跑资格篡改回归，不能仅修改旧 hash 以显示通过。当前84模块若新增文件会增长，最终数量以实际清单为准。ANCHOR_HASH、原 anchor bytes、两来源、CHANGED 集合、原基线和排除/归一化规则不扩大；旧 Release/Goal/人工记录和历史 seal 不改签。先保护本轮206的终态归档，再启动新资格，不能让下一源码污染当前唯一回归。
