import collections,hashlib,json,tarfile
from pathlib import Path,PurePosixPath
B=Path('/workspace/pb-source-archive-evidence-20261015');D=Path('/workspace/Sim2Act-pa-provider/docs/evidence/pb-source-archive-20261015');O=Path('/workspace/pb-source-archive-review-20261015')
O.mkdir(parents=True, exist_ok=True)
def h(p):
 z=hashlib.sha256()
 with p.open('rb') as f:
  for q in iter(lambda:f.read(1024*1024),b''):z.update(q)
 return z.hexdigest()
a=json.loads((D/'ARCHIVES.json').read_text());assert len(a)==5
names={'tests','regression','review','integration','design'};assert set(a)==names
results={};allman={};excluded={'__pycache__','.pytest_cache','mypy-cache'}
for name,receipt in a.items():
 root=B/name;man=json.loads((D/(name+'-MANIFEST.json')).read_text());target=D/receipt['file'];assert target.name==name+'-evidence.tar.gz' and target.stat().st_size==receipt['bytes'] and h(target)==receipt['sha256']
 expected={};skip=collections.Counter()
 for p in root.rglob('*'):
  rel=p.relative_to(root)
  if excluded.intersection(rel.parts):skip['declared_cache']+=1;continue
  if p.is_symlink():skip['symlink']+=1;continue
  if not p.is_file():continue
  assert not any(x.is_symlink() for x in p.parents if x!=root.parent)
  if name=='integration' and rel.as_posix()=='PACKAGE_RESULT.json':skip['self_result']+=1;continue
  expected[rel.as_posix()]={'bytes':p.stat().st_size,'sha256':h(p)}
 assert expected==man,(name,'source manifest mismatch')
 seen=set();total=0
 with tarfile.open(target,'r:gz') as archive:
  for member in archive:
   n=member.name;parts=n.split('/');assert n and not PurePosixPath(n).is_absolute() and chr(92) not in n and all(q not in ('','.','..') for q in parts)
   assert member.isfile() and not member.issym() and not member.islnk() and n not in seen and n in man,(name,n)
   seen.add(n);assert member.size==man[n]['bytes'];z=hashlib.sha256();size=0
   with archive.extractfile(member) as f:
    for block in iter(lambda:f.read(1024*1024),b''):z.update(block);size+=len(block)
   assert size==member.size and z.hexdigest()==man[n]['sha256'];total+=size
 assert seen==set(expected) and len(seen)==receipt['members']
 results[name]={'archive_bytes':receipt['bytes'],'archive_sha256':receipt['sha256'],'members':len(seen),'uncompressed_bytes':total,'source_set_manifest_tar_exact':True,'every_member_size_sha256_exact':True,'safe_relative_regular_unique_members':True,'excluded_counts':dict(skip)};allman[name]=man
 print(json.dumps({'name':name,'members':len(seen),'PASS':True}),flush=True)
required={'tests':['capture-first.stderr','capture-initial/RESULT.json','capture-initial/results.xml','capture-corrected/RESULT.json','capture-boundaries/RESULT.json','archive-first/RESULT.json','archive-first/PROCESS_EXIT.json','archive-first/results.xml','pb-cold-pointer-first/RESULT.json','pb-cold-pointer-extended/RESULT.json','pb-cold-pointer-extended/results.xml','pb-cold-pointer-corrected/RESULT.json','mypy-first.stdout','ruff-first.stdout'], 'regression':['final7c/RESULT.json','final7c/PROCESS_EXIT.json','final7c/COLLECTION.json','final7c/results.xml','final7c/FAILED_SUPPORTING_CHECKS.json','final7c/source-before.json','final7c/source-after.json','final7c/executed-source-manifest.json','quality7c/RESULT.json','quality-cold-pointer/RESULT.json','final-cold-pointer/RESULT.json','final-cold-pointer/PROCESS_EXIT.json','final-cold-pointer/COLLECTION.json','final-cold-pointer/results.xml','final-cold-pointer/FAILED_SUPPORTING_CHECKS.json','final-cold-pointer/source-before.json','final-cold-pointer/source-after.json','final-cold-pointer/executed-source-manifest.json'], 'review':['CODE_INITIAL_REVIEW.md','CODE_REVISED_REVIEW.md','QUALIFICATION_7C_REVIEW.md','QUALIFICATION_7C_CHECKS.json','FINAL_7C_TERMINAL_REVIEW.md','FINAL_7C_TERMINAL_CHECKS.json','QUALIFICATION_056_REVIEW.md','PB_COLD_POINTER_EXTENDED_REVIEW.md','FINAL_056_TERMINAL_REVIEW.md','FINAL_056_TERMINAL_CHECKS.json'], 'integration':['TERMINAL_AUDIT.json','QUALIFICATION.json','PROGRESS_SETUP_ERROR.json','TRANSPORT_RECOVERY_7C.json','fix-pb-cold/TERMINAL_AUDIT.json','fix-pb-cold/QUALIFICATION.json','fix-pb-cold/CONNECTION_NOTICE_0935.json','fix-pb-cold/CONNECTION_NOTICE_1008.json','fix-pb-cold/PEER_VERSION_EXISTING_LOG_TIMELINE.json','fix-pb-cold/summarize_failed056.py','fix-pb-cold/write_failed_delivery056.py'], 'design':['SCOPE.md','DELIVERY_DRAFT.md','DELIVERY_056_FINAL.md','FULL7C_FAILURE.md']}
required['review'] += ['056_PROJECT_PEER_VERSION_FAILURE_REVIEW.md','056_PROJECT_READ_SCOPE_CANDIDATES.md','056_FAILURE_AWARE_DELIVERY_REQUIREMENTS.md','056_FAILED_SUMMARY_SCRIPT_REVIEW.md','REVIEW_OUTPUT_NAME_CORRECTION_056.md','REVIEW_OUTPUT_NAME_CORRECTION_056.json','RECONSTRUCTED_7C_REVIEW_RECEIPT.json','CORRECTION_MISWRITTEN_056_OUTPUT.json','056_PB_TARGET_REVIEW.md','056_PB_TARGET_CHECKS.json','DOC_056_FINAL_REVIEW.md']
peer='final-cold-pointer/observer/4c52179251fda12b64aa164765eca3405b46cf52403373f66b41bb84cc877e0f'
required['regression'] += [peer+suffix for suffix in ('.failure.txt','.jsonl','.heartbeat.jsonl')]
for root,paths in required.items():assert all(p in allman[root] for p in paths),(root,'required missing')
assert not {'PACKAGE_RESULT.json'}&set(allman['integration'])
out={'snapshot':'normal-push-before-snapshot','source_sha':'056fb5a4796ba91cd5c2bcd12628bd06d2eae9ca','archives':5,'total_members':sum(x['members'] for x in results.values()),'ARCHIVES_sha256':h(D/'ARCHIVES.json'),'results':results,'required_history_final_probe_quality_review_recovery_present':True,'central_written_by_reviewer':False,'tests_or_diagnostics_run':False,'push_receipt':'NOT_YET_REVIEWED_EXTERNAL_LATER'}
(O/'ARCHIVE_CHECKS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'archives':5,'members':out['total_members'],'all_exact':True}))
