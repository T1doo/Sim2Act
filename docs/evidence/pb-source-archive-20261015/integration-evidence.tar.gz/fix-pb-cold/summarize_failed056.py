"""Prepare explicit failed-full-batch support; never implies suite acceptance."""
from pathlib import Path
import hashlib,json,collections
ROOT=Path('/workspace/pb-source-archive-evidence-20261015/regression/final-cold-pointer')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
result=load(ROOT/'RESULT.json'); collection=load(ROOT/'COLLECTION.json')
terminal=load(ROOT.parent.parent/'integration/fix-pb-cold/TERMINAL_AUDIT.json')
assert terminal['source_sha']==result['sha'] and terminal['returncode']==result['returncode']==1
assert terminal['xml_sha256']==digest(ROOT/'results.xml')==result['xml_sha256']
assert terminal['result_sha256']==digest(ROOT/'RESULT.json')
assert {k:terminal[v] for k,v in [('pass','PASS'),('failure','FAIL'),('error','ERROR'),('skipped','SKIP')]}==result['counts']
assert terminal['unique_ids']==389 and terminal['PASS']+terminal['FAIL']+terminal['ERROR']+terminal['SKIP']==389 and terminal['FAIL']+terminal['ERROR']>0
expected={n.split('::')[0][:-3].replace('/','.')+'::'+'::'.join(n.split('::')[1:]) for n in collection['nodeids']}
actual={x['id'] for x in result['testcases']}
ui=[]
for p in sorted((ROOT/'tmp').glob('test_project_page_exact_cancel*/result.json')):
 if p.parent.is_symlink():continue
 x=load(p)
 ui.append({'path':str(p.relative_to(ROOT)),'sha256':digest(p),'status':x['status'],
  'checks':len(x['checks']),'actions':len(x['actions']),'requests':len(x['requests']),
  'assets':len(x['static_resource_loads']),'boots':len(x['boots']) if isinstance(x['boots'],list) else x['boots'],
  'assets_all_200':all(a['status']==200 for a in x['static_resource_loads'])})
claims=[]
for p in sorted((ROOT/'tmp/test_two_apps_partial_then_com0').glob('worker-claims-*.json')):
 x=load(p)
 claims.append({'path':str(p.relative_to(ROOT)),'sha256':digest(p),'run_id':x['run_id'],
  'run_seconds':x['accepted_clock']['deadline']-x['accepted_clock']['created_at'],
  'lease_seconds':x['settings_lease_seconds'],'max_claims':x['max_claims'],
  'actual_claims':len(x['claims']), 'states':[{'before':c['before']['status'],'after':c['after']['status'],
  'after_fence':c['after']['fence']} for c in x['claims']]})
chains=[]
for p in sorted((ROOT/'tmp').glob('*/actual-combined-admission-budget.json')):
 if p.parent.is_symlink():continue
 x=load(p); a=x['accounting']; ledger=a['ledger']; slots=ledger['slots']
 stamps=[s['reserved_at'] for s in slots]
 chains.append({'path':str(p.relative_to(ROOT)),'sha256':digest(p),
  'source_admission_sha256':x['admission_sha256'],'source_budget_sha256':x['budget_sha256'],
  'slot_count':len(slots),'slot_ids_unique':len(set(x['slot_ids'])),
  'stage_runs':ledger['stage_runs'],'stage_count':dict(collections.Counter(s['reservation']['stage'] for s in slots)),
  'reserved_requests':a['reserved_requests'],'reserved_envelope':a['reserved_envelope'],
  'total_tokens':a['total_tokens'],'usage_status':a['usage_status'],
  'all_slots_accepted':all(s['accepted'] for s in slots),'reservation_gaps':[b-a for a,b in zip(stamps,stamps[1:])],
  'all_permits_synthetic_not_live':all(p['scope']=='SYNTHETIC_ONLY' and not p['live_allowed'] for p in x['permits'])})
assert len(claims)==2 and len({x['run_id'] for x in claims})==2
for x in claims:
 assert x['run_seconds']==300 and x['lease_seconds']==30 and x['max_claims']==3 and x['actual_claims']==1
 assert x['states']==[{'before':'QUEUED','after':'SUCCEEDED','after_fence':1}]
assert len(ui)==8 and all(x['assets_all_200'] for x in ui)
assert sum(x['checks'] for x in ui)==119
assert 0<=len(chains)<=2
for x in chains:
 assert x['slot_count']==x['slot_ids_unique']==x['reserved_requests']==7
 assert x['stage_count']=={'generate':3,'source':2,'cold':2} and len(set(x['stage_runs'].values()))==3
 assert x['reserved_envelope']==48354 and x['total_tokens']==7000 and x['usage_status']=='KNOWN'
 assert x['all_slots_accepted'] and x['all_permits_synthetic_not_live']
 assert len(x['reservation_gaps'])==6 and min(x['reservation_gaps'])>=60
source_paths=[p for p in (ROOT/'tmp').glob('*/actual-source-archive.json') if not p.parent.is_symlink()]
assert len(source_paths)==1
p=source_paths[0]; src=load(p); receipt=src['receipt']
assert src['actual_dispatch_stages']==['generate']*3+['source']*2
assert len(src['reservation_gaps'])==4 and min(src['reservation_gaps'])>=60
assert src['all_read_tables_unchanged'] and src['run_seconds']==300 and src['lease_seconds']==30
assert src['real_models']==src['cold_model_dispatches']==0
assert len(src['checks'])==19 and len({x['case'] for x in src['checks']})==19
assert all(x['all_tables_unchanged'] for x in src['checks'])
assert receipt['verification']=='ACTUAL_MOCK_ARCHIVE_NOT_LIVE_VERIFIED'
assert not receipt['live_allowed'] and not receipt['dispatch_authorized'] and not receipt['formal_publication_enabled']
assert receipt['new_model_requests']==receipt['new_reservations']==receipt['project_writes']==0
assert len(receipt['attempts'])==2
for a in receipt['attempts']:
 assert a['decoded_body_sha256']!=a['canonical_ascii_sha256']
source_summary={'path':str(p.relative_to(ROOT)),'sha256':digest(p),'actual_dispatch_stages':src['actual_dispatch_stages'],'reservation_gaps':src['reservation_gaps'],'internal_read_only_checks':19,'checks_are_not_extra_pytest_cases':True,'all_read_tables_unchanged':True,'cold_reader':'new independent Store engine, same SQLite, not child OS process','cold_model_dispatches':0,'receipt':receipt}
faults=[]
for name in ('received-failure.json','request-rollback.json','response-rollback.json'):
 for p in sorted((ROOT/'tmp').glob('*/'+name)):
  if p.parent.is_symlink():continue
  x=load(p)
  if name=='received-failure.json':
   assert x['actual_sends']==1 and x['real_models']==0 and x['preserved_reservation'] and x['new_typed_results']==0
   assert x['archive']['provenance']=='OFFLINE_MOCKTRANSPORT'
   assert x['attempt_status']==('REJECTED_KNOWN' if x['fault'] in ('cancel','revoked') else 'STARTED')
  elif name=='request-rollback.json':
   assert x=={'no_attempt':True,'no_reservation':True,'no_archive':True,'actual_sends':0}
  else:
   assert x=={'response_transaction_rolled_back':True,'preserved_reservation':True,'actual_sends':1,'state':'UNKNOWN','raw_receipt':'NOT_PERSISTED_IN_EXPLICIT_WRITE_FAILURE'}
  faults.append({'path':str(p.relative_to(ROOT)),'sha256':digest(p),'receipt':x})
assert len(faults)==8
assert sum(Path(z['path']).name=='request-rollback.json' for z in faults)==1
assert sum(Path(z['path']).name=='response-rollback.json' for z in faults)==1
assert {z['receipt']['fault'] for z in faults if 'fault' in z['receipt']}=={'invalid_json','empty','oversize','network_prefix','cancel','revoked'}
summary={'sha':result['sha'],'terminal_counts':result['counts'],'xml_sha256':result['xml_sha256'],
 'collection_xml_bijection':expected==actual,'missing_in_xml':sorted(expected-actual),'unselected_in_xml':sorted(actual-expected),
 'unique_ids':result['unique_ids'],'source_file_count':len(load(ROOT/'source-before.json')),
 'source_closure':all(result[k] for k in ['source_unchanged','executed_source_equal','head_unchanged','worktree_clean']),
 'source_archive':source_summary,'worker_archive_faults':faults,'fault_fixtures_not_original_trial_fee_accounting':True,'original_two_app_claims':claims,'ui':ui,'ui_totals':{k:sum(x[k] for x in ui) for k in ['checks','actions','requests','assets','boots']},
 'actual_synthetic_worker_chains':chains,
 'third_seven_slot_case':{'nodeid':'tests/test_natural_trial_budget.py::test_seven_actual_reservations_stage_binding_nontransfer_no_refund','worker_model_chain':False,'ordinary_store_reserve_settle_heartbeat':True,'original_source_asserted_known_tokens':14,'original_source_asserted_reserved_envelope':7868,'fixture_json_receipt':'NOT_EXPORTED_BY_ORIGINAL_TEST'},
 'old_database_read':False,'real_models':0,'native_browser':'NOT_RUN','PG':'NOT_RUN','Windows':'NOT_RUN'}
# Bind exported fixtures to this batch's exact test outcomes, not historical probes.
import xml.etree.ElementTree as ET
cases=list(ET.parse(ROOT/'results.xml').getroot().iter('testcase'))
def node(case):return case.get('classname').replace('.','/')+'.py::'+case.get('name')
status={node(c):next((v.tag for v in c if v.tag in ('failure','error','skipped')),'pass') for c in cases}
assert set(status)==set(collection['nodeids'])
def bind(receipt,n):
 assert n in status
 receipt['nodeid']=n;receipt['test_status']=status[n]
 # All receipts asserted complete above may support success only if their case passed.
 assert status[n]=='pass',(n,status[n])
bind(source_summary,'tests/test_natural_source_archives.py::test_actual_worker_to_cold_store_same_trial_archive')
for f in faults:
 name=Path(f['path']).name
 fault=f['receipt'].get('fault', 'request_write_failure' if name=='request-rollback.json' else 'response_write_failure')
 bind(f,'tests/test_natural_source_archives.py::test_received_failure_facts_survive_without_business_success['+fault+']')
for claim in claims:bind(claim,'tests/test_project_natural_revalidation.py::test_two_apps_partial_then_complete_checks_and_cold_account')
uinodes=[n for n in collection['nodeids'] if n.startswith('tests/test_project_check_cancel_ui.py::test_project_page_exact_cancel_unknown_cold_and_permission_recovery[')]
assert len(uinodes)==8
ui_indices=[int(Path(u['path']).parent.name.removeprefix('test_project_page_exact_cancel')) for u in ui]
assert len(ui_indices)==len(set(ui_indices))==8 and set(ui_indices)==set(range(8))
for u in ui:
 index=int(Path(u['path']).parent.name.removeprefix('test_project_page_exact_cancel'))
 bind(u,uinodes[index])
chainnodes={'PA':'tests/test_natural_live_admission.py::test_actual_mock_generated_app_stage_binding_and_cold_per_use','PB':'tests/test_pb_trial_admission.py::test_pb_exact_same_trial_source_extraction_and_cold_seven_slots'}
for chain in chains:
 folder=Path(chain['path']).parent.name
 if folder=='test_actual_mock_generated_app0':kind='PA'
 elif folder=='test_pb_exact_same_trial_sourc0':kind='PB'
 else:raise AssertionError('Unrecognized chain receipt directory: '+folder)
 chain['kind']=kind;bind(chain,chainnodes[kind])
assert len({c['kind'] for c in chains})==len(chains)
summary['chain_evidence_status']={kind:{'nodeid':n,'test_status':status[n],'receipt':'EXPORTED_VALIDATED' if any(c['kind']==kind for c in chains) else 'NOT_EXPORTED_BY_CURRENT_CASE'} for kind,n in chainnodes.items()}
summary['suite_outcome']='FAIL';summary['returncode']=1;summary['overall_acceptance']='NOT_ACCEPTED'
summary['process_exit_sha256']=digest(ROOT/'PROCESS_EXIT.json')
summary['elapsed_seconds']=result['elapsed']
summary['case_statuses']=status
summary['non_pass_cases']=[{'nodeid':node(c),'status':status[node(c)],'details':[{'type':v.get('type'),'message':v.get('message'),'text':v.text} for v in c if v.tag in ('failure','error','skipped')]} for c in cases if status[node(c)]!='pass']
summary['new_30_boundary_counts']=dict(collections.Counter(status[n] for n in collection['nodeids'][:30]))
summary['new_20_archive_counts']=dict(collections.Counter(status[n] for n in collection['nodeids'][30:50]))
summary['peer_version_existing_public_log_timeline']=load(ROOT.parent.parent/'integration/fix-pb-cold/PEER_VERSION_EXISTING_LOG_TIMELINE.json')
summary['third_seven_slot_case']['test_status']=status[summary['third_seven_slot_case']['nodeid']]

(ROOT/'FAILED_SUPPORTING_CHECKS.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
