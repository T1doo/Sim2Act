"""Publish accurate completed offline evidence documentation after terminal audit."""
from pathlib import Path
import json
repo=Path('/workspace/Sim2Act-pa-provider')
b=Path('/workspace/pb-source-archive-evidence-20261015')
def load(p):return json.loads(p.read_text())
a=load(b/'integration/fix-pb-cold/TERMINAL_AUDIT.json'); s=load(b/'regression/final-cold-pointer/SUPPORTING_CHECKS.json')
assert a['PASS']==389 and a['FAIL']==a['ERROR']==a['SKIP']==a['returncode']==0
assert s['sha']==a['source_sha']=='056fb5a4796ba91cd5c2bcd12628bd06d2eae9ca'
text=(b/'design/DELIVERY_056_DRAFT.md').read_text()
text=text.replace('## 实际验证（终态待填）','## 实际验证')
old='056完整批389 = 新30边界 + 原359（包含20来源归档与原339），当前运行中，不称已PASS；终态依实际PROCESS_EXIT/XML/RESULT/499源码与独审。旧7c完整批358PASS/1FAIL/0ERROR/SKIP、359全部执行、RC1，6230.71秒，失败与新结果不拼合。原339及原359测试文件/顺序保留。'
assert old in text
new=f"完整批 **389 PASS / 0 FAIL / 0 ERROR / 0 SKIP / 0 deselected**，实际RC0，{a['elapsed_seconds']:.2f}秒。389 unique，新30 + 原359精确顺序保留（内含20来源归档和原339），原359测试文件字节不变；collection与XML逐项双射，PROCESS_EXIT/RESULT一致，无unnamed条目。499文件执行前后/复制源码/当前root/Git字节闭合。XML SHA256 `{a['xml_sha256']}`，RESULT SHA256 `{a['result_sha256']}`。历史7c定向20、WIP30与旧7c完整358PASS/1FAIL另列，不累加389。旧批6230.71秒/RC1，XML e78b1a2f10f3d83a4605db8a67b26e87a07095e2f6c4efba0040007b61b645a4，RESULT fc56083102d445497db1548c9d5931b7c722ff266644dc229df61d73888b57bd；不被新版通过覆盖。"
text=text.replace(old,new).replace('完整056执行才覆盖最终字节','完整056批覆盖最终字节')
u=s['ui_totals']; chains=s['actual_synthetic_worker_chains']; src=s['source_archive']
new=f"本批两次CHECK各1次领取并SUCCEEDED/fence1，Run300/lease30/maxclaims3不变。实际MOCK P-A/P-B各7槽Generate3/Source2/Cold2，均accepted/KNOWN7000 tokens/envelope48354，六个预约间隔各≥60秒。第三个七槽用例为原Store reserve/settle/heartbeat工程验证，由原断言通过，不称模型链。\n\n本批HTTP/JSDOM8例：{u['checks']}检查、{u['actions']}操作、{u['requests']}请求、{u['assets']}静态资源、{u['boots']}启动，静态资源全200。实际来源正链本批再次5次Mock派发、19内部项通过，四gap={src['reservation_gaps']}。8Worker故障回执完整，response事务显式写失败仍明确raw未持久化。所有数字从本批回执重新读取。\n\n独立只读审查覆盖4项P2修复、85模块资格/498源码/定向20终态、同SHA质量、完整389终态及交付文档；详见[证据索引](../evidence/pb-source-archive-20261015/README.md)。"
text=text.replace('## 失败历史与边界',new+'\n\n## 失败历史与边界')
(b/'design/DELIVERY_056_FINAL.md').write_text(text)
(repo/'docs/F2/PBSourceArchive20261015.md').write_text(text)
d=repo/'docs/evidence/pb-source-archive-20261015';d.mkdir(exist_ok=True,parents=True)
(d/'README.md').write_text(f"# 原trial来源归档离线证据\n\n冻结SHA `{a['source_sha']}`；基线fd0ac2198986f201e05924104e7f7a7bb0908769；389PASS/0FAIL/ERROR/SKIP/deselected，RC0。历史7c定向20PASS和WIP30另列不累加；旧7c完整358PASS/1FAIL/RC1保留。新30+原359顺序/原文件字节保持，499源码before/after/copied/root/Git闭合。\n\n[交付说明](../../F2/PBSourceArchive20261015.md)。ARCHIVES.json及每个MANIFEST列出5个归档的实际字节/hash；仅排除声明的cache、symlink/current别名和PACKAGE_RESULT自引用。audit_archives.py逐成员核验原件集合、大小/hash、安全相对regular唯一路径。\n\n- tests：初始setup NOT_RUN、7PASS/1FAIL、8PASS、11PASS、20PASS及各次实际源码副本/封印、mypy/Ruff修复前原输出；pointer首15PASS、扩展29PASS/1FAIL fixture缺字段、corrected30PASS及各次499执行源码。\n- regression：旧7c完整359与新056完整389的COMMAND/START/PROCESS_EXIT/collection/XML/streams/RESULT/各版498或499执行源码、实际Store回执和全表快照；quality7c与quality-cold-pointer。\n- review：设计、初审4P2、修复复审、资格/20终态、质量、终态脚本、旧7c完整359FAIL与新056完整389及最终文档独审。\n- integration：执行/审核/归档/正常push核验脚本、7c及056分开TERMINAL_AUDIT、各版pin、连接恢复和观察脚本setup失败。\n- design：原计划范围、7c失败合同与056最终说明；带DRAFT后缀的文件为准备稿，不代替FINAL和实际RESULT。\n\n旧production-admission批失败历史仍在其原归档，未复制或覆盖。本批仅MOCK工程证明，原始body为HTTPX解码body，不是网络包；prefix不是全响应；response事务写失败raw明确NOT_PERSISTED。真实LIVE/账号/费用/PG/Windows/原生浏览器/人工语义/远端CI/部署NOT_RUN，整体NOT_ACCEPTED。\n")
print(json.dumps({'documentation_written':True,'frozen_source_sha':a['source_sha'],'source_changes':False}))
