"""Write explicit RC1 delivery documentation only after audited terminal results."""
from pathlib import Path
import hashlib,json
B=Path('/workspace/pb-source-archive-evidence-20261015'); R=Path('/workspace/Sim2Act-pa-provider')
def load(p):return json.loads(p.read_text())
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
a=load(B/'integration/fix-pb-cold/TERMINAL_AUDIT.json')
s=load(B/'regression/final-cold-pointer/FAILED_SUPPORTING_CHECKS.json')
assert a['returncode']==s['returncode']==1 and a['unique_ids']==389 and a['FAIL']+a['ERROR']>0
assert a['source_sha']==s['sha']=='056fb5a4796ba91cd5c2bcd12628bd06d2eae9ca'
assert a['xml_sha256']==s['xml_sha256'] and a['result_sha256']==h(B/'regression/final-cold-pointer/RESULT.json')
assert s['process_exit_sha256']==h(B/'regression/final-cold-pointer/PROCESS_EXIT.json')
assert s['xml_sha256']==h(B/'regression/final-cold-pointer/results.xml')
assert any(f['nodeid']=='tests/test_project_natural_revalidation.py::test_late_project_change_no_partial_save[peer_version]' and f['status']=='failure' for f in s['non_pass_cases'])
assert s['suite_outcome']=='FAIL' and s['overall_acceptance']=='NOT_ACCEPTED'
assert s['terminal_counts']=={k:a[v] for k,v in [('pass','PASS'),('failure','FAIL'),('error','ERROR'),('skipped','SKIP')]}
text=(B/'design/DELIVERY_056_DRAFT.md').read_text()
opening=f"**完整回归失败：{a['PASS']} PASS / {a['FAIL']} FAIL / {a['ERROR']} ERROR / {a['SKIP']} SKIP，389项全部执行，RC1。整体 NOT_ACCEPTED。** 本文交付有限离线实现与真实证据，剩余集成阻塞见下文。\n\n"
text=text.replace('\n\n基线 ', '\n\n'+opening+'基线 ',1)
text=text.replace('## 实际验证（终态待填）','## 实际验证')
old='056完整批389 = 新30边界 + 原359（包含20来源归档与原339），当前运行中，不称已PASS；终态依实际PROCESS_EXIT/XML/RESULT/499源码与独审。旧7c完整批358PASS/1FAIL/0ERROR/SKIP、359全部执行、RC1，6230.71秒，失败与新结果不拼合。原339及原359测试文件/顺序保留。'
assert old in text
new=f"056完整批 **{a['PASS']} PASS / {a['FAIL']} FAIL / {a['ERROR']} ERROR / {a['SKIP']} SKIP / 0 deselected**，389 unique，RC1，{a['elapsed_seconds']:.2f}秒。新30+原359精确顺序、原359测试字节保持（内含20来源归档与原339）；collection/XML逐项双射，无unnamed条目。499文件before/after/执行副本/root/Git相等；PROCESS_EXIT/RESULT退出码一致。XML SHA256 `{a['xml_sha256']}`，RESULT SHA256 `{a['result_sha256']}`。本批新30结果 `{s['new_30_boundary_counts']}`，新20结果 `{s['new_20_archive_counts']}`，不和旧探针累计。旧7c完整358PASS/1FAIL/0ERROR/SKIP、359项/RC1、6230.71秒的独立失败历史保留，不与本批拼接。"
text=text.replace(old,new).replace('完整056执行才覆盖最终字节','完整056批覆盖最终字节')
lines=['## 当前完整批失败与具体阻塞','']
for f in s['non_pass_cases']:
 lines.append(f"- `{f['nodeid']}`：{f['status']}。")
lines.extend(['','项目peer_version用例实际在发送前失败，sent=0，版本修改callback未执行，因此预期竞争未得到本批验证。零typed结果/既有两Release保持的前置断言通过，不称完整用例通过。既有公开观测：目标Run最后成功同步heartbeat续租后，下一次主heartbeat持续68.57454565004446秒并报Stale worker lease，目标后台3次SQLite code5。BEGIN等待时间、source_scope分段时间、失败Run最初deadline均NOT_RECORDED；不能把68秒归因于纯锁等待或CPU。相关流程源码虽与旧7c相同，旧批同例PASS不能替代本批FAIL，也不能据此排除本次变更的性能影响。','', '现有project.load_plan已有同连接/事务/write epoch范围缓存及授权重验；独立只读检查尚未找到可安全省略的完整项目权限/依赖证明。该心跳/租约集成失败仍未修复，具体瓶颈未知。未延长lease、跳过保护、跨写缓存或重启测试掩盖失败。精确公开日志时间线及缺失测量见integration/fix-pb-cold/PEER_VERSION_EXISTING_LOG_TIMELINE.json。',''])
for kind,v in s['chain_evidence_status'].items():
 chain=next((c for c in s['actual_synthetic_worker_chains'] if c['kind']==kind),None)
 if chain:
  lines.append(f"本批{kind}实际MOCK七槽用例PASS且回执完整：Generate3/Source2/Cold2，{chain['reserved_requests']}预约、全accepted/KNOWN、{chain['total_tokens']} tokens、envelope {chain['reserved_envelope']}、六gap最小{min(chain['reservation_gaps']):.6f}秒。仅该链的工程验证通过，完整389仍FAIL。")
 else:lines.append(f"本批{kind}节点状态 `{v['test_status']}`，回执 `{v['receipt']}`；无完整成功证明。")
u=s['ui_totals']; src=s['source_archive']
lines.extend(['',f"本批两次CHECK各1次领取并SUCCEEDED/fence1，Run300/lease30/maxclaims3保持。HTTP/JSDOM8例PASS：{u['checks']}检查、{u['actions']}操作、{u['requests']}请求、{u['assets']}资源、{u['boots']}启动，资源全200。第三个七槽用例仅原Store工程测试，节点状态 `{s['third_seven_slot_case']['test_status']}`。",'',f"本批来源正链再次5次Mock派发、19内部检查通过，四gap={src['reservation_gaps']}；独立新Store只读且全表hash不变，8项实际Worker故障回执逐一映射本批PASS节点。response事务写失败仍明确raw未持久化。全部指标取本批真实文件，无新probe。",'', '独立审查与原始失败日志见[证据索引](../evidence/pb-source-archive-20261015/README.md)。真实书生/Intern及其他真实模型API调用 **0**。',''])
text=text.replace('## 失败历史与边界','\n'.join(lines)+'\n## 失败历史与边界')
text=text.replace('## 失败历史与边界', '## 失败历史与边界\n\n终态独审曾将056输出误写至旧FINAL_7C_TERMINAL_CHECKS.json，覆盖前原hash未记录，不能证明原字节恢复。误写056副本单独保留；7c审查JSON依据封存7c结果/先前审查输出重建，显式RECONSTRUCTED_REVIEW_RECEIPT，非原件。纠正说明/实hash与重建副本均封存于review；原7c RESULT/XML/父audit/原审查MD、产品源码和测试未改。新056审查另存正确文件。')
(B/'design/DELIVERY_056_FINAL.md').write_text(text)
(R/'docs/F2/PBSourceArchive20261015.md').write_text(text)
d=R/'docs/evidence/pb-source-archive-20261015';d.mkdir(parents=True,exist_ok=True)
(d/'README.md').write_text(f"""# 原trial来源归档离线证据（完整回归FAIL）

冻结源码 `{a['source_sha']}`；完整389项结果 **{a['PASS']}PASS / {a['FAIL']}FAIL / {a['ERROR']}ERROR / {a['SKIP']}SKIP / 0 deselected，RC1**，整体NOT_ACCEPTED。精确失败及剩余阻塞见[交付说明](../../F2/PBSourceArchive20261015.md)。独立P-B链即使PASS也不构成整批通过。

5个归档实际字节/hash与成员清单见ARCHIVES.json和各MANIFEST；逐成员核验源集合、大小/hash、安全相对regular唯一路径。仅排除声明的cache、symlink/current别名及integration根PACKAGE_RESULT自引用。归档完整性通过不代表产品回归通过。

- tests：setup NOT_RUN、capture 7P1F/8P/11P、旧7c定向20P、pointer首15P/扩展29P1F/修正30P，以及各批执行源码/封印和初始静态失败，全部保留且不累计389。
- regression：旧7c完整358P1F/RC1与当前056完整389/RC1的命令、PROCESS_EXIT、collection、XML、streams、RESULT、FAILED_SUPPORTING_CHECKS、源码前后/副本和真实回执；两版质量结果保留。
- review：设计/代码/P2修复/85模块资格/历次终态/当前失败/失败感知脚本/最终文档独立审查。
- integration：两版终态audit与pin、7c transport恢复、056两次连接通知、peer_version公开日志时间线、执行/归档/正常push核验脚本。postpush回执另存工作区外部文件，避免自引用。
- design：原计划范围、旧7c失败、056最终说明；DRAFT为准备稿，不代替FINAL及RESULT。

独审输出曾误覆盖旧7c审查JSON，覆盖前原hash未知；误写056副本、明确标记的7c重建审查件及纠正哈希说明均保留，非字节恢复。原测试RESULT/XML/父audit未改，详见review/REVIEW_OUTPUT_NAME_CORRECTION_056.md。\n\n499源码before/after/copied/root/Git及30+原359顺序保持。当前汇总为FAILED_SUPPORTING_CHECKS.json；旧7c失败不覆盖。真实书生/Intern/API调用0；仅MockTransport实际Worker。PG/Windows/原生浏览器/人工语义/真实完整P-A/P-B/费用/远端CI/部署NOT_RUN，formal publication false。
""")
print(json.dumps({'documentation_written':True,'suite_outcome':'FAIL','frozen_source_sha':a['source_sha'],'source_changes':False}))
