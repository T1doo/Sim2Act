"""Read existing probe output and scalar SQLite status only; never Run bodies."""
import json
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, '/workspace/Sim2Act-pa-provider/src')
from sqlalchemy import create_engine, func, select
from sim2act.db import attempts, reservations, runs

base = Path('/workspace/pb-source-archive-evidence-20261015/tests/archive-first')
start = json.loads((base / 'START.json').read_text())
result = dict(utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
    pytest_pid=start['pid'], pid_exists=Path('/proc/' + str(start['pid'])).exists(),
    result_exists=(base / 'RESULT.json').exists(), stdout=(base / 'stdout').read_text()[-500:])
paths = [p for p in (base / 'tmp').glob('*/fixture.db') if not p.parent.is_symlink()]
paths = sorted(paths, key=lambda p: (not p.parent.name.startswith('test_actual_worker_to_cold_sto'), str(p)))
if paths:
    result['observed_fixture'] = paths[0].parent.name
    engine = create_engine('sqlite:///' + str(paths[0]), connect_args={'timeout': .1})
    try:
        with engine.connect() as c:
            result['run_status_counts'] = [list(r) for r in c.execute(
                select(runs.c.status, func.count()).group_by(runs.c.status))]
            result['attempt_status_counts'] = [list(r) for r in c.execute(
                select(attempts.c.status, func.count()).group_by(attempts.c.status))]
            result['reservation_count'], result['last_reserved_at'] = c.execute(
                select(func.count(), func.max(reservations.c.created_at))).one()
    finally:
        engine.dispose()
print(json.dumps(result))
Path('/workspace/pb-source-archive-evidence-20261015/integration/LAST_PROGRESS.json').write_text(
    json.dumps(result, indent=2) + '\n')
