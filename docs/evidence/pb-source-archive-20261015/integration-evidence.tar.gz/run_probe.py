"""Run an isolated offline probe and preserve its actual source and terminal."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
import xml.etree.ElementTree as ET

repo = Path('/workspace/Sim2Act-pa-provider')
base = Path('/workspace/pb-source-archive-evidence-20261015/tests')
parser = argparse.ArgumentParser()
parser.add_argument('name')
parser.add_argument('tests', nargs='+')
args = parser.parse_args()
assert args.name.replace('-', '').isalnum()
out = base / args.name
out.mkdir(exist_ok=False)

def write(name, value):
    (out / name).write_text(json.dumps(value, indent=2) + '\n')

def manifest():
    files = [repo / 'pyproject.toml']
    for directory in ('src', 'tests'):
        files.extend(p for p in (repo / directory).rglob('*') if p.is_file()
                     and not p.is_symlink() and '__pycache__' not in p.parts)
    return {str(p.relative_to(repo)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}

before = manifest()
write('source-before.json', before)
for name in before:
    target = out / 'executed-source' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(repo / name, target)
env = {k: os.environ[k] for k in ('PATH', 'LANG', 'LC_ALL', 'TZ') if k in os.environ}
env.update(PYTHONPATH=str(repo / 'src') + ':' + str(repo / 'tests'),
           PYTHONDONTWRITEBYTECODE='1', NODE_PATH='/workspace/node-tools/node_modules')
argv = ['/workspace/Sim2Act/.venv/bin/python', '-m', 'pytest', '-q', '-p', 'no:cacheprovider',
        *args.tests, '--basetemp=' + str(out / 'tmp'), '--junitxml=' + str(out / 'results.xml')]
write('COMMAND.json', dict(argv=argv, cwd=str(repo), inherited_database_url=False))
started = time.time()
with (out / 'stdout').open('wb') as stdout, (out / 'stderr').open('wb') as stderr:
    process = subprocess.Popen(argv, cwd=repo, env=env, stdout=stdout, stderr=stderr)
    write('START.json', dict(pid=process.pid, started=started))
    code = process.wait()
write('PROCESS_EXIT.json', dict(returncode=code, finished=time.time()))
after = manifest()
write('source-after.json', after)
cases = list(ET.parse(out / 'results.xml').getroot().iter('testcase'))
counts = dict(PASS=0, FAIL=0, ERROR=0, SKIP=0)
for case in cases:
    counts['FAIL' if case.find('failure') is not None else 'ERROR' if case.find('error') is not None
           else 'SKIP' if case.find('skipped') is not None else 'PASS'] += 1
result = dict(returncode=code, counts=counts, elapsed_seconds=time.time() - started,
              source_files=len(before), source_unchanged=before == after,
              git_head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
              git_status=subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True),
              xml_sha256=hashlib.sha256((out / 'results.xml').read_bytes()).hexdigest())
write('RESULT.json', result)
print(json.dumps(result), flush=True)
raise SystemExit(code if before == after else 3)
