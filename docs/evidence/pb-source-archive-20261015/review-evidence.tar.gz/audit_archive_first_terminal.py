import hashlib,json,pathlib,subprocess,xml.etree.ElementTree as ET
root=pathlib.Path('/workspace/Sim2Act-pa-provider'); ev=pathlib.Path('/workspace/pb-source-archive-evidence-20261015'); batch=ev/'tests/archive-first'; out=ev/'review'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(root),*args])
before=json.loads((batch/'source-before.json').read_text());after=json.loads((batch/'source-after.json').read_text());assert before==after and len(before)==498
assert all(sha(root/k)==v and sha(batch/'executed-source'/k)==v for k,v in before.items())
proc=subprocess.Popen(['git','-C',str(root),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for k,v in before.items():
 proc.stdin.write(('7c6b89aa507580549509d159c69063031509673c:'+k+'\n').encode());proc.stdin.flush()
 header=proc.stdout.readline().split(); size=int(header[2]); body=proc.stdout.read(size);assert proc.stdout.read(1)==b'\n';assert hashlib.sha256(body).hexdigest()==v,k
proc.stdin.close();assert proc.wait()==0
head=git('rev-parse','HEAD').decode().strip();status=git('status','--porcelain').decode();assert head=='7c6b89aa507580549509d159c69063031509673c' and not status
xml=ET.parse(batch/'results.xml');cases=list(xml.iter('testcase'));assert len(cases)==20
ids=[(c.attrib['classname'],c.attrib['name']) for c in cases];assert len(set(ids))==20
assert not any(c.find(t) is not None for c in cases for t in ('failure','error','skipped'))
assert sum('source_capture' in c.attrib['classname'] for c in cases)==11
assert sum('actual_worker_to_cold' in c.attrib['name'] for c in cases)==1
faults=['invalid_json','empty','oversize','network_prefix','cancel','revoked','request_write_failure','response_write_failure']
assert all(sum(c.attrib['name'].endswith('['+f+']') for c in cases)==1 for f in faults)
result=json.loads((batch/'RESULT.json').read_text());exit=json.loads((batch/'PROCESS_EXIT.json').read_text());assert result['returncode']==exit['returncode']==0
assert result['xml_sha256']==sha(batch/'results.xml')=='b60a99ba49916be9041db4fc8c0c2814eab663c02bc2b7f8f13c8b1ef740776f'
receipts=[]
for f in sorted((batch/'tmp').glob('test_received*/*.json')):
 if f.parent.is_symlink():continue
 data=json.loads(f.read_text());receipts.append({'path':str(f.relative_to(batch)), 'sha256':sha(f),'receipt':data})
assert len(receipts)==8
for r in receipts:
 d=r['receipt']
 if 'fault' in d:assert d['actual_sends']==1 and d['preserved_reservation'] and d['new_typed_results']==0
 elif 'no_attempt' in d: assert d==dict(no_attempt=True,no_reservation=True,no_archive=True,actual_sends=0)
 else:assert d['response_transaction_rolled_back'] and d['state']=='UNKNOWN' and d['raw_receipt']=='NOT_PERSISTED_IN_EXPLICIT_WRITE_FAILURE'
checks=json.loads((out/'QUALIFICATION_7C_CHECKS.json').read_text());checks.update(author20_full_terminal={'counts':result['counts'],'returncode':0,'elapsed_seconds':result['elapsed_seconds'],'unique_cases':20,'capture_cases':11,'actual_vertical_cases':1,'worker_fault_cases':8,'source_498_before_after_copied_root_git_closed':True,'root_clean':True,'xml_sha256':sha(batch/'results.xml'),'result_sha256':sha(batch/'RESULT.json'),'process_exit_sha256':sha(batch/'PROCESS_EXIT.json'),'receipts':receipts},new_full359='NOT_RUN_AT_REVIEW')
(out/'QUALIFICATION_7C_CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps({'cases':20,'source_closed':498,'fault_receipts':8,'head':head,'clean':not status}))
