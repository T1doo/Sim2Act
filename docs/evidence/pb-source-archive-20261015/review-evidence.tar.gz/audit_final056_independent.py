from pathlib import Path
import hashlib,json,subprocess,xml.etree.ElementTree as ET,collections,ast
b=Path('/workspace/pb-source-archive-evidence-20261015');f=b/'regression/final-cold-pointer';root=Path('/workspace/Sim2Act-pa-provider');sha='056fb5a4796ba91cd5c2bcd12628bd06d2eae9ca'
def load(p):return json.loads(p.read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(root),*args])
r=load(f/'RESULT.json');c=load(f/'COLLECTION.json');cmd=load(f/'COMMAND.json');exit=load(f/'PROCESS_EXIT.json')
assert r['sha']==cmd['sha']==sha and c['returncode']==0 and r['returncode']==exit['pytest_returncode']==1 and not r['unnamed_xml_entries']
cases=list(ET.parse(f/'results.xml').iter('testcase'));ids=[x.get('classname').replace('.','/')+'.py::'+x.get('name') for x in cases];counts=collections.Counter(next((z.tag for z in x if z.tag in ('failure','error','skipped')),'pass') for x in cases)
assert len(ids)==len(set(ids))==389 and collections.Counter(ids)==collections.Counter(c['nodeids'])
assert counts=={'pass':388,'failure':1} and r['counts']==dict(zip(('pass','failure','error','skipped'),(388,1,0,0)))
failed=[ids[i] for i,x in enumerate(cases) if x.find('failure') is not None];assert failed==['tests/test_project_natural_revalidation.py::test_late_project_change_no_partial_save[peer_version]']
old=load(Path('/workspace/production-admission-evidence-20261015/regression/final206/COLLECTION.json'))['nodeids'];assert len(old)==339 and c['nodeids'][50:]==old
previous=load(b/'regression/final7c/COLLECTION.json')['nodeids'];assert len(previous)==359 and c['nodeids'][30:]==previous
assert all(n.startswith('tests/test_pb_cold_bound_pointer.py::') for n in c['nodeids'][:30])
assert next(x for x in r['testcases'] if x['id']=='tests.test_pb_trial_admission::test_pb_exact_same_trial_source_extraction_and_cold_seven_slots')['status']=='pass'
baseline=load(Path('/workspace/complete-regression-evidence-20261015/final0b6a/COLLECTION.json'))['nodeids'];assert len(baseline)==199 and set(baseline)<=set(ids)
before=load(f/'source-before.json');assert before==load(f/'source-after.json')==load(f/'executed-source-manifest.json') and len(before)==499
paths={str(p.relative_to(root)) for folder in ('src','tests') for p in (root/folder).rglob('*') if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts}|{'pyproject.toml'};assert paths==set(before)
assert all(digest(root/k)==digest(f/'executed-source'/k)==v for k,v in before.items())
proc=subprocess.Popen(['git','-C',str(root),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
def blob(ref,path):
 proc.stdin.write((ref+':'+path+'\n').encode());proc.stdin.flush();header=proc.stdout.readline().split();raw=proc.stdout.read(int(header[2]));assert proc.stdout.read(1)==b'\n';return raw
for k,v in before.items():assert hashlib.sha256(blob(sha,k)).hexdigest()==v
for k in {n.split('::')[0] for n in old}:assert hashlib.sha256(blob('fd0ac2198986f201e05924104e7f7a7bb0908769',k)).hexdigest()==before[k]
files={n.split('::')[0] for n in baseline};assert len(files)==15
for k in files:
 raw=blob('255b6ac407ebad31aedbe1b8d9547ee3892cdc0f',k)
 if k!='tests/test_natural_trial_budget.py':assert hashlib.sha256(raw).hexdigest()==before[k];continue
 assert hashlib.sha256(raw).hexdigest()=='6694714986db64e73a8487aac1a128026717ada8abe6963ce08b8876c4876468' and before[k]=='b821b3b8ed58d72c4779800d1e81f99668213abf475e6d7c76a1bb5fae5c8692'
 trees=[ast.parse(raw),ast.parse((root/k).read_bytes())];target='test_seven_actual_reservations_stage_binding_nontransfer_no_refund';fns=[next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name==target) for t in trees]
 assert [ast.dump(n,include_attributes=False) for n in trees[0].body if n is not fns[0]]==[ast.dump(n,include_attributes=False) for n in trees[1].body if n is not fns[1]]
 ac=[collections.Counter(ast.dump(n,include_attributes=False) for n in ast.walk(fn) if isinstance(n,ast.Assert)) for fn in fns];assert ac[0]<=ac[1]
proc.stdin.close();assert proc.wait()==0
assert git('rev-parse','HEAD').decode().strip()==sha and not git('status','--porcelain')
for k,name in [('xml_sha256','results.xml'),('stdout_sha256','stdout.log'),('stderr_sha256','stderr.log')]:assert r[k]==digest(f/name)
a=load(b/'integration/fix-pb-cold/TERMINAL_AUDIT.json');assert a['PASS']==388 and a['FAIL']==1 and a['xml_sha256']==digest(f/'results.xml') and a['result_sha256']==digest(f/'RESULT.json')
out={'sha':sha,'actual_counts':r['counts'],'pytest_returncode':1,'unique_cases':389,'complete':True,'new30_plus_original359_exact_suffix_order':True,'baseline199_ids_retained':True,'original339_files_byte_exact_fd0':True,'baseline15files_14exact_one_precise_cleanup_and_all_asserts_retained':True,'source499_before_after_copied_currentroot_git_closed':True,'root_clean_at_review':True,'failed_ids':failed,'xml_sha256':digest(f/'results.xml'),'result_sha256':digest(f/'RESULT.json'),'elapsed_seconds':r['elapsed'],'quality':'Ruff/Node PASS; mypy RC1 original5/new0 as previously independently reviewed','transport':'Original056 session resumed to actual RC1; no restart/cwd read','batch_verdict':'FAIL_NOT_UPGRADED_TO_GREEN','tests_or_diagnostics_run_by_reviewer':False}
(b/'review/FINAL_056_TERMINAL_CHECKS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
