from pathlib import Path
import ast,json,re,hashlib,subprocess
b=Path('/workspace/pb-source-archive-evidence-20261015');root=Path('/workspace/Sim2Act-pa-provider');src=root/'src/sim2act';sha='056fb5a4796ba91cd5c2bcd12628bd06d2eae9ca';candidate='259d666da7a230da1749efb9a1d63d8a16271d65'
def dig(raw):return hashlib.sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(root),*args])
proof=json.loads((src/'text_software_qualification.json').read_text());oldproof=json.loads(git('show','7c6b89aa507580549509d159c69063031509673c:src/sim2act/text_software_qualification.json'));code=(src/'text_continuations.py').read_bytes();tree=ast.parse(code)
assert proof['review_candidate']==candidate
pin=dig((src/'text_software_qualification.json').read_bytes());assert pin=='eeb3d4445db81d648612d976d91605aca1f4205a5a6ee13d5aa5c9e35af7ec83'
assign=[n for n in ast.walk(tree) if isinstance(n,ast.Name) and isinstance(n.ctx,ast.Store) and n.id=='QUALIFICATION_HASH'];assert len(assign)==1
norm,n=re.subn(rb'^QUALIFICATION_HASH = "[a-f0-9]{64}"$',b'QUALIFICATION_HASH = "'+b'0'*64+b'"',code,flags=re.M);assert n==1 and ('QUALIFICATION_HASH = "'+pin+'"').encode() in code
files={p.name:dig(norm if p.name=='text_continuations.py' else p.read_bytes()) for p in src.glob('*.py') if p.name!='config.py'};assert len(files)==85 and files==proof['files']
for k in oldproof:
 if k not in ('review_candidate','files'):assert oldproof[k]==proof[k]
oldcode=git('show','7c6b89aa507580549509d159c69063031509673c:src/sim2act/text_continuations.py');oldt=ast.parse(oldcode)
for name in ('ANCHOR_HASH','CHANGED'):
 def val(t):return ast.dump(next(x for x in t.body if isinstance(x,ast.Assign) and any(isinstance(y,ast.Name) and y.id==name for y in x.targets)),include_attributes=False)
 assert val(oldt)==val(tree)
assert git('diff','--name-only',candidate,sha).decode().splitlines()==['src/sim2act/text_continuations.py','src/sim2act/text_software_qualification.json']
assert git('diff','--name-only','7c6b89aa507580549509d159c69063031509673c',candidate).decode().splitlines()==['src/sim2act/natural_live_admission.py','tests/test_pb_cold_bound_pointer.py']
paths=[root/'pyproject.toml']+[p for folder in ('src','tests') for p in (root/folder).rglob('*') if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts];assert len(paths)==499
other=Path('/workspace/Sim2Act-complete-regression');assert all(p.read_bytes()==(other/p.relative_to(root)).read_bytes() for p in paths)
for repo in (root,other):assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==sha and not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True)
q=b/'regression/quality-cold-pointer';r=json.loads((q/'RESULT.json').read_text());assert r['sha']==sha
for name,c in r['commands'].items():
 assert c['returncode']==(1 if name=='mypy' else 0)
 for stream in ('stdout','stderr'):assert dig((q/(name+'.'+stream)).read_bytes())==c[stream+'_sha256']
errs=[x for x in (q/'mypy.stdout').read_text().splitlines() if ': error:' in x];old=[x for x in Path('/workspace/project-reliability-gates-evidence-20261015/author/mypy-typed.stdout').read_text().splitlines() if ': error:' in x];assert errs==old==r['mypy_errors'] and len(errs)==5 and not r['mypy_new_errors'];assert len(r['changed_python'])==10
out={'sha':sha,'candidate':candidate,'pin':pin,'exact_85_manifest_and_literal_verified':True,'ANCHOR_CHANGED_exclusion_normalization_baseline_sources_unchanged':True,'candidate_to_seal_only_2_qualification_files':True,'7c_to_candidate_only_product_pointer_and_test':True,'499_two_trees_bytes_equal_and_clean':True,'quality':{'fullsrc_ruff':0,'changed10_ruff':0,'Node2':[0,0],'mypy_rc':1,'mypy_source_count':86,'original_errors':5,'new_errors':0,'stream_hashes_verified':True},'test30':'18metadata +11 isolated dispatch +1 revision handoff; no new test execution by reviewer','full389':'NOT_RUN_AT_REVIEW','7c_previous':'358PASS1FAIL_RC1_RETAINED'}
(b/'review/QUALIFICATION_056_CHECKS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
