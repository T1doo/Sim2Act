"""One bounded integration observation of public boundaries; no new SQL or bodies.

Nested spans overlap. BEGIN duration includes driver execution/wait; an acquired
transaction body is not CPU time or exact SQLite lock-release instrumentation.
Every original callable/context manager is invoked once with original arguments.
"""
import functools
import itertools
import json
import os
import threading
import time
from contextlib import contextmanager
from pathlib import Path

LIMIT = 20000
LOCK = threading.Lock()
LOCAL = threading.local()
COUNTER = itertools.count(1)
RECORDS = []
DROPPED = 0
BEGIN = {}
COUNTS = {}
WRAPPED = []
PATCHES = []
LISTENERS = []


def new_id():
    with LOCK:
        return next(COUNTER)


def tx_id():
    stack = getattr(LOCAL, 'transactions', ())
    return stack[-1] if stack else None


def emit(kind, **public):
    global DROPPED
    item = dict(kind=kind, monotonic_ns=time.perf_counter_ns(),
        wall_time=time.time(), thread=threading.get_ident(), tx=tx_id(), **public)
    with LOCK:
        COUNTS[kind] = COUNTS.get(kind, 0) + 1
        if len(RECORDS) < LIMIT:
            RECORDS.append(item)
        else:
            DROPPED += 1


def error_public(error):
    from sim2act.errors import DomainError
    if isinstance(error, DomainError):
        return dict(type=type(error).__name__, public=error.public())
    return dict(type=type(error).__name__)


def fields(name, args, kwargs):
    # Identifiers already passed to public functions; no source/context/params/body.
    try:
        if name in ('Store.guard', 'Store.heartbeat'):
            rid = args[2] if len(args) > 2 else kwargs.get('run_id')
            return dict(run_id=rid) if isinstance(rid, str) else {}
        if name == 'Worker.process':
            return dict(run_id=args[1]['id'])
        if name in ('pa_spec_apps.bound',):
            return dict(run_id=args[3]['id'])
        if name == 'pa_spec_apps.commit_guard':
            return dict(run_id=args[2]['id'])
        if name == 'natural_live_admission.admit':
            stage = args[5] if len(args) > 5 else kwargs.get('stage')
            rid = args[6] if len(args) > 6 else kwargs.get('run_id')
            return dict(run_id=rid, stage=stage if stage in ('generate','source','cold') else 'other')
        if name == 'pb_natural_specs.source':
            return dict(source_run_id=args[4])
        if name == 'pa_trial_dispatch.extract_pb':
            return dict(source_run_id=args[2])
    except (IndexError, KeyError, TypeError):
        return dict(identifier='UNAVAILABLE')
    return {}


def wrap(owner, attribute, name):
    original = getattr(owner, attribute)
    @functools.wraps(original)
    def call(*args, **kwargs):
        span = new_id()
        public = fields(name, args, kwargs)
        emit('CALL_ENTER', span=span, function=name, **public)
        try:
            result = original(*args, **kwargs)
        except BaseException as error:
            emit('CALL_ERROR', span=span, function=name, error=error_public(error), **public)
            raise
        else:
            emit('CALL_EXIT', span=span, function=name, **public)
            return result
    PATCHES.append((owner, attribute, original))
    setattr(owner, attribute, call)
    WRAPPED.append(name)


def pytest_configure(config):
    from sqlalchemy import event
    from sqlalchemy.engine import Engine
    from sim2act import natural_live_admission, pa_spec_apps
    from sim2act import pa_trial_dispatch, pb_natural_specs
    from sim2act.db import Store
    from sim2act.worker import Worker

    original_tx = Store.tx
    @contextmanager
    @functools.wraps(original_tx)
    def observed_tx(self, *args, **kwargs):
        identifier = new_id()
        stack = getattr(LOCAL, 'transactions', None)
        if stack is None:
            stack = []
            LOCAL.transactions = stack
        stack.append(identifier)
        acquired = False
        body_ended = False
        emit('TX_REQUEST', store=id(self))
        try:
            with original_tx(self, *args, **kwargs) as connection:
                acquired = True
                emit('TX_ACQUIRED', store=id(self), connection=id(connection))
                try:
                    yield connection
                finally:
                    body_ended = True
                    emit('TX_BODY_END', store=id(self), connection=id(connection))
        except BaseException as error:
            emit('TX_ERROR', store=id(self), error=error_public(error), acquired=acquired)
            raise
        finally:
            emit('TX_EXIT', store=id(self), acquired=acquired, body_ended=body_ended)
            popped = stack.pop() if stack else None
            if popped != identifier:
                emit('OBSERVER_STACK_MISMATCH', expected=identifier, actual=popped)
    PATCHES.append((Store, "tx", original_tx))
    Store.tx = observed_tx
    WRAPPED.append('Store.tx')

    def begin_before(connection, cursor, statement, parameters, context, executemany):
        if connection.engine.dialect.name == 'sqlite' and statement.strip().upper() == 'BEGIN IMMEDIATE':
            span = new_id()
            with LOCK:
                BEGIN[id(context)] = span
            emit('BEGIN_ENTER', span=span, connection=id(connection))

    def begin_after(connection, cursor, statement, parameters, context, executemany):
        if statement.strip().upper() == 'BEGIN IMMEDIATE':
            with LOCK:
                span = BEGIN.pop(id(context), None)
            if span is not None:
                emit('BEGIN_EXIT', span=span, connection=id(connection))

    def begin_error(context):
        if context.statement and context.statement.strip().upper() == 'BEGIN IMMEDIATE':
            with LOCK:
                span = BEGIN.pop(id(context.execution_context), None)
            if span is not None:
                emit('BEGIN_ERROR', span=span, connection=id(context.connection),
                    error_type=type(context.original_exception).__name__,
                    sqlite_errorname=getattr(context.original_exception, 'sqlite_errorname', None))
        # Preserve the original SQLAlchemy exception behavior.

    for name, callback in [('before_cursor_execute', begin_before),
                           ('after_cursor_execute', begin_after), ('handle_error', begin_error)]:
        event.listen(Engine, name, callback)
        LISTENERS.append((Engine, name, callback))
    for owner, attr, name in [
        (Store,'guard','Store.guard'),
        (Store,'heartbeat','Store.heartbeat'),
        (Worker,'process','Worker.process'),
        (pa_spec_apps,'bound','pa_spec_apps.bound'),
        (pa_spec_apps,'commit_guard','pa_spec_apps.commit_guard'),
        (natural_live_admission,'admit','natural_live_admission.admit'),
        (pb_natural_specs,'source','pb_natural_specs.source'),
        (pa_trial_dispatch,'extract_pb','pa_trial_dispatch.extract_pb'),
    ]:
        wrap(owner, attr, name)


def pytest_sessionfinish(session, exitstatus):
    target = Path(os.environ['PB_IMPORT_RECEIPT']).parent / 'PUBLIC_SEGMENTS.json'
    with LOCK:
        value = dict(policy='PUBLIC_BOUNDARIES_ONLY_NO_NEW_SQL_PARAMETERS_OR_BODIES',
            interpretation='Nested spans overlap; BEGIN is driver duration/wait; acquired body is not CPU or precise lock-release duration',
            cap=LIMIT, dropped=DROPPED, counts=dict(COUNTS), records=list(RECORDS),
            pending_begin_spans=list(BEGIN.values()), wrapped=list(WRAPPED),
            pytest_exitstatus=int(exitstatus))
    target.write_text(json.dumps(value, indent=2)+'\n')


def pytest_unconfigure(config):
    from sqlalchemy import event
    for owner, name, callback in reversed(LISTENERS):
        event.remove(owner, name, callback)
    for owner, name, original in reversed(PATCHES):
        setattr(owner, name, original)
    path = Path(os.environ['PB_IMPORT_RECEIPT']).parent / 'PUBLIC_OBSERVER_CLEANUP.json'
    path.write_text(json.dumps(dict(listeners_removed=len(LISTENERS),
        original_callables_restored=len(PATCHES)), indent=2)+'\n')
