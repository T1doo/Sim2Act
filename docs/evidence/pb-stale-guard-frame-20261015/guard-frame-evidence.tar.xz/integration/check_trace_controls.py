"""Synthetic test-wrapper transparency/schema checks only; no Worker, SQL or clock calls."""
import ast
import hashlib
import json
from pathlib import Path

from sqlalchemy.engine import RowMapping

from sim2act.db import Store
from sim2act.errors import DomainError

R = Path('/workspace/Sim2Act-pa-provider')
B = Path('/workspace/pb-stale-guard-frame-evidence-20261015')
p = R / 'tests/test_pb_trial_dispatch.py'
tree = ast.parse(p.read_text())
helper = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'failure_trace')
namespace = dict(Store=Store, RowMapping=RowMapping)
exec(compile(ast.fix_missing_locations(ast.Module(body=[helper], type_ignores=[])), str(p), 'exec'), namespace)

class BrokenDiagnostic:
    @property
    def __traceback__(self):
        raise RuntimeError('Synthetic capture failure; text must not be retained')

    def public(self):
        return {'code': 'SYNTHETIC_CONTROL_ONLY'}


def original_error():
    unapproved_local = 'SYNTHETIC_DO_NOT_DUMP'
    try:
        raise DomainError('SYNTHETIC_CONTROL_ONLY')
    except DomainError as error:
        return error

records = []
for wrapper_name in ('failure', 'source_failure'):
    wrapper = next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == wrapper_name)
    for capture_failure in (False, True):
        for original_raises in (False, True):
            calls = []
            worker, run, sentinel = object(), object(), object()
            error = BrokenDiagnostic() if capture_failure else original_error()
            raised = DomainError('SYNTHETIC_ORIGINAL_HANDLER')

            def original_failure(*args):
                calls.append(args)
                if original_raises:
                    raise raised
                return sentinel

            env = dict(namespace, original_failure=original_failure,
                public_errors=[], failure_traces=[], source_public_errors=[], source_failure_traces=[])
            exec(compile(ast.fix_missing_locations(ast.Module(body=[wrapper], type_ignores=[])), str(p), 'exec'), env)
            caught = None
            result = None
            try:
                result = env[wrapper_name](worker, run, error)
            except DomainError as escaped:
                caught = escaped
            assert len(calls) == 1 and all(a is b for a, b in zip(calls[0], (worker, run, error), strict=True))
            assert caught is raised if original_raises else result is sentinel and caught is None
            trace = env['failure_traces' if wrapper_name == 'failure' else 'source_failure_traces'][0]
            assert set(trace) == {'frames', 'store_guard_values'}
            assert 'SYNTHETIC_DO_NOT_DUMP' not in json.dumps(trace)
            if capture_failure:
                assert trace == dict(frames='Unknown', store_guard_values='Unknown')
            else:
                assert trace['store_guard_values'] == []
                assert trace['frames'] and all(set(f) == {'file', 'function', 'line'} for f in trace['frames'])
            records.append(dict(wrapper=wrapper_name, synthetic_capture_failure=capture_failure,
                original_handler_raises=original_raises, original_calls=1,
                original_arguments_identity_preserved=True, return_or_exception_identity_preserved=True,
                limited_schema_and_no_local_dump=True, passed=True))
x = dict(scope='Synthetic wrapper forwarding and non-Store trace only, not Worker acceptance or Store.guard predicate coverage',
    source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(), pass_count=len(records), records=records)
(B / 'CONTROL_RESULT.json').write_text(json.dumps(x, indent=2) + '\n')
print(json.dumps(x))
