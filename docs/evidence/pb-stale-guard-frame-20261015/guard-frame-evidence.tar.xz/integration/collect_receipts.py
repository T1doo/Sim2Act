"""Copy only completed packed public boundary JSON, never query fixture databases."""
import json
import tarfile
from pathlib import Path

B = Path('/workspace/pb-stale-guard-frame-evidence-20261015')
out = B / 'public'
out.mkdir(exist_ok=True)
receipts, stale = {}, []
for batch in sorted((B / 'observation').iterdir()):
    archive = batch / 'fixtures.tar.gz'
    if not archive.exists() or not (batch / 'PROCESS_EXIT.json').exists():
        continue
    with tarfile.open(archive, 'r:gz') as tar:
        for member in tar.getmembers():
            if not member.isfile() or Path(member.name).name not in ('actual-dispatch-boundary.json', 'actual-source-dispatch-boundary.json'):
                continue
            value = json.loads(tar.extractfile(member).read())
            key = batch.name + '/' + member.name
            receipts[key] = value
            traces = value.get('worker_failure_traces', [])
            for trace in traces:
                assert set(trace) == {'frames', 'store_guard_values'}
                if isinstance(trace['frames'], list):
                    assert all(set(f) == {'file', 'function', 'line'} for f in trace['frames'])
                if isinstance(trace['store_guard_values'], list):
                    for guard in trace['store_guard_values']:
                        assert set(guard) == {'frame_index', 'expected_fence', 'row_fence', 'lease_until', 'status', 'original_comparison_time'}
                        assert guard['original_comparison_time'] == 'Unknown'
            for index, error in enumerate(value.get('worker_public_errors', [])):
                if error.get('code') == 'VERSION_CONFLICT' and error.get('message') == 'Stale worker lease':
                    stale.append(dict(receipt=key, error=error, trace=traces[index] if index < len(traces) else 'Unknown'))
(out / 'ACTUAL_PUBLIC_BOUNDARIES.json').write_text(json.dumps(receipts, indent=2) + '\n')
(out / 'STALE_OCCURRENCES.json').write_text(json.dumps(dict(occurrences=stale,
    count=len(stale), original_comparison_time='Unknown', no_capture_time_substitution=True), indent=2) + '\n')
print(json.dumps(dict(completed_public_receipts=len(receipts), stale_occurrences=len(stale))))
