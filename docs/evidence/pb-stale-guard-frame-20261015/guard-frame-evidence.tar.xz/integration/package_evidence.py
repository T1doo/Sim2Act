"""Seal every regular evidence file; verify archived and retained bytes."""
import hashlib
import json
import tarfile
from pathlib import Path

B = Path('/workspace/pb-stale-guard-frame-evidence-20261015')
OUT = Path('/workspace/Sim2Act-pa-provider/docs/evidence/pb-stale-guard-frame-20261015')
OUT.mkdir(parents=True, exist_ok=False)
files = sorted(p for p in B.rglob('*') if p.is_file() and not p.is_symlink())
manifest = {str(p.relative_to(B)): dict(bytes=p.stat().st_size,
    sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files}
(OUT / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
archive = OUT / 'guard-frame-evidence.tar.xz'
with tarfile.open(archive, 'w:xz', preset=9) as tar:
    for p in files:
        tar.add(p, arcname=str(p.relative_to(B)), recursive=False)
with tarfile.open(archive, 'r:xz') as tar:
    assert len(tar.getmembers()) == len(manifest)
    for member in tar.getmembers():
        assert member.isfile() and member.name in manifest
        data = tar.extractfile(member).read()
        record = manifest[member.name]
        assert len(data) == record['bytes']
        assert hashlib.sha256(data).hexdigest() == record['sha256']
assert set(manifest) == {str(p.relative_to(B)) for p in B.rglob('*') if p.is_file() and not p.is_symlink()}
assert all(hashlib.sha256((B / n).read_bytes()).hexdigest() == v['sha256'] for n, v in manifest.items())
receipt = dict(file=archive.name, bytes=archive.stat().st_size,
    sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), members=len(manifest),
    all_members_readback=True, status='NOT_ACCEPTED', production_changes=False,
    baseline_sha='a85382341fa9b2e83455c31380a5a7eaaeedc896',
    tested_sha='53367c8ec3c70f645e6fd1445a2ae345a012617c')
(OUT / 'ARCHIVE.json').write_text(json.dumps(receipt, indent=2) + '\n')
# Explicit parent-review copies, in addition to the complete archive.
public = OUT / 'public'
public.mkdir()
for p in sorted((B / 'public').iterdir()):
    if p.is_file():
        (public / p.name).write_bytes(p.read_bytes())
print(json.dumps(receipt))
