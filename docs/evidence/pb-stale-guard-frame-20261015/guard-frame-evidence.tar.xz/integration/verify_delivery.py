"""Post-push exact-ref, frozen-byte and unrelated-WIP validation; output stays outside B."""
import hashlib
import json
import subprocess
import tarfile
from pathlib import Path

R = Path('/workspace/Sim2Act-pa-provider')
B = Path('/workspace/pb-stale-guard-frame-evidence-20261015')
BASE = 'a85382341fa9b2e83455c31380a5a7eaaeedc896'
TESTED = '53367c8ec3c70f645e6fd1445a2ae345a012617c'
BRANCH = 'dev/pb-stale-guard-frame-20261015'
PROTECTED = json.loads(Path('/workspace/pb-cold-finally-diagnostics-final-verification-20261015.json').read_text())['remote']

def git(*args, cwd=R):
    return subprocess.check_output(['git', *args], cwd=cwd, text=True).strip()

def h(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

head = git('rev-parse', 'HEAD')
assert git('branch', '--show-current') == BRANCH
refs = ['refs/heads/' + BRANCH, *PROTECTED]
remote = dict(line.split('\t')[::-1] for line in git('ls-remote', 'origin', *refs).splitlines())
assert remote['refs/heads/' + BRANCH] == head
assert all(remote[n] == value for n, value in PROTECTED.items())
assert len(PROTECTED) == 18
assert not git('status', '--porcelain')
assert git('rev-list', '--left-right', '--count', 'HEAD...refs/remotes/origin/' + BRANCH) == '0\t0'
assert not git('diff', '--name-only', BASE, 'HEAD', '--', 'src', 'pyproject.toml')
assert not git('diff', '--name-only', TESTED, 'HEAD', '--', 'src', 'tests', 'pyproject.toml')
assert git('diff', '--name-only', BASE, 'HEAD', '--', 'tests') == 'tests/test_pb_trial_dispatch.py'
changed_docs = git('diff', '--name-only', BASE, 'HEAD', '--', 'docs').splitlines()
assert all(n == 'docs/F2/PBStaleGuardFrame20261015.md' or n.startswith('docs/evidence/pb-stale-guard-frame-20261015/') for n in changed_docs)
for sha in [BASE, 'bb04afc3d42c0565ffe9adf1d076ef7af182ab95', '3e890e329332d434e8f3aa245cb15f905bb41455', '6f688e4dd80b5c81d41aecde90e360d3629f9c21']:
    subprocess.run(['git', 'merge-base', '--is-ancestor', sha, head], cwd=R, check=True)
old = Path('/workspace/Sim2Act')
assert git('rev-parse', 'HEAD', cwd=old) == 'a4fd476127a477006dbdb29a9a1f6c2f09e6a001'
for name, value in json.loads((B / 'BASELINE.json').read_text())['other_wip'].items():
    assert h(old / name) == value
out = R / 'docs/evidence/pb-stale-guard-frame-20261015'
archive = json.loads((out / 'ARCHIVE.json').read_text())
manifest = json.loads((out / 'MANIFEST.json').read_text())
assert set(manifest) == {str(p.relative_to(B)) for p in B.rglob('*') if p.is_file() and not p.is_symlink()}
assert h(out / archive['file']) == archive['sha256']
with tarfile.open(out / archive['file'], 'r:xz') as tar:
    assert len(tar.getmembers()) == len(manifest)
    for member in tar.getmembers():
        assert member.isfile() and member.name in manifest
        data = tar.extractfile(member).read()
        record = manifest[member.name]
        assert len(data) == record['bytes']
        assert hashlib.sha256(data).hexdigest() == record['sha256'] == h(B / member.name)
for p in (B / 'public').iterdir():
    if p.is_file():
        assert h(p) == h(out / 'public' / p.name)
batches = {p.parent.name: json.loads(p.read_text()) for p in sorted((B / 'observation').glob('*/RESULT.json'))}
x = dict(status='NOT_ACCEPTED', final_sha=head, branch=BRANCH, tested_sha=TESTED,
    base_sha=BASE, remote=remote, protected_refs_unchanged=True, protected_ref_count=len(PROTECTED),
    clean=True, ahead_behind='0/0', production_diff=[], final_vs_tested_diff=[],
    old_evidence_unchanged=True, unrelated_wip_unchanged=True,
    unrelated_wip_status=git('status', '--porcelain', cwd=old), archive=archive,
    batches=batches, real_model_paid_calls=0, live=False, remote_ci='NOT_RUN')
Path('/workspace/pb-stale-guard-frame-final-verification-20261015.json').write_text(json.dumps(x, indent=2) + '\n')
print(json.dumps({k: v for k, v in x.items() if k not in ('remote', 'batches')}))
