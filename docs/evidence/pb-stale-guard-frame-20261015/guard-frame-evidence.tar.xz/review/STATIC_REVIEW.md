# Static review of bounded original exception frame capture

No blocking static finding at exact working test hash in STATIC_REVIEW.json. Product src/pyproject zero diff from a85382341fa9b2e83455c31380a5a7eaaeedc896; only the requested test module changes. All fifty original assertion AST expressions/messages and order match baseline. Both original fail_job forwarding calls retain identical arguments and call count; original once forwarding calls remain identical.

Capture reads only error.__traceback__, filename/function/tb_lineno, and for the exact Store.guard code object only expected fence and already-read r from frame locals. Row values are accessed only for exact SQLAlchemy RowMapping and only existing fence/lease_until/status fields of exact primitive types. No whole-locals output, new database/clock read, new guard call, callback injection, lease change, retry or business action is introduced. The original comparison time stays Unknown; collected lease_until cannot be compared against a newly sampled time as if that were the original guard instant.

Initial diff allowed unexpected capture exceptions to bypass original fail_job. Current helper wraps capture in except Exception and returns only Unknown fields, preserving the original call for ordinary diagnostic failures. It does not catch BaseException/KeyboardInterrupt/SystemExit. No capture exception text or additional locals are exported. Original error.public and original_failure return/raise semantics remain intact, with existing finally IO exception preservation unchanged. Initial boundary finding and root repair remain authoring history.

Static review does not establish an executed rejection predicate, caller or root cause. In particular missing/wrong frame/RowMapping values must remain Unknown and cannot authorize product changes. Real original-order bounded run remains required; no passing Worker or branch coverage is claimed here.

No tests, SQL, provider API, new runtime observation or source edit by reviewer. Only static Git/AST/hash reads and review files written.
