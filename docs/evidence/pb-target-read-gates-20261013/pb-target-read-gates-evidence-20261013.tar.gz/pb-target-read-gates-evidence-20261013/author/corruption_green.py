import json
from pathlib import Path

from fastapi.testclient import TestClient
from sqlalchemy import select
from test_pb_natural_use_read_gates import TypedPrivateBarrier

from sim2act.api import create_app
from sim2act.config import Settings
from sim2act.db import Store, delivery_graph_requests, internal_app_runs, internal_run_bindings

root = Path('/workspace/pb-target-read-gates-evidence-20261013/author')
import shutil
source = next(p for p in (root / 'green-shared-r1-tmp').glob('*/fixture.db') if not p.parent.is_symlink())
folder = root / 'corruption-green-sandbox'
folder.mkdir(exist_ok=False)
shutil.copyfile(source, folder / 'fixture.db')
store = Store('sqlite:///' + str(folder / 'fixture.db'), test_only=True)
settings = Settings(store.engine.url.render_as_string(hide_password=False), folder, mode='mock', goal_planner_provider='intern-s2')
with store.tx() as c:
    use = c.execute(select(delivery_graph_requests.c.snapshot).where(delivery_graph_requests.c.kind == 'pb_natural_use')).scalar_one()
    accepted = use['response']
    iid = accepted['reviewed']['instance_id']; rid = accepted['run_id']; aid = accepted['app_run_id']
    resource = accepted['reviewed']['variable_bindings']['resource_id']; release = accepted['reviewed']['release_id']
    fp = accepted['reviewed']['release_fingerprint']
    previous = c.execute(select(internal_run_bindings.c.run_id, internal_app_runs.c.id)
        .join(internal_app_runs, internal_app_runs.c.id == internal_run_bindings.c.app_run_id)
        .where(internal_app_runs.c.instance_id == iid, internal_run_bindings.c.run_id != rid)).mappings().one()
from sqlalchemy import delete, insert, update
from sim2act.db import internal_instance_data, new_id
with TestClient(create_app(store, settings), raise_server_exceptions=False) as client:
    client.headers['Authorization'] = 'Bearer synthetic-test-A'
    other_id = client.post(f'/api/internal/releases/{release}/instances', json=dict(expected_release_fingerprint=fp,
        request_key='corruption-other-instance')).json()['id']
    foreign_id = new_id('iapprun')
    with store.tx() as c:
        c.execute(update(__import__('sim2act.db',fromlist=['grants']).grants).where(
            __import__('sim2act.db',fromlist=['grants']).grants.c.resource_id == resource).values(revoked=False))
        app_copy = dict(c.execute(select(internal_app_runs).where(internal_app_runs.c.id == aid)).mappings().one())
        app_copy.update(id=foreign_id, instance_id=other_id, request_key='foreign-frame')
        c.execute(insert(internal_app_runs).values(**app_copy))
        c.execute(update(internal_instance_data).where(internal_instance_data.c.run_id == aid).values(run_id=foreign_id))
    with TypedPrivateBarrier(store,rid,foreign_id,resource) as barrier:
        reply=client.get('/api/internal/instances/'+iid)
        first=dict(name='foreign_typed_row',status=reply.status_code,blocked=barrier.blocked,statements=barrier.statements)
    with store.tx() as c:
        c.execute(update(internal_instance_data).where(internal_instance_data.c.run_id == foreign_id).values(run_id=aid))
        from sim2act.db import grants
        c.execute(update(grants).where(grants.c.resource_id == resource).values(revoked=True))
        c.execute(delete(delivery_graph_requests).where(
            ((delivery_graph_requests.c.app_id == rid)&delivery_graph_requests.c.kind.in_([
                'pa_spec_run_scope','pa_spec_run_scope_seal','pb_natural_use_scope','pb_natural_use_scope_seal']))
            | ((delivery_graph_requests.c.app_id == iid)&delivery_graph_requests.c.kind.in_(['pb_natural_use','pb_natural_use_seal']))))
        bind=dict(c.execute(select(internal_run_bindings).where(internal_run_bindings.c.run_id == rid)).mappings().one())
        snap=dict(bind['snapshot']);snap.pop('pb_use')
        c.execute(update(internal_run_bindings).where(internal_run_bindings.c.run_id == rid).values(snapshot=snap))
    with TypedPrivateBarrier(store,rid,aid,resource) as barrier:
        reply=client.get('/api/internal/instances/'+iid+'/runs/'+rid+'/control-status')
        second=dict(name='missing_all_control_hints',status=reply.status_code,blocked=barrier.blocked,statements=barrier.statements)
(root/'corruption-green-r1.json').write_text(json.dumps([first,second],ensure_ascii=False,indent=2))
print(json.dumps([{k:v for k,v in row.items() if k!='statements'} for row in [first,second]]))
store.engine.dispose()
