# 最终私有试写资格（替代70检查版本）

基线a1649ed443280ad16da45a0a55a0f8086889d8fd，普通分支dev/production-trial-stages-20261018；原12个本地后续提交保持。本轮网络/Git远端/auth/推送/真实模型0，不触main、部署、费用、凭据或新安全权限。复用原Worker/Run/Operation/Intent/Receipt/typed/CAS；无新executor/Grant/表。

原方案位置、九任务对照与未选候选的真实代码缺口保存在旧author原封和独审f2-gap-brief。选F2-T08/AT17：原意图预览和旧注入表13项不能代替真实私有writer，普通空iid还会产生业务资源与Grant。现独立私有锚/受信目标把实际JSON写入app_previews，目录/Run/导出/项目历史标PREVIEW，不提供晋升或发布。

资格以本目录下精确文件为准，不把用例/页面检查/响应加总：

- api-installed-final.log：6个API pytest用例，46.54s；112条实际TestClient/ASGI响应。真实落库、冷Store回读、原key重放、严格DTO、业务/其他私有空间/跨账号拒绝、公共提取拒绝、真实私有插入后失败回滚、权限撤回后元数据取消。全NoModel；正文SQL拒绝具有正向读取校准。
- ui-installed-requalified.log：1个实际served JavaScript/JSDOM页面流程，40.95s，75检查、2boot、174 ASGI响应。其中54静态资源、106页面动作、14fixture检查；状态200=152/201=11/202=5/400=5/403=1，不称所有HTTP成功。
- 页面实际：事前业务A和另一空业务实例；创建私有空间POST201后受控丢回执，换已有业务iid仍保留原UNKNOWN锁、禁用确认/新key，原key单次GET恢复仅一个私有空间。随后独立预览确认CREATE与OPEN→DONE，两次原Worker保存；冷重开/同一旧Run/历史/导出；迟到回读与业务实例、工作区/项目ABA、同账号重连隔离；项目历史精确回到私有Run；另选业务实例重新填写/确认后才由第三次页面Worker保存业务C；最后私有新QUEUED Run撤WRITE→单403清正文→显式停止元数据GET→单次cancel，CANCELLED/fence0未被Worker执行。
- database-before-page/private-checkpoint/after-business/after-cancel.json与private-oracle.json是55表分期原件。全部既有行保持，新增13类账本行逐一绑定私有iid/两个Run/两个Operation，真实app_previews对象2，无资源/Grant。普通业务写入另行明确确认后才产生resource+两派生READ。API另有独立55表和实际回滚原件。
- wheel957688B，SHA256 993d022e17d445f76c8277f8fb65f92a00e1595b58323e8dbff9db708691facc；141包文件源码/wheel/安装完全相等。source-freeze-qualified.json是145项最终源码/测试并集，source-final-unchanged.json为0变化；模块证明全从新安装目录导入。旧source-freeze-final.json/早期test仅用于保留失败阶段，不作最终冻结。
- Ruff/JS语法通过。prior-*保存同Python源的旧2项业务回归PASS15.53s，以及focused mypy旧3/新4文件同4条tools既有错；未冒充新一轮回归或全量类型通过。wheel-difference.json证明旧141包中只JS变，全部Python相同。实际现有Python3.12.14/setuptools84 no-index/no-isolation构建，pin82.0.1构建NOT_RUN。

独审发现与失败原件完整保留：原70检查资格在 /workspace/f2-next-closure-audit-20261018 封存manifest560d99a38a59827fdca6de5ca311d57ae97641db23d01c7223af5dcfb8065f85，613files/63474559B/35links，不再改写；它漏签CREATE_PRIVATE按偶然iid过滤UNKNOWN的静态P2，已整体SUPERSEDED。该P2修复使创建意图按App+Release持久身份、跨iid锁定，切iid清旧确认，普通Run的iid作用域保持。新ui-installed-qualified.log为12.68s实际测试错误：丢回执原控制器会清业务正文，测试误读instance.id；原test/correction JSON保留，修正为selectedIid保留且正文null，再获得最终75检查PASS，未改产品/重签Release。旧两次metadata停止P2、早期测试预期/fixture/build/runner失败都在旧原封。不得提升修复前PASS。

边界：跨账号API实际403与私有空间正文前拒绝；跨账号页面仅静态。冷页成功回读在撤权前，撤权后覆盖本页已核Run停止，不签冷页撤权恢复。真实模型0、语义UNKNOWN、人工PENDING；Windows/PG/原生浏览器/真实场景/远端CI/pin82构建未执行；正式AT17/F2/发布未签。图表/正式发布仍有合同和代码前置；可信账户/免费强制零收费来源SOURCE_MISSING；旧满盘最终独审NOT_RECOVERED。最新远端HEAD未知，最后ACK a7403b379b1278fd1be533ca21d790f0311244af，本轮不查询或推送。
