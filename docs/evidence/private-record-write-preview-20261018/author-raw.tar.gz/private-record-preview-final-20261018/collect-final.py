"""Read only final JSON/log evidence; no product imports or test execution."""
from pathlib import Path
import hashlib,json,collections,re
base=Path(__file__).parent
api=[]
for path in sorted((base/'api-installed-final').rglob('local-record-http.json')):
 rows=json.loads(path.read_text());proof=json.loads(path.with_name('local-record-proof.json').read_text())
 api.append(dict(test=path.parent.name,http_responses=len(rows),statuses=dict(collections.Counter(str(r['status']) for r in rows)),
     response_hashes=[dict(method=r['method'],url=r['url'],status=r['status'],response_sha256=hashlib.sha256(r['response'].encode()).hexdigest()) for r in rows],proof=proof))
uibase=base/'ui-installed-requalified/test_local_record_page_explici0'
page=json.loads((uibase/'page-result.json').read_text());rows=json.loads((uibase/'http-trace.json').read_text())
worker=json.loads((uibase/'worker-log.json').read_text())
oracle=json.loads((uibase/'private-oracle.json').read_text());snap=json.loads((uibase/'database-private-checkpoint.json').read_text())
private_ids={r['id'] for r in snap['runs'] if r['context'].get('execution_namespace')=='local-record-private-preview.v1'}
final=json.loads((uibase/'database-after-cancel.json').read_text())
assert len(final)==55 and len(private_ids)==2
assert all(r['fence']==1 and r['status']=='SUCCEEDED' for r in snap['runs'] if r['id'] in private_ids)
assert len(worker)==3 and all(r['status']=='SUCCEEDED' for r in worker)
assert all(not final[k] for k in ['attempts','reservations'])
cancelled=[{k:r[k] for k in ['id','status','fence','cancel_intent']} for r in final['runs'] if r['status']=='CANCELLED']
assert len(cancelled)==1 and cancelled[0]['fence']==0
freeze=json.loads((base/'source-freeze-qualified.json').read_text());root=Path('/workspace/Sim2Act')
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==row['sha256'] for p,row in freeze.items())
api_oracles=[]
for path in sorted((base/'api-installed-final').rglob('private-delta-oracle.json')):api_oracles.append(json.loads(path.read_text()))
report=dict(scope='Final installed wheel; tests are not additive independent totals',api=dict(pytest_cases=6,pytest_seconds=float(re.findall(r"in ([0-9.]+)s",(base/"api-installed-final.log").read_text())[-1]),http_responses=sum(r['http_responses'] for r in api),cases=api,oracles=api_oracles),
 ui=dict(pytest_cases=1,page_checks=len(page['checks']),pytest_seconds=float(re.findall(r"in ([0-9.]+)s",(base/"ui-installed-requalified.log").read_text())[-1]),boots=page['boots'],http_responses=len(rows),statuses=dict(collections.Counter(str(r['status']) for r in rows)),page_actions=len(page['actions']),assets=len(page['static_resource_loads']),
        private_run_ids=sorted(private_ids),worker_log=worker,fixture_worker_claims=1,page_worker_claims=3,private_delta=oracle,cancelled_private_runs=cancelled,
        response_hashes=[dict(method=r['method'],url=r['url'],status=r['status'],response_sha256=hashlib.sha256(r['response'].encode()).hexdigest()) for r in rows]),
 regression=dict(source_cases=2,seconds=15.53),source_freeze=dict(files=len(freeze),changed=0),
 boundaries=dict(real_models=0,real_semantic='UNKNOWN',human='PENDING',windows='NOT_RUN',postgres='NOT_RUN',native_browser='NOT_RUN',remote_ci='NOT_RUN',remote_operations=0,cross_actor_api='ACTUAL_403_BEFORE_PRIVATE_CONTENT_SQL',cross_actor_ui='STATIC_ONLY',cross_instance_ui='ACTUAL_LATE_RESPONSE',project_workspace_same_account_reconnect_ui='ACTUAL_LATE_RESPONSE',official_AT17='NOT_SIGNED',formal_publish='CLOSED',pinned_setuptools_82_build='NOT_RUN',old_full_disk_review='NOT_RECOVERED'))
(base/'final-evidence-summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(api_cases=6,api_responses=report['api']['http_responses'],ui_checks=report['ui']['page_checks'],ui_responses=len(rows),ui_actions=len(page['actions']),ui_assets=report['ui']['assets'],ui_statuses=report['ui']['statuses'],oracle=oracle,cancelled=cancelled),ensure_ascii=False))
