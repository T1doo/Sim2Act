import hashlib,json,sys
from pathlib import Path
installed=Path('/workspace/private-record-preview-final-20261018/installed-package')
sys.path.insert(0,str(installed))
import sim2act,pytest
assert Path(sim2act.__file__).resolve().is_relative_to(installed)
print('INSTALLED_PACKAGE',sim2act.__file__,flush=True)
code=pytest.main(['-q','-o','pythonpath=',*sys.argv[1:]])
modules={name:module.__file__ for name,module in tuple(sys.modules.items()) if name.startswith('sim2act') and getattr(module,'__file__',None)}
assert all(Path(value).resolve().is_relative_to(installed) for value in modules.values()),modules
out=Path(sys.argv[-1]) if False else Path('/workspace/private-record-preview-final-20261018') / ('installed-modules-'+sys.argv[1].split('/')[-1].split(':')[0]+'.json')
out.write_text(json.dumps(dict(exit_code=code,modules=modules),indent=2)+'\n')
raise SystemExit(code)
