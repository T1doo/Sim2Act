# 原F2下一闭环：有界只读盘点

按父级提供的当前a164上下文；未调用Git核HEAD。对照原计划§4.3（93–101行）、§4.5（129–135行）、AT09–22（361–374行）及产品§3–10。源码/文档观察哈希见`source-observations.json`。没有运行产品、测试、DB、模型、网络或私有留出访问，不产生验收PASS。

## 九任务现状（均为有限实现，不签完整F2）

| 任务 | 已交付，不能重做 | 真正未闭合 |
|---|---|---|
| T01 | GoalCard完整字段、不可变版本/CAS、逐次Goal冻结，同Run人工PREPARE/DECIDE。`goals.py:17/113`、owner控制器。 | 真实任务量表、独立真人判断/语义证据，不是再增表单字段。 |
| T02 | P-A工具反馈、清单/确认、内部Release/实例、逐次新材料Goal及当前源3+2+2普通Worker合成链。 | 真实书生自主选择/反馈/真实语义；生产source/controller安装仍缺受信来源与准入，不能拿mock成功代替。 |
| T03 | 成功来源证明→P-B提取/保存→冷会话新输入/新Run；首次局部逻辑修改、独立CHECK及新Release已有限贯通。`pb_natural_specs.py:301/433`。 | 真实来源任务/未见真实资料泛化与独立语义证据。不能重跑PB同项资格冒新产品。 |
| T04 | 严格Action/Manifest、有限DAG/分支、注册工具、原Worker及输入输出验证。 | 不支持任意图/未知操作符是明确范围；chart只是schema枚举，非已实现组件。 |
| T05 | 三工作区统一使用、自然P-A/P-B、本地记录、历史Run/成果/owner，以及本轮显式App/B业务授权/撤回。 | 正式发布目录仍关闭；不能沿授权/导航/历史继续包装。本轮计划107行旧“App授权页面未提供”已被当前`csv_material_access.py`、`web/use.js`和新交付覆盖，不当现状缺口。 |
| T06 | R0 TXT/MD/CSV/JSON导入、真实文件/结构化成果、JSON/MD下载、本地记录CREATE/OPEN→DONE及集合导出、通用清单text/table已交付。 | 真正chart组件未实现，详下；不是再做filepicker、导出或表格。 |
| T07 | 稳定图/依赖/保守扩验/锁、CSV Goal/列/材料版本、自然配方依赖修改和新内部版本/旧历史。 | 任意语义/布局/Schema修改并无可冻结的通用合同，不能改一个字段或造新模板冒充通用修改。 |
| T08 | 精确批准、不可变内部Release、独立实例/数据、兼容切换及拒绝。 | **生产可用的私有试写namespace缺失（首选代码候选）**；正式发布政策/接线亦未实现，不能将internal flag改名签发布。 |
| T09 | 原运行账本、停止/lease/fence/撤权/原key/未知效果及多条实际HTTP/Worker有限证据。 | 当前源跨平台正式可靠性签收仍缺；旧失败、未执行窗口及满盘审查缺口保留。不建议重做相邻恢复矩阵。 |

## 优先级1：真实私有试写命名空间（T08 / AT17）

**确定是未交付产品能力，且不是只缺真实provider。** 原计划T08第100行、AT17第369行；产品§10.1第452行要求预览只影响独立测试空间。旧`docs/evidence/F2-preview-isolation-20261006/README.md:3–11`及实际`tests/preview_write_fixture.py:1–5/37–54/96`明确：13项FAULT_INJECTION通过，是监听`apps.preview`事务向独立测试MetaData写note/receipt，未注册生产writer、没有用户入口。此历史不能提升为当前可执行试写。

当前`local_record_apps.build_preview:665–691`只形成事件/校验；`preview:718–731`只remember双意图，`confirm:733`后才创建普通Run，`process_job:808–825`才实际保存/派生READ/typed/CAS。合同`LocalRecordState20261018.md:7–11`与代码相符。新建空实例`create_instance:462`现成，称“试用实例”不算新交付。

**不能只给新iid包一层按钮。** `db.py:49–69`的resources/grants无namespace；`tools.write_text_artifact:437–454`按原project存资源并派生两READ Grant；`lifecycle.grant_version:32–42`计算全项目权限指纹。新iid虽隔离typed集合，仍会更改项目资源和权限基线，不能签“只有预览namespace变化”。

可复用原Worker、artifact.save_text、权限校验、Operation/receipt及typed读回；但必须先明确**受信PreviewScope→writer上下文→资源/派生读取权限/目录可见性/依赖指纹**的完整隔离合同。Scope必须服务端绑定owner/project/App/候选/Release/输入，不能让客户端任意指定真实iid或路径；预览结果不得直接当业务成功/隐式采纳。需要设计、代码与新独立oracle，不是已有controller的零改接线。若只能依赖新系统权限、外部库或新写Grant，必须先列授权条件，不能代批准。

最小有价值验收应是一条真实用户页面：明确进入私有试写→原Worker真正保存及独立读回→冷开读试写成果→原业务实例/资源引用/权限基线按事前定义保持；另行显式业务确认才产生新的普通Run和业务效果。不以回滚后保存一份JSON或新iid充当可持久回读的预览writer。全合成、NoModel可实现工程验证；不据此关闭正式发布/Win/PG/真实语义门。

## 次优先：图表与正式发布仍是真缺口，但当前不宜硬造

- **chart（T04/T06，产品第88/103/179行）**：`contracts.View:76–78`只有component_ref/output_field，`web/internal.js:673`明确不支持轴/序列/单位。`ManifestViewComposition20261018.md:7–10`只签text/table，已明确不能把引用行号画成业务图表。缺的是有限chart数据/axis/unit合同和有意义的既有受理producer；不是换table标签。目前没有依据立即选一份业务图表，不推荐造模板/新executor或推断数值语义。
- **正式发布（T08，产品§4/§10）**：`lifecycle.py:1/155`及`api.py:842/869`仍internal/PREVIEW_ONLY/publishable=false。已有不可变版本/兼容切换，不再重做；缺明确的发布状态/证据/适用范围/owner政策及生产安装接口，另有真实语义前置。不能改flag或默认部署消除缺口。本次不推荐先做一个永远deny的发布壳。

## 外部条件与其后代码，必须分开

真实P-A/P-B仍需同账户、独立输入/输出额度及可执行零收费/无付费fallback的可信官方事实/接口；`production_evidence.resolve_account:188–196`仍SOURCE_MISSING，`production_preflight:97–109`在资格/admit前拒绝，`natural_spec_runtime.enabled:45`限testOnly/mock/MockTransport，`worker.main:779`不装生产binding。既有policy/journal/sender/source/3+2+2合成桥都已实现，不能说只缺env，也不能再抽同一helper作新接线。需要可信source实现/独审与安装批准后才谈真实请求。

Win11原生普通权限环境+锁定依赖/明确PG业务角色+原生浏览器、以及有权使用的真实目标材料/独立量表和真人评估仍是正式验收前置；历史Server/PG和Linux/JSDOM不替代。当前禁止Git远端/auth重试与真实调用，均保持0。上述AT17与chart/发布存在真实代码缺口，因此结论不是“所有功能都齐、只差测试环境”；下一步最有价值的是先裁定完整AT17隔离合同是否在本次权限边界内可独立实现，而非继续CSV小变体。
