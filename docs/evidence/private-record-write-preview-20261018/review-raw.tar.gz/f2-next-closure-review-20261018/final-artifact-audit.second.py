"""Independent stdlib-only file audit. Never import Sim2Act or open SQLite."""
import ast
import base64
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import re
from urllib.parse import urlsplit
import zipfile

A = Path('/workspace/f2-next-closure-audit-20261018')
R = Path('/workspace/Sim2Act')
O = Path('/workspace/f2-next-closure-review-20261018')
P = A / 'ui-installed-qualified/test_local_record_page_explici0'
inputs = {}

def sha(b):
    return hashlib.sha256(b).hexdigest()

def read(p):
    p = Path(p)
    assert not any(x in p.name.lower() for x in ('.db', '.sqlite')), p
    b = p.read_bytes()
    inputs[str(p)] = dict(bytes=len(b), sha256=sha(b))
    return b

def load(p):
    return json.loads(read(p))

def canon(x):
    return json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)

def fp(x):
    return sha(canon(x).encode())

# No product import: recover only declared primary-key names from source AST.
pks = {}
for n in ast.walk(ast.parse(read(R / 'src/sim2act/db.py'))):
    if not isinstance(n, ast.Call) or not isinstance(n.func, ast.Name) or n.func.id != 'Table':
        continue
    if not n.args or not isinstance(n.args[0], ast.Constant):
        continue
    cols = []
    for arg in n.args[1:]:
        if not isinstance(arg, ast.Call) or not isinstance(arg.func, ast.Name):
            continue
        if arg.func.id == 'Column' and any(k.arg == 'primary_key' and isinstance(k.value, ast.Constant) and k.value.value is True for k in arg.keywords):
            cols.append(ast.literal_eval(arg.args[0]))
        if arg.func.id == 'PrimaryKeyConstraint':
            cols.extend(ast.literal_eval(a) for a in arg.args)
    if cols:
        pks[ast.literal_eval(n.args[0])] = cols

def keyed(table, rows):
    keys = pks[table]
    result = {tuple(r[k] for k in keys): r for r in rows}
    assert len(result) == len(rows), table
    return result

def delta(before, after):
    assert before.keys() == after.keys() and len(before) == 55
    result = {}
    for t in before:
        old, new = keyed(t, before[t]), keyed(t, after[t])
        result[t] = dict(added=[new[k] for k in new.keys() - old.keys()],
                         removed=[old[k] for k in old.keys() - new.keys()],
                         changed=[dict(before=old[k], after=new[k]) for k in old.keys() & new.keys() if old[k] != new[k]])
    return result

def brief(d):
    return {t: {k: len(v) for k, v in rows.items()} for t, rows in d.items() if any(rows.values())}

seal = load(A / 'SEAL.json')
manifest_bytes = read(A / 'MANIFEST.sha256.json')
assert sha(manifest_bytes) == seal['manifest_sha256'] == '560d99a38a59827fdca6de5ca311d57ae97641db23d01c7223af5dcfb8065f85'
manifest = json.loads(manifest_bytes)
assert len(manifest['files']) == seal['files'] == 613
assert sum(r['bytes'] for r in manifest['files']) == seal['bytes'] == 63474559
db_stat, verified_files = [], []
for item in manifest['files']:
    p = A / item['path']
    assert not p.is_symlink() and p.is_file() and p.stat().st_size == item['bytes'], p
    if any(x in p.name.lower() for x in ('.db', '.sqlite')):
        db_stat.append(dict(path=item['path'], bytes=p.stat().st_size, content_read=False, hash_recomputed=False))
    else:
        assert sha(read(p)) == item['sha256'], p
        verified_files.append(item['path'])
link_results = []
for item in manifest['symlinks']:
    p = A / item['path']
    actual = os.readlink(p)
    assert actual == item['target'], (item, actual)
    link_results.append(dict(path=item['path'], target=actual))
assert len(link_results) == seal['symlinks'] == 35

freeze = load(A / 'source-freeze-final.json')
assert len(freeze) == 144 and load(A / 'source-final-unchanged.json') == dict(files=144, changes={})
for path, expected in freeze.items():
    b = read(R / path)
    assert dict(bytes=len(b), sha256=sha(b)) == expected, path
before_src, after_src = load(P / 'source-before.json'), load(P / 'source-after.json')
assert before_src == after_src and load(P / 'source-changes.json') == {}
assert all(path in freeze and freeze[path] == value for path, value in before_src.items())
wheel_proof = load(A / 'wheel-verification.json')
wheel = next((A / 'wheel').glob('*.whl'))
wheel_bytes = read(wheel)
assert len(wheel_bytes) == wheel_proof['wheel_bytes'] == 957663
assert sha(wheel_bytes) == wheel_proof['wheel_sha256'] == '111aa196f23ab165e3ff9eeb088fa307f897fa09f43d224104b01ee5bec59c94'
with zipfile.ZipFile(wheel) as z:
    entries = {r['path']: r for r in wheel_proof['files']}
    assert len(entries) == 141
    assert {n for n in z.namelist() if n.startswith('sim2act/') and not n.endswith('/')} == set(entries)
    for path, expected in entries.items():
        b = z.read(path)
        assert dict(bytes=len(b), sha256=sha(b)) == {k: expected[k] for k in ('bytes','sha256')}
        assert b == read(R / 'src' / path) == read(A / 'installed-package' / path)
for name in ['test_private_record_preview.py', 'test_local_record_apps_ui.py']:
    modules = load(A / ('installed-modules-' + name + '.json'))
    assert modules['exit_code'] == 0
    assert all(Path(p).is_relative_to(A / 'installed-package') for p in modules['modules'].values())

page, http, ipc = load(P / 'page-result.json'), load(P / 'http-trace.json'), load(P / 'ipc.json')
assert page['status'] == 'PASS' and page['scenario'] == 'private-preview' and len(page['checks']) == 70
assert page['boots'] == 2 and len(page['actions']) == 104 and len(page['static_resource_loads']) == 54 and len(http) == 171
requests = {r['value']['id']: r['value'] for r in ipc if r['direction'] == 'NODE_TO_PYTHON' and 'id' in r['value']}
responses = {r['value']['id']: r['value'] for r in ipc if r['direction'] == 'PYTHON_TO_NODE'}
assert requests.keys() == responses.keys()
def signature(method, path, body, status, text):
    return method, path, canon(body), status, sha(text.encode())
actual = Counter(signature(r['method'], urlsplit(r['url']).path + ('?' + urlsplit(r['url']).query if urlsplit(r['url']).query else ''), r['request'], r['status'], r['response']) for r in http)
bridged = Counter()
for k, req in requests.items():
    if 'method' in req:
        reply = responses[k]
        sig = signature(req['method'], req['path'], req.get('body'), reply['status'], reply['text'])
        bridged[sig] += 1
assert not (bridged - actual), 'IPC HTTP bytes must match actual TestClient trace'
actions = Counter(signature(r['method'], r['path'], r.get('body'), r['status'], r['response_text']) for r in page['actions'])
assert not (actions - bridged), 'Page action bytes must match actual IPC and ASGI response'
for item in page['static_resource_loads']:
    source = R / 'src/sim2act/web' / (item['path'].lstrip('/') or 'index.html')
    assert item['status'] == 200 and sha(read(source)) == item['sha256']
    found = [(req, responses[k]) for k, req in requests.items() if req.get('method') == 'GET' and req.get('path') == item['path']]
    assert any(sha(answer['text'].encode()) == item['sha256'] for _, answer in found)
assert len({r['path'] for r in page['static_resource_loads']}) == 27
assert all(sum(r['boot'] == boot for r in page['static_resource_loads']) == 27 for boot in (1,2))

before, private, business, end = [load(P / n) for n in ['database-before-page.json','database-private-checkpoint.json','database-after-business.json','database-after-cancel.json']]
d1, d2, d3 = delta(before, private), delta(private, business), delta(business, end)
iid = page['instance_id']
pruns = set(page['run_ids'])
assert len(pruns) == 2
binds = {r['run_id']: r for r in private['internal_run_bindings']}
runs = {r['id']: r for r in private['runs']}
app_runs = {r['id']: r for r in private['internal_app_runs']}
private_i = next(r for r in private['internal_instances'] if r['id'] == iid)
creation_rows = [r for r in d1['delivery_graph_requests']['added'] if r['kind'].startswith('local-record-private-preview.v1.instance')]
assert len(creation_rows) == 2
creation = creation_rows[0]['snapshot']
scope_value = dict(namespace='local-record-private-preview.v1', instance_id=iid, principal_id=private_i['principal_id'], project_id=private_i['project_id'], app_id=private_i['source_app_id'], runtime_id=private_i['runtime_id'], release_id=private_i['release_id'], release_fingerprint=creation['request']['expected_release_fingerprint'], creation_request_fingerprint=fp(creation['request']))
scope = dict(scope_value, fingerprint=fp(scope_value))
allowed_private = {'app_previews':2,'delivery_graph_requests':14,'events':10,'heartbeats':2,'internal_app_runs':2,'internal_instance_data':2,'internal_instances':1,'internal_run_bindings':2,'local_effects':2,'operation_intents':2,'operations':2,'run_contracts':2,'runs':2}
assert all(not item['removed'] and not item['changed'] for item in d1.values())
assert {t:len(d['added']) for t,d in d1.items() if d['added']} == allowed_private
assert {r['id'] for r in d1['runs']['added']} == pruns
assert d1['internal_instances']['added'] == [private_i] and private_i['data_version'] == 2
for row in d1['delivery_graph_requests']['added']:
    snap = row['snapshot']
    assert fp(snap) == row['fingerprint'] and fp(snap['request']) == row['request_fingerprint']
    mates = [r for r in d1['delivery_graph_requests']['added'] if r['app_id']==row['app_id'] and r['principal_id']==row['principal_id'] and r['request_key']==row['request_key'] and r['kind'] in (row['kind'].removesuffix('_seal'),row['kind'].removesuffix('_seal')+'_seal')]
    assert len(mates)==2 and mates[0]['snapshot']==mates[1]['snapshot']
    if row['kind'].startswith('local-record-private-preview.v1.instance'):
        assert row['app_id'] == private_i['release_id'] and snap['response'] == {'id':iid}
    elif row['kind'].startswith('local-record-app.v1.run-scope'):
        assert row['app_id'] in pruns and snap['request'] == snap['response'] and snap['request']['preview_scope_fingerprint']==scope['fingerprint']
    else:
        assert row['app_id']==iid and row['kind'].removesuffix('_seal') in ('local-record-app.v1.preview','local-record-app.v1.accepted')
objects = {r['id']:r for r in d1['app_previews']['added']}
history, collection, prior = [], {}, None
for version, rid in enumerate(page['run_ids'],1):
    r, b = runs[rid], binds[rid]
    ar = app_runs[b['app_run_id']]
    assert r['status']=='SUCCEEDED' and r['fence']==1 and r['context']['preview_scope']==scope
    assert r['result']['preview_scope']==scope and r['context']['tools']==1 and r['context']['requests']==0
    assert fp(b['snapshot']) == b['fingerprint'] == r['fingerprint'] and b['snapshot']['preview_scope_fingerprint']==scope['fingerprint']
    assert ar['instance_id']==iid and ar['status']=='SUCCEEDED' and ar['result_version']==version
    typed = next(t for t in d1['internal_instance_data']['added'] if t['run_id']==ar['id'])
    assert typed['instance_id']==iid and typed['version']==version and fp(typed['data'])==typed['fingerprint']
    output = typed['data']['result']
    assert output == ar['output'] and typed['data']['release_ref']==private_i['release_id']
    obj = objects[output['resource_id']]
    meta = obj['input']; saved=obj['output']; event=json.loads(saved['content'])
    assert meta == dict(namespace=scope['namespace'],scope_fingerprint=scope['fingerprint'],instance_id=iid,run_id=rid,operation_id=obj['request_key'],project_id=scope['project_id'],principal_id=scope['principal_id'],runtime_id=scope['runtime_id'],app_id=scope['app_id'],release_id=scope['release_id'])
    assert obj['app_id']==scope['app_id'] and obj['principal_id']==scope['principal_id']
    assert obj['status']=='SUCCEEDED' and obj['error'] is None and saved['format']=='json'
    assert fp(dict(scope=meta,hash=saved['hash']))==obj['fingerprint']
    assert saved['content']==canon(event) and sha(saved['content'].encode())==saved['hash']==output['hash']==fp(event)
    op = next(o for o in d1['operations']['added'] if o['id']==meta['operation_id'])
    intent=next(o['request'] for o in d1['operation_intents']['added'] if o['operation_id']==op['id'])
    effect=next(o for o in d1['local_effects']['added'] if o['operation_id']==op['id'])
    assert op['run_id']==rid and op['tool_ref']=='artifact.save_text' and op['status']=='VERIFIED'
    assert intent==dict(tool='artifact.save_text',args=dict(text=saved['content'])) and fp(intent)==op['fingerprint']
    assert effect['resource_id']==obj['id'] and effect['content_hash']==saved['hash']
    assert op['receipt']['data']==output and op['receipt']['artifact_refs']==[obj['id']]
    assert event['instance_id']==iid and event['collection_version']==version and event['previous_collection_fingerprint']==prior
    record=event['record_id']; old=collection.get(record)
    if old is None:
        assert event['kind']=='CREATE' and event['record_revision']==1 and event['state']=='OPEN' and event['previous_event_fingerprint'] is None
    else:
        assert event['kind']=='SET_STATE' and old['state']=='OPEN' and event['state']=='DONE' and event['record_revision']==old['record_revision']+1 and event['previous_event_fingerprint']==old['last_event_fingerprint']
        assert event['title']==old['title'] and event['details']==old['details']
    collection[record]={k:event[k] for k in ('record_id','record_revision','title','details','state')}|{'last_event_fingerprint':fp(event)}
    prior=fp(event)
    history.append(dict(version=version,event=event,event_fingerprint=prior,artifact=output,run_id=rid,app_run_id=ar['id']))
assert history[0]==page['first_history']
assert len(collection)==1 and next(iter(collection.values()))['state']=='DONE'
assert not private['attempts'] and not private['reservations']

download=page['downloads'][0]
blob=base64.b64decode(download['base64'],validate=True)
assert len(page['downloads'])==1 and len(blob)==download['bytes']==4217 and sha(blob)==download['sha256'] and download['revoked'] is True
export=json.loads(blob.decode('utf-8'))
assert export['snapshot_kind']=='PRIVATE_PREVIEW_COLLECTION' and export['execution_namespace']==scope['namespace'] and export['preview_scope']==scope
assert export['data_version']==2 and export['records']==list(collection.values()) and export['history']==history
assert set(export)=={'namespace','snapshot_kind','execution_namespace','preview_scope','principal_id','project_id','app_id','instance_id','release_id','release_fingerprint','instance_revision','data_version','records','history'}

assert len(d2['resources']['added'])==1 and len(d2['grants']['added'])==2
assert not d2['app_previews']['added'] and not d2['app_previews']['changed'] and not d2['app_previews']['removed']
assert len(d2['runs']['added'])==1
normal=d2['runs']['added'][0]
assert normal['status']=='SUCCEEDED' and normal['fence']==1 and 'preview_scope' not in normal['context']
assert all(r in business['internal_instance_data'] for r in private['internal_instance_data'])
assert next(i for i in business['internal_instances'] if i['id']==iid)==private_i
resource=d2['resources']['added'][0]
assert sha(resource['content'].encode())==resource['hash']
assert all(g['resource_id']==resource['id'] and g['tool_ref']=='resource.read' and not g['revoked'] for g in d2['grants']['added'])

revoke=load(P/'private-write-revocation.json')
assert len(d3['grants']['changed'])==1 and not d3['grants']['added'] and not d3['grants']['removed']
g=d3['grants']['changed'][0];assert g['before']==revoke['before']
assert g['after']==dict(g['before'],revoked=True,revision=g['before']['revision']+1)
stop=next(r for r in end['runs'] if r['id']==revoke['run'])
assert stop['status']=='CANCELLED' and stop['version']==2 and stop['cancel_intent'] is True and stop['fence']==0 and stop['worker_id'] is None and stop['result'] is None
assert not [o for o in end['operations'] if o['run_id']==stop['id']]
assert not [a for a in end['attempts'] if a['run_id']==stop['id']]
assert business['app_previews']==end['app_previews'] and business['internal_instance_data']==end['internal_instance_data'] and business['resources']==end['resources']
tail=[r for r in page['actions'] if stop['id'] in r['path']]
assert [r['method'] for r in tail]==['GET','POST'] and tail[0]['path'].endswith('/private-control-status')
metadata=json.loads(tail[0]['response_text']);assert metadata['content_access'] is False and metadata['version']==1 and metadata['preview_scope_fingerprint']==scope['fingerprint']
assert set(metadata)=={'namespace','id','instance_id','principal_id','project_id','app_id','runtime_id','release_id','status','version','content_access','execution_namespace','preview_scope_fingerprint','formal_publication_enabled'}
assert tail[1]['body']==dict(command='cancel',version=1) and tail[1]['status']==200
assert any(r['status']==403 and r['path']==f'/api/internal/record-instances/{iid}' for r in page['actions'])
workers=load(P/'worker-log.json');assert len(workers)==3 and {w['run_id'] for w in workers}==pruns|{normal['id']}
assert all(w['status']=='SUCCEEDED' and w['model']=='NoModel' and w['cold_store'] for w in workers)

# Independent final API artifacts, including actual pre-rollback row and post-rollback absence.
api_counts={}; api_total=0
for d in sorted((A/'api-installed-final').iterdir()):
    if not d.is_dir() or d.is_symlink():continue
    trace=load(d/'local-record-http.json'); proof=load(d/'local-record-proof.json')
    api_total+=len(trace);api_counts[d.name]=dict(responses=len(trace),statuses=dict(Counter(r['status'] for r in trace)))
    assert proof['real_model_requests']==0
assert len(api_counts)==6 and api_total==112
rollback=A/'api-installed-final/test_real_private_insert_then_0'
rb_before,rb_after=load(rollback/'rollback-before.json'),load(rollback/'rollback-after.json')
rb_delta=delta(rb_before,rb_after)
for t in ['resources','grants','app_previews','operations','operation_intents','local_effects','internal_instance_data','internal_instances']:
    assert rb_before[t]==rb_after[t],t
rb_proof=load(rollback/'local-record-proof.json')
inserted=rb_proof['actual_private_insert_before_rollback']
assert len(inserted)==1 and sha(inserted[0]['output']['content'].encode())==inserted[0]['output']['hash']
assert inserted[0]['id'] not in {r['id'] for r in rb_after['app_previews']}
assert rb_proof['failed_run']['status']=='FAILED' and rb_proof['failed_run']['output'] is None
barrier=load(A/'api-installed-final/test_other_actor_and_other_spa0/local-record-proof.json')
assert barrier['private_content_projection_reads']==0 and not any('SELECT app_previews.output \n' in q for q in barrier['sql'])
api_pos=A/'api-installed-final/test_real_private_storage_isol0'
ap_delta=delta(load(api_pos/'before-private.json'),load(api_pos/'after-private.json'))
assert all(not x['changed'] and not x['removed'] for x in ap_delta.values())
assert {t:len(x['added']) for t,x in ap_delta.items() if x['added']}==allowed_private

logs={name:read(A/name).decode() for name in ['api-installed-final.log','ui-installed-qualified.log','ordinary-regression-2.log','api-attempt-1.log','api-attempt-2.log','api-qualified-1.log','api-qualified-2.log','ui-qualified-1.log','ui-qualified-2.log','ordinary-regression-1.log','mypy-baseline.log','mypy-focused-baseline.log','mypy-focused-final.log','ruff-final.log','wheel-build.log','wheel-build-pip.log','wheel-build-system.log']}
assert '6 passed' in logs['api-installed-final.log'] and '1 passed' in logs['ui-installed-qualified.log'] and '2 passed' in logs['ordinary-regression-2.log']
assert '6 errors' in logs['api-attempt-1.log'] and 'fixture \'evidence\' not found' in logs['api-attempt-1.log']
assert '1 failed, 5 passed' in logs['api-attempt-2.log'] and '1 failed, 5 passed' in logs['api-qualified-1.log']
assert 'TypeError: Cannot read properties of null' in read(A/'ui-qualified-2/test_local_record_page_explici0/node.stderr').decode()
assert logs['mypy-focused-baseline.log'].splitlines()[:-1]==logs['mypy-focused-final.log'].splitlines()[:-1]

result=dict(verdict='LIMITED_PASS_PRIVATE_RECORD_WRITE_PREVIEW',review_method='INDEPENDENT_STATIC_SOURCE_AND_STDLIB_ARTIFACT_AUDIT_NO_PRODUCT_EXECUTION',
    author_manifest=dict(path=str(A/'MANIFEST.sha256.json'),sha256=sha(manifest_bytes),regular_files=613,raw_bytes=63474559,non_database_files_hashed=len(verified_files),database_files_stat_only=db_stat,symlinks_checked=link_results,seal_file_sha256=sha(read(A/'SEAL.json'))),
    source=dict(final_inputs=144,ui_inputs=len(before_src),unchanged=True,wheel_files=141,wheel_bytes=len(wheel_bytes),wheel_sha256=sha(wheel_bytes),current_source_and_install_exact=True,git_not_called=True),
    qualification=dict(final_unique_cases=9,api_cases=6,ui_cases=1,ordinary_regression_cases=2,pytest_logs='6 PASS 31.48s + 1 PASS 37.51s + 2 PASS 15.53s; no JUnit file provided in final author tree',ui_checks=70,boots=2,page_actions=104,page_action_methods=dict(Counter(x['method'] for x in page['actions'])),assets=54,api_responses=112,ui_asgi_responses=171,ui_statuses=dict(Counter(x['status'] for x in http)),page_worker_calls=3,fixture_worker_calls=1,actual_private_writes=2,ordinary_business_writes_during_page=1,queued_cancel_claims=0,real_model_calls=0),
    ui=dict(instance_id=iid,scope=scope,private_run_ids=page['run_ids'],business_run_id=normal['id'],cancelled_run_id=stop['id'],download=dict(bytes=len(blob),sha256=sha(blob),snapshot_kind=export['snapshot_kind']),http_and_ipc_exact=True,assets_current_bytes_exact=True),
    tables=dict(count=55,private_phase=brief(d1),business_phase=brief(d2),queued_revoke_cancel_phase=brief(d3),all_existing_rows_unchanged_in_private_phase=True,private_resources_and_grants_unchanged=True,private_scope_pairs_and_object_hashes_recomputed=True,private_history_fold_recomputed=True,rollback=brief(rb_delta)),
    api=api_counts,
    prior_failures_preserved=['api-attempt-1 six setup ERROR missing evidence fixture','api-attempt-2 and api-qualified-1 each 5 PASS/1 FAIL wrong missing ordinary key status expectation','ui-qualified-1 66 checks successful superseded source','ui-qualified-2 actual P2 TypeError missing accepted Run metadata target','ordinary-regression-1 invalid selection/no test execution','two failed build routes before successful system Python 3.12/setuptools84 build','mypy is not green; focused old/new same four tools errors; wider baseline 28 errors'],
    findings=dict(remaining_P1_P2=[],initial_P2_and_second_P2='FIXED_IN_FINAL_SOURCE_AND_ACTUAL_REVOKED_WRITE_METADATA_CANCEL_SEQUENCE'),
    limits=['Author privileged JSON exports independently compared; physical DB contents/hashes not read or reconstructed.','SQL barrier assertion matches a specific content projection; no independent dynamic SQL probe executed.','Same-account reconnect/project/workspace/instance late callbacks actual JSDOM; cross-account UI static; foreign actor API403 actual.','SQLite/test_only/NoModel and ASGI TestClient+IPC/JSDOM, not native network or browser.','No PG/Windows/native browser/remote CI/deployment/real provider/semantic/human acceptance.','Pinned setuptools82.0.1 build NOT_RUN; successful existing system setuptools84 build only.','No Git/remote/push/commit audit or prospective endorsement.','Original full-disk missing independent report remains missing.'],
    product_execution_by_reviewer=0,database_execution_by_reviewer=0,network_by_reviewer=0)
(O/'final-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
(O/'final-audit-inputs.json').write_text(json.dumps(inputs,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(verdict=result['verdict'],non_db_files_hashed=len(verified_files),database_stat_only=len(db_stat),symlinks=len(link_results),source144=True,wheel141=True,api_responses=api_total,ui_asgi_responses=len(http),ui_checks=70,phases=result['tables'],sha256=sha((O/'final-verification.json').read_bytes())),ensure_ascii=False,indent=2))
