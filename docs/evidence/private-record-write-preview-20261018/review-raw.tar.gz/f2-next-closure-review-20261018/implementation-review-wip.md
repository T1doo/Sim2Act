# 私有试写实现：有限静态复核

结论：当前 WIP 有一项 P2 功能阻断，尚不建议按完整合同冻结。没有发现新的确定私有写入越权或业务降级路径；本结论是静审，未运行产品/测试/SQL/DB/模型/网络/Git。

## P2：撤 WRITE 后清正文也清掉了停止入口

合同第6条承诺撤权后仍能通过 owner 元数据入口停止原 Run。当前用户已接受私有 Run 后，若原 `artifact.save_text` 权限被撤，再点击刷新，则实例 projection 返回403；`localRecordsRefresh` catch 调用 `localRecordsClearPrivate`，继而 `localRecordsClearInstance` 清 `v.control`、`v.instance`、Run选择和已接受Run。`localRecordsControlButtons` 要求控制状态、完整instance和选中Run同时存在，所以取消按钮永久禁用。重新读取同实例仍先走已撤权的内容权限，不能恢复控制。

后端 `local_record_apps.control` 的 cancel/pause 本已仅核 owner/项目/创建锚/Run scope 和当前Run版本，不要求内容 WRITE。问题是无对应 metadata-only GET 与页面路径。旧 `internal_api` 的 `/control-status` 在 `scope_run` 先 `reject_record_legacy`，也不能回退借用。现新API测试最后节点直接 POST version=1 证明后端可取消，未覆盖页面可达性。

最小修复：增加严格 owner/scope 的专用元数据状态 GET，仅返回已知 iid/rid、状态/version/cancel_intent、PREVIEW作用域标记和 content_access=false；页面403后清全部正文，保留独立的已核 iid/rid 控制身份，按原账号/连接/项目/工作区/实例/Run代次围栏显式读取当前版本，再明确cancel。不要恢复完整缓存 instance，不借内容字段授权，不开放无权限 resume，不自动重发。此问题是静态可达路径，未动态复现。精确相关源片段及本次文件SHA见 `implementation-review-wip-observations.json`。

## 其余已读实现

- `instance_header` 同时检索普通/私有创建双锚，要求唯一精确pair和严格DTO；缺半边、全缺、混合、附加锚均不能进入普通writer。独立 `is_instance` 也识别私有锚；Run双锚及binding保存scopeFP，`accepted_binding`再核运行scope。未见合法缺锚降级。
- 正常 Worker 先原完整 accepted_binding/projection/event校验，再从该实际instance生成 `Target`。私有writer重核当前创建锚/WRITE、Run live fence/owner/project/runtime、Operation与原Intent；真实JSON写app_previews。receipt/effect/typed和实例CAS仍同事务，末端也走私有artifact/readback及原最终guard/deadline。普通writer的resources及两派生READ行为保留。
- `artifact` 先owned实例+当前WRITE，再读无正文的scope/hash元数据；确切同iid/Run/Operation/effect验证后才投影output内容，并重算字节SHA。私有空间交叉对象在正文前拒绝，未见到resources的隐式fallback。
- 旧共享app_previews公共提取先join app_drafts；本地记录App定义不存app_drafts，当前正常私有对象不会走到该旧完整row读取。其它旧App preview/read也先读/校验其draft。普通resource API仅查resources，私有对象不在该表。P-B仍要求原自然家族及其独立Run门。最终有限测试仍需核拒绝原件，静审不替代实际屏障资格。
- 业务delivery.instances与preview_instances分列；实例optgroup、Run详情、项目历史与集合导出增加PREVIEW/scope标记。实例切换清标题/正文/确认，iid/read/edit选择围栏和每次hash await后current检查保留。未见自动promote或业务写入。

未发现另一个确定 P1/P2。原候选MODE/工具注册不变，不新增executor、Grant、DDL或LIVE许可。当前代码尚未冻结，后续修改与最终实际Worker/UI原件仍需有限复核；探索性5PASS/1预期错误不在本独审中改签或算作最终资格。
