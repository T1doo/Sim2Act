# 第二次 P2 修正：源码闭合

`P2_CLOSED_IN_SOURCE_PENDING_FINAL_RUNTIME_EVIDENCE`。当前 ClearPrivate 同时要求所选实例确为已核私有 iid，且所选 rid 存于原 projection.runs 或该实例当前 acceptedRun。后者仅由已通过原 input/requestFP/event hash 与 current 检查的确认/原key回执设置；实例切换会清 acceptedRun 和 metadataTarget。任意 Run 下拉字符串不再足以生成新hint，刚受理而尚未进入旧projection的QUEUED Run现在可以留下独立停止身份。

hint只保存 iid/rid/principal/project/App/runtime/Release/scopeFP 标量，清理仍删除私有正文/表单/结果。专用metadata GET再核服务端owner和不可变scope，页面核14字段白名单及全部hint绑定，不重建完整instance。仅cancel可用，原版本命令/pending Map语义不变；当前账号、连接、项目、工作区、实例选择、read代次及target对象身份围栏保留。当前未发现剩余确定 P1/P2。

本结论仅静态源码。两次WIP发现报告保持原件，探索性/修复前UI及在途最终wheel/UI/API不由本报告改签。未运行产品、测试、SQL、DB、模型、网络或Git；未读私有留出。文件观察SHA与限制见 `metadata-fix-source-closure.json`。目录暂不封存，最终结论待闭合原件。
