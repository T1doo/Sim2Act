# 撤权后停止入口：修复静审（尚有一项遗漏）

专用 `private_control_metadata`/GET 已正确先核当前 owner/project/iid/Run、独立创建pair和RUN_SCOPE；业务实例拒绝。返回仅14个白名单元数据字段，不含正文/成果，未放宽WRITE或READ。页面显式GET核所有原target绑定与PREVIEW scopeFP，然后仅启用cancel；不会构造完整instance/成果。pending Map继续锁未知控制，fresh版本推进仅读取状态。实例/工作区/项目/账号/连接/read/selection代次及target对象身份检查阻断迟到赋值。上述为静审，不是本轮实际通过。

仍有 P2：刚接受的 Run 无法留下hint。`localRecordsClearPrivate`仅在 `v.instance.runs.some(r=>r.id===rid)` 时从当前实例创建hint；`localRecordsConfirm`和`localRecordsAcceptedRun`只更新acceptedRun和Run下拉，未更新旧projection的runs。新确认QUEUED、首次刷新前撤WRITE、刷新403这个实际用户顺序中，新rid不在旧runs，target为空，停止入口仍disabled。新driver的stopRun正按此顺序，未执行它也能由静态路径确认。若存在旧metadataTarget，还可能回退到旧Run，不能将其视为新Run的证明。

应从经过原intent/current/精确iid校验的受理/原key恢复回执保存独立标量hint；不能仅相信runSelect字符串。后续专用GET继续完成服务端scope验证，才拿当前版本显式cancel。无需恢复私有instance/正文或添加权限。已向root即时报告。原WIP P2报告原样保留，不能据本次部分修复写为完全关闭。

本次源观察与必要片段见 `metadata-fix-wip-observations.json`。不执行产品、pytest、DB、SQL、网络、Git或模型；不读取正在执行证据或私有留出。仍等待修正和最终冻结实际原件，目录不封存。
