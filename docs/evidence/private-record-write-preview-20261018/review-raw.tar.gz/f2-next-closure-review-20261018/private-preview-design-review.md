# 私有记录试写：实施前有限设计审查

结论：`DESIGN_MAY_PROCEED_WITH_REQUIRED_SCOPE_GATES`。本设计确实新增持久私有写入目标，并隔离资源、派生授权及实例目录；它不等同于已有“新建空业务实例”。可在原本地记录 controller、Worker、`artifact.save_text@1` 和现有写权限交集中实施。尚无本片运行资格，不签 AT17 或整体 F2 通过。

原计划依据：`docs/分阶段开发计划.md:100` 的 F2-T08、`:369` 的 AT17，及 `docs/平台产品设计.md:452` 明确要求独立测试命名空间，不能调用生产写入目标。旧 `test_preview_write_isolation.py` 是明确标注的 FAULT_INJECTION，不能替代该产品功能。

## 实施必须保留的边界

1. 创建命名空间必须由独立双锚重建，普通 INSTANCE 与 PRIVATE_INSTANCE 互斥。缺失、错位、混合或额外锚均拒绝；同一 iid 的已封存 Run scopeFP 不允许重解释为业务模式。仅删除私有标志不能令 writer 转入普通 resources/Grant 路径。`instance_header` 是这个判断的服务端入口；普通本地记录 Release 的既有独立锚仍保持。
2. 私有写入和回读从实际 iid/Run/Operation、创建锚、原候选/Release、当前 WRITE 交集派生目标。原 `process_job` 的保存、末端输出 READ、`reconcile_readback`、projection、`authorize_data` 必须一致分支；不能只改保存点或使用客户端/可变 context flag。私有分支不回退 resources，普通分支不读取 app_previews。原 lease/fence、停止、预览到期、CAS 及写后最终权限重验保持。
3. `app_previews` 是共用物理表。私有行须完整绑定 owner/project/App/runtime/Release/iid/Run/Operation/scopeFP，并在私有正文 SELECT 前核当前权限及交叉对象。既有普通预览/来源接口不得导入这些对象。当前公共 `extract_preview`（`extraction.py:153`）先以 app_drafts join 定位；本地记录定义不进入 app_drafts，因此正常私有对象在这个入口可在全文前拒绝。`verified_source` 自身确有先读整行的实现，仍应在最终边界测试证明公共入口拒绝，不将静态潜在风险写成已发生泄漏。P-B `source_gate`（`pb_natural_specs.py:93`）还要求原始自然家族和独立 Run scope，不能按 SUCCEEDED 接纳私有记录 Run。
4. 私有实例、Run/成果及集合导出必须持续标 PREVIEW/scope。业务 delivery.instances 排除私有实例；项目历史或直接 Run 深链接不能丢失预览性质。共享 local-record VERSION 与 SUCCEEDED 只代表工具/状态成功，不能变为业务验收、P-B 来源、发布或人工签收。普通集合导出若复用，也须明确私有范围或在私有模式关闭，不能沿原业务快照名称输出未标记内容。
5. 复用原表不等于把共享表全排除验证。私有对象、原 journal pair、Run/AppRun/contract/binding、Operation/Intent/Receipt、typed/iid CAS 必须逐新增行核精确私有范围；resources、grants、既有业务行及业务审批指纹保持。私有写后故障整事务回滚。另做一笔正常业务写以证明普通派生 READ 行行为仍在。

## 当前静审与验收限制

这是对冻结合同的设计审查，同时只读到并行新增 `record_preview_storage.py` 及部分 local_record_apps/tools WIP。该时点原 process_job 尚未传入私有目标、末端仍为资源 READ，delivery 尚未分组；这些属于实施尚未闭合，不能认定实现可冻结或运行通过。实际文件观察字节见 `private-preview-design-observations.json`，不把 WIP 文件桥接为 a164 的未改源码。

建议沿合同执行一次完整正向私有 CREATE→DONE、冷回读、原业务保持和独立业务写；仅加新命名空间必要的半锚/跨对象/原键及事务回滚验证。没有发现需要新增系统权限、executor、Grant 或 DDL 的设计前提。私有 READ 使用当前原 WRITE 交集是更窄的工具回读合同，应作为固定服务端能力实现，不能注册成通用按 ID 读取对象的工具。

本审查只读文件，不运行产品、测试、Worker、SQL、模型、网络或 Git；未读 DB/私有留出集，未写仓库和任何旧封存目录。旧满盘缺失独审仍是原证据缺口。没有对未来实现、测试、归档、提交或推送作背书。目录保持未封存，以供后续冻结源码独审。
