# F2-T08 / AT17 有限私有记录试写：原始资格证据

基线 a1649ed443280ad16da45a0a55a0f8086889d8fd；普通开发分支 dev/production-trial-stages-20261018；本任务唯一产品/Git写入者。当前远端未知，远端/auth/推送操作0，最后已知ACK为a7403b379b1278fd1be533ca21d790f0311244af。保留原12个本地提交，不操作main/旧满盘环境/未知锁；没有部署、真实模型或新增Grant/安全权限。

原计划九项对照及候选依据在独立审查的f2-gap-brief/source-observations。选T08/AT17真正私有writer：旧13项是测试注入表，原记录preview仅意图，新空业务iid仍会产生resources/READ Grant；本实现复用原Worker/Run/Operation/Intent/Receipt/typed/CAS，改变受信存储目标。Chart与正式发布仍有代码/合同前置，不造模板或发布壳；P-A/P-B真实来源、可信零收费准入和真实语义/人工条件未关闭。

最终资格只引用以下原件（数量不相加）：

- `api-installed-final.log`：6个API pytest用例，31.48s。实际TestClient/ASGI响应112条，非原始网络wire。各用例local-record-http/proof记录实际请求、响应、拒绝及已核字段；全NoModel。
- `ui-installed-qualified.log`：1个页面pytest流程，37.51s；实际served JavaScript/JSDOM 70项页面检查、2次boot，171个ASGI响应（200=150/201=10/202=5/400=5/403=1），其中54静态资源，104页面动作；余响应包含受限fixture检查，不是额外页面测试。HTTP响应全量与IPC在子目录，400包含已有可选查询，403是WRITE撤回预期拒绝，不能声称全HTTP成功。
- 页面实际私有CREATE+OPEN→DONE两个Run、另行显式业务CREATE一个Run，由原Worker.once冷Store执行；另有一个事前业务fixture Worker，均SUCCEEDED。撤权后另一个已确认QUEUED私有Run通过显式元数据GET+单次cancel成为CANCELLED/fence0、未被Worker执行。
- `database-before-page/private-checkpoint/after-business/after-cancel.json`保存55表分期原件，private-oracle逐行约束全部既有行不变；仅新增与私有iid/2个Run/2个Operation绑定的原账本及2个app_previews对象。resources/grants/principals及原业务行完全保持。后续业务新Run只在单独明确提交后产生原resource+两READ Grant。API另有完整55表及实际写入后故障事务回滚原件。
- `ordinary-regression-2.log`：2项原业务源码回归，15.53s，不是安装包新用例；保留原事务/普通writer能力。
- wheel 957663字节，SHA256 `111aa196f23ab165e3ff9eeb088fa307f897fa09f43d224104b01ee5bec59c94`。141包文件的wheel/源码/安装逐字节相等；144源/测试项冻结后0变化。两个installed-modules文件证明所有实际导入sim2act模块来自本轮安装目录。
- Ruff/三项JS语法通过；focused mypy新4文件与基线旧3文件都只有tools.py同4条既有错误，完整基线import检查另有28条历史问题，不能称全量类型检查通过。最终构建用现有system Python3.12.14/setuptools84.0.0，no-index/no-isolation；pyproject pin82.0.1构建NOT_RUN。

探索/失败必须保留：api-attempt-1漏共享fixture而6ERROR；api-attempt-2及api-qualified-1各5PASS/1测试预期错误（普通不存在key是现OUTCOME_UNKNOWN/400，误预期409）；api-qualified-2是修订前源码6PASS，仅辅助。ui-qualified-1是元数据停止修复前66checks PASS，已SUPERSEDED；ui-qualified-2实际复现二次P2（新QUEUED Run未在旧projection、首次403丢hint），FAIL。之后代码修复，最终安装包70checks覆盖该确切顺序。一次普通regression选择器拼错无测试收集；build模块/venv setuptools缺失的两次失败日志保留；ui-installed-final为runner文件尚未创建时启动的命令失败，最终ui-installed-qualified才是资格。不得提升任何旧PASS。

权限与语义边界：跨账号API/跨私有空间拒绝及正文SQL前置实际执行且有正向SQL校准；跨账号页面仍只静态，页面实际覆盖私有→业务迟到回读、项目/工作区ABA、同账号重新连接。冷页读取私有持久成果发生在撤权前；撤权后停止覆盖本页已核Run，不声称冷页撤权恢复。Windows/PG/原生浏览器/真实provider/远端CI未运行，语义UNKNOWN、人工PENDING、正式AT17/F2未签收，正式发布关闭。旧满盘最后独审缺失NOT_RECOVERED。
