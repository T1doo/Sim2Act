import json, pathlib, httpx, pytest
root=pathlib.Path(__file__).parent
attempts=[]
def denied(*args,**kwargs):
    attempts.append('blocked_real_http_transport')
    raise AssertionError('Real HTTP forbidden in local type-contract regression')
httpx.HTTPTransport.handle_request=denied
httpx.AsyncHTTPTransport.handle_async_request=denied
args=json.loads((root/'pytest-selection.json').read_text())
try:
    code=pytest.main(args)
finally:
    (root/'http-tripwire.json').write_text(json.dumps({'blocked_transport_attempts':len(attempts),'real_http_transport_entries':0,'scope':'httpx standard sync/async transports patched; in-process TestClient/finite MockTransport remain available'})+'\n')
raise SystemExit(code)
