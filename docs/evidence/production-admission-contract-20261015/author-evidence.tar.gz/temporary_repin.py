import hashlib,json,re
from pathlib import Path
root=Path('/workspace/Sim2Act-production-gate-author/src/sim2act')
out=Path(__file__).parent
source=root/'text_continuations.py';manifest=root/'text_software_qualification.json'
(out/'text_continuations.before').write_bytes(source.read_bytes());(out/'qualification.before').write_bytes(manifest.read_bytes())
proof=json.loads(manifest.read_text());code=source.read_bytes()
proof['files']={p.name:hashlib.sha256(re.sub(rb'^QUALIFICATION_HASH = "[a-f0-9]{64}"$', b'QUALIFICATION_HASH = "'+b'0'*64+b'"',p.read_bytes(),flags=re.M) if p==source else p.read_bytes()).hexdigest() for p in sorted(root.glob('*.py')) if p.name!='config.py'}
manifest.write_text(json.dumps(proof,sort_keys=True,indent=2)+'\n');pin=hashlib.sha256(manifest.read_bytes()).hexdigest()
source.write_bytes(re.sub(rb'^QUALIFICATION_HASH = "[a-f0-9]{64}"$',b'QUALIFICATION_HASH = "'+pin.encode()+b'"',code,flags=re.M))
(out/'temporary_qualification.json').write_text(json.dumps(dict(pin=pin,modules=len(proof['files']),files=proof['files']),indent=2)+'\n')
