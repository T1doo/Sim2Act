# F1-T06 / F2-T03 / F3-T05 有限生产准入合同工程

基线255b6ac407ebad31aedbe1b8d9547ee3892cdc0f，独立分支dev/production-admission-contract-20261015。root为唯一集成者；两个隔离作者、只读独审，原199完整批与新增两suite将于同一冻结SHA实际运行，不合并作者/旧版本通过数。

## 执行合同

生产HTTP只接受原trial批准/阶段/Run版本栅栏字段，不接受resolver、sender、任意FeeAuthority/free/LIVE字段。默认没有生产注册，不读取凭据、不发现权益或发送网络；缺真实可核权益或受审发送器必须拒绝且无Run/预算/quota副作用。服务端账户解析合同绑定principal/project/完整trial指纹/account/provider/canonical quota/费用权益与不可收费条件/新鲜性/撤回/零paid cap，调用方quota label不能证明这些。

离线发送器为固定数据、无IO callback，只允许test_only SQLite。真实生产注册与外部请求原子性/幂等发送器未实现，本轮不能签真实LIVE。隔离路径复用原gate.admit + budget.reserve/settle和3+2+2账槽；每次准入在同事务核worker owner/fence/version/lease/status/cancel，原审批、阶段、材料Goal、软件精确资格、总预算、共享账号RPM。保留原300sec/30sec/max3claim等边界。每次new dispatch前新鲜检查；已扣原key只读历史，即使未知/取消/撤回/冷重启也不能重发或退款。未知保留为未知，迟到结算记录真实费用但不复活许可。

## P-B来源合同

独立来源合同绑定完整PBTrialContract及原批准指纹、可信account/provider/quota、同trial原成功source Run/app/两个原response Attempts、原wire/raw bytes/hash、provider request/response identity和已知usage来源、原source槽及抽取key/完整Recipe、新cold材料及完整Goal。不能将旧MOCK字段简单改LIVE；所有合成resolver结果恒NOT_LIVE_VERIFIED，生产resolver未注册不执行任意callback。typed两source槽不代替原3+2+2账本证明；离线cold仍需原budget.audit与gate完整来源检查。

## 必须保留的证据与边界

同account跨trial拆quota、陈旧或伪造免费、worker漂移、完整trial/批准指纹变更等独审红反例先保存再修复。隔离验证跨account/trial、未知费用、duplicate key、迟到结果、取消和原key冷恢复。最终独审精确源码及manifest/pin、实际XML/collection唯一双射、执行前后字节、费用/Run副作用与LIVE拒绝声明后再交付。

前批199同版全过不改写历史ce6/2dda未知拒因；PG、Windows/native browser、真实模型/费用、真实provider evidence resolver/账号权益验证、人工语义、CI与部署均NOT RUN。工程通过不授予真实调用权，不关闭整体F1/F2/F3/R0/C0验收。
