import collections, hashlib, json, subprocess
from pathlib import Path
import xml.etree.ElementTree as ET
b=Path('/workspace/production-admission-evidence-20261015/regression/local-atomic-probe');r=Path('/workspace/Sim2Act-pa-provider');i=b.parents[1]/'integration'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
a=load(b/'RESULT.json');c=load(b/'COLLECTION.json');m=load(b/'source-before.json')
assert a['sha']=='206de555e22c9a6e85c1ea87a33c1e55c0780968'
assert a['returncode']==load(b/'PROCESS_EXIT.json')['pytest_returncode']==0
assert a['counts']=={'pass':35,'failure':0,'error':0,'skipped':0}
assert a['executed_count']==a['unique_ids']==a['collected_count']==len(c['nodeids'])==35
assert a['complete_selected_collection'] and not a['unnamed_xml_entries']
assert m==load(b/'source-after.json')==load(b/'executed-source-manifest.json') and len(m)==495
for name,want in m.items():
 assert sha(b/'executed-source'/name)==sha(r/name)==want
 assert hashlib.sha256(subprocess.check_output(['git','show',a['sha']+':'+name],cwd=r)).hexdigest()==want
cases=list(ET.parse(b/'results.xml').getroot().iter('testcase'))
ids=[x.get('classname').replace('.','/')+'.py::'+x.get('name') for x in cases]
assert collections.Counter(ids)==collections.Counter(c['nodeids'])
assert all(a[k] for k in ('source_unchanged','head_unchanged','worktree_clean','executed_source_equal'))
for field,name in [('stdout_sha256','stdout.log'),('stderr_sha256','stderr.log'),('xml_sha256','results.xml')]:assert a[field]==sha(b/name)
proofs=[]
for pattern in ('test_local_atomic_group_rolls_*/local-write-rollback.json','test_local_atomic_group_final_*/local-current-rollback.json'):
 for p in (b/'tmp').glob(pattern):
  if p.parent.is_symlink():continue
  x=load(p);assert x['all_tables_identical'] and x['fault_injection'] and x['clock_frozen_after_claim'] and x['original_lease_seconds']==30 and x['original_run_seconds']==300
  proofs.append({'path':str(p.relative_to(b)),'sha256':sha(p),'fault':x['fault']})
assert len(proofs)==20
p=b/'observer/e350798183fea7351e268fcc96e5bfd8ba52fafaacb1c1a31dfbe3bb9fe0ba0e.heartbeat.jsonl'
rows=[json.loads(x) for x in p.read_text().splitlines()];rows=[x for x in rows if x['run_id'] is not None]
out={'sha':a['sha'],'PASS':35,'FAIL':0,'ERROR':0,'SKIP':0,'source_files':495,'before_after_copied_root_git_equal':True,'xml_collection_exact_bijection':True,'elapsed_seconds':a['elapsed'],'xml_sha256':a['xml_sha256'],'result_sha256':sha(b/'RESULT.json'),'scope':'newlocal21+route8+originalnormalcancel/peer_lock2+TXT/MD4; not full339, no aggregation','fault_rollback_proofs':proofs,'normal_cancel_heartbeat':{'file_sha256':sha(p),'committed_lease_returns':sum(x['phase']=='return' and x['renewed_until'] is not None for x in rows),'error_types':dict(collections.Counter(x['error_type'] for x in rows if x['phase']=='error')),'max_total_call_seconds':max(x['elapsed'] for x in rows),'wait_scope_split':'NOT_RECORDED','historical_root_cause':'NOT_INFERRED'}}
(i/'LOCAL_ATOMIC_PROBE_AUDIT.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='fault_rollback_proofs'}))
