import ast, collections, hashlib, json, subprocess
from pathlib import Path
import xml.etree.ElementTree as ET
b=Path('/workspace/production-admission-evidence-20261015/regression/final47e'); repo=Path('/workspace/Sim2Act-pa-provider');i=b.parents[1]/'integration'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
r=load(b/'RESULT.json');c=load(b/'COLLECTION.json');before=load(b/'source-before.json')
assert r['sha']=='47e76f9fcd05532c1726d5c1283c3c052a85f3eb'
assert r['returncode']==load(b/'PROCESS_EXIT.json')['pytest_returncode']==2
assert r['counts']=={'pass':137,'failure':1,'error':0,'skipped':0}
assert r['executed_count']==r['unique_ids']==138 and r['collected_count']==318 and not r['complete_selected_collection']
assert before==load(b/'source-after.json')==load(b/'executed-source-manifest.json') and len(before)==494
for name,want in before.items():
 assert sha(b/'executed-source'/name)==sha(repo/name)==want
 assert hashlib.sha256(subprocess.check_output(['git','show',r['sha']+':'+name],cwd=repo)).hexdigest()==want
cases=list(ET.parse(b/'results.xml').getroot().iter('testcase'));named=[x for x in cases if x.get('classname') and x.get('name')]
ids=[x.get('classname').replace('.','/')+'.py::'+x.get('name') for x in named]
assert len(cases)==139 and len(named)==len(set(ids))==138 and set(ids)<=set(c['nodeids'])
counts=collections.Counter(next((z.tag for z in x if z.tag in ('failure','error','skipped')),'pass') for x in named)
assert all(r['counts'][k]==counts[k] for k in ('pass','failure','error','skipped'))
for field,name in [('stdout_sha256','stdout.log'),('stderr_sha256','stderr.log'),('xml_sha256','results.xml')]:assert r[field]==sha(b/name)
assert all(r[k] for k in ('source_unchanged','head_unchanged','worktree_clean','executed_source_equal'))
baseline=load(Path('/workspace/complete-regression-evidence-20261015/final0b6a/COLLECTION.json'))['nodeids']
files=sorted({n.split('::')[0] for n in baseline});assert len(files)==15
for name in files:
 old=subprocess.check_output(['git','show','255b6ac407ebad31aedbe1b8d9547ee3892cdc0f:'+name],cwd=repo)
 if name=='tests/test_natural_trial_budget.py':
  assert hashlib.sha256(old).hexdigest()=='6694714986db64e73a8487aac1a128026717ada8abe6963ce08b8876c4876468'
  assert before[name]=='b821b3b8ed58d72c4779800d1e81f99668213abf475e6d7c76a1bb5fae5c8692'
  x,y=ast.parse(old),ast.parse((b/'executed-source'/name).read_bytes());target='test_seven_actual_reservations_stage_binding_nontransfer_no_refund'
  xf=next(n for n in x.body if isinstance(n,ast.FunctionDef) and n.name==target);yf=next(n for n in y.body if isinstance(n,ast.FunctionDef) and n.name==target)
  assert collections.Counter(ast.dump(n) for n in ast.walk(xf) if isinstance(n,ast.Assert))<=collections.Counter(ast.dump(n) for n in ast.walk(yf) if isinstance(n,ast.Assert))
  assert [ast.dump(n) for n in x.body if n is not xf]==[ast.dump(n) for n in y.body if n is not yf]
 else:assert hashlib.sha256(old).hexdigest()==before[name]
out=dict(source_sha=r['sha'],PASS=137,FAIL=1,ERROR=0,SKIP=0,collected=318,executed_named=138,incomplete=180,unnamed_xml_entries=1,pytest_returncode=2,interrupted_once=True,complete_batch=False,source_files=494,before_after_copied_root_git_equal=True,original15_files_except_reviewed_cleanup_preserved=True,cleanup_all_original_asserts_retained=True,executed_xml_collection_subset_exact=True,missing_ids=sorted(set(c['nodeids'])-set(ids)),xml_sha256=r['xml_sha256'],result_sha256=sha(b/'RESULT.json'))
(i/'PARTIAL47_AUDIT.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='missing_ids'}))
