import collections
import ast
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path
base=Path('/workspace/production-admission-evidence-20261015/regression/final47e')
repo=Path('/workspace/Sim2Act-pa-provider')
sha=json.loads((base/'COMMAND.json').read_text())['sha']
assert sha=='47e76f9fcd05532c1726d5c1283c3c052a85f3eb'
def read(name): return json.loads((base/name).read_text())
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
r=read('RESULT.json'); c=read('COLLECTION.json'); cmd=read('COMMAND.json')
expected=len(c['nodeids'])
baseline=json.loads(Path('/workspace/complete-regression-evidence-20261015/final0b6a/COLLECTION.json').read_text())['nodeids']
assert len(baseline)==199 and set(baseline)<=set(c['nodeids'])
original306=json.loads((base.parent/'final/COLLECTION.json').read_text())['nodeids']
assert len(original306)==306 and set(original306)<=set(c['nodeids']) and expected==318
assert len([n for n in c['nodeids'] if n.startswith('tests/test_natural_dispatch_routing.py::')])==8
assert len([n for n in c['nodeids'] if n.startswith('tests/test_text_workflows.py::test_actual_four_nodes_and_partial_branch[')])==4
assert all(n.split('::')[0] in {'tests/test_production_trial_admission.py','tests/test_pb_live_source_contract.py','tests/test_natural_dispatch_routing.py','tests/test_text_workflows.py'} for n in set(c['nodeids'])-set(baseline))
assert r['sha']==cmd['sha']==sha
assert r['returncode'] in (0,1)
assert sum(r['counts'].values())==expected
assert (r['returncode']==0)==(r['counts']['failure']==r['counts']['error']==0)
assert r['unique_ids']==r['executed_count']==r['collected_count']==expected and r['duplicate_ids']==0
assert all(r[k] for k in ('source_unchanged','head_unchanged','worktree_clean','complete_selected_collection','executed_source_equal'))
assert cmd['no_deselection'] and cmd['no_budget_override']
for key,file in [('stdout_sha256','stdout.log'),('stderr_sha256','stderr.log'),('xml_sha256','results.xml')]: assert r[key]==digest(base/file)
cases=list(ET.parse(base/'results.xml').getroot().iter('testcase'))
xml_counts=collections.Counter(next((z.tag for z in x if z.tag in ('failure','error','skipped')),'pass') for x in cases)
assert all(r['counts'][k]==xml_counts[k] for k in ('pass','failure','error','skipped'))
ids=[x.get('classname').replace('.','/')+'.py::'+x.get('name') for x in cases]
assert collections.Counter(ids)==collections.Counter(c['nodeids']) and len(set(ids))==expected
before=read('source-before.json'); after=read('source-after.json'); executed=read('executed-source-manifest.json')
assert before==after==executed
original_test_files=sorted({n.split('::')[0] for n in baseline})
for name in original_test_files:
 raw=subprocess.check_output(['git','show','255b6ac407ebad31aedbe1b8d9547ee3892cdc0f:'+name],cwd=repo)
 if name=='tests/test_natural_trial_budget.py':
  assert hashlib.sha256(raw).hexdigest()=='6694714986db64e73a8487aac1a128026717ada8abe6963ce08b8876c4876468'
  assert before[name]=='b821b3b8ed58d72c4779800d1e81f99668213abf475e6d7c76a1bb5fae5c8692'
  oldtree=ast.parse(raw); newtree=ast.parse((base/'executed-source'/name).read_bytes())
  target='test_seven_actual_reservations_stage_binding_nontransfer_no_refund'
  oldfn=next(n for n in oldtree.body if isinstance(n,ast.FunctionDef) and n.name==target)
  newfn=next(n for n in newtree.body if isinstance(n,ast.FunctionDef) and n.name==target)
  oldasserts=collections.Counter(ast.dump(n,include_attributes=False) for n in ast.walk(oldfn) if isinstance(n,ast.Assert))
  newasserts=collections.Counter(ast.dump(n,include_attributes=False) for n in ast.walk(newfn) if isinstance(n,ast.Assert))
  assert oldasserts<=newasserts
  assert [ast.dump(n,include_attributes=False) for n in oldtree.body if n is not oldfn]==[ast.dump(n,include_attributes=False) for n in newtree.body if n is not newfn]
 else:
  assert hashlib.sha256(raw).hexdigest()==before[name], 'Original baseline test changed: '+name
for name,want in before.items():
 assert digest(base/'executed-source'/name)==digest(repo/name)==want
 raw=subprocess.check_output(['git','show',sha+':'+name],cwd=repo)
 assert hashlib.sha256(raw).hexdigest()==want
scope=collections.Counter(x.split('::')[0] for x in ids)
seven=[x for x in ids if 'seven' in x or x.endswith('::test_actual_mock_generated_app_stage_binding_and_cold_per_use')]
original_seven=[n for n in baseline if 'seven' in n or n.endswith('::test_actual_mock_generated_app_stage_binding_and_cold_per_use')]
assert len(original_seven)==3 and set(original_seven)<=set(ids)
result={'source_sha':sha,'returncode':r['returncode'],'PASS':r['counts']['pass'],'FAIL':r['counts']['failure'],'ERROR':r['counts']['error'],'SKIP':r['counts']['skipped'],'deselected':0,'xml_collection_exact_bijection':True,'unique_ids':expected,'original_test_files_unchanged_except_reviewed_seven_slot_cleanup':True,'cleanup_original_asserts_retained':True,'cleanup_only_function_changed':True,'cleanup_old_hash':'6694714986db64e73a8487aac1a128026717ada8abe6963ce08b8876c4876468','cleanup_new_hash':'b821b3b8ed58d72c4779800d1e81f99668213abf475e6d7c76a1bb5fae5c8692','original_test_file_count':len(original_test_files),'source_files_verified':len(before),'root_and_executed_and_git_bytes_equal':True,'elapsed_seconds':r['elapsed'],'scope':dict(scope),'seven_slot_test_ids':seven,'xml_sha256':r['xml_sha256'],'result_sha256':digest(base/'RESULT.json')}
p=Path('/workspace/production-admission-evidence-20261015/integration/TERMINAL_AUDIT.json');p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
