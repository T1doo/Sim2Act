"""Read-only original pytest monitor; never starts or changes a test."""
from pathlib import Path
import datetime,json,time
b=Path('/workspace/production-admission-evidence-20261015/regression/final')
out=Path('/workspace/production-admission-evidence-20261015/integration/PROCESS_TIMELINE.jsonl')
c=json.loads((b/'COLLECTION.json').read_text());st=json.loads((b/'START.json').read_text())
while True:
    at=datetime.datetime.now(datetime.timezone.utc);s=(b/'stdout.log').read_text()
    m=[x for x in s if x in '.FsE'];n=len(m);terminal=None
    if (b/'RESULT.json').exists():
        try:terminal=json.loads((b/'RESULT.json').read_text())
        except json.JSONDecodeError:pass
    row=dict(utc=at.isoformat(),pid=st['pid'],elapsed_seconds=at.timestamp()-st['started'],progress=n if terminal is None else terminal['executed_count'],failures=m.count('F') if terminal is None else terminal['counts']['failure'],current=c['nodeids'][n] if n<len(c['nodeids']) and terminal is None else None,pid_exists=Path('/proc/'+str(st['pid'])).exists(),result=terminal is not None)
    if terminal is not None:row['counts']=terminal['counts'];row['returncode']=terminal['returncode']
    with out.open('a') as f:f.write(json.dumps(row)+'\n')
    print(json.dumps(row),flush=True)
    if terminal is not None:break
    time.sleep(45)
