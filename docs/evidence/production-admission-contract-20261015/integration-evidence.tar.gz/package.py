"""Archive completed synthetic evidence with exact member hash readback."""
import hashlib
import json
import tarfile
from pathlib import Path

repo = Path('/workspace/Sim2Act-pa-provider')
out = repo / 'docs/evidence/production-admission-contract-20261015'
roots = {
    'author': Path('/workspace/production-admission-evidence-20261015/author'),
    'pb-author': Path('/workspace/production-admission-evidence-20261015/pb-author'),
    'regression': Path('/workspace/production-admission-evidence-20261015/regression'),
    'review': Path('/workspace/production-admission-evidence-20261015/review'),
    'cold-probe': Path('/workspace/production-admission-evidence-20261015/cold-probe'),
    'integration': Path('/workspace/production-admission-evidence-20261015/integration'),
}
for extra in ('cancel-diagnostic','route-before','route-before2','route-fixed','route-family-fixed','peer-lock-diagnostic','peer-lock-diagnostic2','route-local-fixed','budget-cleanup-probe','pb-heartbeat-diagnostic'):
    roots[extra] = Path('/workspace/production-admission-evidence-20261015') / extra
excluded = {'__pycache__', '.pytest_cache', 'mypy-cache'}

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

out.mkdir(parents=True, exist_ok=True)
archives = {}
for name, root in roots.items():
    assert root.is_dir() and not root.is_symlink()
    files = {}
    for path in sorted(root.rglob('*')):
        relative = path.relative_to(root)
        if excluded.intersection(relative.parts) or path.is_symlink() or not path.is_file():
            continue
        assert not any(p.is_symlink() for p in path.parents if p != root.parent)
        if name == 'integration' and relative.name == 'PACKAGE_RESULT.json':
            continue
        files[relative.as_posix()] = {'bytes': path.stat().st_size, 'sha256': digest(path)}
    target = out / (name + '-evidence.tar.gz')
    with tarfile.open(target, 'w:gz') as archive:
        for member in files:
            archive.add(root / member, arcname=member, recursive=False)
    seen = set()
    with tarfile.open(target, 'r:gz') as archive:
        for member in archive:
            assert member.isfile() and member.name in files and member.name not in seen
            seen.add(member.name)
            wanted = files[member.name]
            assert member.size == wanted['bytes']
            h = hashlib.sha256()
            with archive.extractfile(member) as f:
                for block in iter(lambda: f.read(1024 * 1024), b''):
                    h.update(block)
            assert h.hexdigest() == wanted['sha256'] == digest(root / member.name)
    assert seen == set(files)
    (out / (name + '-MANIFEST.json')).write_text(json.dumps(files, indent=2) + '\n')
    archives[name] = dict(file=target.name, bytes=target.stat().st_size,
        sha256=digest(target), members=len(files), complete_regular_member_readback=True)
    print(json.dumps({name: archives[name]}), flush=True)
(out / 'ARCHIVES.json').write_text(json.dumps(archives, indent=2) + '\n')
(roots['integration'] / 'PACKAGE_RESULT.json').write_text(json.dumps(archives, indent=2) + '\n')
