from pathlib import Path
import datetime,json,os,re,collections,hashlib
b=Path('/workspace/production-admission-evidence-20261015/regression/final206')
s=(b/'stdout.log').read_text();m=list(''.join(re.findall(r'(?m)^[.FsExXsr]+(?=\s*\[|\s*$)',s)));c=json.loads((b/'COLLECTION.json').read_text());n=len(m)
st=json.loads((b/'START.json').read_text());pid=st['pid']
x={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':pid,'elapsed_seconds':datetime.datetime.now(datetime.timezone.utc).timestamp()-st['started'],'progress':n,'failures':m.count('F'),'current':c['nodeids'][n] if n<len(c['nodeids']) else None,'stdout_mtime_utc':datetime.datetime.fromtimestamp((b/'stdout.log').stat().st_mtime,datetime.timezone.utc).isoformat(),'result':(b/'RESULT.json').exists(),'pid_exists':Path('/proc/'+str(pid)).exists()}
result=None
if (b/'RESULT.json').exists():
    try:result=json.loads((b/'RESULT.json').read_text())
    except json.JSONDecodeError:pass
if result is not None:x.update(progress=result['executed_count'],failures=result['counts']['failure'],current=None,counts=result['counts'])
p=b/'tmp/test_pb_exact_same_trial_sourc0/settlement-events.jsonl'; rows=[]
if p.exists():
    for line in p.read_text().splitlines():
        try:rows.append(json.loads(line))
        except json.JSONDecodeError:pass
x['pb_events']=dict(collections.Counter(r['event'] for r in rows))
x['pb_stage_settlements']=dict(collections.Counter(r['stage'] for r in rows if r['event']=='settlement_returned'))
files=sorted((b/'observer').glob('*.failure.txt'),key=lambda p:p.stat().st_mtime)
x['failure_reports']=len(files)
x['latest_failure_report']=str(files[-1]) if files else None
if x['current'] is not None:
    key=hashlib.sha256(x['current'].encode()).hexdigest()
    hp=b/'observer'/(key+'.heartbeat.jsonl');hr=[]
    if hp.exists():
        for line in hp.read_text().splitlines():
            try:
                v=json.loads(line)
                if v.get('run_id') is not None:hr.append(v)
            except json.JSONDecodeError:pass
    x['current_heartbeat_events']=dict(collections.Counter(z['phase'] for z in hr))
    x['current_last_heartbeat']=({k:hr[-1].get(k) for k in ('phase','at','elapsed','error_type','sqlite_errorcode')} if hr else None)
print(json.dumps(x))
