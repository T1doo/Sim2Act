"""Seal one complete reviewed target; never broaden filename exemptions."""
import argparse
import ast
import hashlib
import json
import re
import subprocess
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--candidate', required=True)
args = p.parse_args()
repo = Path('/workspace/Sim2Act-pa-provider')
root = repo / 'src/sim2act'
assert re.fullmatch('[a-f0-9]{40}', args.candidate)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == args.candidate
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True).strip()
source = root / 'text_continuations.py'
manifest = root / 'text_software_qualification.json'
before = source.read_bytes()
proof = json.loads(manifest.read_bytes())
old_candidate = proof['review_candidate']
old_pin = proof_pin = re.search(rb'^QUALIFICATION_HASH = "([a-f0-9]{64})"$', before, re.M).group(1)
assert hashlib.sha256(manifest.read_bytes()).hexdigest().encode() == old_pin
anchors_before = (root / 'text_software_anchors.json').read_bytes()
tree = ast.parse(before)
changed_before = ast.get_source_segment(before.decode(), next(n for n in tree.body
    if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'CHANGED' for t in n.targets)))
needle = ('and proof["review_candidate"] == "' + old_candidate + '"').encode()
assert before.count(needle) == 1
code = before.replace(needle, ('and proof["review_candidate"] == "' + args.candidate + '"').encode())
source.write_bytes(code)
proof['review_candidate'] = args.candidate
proof['files'] = {}
for path in sorted(root.glob('*.py')):
    if path.name == 'config.py':
        continue
    raw = path.read_bytes()
    if path == source:
        raw, count = re.subn(rb'^QUALIFICATION_HASH = "[a-f0-9]{64}"$',
            b'QUALIFICATION_HASH = "' + b'0' * 64 + b'"', raw, flags=re.M)
        assert count == 1
    proof['files'][path.name] = hashlib.sha256(raw).hexdigest()
manifest.write_text(json.dumps(proof, sort_keys=True, indent=2) + '\n')
pin = hashlib.sha256(manifest.read_bytes()).hexdigest()
code, count = re.subn(rb'^QUALIFICATION_HASH = "[a-f0-9]{64}"$',
    b'QUALIFICATION_HASH = "' + pin.encode() + b'"', code, flags=re.M)
assert count == 1
source.write_bytes(code)
tree = ast.parse(code)
changed_after = ast.get_source_segment(code.decode(), next(n for n in tree.body
    if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'CHANGED' for t in n.targets)))
assert anchors_before == (root / 'text_software_anchors.json').read_bytes()
assert changed_before == changed_after
assert proof['anchor_hash'] == '24f26f3621b8fc49a24fa3566484b568148d9317f2d279d79f264416b994193a'
receipt = dict(candidate=args.candidate, previous_candidate=old_candidate,
    previous_pin=proof_pin.decode(), pin=pin, module_count=len(proof['files']),
    exact_complete_files=proof['files'], anchor_and_changed_unchanged=True,
    normalization=proof['normalization'])
(Path(__file__).parent / 'QUALIFICATION.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k:v for k,v in receipt.items() if k != 'exact_complete_files'}))
