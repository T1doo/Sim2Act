"""Independent full batch: run only on root's exact clean frozen commit."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
import xml.etree.ElementTree as ET

ROOT = Path('/workspace/Sim2Act-complete-regression')
OUT = Path('/workspace/production-admission-evidence-20261015/regression')
PYTHON = '/workspace/Sim2Act/.venv/bin/python'
TESTS = ['tests/test_natural_local_write_group.py', 'tests/test_natural_dispatch_routing.py', 'tests/test_project_natural_revalidation.py::test_late_project_change_no_partial_save[cancel]', 'tests/test_project_natural_revalidation.py::test_late_project_change_no_partial_save[peer_lock]', 'tests/test_text_workflows.py::test_actual_four_nodes_and_partial_branch']

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def write(p, x):
    p.write_text(json.dumps(x, ensure_ascii=False, indent=2) + '\n')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

def manifest():
    paths = [ROOT / 'pyproject.toml']
    for directory in ('src', 'tests'):
        paths.extend(p for p in (ROOT / directory).rglob('*') if p.is_file()
                     and '__pycache__' not in p.parts and not p.is_symlink())
    return {str(p.relative_to(ROOT)): digest(p) for p in sorted(paths)}

p = argparse.ArgumentParser()
p.add_argument('--sha', required=True)
p.add_argument('--name', required=True)
args = p.parse_args()
assert len(args.sha) == 40
assert args.name.isalnum() or all(c.isalnum() or c in '-_' for c in args.name)
assert git('rev-parse', 'HEAD') == args.sha
assert not git('status', '--porcelain'), 'Independent tree must be clean'
run = OUT / args.name
run.mkdir(exist_ok=False)
before = manifest()
write(run / 'source-before.json', before)
for name in before:
    dest = run / 'executed-source' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT / name, dest)
env = {k: os.environ[k] for k in ('PATH', 'LANG', 'LC_ALL', 'TZ') if k in os.environ}
env.pop('SIM2ACT_TEST_DATABASE_URL', None)
env.update(PYTHONDONTWRITEBYTECODE='1', PYTHONPATH=f'{ROOT}/src:{ROOT}/tests',
           NODE_PATH='/workspace/node-tools/node_modules',
           SIM2ACT_REGRESSION_OBSERVER_DIR=str(run/'observer'))
collect_argv = [PYTHON, '-m', 'pytest', '--collect-only', '-q',
                '-p', 'no:cacheprovider', '-p', 'production_regression_observer', *TESTS]
collected = subprocess.run(collect_argv, cwd=ROOT, env=env, capture_output=True)
(run / 'collection.stdout').write_bytes(collected.stdout)
(run / 'collection.stderr').write_bytes(collected.stderr)
nodeids = [line for line in collected.stdout.decode().splitlines()
           if line.startswith('tests/') and '::' in line]
write(run / 'COLLECTION.json', dict(argv=collect_argv,
      returncode=collected.returncode, nodeids=nodeids,
      count=len(nodeids), unique_count=len(set(nodeids)),
      stdout_sha256=hashlib.sha256(collected.stdout).hexdigest(),
      stderr_sha256=hashlib.sha256(collected.stderr).hexdigest(),
      collection_is_not_pass=True))
assert collected.returncode == 0 and nodeids and len(nodeids) == len(set(nodeids))
assert manifest() == before and git('rev-parse', 'HEAD') == args.sha
print(json.dumps(dict(sha=args.sha, collected_count=len(nodeids),
      unique_count=len(set(nodeids)), collection_is_not_pass=True)), flush=True)
argv = [PYTHON, '-m', 'pytest', '-q', '-p', 'no:cacheprovider', '-p', 'production_regression_observer', *TESTS,
        f'--basetemp={run}/tmp', f'--junitxml={run}/results.xml']
write(run / 'COMMAND.json', dict(sha=args.sha, cwd=str(ROOT), argv=argv,
      database='isolated per-test SQLite tmp_path; inherited database URL removed',
      no_deselection=True, no_budget_override=True,
      observer_plugin='tests/production_regression_observer.py',
      observer_sha256=digest(ROOT/'tests/production_regression_observer.py'),
      observer_scope='public rejection, heartbeat entry/exit/errors and existing pytest longrepr; no DB/scheduling/decision changes'))
started = time.time()
with (run / 'stdout.log').open('w') as stdout, (run / 'stderr.log').open('w') as stderr:
    child = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=stdout, stderr=stderr)
    write(run / 'START.json', dict(pid=child.pid, started=started))
    code = child.wait()
finished = time.time()
write(run / "PROCESS_EXIT.json", dict(pytest_returncode=code, finished=finished))
after = manifest()
write(run / 'source-after.json', after)
executed = {name: digest(run / 'executed-source' / name) for name in before}
write(run / 'executed-source-manifest.json', executed)
cases = []
unnamed_xml_entries = []
if (run / 'results.xml').exists():
    for case in ET.parse(run / 'results.xml').getroot().iter('testcase'):
        if not case.get('classname') or not case.get('name'):
            unnamed_xml_entries.append(dict(attributes=case.attrib, children=[c.tag for c in case]))
            continue
        state = next((x.tag for x in case if x.tag in ('failure', 'error', 'skipped')), 'pass')
        cases.append(dict(id=case.get('classname') + '::' + case.get('name'),
                          status=state, time=case.get('time')))
ids = [x['id'] for x in cases]
summary = dict(sha=args.sha, returncode=code, started=started, finished=finished,
               elapsed=finished-started, unnamed_xml_entries=unnamed_xml_entries, source_unchanged=before == after,
               head_unchanged=git('rev-parse', 'HEAD') == args.sha,
               worktree_clean=not git('status', '--porcelain'), unique_ids=len(set(ids)),
               duplicate_ids=len(ids)-len(set(ids)),
               collected_count=len(nodeids), executed_count=len(cases),
               complete_selected_collection=len(nodeids) == len(cases),
               executed_source_equal=before == executed,
               stdout_sha256=digest(run / 'stdout.log'),
               stderr_sha256=digest(run / 'stderr.log'),
               counts={s: sum(x['status']==s for x in cases) for s in ('pass','failure','error','skipped')},
               xml_sha256=digest(run / 'results.xml') if (run / 'results.xml').exists() else None,
               testcases=cases)
write(run / 'RESULT.json', summary)
print(json.dumps({k:v for k,v in summary.items() if k != 'testcases'}), flush=True)
