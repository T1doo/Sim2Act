"""Exact SHA quality evidence, retaining mypy failures rather than waiving them."""
import argparse, hashlib, json, os, subprocess
from pathlib import Path

p=argparse.ArgumentParser()
p.add_argument('--sha',required=True)
p.add_argument('--name',required=True)
a=p.parse_args()
root=Path('/workspace/Sim2Act-complete-regression')
out=Path('/workspace/production-admission-evidence-20261015/regression')/a.name
out.mkdir(exist_ok=False)
def git(*args): return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
assert git('rev-parse','HEAD')==a.sha and not git('status','--porcelain')
venv=Path('/workspace/Sim2Act/.venv/bin')
env={k:os.environ[k] for k in ('PATH','LANG','LC_ALL','TZ') if k in os.environ}
env['PYTHONDONTWRITEBYTECODE']='1'
commands={
 'ruff_fullsrc':[str(venv/'ruff'),'check','--no-cache','src'],
 'ruff_changed':[str(venv/'ruff'),'check','--no-cache'],
 'mypy':[str(venv/'mypy'),'--cache-dir',str(out/'mypy-cache'),'src'],
 'node_product':['node','--check','src/sim2act/web/project-natural.js'],
 'node_fixture':['node','--check','tests/project_check_cancel.cjs']}
changed=subprocess.check_output(['git','diff','--name-only','255b6ac407ebad31aedbe1b8d9547ee3892cdc0f',a.sha],cwd=root,text=True).splitlines()
changed_python=[x for x in changed if x.endswith('.py') and (x.startswith('src/') or x.startswith('tests/'))]
commands['ruff_changed'].extend(changed_python or ['src/sim2act/natural_trial_budget.py'])
receipt={'sha':a.sha,'commands':{},'changed_python':changed_python,'fullsrc_scope_separate_from_changed_scope':True}
for name,argv in commands.items():
 r=subprocess.run(argv,cwd=root,env=env,capture_output=True)
 (out/(name+'.stdout')).write_bytes(r.stdout)
 (out/(name+'.stderr')).write_bytes(r.stderr)
 receipt['commands'][name]={'argv':argv,'returncode':r.returncode,
 'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest()}
 if name=='ruff_fullsrc':
  baseline_ruff=Path('/workspace/complete-regression-evidence-20261015/baseline526-fullsrc-ruff.stdout')
  receipt['ruff_fullsrc_prior_actual_sha']='52654f7610602b7afc8a2c44eee7abc23e5c2d5d'
  receipt['ruff_fullsrc_prior_stdout_sha256']=hashlib.sha256(baseline_ruff.read_bytes()).hexdigest()
  receipt['ruff_fullsrc_prior_stdout_equal']=r.stdout==baseline_ruff.read_bytes()
  receipt['ruff_fullsrc_historical_10_not_assumed']=True
 if name=='mypy':
  errors=[line for line in r.stdout.decode().splitlines() if ': error:' in line]
  receipt['mypy_errors']=errors
  baseline=Path('/workspace/project-reliability-gates-evidence-20261015/author/mypy-typed.stdout')
  old=[line for line in baseline.read_text().splitlines() if ': error:' in line]
  receipt['mypy_prior_exact_errors_equal']=errors==old
  receipt['mypy_new_errors']=[e for e in errors if e not in old]
receipt['head_unchanged']=git('rev-parse','HEAD')==a.sha
receipt['tree_clean']=not git('status','--porcelain')
(out/'RESULT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
