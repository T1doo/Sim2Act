import hashlib,json,os,subprocess,time,xml.etree.ElementTree as ET
from pathlib import Path
r=Path('/workspace/Sim2Act-pa-provider');b=Path('/workspace/production-admission-evidence-20261015/route-family-fixed');b.mkdir()
env={k:os.environ[k] for k in ('PATH','LANG','LC_ALL','TZ') if k in os.environ};env.update(PYTHONPATH=str(r/'src')+':'+str(r/'tests'),PYTHONDONTWRITEBYTECODE='1',NODE_PATH='/workspace/node-tools/node_modules')
tests=['tests/test_natural_dispatch_routing.py','tests/test_project_natural_revalidation.py::test_late_project_change_no_partial_save[cancel]','tests/test_text_workflows.py::test_actual_four_nodes_and_partial_branch']
argv=['/workspace/Sim2Act/.venv/bin/python','-m','pytest','-q','-p','no:cacheprovider',*tests,'--basetemp='+str(b/'tmp'),'--junitxml='+str(b/'results.xml')]
paths=[r/'pyproject.toml']+[p for folder in ('src','tests') for p in (r/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and not p.is_symlink()]
before={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
def write(n,v): (b/n).write_text(json.dumps(v,indent=2)+'\n')
write('source-before.json',before);start=time.time();sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()
with (b/'stdout').open('w') as out,(b/'stderr').open('w') as err:
 c=subprocess.Popen(argv,cwd=r,env=env,stdout=out,stderr=err);write('START.json',dict(pid=c.pid,argv=argv,started=start,sha=sha));code=c.wait()
after={n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in before};write('source-after.json',after)
cases=[]
for x in ET.parse(b/'results.xml').getroot().iter('testcase'):
 cases.append(dict(id=x.get('classname')+'::'+x.get('name'),status=next((c.tag for c in x if c.tag in ('failure','error','skipped')),'pass')))
v=dict(sha=sha,returncode=code,elapsed=time.time()-start,source_files=len(before),source_unchanged=before==after,head_unchanged=sha==subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),git_clean=not subprocess.check_output(['git','status','--porcelain'],cwd=r),counts={s:sum(x['status']==s for x in cases) for s in ('pass','failure','error','skipped')},testcases=cases,argv=argv)
write('RESULT.json',v);print(json.dumps(v))
