"""Read only sealed ordinary fixture outputs after terminal pytest."""
from pathlib import Path
import hashlib,json,collections
ROOT=Path('/workspace/production-admission-evidence-20261015/regression/final2cb')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
result=load(ROOT/'RESULT.json'); collection=load(ROOT/'COLLECTION.json')
expected={n.split('::')[0][:-3].replace('/','.')+'::'+'::'.join(n.split('::')[1:]) for n in collection['nodeids']}
actual={x['id'] for x in result['testcases']}
ui=[]
for p in sorted((ROOT/'tmp').glob('test_project_page_exact_cancel*/result.json')):
 if p.parent.is_symlink():continue
 x=load(p)
 ui.append({'path':str(p.relative_to(ROOT)),'sha256':digest(p),'status':x['status'],
  'checks':len(x['checks']),'actions':len(x['actions']),'requests':len(x['requests']),
  'assets':len(x['static_resource_loads']),'boots':len(x['boots']) if isinstance(x['boots'],list) else x['boots'],
  'assets_all_200':all(a['status']==200 for a in x['static_resource_loads'])})
claims=[]
for p in sorted((ROOT/'tmp/test_two_apps_partial_then_com0').glob('worker-claims-*.json')):
 x=load(p)
 claims.append({'path':str(p.relative_to(ROOT)),'sha256':digest(p),'run_id':x['run_id'],
  'run_seconds':x['accepted_clock']['deadline']-x['accepted_clock']['created_at'],
  'lease_seconds':x['settings_lease_seconds'],'max_claims':x['max_claims'],
  'actual_claims':len(x['claims']), 'states':[{'before':c['before']['status'],'after':c['after']['status'],
  'after_fence':c['after']['fence']} for c in x['claims']]})
chains=[]
for p in sorted((ROOT/'tmp').glob('*/actual-combined-admission-budget.json')):
 if p.parent.is_symlink():continue
 x=load(p); a=x['accounting']; ledger=a['ledger']; slots=ledger['slots']
 stamps=[s['reserved_at'] for s in slots]
 chains.append({'path':str(p.relative_to(ROOT)),'sha256':digest(p),
  'source_admission_sha256':x['admission_sha256'],'source_budget_sha256':x['budget_sha256'],
  'slot_count':len(slots),'slot_ids_unique':len(set(x['slot_ids'])),
  'stage_runs':ledger['stage_runs'],'stage_count':dict(collections.Counter(s['reservation']['stage'] for s in slots)),
  'reserved_requests':a['reserved_requests'],'reserved_envelope':a['reserved_envelope'],
  'total_tokens':a['total_tokens'],'usage_status':a['usage_status'],
  'all_slots_accepted':all(s['accepted'] for s in slots),'reservation_gaps':[b-a for a,b in zip(stamps,stamps[1:])],
  'all_permits_synthetic_not_live':all(p['scope']=='SYNTHETIC_ONLY' and not p['live_allowed'] for p in x['permits'])})
summary={'sha':result['sha'],'terminal_counts':result['counts'],'xml_sha256':result['xml_sha256'],
 'collection_xml_bijection':expected==actual,'missing_in_xml':sorted(expected-actual),'unselected_in_xml':sorted(actual-expected),
 'unique_ids':result['unique_ids'],'source_file_count':len(load(ROOT/'source-before.json')),
 'source_closure':all(result[k] for k in ['source_unchanged','executed_source_equal','head_unchanged','worktree_clean']),
 'original_two_app_claims':claims,'ui':ui,'ui_totals':{k:sum(x[k] for x in ui) for k in ['checks','actions','requests','assets','boots']},
 'actual_synthetic_worker_chains':chains,
 'third_seven_slot_case':{'nodeid':'tests/test_natural_trial_budget.py::test_seven_actual_reservations_stage_binding_nontransfer_no_refund','worker_model_chain':False,'ordinary_store_reserve_settle_heartbeat':True,'original_source_asserted_known_tokens':14,'original_source_asserted_reserved_envelope':7868,'fixture_json_receipt':'NOT_EXPORTED_BY_ORIGINAL_TEST'},
 'old_database_read':False,'real_models':0,'native_browser':'NOT_RUN','PG':'NOT_RUN','Windows':'NOT_RUN'}
(ROOT/'SUPPORTING_CHECKS.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
