"""Separate-process original-key recovery, synthetic SQLite only."""
import json
import os
import subprocess
import sys
from dataclasses import replace
from pathlib import Path

from conftest import env  # noqa: F401
from sqlalchemy import select, update
from test_natural_live_admission import records
from test_production_trial_admission import dispatch, trial  # noqa: F401

from sim2act import production_trial_admission as production
from sim2act.db import runs


def test_unknown_cancel_original_key_recovers_in_separate_process(trial, tmp_path):
    data, contract, approval, job, registry, wire, request = trial
    first = dispatch(trial, registry=replace(registry,
        sender=production.OfflineSender(outcome_unknown=True)))
    assert first['usage_status'] == 'UNKNOWN' and first['total_tokens'] is None
    assert first['reserved_requests'] == 1 and first['ledger']['halted'] is True
    with data[0].tx() as c:
        c.execute(update(runs).where(runs.c.id == job['id']).values(cancel_intent=True))
        before_runs = [dict(x) for x in c.execute(select(runs)).mappings()]
    before = records(data[0])
    payload = dict(database=str(data[0].engine.url), user=data[3], contract=contract.model_dump(),
        approval_key=approval.request_key, request=request, wire=wire.decode(), worker_id=job['worker_id'])
    code = '''import json,sys
from sim2act import natural_live_admission as gate
from sim2act import production_trial_admission as production
from sim2act.db import Store
p=json.load(sys.stdin)
s=Store(p['database'],test_only=True)
contract=gate.TrialContract.model_validate(p['contract'])
r=production.dispatch_offline(s,p['user'],contract,p['approval_key'],p['request'],p['wire'].encode(),registry=None,worker_id=p['worker_id'])
h=production.recover(s,p['user'],contract,p['approval_key'])
print(json.dumps(dict(duplicate=r['duplicate'],usage_status=r['usage_status'],total_tokens=r['total_tokens'],reserved_requests=r['reserved_requests'],reserved_envelope=r['reserved_envelope'],halted=r['ledger']['halted'],history_equal=h['ledger']==r['ledger'],live_allowed=False)))
s.engine.dispose()
'''
    child_env = {k: os.environ[k] for k in ('PATH', 'LANG', 'LC_ALL', 'TZ') if k in os.environ}
    child_env.update(PYTHONPATH=str(Path(production.__file__).parents[1]), PYTHONDONTWRITEBYTECODE='1')
    result = subprocess.run([sys.executable, '-c', code], input=json.dumps(payload),
        capture_output=True, text=True, env=child_env, timeout=30)
    assert result.returncode == 0, result.stderr
    value = json.loads(result.stdout)
    assert value == dict(duplicate=True, usage_status='UNKNOWN', total_tokens=None,
        reserved_requests=1, reserved_envelope=first['reserved_envelope'], halted=True,
        history_equal=True, live_allowed=False)
    assert records(data[0]) == before
    with data[0].tx() as c:
        assert [dict(x) for x in c.execute(select(runs)).mappings()] == before_runs
    (tmp_path/'cold-process-receipt.json').write_text(json.dumps(value,indent=2)+'\n')
