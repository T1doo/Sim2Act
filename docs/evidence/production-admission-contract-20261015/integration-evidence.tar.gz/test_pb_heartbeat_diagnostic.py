"""Original actual MOCK P-B seven-slot test, ordinary heartbeat observation only."""
import functools
import json
import threading
import time

from conftest import env  # noqa: F401
from test_pb_trial_admission import (
    test_pb_exact_same_trial_source_extraction_and_cold_seven_slots as original,
)

from sim2act.db import Store
from sim2act.errors import DomainError


def test_original_pb_with_heartbeat_events(env, monkeypatch, tmp_path):
    target = Store.heartbeat
    log = tmp_path/'heartbeat-events.jsonl'

    def event(value):
        try:
            value.update(at=time.time(), thread=threading.get_ident())
            with log.open('a') as f:
                f.write(json.dumps(value)+'\n')
        except Exception:
            pass

    @functools.wraps(target)
    def observed(store, worker_id, run_id=None, fence=None, lease_seconds=30, **kwargs):
        common = dict(worker_id=worker_id, run_id=run_id, fence=fence,
                      lease_seconds=lease_seconds)
        start = time.monotonic()
        event(dict(common, phase='begin'))
        try:
            result = target(store, worker_id, run_id, fence, lease_seconds, **kwargs)
        except BaseException as exc:
            event(dict(common, phase='error', elapsed=time.monotonic()-start,
                error=exc.public() if isinstance(exc, DomainError) else None,
                error_type=type(exc).__name__,
                sqlite_errorcode=getattr(getattr(exc,'orig',None),'sqlite_errorcode',None)))
            raise
        event(dict(common, phase='return', elapsed=time.monotonic()-start,
                   renewed_until=result))
        return result

    monkeypatch.setattr(Store, 'heartbeat', observed)
    original(env, monkeypatch, tmp_path)
