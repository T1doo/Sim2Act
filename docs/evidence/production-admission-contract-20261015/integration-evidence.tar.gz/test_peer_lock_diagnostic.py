"""Original cancellation assertion, one call each; observation only, no clock faults."""
import functools
import json
import threading
import time
from pathlib import Path

from conftest import env  # noqa: F401
from sqlalchemy import select
from test_project_natural_revalidation import test_late_project_change_no_partial_save as original

from sim2act import app_jobs, natural_spec_runtime, pa_spec_apps
from sim2act.db import Store, runs
from sim2act.errors import DomainError
from sim2act.worker import Worker


def test_original_peer_lock_with_metadata_timing(env, monkeypatch, tmp_path):
    log = tmp_path/'function-events.jsonl'
    lock = threading.Lock()
    def event(value):
        value.update(at=time.time(), thread=threading.get_ident())
        with lock:
            with log.open('a') as f:f.write(json.dumps(value,default=str)+'\n')
    def wrap(owner, name):
        target=getattr(owner,name)
        @functools.wraps(target)
        def observed(*args,**kwargs):
            stamp=time.monotonic();run=next((a for a in args if isinstance(a,dict) and str(a.get('id','')).startswith('run_')),None)
            label=owner.__name__+'.'+name
            event(dict(function=label,phase='begin',run=None if run is None else {k:run.get(k) for k in ('id','status','version','fence','lease_until','created_at','worker_id')}))
            try:r=target(*args,**kwargs)
            except BaseException as e:
                event(dict(function=label,phase='error',elapsed=time.monotonic()-stamp,error=e.public() if isinstance(e,DomainError) else dict(type=type(e).__name__,message=str(e))))
                raise
            metadata=None
            if isinstance(r,dict) and str(r.get('id','')).startswith('run_'):
                metadata={k:r.get(k) for k in ('id','status','version','fence','lease_until','created_at','worker_id')}
            elif type(r) in (int,float,bool) or r is None:metadata=r
            event(dict(function=label,phase='return',elapsed=time.monotonic()-stamp,result=metadata))
            return r
        monkeypatch.setattr(owner,name,observed)
    for owner,name in [(Worker,'process'),(Store,'claim'),(Store,'heartbeat'),(Store,'guard'),
        (app_jobs,'process_job'),(app_jobs,'lock_live'),(pa_spec_apps,'is_job'),
        (pa_spec_apps,'job_scope_gate'),(pa_spec_apps,'process_job'),
        (pa_spec_apps,'bound'),(pa_spec_apps,'commit_guard'),(natural_spec_runtime,'advance_model'),(natural_spec_runtime,'fail_owned')]:wrap(owner,name)
    try:original(env,'peer_lock')
    finally:
        with env[0].engine.connect() as c:
            header=[dict(x) for x in c.execute(select(runs.c.id,runs.c.status,runs.c.cancel_intent,runs.c.version,runs.c.fence,runs.c.worker_id,runs.c.lease_until,runs.c.created_at,runs.c.error)).mappings()]
        event(dict(function='diagnostic',phase='final_headers',headers=header))
