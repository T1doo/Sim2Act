"""Write reviewable documentation only after the frozen terminal audit passes."""
import json
from pathlib import Path
base=Path('/workspace/production-admission-evidence-20261015');repo=Path('/workspace/Sim2Act-pa-provider');i=base/'integration'
a=json.loads((i/'TERMINAL_AUDIT.json').read_text());s=json.loads((base/'regression/final206/SUPPORTING_CHECKS.json').read_text());q=json.loads((base/'regression/quality206/RESULT.json').read_text())
assert a['PASS']==339 and a['FAIL']==a['ERROR']==a['SKIP']==a['deselected']==0
assert a['source_sha']==s['sha']==q['sha']=='206de555e22c9a6e85c1ea87a33c1e55c0780968'
assert all(q['commands'][k]['returncode']==0 for k in ('ruff_fullsrc','ruff_changed','node_product','node_fixture'))
assert q['mypy_prior_exact_errors_equal'] and not q['mypy_new_errors'] and len(q['mypy_errors'])==5 and len(q['changed_python'])==12
probe=json.loads((base/'regression/local-atomic-probe/RESULT.json').read_text())
assert probe['sha']==a['source_sha'] and probe['returncode']==0 and probe['counts']=={'pass':35,'failure':0,'error':0,'skipped':0}
t=(i/'DELIVERY_TEMPLATE.md').read_text()
terminal=f"冻结版本完整批 **339 PASS / 0 FAIL / 0 ERROR / 0 SKIP / 0 deselected**，RC0；{a['elapsed_seconds']:.2f}秒。339 unique，原199/306/318用例标识均保留；仅原七槽测试清理顺序作精确修正，其余14个原测试文件字节不变，新增local写组21与route8及既有TXT/MD4分支；collection↔XML逐项双射。{a['source_files_verified']}文件执行前后、拷贝执行源码、root与Git字节一致。XML SHA256 `{a['xml_sha256']}`；RESULT SHA256 `{a['result_sha256']}`。5ed版本独立探针14PASS另列，不累加339。"
u=s['ui_totals'];claims=s['original_two_app_claims'];chains=s['actual_synthetic_worker_chains']
assert len(claims)==2 and all(c['actual_claims']==1 and c['lease_seconds']==30 and c['max_claims']==3 for c in claims)
assert len(chains)==2 and all(c['slot_count']==7 and c['all_slots_accepted'] and c['all_permits_synthetic_not_live'] for c in chains)
assert all(c['run_seconds']==300 and len(c['states'])==1 and c['states'][0]['after']=='SUCCEEDED' and c['states'][0]['after_fence']==1 for c in claims)
assert len(s['ui'])==8 and all(x['status']=='PASS' and x['assets_all_200'] for x in s['ui'])
assert all(c['stage_count']=={'generate':3,'source':2,'cold':2} and c['total_tokens']==7000 and c['reserved_envelope']==48354 and c['usage_status']=='KNOWN' and len(c['reservation_gaps'])==6 and all(g>=60 for g in c['reservation_gaps']) for c in chains)
supporting=f"原两应用分段后完成用例，两次CHECK各实际领取1次并SUCCEEDED，原Run300/lease30/maxclaims3不变。原三项七槽用例均PASS：实际MOCK P-A与P-B各Generate3/Source2/Cold2，7 accepted/KNOWN7000 tokens/envelope48354；每条六个预留间隔均≥60秒。第三例为Store实际reserve/settle/heartbeat非模型链，14tokens/envelope7868，由原断言核验，原测试没有JSON导出。\n\n进程内HTTP/JSDOM页面8例：{u['checks']}检查、{u['actions']}操作、{u['requests']}请求、{u['assets']}静态资源、{u['boots']}启动，资源全200；不称原生浏览器。9f版本独立冷进程补充探针1PASS仅证明cancel_intent后的原key重复恢复UNKNOWN/null、不重发/不退槽；子进程PID未记录、非Worker终态CANCELLED、仅delivery_graph_requests/runs全行前后相同，不归入新版339。"
review="独立只读审查已核实际接口/默认拒绝、合成账户与来源合同、namespace修复位置、84模块精确资格、质量、5ed14例独立探针及206原子写组v3/35例独立探针；完整339终态与最终成稿审查见证据内独审报告。先前静审漏掉namespace缺门已明确记录，不能用旧静审结论覆盖实际失败。"
for token,value in [('@@TERMINAL@@',terminal),('@@SUPPORTING@@',supporting),('@@REVIEW@@',review)]:
 assert token in t;t=t.replace(token,value)
p=repo/'docs/F2/ProductionAdmissionContract20261015.md';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(t)
o=repo/'docs/evidence/production-admission-contract-20261015';o.mkdir(parents=True,exist_ok=True)
roots=['author','pb-author','regression','review','cold-probe','integration','cancel-diagnostic','route-before','route-before2','route-fixed','route-family-fixed','route-local-fixed','peer-lock-diagnostic','peer-lock-diagnostic2','budget-cleanup-probe','pb-heartbeat-diagnostic']
readme='# 生产准入与P-B来源合同有限工程证据\n\n冻结源码 `'+a['source_sha']+'`，339PASS0FAIL/ERROR/SKIP/deselected。同版339与独立探针不累加，真实LIVE默认拒绝。\n\n[交付报告](../../F2/ProductionAdmissionContract20261015.md)。[归档哈希](ARCHIVES.json)；每包都有逐成员大小/SHA256清单，打包后逐字节读取并与原文件比对。\n\n'
for root in roots:readme+='- ['+root+'归档]('+root+'-evidence.tar.gz) · [成员清单]('+root+'-MANIFEST.json)\n'
readme+='\nregression/final47e保留137PASS1FAIL/180未完成/pytestRC2及494文件封印，不能称318完整通过。regression/local-atomic-probe为206独立35例，不能累加完整339。regression/final5ed保留完整314PASS4FAIL及494文件封印，不能拼接任何独立探针。budget-cleanup-probe为修正后1PASS，pb-heartbeat-diagnostic为正常P-B1PASS并保留证明边界。regression/final保留9f305PASS1FAIL；route-fixed保留a612PASS1FAIL；route-before保存首次受控probe setup ERROR，route-before2保存旧路由受控1FAIL；route-family-fixed为2cb13PASS；route-local-fixed为5ed14PASS。regression/final2cb保留主动中断的123PASS1FAIL、194未完成及runner解析错误，不能计为完整318。peer-lock-diagnostic保留setup ERROR，peer-lock-diagnostic2为2cb正常时钟1PASS且未重现历史。integration含精确冻结/资格/collection/终态审计/旧失败DB只读摘录与全部运行脚本，review含原与恢复后独审。PG/Windows/原生浏览器/真实模型费用/可信真实权益解析器/生产sender/P-B真实归档resolver/完整真实P-A-P-B/人工语义/远端CI/部署NOT RUN或NOT IMPLEMENTED。整体NOT_ACCEPTED。\n'
(o/'README.md').write_text(readme)
print(p)
