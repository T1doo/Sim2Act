# Independent separate-process recovery evidence review

Supplemental external probe on frozen product SHA 9f64cca316935de1fc160a39c468a786ba610051: actual 1 PASS, 0 FAIL/ERROR/SKIP, exit 0; JUnit 4.618 sec. This is separate evidence and is not added to the original 306-case batch. Reviewer did not run or repeat tests.

Reviewed fixed external test source/hash, exact command, terminal raw streams/hash, JUnit and actual child receipt. The test first deducts one offline UNKNOWN slot, then sets cancel_intent. A literal subprocess.run launches another Python interpreter, instantiates a new Store on the same isolated SQLite database, calls dispatch_offline with registry=None and original frozen request key, and reads recover. Successful assertions establish duplicate=true, UNKNOWN total_tokens=None, one unchanged reserved slot/envelope, halted=true, equal original ledger and no LIVE allowance. No sender or network transport exists on this path. A child-specific PID was not recorded; none is inferred.

The parent compares all delivery_graph_requests rows (the records helper) and all runs rows before/after the child; both are unchanged. This does not assert all other database tables are unchanged. Cancellation is an intent in this fixture, not a full real LIVE Worker terminal-cancellation scenario.

Independently recomputed all 492 frozen source/test/pyproject file hashes against both current root files and git show of the exact frozen SHA; all match. The child used current root product source. Product implementation remained the same. Detailed hashes, receipt and scope are in COLD_PROBE_CHECKS.json.
