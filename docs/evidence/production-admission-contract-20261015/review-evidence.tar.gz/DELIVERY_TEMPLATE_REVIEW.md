# Delivery template pre-review

Reviewed integration/DELIVERY_TEMPLATE.md as an incomplete template only, while the original 306 process remains active. TERMINAL/SUPPORTING/REVIEW placeholders are pending and are not PASS findings.

Engineering boundaries, synthetic/live distinction, source resolver NOT_IMPLEMENTED status, no registration/call permission, quality baseline and historical failure separation are accurate. Two wording corrections were sent to root:

1. Each offline admission first resolves synthetic account/software, then executes the original gate, expected worker check and extra PB bridge. Avoid implying original gate runs before account resolution.
2. The DB PB bridge compares actual stored wire SHA/byte-count metadata against fixture wire bytes, and actual archived received_raw complete bytes against fixture response bytes. It does not read a persisted full wire body from actual Attempt parameters. Say wire hash/byte count, full archived raw response bytes and usage, rather than implying both complete byte bodies are independently read from DB.

The separate-process probe should remain one supplemental PASS outside306, specify cancel_intent rather than full Worker terminal cancellation, compare only delivery_graph_requests/runs tables, and avoid inventing a child PID. Final filled delivery document and terminal metrics still need independent review.
