# Independent design conditions

Read-only baseline review at 255b6ac407ebad31aedbe1b8d9547ee3892cdc0f. No tests or network invoked; no credentials read. Reviewed natural_live_admission.py, natural_trial_budget.py, natural_trial_api.py, db.guard/frozen_contract and original V5 F1-T06/F2-T03/F3-T05.

The existing SyntheticOnlyFeeAuthority exact-class gate, test_only SQLite confinement, live_allowed=false permit and MOCK Attempt checks cannot be converted into production entitlement by changing a mode tag. New production wiring must be separately fail closed.

Minimum final-review checks:

1. Public DTOs cannot instantiate a resolver, fee authority, sender, free label or trusted account evidence. The server resolves authenticated principal/account identity to the canonical quota subject; an arbitrary caller-supplied subject cannot partition the account rate limit.
2. Missing reviewed sender or independently verified legal entitlement plus enforced non-chargeability rejects before Run/Attempt/budget/quota writes. An endpoint accepting a contract must not treat that frozen declaration as the account resolver's proof.
3. Pre-send checks must be executed fresh for the exact attempt, inside the actual accounting/owner transaction. Approval/revocation, complete materials and Goals, software qualification, Run principal/project/runtime/version/fence/owner/lease/cancellation and bounded original 3+2+2 accounting are conjunctive. Callback time/writes cannot extend the authority of an earlier snapshot. Read/check endpoints do not mint reusable dispatch capabilities.
4. reserve's duplicate result is historical only. It must never cause a second sender call. One request key binds immutable wire hash/bytes, attempt, stage, trial/account/contract and slot. A failed/unknown sender call must persist the charge and block progression; no automatic retry or quota refund.
5. Late settlement preserves actual usage but cannot regain accepted=true after cancellation/revocation/lease/version drift. UNKNOWN stays UNKNOWN until original-key evidence recovery; a new request is not recovery. Recovery is accounting only and cannot authorize a resend.
6. P-B real provenance must bind the same trial's completed source Run, all source attempts, their original response and wire evidence, trusted usage source/account, extraction key, complete edited Recipe, distinct new cold material and full Goal. Hash equality alone is not original provenance; expected vs independently persisted actual values must be compared. MOCK source attempts fail real-source validation even when copied into a LIVE-tagged candidate.

Minimal counterexamples for isolated fixture tests: mismatched resolved account vs subject; same account across projects/trials; revoked approval after resolver returns; resolver changes contract/mode/free label; missing sender before any writes; source Attempt from another trial/account; response/usage swapped between source Attempts; stale owner/version/fence/lease; duplicate after unknown; cancellation during sender callback followed by late usage; cold restart reads original key without sender call or accepted-state restoration.

Status: design conditions only, not implementation acceptance or LIVE authority. Await frozen implementation and actual same-SHA test evidence.

## Early author-worktree review (mutable drafts, not final acceptance)

- Gate draft `_resolve`: canonical mapping must cover all OfflineRegistry accounts. Matching one `(principal, project, trial, contract)` record and comparing its subject with caller contract does not stop the same account_id from using two subjects in two trials.
- Gate draft `_admission`: bind expected worker_id here, so reserve, pre-dispatch and settle all recheck it inside their transaction. Standalone worker checks before reserve and before canned send leave owner drift outside settlement acceptance.
- PB draft SourceEvidence/ResponseEvidence/SourceSlotEvidence carry trial_key, but not the full originally approved contract/approval fingerprint. Same key with altered software/authorization/expiry and unchanged material/Recipe is not the exact original approved trial. Add original archive-bound full trial identity and negative test.
- PB draft response and two source slots do not independently prove full original generate3/source2/cold2 ledger or envelope. Do not describe them as that full proof. Gate integration must preserve the original accounting proof rather than treating a source-only receipt as dispatch authority.

These are concrete draft review findings sent to root; production default remains denied. Fix and final frozen-source verification pending.

## Mutable-draft follow-up

Gate author added canonical `(provider, account_id) <-> quota_subject` validation and moved worker identity checks into the admission closure used by reserve, fresh check and settlement. These two early findings are code-addressed; actual tests and frozen review pending.

New PB-bridge finding: `_source` must compare its source contract approval key to the controller's actual approval key and its source Run to the original budget ledger's stage_runs.source. A full trial match plus fixture account match still permits the additional source receipt to describe a different Run. Preserve the existing gate's independently audited actual source lineage and bind the receipt to it. Put this bridge inside the fresh admission closure for settlement as well; the receipt is never a real archive resolver or production authority.

## Gate draft 011aac follow-up, integration blockers

The controller now binds approval_key, ledger stage_runs.source, two actual Attempt IDs, source app and source-slot hashes/usage. However the actual DB Attempt mode/status are not checked in `_source`: a fixture LIVE ResponseEvidence copying a real MOCK Attempt's hashes and usage can satisfy the added bridge. The later existing gate deliberately requires actual MOCK; it cannot be cited as proof of LIVE archive origin. Add explicit actual LIVE/VERIFIED provenance checks, preserving existing MOCK gate and default-denied live path. A successful actual LIVE bridge remains NOT_RUN while no real archive resolver exists.

The new gate test file at this draft has no PB-bridge case. The separate 64 puretyped PB tests do not execute `_source`. Require direct controlled tests for the bridge's DB join/refusal branches, including MOCK relabel, wrong approval/source Run, malformed usage and late settlement. Root also identified unchecked usage shape before gate.admit can raise TypeError/KeyError and roll back settlement rather than preserve unaccepted actual cost; this needs DomainError fail closure and evidence.
