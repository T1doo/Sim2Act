# First marker static triage — no root-cause conclusion

Frozen source 9f64cca316935de1fc160a39c468a786ba610051, original full306 continues. Reviewed integration/first_failure_9f64/OBSERVATION.json: one failure marker at collected index112, tests/test_project_natural_revalidation.py::test_late_project_change_no_partial_save[cancel]. The marker identifies the case, not the failed line or cause. Terminal stack/XML pending. Current gate is FAILED pending diagnosis, not an all-pass candidate.

Read-only source trace: this case first creates the two-app cohort, freezes the plan and starts one check. Its MockTransport appends sent payload, validates fixed synthetic prompt expectations, and only then invokes mutate; cancel's mutate uses an independent Store.tx to set the accepted Run cancel_intent=True before returning a fixed HTTP200 response. It calls Worker.once once, then checks no check-instance output row, exactly two Releases, exactly one sent request and the final historical plan read condition.

The cancel case has no tmp_path parameter and writes no custom JSON receipt. The public first-two-app receipt is a different completed case. Before terminal stack, it is unknown whether this case reached the cancellation mutator or failed earlier in cohort/plan/start/helper/Worker, or at a final assertion. No inference of performance/lease/root cause is supported by a dot/F marker.

Reviewer did not read or write the running fixture database, insert hooks, start a reproduction or any other test, or change frozen source. On terminal, examine exact failure line and exception first; preserve raw output and distinguish setup failure, domain rejection, liveness and forbidden partial write assertions.
