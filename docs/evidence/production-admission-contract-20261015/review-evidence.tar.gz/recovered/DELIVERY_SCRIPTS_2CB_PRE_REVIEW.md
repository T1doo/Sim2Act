# Delivery/audit/package scripts pre-execution review

Reviewed integration/write_delivery.py, audit_terminal.py, summarize_final.py and package.py while full final2cb318 remains running. Scripts were not executed by reviewer. No active fixture DB access.

Core structure is suitable: generation requires exact2cb source SHA and318 all-pass terminal; original199 and306 membership/318 uniqueness are preserved; separate route8/text4 scope is explicit; archive records member names/lengths/hashes and reads every regular member back against the original, with cache/symlink exclusions and PACKAGE_RESULT recursion exclusion. Supplemental9f cold-process caveats are accurate and counts are not accumulated into318. Final doc and terminal data still require review.

Two actionable pre-delivery gaps were sent to root:

1. The first route-before setup ERROR's stdout/stderr live at evidence-root route-before.stdout / route-before.stderr, whereas package.py collects only the route-before directory (currently only XML). Preserve originals and include byte-identical copies with source/copy hash receipt in that directory or add those regular files explicitly. Otherwise the archive omits the complete original setup error streams.
2. write_delivery hardcodes several metrics not currently asserted in its input: chain stage3/2/2, KNOWN7000/envelope48354 and six>=60sec gaps; two claims SUCCEEDED/fence1/Run300; UI8 and every asset200. summarize_final only extracts these fields. Validate these exact sealed values before writing claims or generate text directly from the validated fields, rather than relying on an assumed unchanged test contract.

Additional audit hardening recommended: require exact pinned2cb SHA within audit_terminal itself, and independently count XML status elements against RESULT counts, beyond existing ID bijection/hash/RC checks. These do not require product/test changes or a new test run.

These are reporting/archival issues in not-yet-run scripts, not new failures of the running318 batch. Original test scope, budgets and frozen source remain untouched. Re-review corrections and final generated artifacts before normal push.
