# Routing probe failure and scoped fix placement

Actual `route-fixed` terminal on a6a8e006a5ede0655b4131c4d2b9a57af397e537: **12 PASS / 1 FAIL**, exit1. The failure is new actual-fixture `namespace` case: `assert sent == []` at test line107 observed one synthetic MockTransport payload. This is a real failing negative test, not an all-pass candidate. The previous static no-P1/P2 conclusion is limited by this subsequent execution finding. Preserve raw probe and do not weaken the zero-send assertion.

The test corrupts only current `app_drafts.candidate.namespace` to an unknown string; the existing immutable Release retains its legitimate frozen natural candidate. Actual bound validation primarily validates that frozen candidate. PA `scope_gate` can still independently identify the app as spec through original task/extraction/generation/ledger markers and authorize its resource, but currently does not require its current projected namespace to be one of the supported FAMILIES. Both old classifier and new direct route ultimately use this gate, so this evidence does not establish a newly introduced routing-only bypass.

Minimal safe placement for the proposed family-membership check is **after** the PB branch and after the existing non-spec false-return classifier:

```
if not ((location and (...)) or kind == KIND or gen in GENERATIONS or ledger is not None):
    return False
require(location is not None)
require(location['family'] in FAMILIES, ...)
```

Do not add it unconditionally in the broad initial `if hinted:`. That hint includes `confirmed is not None`, and goal_application_candidates also stores legitimate non-spec generated applications; those must still be allowed to return False from this family's classifier and take their own route. The narrow confirmed-spec branch is the right point to require a supported current family. Existing PB scope already checks `kind == KIND and location['family'] == natural.VERSION and location['task'] == KIND`, so no PB change is required here.

Membership in both supported FAMILIES permits independently valid current draft evolution while a Run uses its immutable older Release. Do not require current draft equality or namespace equality with the frozen Release: that would introduce a stronger cross-version constraint unrelated to this finding. Full current resource/owner/source checks and frozen Release proofs remain necessary. Add/retain actual non-spec Goal-generated compatibility evidence and valid FAMILIES transition evidence where existing contracts permit those transitions, then rerun the failed negative unchanged. A later probe pass does not replace same-SHA full regression.

Reviewer read terminal evidence/static code only, without test runs, fixture DB access or product edits.
