import ast,collections,hashlib,json,subprocess,xml.etree.ElementTree as ET
from pathlib import Path
B=Path('/workspace/production-admission-evidence-20261015');b=B/'regression/final206';repo=Path('/workspace/Sim2Act-pa-provider');sha='206de555e22c9a6e85c1ea87a33c1e55c0780968'
def j(p):return json.loads(p.read_text())
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
r=j(b/'RESULT.json');c=j(b/'COLLECTION.json');cmd=j(b/'COMMAND.json');assert r['sha']==cmd['sha']==sha;assert j(b/'PROCESS_EXIT.json')['pytest_returncode']==r['returncode']==0
cases=list(ET.parse(b/'results.xml').getroot().iter('testcase'));ids=[x.attrib['classname'].replace('.','/')+'.py::'+x.attrib['name'] for x in cases];assert len(ids)==len(set(ids))==len(c['nodeids'])==339 and collections.Counter(ids)==collections.Counter(c['nodeids']) and all(not list(x) for x in cases);assert r['counts']=={'pass':339,'failure':0,'error':0,'skipped':0} and not r['unnamed_xml_entries']
old318=j(B/'regression/final47e/COLLECTION.json')['nodeids'];old306=j(B/'regression/final/COLLECTION.json')['nodeids'];old199=j(Path('/workspace/complete-regression-evidence-20261015/final0b6a/COLLECTION.json'))['nodeids'];assert c['nodeids'][21:]==old318 and all(n.startswith('tests/test_natural_local_write_group.py::') for n in c['nodeids'][:21]);assert len(old199)==199 and len(old306)==306 and set(old199)<=set(ids) and set(old306)<=set(ids)
a=j(b/'source-before.json');assert a==j(b/'source-after.json')==j(b/'executed-source-manifest.json') and len(a)==495
for n,w in a.items():assert h(repo/n)==h(b/'executed-source'/n)==hashlib.sha256(subprocess.check_output(['git','show',sha+':'+n],cwd=repo)).hexdigest()==w
for k,n in [('xml_sha256','results.xml'),('stdout_sha256','stdout.log'),('stderr_sha256','stderr.log')]:assert r[k]==h(b/n)
files=sorted({n.split('::')[0] for n in old199});assert len(files)==15
for n in files:
 raw=subprocess.check_output(['git','show','255b6ac407ebad31aedbe1b8d9547ee3892cdc0f:'+n],cwd=repo)
 if n!='tests/test_natural_trial_budget.py':assert hashlib.sha256(raw).hexdigest()==a[n]
 else:
  assert hashlib.sha256(raw).hexdigest()=='6694714986db64e73a8487aac1a128026717ada8abe6963ce08b8876c4876468' and a[n]=='b821b3b8ed58d72c4779800d1e81f99668213abf475e6d7c76a1bb5fae5c8692'
  t1=ast.parse(raw);t2=ast.parse((repo/n).read_bytes());changes=[(x,y) for x,y in zip(t1.body,t2.body) if ast.dump(x)!=ast.dump(y)];assert len(t1.body)==len(t2.body) and len(changes)==1 and changes[0][0].name=='test_seven_actual_reservations_stage_binding_nontransfer_no_refund';x,y=changes[0];assert collections.Counter(ast.dump(z) for z in ast.walk(x) if isinstance(z,ast.Assert))<=collections.Counter(ast.dump(z) for z in ast.walk(y) if isinstance(z,ast.Assert))
s=j(b/'SUPPORTING_CHECKS.json');u=s['ui_totals'];assert u==dict(checks=119,actions=143,requests=895,assets=189,boots=9);assert len(s['ui'])==8
for x in s['ui']:
 p=b/x['path'];assert h(p)==x['sha256'];raw=j(p);assert raw['status']=='PASS' and all(z['status']==200 for z in raw['static_resource_loads']);assert len(raw['checks'])==x['checks'] and len(raw['actions'])==x['actions'] and len(raw['requests'])==x['requests']
claims=s['original_two_app_claims'];assert len(claims)==2
for x in claims:
 assert h(b/x['path'])==x['sha256'];raw=j(b/x['path']);assert len(raw['claims'])==1 and raw['claims'][0]['after']['status']=='SUCCEEDED' and raw['claims'][0]['after']['fence']==1;assert raw['settings_lease_seconds']==30 and raw['max_claims']==3 and raw['accepted_clock']['deadline']-raw['accepted_clock']['created_at']==300
chains=s['actual_synthetic_worker_chains'];assert len(chains)==2
for x in chains:
 assert h(b/x['path'])==x['sha256'];raw=j(b/x['path']);acct=raw['accounting'];slots=acct['ledger']['slots'];assert len(slots)==7 and all(z['accepted'] for z in slots);assert collections.Counter(z['reservation']['stage'] for z in slots)=={'generate':3,'source':2,'cold':2};assert acct['total_tokens']==7000 and acct['reserved_envelope']==48354 and acct['usage_status']=='KNOWN';assert min(y['reserved_at']-z['reserved_at'] for z,y in zip(slots,slots[1:]))>=60;assert all(z['scope']=='SYNTHETIC_ONLY' and not z['live_allowed'] for z in raw['permits'])
q=j(B/'regression/quality206/RESULT.json')
for n,v in q['commands'].items():
 for stream in ('stdout','stderr'):assert h(B/'regression/quality206'/(n+'.'+stream))==v[stream+'_sha256']
 assert v['returncode']==(1 if n=='mypy' else 0)
errors=lambda p:[z for z in p.read_text().splitlines() if ': error:' in z];assert errors(B/'regression/quality206/mypy.stdout')==errors(B/'regression/quality/mypy.stdout')==q['mypy_errors'] and len(q['mypy_errors'])==5 and not q['mypy_new_errors']
report=repo/'docs/F2/ProductionAdmissionContract20261015.md';readme=repo/'docs/evidence/production-admission-contract-20261015/README.md'
out={'source_sha':sha,'PASS':339,'FAIL':0,'ERROR':0,'SKIP':0,'deselected':0,'actual_exit':0,'339unique_collection_xml_exact':True,'new21_then_original318_exact_order':True,'old199_and306_ids_retained':True,'original14_files_byte_identical_cleanup_only_function_and_all_original_asserts_retained':True,'495before_after_copied_root_git_exact':True,'actual_ui_totals':u,'two_checks_claim1_fence1_SUCCEEDED_original300_30_3':True,'actual_PA_PB_each7accepted_KNOWN7000_envelope48354_gaps60':True,'mypy_original5_new0':True,'xml_sha256':h(b/'results.xml'),'result_sha256':h(b/'RESULT.json'),'delivery_report_sha256':h(report),'readme_sha256':h(readme),'elapsed_seconds':r['elapsed'],'full_product_acceptance':False}
(B/'review/recovered/FINAL_206_TERMINAL_CHECKS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
