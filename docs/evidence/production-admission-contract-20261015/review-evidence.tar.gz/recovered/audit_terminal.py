"""Read-only independent terminal evidence audit; never launches tests."""
import hashlib,json,subprocess,collections,xml.etree.ElementTree as ET
from pathlib import Path
B=Path('/workspace/production-admission-evidence-20261015/regression/final')
O=Path('/workspace/production-admission-evidence-20261015/review/recovered')
R=Path('/workspace/Sim2Act-pa-provider')
SHA='9f64cca316935de1fc160a39c468a786ba610051'
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def j(n):return json.loads((B/n).read_text())
r=j('RESULT.json');c=j('COLLECTION.json');cmd=j('COMMAND.json')
assert r['sha']==cmd['sha']==SHA
cases=list(ET.parse(B/'results.xml').getroot().iter('testcase'))
ids=[x.attrib['classname'].replace('.','/')+'.py::'+x.attrib['name'] for x in cases]
assert len(ids)==len(set(ids))==len(c['nodeids'])==306
assert collections.Counter(ids)==collections.Counter(c['nodeids'])
counts=collections.Counter('error' if x.find('error') is not None else 'failure' if x.find('failure') is not None else 'skipped' if x.find('skipped') is not None else 'pass' for x in cases)
assert all(r['counts'][k]==counts[k] for k in ('error','failure','skipped','pass'))
assert r['returncode']==(1 if counts['error']+counts['failure'] else 0)
for k,p in [('stdout_sha256','stdout.log'),('stderr_sha256','stderr.log'),('xml_sha256','results.xml')]:assert r[k]==h(B/p)
before=j('source-before.json');assert before==j('source-after.json')==j('executed-source-manifest.json');assert len(before)==492
for n,w in before.items():
 assert h(B/'executed-source'/n)==h(R/n)==w
 assert hashlib.sha256(subprocess.check_output(['git','show',SHA+':'+n],cwd=R)).hexdigest()==w
baseline=json.loads(Path('/workspace/complete-regression-evidence-20261015/final0b6a/COLLECTION.json').read_text())['nodeids']
assert len(baseline)==199 and set(baseline)<=set(ids)
assert len(set(ids)-set(baseline))==107
assert {n.split('::')[0] for n in set(ids)-set(baseline)}=={'tests/test_production_trial_admission.py','tests/test_pb_live_source_contract.py'}
fail=[]
for n,x in zip(ids,cases):
 for kind in ('failure','error'):
  e=x.find(kind)
  if e is not None:fail.append({'nodeid':n,'kind':kind,'message':e.attrib.get('message'),'stack':e.text})
result={'sha':SHA,'counts':dict(counts),'returncode':r['returncode'],'collected_xml_unique':306,'source_files_exact':492,'baseline_199_retained':True,'new_cases':107,'result_sha256':h(B/'RESULT.json'),'xml_sha256':h(B/'results.xml'),'failures':fail}
(O/'TERMINAL_CHECKS.json').write_text(json.dumps(result,indent=2)+'\n')
(O/'FAILURES.txt').write_text('\n\n'.join(x['nodeid']+'\n'+(x['stack'] or '') for x in fail)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='failures'},indent=2))
