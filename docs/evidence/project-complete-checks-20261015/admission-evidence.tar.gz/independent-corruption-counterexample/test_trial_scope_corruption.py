"""Fresh synthetic DB reproduction; no historical DB or actual provider."""
import copy
import pytest
from pydantic import ValidationError
from sqlalchemy import select, update
from conftest import env
from test_natural_trial_api import prepare
from sim2act import natural_live_admission as gate
from sim2act.db import delivery_graph_requests as rows, fingerprint

def test_original_scope_invalid_paired_schema_escapes_http(env):
    data, contract, body = prepare(env)
    store, client = data[0], data[2]
    path = f'/api/projects/{data[4]}/natural-trials/{contract.trial_key}'
    assert client.post(path + '/approval', json=dict(contract=contract.model_dump(),
        approval=body.model_dump())).status_code == 200
    with store.tx() as c:
        saved = c.execute(select(rows).where(rows.c.kind == gate.SCOPE)).mappings().one()
        snap = copy.deepcopy(saved['snapshot'])
        snap['request']['expires_at'] = 'malformed-persisted-value'
        snap['response']['expires_at'] = 'malformed-persisted-value'
        c.execute(update(rows).where(rows.c.kind.in_([gate.SCOPE, gate.SCOPE + '_seal']))
            .values(snapshot=snap, fingerprint=fingerprint(snap),
                    request_fingerprint=fingerprint(snap['request'])))
    with pytest.raises(ValidationError) as observed:
        client.get(path + '/approvals/' + body.request_key)
    assert observed.value.errors()[0]['loc'] == ('expires_at',)
    client.close()
