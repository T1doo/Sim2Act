# 有限双应用完整复验与 P-A/P-B 准入工程

当前冻结源码 `0b6a780c952fb6eeed5e545f0f6db5f8e64360e6`，集成分支 `dev/project-complete-checks-admission-20261015`。基线 `52654f7610602b7afc8a2c44eee7abc23e5c2d5d`；根单一集成者，作者、独审和回归使用隔离工作树与 SQLite 夹具。main/coredev 与其他工作树不修改。本文是交付草稿，原 2dda 整批已实际终态为 198 PASS / 1 FAIL / 0 ERROR / 0 SKIP；新 P-B cold Worker 结算 accepted=false，门禁 FAILED，不以 collection 或子批通过替代。诊断复现 commit 9b1a8f778041bed4a3d6d6ad453f4efa51719bf3 仅新增公开结算/原准入错误 JSONL，不改产品、原断言/预算/租约/真实 RPM，尚未修复或获最终通过。

## 具体修改与已知根因边界

普通 Worker 的 SAVE 将 typed/AppRun/terminal 写入组成同一事务写组，去掉两次重复全项目审计。初始完整授权读段只提前取得实例公开指针与版本；原 data_version/revision/release CAS 保留。真实 artifact 写入与读回后仍有完整 guard，末尾仍完整 source scope、verify_job、typed/实例/原模型审计、未知效果和当前授权检查。写组之间只核精确 owner/fence/version/原 lease 与新鲜 worker 模式、工具和截止预算，不新增跨事务授权证明缓存；最终仍重新读取并验证完整绑定与模型审计，不给过期 lease 续租。

原 `test_two_apps_partial_then_complete_checks_and_cold_account` 保持原断言、300 秒 Run、30 秒 lease、最多三次领取。旧 ce6 失败（peer 三次均 RUNNING、fence 1→3→5）源码/XML/时间线继续封存。526 原样本次普通运行完整 1 PASS（487.17 秒），计时运行完整 1 PASS（506.88 秒）；这些是旧源码结果，不计入新源码通过数。

计时运行实测 peer SAVE writer 锁 35.468639 秒，进入时原 lease 仅余 29.991211 秒，末尾已过期 5.477428 秒；同窗口三次后台 heartbeat 因 BEGIN IMMEDIATE 锁忙失败。最终原 lease 检查拒绝旧 fence，正常第二次领取完成。`PROFILE_OBSERVATION.json` 绑定原 JSONL/claims 哈希。这证明同类长写事务与租约失效机制，**没有自然复现旧三次领取全失败的完整事件，旧历史确切首因仍 UNKNOWN**，不承诺任意负载下 30 秒内完成。

受控 phase 测试明确为 FAULT_INJECTION：实际 Store/Worker/spec.advance 和原 300/30/3，在每次完整 SAVE scope 重验后推进八秒测试时钟。旧四次重验共 32 秒，三次领取均 RUNNING；新两次共 16 秒，首次领取成功。不是完整 Worker.once 自然历史复现或性能节省证据。旧另一注入尝试在 SAVE 前即遇到后台锁异常，segments 为空，失败保留，不能算 SAVE 机制证据。

独审发现后修复三个明确错误：后台已识别 SQLite BUSY/LOCKED 不再穿透终止 worker，结算仍按原 lease/owner/unknown 决定；损坏的原试验 scope GET 转为受控 409；新 SAVE public owner 查询缺失转为 VERSION_CONFLICT，避免 NoResultFound 穿透。其他意外异常仍抛出，不扩大重试、领取、预算或安全权限。修复前 counterexamples 和弱 budget=0 的首轮测试源码保留；当前有效预算收紧负测用 2，实际使用 3，明确验证错误码。

## 准入接口的有限工程范围

正常 API 挂载八个统一鉴权入口：精确批准、撤回、阶段预检/批准、准入及原 key 的批准/阶段/预算读取。GET 先核身份、项目及材料授权，再读取原成对合同，不接受替换合同。生产准入没有费用权威参数，默认拒绝；没有 reserve/sender 路由，没有开启 LIVE。

P-B 合同保留旧 P-A 序列化，额外冻结 P-B 路径、独立抽取 key 和完整编辑 Recipe。仍为同试验 Generate/Source/Cold 3+2+2 槽：来源必须是同总账原 source Run 的完整成功任务、两条 VERIFIED/MOCK/known/accepted Attempt；逐项关联真实 wire/raw 哈希、字节和 usage，再由既有完整抽取验证器核对来源/抽取/元数据与新 cold Goal/material。未知、被拒成本或其他试验来源不获资格。

可信 account→quota resolver、合法免费权益与强制不可收费 authority、经审发送器仍未注册。冻结 caller quota label、用户确认或 SYNTHETIC_ONLY 证明都不代表真实零收费。真实模型、凭据、费用、生产 LIVE 不运行。

## 单一源码回归与资格

冻结源码实际 collection 199 unique / 0 duplicate，包含原双应用6、取消10、恢复4、历史 UI8、准入34、预算28、精确资格22、租约4、心跳33、普通 P-B failures7、新 P-B trial1、HTTP8、受控 phase1、typed27、原 final transaction6。原单进程终态 198 PASS / 1 FAIL / 0 ERROR / 0 SKIP，199 unique / 0 deselection，4721.077 秒，完整 488 个 src/tests/pyproject 前后及 executed-source 与 Git 字节闭合。XML SHA256 193c5cd1b48467b8554a11069799624110536eaa9c4287c5f1655e116559f919。原双应用、两项旧七槽、UI8、HTTP8、phase1、typed27、原事务6都通过；新 P-B cold Worker 内 budget.settle 正常返回最后 accepted=false，为唯一失败，不结案或推送通过候选。

本轮已经完成的普通公开回执显示，原双应用两个 CHECK Run 都首次领取 SUCCEEDED/fence1，原 300/30/3 不变。UI8 逐例 JSON 全 PASS，共 119 内部检查、143 actions、897 API requests、189 assets、9 boots，属于进程内 HTTP/JSDOM，不是原生浏览器。这些回执属于原整批 198P/1F，不作为修复后新 SHA 的结果。

原2dda同SHA质量（不代替bb287新质量）：fullsrc Ruff PASS、11 个 changed Python 文件 Ruff PASS、两项 Node 语法 PASS；全库 mypy FAIL，仅 status_report.py 三条/tools.py 两条原5错误，逐行与原输出一致，没有新增错误。原2dda精确软件资格为完整 82 模块，config 仍按原规则排除；ANCHOR/CHANGED/旧来源和 baseline 不扩。pin `30e9a47083c8e9929cc267c5371c79d036230c7b8532f7e8e041127eee9d7d1b`，review_candidate `53e4f0b789b5424033a44b19e19f87ffd1a479af`，只规范化唯一 simple literal pin 为 zero64。独审资格22 PASS 单列，不与整批同样22重复计数。

已知 SQL/UDF 私有 barrier、原生浏览器拒绝路径不执行，不改名/改 hook 绕过；回归选择原有普通 API/Store/event/snapshot 病例。可选排除列表保留。执行环境重启后先核分支、文件和原 PID/终态，没有重复未知运行。

## 仍未验收

旧历史确切首因 UNKNOWN；2dda 完整整批唯一 P-B 失败待具体修复及新 SHA 全链。PG、干净 Win11、原生浏览器、真实模型/费用、独立人工语义、完整真实 P-A/P-B、真实旧源码升级、远端 CI 与部署 NOT RUN。工程局部交付不关闭 F1/F3/R0/C0：dependency completeness 仍 BLOCKED_UNKNOWN、owner PENDING、semantic UNKNOWN、formal publication false。

用户硬目标仍为北京时间 2026-10-22 00:08（UTC 2026-10-21 16:08），不是已核实赛事截止。原首版为 F1→F2→F3→R0→C0，不要求 F4–F7；P-A/P-B 是两条路径。真实非秘密零收费/账户证据、原生操作者/设备、授权材料与 owner/独立语义验收、官方规则/另一参赛项目身份等外部缺口仍由父级统一收集，不能以离线合成通过替代。

## P-B 失败后有限修改（新整批待终态）

2dda 唯一 P-B accepted=false 保留，原具体拒因仍 UNKNOWN。9b1a 仅公开诊断单例实际 1 PASS/0F/E/S（477.525秒、488字节闭合）；28事件包含21个 SYNTHETIC_ONLY/不允许 LIVE 的 permit与7个 accepted KNOWN结算，3+2+2/7000 tokens/48354 envelope，六次间隔均至少60秒。没有重现旧拒因，不作为产品修复证明或旧198通过的补数。

新代码 cadd1864e9f4da8209936edcf8b8e299a537a2e4 只减少同只读段已证重复验证：普通 spec_task binding 已经在 bound→verify_origin→pb.verify 完整验证精确 draft/conn/limits；snapshot包含 human_correction/logic_check/pb_use/pa_use 或 Release有 natural_logic_source 时仍执行原额外验证。来源原 trial、提取 key/Recipe、原Source2 Attempts、wire/raw/usage完整检查不动，不跨写边界复用证明。没有新增容量、耗时保证或真实零费许可。诊断另外保留原 budget._active 的公开错误后原样抛出，只记录已有 Run lease/created/deadline 标量，不增加读取、重试、续租或sleep。

新clean冻结bb287dceff767f8f5179e65c3d1a272e6fb0fcac，精确完整82 pin bcf48da5c3141eeaa35ad32543d34a48b14519b7e4f5f0e1772c701b61f41041，review_candidate cadd1864e9f4da8209936edcf8b8e299a537a2e4，原anchor/CHANGED/排除规则不扩。新 finalbb287 将实际执行同199全链，质量同SHA重跑；当前门禁仍PENDING，不能复用2dda/9b结果。

新bb287实际qualitybb287：fullsrc Ruff/11changed Python Ruff/Node两项语法 PASS；fullmypy FAIL5与旧输出逐行相同、无新增。独审BB287_PIN_REVIEW已核完整82/唯一ASTliteral/488文件/source delta，静态有限通过不代替新整批终态。

## bb287 真实整批与恢复准备修正

bb287原完整199终态198 PASS/1 FAIL/0 ERROR/0 SKIP，488源字节闭合，4749.329秒，XML6c1ff17443cb28f95e05bc0618fede902b77c52dfebb4237f103e0dad0558937。本轮三组七槽全部通过，P-A/P-B两实际mock Worker链各3+2+2 accepted/KNOWN7000/envelope48354，P-B35公开事件无拒绝/停止。UI8实际119检查、143 actions、878 requests、189 assets、9 boots；typed27与原事务6通过。唯一FAIL为恢复矩阵expired_return准备line59：取消返回RECONCILING，等待pause/cancel前旧lease后，Worker返回公开CANCELLED，原断言期望RECONCILING；matrix尚未开始，历史实际renew时间NOT_RECORDED。

独审源码确认fail_owned只允许仍然live的同owner/fence终结已known取消，过期owner不能提交。RUNNING heartbeat可以在旧读取与pause/cancel提交之间正常续租，取消RECONCILING后不允许续租；旧读取存在时序窗口，但不能虚构该历史实际renew。0b6a只移动原有同一次Run读取至取消已提交之后，加同worker/status/cancel断言，等该真实lease自然过期。没有新查询、续租、clock修改、预算扩大或删除RECONCILING/matrix断言。old返回现在指取消后的同worker旧fence owner，不是pre-cancel claim；原最终version+1和旧owner不能复用仍正确。生产82源码与bb287完全相同，pin仍bcf48da5c3141eeaa35ad32543d34a48b14519b7e4f5f0e1772c701b61f41041，不需扩或重新seal。新完整恢复4例先实际确认，再0b6a完整199；当前PENDING，不合并旧结果。

0b6a恢复文件实际完整4 PASS/0F/E/S，237.704秒，488完整字节及XMLbijection闭合。独立fixture读出的lease只等待自然过期。新final0b6a完整199将按原全部scope执行，先前4P不加总；quality0b6a同SHA重跑changed12/fullsrc/Node/fullmypy。
