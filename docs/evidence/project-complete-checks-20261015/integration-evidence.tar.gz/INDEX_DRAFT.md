# Evidence index — final terminal pending

Current frozen source: `bb287dceff767f8f5179e65c3d1a272e6fb0fcac`. Old2dda is retained separately.

The final report must retain these separate evidence classes:

- `regression/final2dda`: single-process selected199 terminal XML, collection, executed source, original command and original budgets. Collection is not PASS. Old2dda terminal198 PASS/1 FAIL/0 ERROR/0 SKIP,199unique/488 bytes closure. New finalbb287199 terminal PENDING.
- `regression/quality2dda` and independently repeated `qualitybb287`: fullsrc Ruff and changed-file Ruff PASS, Node2 syntax PASS, fullmypy FAIL5 exact baseline diagnostics; no new errors.
- `rootcause`: original historical three-claim failure, same-base original/profile runs and the actual35.468639sec SAVE writer observation; historical exact first cause remains UNKNOWN. Controlled phase fault injection is separate.
- `heartbeat`: before7FAIL and after37PASS, background identified SQLite contention, ordinary original ownership/unknown recovery.
- `admission`: before PB1FAIL and HTTP/corrupt-scope failures, finite API/PB fixes. Final exact-source PB chain is part of regression, not substituted with an old short subset.
- `review`: original counterexamples and finite fixes, current owner2/qualification22/quality review, old2dda199 terminal review complete (198P1F); newbb287199/doc/source review PENDING. Independent subsets are not added to the full199 count.
- `integration`: qualification repin, restart/PID recovery, root profile observation, final packaging manifests and remote verification procedure.

Production LIVE remains disabled. Real model/fees, Windows/native browser, PG, manual semantics, full real P-A/P-B, old-source upgrade, remote CI/deploy are NOT RUN. Unknown dependency/owner/semantic/publication acceptance is not closed.

Final archives will be produced only after terminal regression and review, and read back every regular member against the original SHA256/size manifest. Ordinary development branch push will then be verified against exact remote SHA, nine protected refs, source diff and existing unrelated WIP.

`regression/pbprobe9b1a`: diagnosis-only newtest1 PASS/0F/E/S,7 accepted3+2+2/KNOWN7000/envelope48354/28public events. No product change or original2dda rejection reproduced. Newcadd product change only omits a proved redundant fullPB verification in the same ordinary binding read segment; alternative branches keep it. No injected delays or budget changes.
