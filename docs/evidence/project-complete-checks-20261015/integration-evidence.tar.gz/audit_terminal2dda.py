import collections
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path
base=Path('/workspace/complete-regression-evidence-20261015/final2dda')
repo=Path('/workspace/Sim2Act-pa-provider')
sha='2dda86b2b943493d81dcf83c23e04119e85e23ed'
def read(name): return json.loads((base/name).read_text())
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
r=read('RESULT.json'); c=read('COLLECTION.json'); cmd=read('COMMAND.json')
assert r['sha']==cmd['sha']==sha
assert r['returncode'] in (0,1)
assert sum(r['counts'].values())==199
assert (r['returncode']==0)==(r['counts']['failure']==r['counts']['error']==0)
assert r['unique_ids']==r['executed_count']==r['collected_count']==199 and r['duplicate_ids']==0
assert all(r[k] for k in ('source_unchanged','head_unchanged','worktree_clean','complete_selected_collection','executed_source_equal'))
assert cmd['no_deselection'] and cmd['no_budget_override']
for key,file in [('stdout_sha256','stdout.log'),('stderr_sha256','stderr.log'),('xml_sha256','results.xml')]: assert r[key]==digest(base/file)
cases=list(ET.parse(base/'results.xml').getroot().iter('testcase'))
ids=[x.get('classname').replace('.','/')+'.py::'+x.get('name') for x in cases]
assert collections.Counter(ids)==collections.Counter(c['nodeids']) and len(set(ids))==199
before=read('source-before.json'); after=read('source-after.json'); executed=read('executed-source-manifest.json')
assert before==after==executed
for name,want in before.items():
 assert digest(base/'executed-source'/name)==digest(repo/name)==want
 raw=subprocess.check_output(['git','show',sha+':'+name],cwd=repo)
 assert hashlib.sha256(raw).hexdigest()==want
scope=collections.Counter(x.split('::')[0] for x in ids)
seven=[x for x in ids if 'seven' in x or x.endswith('::test_actual_mock_generated_app_stage_binding_and_cold_per_use')]
assert len(seven)==3
result={'source_sha':sha,'returncode':r['returncode'],'PASS':r['counts']['pass'],'FAIL':r['counts']['failure'],'ERROR':r['counts']['error'],'SKIP':r['counts']['skipped'],'deselected':0,'xml_collection_exact_bijection':True,'unique_ids':199,'source_files_verified':len(before),'root_and_executed_and_git_bytes_equal':True,'elapsed_seconds':r['elapsed'],'scope':dict(scope),'seven_slot_test_ids':seven,'xml_sha256':r['xml_sha256'],'result_sha256':digest(base/'RESULT.json')}
p=Path('/workspace/project-complete-checks-evidence-20261015/TERMINAL_AUDIT.json');p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
