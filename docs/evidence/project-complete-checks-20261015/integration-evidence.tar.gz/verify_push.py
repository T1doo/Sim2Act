"""Read-only exact remote/source/WIP verification after an ordinary push."""
import hashlib
import json
import subprocess
from pathlib import Path

repo = Path('/workspace/Sim2Act-pa-provider')
protected = {
 'main': '6f688e4dd80b5c81d41aecde90e360d3629f9c21',
 'dev/f1-foundation': 'bbe07a2a10583001d12a0d00fc2aff92254d80fe',
 'dev/csv-two-sum-instances-20261011': '3e890e329332d434e8f3aa245cb15f905bb41455',
 'dev/logic-version-per-use-20261013': '5dc3d54a1e2dfe32fb665480bb65dea3e10b9192',
 'dev/logic-version-correction-20261013': 'fbffaca5a5ca289b2c13d26d50c131d238389a21',
 'dev/project-natural-revalidation-20261014': '0bc90d9f8d4ab1093be079be3dae3d5f45ffb05d',
 'dev/project-account-close-20261014': '2858226b9a68c943476d112af511e54581a0bf93',
 'dev/project-check-cancel-20261014': '80329152ff4b9f39c72f59fafed4828f0d68b6bb',
 'dev/project-reliability-gates-20261015': '52654f7610602b7afc8a2c44eee7abc23e5c2d5d',
}
def git(*args, cwd=repo):
    return subprocess.check_output(['git', *args], cwd=cwd, text=True).strip()

branch = git('branch', '--show-current')
sha = git('rev-parse', 'HEAD')
assert branch == 'dev/project-complete-checks-admission-20261015'
refs = ['refs/heads/' + b for b in [branch, *protected]]
remote = dict(line.split('\t')[::-1] for line in git('ls-remote', 'origin', *refs).splitlines())
assert remote['refs/heads/' + branch] == sha
for name, expected in protected.items():
    assert remote['refs/heads/' + name] == expected
assert not git('status', '--porcelain')
assert git('rev-list', '--left-right', '--count', 'HEAD...@{upstream}') == '0\t0'
frozen = '0b6a780c952fb6eeed5e545f0f6db5f8e64360e6'
assert not git('diff', '--name-only', frozen, 'HEAD', '--', 'src', 'tests', 'pyproject.toml')
for ancestor in ('3e890e329332d434e8f3aa245cb15f905bb41455',
                 '0bc90d9f8d4ab1093be079be3dae3d5f45ffb05d',
                 '2858226b9a68c943476d112af511e54581a0bf93',
                 '52654f7610602b7afc8a2c44eee7abc23e5c2d5d'):
    subprocess.run(['git', 'merge-base', '--is-ancestor', ancestor, sha], cwd=repo, check=True)
other = Path('/workspace/Sim2Act')
assert git('rev-parse', 'HEAD', cwd=other) == 'a4fd476127a477006dbdb29a9a1f6c2f09e6a001'
old_files = {
 'src/sim2act/owner_acceptance.py': '4b0f680cd5817db49c180ec0cae0613f67bbcc5aac4d3f02965c50bd3d638db7',
 'docs/F2/TextFourStepOwnerAcceptance20261012.md': 'c3ad19200029ab85377fbc352cb7cdc4c9699fdbdbcb10b304c6f26c5dc4ca1e',
}
for name, expected in old_files.items():
    assert hashlib.sha256((other / name).read_bytes()).hexdigest() == expected
result = dict(final_sha=sha, branch=branch, frozen_source_sha=frozen, remote=remote,
    protected_refs_unchanged=True, working_tree_clean=True, ahead_behind='0\t0',
    source_test_pyproject_diff_empty=True, other_wip_files_unchanged=True,
    other_wip_head_unchanged=True, other_wip_status=git('status', '--porcelain', cwd=other),
    remote_ci='NOT RUN')
target = Path('/workspace/project-complete-checks-final-git-20261015.json')
target.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
