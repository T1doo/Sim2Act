# Independent exact-source complete regression

Frozen source: `2dda86b2b943493d81dcf83c23e04119e85e23ed`.

The single original selected run terminated with **198 PASS / 1 FAIL / 0 ERROR / 0 SKIP**, 199 unique cases, no deselection, return code 1, elapsed 4721.077 seconds. Collection and XML have an exact two-way node-ID bijection. All 488 regular src/tests/pyproject files match before, after and copied executed bytes; HEAD remained frozen and the independent worktree remained clean. PID 985684 exited; no unknown execution was restarted.

The sole failure is `test_pb_exact_same_trial_source_extraction_and_cold_seven_slots`: source Worker has passed the SUCCEEDED and two observed requests assertions, but cold Worker MockTransport settlement at test line 82 returned last slot `accepted=false` instead of true. The complete traceback and original round are retained. The cause is not established by this regression; do not infer lease, fee, or approval expiry as the first cause from this assertion alone. No failed fixture was modified or replayed, no database was queried for diagnosis, and the full PB combined receipt was not exported because the test failed before that statement.

The unmodified original two-application test passed. Both CHECK Runs reached SUCCEEDED on their first actual claim, fence 1, keeping accepted deadline 300 seconds, lease 30 seconds and max claims 3. The old historical failure, source and timeline eight-file seal remains hash equal. Passing now does not retrospectively establish the historical first timeout cause.

P-A actual synthetic Worker chain completed 3+2+2 requests, seven distinct slot/Attempt IDs and three Run IDs. All slots accepted, usage KNOWN 7000 synthetic tokens, reserved envelope 48354; measured successive reservation gaps 60.080,60.092,63.520,63.603,65.561,65.120 seconds. All permits are SYNTHETIC_ONLY and live_allowed=false. The original separate seven-slot budget test passed using ordinary Store submit/claim/heartbeat and real spaced reserve/settle; it is not a third model Worker chain and originally exports no JSON receipt. Its frozen assertions require KNOWN 14 tokens and envelope 7868.

Eight actual HTTP/JSDOM fixture results passed: 119 internal checks, 143 actions, 897 API requests, 189 status-200 asset fetches, nine page boots. This is offline page evidence, not native-browser acceptance.

Same frozen source quality: full src Ruff PASS; all 11 changed Python files Ruff PASS; Node product and fixture syntax PASS. Full mypy FAIL with exactly the five recorded earlier errors and no new errors (status_report.py lines 72/107 and tools.py lines 210/264). Full-src Ruff is compared against actual 526 full-src PASS, not an unrelated older ten-error baseline.

Paths: `final2dda/RESULT.json`, `COLLECTION.json`, `SUPPORTING_CHECKS.json`, `FAILURES.json`, `DELIVERY_MANIFEST.json`, original XML/raw outputs/executed-source snapshots; `quality2dda/RESULT.json` and raw quality outputs; `original-failure-readonly/MANIFEST.json`; `EXCLUDED.json`.

Known denied UDF/private-barrier files and native browser paths were not executed or renamed; only the six original exact natural_spec_apps transaction node IDs were selected from that mixed file. No real models, credentials, fees, PG, Windows or deployment ran. This engineering gate is **FAILED pending the PB settlement fix**, not overall acceptance or production LIVE authorization.
