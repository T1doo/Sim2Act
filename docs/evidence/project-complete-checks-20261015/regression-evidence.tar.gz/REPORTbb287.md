# Independent complete regression — bb287

Exact frozen SHA: `bb287dceff767f8f5179e65c3d1a272e6fb0fcac`.

This new single-process full selected run terminated with **198 PASS / 1 FAIL / 0 ERROR / 0 SKIP**, 199 unique cases, no deselection, return code 1, 4749.329 seconds. Collection-to-XML node IDs form an exact two-way bijection. All 488 src/tests/pyproject regular files match before/after/copied executed bytes; clean detached HEAD was unchanged. PID 995345 has exited. No count is combined with 2dda or 9b.

The sole failure is `test_expired_known_cancel_recovery_failclosed_matrix_rollback_revocation_and_two_stores`. Its setup helper `expired_return()` failed at line 59 because the original public status after Worker.once was **CANCELLED**, whereas the existing assertion expected RECONCILING. The subsequent fail-closed matrix, rollback, revocation and two-store portion was not reached in this failing case. This result alone establishes neither a product unsafe recovery nor a race's first cause. The original assertion, fixture, budget and data were not modified or replayed. Full raw/XML traceback is retained in FAILURES.json.

The original two-application complete check passed on this source: both CHECK Runs succeeded on their first actual claim, fence 1, keeping max claims 3, original deadline 300 seconds and lease 30 seconds.

All three original seven-slot cases executed without exclusion and passed on this same source. P-A and P-B actual synthetic Worker chains each completed 3+2+2 requests, seven distinct Attempt/slot IDs and three Run IDs; all slots accepted, usage KNOWN 7000 synthetic tokens, envelope 48354. Both chains' measured six reservation gaps are at least 60 seconds. All recorded permits are SYNTHETIC_ONLY/live_allowed=false. P-B public diagnostics contain 35 events, seven accepted known settlements and no refused event. The separate generic budget seven-slot case uses real spaced ordinary Store submit/claim/heartbeat and reserve/settle; it is not another model Worker chain, and its original test does not export a JSON receipt. Its unchanged assertions require KNOWN 14 tokens and envelope 7868.

Eight HTTP/JSDOM fixtures passed: 119 internal checks, 143 actions, 878 API requests, 189 status-200 assets, nine page boots. API8, heartbeat33, ownership4, phase1, typed27 and six original exact final-transaction cases all passed in this round. The recovery file is 3 PASS / 1 FAIL, not fully passing.

Same-SHA actual quality: full-src Ruff PASS; all 11 changed Python files Ruff PASS; Node product/fixture syntax PASS. Full mypy remains FAIL with exactly five prior errors (status_report.py 72/107, tools.py 210/264), no new error. The raw full-src Ruff baseline is an actual 526 PASS, not an assumed older ten-error scope.

Evidence: finalbb287/RESULT.json, COLLECTION.json, SUPPORTING_CHECKS.json, FAILURES.json, PB_PUBLIC_EVENTS_SUMMARY.json, DELIVERY_MANIFEST.json, full original XML/raw output/executed snapshots and ordinary fixture receipts; qualitybb287/RESULT.json and raw checker outputs. Historical 2dda failure and 9b diagnostic pass remain separate and unchanged.

No private SQL/UDF diagnosis, known-denied browser path, real models, credentials, fees, PG, Windows or deployment were executed. Current engineering gate remains **FAILED pending the recovery setup investigation**; this is not whole-project acceptance or production LIVE permission.
