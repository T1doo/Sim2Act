# 70ac699 fixed API delta

Exact source `70ac699e2800776fd5fad19fdc7b2a3ecd8e2d91` (parent 8ecf3f4), clean independent tree. The persisted-schema P2 is fixed with the existing `controlled` decorator on original_contract. Resource revocation gates remain before private pair parsing; no approval/body/Run/ledger write added.

Independent fresh actual P-A/P-B corrupt-paired-schema regressions: **2 PASS /6 deselected**, 3.35 seconds; each checks original approval, budget and stage recovery return VERSION_CONFLICT/409 and unchanged request/Run rows. Evidence `corrupt-fixed.xml`/stdout. Author full short HTTP suite records 8 PASS on this corrected source. Original 8ecf counterexample remains preserved separately and must not be counted as a product acceptance pass.

Decision: **8ecf3f4 + 70ac699 may integrate** the denied-by-default API and exact P-B engineering contract. This independent decision does not assert actual corrected seven-slot P-B Worker acceptance (NOT RUN here) or production fee/quota/sender readiness. Precise 82-file implementation pin, root same-SHA full integration tests, type checking and original two-app progress evidence are still required.
