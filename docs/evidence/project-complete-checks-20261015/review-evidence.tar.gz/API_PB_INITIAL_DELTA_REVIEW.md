# 8ecf3f4 independent API/P-B delta review

Exact source `8ecf3f44593217896e26dfd1b21a7f5edd636f5c`, clean review tree. Six-file delta, no production sender/reserve/fee override. Independent HTTP suite: **6 PASS**, 13.10 seconds, fresh isolated DB and `trial-api.xml`/stdout. No full seven-slot P-B execution run by reviewer.

## P2 requiring correction

`natural_trial_api.original_contract` directly parses persisted original scope without the existing controlled malformed-persistence wrapper. A consistently hashed/sealed original scope whose expires_at has an invalid persisted type raises Pydantic ValidationError out of the HTTP handler (production 500 / TestClient exception) rather than VERSION_CONFLICT. Independent fresh synthetic reproduction `test_trial_scope_corruption.py` confirms the exception: **one counterexample PASS**, 5.77 seconds, `corrupt-scope.xml`/stdout. This passing counterexample is not a passing product acceptance case.

Fix: reuse controlled on original_contract and add PA/PB malformed sealed persistence HTTP409 + no-partial negative cases. Original resource grant revocation still must deny before `_saved` reads private material/Goal scope bytes; existing actual HTTP case verifies that ordinary revoked-resource path.

## Static safety findings

P-A serialization unchanged; PBTrialContract adds exact extraction key and complete Recipe, distinct from stage keys. P-B only cold may use spec_task; pb.verify proves actual source/extraction/review metadata and current target. Same-trial ledger source Run and exact review source_run/key/Recipe matched. Two original source Attempts independently correlate accepted slots with VERIFIED/MOCK/model, wire/raw hashes/bytes and known usage; Generate's original three accounted Attempts retained. Stage runtime/app/instance/revision/Release/Goal/current authority version bound by existing stage proof. UNKNOWN/rejected/halted accounting cannot qualify.

API identity and exact user/project/key guard precede actions. Original-key GET has no caller replacement contract and performs scalar resource read + save authorization before paired body read, followed by full current material/Goal checks. Historical expiration does not restore live_allowed/dispatch; revoke remains metadata-only stop. No caller FeeProof/arbitrary free flag accepted. Production fee authority is None and denies.

Production trusted account-to-quota resolver, free entitlement/enforced nonchargeability and sender are explicitly absent; this interface is denied-by-default engineering. MOCK-only evidence is not real model/fee acceptance. Current pin still requires precise new natural_trial_api inclusion and repin after final integrated source. P-B original failed attempt (RECEIVED versus final VERIFIED guard) remains failure history; corrected full P-B actual execution NOT RUN at this review epoch.
