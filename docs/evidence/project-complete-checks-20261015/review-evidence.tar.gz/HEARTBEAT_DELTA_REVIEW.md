# c607844 independent delta review

Author exact commit: `c6078444681bba9e5fd76a1badeeff610ae3ac11`, clean `/workspace/Sim2Act-workflow-heartbeat-error`. Delta against 52654f: text_workflows 18 added/1 removed line; tests 103 added/2 removed lines. No Store/claim/lease/budget/settlement changes.

Decision: **may integrate** this finite heartbeat exception fix. No demonstrated new P1/P2 in the precise delta.

Only background errors already identified by existing `_sqlite_heartbeat_contention` (real sqlite3.Error + SQLAlchemy OperationalError + SQLITE_BUSY/LOCKED including extended codes + SQLite Store) are translated to RESOURCE_UNAVAILABLE. Existing fail_job independently decides current owner/fence/lease/stop/unknown metadata. Expired/replaced ownership cannot settle. If that metadata transaction encounters the same allowlisted contention, no new retry/renew/claim or fabricated terminal is made. Other errors preserve the original exception. Terminal advance wins over a late heartbeat failure as previously.

Unknown operation remains unknown. With cancel intent it remains RECONCILING; without cancel existing stop_state returns WAITING_RESOURCE, but original operation and no-resend guards remain. Do not describe WAITING_RESOURCE as known outcome. State-write does not imply any model result or semantic acceptance.

Author preserved pre-fix seven actual failures in before-test.log/XML; failures show OperationalError escape from actual Worker.once control boundary. Author final.xml records 37 PASS/0 FAIL/ERROR/SKIP, SHA256 `8113b344d1fa08e656dd4e9cd14e8317ab3e5630c09d3814b4268557f6946f49`. Tests use real SQLite Store and real metadata writer but controlled advance/heartbeat and overridden first claim; they do not replay the original two-app test or establish its first cause.

Independent actual run: exact c607 source, `tests/test_workflow_heartbeat_failure.py -k 'exhausted_background_contention or unexpected_settlement_failure'`, fresh isolated evidence basetemp, no shared DB, no cache writes to product. **10 PASS /23 deselected**, 10.31 seconds, `heartbeat-fixed.xml` and `heartbeat-fixed.stdout`. Product worktree remained clean before and after. Scope covers unknown/cancel, pause/cancel, expiry, replacement owner, metadata contention, and unexpected settlement exception propagation. Next ordinary queue survives in controlled tests; old Run lease is deliberately made noneligible in fixture for that next-queue check, so it is not proof of old-Run recovery.

text_workflows.py SHA256 `76b214e8f3ef10e23ca2984fde3c68cba9abd9f9b6dcc257dfeecd9bf5dee4fd`; test file SHA256 `34b2f877b8e6275f28fdb59cc497aef60a62733f3314195f66873e552f156dce`.

Author scoped Ruff PASS. Scoped mypy retains two previously known tools.py annotations, not new errors. Root final full-source typing and qualification repin still required after integration. All counts here belong to c607, not a future integrated SHA.
