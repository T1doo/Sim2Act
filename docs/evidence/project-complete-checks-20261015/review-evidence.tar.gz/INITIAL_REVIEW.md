# Independent review of 52654f

Reviewed source: `52654f7610602b7afc8a2c44eee7abc23e5c2d5d`, `/workspace/Sim2Act-complete-review`. Read-only product tree, no historical DB reused, no actual model or credentials, no long integration tests. No applicable AGENTS.md found in this worktree or workspace catalog.

## P2 confirmed: exhausted heartbeat SQLite contention stops entire worker

`src/sim2act/text_workflows.py:951-980` records a background heartbeat exception and subsequently raises the original `failure[0]`. Its handler catches only DomainError. A SQLAlchemy OperationalError wrapping identified SQLITE_BUSY/SQLITE_LOCKED therefore escapes process_job and Worker.once, whose outer handling also catches only DomainError, and the service main loop has no general handler. A current Run can remain RUNNING until lease expiry and the worker process is terminated instead of advancing unrelated ordinary queue work.

Actual bounded control-flow reproduction: `heartbeat_exception_repro.py` and `heartbeat_exception_repro.stdout`. FakeStore only, no DB writes. Actual result OperationalError escaped, sqlite code 5. Tiny stub cadence accelerates the background thread in this independent unit demonstration; product lease 30 seconds, deadline 300 seconds and original 3 claims unchanged.

This is not established as the cause of the original second application's missing SAVE. That historical test and timing/evidence require an independent root-cause investigation. Fix must not fabricate renewal success, silently extend lease/deadline, terminalize unknown outcomes, dispatch or claim twice, or swallow unidentified non-SQLite exceptions. The exhausted identified contention can safely end the current invocation while leaving original durable state for ordinary original-lease recovery.

## Reviewed adjacent safety boundaries

No additional demonstrated P1 was found in the finite review of cancellation recovery, exact approval/stage binding, nonrefundable slots and history UI. This is a scoped code review, not an acceptance pass or a fresh full-test claim.

Cancellation recovery only targets RECONCILING + explicit cancel + genuinely expired old lease, locks project before Run, independently matches accepted original public control/scope seals, requires known original receipt accounting and no unknown, performs atomic Run/AppRun transition, preserves original effects/history. Corrupt/incomplete scope skipped; finite 16-ID cursor. Unknown remains uncommitted.

Budget reserve and settle use original trial/project/owner/software contract and original Run/version/fence, fixed stage slots, global quota row, no refund or new dispatch permission; late or revoked settlement retains actual receipt with accepted false; one-way same-response UNKNOWN correction preserves halt.

Admission currently denies production fee authority, accepts exact synthetic authority only in test-only SQLite with live_allowed false. It is not yet a production LIVE registration. Future production quota_subject must be resolved from trusted server entitlement/account identity rather than merely accepting caller-selected quota identifiers.

History uses original-key GETs and version match, catches 403 via public controls only, clears unresolved visible private proofs on recovery failure and does not issue Run commands or create keys. Backend authorization remains necessary; display checksum alone is not an authorization mechanism.

## Pending

Root new source and actual same-SHA integration evidence; isolated heartbeat exception fix; P-A/P-B HTTP engineering delta; precise production pin extension. No real PG/Windows/native browser/model/fee/human semantics test was run here.
