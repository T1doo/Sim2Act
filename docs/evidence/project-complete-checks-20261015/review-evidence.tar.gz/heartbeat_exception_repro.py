"""Short isolated control-flow reproduction: no Store, DB or product writes."""
import json
import sqlite3
import time
from types import SimpleNamespace
from sqlalchemy.exc import OperationalError
from sim2act.text_workflows import process_job

class FakeStore:
    sqlite = True
    def heartbeat(self, *args, **kwargs):
        error = sqlite3.OperationalError('database is locked')
        error.sqlite_errorcode = sqlite3.SQLITE_BUSY
        raise OperationalError('heartbeat', {}, error)

worker = SimpleNamespace(store=FakeStore(), id='isolated-review',
                         s=SimpleNamespace(lease_seconds=0.03),
                         stop=__import__('threading').Event())
run = dict(id='isolated-review-run', fence=1, lease_until=time.time() + 30)
def advance(worker, run):
    time.sleep(0.05)
    return True

try:
    process_job(worker, run, advance_fn=advance)
except Exception as exc:
    print(json.dumps(dict(escaped_type=type(exc).__name__,
                         sqlite_code=exc.orig.sqlite_errorcode,
                         product_head='52654f7610602b7afc8a2c44eee7abc23e5c2d5d',
                         no_database=True,
                         note='0.03 stub cadence only; production 30s lease unchanged')))
    assert isinstance(exc, OperationalError)
else:
    raise AssertionError('Expected uncaught heartbeat OperationalError')
