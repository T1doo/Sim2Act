# Diagnostic single-case evidence review

Exact9b1a8f778041bed4a3d6d6ad453f4efa51719bf3: actual1 PASS/0FAIL/ERROR/SKIP,477.525-second command runtime. Independently read terminal XML/raw stream hashes,488 exact before/after/executed source hashes and every archived byte.28 emitted public events comprise21 returned synthetic no-LIVE permits and7 successful accepted known settlements, exact3+2+2 slots,7000 tokens/48354 reserved and all six real RPM gaps>=60. No refused or acceptedfalse event.

This does not reproduce2dda actual failure or resolve its precise rejection. Logging-only test source changed and timings may be perturbed; full2dda198P1F remains independent. No real fees, provider, native browser or production readiness demonstrated. Detailed machine evidence and actual cold admission durations in PB_PROBE_REVIEW_CHECKS.json.
