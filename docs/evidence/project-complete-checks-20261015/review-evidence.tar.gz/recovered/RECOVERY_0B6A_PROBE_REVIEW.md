# Exact revised recovery fixture probe review

Exact clean0b6a780c952fb6eeed5e545f0f6db5f8e64360e6, original four recovery cases actual4PASS/0FAIL/ERROR/SKIP,237.704 seconds command. Independently read original XML, exact four selected unique IDs, every raw stream hash, all488 before/after/executed/current source bytes, and both public known/unknown fixture JSON receipts against recorded size/hash. Whole selected probe completed, no subcase filtering.

Only tests/test_project_check_recovery.py differs frombb287; fullsrc/web/pins and all other tests are unchanged, complete82 qualification pin remainsbcf48da5c3141eeaa35ad32543d34a48b14519b7e4f5f0e1772c701b61f41041. Existing single lease SELECT moved after committed RECONCILING cancel; original recovery guard matrix/rollback/revocation/twoStore assertions now actually executed in this probe. No extra SQL/renewal/budget/clock/claim. Returned old semantics postcancel same owner old fence retained as previous review.

May proceed to fresh sameSHA199 full validation. This4P is a separate preprobe and must not be added to the same four cases in the full run. Historicalbb failure's actual heartbeat renewal time remainsNOT_RECORDED; earlier2dda P-B rejection precise causeUNKNOWN; both198P1F histories preserved. No entire new-source acceptance, production LIVE/fees/native/PG/Windows/human/CI claim.
