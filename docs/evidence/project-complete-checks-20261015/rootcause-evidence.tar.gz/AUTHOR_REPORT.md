# Project SAVE ownership-interval repair

Commit: `e8bb45734c7b954f8ff704a4cf27b3dad3101f9c`
Branch: `dev/two-app-progress-rootcause-20261015`; clean; not pushed (root is sole integrator).

## Behavior and evidence

The retained ce6 historical second-app failure is still **historical exact first cause UNKNOWN**: its three ordinary claims ended RUNNING at fences 1/3/5. No historical DB was read or modified here; existing XML/stdout/claims/public response records were copied to `retained-historical-failure`.

The unchanged original complete cold test on 526 passed once (487.17s) and again with ordinary call-duration logging (506.88s). This does not erase the historical failure. The logged second pass actually caught a peer SAVE rollback on its first claim: real SQLite BEGIN IMMEDIATE held 35.469s, only 29.9919s remained in the current lease; the end was 5.4776s beyond it. Background heartbeat repeatedly failed to enter BEGIN IMMEDIATE. The final SAVE guard rejected; fail_owned left the expired Run RUNNING, and the next normal claim/fence3 succeeded. `OBSERVED_SAVE_LEASE_WINDOW.json` binds the exact raw time window, heartbeat errors and original public claim tuples. This is an observed current lease-window mechanism, not proof of the unrecorded historical phase.

An initial ordinary Worker.once clock-injection attempt failed before SAVE with background OperationalError; its `segments=[]` and only one peer model request establish that it is **not** the SAVE mechanism proof. That failed attempt is retained as `injected-before.*`.

A separate explicitly labelled FAULT_INJECTION phase test uses the real Store/Worker/spec.advance and normal synchronized lease API, no background scheduler replacement or private cell/UDF observer. Original Run300/lease30/maxclaims3 stay unchanged. Advancing test time8s after each complete SAVE-scope replay produced four replays /32s per locked SAVE and all three claims remained RUNNING on old code. The repair produced two replays /16s and first claim/fence1 SUCCEEDED, with exactly two synthetic runtime model requests. This is a controlled elapsed-phase regression, not a natural reproduction or performance/capacity claim.

## Repair

Only the existing SAVE implementation changes. Public instance ID/version projections are captured in the first fully authorized read segment, before writes; original data_version/revision CAS and full final instance/typed-history readback bind the target. The model audit digest is captured in that same read segment. Two redundant full project replays inside the single atomic write group are removed. Fresh exact public Run owner/fence/version/lease/cancel/status/identity guards and current worker mode/tools/deadline scalar checks remain. The final fresh job_scope_gate, verify_job, original and runtime audits, final tuple and original lease/deadline checks remain intact. There is no cross-write permission proof cache, renewed expired lease, increased budget or new executor.

## Actual verification (do not combine source epochs)

- Source526 unchanged original complete two-app cold test: 1 PASS. Source526 logged original test: 1 PASS; first peer SAVE failed internally then the existing second claim succeeded.
- Old-code original Worker.once injection: 1 FAIL, OperationalError before SAVE, no injected segments. Old-code isolated phase injection: 1 FAIL, bounded three claims remained RUNNING. Both failures retained.
- Repaired product bytes, first test-oracle version: 29 PASS /0 FAIL/ERROR/SKIP (794.04s): phase1 + ordinary typed-write mutation22 + original final-transaction mutations6. All485 source/test/pyproject files match the during/after seals. Two budget tests erroneously used invalid0 and therefore proved malformed limits denial rather than valid lower budgets; this quality finding and old test source are retained. **Do not call this the whole current test-source run.**
- Current commit e8bb: 3 PASS /0 FAIL/ERROR/SKIP (79.46s), valid worker max_tools2 below actual single-app local-tool use3 yields BUDGET_EXHAUSTED, valid frozen max_tools2 change yields VERSION_CONFLICT, lower valid worker deadline yields BUDGET_EXHAUSTED. Original product bytes remain exactly those of the29-pass run. Root must run the complete original two-app flow and all latest cases together on its final integrated qualified SHA.
- Scoped Ruff PASS. Full mypy FAIL only the existing5 errors in status_report.py/tools.py; no added source errors (82 source files checked).

Typed-write cases reject real ordinary mutations after actual INSERT: lease/fence/version/cancel/stop/deadline, current worker tools/deadline/LIVE flag, read/save revoke and expiry, Goal/material change, context/typed row/instance/receipt/original model audit/UNKNOWN/frozen budget corruption. Every rejected transaction leaves **every table exactly equal** to the pre-SAVE snapshot, including known model history. No private-cell reading barrier was run or claimed.

## Remaining verification

Root integrated same-SHA complete Worker flow, current all29 suite and software qualification are pending at this child delivery. PostgreSQL, Windows/native browser, real provider/fees/credentials, human semantics and capacity are NOT RUN. Historical three-claim first cause remains UNKNOWN. This child commit does not implement production LIVE activation, P-B real trials, deployment, CI or overall acceptance.

`RESULTS.json` contains XML counts and hashes. Raw logs, timing JSONL, source seals, all synthetic fixtures, failed attempts and oracle-quality history remain in this directory.
