import functools, importlib, json, pathlib, sys, threading, time
sys.path.insert(0, str(pathlib.Path.cwd()/'src'))
log=pathlib.Path(sys.argv[1]); log.parent.mkdir(parents=True,exist_ok=True)
lock=threading.Lock()
def wrap(module,name):
    original=getattr(module,name)
    @functools.wraps(original)
    def traced(*args,**kwargs):
        start=time.time(); err=None
        try: return original(*args,**kwargs)
        except BaseException as exc:
            err=dict(type=type(exc).__name__,code=getattr(exc,'code',None),message=str(exc)); raise
        finally:
            end=time.time(); record=dict(module=module.__name__,function=name,start=start,end=end,seconds=end-start,thread=threading.get_ident(),error=err)
            for value in args:
                if isinstance(value,dict) and 'fence' in value and 'id' in value:
                    record.update(run_id=value['id'],fence=value['fence'],lease_until=value.get('lease_until'),status=value.get('status'));break
            with lock:
                with log.open('a') as f: f.write(json.dumps(record)+'\n')
    setattr(module,name,traced)
for module,names in [('sim2act.pa_spec_apps',['bound','commit_guard','_advance_local','verify_job']),('sim2act.project_natural_revalidation',['_load_plan','members','calculate']),('sim2act.natural_spec_runtime',['advance_model','renew','fail_owned'])]:
    loaded=importlib.import_module(module)
    for name in names: wrap(loaded,name)
from sim2act.db import Store
from contextlib import contextmanager
original_tx=Store.tx
@contextmanager
def traced_tx(self,*args,**kwargs):
    start=time.time();entered=None;err=None
    try:
        with original_tx(self,*args,**kwargs) as c:
            entered=time.time()
            yield c
    except BaseException as exc:
        err=dict(type=type(exc).__name__,code=getattr(exc,'code',None),message=str(exc));raise
    finally:
        end=time.time()
        record=dict(module='Store',function='tx',start=start,entered=entered,end=end,seconds=end-start,thread=threading.get_ident(),error=err)
        with lock:
            with log.open('a') as f:f.write(json.dumps(record)+'\n')
Store.tx=traced_tx
wrap(Store,'heartbeat')
original_event=Store.event
@functools.wraps(original_event)
def traced_event(self,c,rid,kind,data):
    record=dict(module='Store',function='event',start=time.time(),run_id=rid,kind=kind,thread=threading.get_ident())
    with lock:
        with log.open('a') as f:f.write(json.dumps(record)+'\n')
    return original_event(self,c,rid,kind,data)
Store.event=traced_event
import pytest
raise SystemExit(pytest.main(sys.argv[2:]))
