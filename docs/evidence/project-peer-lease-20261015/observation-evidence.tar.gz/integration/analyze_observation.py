"""Read only original singleton boundaries; inclusive durations are never summed as wall time."""
import collections,hashlib,json,subprocess,xml.etree.ElementTree as ET
from pathlib import Path
B=Path('/workspace/project-peer-lease-evidence-20261015');R=Path('/workspace/Sim2Act-pa-provider');O=B/'observation/original-peer-observed'
def load(p):return json.loads(p.read_text())
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
result=load(O/'RESULT.json'); cmd=load(O/'COMMAND.json'); before=load(O/'source-before.json')
assert result['sha']==cmd['sha']=='2747eec91fdcfdefb6f575a8d96dbb0dab26114e'
assert result['returncode']==0 and result['counts']=={'pass':1,'failure':0,'error':0,'skipped':0}
assert all(result[k] for k in ('source_unchanged','head_unchanged','tree_clean'))
assert before==load(O/'source-after.json')==load(O/'executed-source-manifest.json') and len(before)==499
for n,want in before.items():
 assert h(O/'executed-source'/n)==h(R/n)==want
 raw=subprocess.check_output(['git','show',cmd['sha']+':'+n],cwd=R)
 assert hashlib.sha256(raw).hexdigest()==want
p=next((O/'boundaries').glob('*.json')); x=load(p);rows=x['spans'];byid={r['id']:r for r in rows}
assert x['dropped']==0 and len(byid)==len(rows)
assert h(B/'integration/peer_boundary_observer.py')==cmd['observer_sha256']
scopes=collections.defaultdict(list)
for r in rows:scopes[r['name']].append(r)
stats={n:dict(calls=len(rs),sum_inclusive_seconds=sum(r['elapsed'] for r in rs),max_seconds=max(r['elapsed'] for r in rs),errors=sum(r['status']=='ERROR' for r in rs)) for n,rs in scopes.items()}
dup=[r for r in scopes['natural.compile_candidate'] if r['parent'] and byid[r['parent']]['name']=='project.members']
guards=[]
for g in scopes['guard']:
 children=[r for r in scopes['source_scope'] if r['parent']==g['id']]
 assert len(children)==1
 q=children[0]
 guards.append(dict(id=g['id'],thread_name=g['thread_name'],status=g['status'],guard_seconds=g['elapsed'],source_scope_seconds=q['elapsed'],after_source_scope_seconds=(g['start']+g['elapsed'])-(q['start']+q['elapsed']),after_source_scope_is_not_pure_lease_predicate=True))
main_hb=[r for r in scopes['heartbeat'] if r['thread_name']=='MainThread']
begin={kind:dict(calls=len(rs),max_seconds=max((r['elapsed'] for r in rs),default=0),errors=sum(r['status']=='ERROR' for r in rs)) for kind,rs in [('main',[r for r in scopes['SQL.BEGIN_IMMEDIATE'] if r['thread_name']=='MainThread']),('other',[r for r in scopes['SQL.BEGIN_IMMEDIATE'] if r['thread_name']!='MainThread'])]}
summary=dict(source_sha=cmd['sha'],original_full_failure_not_overwritten=True,singleton_counts=result['counts'],singleton_elapsed=result['elapsed'],xml_sha256=h(O/'results.xml'),source_files=499,source_before_after_copied_root_git_equal=True,observation_sha256=h(p),spans=len(rows),dropped=0,stats=stats,members_compile_outside_load_family_upper_bound=dict(not_callsite_identified=True,includes_graph_current_compilation=True,calls=len(dup),sum_seconds=sum(r['elapsed'] for r in dup),max_seconds=max((r['elapsed'] for r in dup),default=0),fraction_of_members_inclusive=sum(r['elapsed'] for r in dup)/stats['project.members']['sum_inclusive_seconds']),begin_acquisition=begin,main_heartbeat=dict(calls=len(main_hb),max_seconds=max(r['elapsed'] for r in main_hb),errors=sum(r['status']=='ERROR' for r in main_hb)),guard_source_split=guards,inclusive_durations_overlap=True,pure_lease_predicate_seconds='NOT_RECORDED',old_68_second_failure_reproduced=False,callback_direct_observation='NOT_RECORDED; original test PASS alone is not an added explicit callback counter',production_code_changed=False,full_regression_rerun=False)
(O/'ANALYSIS.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ('stats','guard_source_split')},indent=2))
