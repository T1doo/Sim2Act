"""Package completed bounded diagnostic receipts, excluding only declared caches/aliases."""
import hashlib,json,tarfile
from pathlib import Path
B=Path('/workspace/project-peer-lease-evidence-20261015');D=Path('/workspace/Sim2Act-pa-provider/docs/evidence/project-peer-lease-20261015')
def h(p):
 z=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):z.update(block)
 return z.hexdigest()
files={}
for p in sorted(B.rglob('*')):
 rel=p.relative_to(B)
 if {'__pycache__','.pytest_cache','mypy-cache'}.intersection(rel.parts) or p.is_symlink() or not p.is_file():continue
 assert not any(x.is_symlink() for x in p.parents if x!=B.parent)
 if rel.as_posix()=='PACKAGE_RESULT.json':continue
 files[rel.as_posix()]={'bytes':p.stat().st_size,'sha256':h(p)}
assert 'delivery/REPORT.md' in files
for run in ('original-peer-observed','original-peer-callsite-callback'):
 for n in ('COMMAND.json','START.json','PROCESS_EXIT.json','RESULT.json','results.xml','source-before.json','source-after.json','executed-source-manifest.json','ANALYSIS.json'):
  assert 'observation/'+run+'/'+n in files
D.mkdir(exist_ok=True,parents=True);target=D/'observation-evidence.tar.gz'
with tarfile.open(target,'w:gz') as archive:
 for name in files:archive.add(B/name,arcname=name,recursive=False)
seen=set()
with tarfile.open(target,'r:gz') as archive:
 for m in archive:
  n=m.name;assert m.isfile() and n not in seen and n in files and not n.startswith('/') and chr(92) not in n and all(x not in ('','.','..') for x in n.split('/'))
  seen.add(n);z=hashlib.sha256()
  with archive.extractfile(m) as f:
   for block in iter(lambda:f.read(1024*1024),b''):z.update(block)
  assert m.size==files[n]['bytes'] and z.hexdigest()==files[n]['sha256']==h(B/n)
assert seen==set(files)
(D/'MANIFEST.json').write_text(json.dumps(files,indent=2)+'\n')
x=dict(file=target.name,bytes=target.stat().st_size,sha256=h(target),members=len(files),product_source_sha='2747eec91fdcfdefb6f575a8d96dbb0dab26114e',product_fix='NOT_PROVEN_OR_IMPLEMENTED',all_members_readback=True)
(D/'ARCHIVE.json').write_text(json.dumps(x,indent=2)+'\n');(B/'PACKAGE_RESULT.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x))
