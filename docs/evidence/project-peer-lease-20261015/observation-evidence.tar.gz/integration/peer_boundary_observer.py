"""Opt-in bounded public-call and SQL BEGIN timing; no queries or decision changes."""
import contextlib
import functools
import json
import os
import threading
import time
from pathlib import Path

import pytest
from sqlalchemy import event
from sqlalchemy.engine import Engine
from sim2act import goal_applications, project_natural_revalidation as project
from sim2act import natural_specs, delivery_graph_apps, natural_logic_patches
from sim2act.db import Store


@pytest.fixture(autouse=True)
def public_boundaries(request, monkeypatch):
    output = os.environ.get('SIM2ACT_PEER_OBSERVER')
    if not output:
        yield
        return
    rows=[]; lock=threading.Lock(); tls=threading.local(); sequence=0; dropped=0
    cursor_starts={}
    def start(name, **meta):
        nonlocal sequence
        with lock:
            sequence+=1; seq=sequence
        stack=getattr(tls,'stack',[])
        value=dict(id=seq,parent=stack[-1] if stack else None,name=name,
                   thread=threading.get_ident(),thread_name=threading.current_thread().name,
                   start=time.monotonic(),wall_start=time.time(),**meta)
        tls.stack=stack+[seq]
        return value
    def finish(value,error=None):
        nonlocal dropped
        value.update(elapsed=time.monotonic()-value['start'],wall_end=time.time(),
                     status='ERROR' if error else 'RETURN',
                     error_type=type(error).__name__ if error else None)
        if error and hasattr(error,'public'):value['public_error']=error.public()
        stack=getattr(tls,'stack',[])
        if stack and stack[-1]==value['id']:tls.stack=stack[:-1]
        with lock:
            if len(rows)<20000:rows.append(value)
            else:dropped+=1
    def wrap(owner,name,label):
        original=getattr(owner,name)
        @functools.wraps(original)
        def measured(*args,**kwargs):
            v=start(label)
            try:r=original(*args,**kwargs)
            except BaseException as e:
                finish(v,e);raise
            finish(v);return r
        monkeypatch.setattr(owner,name,measured)
    for owner,name,label in [(Store,'heartbeat','heartbeat'),(Store,'guard','guard'),
        (goal_applications,'source_scope_gate','source_scope'),(project,'load_plan','project.load_plan'),
        (project,'members','project.members'),(project,'calculate','project.calculate'),
        (natural_specs,'compile_candidate','natural.compile_candidate'),
        (delivery_graph_apps,'load_family','graph.load_family'),
        (natural_logic_patches,'context','logic.context')]:wrap(owner,name,label)
    original_tx=Store.tx
    @contextlib.contextmanager
    def tx(store,*args,**kwargs):
        v=start('tx.acquire')
        cm=original_tx(store,*args,**kwargs)
        try:c=cm.__enter__()
        except BaseException as e:
            finish(v,e);raise
        finish(v)
        try:yield c
        except BaseException:
            import sys
            if not cm.__exit__(*sys.exc_info()):raise
        else:cm.__exit__(None,None,None)
    monkeypatch.setattr(Store,'tx',tx)
    def before(c,cursor,statement,parameters,context,many):
        if statement.strip().upper()=='BEGIN IMMEDIATE':
            cursor_starts[id(context)]=start('SQL.BEGIN_IMMEDIATE')
    def after(c,cursor,statement,parameters,context,many):
        v=cursor_starts.pop(id(context),None)
        if v:finish(v)
    def error(ctx):
        v=cursor_starts.pop(id(ctx.execution_context),None)
        if v:finish(v,ctx.original_exception)
    event.listen(Engine,'before_cursor_execute',before)
    event.listen(Engine,'after_cursor_execute',after)
    event.listen(Engine,'handle_error',error)
    try:yield
    finally:
        event.remove(Engine,'before_cursor_execute',before)
        event.remove(Engine,'after_cursor_execute',after)
        event.remove(Engine,'handle_error',error)
        target=Path(output);target.mkdir(parents=True,exist_ok=True)
        key=request.node.nodeid.replace('/','_').replace(':','_')
        (target/(key+'.json')).write_text(json.dumps(dict(nodeid=request.node.nodeid,
            cap=20000,dropped=dropped,spans=sorted(rows,key=lambda r:r['start']),
            no_new_queries=True,sql_parameters_recorded=False,
            observation_inclusive_and_perturbs_timing=True,
            guard_after_scope_includes_run_row_lease_predicate_and_frozen_contract=True,
            pure_lease_predicate_duration='NOT_RECORDED'),indent=2)+'\n')
