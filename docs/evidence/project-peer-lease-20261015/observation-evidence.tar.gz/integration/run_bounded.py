"""Bounded exact-node run, immutable source capture and actual terminal receipt."""
import argparse,hashlib,json,os,shutil,subprocess,time
from pathlib import Path
import xml.etree.ElementTree as ET
R=Path('/workspace/Sim2Act-pa-provider');B=Path('/workspace/project-peer-lease-evidence-20261015')
P='/workspace/Sim2Act/.venv/bin/python'
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def manifest():return {str(p.relative_to(R)):h(p) for folder in ('src','tests') for p in sorted((R/folder).rglob('*')) if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts}|{'pyproject.toml':h(R/'pyproject.toml')}
a=argparse.ArgumentParser();a.add_argument('--name',required=True);a.add_argument('--sha',required=True);a.add_argument('--observe',action='store_true');a.add_argument('--observer-plugin',default='peer_boundary_observer');a.add_argument('--node',action='append',required=True);args=a.parse_args()
assert all(x.isalnum() or x in '-_' for x in args.name)
assert git('rev-parse','HEAD')==args.sha and not git('status','--porcelain')
out=B/'observation'/args.name;out.mkdir(exist_ok=False)
before=manifest();write(out/'source-before.json',before)
for n in before:
 d=out/'executed-source'/n;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/n,d)
env={k:os.environ[k] for k in ('PATH','LANG','LC_ALL','TZ') if k in os.environ}
env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=f'{B}/integration:{R}/src:{R}/tests',NODE_PATH='/workspace/node-tools/node_modules')
argv=[P,'-m','pytest','-q','-p','no:cacheprovider']
if args.observe:
 assert args.observer_plugin in ('peer_boundary_observer','peer_boundary_observer_v2')
 argv+=['-p',args.observer_plugin];env['SIM2ACT_PEER_OBSERVER']=str(out/'boundaries')
argv+=args.node+[f'--basetemp={out}/tmp',f'--junitxml={out}/results.xml']
write(out/'COMMAND.json',dict(sha=args.sha,argv=argv,nodes=args.node,observer=args.observe,observer_sha256=h(B/'integration'/(args.observer_plugin+'.py')) if args.observe else None,timeout_seconds=900,isolated_sqlite=True,no_budget_override=True,no_inherited_database_url=True))
start=time.time()
with (out/'stdout.log').open('w') as so,(out/'stderr.log').open('w') as se:
 child=subprocess.Popen(argv,cwd=R,env=env,stdout=so,stderr=se)
 write(out/'START.json',dict(pid=child.pid,started=start))
 timed_out=False
 try:code=child.wait(timeout=900)
 except subprocess.TimeoutExpired:
  timed_out=True;child.kill();code=child.wait()
end=time.time();write(out/'PROCESS_EXIT.json',dict(returncode=code,timed_out=timed_out,finished=end))
after=manifest();write(out/'source-after.json',after)
executed={n:h(out/'executed-source'/n) for n in before};write(out/'executed-source-manifest.json',executed)
cases=[]
if (out/'results.xml').exists():
 for c in ET.parse(out/'results.xml').getroot().iter('testcase'):
  cases.append(dict(id=c.get('classname','')+'::'+c.get('name',''),status=next((v.tag for v in c if v.tag in ('failure','error','skipped')),'pass'),time=c.get('time')))
x=dict(sha=args.sha,returncode=code,timed_out=timed_out,elapsed=end-start,cases=cases,counts={s:sum(c['status']==s for c in cases) for s in ('pass','failure','error','skipped')},source_files=len(before),source_unchanged=before==after==executed,head_unchanged=git('rev-parse','HEAD')==args.sha,tree_clean=not git('status','--porcelain'),xml_sha256=h(out/'results.xml') if (out/'results.xml').exists() else None)
write(out/'RESULT.json',x);print(json.dumps(x),flush=True)
