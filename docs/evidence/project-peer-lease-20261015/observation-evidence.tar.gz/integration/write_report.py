from pathlib import Path
import json
B=Path('/workspace/project-peer-lease-evidence-20261015');R=Path('/workspace/Sim2Act-pa-provider')
def load(p):return json.loads(p.read_text())
a=load(B/'observation/original-peer-observed/ANALYSIS.json');b=load(B/'observation/original-peer-callsite-callback/ANALYSIS.json')
assert a['source_sha']==b['source_sha']=='2747eec91fdcfdefb6f575a8d96dbb0dab26114e'
assert a['singleton_counts']==b['singleton_counts']=={'pass':1,'failure':0,'error':0,'skipped':0}
assert b['callback_direct_observation']['calls']==1 and b['callback_direct_observation']['status']=='RETURN'
d=b['exact_members_line145_duplicate_compile']
rows=[]
for label,x in [('原公开边界',a),('精确调用点及回调',b)]:
 rows.append(f"| {label} | {x['singleton_elapsed']:.6f} | {x['spans']} / {x['dropped']} | {x['main_heartbeat']['max_seconds']:.6f} | {x['begin_acquisition']['main']['max_seconds']:.6f} |")
parts=[]
for key in ('project.members','project.calculate','source_scope'):
 z=b['stats'][key];parts.append(f"| {key} | {z['calls']} | {z['max_seconds']:.6f} | {z['sum_inclusive_seconds']:.6f} |")
g=max((g for g in b['guard_source_split'] if g['thread_name']=='MainThread'),key=lambda g:g['guard_seconds'])
t=f'''# peer_version 发前租约失败：有限公开边界观测，未证实修复

**没有提交产品修复；旧完整回归仍为388 PASS / 1 FAIL / 0 ERROR / 0 SKIP，RC1，整体NOT_ACCEPTED。** 本轮只完成两次原失败单例观测及独立核验，两次PASS不能覆盖旧FAIL，也不构成完整回归通过。

基线/观测源码 SHA `2747eec91fdcfdefb6f575a8d96dbb0dab26114e`，分支 `dev/project-peer-lease-20261015`。旧完整批代码冻结于056，2747仅追加原已审文档证据；历史见[原交付说明](PBSourceArchive20261015.md)。本轮src/tests/pyproject及85模块资格pin均未改变。

## 执行合同与真实结果

仅执行原节点 `tests/test_project_natural_revalidation.py::test_late_project_change_no_partial_save[peer_version]`，两次独立隔离SQLite/实际Worker/显式MockTransport，各次最多900秒，均正常结束未超时。原sent==1、零typed保存、两Release保持及变更后旧plan拒绝等所有断言未改。第二次额外观测竞争callback恰1次RETURN，证明实际版本更新回调完成，未以发送前拒绝冒充该竞争测试。

| 独立单例批 | 秒 | span数 / 丢弃 | 主heartbeat最大秒 | 主线程BEGIN取得最大秒 |
|---|---:|---:|---:|---:|
{chr(10).join(rows)}

各批均1 PASS / 0 FAIL / 0 ERROR / 0 SKIP，RC0；不与旧完整批或其他历史测试累计。各自499真实文件pathset与before/after/执行副本/root/Git逐字节闭合。观测器hash在执行前COMMAND记录；终态后封存的observer/runner副本标明时点，并核observer hash一致。

第一批XML SHA256 `{a['xml_sha256']}`；第二批 `{b['xml_sha256']}`。第二批公开回调耗时{b['callback_direct_observation']['elapsed']:.6f}秒。真实书生/Intern及其他真实模型API调用0，未配置凭据或扩大费用/网络安全权限。

## 分段测量与不能推出的结论

SQLAlchemy公开cursor事件只观测原BEGIN IMMEDIATE取得/失败，不新增SQL，不录参数/数据。函数wrapper仍调用原函数一次、原事务enter/exit及异常行为不变；观测会扰动时序，不能用两次耗时作性能前后对照。tx.acquire包含连接和BEGIN，两者重叠。下面是第二次整条测试中的**inclusive嵌套调用**，不是互斥时间，合计不能当总耗时。

| 公开边界 | 调用数 | 最大秒 | inclusive合计秒 |
|---|---:|---:|---:|
{chr(10).join(parts)}

第二次主线程最长guard为{g['guard_seconds']:.6f}秒，其中直接source_scope为{g['source_scope_seconds']:.6f}秒，scope之后余量{g['after_source_scope_seconds']:.6f}秒。余量还含Run行读取、lease谓词与frozen contract证明，**纯lease谓词耗时NOT_RECORDED**。其他线程BEGIN最大{b['begin_acquisition']['other']['max_seconds']:.6f}秒、{b['begin_acquisition']['other']['errors']}次失败；BEGIN异常未记录SQLite errorcode，不能仅凭OperationalError类型认定全是busy或锁等待；回调后合同拒绝也不能当作旧发前Stale worker lease。旧68.5745秒失败的BEGIN/source_scope分段当时未记录，不能从本次成功运行倒推。

## 微去重候选的独立结论

members的load_family先走validate_frozen_candidate→compile_preview→自然编译器，随后members:145再次编译同候选且丢弃结果。独审证明编译器无DB/时钟/授权副作用，但两次SELECT的candidate一致性仍须明确保证。members/logic.context各自权限、版本、原来源及完整成员证明职责不同，不能删除这些验证。

第二次按caller文件/函数/行精确筛选members:145，实际{d['calls']}次、合计{d['sum_seconds']:.9f}秒、单次最大{d['max_seconds']:.9f}秒，约占成员重验inclusive耗时{100*d['fraction_of_members_inclusive']:.4f}%。第一批粗筛把graph.current中的编译也算入候选，上界72次/0.258204秒，并非精确重复次数；INITIAL_COARSE原输出保留，修正分析及METHOD_NOTE明确说明。

**该数据不足以将删除重复编译认定为租约修复，本轮未实施此微改。** 两次单例均未复现旧失败；具体瓶颈仍未知，因此没有获证实的最小产品修复可提交。未扩lease/Run预算、未跨事务或write epoch缓存、未删除授权证明、未改原竞争断言；也未转向其他微项。

## 剩余阻塞与未执行项

当前阻塞是旧发前租约失效未复现，且旧失效段缺公开分段证据。应保留旧FAIL，不能仅凭重跑通过关闭问题。此次已按有界范围完成两次观测，停止重试，未盲跑389。没有产品变更，未新增资格版本或声称修复后安全反例/完整回归通过。

完整389重跑、新修复反例测试、PG、Windows、原生浏览器、旧源码升级、人工语义、真实P-A/P-B、真实费用、远端CI、部署均NOT_RUN。没有新的工具授权拒绝；已知被拒私有DB/UDF/barrier、proc cwd及浏览器路径未重试，未删除未知锁。此前388P1F及审查JSON重建历史仍留在原归档，未覆盖。

[本轮证据索引](../evidence/project-peer-lease-20261015/README.md)含两批COMMAND/START/PROCESS_EXIT/XML/RESULT、499源码副本与manifest、公开边界数据、初始粗筛和更正、外部observer/runner及独审。证据完整性通过不等于产品通过；后续正常push核验回执单独存工作区，避免归档自引用。
'''
(B/'delivery/REPORT.md').write_text(t);(R/'docs/F2/ProjectPeerLeaseObservation20261015.md').write_text(t)
D=R/'docs/evidence/project-peer-lease-20261015';D.mkdir(parents=True,exist_ok=True)
(D/'README.md').write_text('''# peer_version有限观测证据（未证实修复）

基线2747eec91fdcfdefb6f575a8d96dbb0dab26114e。两个单例批各1PASS/RC0，完整旧批仍388PASS1FAIL/RC1/NOT_ACCEPTED；源码、测试、资格pin未变，不声称已修复。不累计两次单例为完整回归。

[报告](../../F2/ProjectPeerLeaseObservation20261015.md)。本包包含integration观测/执行/分析脚本、observation两次真实隔离测试及499源码/manifest/XML/日志、METHOD_NOTE粗筛修正、delivery报告和review独审。第一批INITIAL_COARSE是保留的粗筛上界，不当精确重复次数；第二批有精确caller及callback1RETURN。observer脚本副本在终态后封存并与执行前hash核对，不冒称启动时复制。

ARCHIVE.json/MANIFEST.json记录真实包大小/hash和全部regular成员集合，排除声明cache/symlink及根PACKAGE_RESULT自引用。独立外部审核逐成员比较原件/清单/tar的大小/hash和安全唯一路径。归档完整不升级产品验收。原完整FAIL和旧审查JSON重建说明仍在前批原归档，未复制覆盖。真实API0；完整389/安全反例/PG/Windows/原生浏览器/真实P-A/P-B/CI/部署未运行。
''')
print('Wrote explicit no-fix diagnostic report and index; src/tests unchanged.')
