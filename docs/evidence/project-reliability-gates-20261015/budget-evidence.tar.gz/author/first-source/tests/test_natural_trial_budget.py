"""Accounting primitives only; no provider, transport, LIVE approval or fee proof."""

import time
from concurrent.futures import ThreadPoolExecutor
from threading import Event, Thread
from types import SimpleNamespace

import pytest
from sqlalchemy import select, update

from sim2act.contracts import Strict
from sim2act.db import Store, delivery_graph_requests, fingerprint, projects, runs
from sim2act.errors import DomainError
from sim2act import natural_trial_budget as budget


class SyntheticContract(Strict):
    trial_key: str
    project_id: str
    principal_id: str
    runtime_id: str
    quota_subject: str
    expires_at: float
    caps: dict


def admitted(*args):
    return SimpleNamespace(scope="SYNTHETIC_ONLY", live_allowed=False,
        contract_fingerprint=fingerprint(args[3].model_dump()), stage=args[5],
        run_id=args[6], run_version=args[7], fence=args[8], expires_at=args[3].expires_at)


@pytest.fixture
def trial(env):
    store, settings, client, user, other, pid, resource = env
    with store.tx() as c:
        runtime = c.execute(select(projects.c.runtime_id).where(projects.c.id == pid)).scalar_one()
    contract = SyntheticContract(trial_key="trial", project_id=pid, principal_id=user,
        runtime_id=runtime, quota_subject="synthetic-account-" + pid,
        expires_at=time.time() + 1200,
        caps=dict(generate_requests=3, source_requests=2, cold_requests=2, max_requests=7,
                  max_output_tokens=1024, max_wire_bytes=32768, max_response_ascii_bytes=32768,
                  per_run_reserved=64000, total_reserved=192000, total_output_tokens=7168,
                  run_seconds=300, lease_seconds=30, requests_per_minute=1, paid_cap=0))
    rid = store.submit(user, pid, "synthetic accounting only", [], "generate")
    run = store.claim("synthetic-worker", 30)
    assert run["id"] == rid
    request = budget.Reservation(request_key="r1", stage="generate", run_id=rid,
        expected_version=run["version"], fence=run["fence"], wire_sha256="a" * 64, wire_bytes=100)
    return store, user, other, contract, budget.scope_for(contract, "approval"), request


def reserve(t, request=None, *, store=None, admission=admitted):
    s, user, _, contract, scope, original = t
    return budget.reserve(store or s, user, scope, contract, request or original, admission=admission)


def settle(t, *, admission=admitted, **changes):
    s, user, _, contract, scope, request = t
    response = budget.Settlement(request_key=request.request_key, response_sha256="b" * 64,
        response_ascii_bytes=100, prompt_tokens=5, completion_tokens=3, total_tokens=8)
    return budget.settle(s, user, scope, contract, response.model_copy(update=changes), admission=admission)


def rejected(code, action):
    with pytest.raises(DomainError) as caught:
        action()
    assert caught.value.code == code


def test_duplicate_cold_restart_original_key_is_read_only_and_nonrefundable(trial):
    first = reserve(trial)
    assert first["usage_status"] == "UNKNOWN" and first["total_tokens"] is None
    assert first["reserved_envelope"] == 1124 and first["reserved_requests"] == 1
    second_store = Store(str(trial[0].engine.url), test_only=True)
    try:
        duplicate = reserve(trial, store=second_store)
        assert duplicate["duplicate"] and not duplicate["dispatch_authorized"]
        result = settle(trial)
        assert result["total_tokens"] == 8 and result["status"] == "ACCOUNTED"
        assert budget.read(second_store, trial[1], trial[4])["ledger"] == result["ledger"]
        assert settle(trial)["duplicate"]
        rejected("VERSION_CONFLICT", lambda: reserve(trial,
            trial[-1].model_copy(update={"wire_sha256": "c" * 64})))
        rejected("VERSION_CONFLICT", lambda: settle(trial, total_tokens=9))
    finally:
        second_store.engine.dispose()


def test_two_stores_concurrent_same_key_one_slot(trial):
    second = Store(str(trial[0].engine.url), test_only=True)
    try:
        with ThreadPoolExecutor(max_workers=2) as pool:
            futures = [pool.submit(reserve, trial, store=s) for s in (trial[0], second)]
            results = [f.result() for f in futures]
        assert sorted(x["duplicate"] for x in results) == [False, True]
        assert all(x["reserved_requests"] == 1 for x in results)
    finally:
        second.engine.dispose()


def test_two_stores_different_keys_unknown_first_blocks_second(trial):
    second = Store(str(trial[0].engine.url), test_only=True)
    def attempt(s, key):
        try:
            return reserve(trial, trial[-1].model_copy(update={"request_key": key}), store=s)
        except DomainError as exc:
            return exc.code
    try:
        with ThreadPoolExecutor(max_workers=2) as pool:
            futures = [pool.submit(attempt, s, k) for s, k in ((trial[0], "a"), (second, "b"))]
            actual = [f.result() for f in futures]
        assert sum(isinstance(x, dict) for x in actual) == 1 and "OUTCOME_UNKNOWN" in actual
        assert budget.read(trial[0], trial[1], trial[4])["reserved_requests"] == 1
    finally:
        second.engine.dispose()


@pytest.mark.parametrize("change,code", [({"fence": 2}, "VERSION_CONFLICT"),
    ({"expected_version": 2}, "VERSION_CONFLICT")])
def test_actual_run_version_fence_refusal_has_no_partial_ledger(trial, change, code):
    rejected(code, lambda: reserve(trial, trial[-1].model_copy(update=change)))
    with trial[0].tx() as c:
        assert not c.execute(select(delivery_graph_requests)).first()


@pytest.mark.parametrize("mode", ["denied", "expired", "cancel"])
def test_initial_denial_expiry_cancel_no_partial(trial, mode):
    store, user, _, contract, scope, request = trial
    if mode == "expired":
        contract = contract.model_copy(update={"expires_at": time.time() - 1})
        scope = budget.scope_for(contract, "approval")
    if mode == "cancel":
        store.command(user, request.run_id, "cancel", request.expected_version)
    def denied(*args):
        raise DomainError("PERMISSION_DENIED")
    with pytest.raises(DomainError):
        budget.reserve(store, user, scope, contract, request,
                       admission=denied if mode == "denied" else admitted)
    with store.tx() as c:
        assert not c.execute(select(delivery_graph_requests)).first()


@pytest.mark.parametrize("mode", ["cancel", "revoked", "version", "fence", "unknown", "overflow"])
def test_late_or_unknown_usage_retained_halted_no_refund(trial, mode):
    reserve(trial)
    store, user, _, _, scope, request = trial
    if mode == "cancel":
        store.command(user, request.run_id, "cancel", request.expected_version)
    elif mode in {"version", "fence"}:
        with store.tx() as c:
            c.execute(update(runs).where(runs.c.id == request.run_id)
                      .values(**{mode: 2}))
    def denied(*args):
        raise DomainError("PERMISSION_DENIED")
    changes = dict(prompt_tokens=None, completion_tokens=None, total_tokens=None) if mode == "unknown" else {}
    if mode == "overflow":
        changes = dict(response_ascii_bytes=32769, prompt_tokens=1000, completion_tokens=1025, total_tokens=2025)
    result = settle(trial, admission=denied if mode == "revoked" else admitted, **changes)
    assert result["status"] == "HALTED" and result["reserved_envelope"] == 1124
    assert result["reserved_requests"] == 1 and not result["ledger"]["slots"][0]["accepted"]
    assert result["total_tokens"] == (None if mode == "unknown" else 2025 if mode == "overflow" else 8)
    assert budget.read(store, user, scope)["ledger"] == result["ledger"]
    with pytest.raises(DomainError):
        reserve(trial, request.model_copy(update={"request_key": "new"}))


def test_quota_across_trials_real_rate_no_wait_or_partial(trial):
    reserve(trial)
    settle(trial)
    s, user, _, contract, _, req = trial
    contract = contract.model_copy(update={"trial_key": "explicit-new"})
    rejected("RATE_LIMITED", lambda: budget.reserve(s, user, budget.scope_for(contract, "new"),
        contract, req, admission=admitted))
    with s.tx() as c:
        assert not c.execute(select(delivery_graph_requests).where(
            delivery_graph_requests.c.request_key == "explicit-new")).first()


def test_corrupt_pair_and_nonowner_fail_closed(trial):
    reserve(trial)
    s, user, other, _, scope, _ = trial
    rejected("PERMISSION_DENIED", lambda: budget.read(s, other, scope))
    with s.tx() as c:
        c.execute(update(delivery_graph_requests).where(delivery_graph_requests.c.kind == budget.KIND)
                  .values(fingerprint="0" * 64))
    rejected("VERSION_CONFLICT", lambda: budget.read(s, user, scope))


def test_fixed_caps_cannot_expand(trial):
    contract = trial[3]
    for field in contract.caps:
        caps = {**contract.caps, field: contract.caps[field] + 1}
        rejected("BUDGET_EXHAUSTED", lambda: budget.scope_for(
            contract.model_copy(update={"caps": caps}), "approval"))


def test_seven_actual_reservations_stage_binding_nontransfer_no_refund(trial):
    """Uses real 60s spacing and ordinary 30s heartbeats; no clock/lease patch."""
    store, user, _, contract, scope, first = trial
    last = None
    count = 0
    for stage, cap in budget.STAGES.items():
        request = first
        if stage != "generate":
            rid = store.submit(user, scope.project_id, "synthetic accounting only", [], stage)
            job = store.claim("worker-" + stage, 30)
            assert job["id"] == rid
            request = first.model_copy(update={"run_id": rid, "stage": stage,
                "fence": job["fence"], "expected_version": job["version"]})
        stopped = Event()
        failures = []
        with store.tx() as c:
            deadline = c.execute(select(runs.c.created_at).where(
                runs.c.id == request.run_id)).scalar_one() + 300
        def heartbeat():
            while not stopped.wait(10):
                try:
                    store.heartbeat("worker-" + stage, request.run_id, request.fence,
                        lease_seconds=30, _deadline=deadline,
                        _running_only=True)
                except BaseException as exc:
                    failures.append(exc)
                    return
        thread = Thread(target=heartbeat)
        thread.start()
        try:
            for index in range(cap):
                if last is not None:
                    delay = 60.05 - (time.time() - last)
                    if delay > 0:
                        time.sleep(delay)
                assert not failures
                count += 1
                req = request.model_copy(update={"request_key": "slot" + str(count)})
                current = budget.reserve(store, user, scope, contract, req, admission=admitted)
                last = current["ledger"]["last_reserved_at"]
                result = budget.settle(store, user, scope, contract,
                    budget.Settlement(request_key=req.request_key, response_sha256="b" * 64,
                        response_ascii_bytes=10, prompt_tokens=1, completion_tokens=1, total_tokens=2),
                    admission=admitted)
            rejected("BUDGET_EXHAUSTED", lambda: budget.reserve(store, user, scope, contract,
                req.model_copy(update={"request_key": "overflow-" + stage}), admission=admitted))
            store.command(user, request.run_id, "cancel", request.expected_version)
        finally:
            stopped.set()
            thread.join(timeout=5)
        assert not failures
    assert result["reserved_requests"] == 7 and result["reserved_envelope"] == 7868
    assert result["total_tokens"] == 14 and result["usage_status"] == "KNOWN"
    assert budget.read(store, user, scope)["reserved_requests"] == 7
