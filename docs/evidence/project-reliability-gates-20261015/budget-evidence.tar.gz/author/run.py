import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

repo = Path('/workspace/Sim2Act-trial-budget-20261015')
root = Path(__file__).parent
label = sys.argv[1]
command = ['/workspace/Sim2Act/.venv/bin/python', '-m', 'pytest', 'tests/test_natural_trial_budget.py', '-q', '--junitxml=' + str(root / (label + '.xml'))] + sys.argv[2:]
paths = ['src/sim2act/natural_trial_budget.py', 'tests/test_natural_trial_budget.py']
def snapshot():
    return {p: hashlib.sha256((repo / p).read_bytes()).hexdigest() for p in paths}
before = snapshot()
for name in paths:
    saved = root / (label + '-source') / name
    saved.parent.mkdir(parents=True, exist_ok=True)
    saved.write_bytes((repo / name).read_bytes())
env = dict(os.environ)
env.pop('SIM2ACT_TEST_DATABASE_URL', None)
env['PYTHONPATH'] = str(repo / 'src') + ':' + str(repo / 'tests')
started = time.time()
with (root / (label + '.stdout')).open('w') as out, (root / (label + '.stderr')).open('w') as err:
    child = subprocess.Popen(command, cwd=repo, env=env, stdout=out, stderr=err)
    (root / (label + '-running.json')).write_text(json.dumps(dict(command=command, pid=child.pid, before=before)))
    code = child.wait()
result = dict(command=command, exit_code=code, elapsed=time.time()-started, before=before, after=snapshot())
(root / (label + '-result.json')).write_text(json.dumps(result, indent=2))
print(json.dumps(result))
sys.exit(code)
