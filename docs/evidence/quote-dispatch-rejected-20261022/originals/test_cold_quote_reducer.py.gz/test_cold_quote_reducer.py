"""Explicit codec component only: zero Worker/Mock/HTTP/G0 or runtime enablement."""

import builtins
import gc
import hashlib
import json
import statistics
import sys
import time

import pytest
from sqlalchemy.engine import RowMapping
from sqlalchemy.engine.result import SimpleResultMetaData
from sqlalchemy.sql.elements import quoted_name
from sqlalchemy import select
from test_cold_graph_row_storage import row
from test_cold_typed_native import backend as backend
from test_cold_accounted_sqlite import forbid_execution as forbid_execution
from test_cold_accounted_sqlite import sql_facts as sql_facts

from sim2act import natural_spec_runtime as runtime
from sim2act.errors import DomainError
from sim2act import natural_live_admission as gate
from sim2act.db import runs, attempts, grants


@pytest.fixture
def reducer(backend):
    result = backend.make_quote_reducer(runtime._ColdGraphPickler.reducer_override,
        quoted_name, runtime._cold_graph_pickle_marker)
    assert result is not None
    return result


def encoder(reducer):
    # Explicit test-only wiring; the default runtime's Pickler is untouched.
    class Candidate(runtime._ColdGraphPicklerBase):
        reducer_override = reducer
    def encode(value):
        output = runtime._ColdGraphBytesIO()
        output.write(b'SIM2ACT_COLD_GRAPH_PICKLE_V2\x00')
        Candidate(output, protocol=5).dump(value)
        return output.getvalue()
    return encode


def encode(value, reducer):
    return encoder(reducer)(value)


def test_exact_original_tag_marker_aliases_and_complete_row(backend, reducer):
    original = runtime._ColdGraphPickler.reducer_override
    tag = next(item for item in original.__code__.co_consts if item == 'quoted-name-v1')
    value = quoted_name('same', True)
    payload = reducer(value)
    assert payload[0] is runtime._cold_graph_pickle_marker
    assert payload[1][0] is tag
    assert type(payload[1][1]) is str
    actual_row = row()
    data = object.__getattribute__(actual_row, '_data')
    root = dict(tag=tag, marker=runtime._cold_graph_pickle_marker,
        values=[value, value, quoted_name('same', False), tag],
        row=actual_row, hidden_alias=data[2], keys=actual_row._parent._keys,
        limits=runtime.Limits(max_requests=4, max_tools=1, max_repairs=0,
            max_total_tokens=1000, max_output_tokens=100, run_seconds=300))
    assert encode(root, reducer) == runtime._cold_graph_bytes(root)
    data[2]['hidden'].append('fresh')
    assert encode(root, reducer) == runtime._cold_graph_bytes(root)
    native, python = backend.quote_reducer_counts(reducer)
    assert native > 0 and python > 0


@pytest.mark.parametrize('name', ['type', 'str'])
def test_unknown_callback_once_with_original_python_frame(reducer, monkeypatch, name):
    value, calls = quoted_name('fresh', None), []
    error = ValueError('exact callback failure')
    def callback(obj):
        calls.append(sys._getframe(1).f_code)
        raise error
    with monkeypatch.context() as patch:
        patch.setattr(runtime, name, callback, raising=False)
        with pytest.raises(ValueError) as caught:
            reducer(value)
        assert caught.value is error
    assert calls == [runtime._ColdGraphPickler.reducer_override.__code__]
    assert reducer(value)[1][1] == 'fresh'


@pytest.mark.parametrize('name', ['Limits', '_ColdGraphRowMapping'])
def test_prior_branch_rebinding_uses_original_helper_and_exception(reducer, monkeypatch, name):
    value, calls = quoted_name('fresh', None), []
    error = ValueError('earlier branch')
    def helper(obj):
        calls.append(obj)
        raise error
    with monkeypatch.context() as patch:
        patch.setattr(runtime, name, quoted_name)
        patch.setattr(runtime, '_cold_graph_limit_values' if name == 'Limits'
            else '_cold_graph_row_storage', helper)
        with pytest.raises(ValueError) as caught:
            reducer(value)
        assert caught.value is error
    assert calls == [value]


def test_quoted_descriptor_code_change_and_unknown_reducer_fail_once(reducer, monkeypatch):
    calls, value = [], quoted_name('fresh', None)
    error = ValueError('unknown __str__')
    def string(obj):
        calls.append(sys._getframe(1).f_code)
        raise error
    with monkeypatch.context() as patch:
        patch.setattr(quoted_name, '__str__', string)
        with pytest.raises(ValueError) as caught:
            reducer(value)
        assert caught.value is error
    assert calls == [runtime._ColdGraphPickler.reducer_override.__code__]
    def replacement(self, obj):
        return ('changed code', obj)
    with monkeypatch.context() as patch:
        patch.setattr(runtime._ColdGraphPickler.reducer_override, '__code__', replacement.__code__)
        assert reducer(value) == ('changed code', value)
    class Foreign:
        def __reduce__(self):
            pytest.fail('Unknown reducer callback must stay unreachable')
    for codec in [runtime._cold_graph_bytes, lambda root: encode(root, reducer)]:
        with pytest.raises(DomainError) as caught:
            codec(Foreign())
        assert caught.value.code == 'VERSION_CONFLICT'
    assert reducer(value)[1][1] == 'fresh'


def test_import_callback_changes_later_leaf_without_cached_metadata(reducer, monkeypatch):
    metadata = SimpleResultMetaData([quoted_name('visible', None)])
    index = {'visible': 0, 'hidden': 1}
    rows = [RowMapping(metadata, None, index, ('same', 'same')) for _ in range(2)]
    original_import = builtins.__import__
    def run(codec):
        index['hidden'] = 1
        calls = []
        def importing(name, *args, **kwargs):
            if name == runtime.__name__ and not calls:
                calls.append(name)
                index['hidden'] = 0
            return original_import(name, *args, **kwargs)
        with monkeypatch.context() as patch:
            patch.setattr(builtins, '__import__', importing)
            result = codec(rows)
        assert calls == [runtime.__name__]
        return result
    assert run(runtime._cold_graph_bytes) == run(lambda values: encode(values, reducer))


def test_counts_refs_and_component_net_cpu(backend, reducer, tmp_path):
    # Shape is explicit, not asserted representative of the complete G0 graph.
    values = [quoted_name('column-' + str(i), bool(i % 2)) for i in range(128)]
    candidate = encoder(reducer)
    expected = runtime._cold_graph_bytes(values)
    assert encode(values, reducer) == expected
    gc.collect()
    refs = tuple(sys.getrefcount(obj) for obj in [runtime._cold_graph_pickle_marker,
        runtime._ColdGraphPickler.reducer_override, quoted_name])
    samples = []
    for i in range(7):
        sample = {}
        for name in (('old', 'candidate') if i % 2 == 0 else ('candidate', 'old')):
            start = time.thread_time_ns()
            for _ in range(500):
                actual = runtime._cold_graph_bytes(values) if name == 'old' else candidate(values)
            sample[name] = (time.thread_time_ns() - start) / 1e9
            assert actual == expected
        samples.append(sample)
    gc.collect()
    assert refs == tuple(sys.getrefcount(obj) for obj in [runtime._cold_graph_pickle_marker,
        runtime._ColdGraphPickler.reducer_override, quoted_name])
    report = dict(samples=samples, repeats=500, shape='128 distinct quoted_name values',
        medians={name: statistics.median(sample[name] for sample in samples)
            for name in ['old', 'candidate']}, dispatch=backend.quote_reducer_counts(reducer),
        limits='component only; both classes hoisted, fresh stream/pickler/memo per call, not G0 or full-chain')
    (tmp_path / 'quote-cost.json').write_text(json.dumps(report, indent=2)+'\n')
    print('quote-cost', report)


def test_actual_isolated_sqlite_row_and_contract_batch(backend, reducer, sql_facts, tmp_path):
    f = sql_facts
    with f.store.tx() as connection:
        values = {table.name: connection.execute(select(table)).mappings().all()
            for table in (runs, attempts, grants)}
        # Keep the codec's accepted list type, every original RowMapping and its
        # complete hidden data/metadata. No reconstruction of visible pairs.
        values = {key: list(rows) for key, rows in values.items()}
        values['contract'] = gate._trial_typed_storage(gate.PBTrialContract, f.contract)
        candidate = encoder(reducer)
        expected = runtime._cold_graph_bytes(values)
        assert candidate(values) == expected
        before = backend.quote_reducer_counts(reducer)
        samples = []
        for index in range(7):
            sample = {}
            for name in (('old', 'candidate') if index % 2 == 0 else ('candidate', 'old')):
                start = time.thread_time_ns()
                for _ in range(100):
                    actual = runtime._cold_graph_bytes(values) if name == 'old' else candidate(values)
                sample[name] = (time.thread_time_ns() - start) / 1e9
                assert actual == expected
            samples.append(sample)
        after = backend.quote_reducer_counts(reducer)
        report = dict(samples=samples, repeats=100, wire_bytes=len(expected),
            shape={key: len(rows) for key, rows in values.items() if type(rows) is list},
            medians={name: statistics.median(sample[name] for sample in samples)
                for name in ['old', 'candidate']},
            dispatch_delta=[right-left for left,right in zip(before, after, strict=True)],
            limits='isolated SQLite fixture batch, not full Cold graph/chain or G0')
        (tmp_path / 'sqlite-quote-cost.json').write_text(json.dumps(report, indent=2)+'\n')
        print('sqlite-quote-cost', report)


def test_known_non_equivalence_disqualifies_candidate(reducer, monkeypatch):
    # The original reducer has a real Pickler self. The experimental standalone
    # C callable cannot preserve it on a changed-code fallback. This witness
    # DISQUALIFIES the candidate; passing this test does not qualify dispatch.
    def replacement(self, value):
        if value is _cold_graph_pickle_marker:
            return NotImplemented
        return (_cold_graph_pickle_marker, ('self-binding', self is not None))
    value = quoted_name('fresh', None)
    candidate = encoder(reducer)
    with monkeypatch.context() as patch:
        patch.setattr(runtime._ColdGraphPickler.reducer_override, '__code__', replacement.__code__)
        old, new = runtime._cold_graph_bytes(value), candidate(value)
    assert old != new
    print('DISQUALIFIED changed-code fallback self mismatch',
        dict(old_sha256=hashlib.sha256(old).hexdigest(),
            candidate_sha256=hashlib.sha256(new).hexdigest()))
