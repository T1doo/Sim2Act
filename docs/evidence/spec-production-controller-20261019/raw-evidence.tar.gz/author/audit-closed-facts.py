from pathlib import Path
import json,hashlib,base64,collections
root=Path(__file__).parent;where=root/'qualified-third/actual/test_live_shaped_spec_generati0'
d=json.loads((where/'closed-state.json').read_text());proof=json.loads((where/'controller-proof.json').read_text())
def fp(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
rows=d['delivery_graph_requests'];by_attempt={r['id']:r for r in d['attempts']};by_run={r['id']:r for r in d['runs']};contracts={r['run_id']:r for r in d['run_contracts']}
for row in rows:assert row['fingerprint']==fp(row['snapshot']) and row['request_fingerprint']==fp(row['snapshot']['request'])
journals=[r for r in rows if r['kind'] in ['uninstalled-production-trial-journal.v1','uninstalled-production-trial-journal.v1_seal']]
assert len(journals)==2 and journals[0]['snapshot']==journals[1]['snapshot']
ledger=journals[0]['snapshot']['response']['ledger'];slots=ledger['slots'];assert len(slots)==7 and not ledger['halted'] and all(s['accepted'] and s['attempted'] for s in slots)
assert collections.Counter(s['identity']['stage'] for s in slots)==dict(generate=3,source=2,cold=2)
assert set(by_attempt)=={s['identity']['attempt_id'] for s in slots}
exchanges=[json.loads(x) for x in (where/'mock-exchanges.jsonl').read_text().splitlines()];assert len(exchanges)==7
facts=[]
for slot,exchange in zip(slots,exchanges,strict=True):
 item=slot['identity'];aid=item['attempt_id'];attempt=by_attempt[aid];run=by_run[item['run_id']];contract=contracts[item['run_id']]
 assert attempt['run_id']==run['id'] and attempt['mode']=='LIVE' and contract['snapshot']['mode']=='live'
 assert attempt['parameters']['pa_trial_binding']['version']=='spec-production-controller.v1'
 assert run['id']==proof[item['stage'] if item['stage']!='generate' else 'generation']
 captures=[r for r in rows if r['kind'] in ['uninstalled-production-trial-capture.v1','uninstalled-production-trial-capture.v1_seal'] and r['request_key']==aid]
 assert len(captures)==2 and captures[0]['snapshot']==captures[1]['snapshot']
 captured=captures[0]['snapshot'];assert captured['request']['identity']==item
 raw=captured['response'];request=base64.b64decode(exchange['request_b64'],validate=True);response=base64.b64decode(exchange['response_b64'],validate=True)
 assert raw['provenance']=='SPEC_PRODUCTION_CONTROLLER' and base64.b64decode(raw['body_b64'],validate=True)==response
 assert hashlib.sha256(request).hexdigest()==item['wire_sha256'] and len(request)==item['wire_bytes']
 assert hashlib.sha256(response).hexdigest()==raw['raw_sha256']==slot['settlement']['response_sha256']
 assert raw['outcome']==slot['settlement'] and raw['raw_bytes']==len(response)
 facts.append(dict(stage=item['stage'],run_id=run['id'],run_status=run['status'],attempt_id=aid,attempt_mode=attempt['mode'],frozen_mode=contract['snapshot']['mode'],marker=attempt['parameters']['pa_trial_binding']['version'],capture_provenance=raw['provenance'],full_identity_pair_matches=True,request_sha256=item['wire_sha256'],response_sha256=raw['raw_sha256'],reserved_at=slot['reserved_at']))
gaps=[b['reserved_at']-a['reserved_at'] for a,b in zip(facts,facts[1:])];assert all(x>=60 for x in gaps)
body_rows=[r for r in rows if r['kind'] in ['natural_source_request_body.v1','natural_source_request_body.v1_seal','natural_source_response_body.v1','natural_source_response_body.v1_seal']];assert len(body_rows)==16
assert all(r['snapshot']['response']['provenance']=='SPEC_PRODUCTION_CONTROLLER' for r in body_rows)
assert by_run[proof['generation']]['status']=='PARTIAL'
for stage,version in [('source',1),('cold',2)]:
 job=by_run[proof[stage]];assert job['status']=='SUCCEEDED' and job['result']['result_version']==version
 app=next(r for r in d['internal_app_runs'] if r['id']==job['result']['app_run_id'])
 assert app['output']['checklist']['owner_acceptance']=='PENDING' and app['output']['checklist']['semantic_goal_acceptance']=='NOT_RUN'
(root/'closed-facts.json').write_text(json.dumps(dict(classification='AUTHOR_STDLIB_RECOMPUTATION_OF_CLOSED_SYNTHETIC_FILES_NOT_PRODUCT_REEXECUTION',tables=len(d),graph_rows=len(rows),all_graph_row_hashes_valid=True,attempts=facts,gaps_seconds=gaps,body_archive_rows=len(body_rows),captured_response_pairs=7,journal_slots_accepted=7,generation='PARTIAL',source='SUCCEEDED/v1',cold='SUCCEEDED/v2',owner_acceptance='PENDING',semantic_goal_acceptance='NOT_RUN',real_requests=0),indent=2)+'\n')
print('closed facts PASS')
