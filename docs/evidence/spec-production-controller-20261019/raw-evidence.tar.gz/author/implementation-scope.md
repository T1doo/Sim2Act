# Implementation scope (not a test verdict)

Base local HEAD: a343c60a8446d697b684d47862d9a9f1c61d7182. Existing 15 local commits after acknowledged a7403b379b1278fd1be533ca21d790f0311244af preserved. This task does not contact any Git remote or auth service.

ProductionTrialBinding selects the original P-A TrialContract/TrialContractV2 only, reusing JournalTrialBinding closed contract/account validation and original Worker/Run/Attempt/controller/journal. Explicit all-five worker CLI metadata selection calls install; defaults remain disabled. Fixed production_evidence.resolve_account still raises LIVE_BLOCKED; no credential, account fact, approval, entitlement, Grant or software anchor was installed. Existing application and Run/phase authorization, quotas, cancellation, exact versions, original lease/deadlines and receipt accounting remain in place.

The isolated tests replace precisely environment eligibility, fixed resolve_account and software _qualified in the test process. This is not real lawful admission. SQLite is intentionally substituted for production PostgreSQL, and finite MockTransport receives actual serialized bodies while ordinary HTTP transports are rejected. LIVE in these synthetic Core Attempt records is the branch-under-test marker, not evidence of real provider provenance.

Reviewer findings fixed before current qualification: public offline sender rejection for exact Production binding, original frozen Run mode anchoring of capture history with old no-Core-Attempt compatibility, BodyArchive source classification, production marker participation in existing same-read-segment full-proof reuse. The earlier Source RUNNING/no-step failure is an observed failure with exact cause unproven; the cache omission is a static candidate, not retrospective proof of causation. No lease/RPM/time expansion, private holdout, old sealed-root write or historical 56-node rerun.

Not executed: real service/model/semantic scenario, Windows, native browser, PG concurrency, remote CI, deploy or publish. The old full-disk independent-review absence remains a gap.
