# Initial streaming typed-cohort code review

Result: two P2 findings require closure before a code ACK. This is an initial-byte review, not a final-source review or test result.

Read-only source hashes:

- `_cold_typed_stream.py`: `130c75f0ca683dafc1402e8a46b394bee496638a66a01460dc41192d6519f4df`
- `natural_live_admission.py`: `1d9f85ab98a71ba00715b6a2c64037a22878280eb43965515762f7b7b9914749`

P2-1, `_cold_typed_stream.py:187-189`: exact `SchemaSerializer` type does not identify the original standard serializer. A replacement instance of that exact type can contain a custom plain serialization function while `expected.model_dump` remains the original BaseModel function. A callback which mutates raw and returns the same changed content reaches the new live-raw comparison; the old pre-serializer snapshot would reject it. The documented fallback guarantee therefore does not yet cover same-type serializer replacement. Preserve an exact trusted serializer identity/provenance for fixed schemas, or route unqualified metadata to the original snapshot algorithm. A pure differential test should use a replacement exact SchemaSerializer, not only a foreign fake serializer object.

P2-2, `:187`: ordinary `expected.model_dump` lookup occurs before the complete actual-storage gate at `:191`. A class descriptor replacement can invoke its `__get__` callback during eligibility classification. With malformed actual storage, the old algorithm rejects before this attribute lookup; the new one invokes it first. Move full actual gating before callable/serializer dispatch eligibility, or use callback-free static class-dictionary classification which preserves that ordering. Test an invalid actual model together with a dump descriptor tripwire.

The main iterator structure otherwise matches the reviewed local design: complete actual validation precedes complete raw validation and mismatch checks; actual headers and the two None omissions match the old helper; only controlled scalar/container types are traversed; active ancestry is checked before completed-node reuse; comparison pairs are invocation-local, scalars do not use identity equality; raw RowMapping uses the existing safe visible projection; root raw remains exact dict. The six-line caller integration leaves the old snapshot fallback and guard/CGR functions unchanged. No additional source blocker was established in this initial pass. This statement is limited to the two hashes above and does not attest to author test outcomes.

Reviewer executed zero product imports, tests, DB operations, Worker/Mock/G0/PB/launcher invocations; no repository writes. Findings were sent to the sole writer immediately. Later fixes require a separate hash-bound closure review.
