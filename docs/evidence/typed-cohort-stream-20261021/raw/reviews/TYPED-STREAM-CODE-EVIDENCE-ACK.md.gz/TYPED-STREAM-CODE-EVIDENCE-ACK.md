# Streaming typed-cohort code and evidence review

Decision: **ACK for the frozen streaming comparator and stated local/regression evidence**. No blocking source finding remains in this review. This is not whole-owned migration, successful complete Cold tail, G0/deadline acceptance, account qualification or authorization for a new window.

Baseline HEAD: `6f2a848f701673c3c26a24b93eee9a15fbeb5d7d`.
Final SHA-256:

| File | SHA-256 |
| --- | --- |
| src/sim2act/_cold_typed_stream.py | 38eb83139b6aaf70f0e624075951fb0f5caf5537c306c2fb9a1356275107868f |
| src/sim2act/natural_live_admission.py | 1d9f85ab98a71ba00715b6a2c64037a22878280eb43965515762f7b7b9914749 |
| tests/test_cold_typed_stream.py | fdc35cde14d40a58b0a364e9d8a71fe8de9cf6b8d2f8fd0edd6c1fe4543bff5e |
| unchanged closure witness test | a4b3af0d09f5e0573c70fa307976bf2722575189fc0b15312178301aa3a8f310 |

Reviewer read source/diff, test definitions, author logs/XML/manifests and pinned dependency declarations, and independently hashed the files. Reviewer ran no code, tests, DB/SQL, Worker, product, Mock/model, G0, profile or signals and wrote no repository files. Only these `/tmp` reports were written.

## Scope and original boundaries

The sole existing-source edit is six added lines in `_trial_typed_values`: lazy import, standard stream attempt and old snapshot fallback. No existing `_trial_typed_guard`, `_graph_trial_produced`, runtime call site, CGR, SQL/authorization call or business clock location is moved/deleted. Parent failures still propagate before the value pass. Original model cohort growth and fresh producer calls remain; no prior validation/PASS/identity grants permission.

This is a **unified default helper change**, covering every `_trial_typed_values` caller, including non-native/default graph helpers and post uses. It is not gated only to explicit native mode. Direct `_trial_typed_storage` use by CGR `input_bytes` remains the original complete-storage path; the change does not eliminate CGR hash/serialization work or claim every typed traversal is removed.

## Comparator reasoning

- Exact root class/known nested type and complete Pydantic raw/fields/fields-set/extra/private gates are retained. Iterative DFS keeps the original actual storage order and tests active cycles before completed-node reuse. Model-header projections are invocation-local and retain sources; there is no cross-pin cache.
- The raw pass still validates the entire allowed raw graph, including keys, native RowMapping/quoted-key business projection, cycles and unknown objects. A known value mismatch is delayed until this raw gate completes, so it cannot hide a later raw rejection. Raw-validation completion and actual/raw pair equality use different memo sets; a raw node having been validated does not establish equality with a different actual node.
- Native scalar/container types remain exact, preserving bool/int, int/float, list/tuple, NaN rejection, accepted infinities and signed-zero rules of the reference comparator. Actual omitted `BranchCondition.value=None` and `WorkflowStep.when=None` are represented virtually. An omitted key supplied in raw cannot replace a different required field; the recorded omission regression now rejects at the original storage-comparison boundary.
- The fixed standard serializer is still actually invoked. Its returned value is compared strictly against the raw virtual projection. Nested fixed model serializers are inspected as well as the root; method/descriptor/replaced-extension cases fall back to the original pre-serializer snapshot bridge. This reasoning is for the fixed trusted catalog and pinned Pydantic/extension environment, not a general arbitrary-code-mutation defense or a new serializer permission.
- The old snapshot bridge remains verbatim for a nonstandard serializer. That path can perform additional preliminary pure validation before the old bridge, so no claim is made that all low-level traversal counts remain identical. Original parent/CGR/SQL/time call order and count remain unchanged by the source diff.

The standard path removes recursive actual-storage and saved-raw materialization. It still allocates iterator/memo/header metadata, required non-native raw mapping projections, and the original model_dump output. It is neither zero-allocation nor a bounded RSS guarantee. Mutable aliases remain freshly compared; no ownership exemption is introduced.

## Author evidence and exact versions

The broad frozen batch reports **111 passed / 71.06 s**, one existing warning; JUnit reports tests=111, failures/errors/skips=0, time=71.063. It ran source `6660067b67684cc1aefea8dc98691634da3888f30a0b55bff57334a781e32563`, admission `1d9f...`, and the then test `b9d50805...` frozen in `frozen-before.json`/`frozen-after111.json`.

Final source `38eb...` differs from the preserved pre-annotations source only by seven local variable type declarations, without assignment. The author records recursively equal runtime bytecode metadata; reviewer did not execute that compilation/check, but independently read the annotation-only diff. Final targeted **37 passed / 11.87 s**, one existing warning; JUnit tests=37, failures/errors/skips=0, time=11.874, actually ran the final hashes above. It includes the reverse-DAG pair case and the two existing real SQLite Approval alias witnesses. Final before/after manifests are byte-identical (SHA-256 `81014047de8e1a54ce2f1da46877770a9f473ac9219d14bf90cf377542a336cf`) and match independently read current files. These overlapping batches are **not 148 distinct tests**, and 111 is not represented as a final-test-hash full rerun.

The differential reference directly invokes the old four-stage complete algorithm. Cases cover complete headers/storage, mixed errors/order, actual/raw cycles and unknowns, both DAG directions, RowMapping/quoted keys, scalar/container domains, the two omissions, serializer replacement and raw snapshot mutation, new-call alias drift, parent exception identity and content-only UNKNOWN/RunCheck data. SourceVerificationResult UNKNOWN is not a resolver ALLOW or authority. The normal stream test forbids calling old copy/comparison helpers, while a fresh raw mutation is still rejected on the next invocation.

The local 11-model actual SQLite cohort observation is only a 25387-byte raw-JSON sample. In its final log, 40 iterations have old thread CPU 53223655/53279458 ns and stream 48865494/49261534 ns; traced peak observations are old 67912/62168 bytes versus stream 14720/14720. These are finite local thread-time/tracemalloc observations, not RSS, candidate-ledger accounting, complete-tail CPU or a forecast of meeting 30 seconds. No fresh full G0/Mock/model was run.

Historical initial/differential logs remain distinct: differential-1 had 28P2F; the dedicated omission-before check had 1F/32 deselected and showed an incorrect error boundary, now covered and fixed. Initial mypy and the first `mypy-final` logs had type-annotation errors; final corrected mypy reports success for two source files and corrected Ruff reports all checks passed. Earlier failures are not relabelled as passing.

## Full-tail limitation retained

No reusable complete native prepare -> first commit -> receipt/parse -> second commit -> normal original scope fixture meeting the no-safety-stub rule is established. Exact ProductionTrialBinding still routes to the unregistered fixed production account resolver, which denies SOURCE_MISSING; SQL seeding cannot authorize it. Existing lower native/base/receipt tests and synthetic coordinator stand-ins are not full-tail acceptance. The test/source-missing constraint is independent of this comparator's local equivalence evidence.

The complete tail remains NOT RUN/NOT PROVEN. No owned-consumer migration, transaction split, lease/heartbeat change, safety gate weakening, new allowance or new window follows from this ACK.

## Final README review

`docs/evidence/typed-cohort-stream-20261021/README.md` SHA-256 `ba1979bf4a5da0e992307b6629097ecbb0c0b1e9f9e3a205d21af38423fbbf91` was read after the frozen code/evidence review. No blocking exaggeration or required correction was identified. It explicitly identifies the unified default helper scope, unchanged direct CGR storage, additional fallback pure prechecks, separate 111/37 source versions, local-only CPU/traced-allocation sample and source-missing full-tail limit. Its 7.9% observation is clearly confined to this small sample, without G0/30-second extrapolation.

The README also appropriately limits snapshot-equivalence claims for coordinated mutation or simultaneous schema/serializer code replacement. Primary source verification supports its static-lookup and pinned extension metadata explanations: [Python getattr_static](https://docs.python.org/3.12/library/inspect.html#inspect.getattr_static), [pydantic-core 2.41.5 serializer metadata](https://github.com/pydantic/pydantic-core/blob/v2.41.5/src/serializers/mod.rs#L174), and [nested serializer dispatch](https://github.com/pydantic/pydantic-core/blob/v2.41.5/src/serializers/infer.rs#L589). The extension's reduce metadata returns stored schema/config references; it is not a serialization or pickle-load operation. No further code/test execution or broader review was performed for this README increment.
