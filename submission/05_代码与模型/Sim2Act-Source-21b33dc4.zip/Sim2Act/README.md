# Sim2Act

> **当前源码候选4e7b4443（2026-11-01，未替代安装包）**。先完成原30秒CPU／墙钟归因，拒绝低收益缓冲池；默认完整字典边减少类型派发，校验、动态授权、原子写和独立G1保留。313项相关／真实信号回归零失败／跳过。同输入signed120两笔提交85.151／89.237秒，比[97基线](docs/evidence/graph-version-facts-20261101/README.md)各少3.434／4.093秒，仅签本次样本；首次新进程回读与真实持锁取消／默认worker副本收敛CANCELLED通过。**原30仍在首次DML前G0拒绝**，长写锁和完整PB合同所有权缺口未解决。[精确源码、CPU热点、失败和实际范围](docs/evidence/g0-attribution-edge-20261101/README.md)。旧35 Linux限制候选保留，不扩签新安装包、Windows／PG／大型live或全产品验收。

> **默认Graph真实时钟源码：35eaa941（2026-11-01）**。已修跨Graph清理归属，并将新协议同次版本读取的重复资格核合为一次fresh C检查，完整动态门／五写／G1保留。匹配显式120两笔总计113.804/116.194降至87.406/94.006秒，保存与首次回读通过；原控制检查次数一致。189相关回归零失败／跳过；真实G1取消完整回滚，默认worker收敛CANCELLED。[原始对照、原30失败与全部边界](docs/evidence/graph-current-real-clock-20261101/README.md)。[新Linux限制候选](deliverables/limited-graph-current-20261101/README.md)实际安装CSV30/v1保存／重开通过；**原普通30仍在首次写前G0拒绝**，长锁、新Windows、正式PG／大型live未解决，非全产品完成。

> **默认 Graph 完整版本协议源码：4d0b16f2（2026-10-31）**。Graph/Frontier按版本持有完整不可变V2期望，check、selector、fallback、export及G1 proof消费同版本，W5→G1仍原完整执行。相关172项零失败／零跳过；一次实际Cold五写、完整G1及SQL提交已验证，6次固定Mock、0real、文件SQLite、虚拟业务时钟，**不是原30秒性能验收**。[完整接线、失败对照、冻结版本和边界](docs/evidence/graph-version-lifecycle-20261031/README.md)。新源码未重新打包，以下2ad Linux候选保留；新Windows／正式PG／大型live及完整交付仍未验。

> **当前更早截止修复候选：2ad32276（Linux x86_64／CPython3.12）**。[包身份及使用范围](deliverables/limited-text-candidate-deadline-20261031/README.md)。签120结算也受原更早state截止约束，原越界提交反例已实修；307／安装44项定向回归通过，范围重叠。匹配大型两笔保存／首次重开通过，但G0为31.09／30.96秒、writer45.45／49.60秒、total76.54／80.56秒，比基线更慢，**未解决原普通30秒目标**。[原失败、实际对照及未实现的最小完整架构](docs/evidence/cold-earliest-deadline-boundary-20261031/README.md)。本轮0新真实模型，未改main／Release、Windows／PG未验；不是全产品完成。

> **前版图错误边界修复候选：2d41ad38（Linux x86_64／CPython3.12）**。[ZIP、准确身份、安装／停止／卸载范围](deliverables/limited-text-candidate-graph-fixed-20261031/README.md)。原12图失败逐项闭合：11项fixture替换生产函数违反原代码门，去替换后暴露1项真实frontier AttributeError，已修受控拒绝且完整门保留。冻结293及新安装59项零失败／零跳过；新包CSV=30保存／首次重开／原键、正常关闭及专用环境卸载后数据保留实测通过。[失败原件、逐项对照和实际流程](docs/evidence/graph-fixture-and-installed-cleanup-20261031/README.md)。本轮0新真实模型调用，仅核前版真实结果兼容；非Windows EXE／全产品／正式Release，PG／大型Cold live及30秒稳定性能缺口仍保留。

> **前版真实模型限制候选：1a23c032（Linux x86_64／CPython3.12）**。[ZIP、一次启动步骤、版本与哈希](deliverables/limited-text-candidate-final-20261031/README.md)。已新安装并从源码目录外执行：新direct.v2单文本目标2次真实Intern、1739 tokens、6.39秒独立验收保存及首次重开，原键不重放；历史UNKNOWN和格式失败保留。旧SQLite30秒续租／提交及更窄state截止已补尾检，原120秒合同未改；安全修复不冒充性能达标。[分版本测试、失败及实际证据](docs/evidence/finite-lease-and-installed-v2-20261031/README.md)。默认模型关闭，非Windows EXE／正式Release，PG／大型Cold live及30秒稳定性能仍未验。

> **可启动的限制候选：6424cc04（Linux x86_64／CPython3.12）**。[ZIP、版本与哈希](deliverables/limited-text-candidate-20261031/README.md)。已从wheel新安装并实际启动，显式单文本目标2次真实Intern、1477 tokens、5.16秒完成保存及首次重开；默认CLI关闭模型，自由目标明确拒绝。包不含运行时／依赖wheelhouse，也不是Windows EXE或正式Release。[实际安装、额外失败和范围](docs/evidence/limited-text-installed-20261031/README.md)。

> **首版有限真实目标源码：fc978d31（2026-10-31）**。普通任务入口显式选择单文本逐字合同后，真实 Intern→原授权工具→独立验收→保存→首次新进程重开已通过：2次真实请求、1513 tokens、5.69秒，`SUCCEEDED / PASS_EXACT_READ_CONTRACT`，原键无重放；前次8秒超时的UNKNOWN保留在同一账本。302＋84项定向回归零失败／零跳过。[完整源码、真实失败／成功证据与范围](docs/evidence/intern-exact-goal-live-20261031/README.md)。默认模型仍关闭；通用语义、人工验收、正式PG／大型Cold真实模型整链及新版Windows不据此通过，30秒目标仍未稳定达到。旧实例续接与原58项修复见[前版记录](docs/evidence/text-current-target-20261031/README.md)。

> **最新默认生命周期修复：bbe2a11c（2026-10-31，Linux／合成Mock／文件SQLite）**。两笔大型Cold已提交并经首次新进程重开核对；实际持锁取消完整回滚后，默认worker收敛为CANCELLED，重复取消和再次重启无重放。修复了回调耗尽原期限后仍可提交的边界，未增加任何时限。G0为29.41／31.34秒、写入区段44.29／45.97秒，30秒目标仍未稳定达成；本版不是正式PG、真实模型整链或新Windows验收。[冻结源码、原始输出与限制](docs/evidence/sqlite-commit-boundary-20261031/full-acceptance/README.md)。
> **历史完整链源码：9523d3e2（Mock／文件SQLite）**。Generate→Source→提取→fresh Cold Store→完整G0/G1→保存结果，在真实时钟、7次有限Mock下通过，两次结算88.137/97.243秒，写入区段上界52.821/54.959秒；独立进程只读重开一致。原结算期限已接入写入准入，G0/G1取消、材料竞争及撤权均有实际回滚证据。[精确版本、热点表、失败与限制](docs/evidence/cloud-cold-deadline-20261030/README.md)。计时含被动监测，不能据此证明稳定因果提速；明确120秒SQLite合同未扩大，原30秒、真实模型整链、PG及自然语义未通过。以前失败及B2/9a通过证据保留，不改签为新版本通过。
> 可独立使用的[空白合成桌面工作台与首次CSV流程](docs/PreviewRelease.md)不需要PG或模型密钥。固定免费Intern已有[独立真实提取证据](docs/evidence/cloud-settlement-20261028/README.md)，免费授权有效；[正式连接及精确试运行选择](docs/ProductionConnection.md)仍须使用已有应用连接、身份和原审批。桌面源包、EXE实编、窗口出现、完整操作及关闭重开分别验收，不互相替代。后续源码修补的验证范围各自记录。


让想法成为会行动的应用。当前接续开发分支 `dev/cloud-g0-live-20261028`，F1 底座之上正推进有限 F2 工程；F1/F2/R0 整体验收尚未通过。

[动态计划](docs/Plan.md) · [F1 任务](docs/F1/Plan.md) · [实际日志](docs/F1/Log.md) · [V5 产品设计](docs/平台产品设计.md)

[协议任务恢复与完成回执](docs/F2/ProtocolRecoveryQuickstart20261022.md)：区分原任务结算、冷页只读找回完成/核查回执和未知请求；列明两族真实硬刷新证据及PG/provider/G0等未验边界。仅为开发分支的有限工程交付，尚未正式发布。

[本机安装与只读预检](docs/Installation.md)：MOCK 工程体验；真实 Win11 普通用户首次启动仍未测。

[从安装包开始的空白合成工程](docs/F2/BlankSyntheticWorkspaceQuickstart.md)：显式新目录、自己创建 CSV/Goal/应用、原 Worker 运行与保留数据后冷重开；默认仅公开测试身份和固定工具；可显式开启单文本真实模型合同，正式发布关闭。

[保留原 Goal 修改 CSV 列绑定](docs/F2/InitialColumnRevision20261018.md)：在原实例明确修改已有列，经独立检查、版本确认及采纳后重新运行，并保留旧结果。

[首次更换已有授权 CSV](docs/F2/FirstMaterialRevision20261018.md)：原实例可保留 Goal 直接选择另一份 App 已获授权的 CSV，无需先做列修订；经独立检查及版本确认后使用新材料。

[CSV 列绑定局部修改](docs/F2/ColumnBindingPatchQuickstart.md)：同一求和节点 amount → quantity 新草案、精确版本确认、实际只读检查和无关对象保持证明。离线工程候选未验收，旧应用不覆盖，正式发布关闭。

[固定 CSV 三步 DAG](docs/F2/FixedCsvDagQuickstart.md)：在同一应用保存预览 → 求和 → 固定文字报告计划，复用既有 Worker 与持久步骤回执，支持精确确认和冷恢复。离线工程候选未验收。

[有限只读 CSV 节点组合](docs/F2/BoundedCsvCompositionQuickstart.md)：已按限定独审整合 dev，可在原面板编辑一至四个已有动作节点并保留多个末端新输出；原预算与授权范围不变，验收仍 PENDING，不代表非 CSV／PROJECT／AT13 完成。[整合证据与限制](docs/evidence/bounded-readonly-dag-integration-20261008/README.md)。

[历史 Report 展示晚回执恢复](docs/F2/ReportPresentationLateReceiptFix.md)：同应用重开后重新读取当前授权展示历史，保留原 decision 与 explanation 展示；限定修复已集成 dev，PROJECT 仍 PENDING/BLOCKED_PARTIAL，整体验收与发布关闭。[集成回归与保留限制](docs/evidence/report-late-integration-20261009/README.md)。

[有限 all/any 条件组合](docs/F2/BoundedConditionGroupsQuickstart.md)：已按限定独审集成dev，补原F2-T04的二至四项有限逻辑组合，复用既有类型、授权、预算与持久执行证明。[候选证据](docs/evidence/bounded-condition-groups-20261009/README.md)与[集成回归及保留限制](docs/evidence/bounded-condition-groups-integration-20261009/README.md)，未整体验收、发布关闭。

[三端口受限接线草案](docs/F2/CsvWiringPatchQuickstart.md)：服务端允许来源、新计划精确确认、实际前驱与来源证明；默认旧接线兼容，候选未验收、发布关闭。

已成功内部 CSV 任务的有界复用入口：[最短上手说明](docs/F2/RegisteredRunQuickstart.md)。保持本机 MOCK，不代表完整 P-B 或正式发布。

本增量支持：本地身份、三个工作区、项目内文本材料、异步持久任务、独立 API/worker、受控工具与回执、幂等提交、租约/fencing、暂停/取消、授权撤回、有限模型循环和跨进程配额账本。
默认 **MOCK 工程模式**；显式单文本合同已有真实 Intern 的执行、独立验收、保存及重开证据，正式 PG／大型 Cold 真实模型整链尚未验收。普通未声明有限合同的 F1 工具链仍显示 `PARTIAL`，不代表任意目标语义、应用生成或 R0 验收通过。P-A、P-B、发布、增量修改在 F2 实现；不会用空按钮冒充。

前轮记录：[原30秒预算诊断修正与未启用的PB候选切片对照](docs/evidence/pb-candidate-slice-refusal-20261031/README.md)。当轮应用保留2ad32276，未执行大型Cold或新live；其原负例与本轮版本协议语义验收分开记录，原30秒大型保存缺口仍未解决。

## 运行边界

- 目标：Windows 11 x64 原生、Python 3.12 x64、PowerShell 7、PostgreSQL。Windows 精确 OS/依赖组合及脚本实测 **BLOCKED**。
- 已测：云端 Linux、Python 3.12.14、临时 PostgreSQL 17.9；SQLite 仅用于显式合成工程和测试夹具，普通应用启动拒绝 SQLite。
- 云端Windows Server2025工程已测：Python3.12.10 x64、临时PG17.11、六PowerShell接口及111项回归通过；[CI结果与限制](docs/F1/WindowsCI.md)。目标Win11原生验收仍待实测。
- 审计发现的owner环境继承已[本地修复](docs/evidence/F1-env-isolation-20261005/README.md)，Linux PG114项通过；修复后的Windows CI未运行，旧111项不能作为该修复的验证。
- 前端是随 Python 包分发的静态 HTML/CSS/JS，无 Node 构建依赖；默认本机 API 提供资源，不启动每应用服务器。
- API 仅绑定 `127.0.0.1`。关闭网页不会取消任务；停止 worker 或关机会停止处理；未完成模型请求的结果/用量可能未知。
- R0 不执行模型生成的 Python、JS、Shell、SQL，不安装模型指定依赖，不读取任意路径，不支持真实外部写入。

## Windows 原生复现说明（待实测）

安装 Git、Python 3.12 x64、PowerShell 7 与 PostgreSQL。PostgreSQL 17.9 仅为本轮 Linux 测试版本，尚不能据此冻结 Windows 验收版本。不要修改全局 PowerShell 安全策略。

```powershell
git clone --branch dev/f1-foundation https://github.com/T1doo/Sim2Act.git
Set-Location Sim2Act
Copy-Item .env.example .env
# 在本机编辑 .env；保持 MOCK，配置本机数据库应用角色和明确数据目录。
# 不把密钥发到聊天，不提交 .env，不沿用示例密码。
pwsh -NoProfile -File .\scripts\Setup.ps1
```

数据库应预先由本机管理员建立：独立数据库、迁移角色（可建表）、应用角色（仅业务表读写）。应用角色不授予超级用户、建库、建角色、任意 schema 建表或管理员权限。用单独本地配置文件 `migration.env` 指向迁移角色后执行：

```powershell
pwsh -NoProfile -File .\scripts\Setup.ps1 -Config migration.env -InitializeDatabase
# 管理员随后仅向应用角色授予目标 schema 的 USAGE，及业务表的 SELECT/INSERT/UPDATE/DELETE。
pwsh -NoProfile -File .\scripts\Doctor.ps1 -Config .env
# 载入明确指定的应用配置，在本机初始化身份（令牌只显示一次，请私下保存）。
. .\scripts\Common.ps1
Import-Sim2ActConfig '.env'
Invoke-Sim2ActPython -Arguments @('-m', 'sim2act.cli', 'init-user', '--name', '本机使用者')
pwsh -NoProfile -File .\scripts\Start.ps1
pwsh -NoProfile -File .\scripts\Status.ps1
```

浏览器打开 Start 输出的地址，用本机访问令牌连接。创建项目 → 在资源工作区保存并授权 TXT/MD/CSV/JSON 文本 → 回到项目提交目标 → 查看后台状态、成果和可展开的来源回执。资源授权当前为 24 小时；撤回或到期后重新读取和派发拒绝。令牌只保存在页面内存，刷新后重新连接。

```powershell
pwsh -NoProfile -File .\scripts\Test.ps1 -Suite Engineering
pwsh -NoProfile -File .\scripts\Stop.ps1
```

Stop 只停止启动器记录且身份匹配的 API/worker，保留数据库服务、日志和数据；不存在自动清库/卸载操作。PID 文件不含令牌或数据库 URL。端口冲突拒绝启动，不终止其他程序。启动/状态输出分别报告 API、worker、数据库和数据目录。

`Test.ps1 -Suite R0` 明确拒绝：完整首版验收尚未实现，不能把工程 pytest 作为 R0 通过。

## Linux 工程验证

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements.lock
.venv/bin/python -m pip install -e . --no-deps
.venv/bin/python -m ruff check src scripts tests
.venv/bin/python -m mypy src
.venv/bin/python -m pytest -q
# 可选：仅显式指定隔离测试 PostgreSQL URL，pytest 自动建立并清理自己的 test_* schema。
# SIM2ACT_TEST_DATABASE_URL='<隔离测试数据库>' .venv/bin/python -m pytest -q
```

不要让测试 URL 指向用户数据数据库。Linux沿用requirements.lock；Windows Setup使用独立requirements-windows.lock，完整版本集合及首次py-launcher安装已在Server CI验证，详情见[Windows CI](docs/F1/WindowsCI.md)。目标Win11及其他平台仍需独立验收。

用应用环境变量执行 `python scripts/manage.py doctor|start|status|stop`，用迁移角色显式执行 `python -m sim2act.cli migrate`。API/worker 不自动迁移，也不搜索 `.env`、隐藏凭据或系统文件。PowerShell 仅载入用户显式指定的本地配置。

## 书生接入（LIVE BLOCKED）

运行模型限定 `intern-s2`，固定官方非流式 Chat Completions 端点；开发辅助模型不会进入运行链。适配器使用 HTTP 请求，关闭隐藏重试，严格校验工具参数、结构和结束原因；所有请求共用数据库配额主体。账号被其他程序共用时仍可能遭上游限流。

2026-10-28 云端已用既有 `INTERN_API_TOKEN` 完成一次真实 HTTP 200 调用：身份与精确输出校验通过，161 tokens、2.50 秒、无重试。用户已明确确认既有固定服务零费用；服务器来源采用该确认，固定 `intern-s2` 与原端点、付费上限 0、失败停止，无其他供应商或付费回退。这不是 provider 账单 API 证明，也不代表完整生产业务或语义验收。正式执行配置与当前缺项见 [云端候选与失败证据](docs/evidence/cloud-core-20261028/README.md)。

名称优先级：非空 `SIM2ACT_INTERN_TOKEN` 优先；专用变量为空或未设置时读取 `INTERN_API_TOKEN`；两者都为空或未设置则无 token。`.env.example` 中的空专用变量不会遮蔽通用别名。PowerShell 显式配置载入接受这两个名称；Python 仍不自动搜索/读取 `.env`。由用户亲自在私有环境输入，不把值发到聊天、日志或提交；设置 token 本身不会打开 LIVE。

上游约束与参数来自 [书生官方 API 文档](https://internlm.intern-ai.org.cn/doc/docs/Chat/) 和 [模型列表](https://internlm.intern-ai.org.cn/doc/docs/模型列表/)，账号能力仍需实际探针确认。能力报告当前保留 LIVE BLOCKED；未知 usage 保留 null，不记为零、不估算费用。

遇到未核对的在途模型请求，恢复进入 `WAITING_RESOURCE / OUTCOME_UNKNOWN`，不会盲目重发。此增量尚未提供人工核对与重新批准该请求的完整界面，属于下一步工作。

## F1-2 离线检查与人工核对

安装既有锁定依赖后，可运行 `python -m sim2act.cli probe --output offline-report.json`。命令在读取环境配置之前执行，用临时工程库及固定 MockTransport 检查适配器/工具反馈和错误分支，不读取账号、不产生外部请求；模型列表明确 SYNTHETIC，LIVE 仍 BLOCKED。请将报告输出到本地数据目录，避免提交运行数据。

未知模型请求在项目成果画布提供人工核对：记录已有完整响应后保持暂停，需另点“继续”；无法确认时结束任务，保留未知用量和已有效果。依据必须对应原请求指纹；不会靠自动重试抹掉未知请求。详见 [核对规则](docs/F1/Reconciliation.md)、[候选契约校验](docs/F1/Contracts.md) 和 [实测证据](docs/evidence/F1-2-TestReport.md)。

## F1-3 升级与阶段边界

升级既有数据库前先 Stop API/worker；通过已配置的**迁移角色**显式执行 migrate（沿用上文 migration.env / Setup -InitializeDatabase），仅创建新增 run_contracts、operation_intents、local_effects 三表。管理员给运行角色这些表的 SELECT/INSERT/UPDATE/DELETE，再 Doctor/Start；运行角色不做 DDL。没有新凭据发现或自动迁移。

历史任务没有冻结快照时显示 LEGACY_UNFROZEN，不能悄悄按当前内容恢复执行；不要删除旧记录，可明确结束并提交新的授权任务。新任务冻结目标/输入哈希/模式/预算；旧配置或worker无法扩大原上限。

候选清单预检和未知工具核对提供HTTP API，详见 [契约](docs/F1/Contracts.md)、[核对规则](docs/F1/Reconciliation.md)；这不是应用发布或F2运行器。[F1/F2边界及Windows/LIVE验证步骤](docs/F1/Scope.md)明确剩余条件，当前F1未验收。

## F2 本地并行工程：CSV 应用草案预览

F1 仍未签收，F2 正式准入尚未满足；本轮用户明确授权隔离并行开发。先按既有说明由迁移角色执行 migrate（新增 app_drafts/app_previews 表），再向应用角色授予这些表的业务 CRUD 权限；API 不自动建表。

1. 在“资源”保存并授权当前项目的 CSV（最多 32 KiB/1000 条记录）。
2. 打开“应用”，选择 CSV、填写目标说明，点击“创建草案并授权读取”。仅授权该应用读取/汇总这一个材料 24 小时。
3. 选择可用数值列并运行新预览；可更换列得到新的结果/预览 ID，也可回读历史。错误列显示 FAILED，保留历史；不偷偷重试或制造成果。

草案使用 1.0-draft ActionSpec/AppManifest 的固定单节点声明式模板、当前用户与应用 Grant 交集、冻结材料哈希和候选指纹。预览与 F1 任务、发布/实例业务数据分开；最近 50 条历史可回读。撤权/到期或材料变化后需处理授权或重新创建草案，历史接口也会重新授权。界面和 API 使用同一可信读取网关。

这是 MOCK_ENGINEERING 的纯本地受控计算，0 模型请求，0 业务写入；不是自然语言 P-A/P-B 完成、正式发布或 R0-alpha。同步有界只读预览没有后台长任务/暂停取消恢复；这些仍属于后续 F2 完整链路。见 [计划与门槛](docs/F2/Plan.md)。

## 通用目标卡（F2并行草案）

项目页可人工整理任意目标的已知、假设、未决项、硬条件和验收检查，并选择同项目授权材料。保存追加版本，旧窗口版本冲突时重新打开目标卡，未保存文字保留；历史可回看最近50版。目标卡不会启动模型、执行任务或发布应用，不能代替P-A/P-B生成或正式验收。

更新现有安装时，先由迁移角色按既有migrate说明创建goal_cards/goal_card_versions，再为应用角色授予两表业务CRUD；API不自动DDL，不把迁移身份交给API/worker。撤权或材料版本改变会阻止相关旧快照回读/修订。工程边界与证据见docs/F2/Plan.md和docs/evidence/F2-goal-cards-20261005。


## 已保存目标 → MOCK固定能力候选 → CSV预览

1. 在项目目标卡绑定已授权CSV并保存，打开该目标卡。
2. 在“从已保存目标创建候选”选择绑定CSV及可信“CSV数值列求和”，点击“创建候选并授权预览”。使用已保存版本；未保存编辑不会混入。仅给这个preview应用所选CSV的读取/求和授权24小时。
3. 应用页明确显示MOCK、目标来源版本、未验收/未发布。选择数值列运行，查看新结果/历史；“返回来源目标卡”可回到最新卡并从候选列表重新打开。刷新后重新连接，已保存目标、候选及预览历史仍可回读。

取消提交前不创建候选。提交已接受后“返回编辑”只停止页面跳转，候选仍保留；同步事务不是可暂停/取消的后台AppRun。失败保留编辑；相同请求键重试返回同候选且不重复创建身份/Grant。旧目标版本候选不随目标修订改变；所有来源材料在候选详情/预览重新校验权限及hash，旧快照不能恢复撤权。候选列表仅元信息，不作为执行授权。

P-A只支持人工目标分项+用户明确选择固定声明式模板的工程子集，没有自然语言理解、任意应用生成或语义验收；完整P-B仍未验收；成功内部CSV任务→已有授权新CSV→冷运行的有界子集见[上手说明](docs/F2/RegisteredRunQuickstart.md)。该历史子集零真实模型请求；本轮独立云端实测见上文。候选仍PREVIEW_ONLY，不是Release。更新既有安装仍需迁移角色显式migrate创建goal_candidate_requests并给应用角色该表业务CRUD；API/worker不自动DDL，不发现凭据。测试边界见docs/F2/Plan.md。
