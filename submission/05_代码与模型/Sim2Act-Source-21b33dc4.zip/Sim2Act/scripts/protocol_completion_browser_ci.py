"""One Windows protected-browser window; reuse sealed facts, never run a Worker.

The first workflow step supplies the absolute 180s deadline, including dependency
setup. Cleanup has one shared further 10s deadline. Only explicitly named,
bounded synthetic results are emitted to the existing job log (no artifacts).
"""

import base64
import gzip
import hashlib
import json
import os
import shutil
import socket
import subprocess
import sys
import threading
import time
import traceback
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
def evidence_for(phase):
    if phase not in {"source", "extract"}:
        raise ValueError("Unknown explicit completion phase")
    return REPO / f"docs/evidence/protocol-{phase}-process-recovery-20261022"
REAL_TIME = time.time


def write(root, name, value):
    (root / name).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def collect(root):
    outputs = {}
    total = 0
    for name in ("launch-contract.json", "inventory.json", "result.json", "browser.json", "initial.png", "unknown.png", "completed.png", "read-failed.png", "cold.png", "source-failed.png", "source-refreshed.png", "extract-failed.png", "extract-refreshed.png", "store-content-hashes.json", "failure.png", "before-projects-wide.png", "before-projects-narrow.png", "after-projects-wide.png", "after-projects-narrow.png", "after-apps-wide.png", "after-apps-narrow.png", "after-resources-wide.png", "after-resources-narrow.png", "after-source-receipt-wide.png", "after-source-error-narrow.png", "maintenance-expanded-wide.png", "project-create-narrow.png", "app-result-wide.png", "app-result-narrow.png", "app-read-error-narrow.png", "content-result.json", "app-loading-wide.png", "app-empty-narrow.png", "app-read-error-wide.png", "before-tasks-wide.png", "before-tasks-narrow.png", "after-tasks-wide.png", "after-tasks-narrow.png", "task-focus-wide.png", "task-reduced-narrow.png", "before-goals-wide.png", "before-goals-narrow.png", "before-editor-wide.png", "before-editor-narrow.png", "after-goals-wide.png", "after-goals-narrow.png", "after-editor-wide.png", "after-editor-narrow.png", "goal-focus-wide.png", "goal-trial-narrow.png", "goal-history-1366.png", "goal-history-390.png", "goal-unknown-1366.png", "goal-unknown-390.png", "goal-directory-failed-390.png", "goal-directory-recovered-1366.png", "app-directory-failed-390.png", "app-directory-recovered-1366.png", "before-connections-1366.png", "before-connections-390.png", "after-connections-1366.png", "after-connections-390.png", "catalog-contract.json"):
        file = root / name
        if not file.exists():
            continue
        data = file.read_bytes()
        total += len(data)
        assert len(data) <= 500_000 and total <= 2_000_000, "Evidence log bound exceeded"
        outputs[name] = data
    return outputs


def emit(outputs, phase="extract", review=False, readback=False, completion_readback=False, workspace_visual=False):
    prefix = "SIM2ACT_WORKSPACE_VISUAL_UI" if workspace_visual else "SIM2ACT_COMPLETION_READBACK_UI" if completion_readback else "SIM2ACT_REVIEW_READBACK_UI" if readback else "SIM2ACT_SOURCE_REVIEW_UI" if review else "SIM2ACT_SOURCE_UI" if phase == "source" else "SIM2ACT_EXTRACT_UI"
    for name, data in outputs.items():
        encoded = base64.b64encode(data).decode()
        print(prefix + "_FILE " + json.dumps(dict(name=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest(), chunks=(len(encoded) + 3999) // 4000)))
        for i, start in enumerate(range(0, len(encoded), 4000)):
            print(f"{prefix}_CHUNK {name} {i} {encoded[start:start + 4000]}")
    sys.stdout.flush()


def launch_paths(root, deadline, phase="extract", review=False, readback=False, completion_readback=False, workspace_visual=False):
    if review and phase != "source":
        raise ValueError("Only sealed Source supports registered review UI")
    evidence = evidence_for(phase)
    """Resolve the entire existing launch toolchain before any installation.

    Scalar executable paths are passed as argv elements, never a shell string.
    Missing/unknown layouts fail together; no alternate SDK or PATH retry.
    """
    errors, paths = [], {}

    def file(label, value):
        if time.monotonic() >= deadline:
            raise TimeoutError("Original work deadline during launch preflight")
        try:
            if value is None or not str(value).strip() or any(c in str(value) for c in "\r\n"):
                raise ValueError("missing or ambiguous path")
            path = Path(value)
            if not path.is_absolute() or not path.is_file():
                raise ValueError("absolute existing file required")
            paths[label] = str(path.resolve(strict=True))
        except (OSError, ValueError) as error:
            errors.append(dict(path=label, error=type(error).__name__, message=str(error)))

    file("python", sys.executable)
    for label, name in (("pwsh", "pwsh.exe"), ("node", "node.exe"), ("npm_cmd", "npm.cmd"), ("git", "git.exe")):
        if time.monotonic() >= deadline:
            raise TimeoutError("Original work deadline during tool resolution")
        file(label, shutil.which(name))
    if "npm_cmd" in paths:
        file("npm_cli", Path(paths["npm_cmd"]).parent / "node_modules/npm/bin/npm-cli.js")
    try:
        expected = Path(os.environ["pythonLocation"]) / "python.exe"
        if "python" not in paths or not os.path.samefile(paths["python"], expected):
            raise ValueError("interpreter differs from selected setup-python file")
    except (OSError, KeyError, ValueError) as error:
        errors.append(dict(path="selected_python", error=type(error).__name__, message=str(error)))
    required = [
        ".gitattributes", ".github/workflows/windows-native-mock.yml", "pyproject.toml", "requirements-windows.lock",
        "scripts/OwnedBrowserSetup.ps1", "scripts/WindowsExtractCompletionUI.ps1",
        "scripts/protocol_completion_browser_ci.py", "scripts/windows_browser_ci.py",
        "scripts/browser-ci/package.json", "scripts/browser-ci/package-lock.json", "scripts/browser-ci/extract-completion.cjs",
        "src/sim2act/__init__.py", "src/sim2act/api.py", "src/sim2act/protocol_jobs.py", "src/sim2act/protocol_reviews.py", "src/sim2act/web/index.html", "src/sim2act/web/app.js", "src/sim2act/web/app.css", "src/sim2act/web/protocol.js",
    ]
    if completion_readback:
        from protocol_completion_readback_fixture import required_files
        required += required_files()
    elif readback:
        from protocol_review_readback_fixture import required_files
        required += required_files()
    else:
        required += [str((evidence / name).relative_to(REPO)) for name in ("original.json", "after.sqlite.gz" if review else "before.sqlite.gz", "original-received-sidecar.json")]
    if workspace_visual:
        required += ["scripts/browser-ci/workspace-visual.cjs", "scripts/browser-ci/goal-history-state.cjs", "docs/evidence/goal-history-visual-candidate-20261025/fixture.json", "src/sim2act/web/natural-goal.js", "scripts/readonly_content_fixture.py", "src/sim2act/web/use.js", "src/sim2act/web/csv-owner.js", "src/sim2act/web/csv-goal-revision.js", "docs/evidence/research-desk-content-20261023/saved-csv.json", "docs/evidence/research-desk-content-20261023/saved-csv.sqlite.gz"]
    if sys.argv[1:] == ["--catalog-visual"]:
        required += ["scripts/catalog_visual_contract.py", "scripts/browser-ci/catalog-visual.cjs",
                     *["docs/evidence/catalog-four-frame-plan-20261026/before-assets/" + n for n in ("index.html", "app.css", "app.js")],
                     "docs/evidence/catalog-four-frame-wiring-20261026/execution.json",
                     "docs/evidence/catalog-four-frame-wiring-20261026/runtime-manifest.json"]
    required += [f"docs/evidence/protocol-store-loop-20261006/evaluation/{name}.json" for name in ("a-source", "a-cold", "b-source", "b-cold")]
    for name in required:
        file(name, REPO / name)
    write(root, "launch-contract.json", dict(status="FAIL" if errors else "QUALIFIED_FILES_ONLY", paths=paths, errors=errors, cwd=str(REPO), root=str(root), scope="file/layout checks, not Windows handle/sandbox qualification"))
    if errors:
        raise RuntimeError("Launch contract incomplete: " + json.dumps(errors))
    return paths


def join_api_threads(thread, deadline, attempt):
    """Normal loop/thread shutdown within the coordinator's shared remainder."""
    if thread:
        attempt("api_join", lambda: thread.join(max(0, deadline - time.monotonic())))
    for worker in threading.enumerate():
        if worker.name == "AnyIO worker thread":
            attempt("anyio_join", lambda worker=worker: worker.join(max(0, deadline - time.monotonic())))
    return [worker.name for worker in threading.enumerate() if worker.name == "AnyIO worker thread" and worker.is_alive()]


def close_content_child(child, cleanup_until, attempt):
    """Exact Popen ownership only; reserve time for the parent's API cleanup."""
    forced = False
    try:
        child.wait(timeout=max(.01, min(1.5, cleanup_until-time.monotonic()-2)))
    except BaseException as error:
        forced = True
        if not isinstance(error, subprocess.TimeoutExpired):
            attempt("content_join_error", lambda: (_ for _ in ()).throw(error))
        terminated = attempt("content_terminate", lambda: (child.terminate(), True)[1])
        if terminated:
            attempt("content_terminate_wait", lambda: child.wait(timeout=max(.01, min(.5, cleanup_until-time.monotonic()-1))))
            if child.poll() is None:
                attempt("content_kill", child.kill)
                attempt("content_reap", lambda: child.wait(timeout=max(.01, min(.5, cleanup_until-time.monotonic()))))
    return dict(forced=forced, exit=child.poll())


def main():
    assert sys.argv[1:] in ([], ["--source"], ["--source-review"], ["--review-readback"], ["--completion-readback"], ["--workspace-visual"], ["--catalog-visual"]), "Unknown phase arguments; no fallback"
    phase = "source" if sys.argv[1:] else "extract"
    review = sys.argv[1:] == ["--source-review"]
    catalog_visual = sys.argv[1:] == ["--catalog-visual"]
    workspace_visual = catalog_visual or sys.argv[1:] == ["--workspace-visual"]
    completion_readback = workspace_visual or sys.argv[1:] == ["--completion-readback"]
    readback = completion_readback or sys.argv[1:] == ["--review-readback"]
    action = "catalog-visual" if catalog_visual else "workspace-visual" if workspace_visual else "completion-readback" if completion_readback else "review-readback" if readback else "review" if review else "completion"
    get_limit = 100 if completion_readback else 60 if readback else 30
    static_limit = 120 if completion_readback else 60 if readback else 40
    evidence = evidence_for(phase)
    assert os.name == "nt" and os.environ.get("GITHUB_ACTIONS") == "true"
    assert os.environ.get("GITHUB_RUN_ATTEMPT") == "1", "No rerun"
    assert os.environ.get("GITHUB_REF") == "refs/heads/dev/production-trial-stages-20261018"
    absolute = int(os.environ["SIM2ACT_UI_UNTIL"]) / 1000
    until = time.monotonic() + (absolute - REAL_TIME())
    root = Path(os.environ["RUNNER_TEMP"]) / (f"sim2act-{action if readback else phase + ('-review' if review else '')}-ui-" + os.environ["GITHUB_RUN_ID"] + "-1")
    root.mkdir()  # New window only; never reuse a consumed directory.
    result = dict(status="UNKNOWN", phase=phase, action=action, scope="SYNTHETIC SQLite / real Windows Edge DOM; not G0 or production source", limits=dict(work_seconds=180, cleanup_seconds=10, business_get=get_limit, static_get=static_limit, screenshots=4, **{"business_post" if readback else "review_post" if review else "completion_post": 0 if readback else 3}), model_calls=0, new_worker=0, new_source=0, new_extract=0)
    if readback:
        result["phases"] = ["source", "extract"] if completion_readback else ["source", "cold"]
    node = server = thread = store = counts = None
    extra_store = extra_settings = None
    extra_server = extra_thread = extra_listener = None
    originals = None
    sql_verbs = {}
    sql_lock = threading.Lock()
    monitor_stop = threading.Event()
    watcher = None
    forbidden_calls = []
    owned = {}
    owned_lock = threading.Lock()
    setup = []
    cleanup_until = None
    exit_code = 1
    private_files = []
    content_child = content_log = None

    def remaining():
        value = until - time.monotonic()
        if value <= 0:
            raise TimeoutError("Single absolute 180s work deadline")
        return value

    def command(args, log):
        config = root / (log + ".json")
        executable = args[0]
        assert Path(executable).is_absolute() and Path(executable).is_file()
        write(root, config.name, dict(executable=executable, arguments=args[1:], cwd=str(REPO), until_ms=absolute * 1000, receipt=str(root / (log + ".receipt.json"))))
        with (root / log).open("wb") as output:
            # The original deadline belongs to the supervisor too. The extra
            # two seconds allow its exact-handle tree termination, not work.
            wait = remaining()
            supervisor = subprocess.Popen([paths["pwsh"], "-NoProfile", "-NonInteractive", "-File", paths["scripts/OwnedBrowserSetup.ps1"], "-Config", str(config)], cwd=REPO, env=child_env, stdout=output, stderr=subprocess.STDOUT)
            setup.append(supervisor)
            supervisor.wait(timeout=wait + 2)
            assert supervisor.returncode == 0, "Owned setup failed; no retry"

    try:
        remaining()
        paths = launch_paths(root, until, phase, review, readback, completion_readback, workspace_visual)
        remaining()
        child_env = dict(os.environ)
        if catalog_visual:
            from catalog_visual_contract import prepare_tools, verify_contract
            catalog_contract = verify_contract(REPO)
            npm_root, local_temp = prepare_tools(REPO, root)
            child_env.update(TEMP=str(local_temp), TMP=str(local_temp), NODE_PATH=str(npm_root / "node_modules"))
            write(root, "catalog-contract.json", catalog_contract)
        else:
            npm_root = REPO / "scripts/browser-ci"
        # Existing project lock/SDK/license, official registries, no lifecycle
        # scripts, new SDK, browser installation, Actions cache or artifact.
        site = root / "site"
        command([paths["python"], "-m", "pip", "--isolated", "install", "--target", str(site), "--only-binary=:all:", "--no-input", "--no-cache-dir", "--disable-pip-version-check", "--keyring-provider", "disabled", "--retries", "0", "--timeout", "20", "--index-url", "https://pypi.org/simple", "-r", paths["requirements-windows.lock"]], "pip.log")
        sys.path[:0] = [str(site), str(REPO / "src"), str(REPO / "scripts")]
        command([paths["node"], paths["npm_cli"], "ci", "--prefix", str(npm_root), "--ignore-scripts", "--no-audit", "--no-fund", "--registry=https://registry.npmjs.org", "--cache", str(root / "npm-cache"), "--fetch-retries=0", "--fetch-timeout=30000"], "npm.log")
        import psutil
        import uvicorn
        from sqlalchemy import select, event
        from starlette.responses import JSONResponse

        from sim2act.api import create_app
        from sim2act.config import Settings
        from sim2act.db import Store, fingerprint, meta, protocol_jobs, runs
        from sim2act.model import InternModel
        from sim2act.model_budget import BudgetedProvider
        from sim2act.worker import Worker

        db = root / "fixture.sqlite"
        private_files.extend([db, root / "fixture.sqlite-wal", root / "fixture.sqlite-shm", root / "info.json", root / "owned-browser-pids.json"])
        if completion_readback:
            from protocol_completion_readback_fixture import prepare, cases
            originals, sealed_sidecars = prepare(root)
            original = originals[0]
        elif readback:
            from protocol_review_readback_fixture import prepare, cases
            original, sealed_sidecars = prepare(root)
        else:
            original = json.loads((evidence / "original.json").read_text(encoding="utf-8"))
            with gzip.open(evidence / ("after.sqlite.gz" if review else "before.sqlite.gz"), "rb") as src, db.open("wb") as dst:
                shutil.copyfileobj(src, dst)
            sidecar = root / (original["run"] + ".json")
            shutil.copyfile(evidence / "original-received-sidecar.json", sidecar)
            sidecar.with_suffix(".lock").write_bytes(b"")
            sealed_sidecars = [sidecar]
        for path in sealed_sidecars:
            private_files.extend([path, path.with_suffix(".lock")])
        side_bytes = {path.name: path.read_bytes() for path in sealed_sidecars}
        store = Store("sqlite:///" + str(db), test_only=True)  # No initialize/migrate.
        settings = Settings(**dict(original["settings"], database_url=str(store.engine.url), data_dir=root))
        assert settings.mode == "mock" and not settings.live_enabled and not settings.token
        if completion_readback:
            extra_db = root / "extract.sqlite"
            private_files.extend([extra_db, root / "extract.sqlite-wal", root / "extract.sqlite-shm"])
            extra_store = Store("sqlite:///" + str(extra_db), test_only=True)
            extra_settings = Settings(**dict(originals[1]["settings"], database_url=str(extra_store.engine.url), data_dir=root))
            assert extra_settings.mode == "mock" and not extra_settings.live_enabled and not extra_settings.token

            def only_read(_c, _cursor, sql, _params, _context, _many):
                verb = sql.lstrip().split(None, 1)[0].upper()
                with sql_lock:
                    sql_verbs[verb] = sql_verbs.get(verb, 0) + 1
                assert verb in {"SELECT", "BEGIN"}, "Read-only window forbids DML/DDL"

            for item in (store, extra_store):
                event.listen(item.engine, "before_cursor_execute", only_read)

        def snapshot():
            def one(item):
                with item.engine.connect() as c:
                    return {t.name: sorted(fingerprint(dict(r)) for r in c.execute(select(t)).mappings()) for t in meta.sorted_tables}
            return {"source": one(store), "extract": one(extra_store)} if completion_readback else one(store)

        before = snapshot()
        with store.engine.connect() as c:
            all_jobs = list(c.execute(select(protocol_jobs)).mappings())
            before_run = dict(c.execute(select(runs).where(runs.c.id == original["run"])).mappings().one())
        if completion_readback:
            assert original["run"] in {r["run_id"] for r in all_jobs}
            others = []
        elif readback:
            assert {original["run"], original["cold"]}.issubset({r["run_id"] for r in all_jobs})
            others = []
        elif phase == "source":
            assert len(all_jobs) == 1 and all_jobs[0]["run_id"] == original["run"]
            assert all_jobs[0]["accepted_snapshot"]["phase"] == "source"
            others = []  # Source does not manufacture another Run for navigation.
        else:
            others = [r["run_id"] for r in all_jobs if r["accepted_snapshot"]["phase"] == "extract" and r["run_id"] != original["run"]]
            assert len(others) == 1

        def forbidden(*args, **kwargs):
            forbidden_calls.append("send/reserve/accept")
            raise AssertionError("Forbidden new model/Worker action")

        for owner, name in ((InternModel, "request"), (InternModel, "request_serialized"), (BudgetedProvider, "call"), (BudgetedProvider, "preflight"), (BudgetedProvider, "accept_candidate"), (Worker, "reserve"), (Worker, "__init__"), (Store, "claim")):
            setattr(owner, name, forbidden)
        if completion_readback:
            Store.event = forbidden
        # Explicit test business clock only. All operation/cleanup limits use
        # saved real wall clock or monotonic; product clock code is unchanged.
        business_at = max(o["resume_at"] for o in originals) if completion_readback else original["resume_at"]
        time.time = lambda: business_at
        app = create_app(store, settings)
        post_kind = "business_post" if readback else "review_post" if review else "completion_post"
        counts = dict(business_get=0, static_get=0, blocked=0, **{post_kind: 0})
        counter_lock = threading.Lock()
        completion_path = f'/api/internal/protocol/runs/{original["run"]}/reviews' if review else f'/api/projects/{original["project"]}/protocol/runs/{original["run"]}/complete-{phase if phase == "source" else "extraction"}'

        @app.middleware("http")
        async def bounded_http(request, call_next):
            route = request.url.path
            with counter_lock:
                if request.method == "GET":
                    kind = "business_get" if route.startswith("/api/") or route == "/health" else "static_get"
                    counts[kind] += 1
                    allowed = counts[kind] <= (get_limit if kind == "business_get" else static_limit)
                elif request.method == "POST" and (readback or route == completion_path):
                    counts[post_kind] += 1
                    allowed = not readback and counts[post_kind] <= 3
                else:
                    allowed = False
                if time.monotonic() >= until or not allowed:
                    counts["blocked"] += 1
                    return JSONResponse({"error": {"code": "TEST_WINDOW_STOP"}}, status_code=409)
            return await call_next(request)

        listener = socket.socket()
        listener.bind(("127.0.0.1", 0))
        listener.listen(128)
        port = listener.getsockname()[1]
        server = uvicorn.Server(uvicorn.Config(app, log_level="error", access_log=False))
        thread = threading.Thread(target=server.run, kwargs={"sockets": [listener]}, daemon=True)
        thread.start()
        ready = time.monotonic() + min(10, remaining())
        while not server.started:
            assert thread.is_alive() and time.monotonic() < ready, "API did not start"
            time.sleep(0.01)
        if completion_readback:
            extra_app = create_app(extra_store, extra_settings)
            extra_app.middleware("http")(bounded_http)
            extra_listener = socket.socket()
            extra_listener.bind(("127.0.0.1", 0))
            extra_listener.listen(128)
            extra_port = extra_listener.getsockname()[1]
            extra_server = uvicorn.Server(uvicorn.Config(extra_app, log_level="error", access_log=False))
            extra_thread = threading.Thread(target=extra_server.run, kwargs={"sockets": [extra_listener]}, daemon=True)
            extra_thread.start()
            ready = time.monotonic() + min(10, remaining())
            while not extra_server.started:
                assert extra_thread.is_alive() and time.monotonic() < ready, "Extract API did not start"
                time.sleep(0.01)
        commit = subprocess.check_output([paths["git"], "rev-parse", "HEAD"], cwd=REPO, timeout=remaining(), text=True).strip()
        hashes = {name: hashlib.sha256((REPO / name).read_bytes()).hexdigest() for name in ("src/sim2act/web/app.js", "src/sim2act/web/app.css", "src/sim2act/web/protocol.js", "src/sim2act/web/index.html", "scripts/protocol_completion_browser_ci.py", "scripts/browser-ci/extract-completion.cjs", "scripts/browser-ci/package-lock.json", "scripts/OwnedBrowserSetup.ps1", "scripts/windows_browser_ci.py", "scripts/WindowsExtractCompletionUI.ps1", ".github/workflows/windows-native-mock.yml", "src/sim2act/protocol_jobs.py", "src/sim2act/protocol_reviews.py", *(["scripts/protocol_completion_readback_fixture.py", "src/sim2act/protocol_completion_readback.py", "src/sim2act/protocol_recovery.py", "src/sim2act/protocol_source_completion.py", "src/sim2act/protocol_extract_completion.py"] if completion_readback else ["scripts/protocol_review_readback_fixture.py"] if readback else []))}
        if workspace_visual:
            for name in ("scripts/browser-ci/workspace-visual.cjs", "scripts/browser-ci/goal-history-state.cjs", "docs/evidence/goal-history-visual-candidate-20261025/fixture.json", "src/sim2act/web/natural-goal.js", "scripts/readonly_content_fixture.py", "src/sim2act/web/use.js", "src/sim2act/web/csv-owner.js", "src/sim2act/web/csv-goal-revision.js", "docs/evidence/research-desk-content-20261023/saved-csv.json", "docs/evidence/research-desk-content-20261023/saved-csv.sqlite.gz"):
                hashes[name] = hashlib.sha256((REPO / name).read_bytes()).hexdigest()
        lf_hashes = {name: hashlib.sha256((REPO / name).read_bytes().replace(b"\r\n", b"\n")).hexdigest() for name in hashes}
        write(root, "inventory.json", dict(commit=commit, source_sha256=hashes, source_lf_sha256=lf_hashes, synthetic_clock=business_at, browser_install=False, added_sdk=False))
        info = dict(phase=phase, action=action, base=f"http://127.0.0.1:{port}", project=original["project"], run=original["run"], captured=original["captured"], until_ms=absolute * 1000,
                    expected_version=before_run["version"], expected_fence=before_run["fence"])
        if workspace_visual:
            info["visual_source"] = dict(commit=commit, asset_lf_sha256={name: lf_hashes[name] for name in ("src/sim2act/web/app.js", "src/sim2act/web/app.css", "src/sim2act/web/protocol.js", "src/sim2act/web/index.html", "src/sim2act/web/use.js", "src/sim2act/web/csv-owner.js", "src/sim2act/web/csv-goal-revision.js", "src/sim2act/web/natural-goal.js")})
        if catalog_visual:
            info["catalog_comparison"] = catalog_contract
        if completion_readback:
            original_cases = cases([store, extra_store], [settings, extra_settings], originals)
            info["cases"] = [dict(item, base=base) for item, base in zip(original_cases, [info["base"], f"http://127.0.0.1:{extra_port}"], strict=True)]
            info["limits"] = result["limits"]
        elif readback:
            info["cases"] = cases(store, original)
            info["limits"] = result["limits"]
        elif review:
            info["contract_id"] = all_jobs[0]["accepted_snapshot"]["contract"]["contract_id"]
            info["expected_result_fingerprint"] = all_jobs[0]["result_fingerprint"]
            assert before_run["status"] == "WAITING_APPROVAL" and before_run["result"] is not None
        if phase == "extract":
            info["other"] = others[0]
        # Task hierarchy uses only the already sealed Source case; no CSV API child.
        write(root, "info.json", info)
        env = dict(child_env, PYTHONPATH=os.pathsep.join([str(site), str(REPO / "src")]))
        output = (root / "driver.log").open("wb")
        node = subprocess.Popen([paths["node"], paths["scripts/browser-ci/extract-completion.cjs"], str(root), paths["python"]], cwd=REPO, env=env, stdout=output, stderr=subprocess.STDOUT)
        node_process = psutil.Process(node.pid)
        node_process.create_time()  # Bind this process identity once, not by later PID lookup.

        def monitor():
            while not monitor_stop.wait(0.1):
                if node.poll() is not None:
                    break
                try:
                    for child in node_process.children(recursive=True):
                        try:
                            created = child.create_time()
                        except psutil.NoSuchProcess:
                            continue  # A short-lived child cannot stop the root watcher.
                        with owned_lock:
                            owned[(child.pid, created)] = child
                except psutil.NoSuchProcess:
                    if node.poll() is None:
                        result["monitor_error"] = "NODE_IDENTITY_DISAPPEARED_WHILE_HANDLE_LIVE"
                        (root / "stop").touch()
                    break
                except BaseException as error:
                    result["monitor_error"] = type(error).__name__
                    (root / "stop").touch()
                    break
                if time.monotonic() >= until:
                    (root / "stop").touch()
                    server.should_exit = True
                    if extra_server:
                        extra_server.should_exit = True

        watcher = threading.Thread(target=monitor, daemon=True)
        watcher.start()
        try:
            node.wait(timeout=remaining())
        finally:
            output.close()
        assert node.returncode == 0, "Native DOM driver failed; no rerun"
        browser = json.loads((root / "browser.json").read_text(encoding="utf-8"))
        assert browser["status"] == "PASS" and browser["screenshots"] <= 4
        if catalog_visual:
            assert verify_contract(REPO) == catalog_contract
            result["source_after_matches"] = True
        assert counts["blocked"] == 0 and not forbidden_calls and "monitor_error" not in result
        after = snapshot()
        if completion_readback:
            assert after == before and counts["business_post"] == browser["counts"]["business_post"] == 0
            assert fingerprint(cases([store, extra_store], [settings, extra_settings], originals)) == fingerprint(original_cases)
            if workspace_visual:
                assert not browser["located"]  # This content window makes no locator request.
                expected_names = (["before-connections-1366.png", "before-connections-390.png", "after-connections-1366.png", "after-connections-390.png"] if catalog_visual else
                                  ["goal-directory-failed-390.png", "goal-directory-recovered-1366.png", "app-directory-failed-390.png", "app-directory-recovered-1366.png"])
                assert [x["name"] for x in browser["screenshotFiles"]] == expected_names
                assert browser["screenshots"] == 4
                if catalog_visual:
                    assert browser["catalogComparison"]["before"] == catalog_contract["before_product"]
                    assert browser["catalogComparison"]["after"] == catalog_contract["after_product"]
                    assert len(browser["catalogComparison"]["frames"]) == 4
                else:
                    assert browser["directoryRecovery"]["status"] == "PROVED"
            else:
                assert fingerprint(browser["located"]) == fingerprint([original_cases[0]["locator"]]*2 + [original_cases[1]["locator"]]*2)
                assert all(x["hard_refresh"] and x["cold_page"] for x in browser["phase_results"])
            write(root, "store-content-hashes.json", dict(before=before, after=after, sql_verbs=sql_verbs))
            result["sql_verbs"] = dict(sql_verbs)
            with store.engine.connect() as c:
                run = dict(c.execute(select(runs).where(runs.c.id == original["run"])).mappings().one())
        elif readback:
            assert after == before
            assert counts["business_post"] == 0 and browser["counts"]["business_post"] == 0
            assert len(browser["located"]) == 4
            expected_cases = cases(store, original)
            assert fingerprint(expected_cases) == fingerprint(info["cases"])
            assert fingerprint(browser["located"]) == fingerprint([info["cases"][0]["locator"]]*3 + [info["cases"][1]["locator"]])
            with store.engine.connect() as c:
                run = dict(c.execute(select(runs).where(runs.c.id == original["run"])).mappings().one())
        else:
            assert {name for name in before if before[name] != after[name]} == ({"runs", "events", "protocol_reviews"} if review else {"runs", "protocol_jobs", "events"})
            assert set(before["events"]).issubset(after["events"]) and len(after["events"]) == len(before["events"]) + (1 if review else 4)
            with store.engine.connect() as c:
                run = dict(c.execute(select(runs).where(runs.c.id == original["run"])).mappings().one())
                job = dict(c.execute(select(protocol_jobs).where(protocol_jobs.c.run_id == original["run"])).mappings().one())
            assert fingerprint(job["result_snapshot"]["protocol_result"]) == fingerprint(original["captured"]["result"])
            if review:
                from sim2act.db import protocol_reviews
                with store.engine.connect() as c:
                    row = dict(c.execute(select(protocol_reviews).where(protocol_reviews.c.run_id == original["run"])).mappings().one())
                assert run["status"] == "SUCCEEDED" and run["version"] == before_run["version"] + 1
                assert {key for key in run if run[key] != before_run[key]} == {"status", "version"}
                assert row["payload"]["decision"] == "PASS" and row["payload"]["verification"]["semantic_status"] == "PASS"
                assert len(browser["commandBodies"]) == 2 and browser["commandBodies"][0] == browser["commandBodies"][1]
                assert fingerprint(row["payload"]["request"]) == fingerprint(browser["commandBodies"][0])
                assert browser["receipts"][0] == browser["receipts"][1]
                assert browser["receipts"][0]["fingerprint"] == row["fingerprint"]
                from sim2act.protocol_reviews import _public as public_review
                assert fingerprint(browser["receipts"][0]) == fingerprint(public_review(row))
            elif phase == "source":
                assert run["status"] == "WAITING_APPROVAL"
                assert job["result_snapshot"]["protocol_result"]["semantic_status"] == "UNKNOWN"
                assert "compiled_plan" not in job["result_snapshot"]
                assert len(browser["commandBodies"]) == 2
                assert fingerprint(browser["commandBodies"][0]) == fingerprint(browser["commandBodies"][1])
                from sim2act.db import events
                from sim2act.protocol_source_completion import COMPLETED
                with store.engine.connect() as c:
                    receipt_event = c.execute(select(events.c.data).where(events.c.run_id == original["run"], events.c.kind == COMPLETED)).scalar_one()
                # The real page chooses its key. Never replace crypto/controller or
                # copy the process probe's separately chosen completion key.
                assert fingerprint(receipt_event["request"]) == fingerprint(browser["commandBodies"][0])
                assert fingerprint(receipt_event["response"]) == fingerprint(browser["receipts"][0])
                assert browser["receipts"][0]["result_fingerprint"] == job["result_fingerprint"]
            else:
                assert fingerprint(job["result_snapshot"]["compiled_plan"]) == fingerprint(original["captured"]["compiled"])
        assert run["created_at"] == before_run["created_at"] and run["context"] == before_run["context"]
        assert all(path.read_bytes() == side_bytes[path.name] for path in sealed_sidecars)
        result.update(status="PASS", accounting_tables_unchanged=True, exact_original_result=True, exact_receipts=browser["receipts"], original_deadlines_unchanged=True, server_counts=counts, business_clock="explicit synthetic / not G0", forbidden_calls=forbidden_calls)
        remaining()
        exit_code = 0
    except BaseException:
        result.update(status="FAIL", error=traceback.format_exc(limit=8))
        # Retain bounded original failure diagnostics in log; never config/env.
        for name in ("pip.log", "npm.log", "driver.log"):
            file = root / name
            if file.exists():
                print(name + " (last 6000 bytes):\n" + file.read_bytes()[-6000:].decode("utf-8", "replace"))
    finally:
        cleanup_until = min(time.monotonic() + 10, until + 10)
        cleanup_errors = []

        def attempt(label, fn):
            try:
                return fn()
            except BaseException as error:
                cleanup_errors.append(dict(step=label, error=type(error).__name__, message=str(error)))
                result["status"] = "UNKNOWN"
                return None

        shared = root / "cleanup-until.json"
        if shared.exists():
            prior = attempt("shared_cleanup_deadline", lambda: json.loads(shared.read_text()))
            if prior is not None:
                cleanup_until = min(cleanup_until, time.monotonic() + max(0, prior - REAL_TIME()))
        result["coordinator_cleanup_seconds_at_entry"] = max(0, cleanup_until - time.monotonic())
        attempt("request_stop", lambda: (root / "stop").touch())
        if content_child:
            attempt("content_stop", lambda: (root / "content-stop").touch())
            result["content_child_cleanup"] = attempt("content_child_cleanup", lambda: close_content_child(content_child, cleanup_until, attempt))
            if not result["content_child_cleanup"] or result["content_child_cleanup"]["forced"] or content_child.poll() != 0:
                result["status"] = "UNKNOWN"
            if (root / "content-result.json").exists():
                content_result = attempt("content_result", lambda: json.loads((root / "content-result.json").read_text()))
                if not content_result or content_result["status"] != "PASS":
                    result["status"] = "UNKNOWN"
            else:
                result["status"] = "UNKNOWN"
        if content_log:
            attempt("content_log_close", content_log.close)
        if server:
            server.should_exit = True
        if extra_server:
            extra_server.should_exit = True
        # The outer exact-handle supervisor has the same deadline and covers a
        # catastrophic Python failure. Normal cleanup confirms each owned item.
        if node and node.poll() is None:
            try:
                node.wait(timeout=max(0.01, cleanup_until - time.monotonic() - 3))
            except subprocess.TimeoutExpired:
                result["status"] = "UNKNOWN"
            except BaseException as error:
                cleanup_errors.append(dict(step="node_grace", error=type(error).__name__))
                result["status"] = "UNKNOWN"
        monitor_stop.set()
        if watcher:
            attempt("monitor_join", lambda: watcher.join(max(0, cleanup_until - time.monotonic())))
            if watcher.is_alive():
                cleanup_errors.append(dict(step="monitor_join", error="STILL_RUNNING"))
                result["status"] = "UNKNOWN"
        with owned_lock:
            registered = list(owned.items())
        # Forced cleanup is not success. psutil.Process retains create_time and
        # refuses PID reuse. A denied terminate is not retried another way.
        for (pid, _created), process in registered:
            alive = attempt(f"owned_{pid}_status", process.is_running)
            if alive:
                result["status"] = "UNKNOWN"
                attempt(f"owned_{pid}_terminate", process.terminate)
        if node and node.poll() is None:
            attempt("node_terminate", node.terminate)
            attempt("node_wait", lambda: node.wait(timeout=max(0.01, cleanup_until - time.monotonic())))
        for installer in setup:
            if installer.poll() is None:
                attempt("installer_supervisor_wait", lambda installer=installer: installer.wait(timeout=max(0.01, cleanup_until - time.monotonic())))
        if extra_thread:
            attempt("extract_api_join", lambda: extra_thread.join(max(0, cleanup_until - time.monotonic())))
        anyio_alive = join_api_threads(thread, cleanup_until, attempt)
        if extra_listener and (not extra_thread or not extra_thread.is_alive()):
            attempt("extract_listener_close", extra_listener.close)
        time.time = REAL_TIME
        alive = [pid for (pid, _), process in registered if attempt(f"owned_{pid}_final", process.is_running)]
        installers_alive = [p.pid for p in setup if p.poll() is None]
        receipts = []
        for name in ("pip.log.receipt.json", "npm.log.receipt.json"):
            if (root / name).exists():
                receipt = attempt(name, lambda name=name: json.loads((root / name).read_text(encoding="utf-8-sig")))
                receipts.append(receipt)
                if receipt and (receipt["timed_out"] or receipt["forced_tree_stop"]):
                    result["status"] = "UNKNOWN"
        result["cleanup"] = dict(api_stopped=(not thread or not thread.is_alive()) and (not extra_thread or not extra_thread.is_alive()), anyio_alive=anyio_alive, node_exit=None if node is None else node.poll(), owned_browser_descendants_alive=alive, installer_supervisors_alive=installers_alive, errors=cleanup_errors)
        result["setup_receipts"] = receipts
        if counts is not None:
            with counter_lock:
                result["server_counts"] = dict(counts)
        result["forbidden_attempts"] = forbidden_calls
        if alive or anyio_alive or installers_alive or thread and thread.is_alive() or extra_thread and extra_thread.is_alive() or time.monotonic() > cleanup_until:
            result["status"] = "UNKNOWN"
        if store and (not thread or not thread.is_alive()) and (not extra_thread or not extra_thread.is_alive()):
            attempt("store_dispose", store.engine.dispose)
            if extra_store:
                attempt("extract_store_dispose", extra_store.engine.dispose)
        if completion_readback:
            result["sql_verbs"] = dict(sql_verbs)
            if result.get("accounting_tables_unchanged"):
                attempt("write_final_store_hashes", lambda: write(root, "store-content-hashes.json", dict(before=before, after=after, sql_verbs=dict(sql_verbs))))
        attempt("write_result", lambda: write(root, "result.json", result))
        outputs = attempt("collect_evidence", lambda: collect(root)) or {}
        # No deletion while process/thread termination is unconfirmed. Bounded
        # failure evidence remains in the ephemeral job directory and job log.
        if result["status"] == "PASS":
            for file in private_files:
                attempt("delete_owned_" + file.name, lambda file=file: file.unlink(missing_ok=True))
            result["cleanup"]["fixture_deleted"] = all(not file.exists() for file in private_files)
        else:
            result["cleanup"]["fixture_deleted"] = False
        result["cleanup"]["within_deadline"] = time.monotonic() <= cleanup_until
        if not result["cleanup"]["within_deadline"]:
            result["status"] = "UNKNOWN"
        outputs["result.json"] = json.dumps(result, ensure_ascii=False, indent=2).encode()
        attempt("write_final_result", lambda: write(root, "result.json", result))
        attempt("emit_evidence", lambda: emit(outputs, phase, review, readback, completion_readback, workspace_visual))
    return exit_code if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
